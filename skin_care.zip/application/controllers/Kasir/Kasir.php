<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kasir extends CI_Controller {


    public function __construct() {
        parent::__construct();
        if ($this->session->userdata('login')=="") {
            redirect('Auth');
        }
        $this->load->library('Template','template');
        $this->load->model('User_model','user');
        $this->load->model('Pegawai_model','pegawai');
        $this->load->model('Pasien_model','pasien');
        $this->load->model('Group_access_model','group_access');
        $this->load->model('Menu_model','menu');
        $this->load->model('Menu_access_model','menu_access');
        $this->load->model('Kelurahan_model','kelurahan');
        $this->load->model('Pendaftaran_model','pendaftaran');
        $this->load->model('PemakaianObat_model','pemakaian_obat');
        $this->load->model('Trx_tindakan_model','trx_tindakan');
        $this->load->model('Detail_trx_tindakan_model','detail_trx_tindakan');
        $this->load->model('Billing_model','Billing');
        $this->load->helper('date');
        $this->load->helper('tanggal');
        date_default_timezone_set("Asia/Jakarta");

    }
    public function index(){
        $data['TagihanPasien'] = $this->Billing->readTagihanPasien(date('Y-m-d'));
        $this->template->layout('Kasir/TagihanPasien/table',$data);
    }
    public function listTagihanPasien(){
      $tgl = $this->input->post('tgl');
      $data['TagihanPasien'] = $this->Billing->readTagihanPasien($tgl);
      $this->load->view('Kasir/TagihanPasien/list',$data);
    }
    public function detailTagihan($id){
      $data['pendaftaran'] = $this->Billing->getDetail($id);
      $data['pendaftaran']->detailHead = $this->trx_tindakan->getByPendaftaran($data['pendaftaran']->id_trx_pendaftaran);
      foreach ($data['pendaftaran']->detailHead as $key => $head) {
          $data['pendaftaran']->detailHead[$key]->detailBody = $this->detail_trx_tindakan->getByTrx($head->id_trx_tindakan);
          foreach ($data['pendaftaran']->detailHead[$key]->detailBody as $keyb => $value) {
            $data['pendaftaran']->detailHead[$key]->detailBody[$keyb]->DetailPemakaian = $this->pemakaian_obat->read($value->id_detail_trx_tindakan);
          }
      }
      $this->template->layout('Kasir/TagihanPasien/detail',$data);
    }

    public function Bayar(){
      $post = json_decode($this->input->post('post'));
      $billing['nilai_tagihan'] = $post->total;
      $billing['nilai_terbayar'] = $post->bayar;
      $billing['id_mst_pegawai'] = $this->session->userdata('id_mst_pegawai');
      $billing['is_update'] = date('Y-m-d');
      $pendaftaran['is_update'] = date('Y-m-d');
      $pendaftaran['flag_lunas'] = '1';
      if ($post->bayar >= $post->total) {
          $this->db->trans_start();
            $this->Billing->update($billing,$post->idBilling);
            $this->pendaftaran->update($pendaftaran,$post->idPendaftaran);
          $this->db->trans_complete();
          if ($this->db->trans_status() === false) {
            echo json_encode($data['code'] = '300');
          }else{
              $data['code'] = '200';
              $data['status'] = 'Lunas';
              $data['sisa'] = $post->bayar - $post->total;
              echo json_encode($data);
          }
      }else{
        echo json_encode($data['code'] = '400');
      }
    }

}
