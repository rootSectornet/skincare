<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tpenjualan extends CI_Controller {


    public function __construct() {
        parent::__construct();
        if ($this->session->userdata('login')=="") {
            redirect('Auth');
        }
        $this->load->library('Template','template');
        $this->load->model('User_model','user');
        $this->load->model('Pegawai_model','pegawai');
        $this->load->model('Pasien_model','pasien');
        $this->load->model('Group_access_model','group_access');
        $this->load->model('Menu_model','menu');
        $this->load->model('Menu_access_model','menu_access');
        $this->load->model('Kelurahan_model','kelurahan');
        $this->load->model('Pendaftaran_model','pendaftaran');
        $this->load->model('PemakaianObat_model','pemakaian_obat');
        $this->load->model('Trx_tindakan_model','trx_tindakan');
        $this->load->model('Detail_trx_tindakan_model','detail_trx_tindakan');
        $this->load->model('Billing_model','Billing');
        $this->load->model('Penjualan_model','penjualan');
        $this->load->model('Detail_penjualan_model','detailPenjualan');
        $this->load->model('Retur_model','Retur');
        $this->load->helper('date');
        $this->load->helper('tanggal');
        date_default_timezone_set("Asia/Jakarta");

    }
    public function index(){
        $data['TagihanPenjualan'] = $this->Billing->readTagihanPenjualan(date('Y-m-d'));
        $this->template->layout('Kasir/TagihanPenjualan/table',$data);
    }
    public function listTagihanPenjualan(){
      $tgl = $this->input->post('tgl');
      $data['TagihanPenjualan'] = $this->Billing->readTagihanPenjualan($tgl);
      $this->load->view('Kasir/TagihanPenjualan/list',$data);
    }
    public function detailTagihan($id){
        $data['tagihan'] = $this->Billing->readById($id);
        $data['tagihan']->detail = $this->detailPenjualan->getByNoFaktur($data['tagihan']->faktur_penjualan);
        foreach ($data['tagihan']->detail as $key => $row) {
          $data['tagihan']->detail[$key]->retur = $this->Retur->getByIdDetail($row->id_detail_penjualan);
        }
      $this->template->layout('Kasir/TagihanPenjualan/detail',$data);
    }
    public function Bayar(){
      $post = json_decode($this->input->post('post'));
      $billing['nilai_tagihan'] = $post->total;
      $billing['nilai_terbayar'] = $post->bayar;
      $billing['id_mst_pegawai'] = $this->session->userdata('id_mst_pegawai');
      $billing['is_update'] = date('Y-m-d');
      $head['is_update'] = date('Y-m-d');
      $head['flag_lunas'] = '1';
      if ($post->bayar >= $post->total) {
          $this->db->trans_start();
            $this->Billing->update($billing,$post->idBilling);
            $this->penjualan->update($head,$post->faktur);
          $this->db->trans_complete();
          if ($this->db->trans_status() === false) {
            echo json_encode($data['code'] = '300');
          }else{
              $data['code'] = '200';
              $data['status'] = 'Lunas';
              $data['sisa'] = $post->bayar - $post->total;
              $data['bayar'] = $post->bayar;
              echo json_encode($data);
          }
      }else{
        echo json_encode($data['code'] = '400');
      }
    }
}
