<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penjualan extends CI_Controller {


    public function __construct() {
        parent::__construct();
        if ($this->session->userdata('login')=="") {
            redirect('Auth');
        }
        $this->load->library('Template','template');
        $this->load->model('Pegawai_model','pegawai');
        $this->load->model('Suplier_model','suplier');
        $this->load->model('Product_model','product');
        $this->load->model('Penjualan_model','penjualan');
        $this->load->model('Detail_penjualan_model','detailPenjualan');
        $this->load->model('Retur_model','Retur');
        $this->load->model('Billing_model','Billing');
        $this->load->helper('date');
        $this->load->helper('tanggal');
        date_default_timezone_set("Asia/Jakarta");

    }
    public function index(){
        $data['penjualan'] = $this->penjualan->getoneDay(date('Y-m-d'));
        $this->template->layout('penjualan/table',$data);
    }
    public function create(){
      if(count($this->input->post()) > 0){
        $post = $this->input->post();
        $this->db->trans_start();
        $total = 0;
          foreach ($post['detail'] as $key => $rows) {
            $total += $rows['sub_total'];
          }
          $post['head']['total'] = $total;
          $post['head']['id_mst_pegawai'] = $this->session->userdata('id_mst_pegawai');
          $this->penjualan->create($post['head']);
          $billing['id_tagihan'] = $post['head']['faktur_penjualan'];
          $billing['flag_from'] = '2';
          $billing['id_mst_pegawai'] = $this->session->userdata('id_mst_pegawai');
          $this->Billing->create($billing);
            foreach ($post['detail'] as $key => $row) {
              $row['faktur_penjualan'] = $post['head']['faktur_penjualan'];
              $Stock = $this->product->getStock($row['id_product']);
              $dataProduct = array(
                'qty' => $Stock - $row['qty'],
                'is_update' => date('Y-m-d')
              );
              $this->product->update($dataProduct,$row['id_product']);
              $this->detailPenjualan->create($row);
            }
        $this->db->trans_complete();
        if ($this->db->trans_status() === false) {
           $this->session->set_flashdata("pesan_eror",AlertFailed(' Gagal Menyimpan Data ! '));
           redirect('gudang/penjualan/','refresh');
        }else{
           $this->session->set_flashdata("pesan_eror",AlertSuccess(' Berhasil Menyimpan Data !'));
               redirect('gudang/penjualan/detail/'.$post['head']['faktur_penjualan'],'refresh');
        }
      }
      $data['faktur'] = $this->penjualan->NoFaktur();
      $this->template->layout('penjualan/create',$data);
    }

    public function edit($NoFaktur){
      if (count($this->input->post()) > 0) {
        $post = $this->input->post();
        $this->db->trans_start();
        $total = 0;
          foreach ($post['detail'] as $key => $rows) {
            $total += $rows['sub_total'];
          }
          $post['head']['total'] = $total;
          $post['head']['id_mst_pegawai'] = $this->session->userdata('id_mst_pegawai');
          $this->penjualan->update($post['head'],$NoFaktur);
            foreach ($this->detailPenjualan->getByNoFaktur($NoFaktur) as $key => $value) {
              $Stock = $this->product->getStock($value->id_product);
              $dataProduct = array(
                'qty' => $Stock + $value->qty,
                'is_update' => date('Y-m-d')
              );
              echo $value->id_product;
              $this->product->update($dataProduct,$value->id_product);
              $this->detailPenjualan->delete($value->id_detail_penjualan);
            }
            foreach ($post['detail'] as $key => $row) {
              $row['faktur_penjualan'] = $post['head']['faktur_penjualan'];
              $Stock = $this->product->getStock($row['id_product']);
              $dataProduct = array(
                'qty' => $Stock - $row['qty'],
                'is_update' => date('Y-m-d')
              );
              $this->product->update($dataProduct,$row['id_product']);
              $this->detailPenjualan->create($row);
            }
        $this->db->trans_complete();
        if ($this->db->trans_status() === false) {
           $this->session->set_flashdata("pesan_eror",AlertFailed(' Gagal Menyimpan Data ! '));
           redirect('gudang/penjualan/','refresh');
        }else{
           $this->session->set_flashdata("pesan_eror",AlertSuccess(' Berhasil Menyimpan Data !'));
               redirect('gudang/penjualan/detail/'.$post['head']['faktur_penjualan'],'refresh');
        }
      }
      $data['penjualan']['head'] = $this->penjualan->getById($NoFaktur);
      $data['penjualan']['detail'] = $this->detailPenjualan->getByNoFaktur($NoFaktur);
      $this->template->layout('penjualan/edit',$data);
    }

    public function list_penjualan(){
      $tgl = $this->input->post('tgl');
      $data['penjualan'] = $this->penjualan->getoneDay($tgl);
      $this->load->view('penjualan/list',$data);
    }

    public function detail($NoFaktur){
      $data['penjualan']['head'] = $this->penjualan->getById($NoFaktur);
      $data['penjualan']['detail'] = $this->detailPenjualan->getByNoFaktur($NoFaktur);
      foreach ($data['penjualan']['detail'] as $key => $row) {
        $data['penjualan']['detail'][$key]->retur = $this->Retur->getByIdDetail($row->id_detail_penjualan);
      }
      $this->template->layout('penjualan/detail',$data);
    }
    public function delete($NoFaktur){
        $hasil = $this->Billing->getByIdTagihan($NoFaktur);
        $this->db->trans_start();
          $this->Billing->delete($hasil->id_billing);
          $this->penjualan->delete($NoFaktur);
        $this->db->trans_complete();
        if ($this->db->trans_status() === false) {
           $this->session->set_flashdata("pesan_eror",AlertFailed(' Gagal Hapus  Data !, Silahkan Kosongkan Terlebih Dahulu  DetailNya'));
           redirect('gudang/penjualan/','refresh');
        }else{
           $this->session->set_flashdata("pesan_eror",AlertSuccess(' Berhasil Hapus Data !'));
           redirect('gudang/penjualan/','refresh');
        }
    }

    public function retur(){
      $post = json_decode($this->input->post('post'));
      $updateDetail['flag_retur'] = '1';
      $updateDetail['is_update'] = date('Y-m-d');
      $DetailLama = $this->detailPenjualan->getById($post->id_detail);
      $TotalTr = $this->penjualan->getTotal($DetailLama->faktur_penjualan);
      $StockBaik = $this->product->getStock($DetailLama->id_product);
      $StockRusak = $this->product->getStockRusak($DetailLama->id_product);
      $StockExp = $this->product->getStockExp($DetailLama->id_product);
      $updateHead['total'] = $TotalTr - $DetailLama->sub_total + $post->sub_total;
      $updateHead['is_update'] = date('Y-m-d');
      if($post->kondisi == '1'){
        $updateProduct['qty'] = $StockBaik + $DetailLama->qty;
      }elseif ($post->kondisi == '2') {
        $updateProduct['qty_rusak'] = $StockRusak + $DetailLama->qty;
      }else{
        $updateProduct['qty_exp'] = $StockExp + $DetailLama->qty;
      }
      $this->db->trans_start();
        $this->product->update($updateProduct,$DetailLama->id_product);
        $this->detailPenjualan->update($updateDetail,$post->id_detail);
      $this->db->trans_complete();
      if ($this->db->trans_status() === false) {
          echo json_encode($data['code'] = '300');
      }else{
          $retur['id_detail'] = $post->id_detail;
          $retur['tgl'] = date('Y-m-d');
          $retur['id_product'] = $post->id_product;
          $retur['qty_retur'] = $post->qty_retur;
          $retur['keterangan'] = $post->keterangan;
          $retur['harga_beli'] = $post->harga_beli;
          $retur['harga_jual'] = $post->harga_jual;
          $retur['sub_total'] = $post->sub_total;
          $retur['id_mst_pegawai'] = $this->session->userdata('id_mst_pegawai');
          $retur['flag_from'] = '1';
          $retur['flag_active'] = '1';
          $retur['kondisi'] = $post->kondisi;
          $stock = $this->product->getStock($post->id_product);
          $updateProductBaru['qty'] = $stock - $post->qty_retur;
          $this->db->trans_start();
            $this->Retur->create($retur);
            $this->penjualan->update($updateHead,$DetailLama->faktur_penjualan);
            $this->product->update($updateProductBaru,$post->id_product);
          $this->db->trans_complete();
          if ($this->db->trans_status() === false) {
              echo json_encode($data['code'] = '400');
          }else{
              $data['code'] = '200';
              $data['id'] = $post->id_detail;
              $data['total'] = $updateHead['total'];
              $data['nama_obat'] = $post->nama_product;
              $data['qty'] = $post->qty_retur;
              $data['harga'] = $retur['harga_jual'];
              $data['sub_total'] = $retur['sub_total'];
              echo json_encode($data);
          }
      }
    }

}
