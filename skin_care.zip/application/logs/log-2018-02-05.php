<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-02-05 06:02:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 06:02:50 --> Severity: Notice --> Undefined property: Template::$session C:\xamppz\htdocs\skin_care\application\libraries\Template.php 10
ERROR - 2018-02-05 06:02:50 --> Severity: Error --> Call to a member function userdata() on null C:\xamppz\htdocs\skin_care\application\libraries\Template.php 10
DEBUG - 2018-02-05 06:03:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 06:03:37 --> Severity: Notice --> Undefined property: Template::$load C:\xamppz\htdocs\skin_care\application\libraries\Template.php 13
ERROR - 2018-02-05 06:03:37 --> Severity: Error --> Call to a member function model() on null C:\xamppz\htdocs\skin_care\application\libraries\Template.php 13
DEBUG - 2018-02-05 06:06:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 06:06:45 --> Severity: Notice --> Undefined variable: CI C:\xamppz\htdocs\skin_care\application\libraries\Template.php 10
ERROR - 2018-02-05 06:06:45 --> Severity: Error --> Cannot access empty property C:\xamppz\htdocs\skin_care\application\libraries\Template.php 10
DEBUG - 2018-02-05 06:07:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 06:07:02 --> Severity: Notice --> Undefined variable: CI C:\xamppz\htdocs\skin_care\application\libraries\Template.php 10
ERROR - 2018-02-05 06:07:02 --> Severity: Error --> Cannot access empty property C:\xamppz\htdocs\skin_care\application\libraries\Template.php 10
DEBUG - 2018-02-05 06:07:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 06:07:06 --> Severity: Notice --> Undefined property: Template::$menu_access C:\xamppz\htdocs\skin_care\application\libraries\Template.php 17
ERROR - 2018-02-05 06:07:06 --> Severity: Error --> Call to a member function getBygroup() on null C:\xamppz\htdocs\skin_care\application\libraries\Template.php 17
DEBUG - 2018-02-05 06:07:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 06:07:21 --> Severity: Notice --> Undefined property: Template::$Menu_access_model C:\xamppz\htdocs\skin_care\application\libraries\Template.php 17
ERROR - 2018-02-05 06:07:21 --> Severity: Error --> Call to a member function getBygroup() on null C:\xamppz\htdocs\skin_care\application\libraries\Template.php 17
DEBUG - 2018-02-05 06:07:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:07:31 --> Total execution time: 0.0910
DEBUG - 2018-02-05 06:09:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:09:34 --> Total execution time: 0.0624
DEBUG - 2018-02-05 06:11:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:11:39 --> Total execution time: 0.0624
DEBUG - 2018-02-05 06:34:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 06:34:34 --> Severity: Notice --> Undefined variable: temp_sub_menu C:\xamppz\htdocs\skin_care\application\libraries\Template.php 35
DEBUG - 2018-02-05 06:34:34 --> Total execution time: 0.0624
DEBUG - 2018-02-05 06:35:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:35:07 --> Total execution time: 0.0624
DEBUG - 2018-02-05 06:35:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:35:56 --> Total execution time: 0.0624
DEBUG - 2018-02-05 06:39:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:39:09 --> Total execution time: 0.0780
DEBUG - 2018-02-05 06:39:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 06:39:55 --> Severity: Warning --> Cannot use a scalar value as an array C:\xamppz\htdocs\skin_care\application\libraries\Template.php 30
ERROR - 2018-02-05 06:39:55 --> Severity: Warning --> Cannot use a scalar value as an array C:\xamppz\htdocs\skin_care\application\libraries\Template.php 30
DEBUG - 2018-02-05 06:39:55 --> Total execution time: 0.0624
DEBUG - 2018-02-05 06:40:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:40:14 --> Total execution time: 0.0468
DEBUG - 2018-02-05 06:40:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:40:58 --> Total execution time: 0.0624
DEBUG - 2018-02-05 06:44:05 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:44:05 --> Total execution time: 0.0780
DEBUG - 2018-02-05 06:49:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 06:49:26 --> Severity: Notice --> Undefined property: stdClass::$menu C:\xamppz\htdocs\skin_care\application\views\Template\Menu.php 81
ERROR - 2018-02-05 06:49:26 --> Severity: Notice --> Undefined property: stdClass::$menu C:\xamppz\htdocs\skin_care\application\views\Template\Menu.php 81
ERROR - 2018-02-05 06:49:26 --> Severity: Notice --> Undefined property: stdClass::$menu C:\xamppz\htdocs\skin_care\application\views\Template\Menu.php 89
DEBUG - 2018-02-05 06:49:26 --> Total execution time: 0.0936
DEBUG - 2018-02-05 06:50:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:50:58 --> Total execution time: 0.0468
DEBUG - 2018-02-05 06:52:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:52:00 --> Total execution time: 0.0624
DEBUG - 2018-02-05 06:52:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:52:18 --> Total execution time: 0.0780
DEBUG - 2018-02-05 06:52:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 06:52:26 --> 404 Page Not Found: Pasien/create
DEBUG - 2018-02-05 06:52:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:52:29 --> Total execution time: 0.0780
DEBUG - 2018-02-05 06:52:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:52:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 06:52:35 --> 404 Page Not Found: Pasien/create
DEBUG - 2018-02-05 06:52:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:52:36 --> Total execution time: 0.0936
DEBUG - 2018-02-05 06:53:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:53:13 --> Total execution time: 0.0624
DEBUG - 2018-02-05 06:53:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:53:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 06:53:19 --> 404 Page Not Found: Pasien/index
DEBUG - 2018-02-05 06:53:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:53:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 06:53:25 --> 404 Page Not Found: Pasien/create
DEBUG - 2018-02-05 06:53:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:53:26 --> Total execution time: 0.0624
DEBUG - 2018-02-05 06:55:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:55:44 --> Total execution time: 0.0936
DEBUG - 2018-02-05 06:57:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:57:08 --> Total execution time: 0.0780
DEBUG - 2018-02-05 06:57:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:57:18 --> Total execution time: 0.0624
DEBUG - 2018-02-05 06:58:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:58:25 --> Total execution time: 0.0936
DEBUG - 2018-02-05 06:58:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 06:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 06:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 06:58:31 --> Total execution time: 0.0936
DEBUG - 2018-02-05 07:06:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:06:39 --> Total execution time: 0.0624
DEBUG - 2018-02-05 07:06:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:06:47 --> Total execution time: 0.0624
DEBUG - 2018-02-05 07:07:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:07:03 --> Total execution time: 0.0624
DEBUG - 2018-02-05 07:09:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:09:19 --> Total execution time: 0.0780
DEBUG - 2018-02-05 07:09:57 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:09:57 --> Total execution time: 0.0624
DEBUG - 2018-02-05 07:10:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:10:14 --> Total execution time: 0.0624
DEBUG - 2018-02-05 07:12:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:12:02 --> Total execution time: 0.0624
DEBUG - 2018-02-05 07:12:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:12:04 --> Total execution time: 0.2100
DEBUG - 2018-02-05 07:12:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:12:06 --> No URI present. Default controller set.
DEBUG - 2018-02-05 07:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:12:06 --> Total execution time: 0.0710
DEBUG - 2018-02-05 07:12:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:12:10 --> No URI present. Default controller set.
DEBUG - 2018-02-05 07:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:12:10 --> Total execution time: 0.0468
DEBUG - 2018-02-05 07:12:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:12:18 --> No URI present. Default controller set.
DEBUG - 2018-02-05 07:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:12:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:12:18 --> Total execution time: 0.0624
DEBUG - 2018-02-05 07:15:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 07:15:43 --> Severity: Parsing Error --> syntax error, unexpected '?' C:\xamppz\htdocs\skin_care\application\views\Template\Menu.php 80
DEBUG - 2018-02-05 07:16:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:16:10 --> Total execution time: 0.0468
DEBUG - 2018-02-05 07:16:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:16:21 --> Total execution time: 0.0624
DEBUG - 2018-02-05 07:16:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:16:22 --> Total execution time: 0.0468
DEBUG - 2018-02-05 07:16:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:16:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 07:16:24 --> 404 Page Not Found: Pasien/create
DEBUG - 2018-02-05 07:16:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:16:25 --> Total execution time: 0.0780
DEBUG - 2018-02-05 07:16:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:16:28 --> Total execution time: 0.0624
DEBUG - 2018-02-05 07:16:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:16:29 --> Total execution time: 0.0624
DEBUG - 2018-02-05 07:33:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 07:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 07:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 07:33:27 --> Total execution time: 0.0624
DEBUG - 2018-02-05 08:16:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 08:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 08:16:21 --> Total execution time: 0.1248
DEBUG - 2018-02-05 08:19:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 08:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 08:19:21 --> Total execution time: 0.0624
DEBUG - 2018-02-05 08:19:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 08:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 08:19:45 --> Total execution time: 0.0624
DEBUG - 2018-02-05 08:28:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:28:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 08:28:37 --> 404 Page Not Found: sdm/Pegawai/1
DEBUG - 2018-02-05 08:28:41 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 08:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 08:28:41 --> Total execution time: 0.0780
DEBUG - 2018-02-05 08:39:16 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 08:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 08:39:16 --> Total execution time: 0.0624
DEBUG - 2018-02-05 08:39:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 08:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 08:39:44 --> Total execution time: 0.0624
DEBUG - 2018-02-05 08:41:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 08:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 08:41:15 --> Total execution time: 0.0468
DEBUG - 2018-02-05 08:49:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 08:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 08:49:26 --> Total execution time: 0.0780
DEBUG - 2018-02-05 08:49:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 08:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 08:49:28 --> Total execution time: 0.0950
DEBUG - 2018-02-05 08:53:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 08:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 08:53:04 --> Total execution time: 0.0624
DEBUG - 2018-02-05 08:54:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 08:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 08:54:21 --> Total execution time: 0.0780
DEBUG - 2018-02-05 08:55:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 08:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 08:55:03 --> Total execution time: 0.0624
DEBUG - 2018-02-05 08:55:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 08:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 08:55:17 --> Total execution time: 0.0780
DEBUG - 2018-02-05 08:56:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 08:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 08:56:34 --> Total execution time: 0.0780
DEBUG - 2018-02-05 08:56:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 08:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 08:56:40 --> Total execution time: 0.0780
DEBUG - 2018-02-05 08:58:11 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 08:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 08:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 08:58:11 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:00:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:00:25 --> Total execution time: 0.0624
DEBUG - 2018-02-05 09:00:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:00:42 --> Total execution time: 0.0468
DEBUG - 2018-02-05 09:01:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:01:09 --> Total execution time: 0.0624
DEBUG - 2018-02-05 09:01:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:01:29 --> Total execution time: 0.0624
DEBUG - 2018-02-05 09:01:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:01:46 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:01:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:01:59 --> Total execution time: 0.0468
DEBUG - 2018-02-05 09:07:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:07:28 --> Total execution time: 0.0624
DEBUG - 2018-02-05 09:07:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:07:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 09:07:30 --> 404 Page Not Found: sdm/Pegawai/index2
DEBUG - 2018-02-05 09:07:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:07:33 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:07:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:07:39 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:17:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:17:29 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:17:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:17:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:17:49 --> Total execution time: 0.0936
DEBUG - 2018-02-05 09:19:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:19:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:19:02 --> Total execution time: 0.0624
DEBUG - 2018-02-05 09:22:41 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:22:41 --> Total execution time: 0.0624
DEBUG - 2018-02-05 09:22:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:22:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:22:54 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:25:16 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:25:16 --> Total execution time: 0.1092
DEBUG - 2018-02-05 09:25:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:25:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:25:23 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:29:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:29:22 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:33:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:33:17 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:33:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 09:33:19 --> 404 Page Not Found: Pegawai/update
DEBUG - 2018-02-05 09:33:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:33:21 --> Total execution time: 0.0600
DEBUG - 2018-02-05 09:33:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 09:33:23 --> 404 Page Not Found: Pegawai/update
DEBUG - 2018-02-05 09:33:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:33:24 --> Total execution time: 0.1092
DEBUG - 2018-02-05 09:33:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:33:38 --> Total execution time: 0.0624
DEBUG - 2018-02-05 09:33:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:33:39 --> Total execution time: 0.0550
DEBUG - 2018-02-05 09:33:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:33:44 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:35:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:35:45 --> Total execution time: 0.0468
DEBUG - 2018-02-05 09:35:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:35:47 --> Total execution time: 0.1190
DEBUG - 2018-02-05 09:35:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:35:49 --> Total execution time: 0.0790
DEBUG - 2018-02-05 09:35:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:35:50 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:35:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:35:52 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:38:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:38:08 --> Total execution time: 0.0468
DEBUG - 2018-02-05 09:38:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:38:12 --> Total execution time: 0.0610
DEBUG - 2018-02-05 09:38:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:38:15 --> Total execution time: 0.0670
DEBUG - 2018-02-05 09:38:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:38:29 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:38:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:38:32 --> Total execution time: 0.0624
DEBUG - 2018-02-05 09:38:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:38:35 --> Total execution time: 0.0624
DEBUG - 2018-02-05 09:38:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:38:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:38:45 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:39:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 15:39:49 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:39:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:39:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 15:39:53 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:41:57 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 15:41:57 --> Total execution time: 0.0936
DEBUG - 2018-02-05 09:45:16 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:45:16 --> Total execution time: 0.0624
DEBUG - 2018-02-05 09:45:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 15:45:19 --> Total execution time: 0.0624
DEBUG - 2018-02-05 09:47:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 15:47:31 --> Total execution time: 0.0624
DEBUG - 2018-02-05 09:47:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:47:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 15:47:35 --> Total execution time: 0.1260
DEBUG - 2018-02-05 09:47:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:47:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 15:47:40 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:47:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 15:47:56 --> Total execution time: 0.0624
DEBUG - 2018-02-05 09:47:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 09:48:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 15:48:00 --> Total execution time: 0.0630
DEBUG - 2018-02-05 09:48:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 15:48:33 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:56:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 15:56:56 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:56:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 15:56:58 --> Total execution time: 0.1092
DEBUG - 2018-02-05 09:57:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 15:57:50 --> Total execution time: 0.0780
DEBUG - 2018-02-05 09:57:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 09:57:52 --> 404 Page Not Found: sdm/Group/index
DEBUG - 2018-02-05 09:58:05 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Undefined property: mysqli::$nama_group C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 30
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Undefined property: mysqli::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 32
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Undefined property: mysqli::$nama_group C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 32
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Undefined property: mysqli::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 33
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Undefined property: mysqli::$nama_group C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 33
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Undefined property: mysqli_result::$nama_group C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 30
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Undefined property: mysqli_result::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 32
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Undefined property: mysqli_result::$nama_group C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 32
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Undefined property: mysqli_result::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 33
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Undefined property: mysqli_result::$nama_group C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 33
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 30
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 32
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 32
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 33
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 33
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 30
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 32
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 32
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 33
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 33
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 30
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 32
ERROR - 2018-02-05 15:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 32
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 33
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 33
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 30
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 32
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 32
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 33
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 33
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 30
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 32
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 32
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 33
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 33
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 30
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 32
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 32
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 33
ERROR - 2018-02-05 15:58:06 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\sdm\group\table.php 33
DEBUG - 2018-02-05 15:58:06 --> Total execution time: 0.1560
DEBUG - 2018-02-05 09:58:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 09:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 15:58:23 --> Total execution time: 0.0624
DEBUG - 2018-02-05 09:59:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 09:59:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 09:59:13 --> 404 Page Not Found: Pasien/create
DEBUG - 2018-02-05 10:04:05 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:04:05 --> Total execution time: 0.1092
DEBUG - 2018-02-05 10:04:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 16:04:06 --> Severity: Notice --> Undefined variable: data C:\xamppz\htdocs\skin_care\application\controllers\Sdm\Group.php 24
DEBUG - 2018-02-05 16:04:06 --> Total execution time: 0.1060
DEBUG - 2018-02-05 10:04:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:04:24 --> Total execution time: 0.0624
DEBUG - 2018-02-05 10:09:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:09:39 --> Total execution time: 0.0780
DEBUG - 2018-02-05 10:11:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:11:37 --> Total execution time: 0.0624
DEBUG - 2018-02-05 10:14:05 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:14:05 --> Total execution time: 0.1092
DEBUG - 2018-02-05 10:14:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:14:20 --> Total execution time: 0.2964
DEBUG - 2018-02-05 10:14:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:14:21 --> Total execution time: 0.0780
DEBUG - 2018-02-05 10:17:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:17:35 --> Total execution time: 0.0780
DEBUG - 2018-02-05 10:17:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 10:17:41 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:17:41 --> Total execution time: 0.0624
DEBUG - 2018-02-05 10:21:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:21:36 --> Total execution time: 0.0936
DEBUG - 2018-02-05 10:21:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:21:38 --> Total execution time: 0.0750
DEBUG - 2018-02-05 10:21:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:21:40 --> Total execution time: 0.0690
DEBUG - 2018-02-05 10:21:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:21:42 --> Total execution time: 0.0780
DEBUG - 2018-02-05 10:21:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 10:21:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:21:47 --> Total execution time: 0.0780
DEBUG - 2018-02-05 10:22:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 10:22:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:22:22 --> Total execution time: 0.1092
DEBUG - 2018-02-05 10:27:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:27:59 --> Total execution time: 0.1390
DEBUG - 2018-02-05 10:28:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:28:48 --> Total execution time: 0.0790
DEBUG - 2018-02-05 10:30:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:30:46 --> Total execution time: 0.1060
DEBUG - 2018-02-05 10:36:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:36:59 --> Total execution time: 0.0750
DEBUG - 2018-02-05 10:38:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:38:13 --> Total execution time: 0.0850
DEBUG - 2018-02-05 10:38:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:38:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 10:38:15 --> 404 Page Not Found: sistem//index
DEBUG - 2018-02-05 10:38:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:38:50 --> Total execution time: 0.0960
DEBUG - 2018-02-05 10:38:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 16:38:52 --> Severity: Error --> Call to undefined method Menu_model::read() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 21
DEBUG - 2018-02-05 10:50:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 10:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 10:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 16:50:56 --> Total execution time: 0.1250
DEBUG - 2018-02-05 12:33:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:33:36 --> No URI present. Default controller set.
DEBUG - 2018-02-05 12:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 12:33:37 --> Total execution time: 1.3426
DEBUG - 2018-02-05 12:33:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:33:48 --> No URI present. Default controller set.
DEBUG - 2018-02-05 12:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 12:33:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 12:33:49 --> Total execution time: 0.3900
DEBUG - 2018-02-05 12:35:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 12:35:52 --> Total execution time: 0.0780
DEBUG - 2018-02-05 12:35:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 12:35:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 12:35:55 --> Total execution time: 0.0630
DEBUG - 2018-02-05 12:35:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 12:35:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 12:35:59 --> Total execution time: 0.0624
DEBUG - 2018-02-05 12:36:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 12:36:03 --> 404 Page Not Found: Pegawai/index
DEBUG - 2018-02-05 12:36:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:36:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 12:36:09 --> 404 Page Not Found: Pegawai/pegawai
DEBUG - 2018-02-05 12:36:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 12:36:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 12:36:17 --> Total execution time: 0.0468
DEBUG - 2018-02-05 12:36:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 12:36:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 12:36:23 --> Total execution time: 0.0780
DEBUG - 2018-02-05 12:36:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:36:26 --> Severity: Error --> Call to undefined method Menu_model::read() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 21
DEBUG - 2018-02-05 12:37:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Undefined property: mysqli::$menu C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 33
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Undefined property: mysqli::$link C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 34
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Undefined property: mysqli::$icon C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 35
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Undefined property: mysqli::$is_main_menu C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 36
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Undefined property: mysqli::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Undefined property: mysqli::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Undefined property: mysqli::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Undefined property: mysqli::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Undefined property: mysqli_result::$menu C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 33
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Undefined property: mysqli_result::$link C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 34
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Undefined property: mysqli_result::$icon C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 35
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Undefined property: mysqli_result::$is_main_menu C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 36
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Undefined property: mysqli_result::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Undefined property: mysqli_result::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Undefined property: mysqli_result::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Undefined property: mysqli_result::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 33
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 34
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 35
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 36
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 33
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 34
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 35
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 36
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 33
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 34
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 35
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 36
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 33
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 34
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 35
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 36
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 33
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 34
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 35
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 36
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 33
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 34
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 35
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 36
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
DEBUG - 2018-02-05 18:37:39 --> Total execution time: 0.4992
DEBUG - 2018-02-05 12:37:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 38
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$id_mst_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
ERROR - 2018-02-05 18:37:51 --> Severity: Notice --> Undefined property: stdClass::$nama_group C:\xamppz\htdocs\skin_care\application\views\system\menu\table.php 39
DEBUG - 2018-02-05 18:37:51 --> Total execution time: 0.1872
DEBUG - 2018-02-05 12:38:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 18:38:20 --> Total execution time: 0.0936
DEBUG - 2018-02-05 12:45:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 18:45:21 --> Total execution time: 0.0936
DEBUG - 2018-02-05 12:45:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:45:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xamppz\htdocs\skin_care\application\views\system\menu\create.php 42
DEBUG - 2018-02-05 18:45:23 --> Total execution time: 0.1090
DEBUG - 2018-02-05 12:46:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:46:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xamppz\htdocs\skin_care\application\views\system\menu\create.php 42
DEBUG - 2018-02-05 18:46:17 --> Total execution time: 0.1092
DEBUG - 2018-02-05 12:47:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:47:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xamppz\htdocs\skin_care\application\views\system\menu\create.php 42
DEBUG - 2018-02-05 18:47:25 --> Total execution time: 0.0780
DEBUG - 2018-02-05 12:47:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:47:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xamppz\htdocs\skin_care\application\views\system\menu\create.php 42
DEBUG - 2018-02-05 18:47:40 --> Total execution time: 0.1248
DEBUG - 2018-02-05 12:49:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:49:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xamppz\htdocs\skin_care\application\views\system\menu\create.php 42
DEBUG - 2018-02-05 18:49:01 --> Total execution time: 0.0780
DEBUG - 2018-02-05 12:50:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:50:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xamppz\htdocs\skin_care\application\views\system\menu\create.php 42
DEBUG - 2018-02-05 18:50:00 --> Total execution time: 0.0780
DEBUG - 2018-02-05 12:50:41 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:50:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xamppz\htdocs\skin_care\application\views\system\menu\create.php 42
DEBUG - 2018-02-05 18:50:42 --> Total execution time: 0.0780
DEBUG - 2018-02-05 12:51:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:51:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xamppz\htdocs\skin_care\application\views\system\menu\create.php 42
DEBUG - 2018-02-05 18:51:25 --> Total execution time: 0.0780
DEBUG - 2018-02-05 12:51:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:51:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xamppz\htdocs\skin_care\application\views\system\menu\create.php 42
DEBUG - 2018-02-05 18:51:49 --> Total execution time: 0.0780
DEBUG - 2018-02-05 12:53:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:53:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xamppz\htdocs\skin_care\application\views\system\menu\create.php 42
DEBUG - 2018-02-05 18:53:09 --> Total execution time: 0.0780
DEBUG - 2018-02-05 12:53:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:53:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xamppz\htdocs\skin_care\application\views\system\menu\create.php 42
DEBUG - 2018-02-05 18:53:32 --> Total execution time: 0.1092
DEBUG - 2018-02-05 12:53:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:53:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xamppz\htdocs\skin_care\application\views\system\menu\create.php 42
DEBUG - 2018-02-05 18:53:45 --> Total execution time: 0.0780
DEBUG - 2018-02-05 12:56:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:56:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xamppz\htdocs\skin_care\application\views\system\menu\create.php 42
DEBUG - 2018-02-05 18:56:42 --> Total execution time: 0.0780
DEBUG - 2018-02-05 12:57:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:57:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xamppz\htdocs\skin_care\application\views\system\menu\create.php 42
DEBUG - 2018-02-05 18:57:14 --> Total execution time: 0.0936
DEBUG - 2018-02-05 12:57:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:57:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xamppz\htdocs\skin_care\application\views\system\menu\create.php 42
DEBUG - 2018-02-05 18:57:59 --> Total execution time: 0.0780
DEBUG - 2018-02-05 12:58:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 18:58:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xamppz\htdocs\skin_care\application\views\system\menu\create.php 42
DEBUG - 2018-02-05 18:58:02 --> Total execution time: 0.0810
DEBUG - 2018-02-05 12:58:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 12:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 12:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 18:58:53 --> Total execution time: 0.1092
DEBUG - 2018-02-05 13:00:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:00:09 --> Total execution time: 0.0780
DEBUG - 2018-02-05 13:00:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:00:13 --> Total execution time: 0.1250
DEBUG - 2018-02-05 13:01:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:01:12 --> Total execution time: 0.0780
DEBUG - 2018-02-05 13:01:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:01:19 --> Total execution time: 0.0936
DEBUG - 2018-02-05 13:02:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:02:14 --> Total execution time: 0.0624
DEBUG - 2018-02-05 13:02:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:02:20 --> Total execution time: 0.0780
DEBUG - 2018-02-05 13:06:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:06:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 13:06:01 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 29
DEBUG - 2018-02-05 13:06:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:06:17 --> Total execution time: 0.0780
DEBUG - 2018-02-05 13:06:57 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 13:06:57 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:06:57 --> Total execution time: 0.0936
DEBUG - 2018-02-05 13:09:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:09:46 --> Total execution time: 0.1092
DEBUG - 2018-02-05 13:10:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:10:09 --> Total execution time: 0.0624
DEBUG - 2018-02-05 13:10:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:10:10 --> Total execution time: 0.0650
DEBUG - 2018-02-05 13:19:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:19:28 --> Total execution time: 0.2028
DEBUG - 2018-02-05 13:27:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:27:02 --> Total execution time: 0.0780
DEBUG - 2018-02-05 13:27:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:27:05 --> Total execution time: 0.1210
DEBUG - 2018-02-05 13:30:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:30:47 --> Total execution time: 0.0780
DEBUG - 2018-02-05 13:35:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:35:31 --> Total execution time: 0.0936
DEBUG - 2018-02-05 13:35:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:35:53 --> Total execution time: 0.0624
DEBUG - 2018-02-05 13:38:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:38:44 --> Total execution time: 0.0624
DEBUG - 2018-02-05 13:38:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:38:45 --> Total execution time: 0.1092
DEBUG - 2018-02-05 13:38:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 13:38:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:38:50 --> Total execution time: 0.0624
DEBUG - 2018-02-05 13:38:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:38:53 --> Total execution time: 0.0624
DEBUG - 2018-02-05 13:38:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:38:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 13:38:55 --> 404 Page Not Found: sistem/System/get_menu_akses
DEBUG - 2018-02-05 13:38:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 13:38:56 --> 404 Page Not Found: sistem/System/get_menu_akses
DEBUG - 2018-02-05 13:39:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:39:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 13:39:08 --> 404 Page Not Found: sistem/System/get_menu_akses
DEBUG - 2018-02-05 13:40:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:40:25 --> Total execution time: 0.0780
DEBUG - 2018-02-05 13:40:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 19:40:39 --> Severity: Warning --> Missing argument 2 for Menu_access_model::getBygroup(), called in C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php on line 71 and defined C:\xamppz\htdocs\skin_care\application\models\Menu_access_model.php 8
ERROR - 2018-02-05 19:40:39 --> Severity: Notice --> Undefined variable: is_main_menu C:\xamppz\htdocs\skin_care\application\models\Menu_access_model.php 10
ERROR - 2018-02-05 19:40:39 --> Severity: Notice --> Undefined variable: data C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 72
DEBUG - 2018-02-05 13:40:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 19:40:42 --> Severity: Warning --> Missing argument 2 for Menu_access_model::getBygroup(), called in C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php on line 71 and defined C:\xamppz\htdocs\skin_care\application\models\Menu_access_model.php 8
ERROR - 2018-02-05 19:40:42 --> Severity: Notice --> Undefined variable: is_main_menu C:\xamppz\htdocs\skin_care\application\models\Menu_access_model.php 10
ERROR - 2018-02-05 19:40:42 --> Severity: Notice --> Undefined variable: data C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 72
DEBUG - 2018-02-05 13:40:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 19:40:43 --> Severity: Warning --> Missing argument 2 for Menu_access_model::getBygroup(), called in C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php on line 71 and defined C:\xamppz\htdocs\skin_care\application\models\Menu_access_model.php 8
ERROR - 2018-02-05 19:40:43 --> Severity: Notice --> Undefined variable: is_main_menu C:\xamppz\htdocs\skin_care\application\models\Menu_access_model.php 10
ERROR - 2018-02-05 19:40:43 --> Severity: Notice --> Undefined variable: data C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 72
DEBUG - 2018-02-05 13:40:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 19:40:49 --> Severity: Warning --> Missing argument 2 for Menu_access_model::getBygroup(), called in C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php on line 71 and defined C:\xamppz\htdocs\skin_care\application\models\Menu_access_model.php 8
ERROR - 2018-02-05 19:40:49 --> Severity: Notice --> Undefined variable: is_main_menu C:\xamppz\htdocs\skin_care\application\models\Menu_access_model.php 10
ERROR - 2018-02-05 19:40:49 --> Severity: Notice --> Undefined variable: data C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 72
DEBUG - 2018-02-05 13:42:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:42:10 --> Total execution time: 0.0780
DEBUG - 2018-02-05 13:42:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 19:42:14 --> Severity: Notice --> Undefined variable: data C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 72
DEBUG - 2018-02-05 13:42:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:42:35 --> Total execution time: 0.0780
DEBUG - 2018-02-05 13:42:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 13:43:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:43:37 --> Total execution time: 0.0780
DEBUG - 2018-02-05 13:43:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:43:45 --> Total execution time: 0.0624
DEBUG - 2018-02-05 13:44:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:44:03 --> Total execution time: 0.0780
DEBUG - 2018-02-05 13:44:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:44:08 --> Total execution time: 0.0500
DEBUG - 2018-02-05 13:44:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:44:14 --> Total execution time: 0.0468
DEBUG - 2018-02-05 13:45:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:45:31 --> Total execution time: 0.0780
DEBUG - 2018-02-05 13:45:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:45:46 --> Total execution time: 0.0780
DEBUG - 2018-02-05 13:45:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:45:49 --> Total execution time: 0.0680
DEBUG - 2018-02-05 13:45:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:45:51 --> Total execution time: 0.0500
DEBUG - 2018-02-05 13:45:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:45:52 --> Total execution time: 0.0468
DEBUG - 2018-02-05 13:45:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:45:54 --> Total execution time: 0.0780
DEBUG - 2018-02-05 13:46:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:46:02 --> Total execution time: 0.0780
DEBUG - 2018-02-05 13:51:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:51:55 --> Total execution time: 0.0780
DEBUG - 2018-02-05 13:51:57 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:51:57 --> Total execution time: 0.1070
DEBUG - 2018-02-05 13:52:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:52:37 --> Total execution time: 0.0740
DEBUG - 2018-02-05 13:56:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:56:46 --> Total execution time: 0.1370
DEBUG - 2018-02-05 13:57:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 13:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 13:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 19:57:42 --> Total execution time: 0.0900
DEBUG - 2018-02-05 14:08:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 20:08:28 --> Total execution time: 0.0780
DEBUG - 2018-02-05 14:08:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 20:08:37 --> Total execution time: 0.0624
DEBUG - 2018-02-05 14:08:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 20:08:50 --> Total execution time: 0.0780
DEBUG - 2018-02-05 14:12:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 20:12:49 --> Total execution time: 0.0780
DEBUG - 2018-02-05 14:13:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-05 20:13:07 --> Query error: Unknown column 'is_main_menu' in 'field list' - Invalid query: INSERT INTO `menu_akses` (`is_main_menu`) VALUES ('1')
DEBUG - 2018-02-05 20:13:07 --> DB Transaction Failure
DEBUG - 2018-02-05 14:13:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 20:13:39 --> Total execution time: 0.0624
DEBUG - 2018-02-05 14:13:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 14:13:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 20:13:46 --> Total execution time: 0.0780
DEBUG - 2018-02-05 14:15:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 14:15:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 14:15:45 --> Total execution time: 0.0936
DEBUG - 2018-02-05 14:15:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 14:16:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 14:16:00 --> Total execution time: 0.0624
DEBUG - 2018-02-05 14:16:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 14:16:21 --> Total execution time: 0.0780
DEBUG - 2018-02-05 14:17:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 14:17:37 --> Total execution time: 0.0624
DEBUG - 2018-02-05 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 14:17:46 --> Total execution time: 0.0468
DEBUG - 2018-02-05 14:17:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 14:17:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 14:17:50 --> Total execution time: 0.0780
DEBUG - 2018-02-05 14:18:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 20:18:12 --> Total execution time: 0.0624
DEBUG - 2018-02-05 14:18:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 20:18:15 --> Total execution time: 0.0624
DEBUG - 2018-02-05 14:18:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 14:18:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 20:18:23 --> Total execution time: 0.0780
DEBUG - 2018-02-05 14:18:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 20:18:30 --> Total execution time: 0.0780
DEBUG - 2018-02-05 14:18:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 20:18:35 --> Total execution time: 0.0624
DEBUG - 2018-02-05 14:32:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:32:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-05 14:32:49 --> 404 Page Not Found: sistem/System/group_akses
DEBUG - 2018-02-05 14:32:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 20:32:50 --> Total execution time: 0.0780
DEBUG - 2018-02-05 14:36:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 14:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 14:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 20:36:23 --> Total execution time: 0.0624
DEBUG - 2018-02-05 15:21:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 15:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 15:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 21:21:54 --> Total execution time: 0.0936
DEBUG - 2018-02-05 15:23:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 15:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 15:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 21:23:31 --> Total execution time: 0.0624
DEBUG - 2018-02-05 18:06:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 18:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 18:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 18:06:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 18:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 18:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 18:06:38 --> Total execution time: 0.1310
DEBUG - 2018-02-05 18:06:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 18:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 18:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 18:06:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 18:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 18:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 18:06:44 --> Total execution time: 0.1000
DEBUG - 2018-02-05 18:06:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 18:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 18:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 18:06:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 18:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 18:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-05 18:06:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-05 18:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-05 18:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
