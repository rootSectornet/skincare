<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-02-06 00:06:48 --> Total execution time: 0.0650
DEBUG - 2018-02-06 00:06:51 --> Total execution time: 0.0780
DEBUG - 2018-02-06 00:06:55 --> Total execution time: 0.1300
DEBUG - 2018-02-06 07:03:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:03:56 --> No URI present. Default controller set.
DEBUG - 2018-02-06 07:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 07:03:56 --> Total execution time: 0.1070
DEBUG - 2018-02-06 07:04:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:04:07 --> No URI present. Default controller set.
DEBUG - 2018-02-06 07:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 07:04:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 07:04:08 --> Total execution time: 0.0960
DEBUG - 2018-02-06 07:04:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:04:18 --> Total execution time: 0.0610
DEBUG - 2018-02-06 07:04:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:04:20 --> Total execution time: 0.0890
DEBUG - 2018-02-06 07:04:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:04:23 --> Total execution time: 0.0690
DEBUG - 2018-02-06 07:04:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:04:25 --> Total execution time: 0.0790
DEBUG - 2018-02-06 07:04:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:04:28 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
DEBUG - 2018-02-06 13:04:28 --> Total execution time: 0.0600
DEBUG - 2018-02-06 07:04:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 07:04:36 --> Total execution time: 0.0580
DEBUG - 2018-02-06 07:15:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:15:22 --> Total execution time: 0.0770
DEBUG - 2018-02-06 07:24:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:24:42 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
DEBUG - 2018-02-06 13:24:42 --> Total execution time: 0.0550
DEBUG - 2018-02-06 07:24:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:24:44 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
DEBUG - 2018-02-06 13:24:44 --> Total execution time: 0.0590
DEBUG - 2018-02-06 07:24:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:24:47 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
DEBUG - 2018-02-06 13:24:47 --> Total execution time: 0.0590
DEBUG - 2018-02-06 07:24:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:24:48 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
DEBUG - 2018-02-06 13:24:48 --> Total execution time: 0.0610
DEBUG - 2018-02-06 07:24:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:24:49 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
DEBUG - 2018-02-06 13:24:49 --> Total execution time: 0.0960
DEBUG - 2018-02-06 07:24:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:24:51 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
DEBUG - 2018-02-06 13:24:51 --> Total execution time: 0.0530
DEBUG - 2018-02-06 07:24:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:24:52 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
DEBUG - 2018-02-06 13:24:52 --> Total execution time: 0.0530
DEBUG - 2018-02-06 07:24:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:24:53 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
DEBUG - 2018-02-06 13:24:53 --> Total execution time: 0.0500
DEBUG - 2018-02-06 07:24:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:24:54 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
DEBUG - 2018-02-06 13:24:54 --> Total execution time: 0.0490
DEBUG - 2018-02-06 07:24:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:24:55 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
DEBUG - 2018-02-06 13:24:55 --> Total execution time: 0.0530
DEBUG - 2018-02-06 07:24:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:24:56 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
DEBUG - 2018-02-06 13:24:56 --> Total execution time: 0.0530
DEBUG - 2018-02-06 07:24:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:24:58 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
DEBUG - 2018-02-06 13:24:58 --> Total execution time: 0.0560
DEBUG - 2018-02-06 07:24:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:24:59 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
DEBUG - 2018-02-06 13:24:59 --> Total execution time: 0.0660
DEBUG - 2018-02-06 07:25:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:25:01 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
DEBUG - 2018-02-06 13:25:01 --> Total execution time: 0.0570
DEBUG - 2018-02-06 07:25:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:25:02 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
DEBUG - 2018-02-06 13:25:02 --> Total execution time: 0.0500
DEBUG - 2018-02-06 07:43:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:43:20 --> Total execution time: 0.0650
DEBUG - 2018-02-06 07:43:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:43:24 --> Severity: Warning --> Missing argument 1 for System::get_group_akses() C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 106
ERROR - 2018-02-06 13:43:24 --> Severity: Notice --> Undefined variable: id C:\xamppz\htdocs\skin_care\application\controllers\Sistem\System.php 107
DEBUG - 2018-02-06 13:43:24 --> Total execution time: 0.0640
DEBUG - 2018-02-06 07:44:05 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:44:05 --> Total execution time: 0.0730
DEBUG - 2018-02-06 07:44:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:44:07 --> Total execution time: 0.0790
DEBUG - 2018-02-06 07:44:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:44:08 --> Total execution time: 0.0560
DEBUG - 2018-02-06 07:44:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:44:10 --> Total execution time: 0.0590
DEBUG - 2018-02-06 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:44:11 --> Total execution time: 0.0630
DEBUG - 2018-02-06 07:44:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:44:12 --> Total execution time: 0.0610
DEBUG - 2018-02-06 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:44:13 --> Total execution time: 0.0610
DEBUG - 2018-02-06 07:44:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:44:15 --> Total execution time: 0.0590
DEBUG - 2018-02-06 07:44:16 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:44:16 --> Total execution time: 0.0610
DEBUG - 2018-02-06 07:44:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:44:17 --> Total execution time: 0.0530
DEBUG - 2018-02-06 07:44:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:44:18 --> Total execution time: 0.0624
DEBUG - 2018-02-06 07:44:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:44:20 --> Total execution time: 0.1000
DEBUG - 2018-02-06 07:54:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:54:20 --> Total execution time: 0.0700
DEBUG - 2018-02-06 07:54:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 07:54:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:54:26 --> Total execution time: 0.0860
DEBUG - 2018-02-06 07:54:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:54:53 --> Total execution time: 0.0700
DEBUG - 2018-02-06 07:55:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 13:55:01 --> Severity: Notice --> Undefined property: stdClass::$id_mst_pegawai C:\xamppz\htdocs\skin_care\application\views\system\group_akses\create.php 34
ERROR - 2018-02-06 13:55:01 --> Severity: Notice --> Undefined property: stdClass::$nama_pegawai C:\xamppz\htdocs\skin_care\application\views\system\group_akses\create.php 34
ERROR - 2018-02-06 13:55:01 --> Severity: Notice --> Undefined property: stdClass::$id_mst_pegawai C:\xamppz\htdocs\skin_care\application\views\system\group_akses\create.php 34
ERROR - 2018-02-06 13:55:01 --> Severity: Notice --> Undefined property: stdClass::$nama_pegawai C:\xamppz\htdocs\skin_care\application\views\system\group_akses\create.php 34
ERROR - 2018-02-06 13:55:01 --> Severity: Notice --> Undefined property: stdClass::$id_mst_pegawai C:\xamppz\htdocs\skin_care\application\views\system\group_akses\create.php 34
ERROR - 2018-02-06 13:55:01 --> Severity: Notice --> Undefined property: stdClass::$nama_pegawai C:\xamppz\htdocs\skin_care\application\views\system\group_akses\create.php 34
DEBUG - 2018-02-06 13:55:01 --> Total execution time: 0.0860
DEBUG - 2018-02-06 07:55:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:55:21 --> Total execution time: 0.0710
DEBUG - 2018-02-06 07:55:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:55:29 --> Total execution time: 0.0960
DEBUG - 2018-02-06 07:56:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:56:49 --> Total execution time: 0.0630
DEBUG - 2018-02-06 07:56:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:56:53 --> Total execution time: 0.0710
DEBUG - 2018-02-06 07:56:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:56:56 --> Total execution time: 0.0640
DEBUG - 2018-02-06 07:58:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:58:33 --> Total execution time: 0.0610
DEBUG - 2018-02-06 07:58:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:58:36 --> Total execution time: 0.0970
DEBUG - 2018-02-06 07:58:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 07:58:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 07:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 07:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:58:56 --> Total execution time: 0.0710
DEBUG - 2018-02-06 08:15:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 08:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 08:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 14:15:28 --> Total execution time: 0.0890
DEBUG - 2018-02-06 08:15:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 08:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 08:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 14:15:37 --> Total execution time: 0.0660
DEBUG - 2018-02-06 08:15:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 08:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 08:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 14:15:42 --> Total execution time: 0.0790
DEBUG - 2018-02-06 08:16:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 08:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 08:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 08:16:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 08:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 08:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 14:16:33 --> Total execution time: 0.0680
DEBUG - 2018-02-06 08:16:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 08:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 08:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 14:16:42 --> Total execution time: 0.0850
DEBUG - 2018-02-06 08:16:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 08:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 08:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 14:16:44 --> Total execution time: 0.0840
DEBUG - 2018-02-06 08:16:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 08:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 08:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 08:16:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 08:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 08:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 14:16:53 --> Total execution time: 0.0820
DEBUG - 2018-02-06 08:16:57 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 08:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 08:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 14:16:57 --> Total execution time: 0.0700
DEBUG - 2018-02-06 09:23:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:23:44 --> Total execution time: 0.5770
DEBUG - 2018-02-06 09:23:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:23:47 --> Total execution time: 0.0820
DEBUG - 2018-02-06 09:26:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:26:55 --> Total execution time: 0.0940
DEBUG - 2018-02-06 09:27:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 09:27:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:27:13 --> Total execution time: 0.0860
DEBUG - 2018-02-06 09:39:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:39:44 --> Total execution time: 0.0700
DEBUG - 2018-02-06 09:41:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:41:09 --> Total execution time: 0.0900
DEBUG - 2018-02-06 09:41:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:41:21 --> Total execution time: 0.0700
DEBUG - 2018-02-06 09:46:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:46:18 --> Total execution time: 0.0800
DEBUG - 2018-02-06 09:46:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:46:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 09:46:33 --> 404 Page Not Found: sdm/Pegawai/sdm
DEBUG - 2018-02-06 09:46:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:46:37 --> Total execution time: 0.0700
DEBUG - 2018-02-06 09:47:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:47:39 --> Total execution time: 0.0800
DEBUG - 2018-02-06 09:47:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:47:39 --> Total execution time: 0.0900
DEBUG - 2018-02-06 09:48:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:48:17 --> Total execution time: 0.0700
DEBUG - 2018-02-06 09:48:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:48:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 09:48:21 --> 404 Page Not Found: sdm/Pegawai/sdm
DEBUG - 2018-02-06 09:48:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:48:43 --> Total execution time: 0.0700
DEBUG - 2018-02-06 09:48:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 15:48:47 --> Severity: Warning --> Missing argument 1 for Pegawai::ganti_pass() C:\xamppz\htdocs\skin_care\application\controllers\Sdm\Pegawai.php 122
DEBUG - 2018-02-06 15:48:47 --> Total execution time: 0.1200
DEBUG - 2018-02-06 09:49:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:49:00 --> Total execution time: 0.0700
DEBUG - 2018-02-06 09:49:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:49:02 --> Total execution time: 0.0600
DEBUG - 2018-02-06 09:49:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:49:04 --> Total execution time: 0.0600
DEBUG - 2018-02-06 09:49:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:49:07 --> Total execution time: 0.0500
DEBUG - 2018-02-06 09:49:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:49:09 --> Total execution time: 0.0800
DEBUG - 2018-02-06 09:49:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:49:37 --> Total execution time: 0.0800
DEBUG - 2018-02-06 09:49:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:49:52 --> Total execution time: 0.0600
DEBUG - 2018-02-06 09:53:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:53:20 --> Total execution time: 0.0600
DEBUG - 2018-02-06 09:53:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:53:26 --> Total execution time: 0.0800
DEBUG - 2018-02-06 09:53:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 15:53:32 --> Query error: Unknown column 'submit' in 'field list' - Invalid query: UPDATE `user_login` SET `id_user` = '3', `password` = '$2y$10$dp/Au8F6gNZcecRus52IqOGS3mofBtHY1XGu4tPtSme0B./RYCHNO', `submit` = ''
WHERE `id_user` = '3'
DEBUG - 2018-02-06 15:53:32 --> DB Transaction Failure
DEBUG - 2018-02-06 09:53:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:53:55 --> Total execution time: 0.0800
DEBUG - 2018-02-06 09:54:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 09:54:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:54:00 --> Total execution time: 0.0700
DEBUG - 2018-02-06 09:54:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 09:54:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:54:19 --> Total execution time: 0.0700
DEBUG - 2018-02-06 09:54:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 09:54:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 09:54:30 --> Total execution time: 0.0500
DEBUG - 2018-02-06 09:54:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 09:54:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 09:54:36 --> Total execution time: 0.1300
DEBUG - 2018-02-06 09:54:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:54:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 09:54:38 --> 404 Page Not Found: Pasien/index
DEBUG - 2018-02-06 09:54:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 09:54:39 --> Total execution time: 0.0600
DEBUG - 2018-02-06 09:54:41 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 09:54:41 --> Total execution time: 0.0600
DEBUG - 2018-02-06 09:54:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 09:54:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 09:54:55 --> Total execution time: 0.0500
DEBUG - 2018-02-06 09:54:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 09:54:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 09:54:58 --> Total execution time: 0.0700
DEBUG - 2018-02-06 09:55:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 09:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 09:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 15:55:09 --> Total execution time: 0.0600
DEBUG - 2018-02-06 10:01:05 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:01:05 --> Total execution time: 0.0800
DEBUG - 2018-02-06 10:02:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 16:02:14 --> Severity: Notice --> Undefined property: stdClass::$nama_pegawai C:\xamppz\htdocs\skin_care\application\views\sdm\pegawai\user\update.php 33
DEBUG - 2018-02-06 16:02:14 --> Total execution time: 0.0800
DEBUG - 2018-02-06 10:02:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:02:30 --> Total execution time: 0.0700
DEBUG - 2018-02-06 10:02:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:02:34 --> Total execution time: 0.0730
DEBUG - 2018-02-06 10:02:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:02:35 --> Total execution time: 0.0860
DEBUG - 2018-02-06 10:02:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:02:39 --> Total execution time: 0.0700
DEBUG - 2018-02-06 10:02:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:02:40 --> Total execution time: 0.0900
DEBUG - 2018-02-06 10:02:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:02:45 --> Total execution time: 0.0700
DEBUG - 2018-02-06 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:03:38 --> Total execution time: 0.0600
DEBUG - 2018-02-06 10:03:41 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 10:03:41 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:03:41 --> Total execution time: 0.0700
DEBUG - 2018-02-06 10:05:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:05:18 --> Total execution time: 0.0700
DEBUG - 2018-02-06 10:05:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 10:05:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:05:22 --> Total execution time: 0.0660
DEBUG - 2018-02-06 10:05:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:05:35 --> Total execution time: 0.0600
DEBUG - 2018-02-06 10:06:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:06:52 --> Total execution time: 0.0700
DEBUG - 2018-02-06 10:07:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 10:07:28 --> Total execution time: 0.0600
DEBUG - 2018-02-06 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:32:47 --> Total execution time: 0.1200
DEBUG - 2018-02-06 10:33:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:33:26 --> Total execution time: 0.0840
DEBUG - 2018-02-06 10:33:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:33:28 --> Total execution time: 0.0790
DEBUG - 2018-02-06 10:33:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:33:39 --> Total execution time: 0.0740
DEBUG - 2018-02-06 10:33:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:33:50 --> Total execution time: 0.0690
DEBUG - 2018-02-06 10:34:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:35:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 10:35:00 --> 404 Page Not Found: Pasien/create
DEBUG - 2018-02-06 10:35:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:35:01 --> Total execution time: 0.0760
DEBUG - 2018-02-06 10:36:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:36:02 --> Total execution time: 0.1140
DEBUG - 2018-02-06 10:36:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:36:04 --> Total execution time: 0.1000
DEBUG - 2018-02-06 10:36:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:36:17 --> Total execution time: 0.0740
DEBUG - 2018-02-06 10:36:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:36:21 --> Total execution time: 0.0680
DEBUG - 2018-02-06 10:36:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:36:29 --> Total execution time: 0.0660
DEBUG - 2018-02-06 10:37:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:37:45 --> Total execution time: 0.0910
DEBUG - 2018-02-06 10:37:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:37:47 --> Total execution time: 0.0930
DEBUG - 2018-02-06 10:43:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:43:47 --> Total execution time: 0.0720
DEBUG - 2018-02-06 10:43:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:43:48 --> Total execution time: 0.0560
DEBUG - 2018-02-06 10:43:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:43:49 --> Total execution time: 0.0630
DEBUG - 2018-02-06 10:43:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:43:50 --> Total execution time: 0.0680
DEBUG - 2018-02-06 10:43:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:43:51 --> Total execution time: 0.0580
DEBUG - 2018-02-06 10:43:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:43:58 --> Total execution time: 0.0670
DEBUG - 2018-02-06 10:43:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:43:59 --> Total execution time: 0.0550
DEBUG - 2018-02-06 10:44:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:44:00 --> Total execution time: 0.0760
DEBUG - 2018-02-06 10:44:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:44:02 --> Total execution time: 0.0650
DEBUG - 2018-02-06 10:44:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:44:03 --> Total execution time: 0.0560
DEBUG - 2018-02-06 10:44:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:44:04 --> Total execution time: 0.0650
DEBUG - 2018-02-06 10:44:05 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:44:05 --> Total execution time: 0.1510
DEBUG - 2018-02-06 10:44:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:44:06 --> Total execution time: 0.0550
DEBUG - 2018-02-06 10:44:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:44:08 --> Total execution time: 0.0700
DEBUG - 2018-02-06 10:44:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:44:08 --> Total execution time: 0.0630
DEBUG - 2018-02-06 10:44:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:44:09 --> Total execution time: 0.0540
DEBUG - 2018-02-06 10:44:11 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:44:11 --> Total execution time: 0.0610
DEBUG - 2018-02-06 10:44:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:44:12 --> Total execution time: 0.0600
DEBUG - 2018-02-06 10:44:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:44:13 --> Total execution time: 0.0730
DEBUG - 2018-02-06 10:44:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:44:14 --> Total execution time: 0.0570
DEBUG - 2018-02-06 10:50:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:50:38 --> Total execution time: 0.0660
DEBUG - 2018-02-06 10:50:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:50:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 10:50:46 --> 404 Page Not Found: pasien/Pasein/index
DEBUG - 2018-02-06 10:51:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 10:51:01 --> 404 Page Not Found: Pasien/Pasein/index
DEBUG - 2018-02-06 10:51:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 16:51:25 --> Total execution time: 0.0700
DEBUG - 2018-02-06 10:51:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 10:51:48 --> Total execution time: 0.0590
DEBUG - 2018-02-06 10:53:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 10:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 10:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 10:53:01 --> Total execution time: 0.0700
DEBUG - 2018-02-06 11:08:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 11:08:25 --> Total execution time: 0.0530
DEBUG - 2018-02-06 11:08:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 17:08:25 --> Total execution time: 0.0670
DEBUG - 2018-02-06 11:08:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 17:08:26 --> Total execution time: 0.0640
DEBUG - 2018-02-06 11:08:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 17:08:27 --> Total execution time: 0.0700
DEBUG - 2018-02-06 11:08:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 11:08:28 --> Total execution time: 0.0650
DEBUG - 2018-02-06 11:16:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 11:16:24 --> Total execution time: 0.0670
DEBUG - 2018-02-06 11:16:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-06 11:16:56 --> Severity: Notice --> Array to string conversion C:\xamppz\htdocs\skin_care\application\controllers\Pasien\Pasien.php 25
ERROR - 2018-02-06 11:16:56 --> Severity: Notice --> Array to string conversion C:\xamppz\htdocs\skin_care\application\controllers\Pasien\Pasien.php 25
DEBUG - 2018-02-06 11:16:56 --> Total execution time: 0.0540
DEBUG - 2018-02-06 11:18:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:18:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 11:18:32 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xamppz\htdocs\skin_care\application\controllers\Pasien\Pasien.php 31
DEBUG - 2018-02-06 11:54:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 17:54:51 --> Total execution time: 0.4870
DEBUG - 2018-02-06 11:55:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 17:55:39 --> Total execution time: 0.0720
DEBUG - 2018-02-06 11:55:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 17:55:45 --> Total execution time: 0.0810
DEBUG - 2018-02-06 11:56:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 17:56:01 --> Total execution time: 0.0770
DEBUG - 2018-02-06 11:56:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 11:56:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 17:56:13 --> Total execution time: 0.0680
DEBUG - 2018-02-06 11:56:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 17:56:29 --> Total execution time: 0.0790
DEBUG - 2018-02-06 11:56:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 17:56:31 --> Total execution time: 0.0750
DEBUG - 2018-02-06 11:56:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 11:56:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 17:56:40 --> Total execution time: 0.0680
DEBUG - 2018-02-06 11:56:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 17:56:42 --> Total execution time: 0.1060
DEBUG - 2018-02-06 11:56:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 11:56:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 17:56:48 --> Total execution time: 0.0680
DEBUG - 2018-02-06 11:56:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:56:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 11:56:56 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xamppz\htdocs\skin_care\application\controllers\Pasien\Pasien.php 23
DEBUG - 2018-02-06 11:57:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 11:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 11:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 11:57:03 --> Total execution time: 0.0670
DEBUG - 2018-02-06 12:56:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 12:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 12:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 12:56:45 --> Total execution time: 0.1300
DEBUG - 2018-02-06 12:56:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 12:56:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-06 12:56:50 --> 404 Page Not Found: pasien/Create/index
DEBUG - 2018-02-06 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 12:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 12:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 12:56:54 --> Total execution time: 0.0600
DEBUG - 2018-02-06 12:56:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 12:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 12:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 18:56:57 --> Total execution time: 0.1000
DEBUG - 2018-02-06 12:57:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 12:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 12:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 18:57:00 --> Total execution time: 0.1300
DEBUG - 2018-02-06 12:57:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 12:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 12:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 18:57:04 --> Total execution time: 0.0600
DEBUG - 2018-02-06 13:21:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 13:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 13:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 19:21:23 --> Total execution time: 0.0800
DEBUG - 2018-02-06 13:41:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-06 13:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-06 13:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-06 13:41:33 --> Total execution time: 0.0600
