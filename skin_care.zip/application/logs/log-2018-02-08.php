<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-02-08 13:49:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 13:49:53 --> No URI present. Default controller set.
DEBUG - 2018-02-08 13:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 13:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 13:49:54 --> Total execution time: 1.2792
DEBUG - 2018-02-08 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 13:50:03 --> No URI present. Default controller set.
DEBUG - 2018-02-08 13:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 13:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 13:50:03 --> Total execution time: 0.0780
DEBUG - 2018-02-08 13:50:05 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 13:50:05 --> No URI present. Default controller set.
DEBUG - 2018-02-08 13:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 13:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 13:50:05 --> Total execution time: 0.0468
DEBUG - 2018-02-08 13:50:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 13:50:37 --> No URI present. Default controller set.
DEBUG - 2018-02-08 13:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 13:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 13:50:37 --> Total execution time: 0.0780
DEBUG - 2018-02-08 13:50:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 13:50:42 --> No URI present. Default controller set.
DEBUG - 2018-02-08 13:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 13:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 13:50:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 13:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 13:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 13:50:43 --> Total execution time: 0.3120
DEBUG - 2018-02-08 13:50:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 13:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 13:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 13:50:55 --> Total execution time: 0.0780
DEBUG - 2018-02-08 13:56:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 13:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 13:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 13:56:59 --> Total execution time: 0.0780
DEBUG - 2018-02-08 14:09:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 14:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 14:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 14:09:56 --> Total execution time: 0.0780
DEBUG - 2018-02-08 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 14:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 14:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 14:17:46 --> Total execution time: 0.0624
DEBUG - 2018-02-08 14:18:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 14:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 14:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 14:18:17 --> Total execution time: 0.0780
DEBUG - 2018-02-08 14:18:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 14:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 14:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 14:18:26 --> Total execution time: 0.0624
DEBUG - 2018-02-08 14:18:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 14:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 14:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 14:18:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 14:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 14:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 14:18:38 --> Total execution time: 0.0624
DEBUG - 2018-02-08 14:18:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 14:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 14:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 14:18:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 14:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 14:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 14:18:45 --> Total execution time: 0.0624
DEBUG - 2018-02-08 14:18:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 14:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 14:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 14:18:50 --> Total execution time: 0.0780
DEBUG - 2018-02-08 14:20:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 14:20:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-08 14:20:32 --> 404 Page Not Found: Pasien/Pasien/1
DEBUG - 2018-02-08 14:20:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 14:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 14:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 14:20:33 --> Total execution time: 0.0624
DEBUG - 2018-02-08 15:08:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 15:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 15:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 15:08:19 --> Total execution time: 0.1092
DEBUG - 2018-02-08 17:54:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 17:54:01 --> No URI present. Default controller set.
DEBUG - 2018-02-08 17:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 17:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 17:54:01 --> Total execution time: 0.1275
DEBUG - 2018-02-08 17:54:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 17:54:06 --> No URI present. Default controller set.
DEBUG - 2018-02-08 17:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 17:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 17:54:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 17:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 17:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 17:54:06 --> Total execution time: 0.0760
DEBUG - 2018-02-08 17:54:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 17:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 17:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-08 17:54:10 --> Query error: Unknown column 'kecamatan.id.kab' in 'on clause' - Invalid query: SELECT *
FROM `mst_pasien`
INNER JOIN `kelurahan` ON `kelurahan`.`id_kel` = `mst_pasien`.`id_kel`
INNER JOIN `kecamatan` ON `kecamatan`.`id_kec` = `kelurahan`.`id_kec`
INNER JOIN `kabupaten` ON `kabupaten`.`id_kab` = `kecamatan`.`id`.`kab`
INNER JOIN `provinsi` ON `provinsi`.`id_prov` = `kabupaten`.`id_prov`
DEBUG - 2018-02-08 17:55:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 17:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 17:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 17:55:19 --> Total execution time: 0.0880
DEBUG - 2018-02-08 17:55:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 17:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 17:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 17:55:23 --> Total execution time: 0.0560
DEBUG - 2018-02-08 18:07:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:07:33 --> Total execution time: 0.0670
DEBUG - 2018-02-08 18:08:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:08:15 --> Total execution time: 0.0720
DEBUG - 2018-02-08 18:08:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:08:47 --> Total execution time: 0.0710
DEBUG - 2018-02-08 18:09:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:09:34 --> Total execution time: 0.0820
DEBUG - 2018-02-08 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:10:08 --> Total execution time: 0.0750
DEBUG - 2018-02-08 18:10:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:10:51 --> Total execution time: 0.0790
DEBUG - 2018-02-08 18:11:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:11:28 --> Total execution time: 0.0670
DEBUG - 2018-02-08 18:12:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:12:58 --> Total execution time: 0.0810
DEBUG - 2018-02-08 18:13:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:13:18 --> Total execution time: 0.0900
DEBUG - 2018-02-08 18:13:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:13:24 --> Total execution time: 0.0650
DEBUG - 2018-02-08 18:13:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:13:25 --> Total execution time: 0.0770
DEBUG - 2018-02-08 18:13:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:13:26 --> Total execution time: 0.0640
DEBUG - 2018-02-08 18:13:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:13:33 --> Total execution time: 0.0800
DEBUG - 2018-02-08 18:15:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:15:14 --> Total execution time: 0.0880
DEBUG - 2018-02-08 18:15:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:15:22 --> Total execution time: 0.0640
DEBUG - 2018-02-08 18:15:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:15:36 --> Total execution time: 0.0580
DEBUG - 2018-02-08 18:18:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:18:30 --> Total execution time: 0.0730
DEBUG - 2018-02-08 18:18:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:18:36 --> Total execution time: 0.0670
DEBUG - 2018-02-08 18:20:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:20:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:20:27 --> Total execution time: 0.0570
DEBUG - 2018-02-08 18:20:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:20:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:20:33 --> Total execution time: 0.1010
DEBUG - 2018-02-08 18:20:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:20:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-08 18:20:40 --> 404 Page Not Found: pasien/Create/index
DEBUG - 2018-02-08 18:20:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:20:42 --> Total execution time: 0.0820
DEBUG - 2018-02-08 18:20:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:20:45 --> Total execution time: 0.0650
DEBUG - 2018-02-08 18:20:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:20:47 --> Total execution time: 0.1590
DEBUG - 2018-02-08 18:20:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:20:53 --> Total execution time: 0.0780
DEBUG - 2018-02-08 18:21:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:21:01 --> Total execution time: 0.0700
DEBUG - 2018-02-08 18:24:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:24:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:24:12 --> Total execution time: 0.0750
DEBUG - 2018-02-08 18:24:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:24:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:24:19 --> Total execution time: 0.3920
DEBUG - 2018-02-08 18:24:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:24:25 --> Total execution time: 0.1370
DEBUG - 2018-02-08 18:24:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:24:27 --> Total execution time: 0.1850
DEBUG - 2018-02-08 18:24:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:24:34 --> Total execution time: 0.1010
DEBUG - 2018-02-08 18:25:11 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:25:11 --> Total execution time: 0.1090
DEBUG - 2018-02-08 18:25:16 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:25:16 --> Total execution time: 0.0530
DEBUG - 2018-02-08 18:25:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:25:45 --> Total execution time: 0.1130
DEBUG - 2018-02-08 18:25:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:25:49 --> Total execution time: 0.0550
DEBUG - 2018-02-08 18:25:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:25:55 --> Total execution time: 0.0770
DEBUG - 2018-02-08 18:26:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:26:37 --> Total execution time: 0.1010
DEBUG - 2018-02-08 18:26:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:26:46 --> Total execution time: 0.0870
DEBUG - 2018-02-08 18:27:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:27:59 --> Total execution time: 0.0630
DEBUG - 2018-02-08 18:28:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:28:04 --> Total execution time: 0.0750
DEBUG - 2018-02-08 18:28:05 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:28:05 --> Total execution time: 0.0740
DEBUG - 2018-02-08 18:29:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:29:21 --> Total execution time: 0.0720
DEBUG - 2018-02-08 18:29:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:29:26 --> Total execution time: 0.0630
DEBUG - 2018-02-08 18:29:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:29:37 --> Total execution time: 0.0700
DEBUG - 2018-02-08 18:29:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:29:38 --> Total execution time: 0.1110
DEBUG - 2018-02-08 18:31:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:31:50 --> Total execution time: 0.0760
DEBUG - 2018-02-08 18:31:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:31:54 --> Total execution time: 0.0730
DEBUG - 2018-02-08 18:32:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:32:06 --> Total execution time: 0.0830
DEBUG - 2018-02-08 18:32:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:32:10 --> Total execution time: 0.0530
DEBUG - 2018-02-08 18:32:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:32:28 --> Total execution time: 0.0710
DEBUG - 2018-02-08 18:32:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:32:32 --> Total execution time: 0.0730
DEBUG - 2018-02-08 18:34:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:34:54 --> Total execution time: 0.0650
DEBUG - 2018-02-08 18:34:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:34:59 --> Total execution time: 0.0550
DEBUG - 2018-02-08 18:35:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:35:29 --> Total execution time: 0.1230
DEBUG - 2018-02-08 18:35:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:35:34 --> Total execution time: 0.0790
DEBUG - 2018-02-08 18:36:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:36:27 --> Total execution time: 0.0680
DEBUG - 2018-02-08 18:36:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:36:33 --> Total execution time: 0.0680
DEBUG - 2018-02-08 18:37:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:37:45 --> Total execution time: 0.0930
DEBUG - 2018-02-08 18:37:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:37:49 --> Total execution time: 0.0540
DEBUG - 2018-02-08 18:38:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:38:01 --> Total execution time: 0.0730
DEBUG - 2018-02-08 18:38:05 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:38:06 --> Total execution time: 0.0900
DEBUG - 2018-02-08 18:38:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:38:07 --> Total execution time: 0.0740
DEBUG - 2018-02-08 18:41:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:41:02 --> Total execution time: 0.0950
DEBUG - 2018-02-08 18:41:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:41:06 --> Total execution time: 0.0660
DEBUG - 2018-02-08 18:44:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:44:38 --> Total execution time: 0.0840
DEBUG - 2018-02-08 18:44:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:44:45 --> Total execution time: 0.0530
DEBUG - 2018-02-08 18:44:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:44:58 --> Total execution time: 0.0760
DEBUG - 2018-02-08 18:45:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:45:04 --> Total execution time: 0.0530
DEBUG - 2018-02-08 18:45:05 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:45:06 --> Total execution time: 0.0870
DEBUG - 2018-02-08 18:46:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:46:18 --> Total execution time: 0.0770
DEBUG - 2018-02-08 18:46:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:46:31 --> Total execution time: 0.0650
DEBUG - 2018-02-08 18:49:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:49:56 --> Total execution time: 0.0710
DEBUG - 2018-02-08 18:50:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:50:02 --> Total execution time: 0.0610
DEBUG - 2018-02-08 18:51:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:51:02 --> Total execution time: 0.0780
DEBUG - 2018-02-08 18:51:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:51:07 --> Total execution time: 0.0710
DEBUG - 2018-02-08 18:52:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:52:29 --> Total execution time: 0.0630
DEBUG - 2018-02-08 18:52:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:52:33 --> Total execution time: 0.0670
DEBUG - 2018-02-08 18:52:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:52:47 --> Total execution time: 0.0680
DEBUG - 2018-02-08 18:52:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:52:49 --> Total execution time: 0.0770
DEBUG - 2018-02-08 18:52:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:52:53 --> Total execution time: 0.0600
DEBUG - 2018-02-08 18:52:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:52:54 --> Total execution time: 0.0600
DEBUG - 2018-02-08 18:54:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:54:14 --> Total execution time: 0.0730
DEBUG - 2018-02-08 18:55:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:55:29 --> Total execution time: 0.0670
DEBUG - 2018-02-08 18:55:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:55:50 --> Total execution time: 0.0530
DEBUG - 2018-02-08 18:55:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:55:51 --> Total execution time: 0.0690
DEBUG - 2018-02-08 18:55:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 18:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 18:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 18:55:53 --> Total execution time: 0.0820
DEBUG - 2018-02-08 19:00:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:00:53 --> Total execution time: 0.0700
DEBUG - 2018-02-08 19:01:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:01:28 --> Total execution time: 0.0580
DEBUG - 2018-02-08 19:01:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:01:29 --> Total execution time: 0.0680
DEBUG - 2018-02-08 19:01:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-08 19:01:35 --> Severity: Notice --> Undefined index: no_telp C:\xamppz\htdocs\skin_care\application\controllers\Pasien\Pasien.php 33
ERROR - 2018-02-08 19:01:35 --> Query error: Column 'no_telp' cannot be null - Invalid query: INSERT INTO `mst_pasien` (`nama_pasien`, `no_rm`, `tgl_lahir`, `no_telp`, `gender`, `alamat`, `id_kel`) VALUES ('testing', '01234', '2018-02-01', NULL, '1', 'jl, studio alam rt 01 rw 02 no 35', '1')
DEBUG - 2018-02-08 19:01:35 --> DB Transaction Failure
DEBUG - 2018-02-08 19:01:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:01:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:01:49 --> Total execution time: 0.0680
DEBUG - 2018-02-08 19:02:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:02:10 --> Total execution time: 0.0840
DEBUG - 2018-02-08 19:02:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:02:55 --> Total execution time: 0.0770
DEBUG - 2018-02-08 19:09:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:09:19 --> Total execution time: 0.0590
DEBUG - 2018-02-08 19:09:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:09:20 --> Total execution time: 0.0750
DEBUG - 2018-02-08 19:09:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:09:43 --> Total execution time: 0.0760
DEBUG - 2018-02-08 19:10:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:10:36 --> Total execution time: 0.0770
DEBUG - 2018-02-08 19:11:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:11:50 --> Total execution time: 0.0590
DEBUG - 2018-02-08 19:12:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-08 19:12:01 --> Severity: Error --> Call to undefined method Pasien_model::udpate() C:\xamppz\htdocs\skin_care\application\controllers\Pasien\Pasien.php 78
DEBUG - 2018-02-08 19:12:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:12:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:12:18 --> Total execution time: 0.0760
DEBUG - 2018-02-08 19:13:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:13:33 --> Total execution time: 0.0900
DEBUG - 2018-02-08 19:13:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:13:34 --> Total execution time: 0.0860
DEBUG - 2018-02-08 19:13:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:13:48 --> Total execution time: 0.0590
DEBUG - 2018-02-08 19:13:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:13:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:13:51 --> Total execution time: 0.0750
DEBUG - 2018-02-08 19:13:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:13:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:13:55 --> Total execution time: 0.1750
DEBUG - 2018-02-08 19:14:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:14:53 --> Total execution time: 0.0700
DEBUG - 2018-02-08 19:14:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:14:56 --> Total execution time: 0.2280
DEBUG - 2018-02-08 19:15:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:23:05 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:23:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:23:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:23:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:24:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:24:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:24:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:24:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:24:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:25:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:25:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:25:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:25:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:25:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:26:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:26:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:26:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:26:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:26:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:26:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:26:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:26:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-08 19:26:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:26:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-08 19:26:39 --> 404 Page Not Found: pendaftaran/Pendaftaran/index
DEBUG - 2018-02-08 19:27:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-08 19:27:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Pendafataran_model C:\xamppz\htdocs\skin_care\system\core\Loader.php 344
DEBUG - 2018-02-08 19:27:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-08 19:27:08 --> Query error: Unknown column 'pasien.id_mst_pasien' in 'on clause' - Invalid query: SELECT *
FROM `pendaftaran`
INNER JOIN `mst_pegawai` ON `mst_pegawai`.`id_mst_pegawai` = `pendaftaran`.`id_mst_pegawai`
INNER JOIN `mst_pasien` ON `pasien`.`id_mst_pasien` = `pendaftaran`.`id_mst_pasien`
INNER JOIN `kelurahan` ON `kelurahan`.`id_kel` = `mst_pasien`.`id_kel`
INNER JOIN `kecamatan` ON `kecamatan`.`id_kec` = `kelurahan`.`id_kec`
INNER JOIN `kabupaten` ON `kabupaten`.`id_kab` = `kecamatan`.`id_kab`
INNER JOIN `provinsi` ON `provinsi`.`id_prov` = `kabupaten`.`id_prov`
DEBUG - 2018-02-08 19:27:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-08 19:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-08 19:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
