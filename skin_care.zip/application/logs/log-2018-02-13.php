<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-02-13 00:19:22 --> Total execution time: 0.1560
DEBUG - 2018-02-13 00:21:07 --> Total execution time: 0.0936
DEBUG - 2018-02-13 00:22:14 --> Total execution time: 0.0780
DEBUG - 2018-02-13 00:22:57 --> Total execution time: 0.0624
DEBUG - 2018-02-13 00:23:08 --> Total execution time: 0.0780
DEBUG - 2018-02-13 00:24:07 --> Total execution time: 0.0840
DEBUG - 2018-02-13 00:24:23 --> Total execution time: 0.0920
DEBUG - 2018-02-13 00:25:01 --> Total execution time: 0.0890
DEBUG - 2018-02-13 00:26:56 --> Total execution time: 0.0670
DEBUG - 2018-02-13 00:27:17 --> Total execution time: 0.0810
DEBUG - 2018-02-13 00:28:00 --> Total execution time: 0.1620
DEBUG - 2018-02-13 00:29:28 --> Total execution time: 0.0660
DEBUG - 2018-02-13 00:30:10 --> Total execution time: 0.0790
DEBUG - 2018-02-13 00:30:19 --> Total execution time: 0.0980
DEBUG - 2018-02-13 00:30:32 --> Total execution time: 0.0830
DEBUG - 2018-02-13 00:30:49 --> Total execution time: 0.0780
DEBUG - 2018-02-13 00:30:56 --> Total execution time: 0.0780
DEBUG - 2018-02-13 00:31:10 --> Total execution time: 0.0910
DEBUG - 2018-02-13 00:31:38 --> Total execution time: 0.0760
DEBUG - 2018-02-13 00:32:31 --> Total execution time: 0.0860
DEBUG - 2018-02-13 00:33:16 --> Total execution time: 0.0780
DEBUG - 2018-02-13 00:33:36 --> Total execution time: 0.0800
DEBUG - 2018-02-13 00:37:57 --> Total execution time: 0.0930
DEBUG - 2018-02-13 00:38:02 --> Total execution time: 0.0870
DEBUG - 2018-02-13 00:38:45 --> Total execution time: 0.0870
DEBUG - 2018-02-13 00:38:48 --> Total execution time: 0.0580
DEBUG - 2018-02-13 00:38:53 --> Total execution time: 0.0700
DEBUG - 2018-02-13 01:16:48 --> Total execution time: 0.0880
DEBUG - 2018-02-13 01:16:54 --> Total execution time: 0.0720
DEBUG - 2018-02-13 01:17:00 --> Total execution time: 0.1690
DEBUG - 2018-02-13 01:17:06 --> Total execution time: 0.0660
DEBUG - 2018-02-13 01:17:09 --> Total execution time: 0.2060
DEBUG - 2018-02-13 01:17:23 --> Total execution time: 0.1280
DEBUG - 2018-02-13 01:17:26 --> Total execution time: 0.1320
DEBUG - 2018-02-13 01:17:50 --> Total execution time: 0.0660
DEBUG - 2018-02-13 01:17:52 --> Total execution time: 0.0760
DEBUG - 2018-02-13 01:21:43 --> Total execution time: 0.0850
DEBUG - 2018-02-13 01:21:45 --> Total execution time: 0.0720
DEBUG - 2018-02-13 01:27:31 --> Total execution time: 0.2200
DEBUG - 2018-02-13 01:27:35 --> Total execution time: 0.1230
DEBUG - 2018-02-13 01:27:37 --> Total execution time: 0.2090
DEBUG - 2018-02-13 01:27:39 --> Total execution time: 0.1160
DEBUG - 2018-02-13 01:30:19 --> Total execution time: 0.0680
DEBUG - 2018-02-13 01:30:39 --> Total execution time: 0.0870
DEBUG - 2018-02-13 01:31:40 --> Total execution time: 0.0710
DEBUG - 2018-02-13 01:32:59 --> Total execution time: 0.0780
DEBUG - 2018-02-13 01:34:25 --> Total execution time: 0.0710
DEBUG - 2018-02-13 01:35:00 --> Total execution time: 0.1080
DEBUG - 2018-02-13 01:35:18 --> Total execution time: 0.0820
DEBUG - 2018-02-13 01:36:04 --> Total execution time: 0.0860
DEBUG - 2018-02-13 01:36:16 --> Total execution time: 0.0890
DEBUG - 2018-02-13 01:36:31 --> Total execution time: 0.1000
DEBUG - 2018-02-13 01:36:48 --> Total execution time: 0.0890
DEBUG - 2018-02-13 01:39:54 --> Total execution time: 0.0740
DEBUG - 2018-02-13 01:40:09 --> Total execution time: 0.0820
DEBUG - 2018-02-13 01:58:04 --> Total execution time: 0.1040
DEBUG - 2018-02-13 01:59:06 --> Total execution time: 0.0830
DEBUG - 2018-02-13 02:01:41 --> Total execution time: 0.1130
DEBUG - 2018-02-13 02:01:49 --> Total execution time: 0.0980
DEBUG - 2018-02-13 02:01:59 --> Total execution time: 0.1010
DEBUG - 2018-02-13 02:02:07 --> Total execution time: 0.0700
DEBUG - 2018-02-13 02:02:15 --> Total execution time: 0.0800
DEBUG - 2018-02-13 02:02:20 --> Total execution time: 0.0780
DEBUG - 2018-02-13 02:05:28 --> Total execution time: 0.0900
DEBUG - 2018-02-13 02:05:43 --> Total execution time: 0.0850
DEBUG - 2018-02-13 02:06:05 --> Total execution time: 0.0780
DEBUG - 2018-02-13 02:06:56 --> Total execution time: 0.0940
DEBUG - 2018-02-13 02:07:06 --> Total execution time: 0.0730
DEBUG - 2018-02-13 02:07:11 --> Total execution time: 0.0750
DEBUG - 2018-02-13 02:07:41 --> Total execution time: 0.1700
DEBUG - 2018-02-13 02:07:43 --> Total execution time: 0.1500
DEBUG - 2018-02-13 02:07:45 --> Total execution time: 0.0970
DEBUG - 2018-02-13 02:07:52 --> Total execution time: 0.0960
DEBUG - 2018-02-13 02:08:29 --> Total execution time: 0.0790
DEBUG - 2018-02-13 02:10:21 --> Total execution time: 0.0970
DEBUG - 2018-02-13 02:10:22 --> Total execution time: 0.1000
DEBUG - 2018-02-13 02:10:23 --> Total execution time: 0.1400
DEBUG - 2018-02-13 02:10:24 --> Total execution time: 0.1140
ERROR - 2018-02-13 02:10:25 --> Severity: Notice --> Undefined variable: row C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 60
ERROR - 2018-02-13 02:10:25 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 60
ERROR - 2018-02-13 02:10:25 --> Severity: Notice --> Undefined variable: row C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 60
ERROR - 2018-02-13 02:10:25 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 60
ERROR - 2018-02-13 02:10:25 --> Severity: Notice --> Undefined variable: row C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 60
ERROR - 2018-02-13 02:10:25 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 60
DEBUG - 2018-02-13 02:10:25 --> Total execution time: 0.1350
ERROR - 2018-02-13 02:11:05 --> Severity: Notice --> Undefined variable: row C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 60
ERROR - 2018-02-13 02:11:05 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 60
DEBUG - 2018-02-13 02:11:05 --> Total execution time: 0.0820
ERROR - 2018-02-13 02:11:08 --> Severity: Notice --> Undefined variable: row C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 60
ERROR - 2018-02-13 02:11:08 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 60
DEBUG - 2018-02-13 02:11:08 --> Total execution time: 0.1440
ERROR - 2018-02-13 02:11:08 --> Severity: Notice --> Undefined variable: row C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 60
ERROR - 2018-02-13 02:11:08 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 60
DEBUG - 2018-02-13 02:11:08 --> Total execution time: 0.0890
DEBUG - 2018-02-13 02:11:22 --> Total execution time: 0.0900
DEBUG - 2018-02-13 02:11:57 --> Total execution time: 0.0820
DEBUG - 2018-02-13 02:12:20 --> Total execution time: 0.0730
DEBUG - 2018-02-13 02:19:07 --> Total execution time: 0.1248
DEBUG - 2018-02-13 02:19:45 --> Total execution time: 0.0930
DEBUG - 2018-02-13 02:19:58 --> Total execution time: 0.0770
DEBUG - 2018-02-13 02:20:19 --> Total execution time: 0.0790
DEBUG - 2018-02-13 02:20:24 --> Total execution time: 0.0960
DEBUG - 2018-02-13 02:21:27 --> Total execution time: 0.0830
DEBUG - 2018-02-13 02:21:31 --> Total execution time: 0.0830
ERROR - 2018-02-13 02:21:34 --> Severity: Notice --> Undefined offset: 0 C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 26
ERROR - 2018-02-13 02:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 26
ERROR - 2018-02-13 02:21:34 --> Severity: Notice --> Undefined offset: 0 C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 28
ERROR - 2018-02-13 02:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 28
ERROR - 2018-02-13 02:21:34 --> Severity: Notice --> Undefined offset: 0 C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 30
ERROR - 2018-02-13 02:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 30
ERROR - 2018-02-13 02:21:34 --> Severity: Notice --> Undefined offset: 0 C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 34
ERROR - 2018-02-13 02:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 34
ERROR - 2018-02-13 02:21:34 --> Severity: Notice --> Undefined offset: 0 C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 37
ERROR - 2018-02-13 02:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 37
ERROR - 2018-02-13 02:21:34 --> Severity: Notice --> Undefined offset: 0 C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 63
ERROR - 2018-02-13 02:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 63
ERROR - 2018-02-13 02:21:34 --> Severity: Notice --> Undefined offset: 0 C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 347
ERROR - 2018-02-13 02:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xamppz\htdocs\skin_care\application\views\pendaftaran\detail.php 347
DEBUG - 2018-02-13 02:21:34 --> Total execution time: 0.1850
DEBUG - 2018-02-13 02:22:00 --> Total execution time: 0.1220
DEBUG - 2018-02-13 02:22:06 --> Total execution time: 0.0770
DEBUG - 2018-02-13 02:22:08 --> Total execution time: 0.1060
DEBUG - 2018-02-13 02:23:10 --> Total execution time: 0.1010
DEBUG - 2018-02-13 02:23:15 --> Total execution time: 0.0700
DEBUG - 2018-02-13 02:23:15 --> Total execution time: 0.0540
DEBUG - 2018-02-13 02:23:17 --> Total execution time: 0.0620
DEBUG - 2018-02-13 02:23:53 --> Total execution time: 0.0750
DEBUG - 2018-02-13 02:29:05 --> Total execution time: 0.0930
DEBUG - 2018-02-13 02:29:09 --> Total execution time: 0.0620
ERROR - 2018-02-13 02:29:11 --> Query error: Column 'id_trx_tindakan' cannot be null - Invalid query: INSERT INTO `detail_trx_tindakan` (`id_trx_tindakan`, `id_mst_tindakan`, `harga`) VALUES (NULL, '2', '450000')
DEBUG - 2018-02-13 02:29:11 --> DB Transaction Failure
DEBUG - 2018-02-13 02:31:52 --> Total execution time: 0.1130
DEBUG - 2018-02-13 02:31:56 --> Total execution time: 0.0830
ERROR - 2018-02-13 02:32:14 --> Severity: Error --> Call to undefined method Detail_trx_tindakan_model::getByTrx() C:\xamppz\htdocs\skin_care\application\controllers\Pendaftaran\Pendaftaran.php 74
DEBUG - 2018-02-13 02:33:44 --> Total execution time: 0.1070
DEBUG - 2018-02-13 02:34:52 --> Total execution time: 0.1180
DEBUG - 2018-02-13 02:36:37 --> Total execution time: 0.0820
DEBUG - 2018-02-13 02:38:14 --> Total execution time: 0.1080
DEBUG - 2018-02-13 02:38:24 --> Total execution time: 0.0860
DEBUG - 2018-02-13 02:41:26 --> Total execution time: 0.0980
DEBUG - 2018-02-13 02:41:42 --> Total execution time: 0.1010
DEBUG - 2018-02-13 02:41:51 --> Total execution time: 0.0840
DEBUG - 2018-02-13 13:19:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:19:59 --> No URI present. Default controller set.
DEBUG - 2018-02-13 13:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:20:00 --> Total execution time: 1.0101
DEBUG - 2018-02-13 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:20:06 --> No URI present. Default controller set.
DEBUG - 2018-02-13 13:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 13:20:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:20:07 --> Total execution time: 0.3150
DEBUG - 2018-02-13 13:20:11 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:20:12 --> Total execution time: 0.6920
DEBUG - 2018-02-13 13:20:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:20:15 --> Total execution time: 0.4320
DEBUG - 2018-02-13 13:21:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:21:48 --> Total execution time: 0.0940
DEBUG - 2018-02-13 13:22:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:22:18 --> Total execution time: 0.0780
DEBUG - 2018-02-13 13:23:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:23:21 --> Total execution time: 0.0800
DEBUG - 2018-02-13 13:24:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:24:27 --> Total execution time: 0.0690
DEBUG - 2018-02-13 13:25:57 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:25:57 --> Total execution time: 0.0700
DEBUG - 2018-02-13 13:28:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:28:19 --> Total execution time: 0.0950
DEBUG - 2018-02-13 13:28:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:28:54 --> Total execution time: 0.1050
DEBUG - 2018-02-13 13:31:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:31:24 --> Total execution time: 0.1040
DEBUG - 2018-02-13 13:31:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:31:39 --> Total execution time: 0.1080
DEBUG - 2018-02-13 13:31:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:31:47 --> Total execution time: 0.1000
DEBUG - 2018-02-13 13:57:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:57:37 --> Total execution time: 0.0990
DEBUG - 2018-02-13 13:58:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:58:34 --> Total execution time: 0.0850
DEBUG - 2018-02-13 13:58:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:58:42 --> Total execution time: 0.1520
DEBUG - 2018-02-13 13:58:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:58:50 --> Total execution time: 0.1350
DEBUG - 2018-02-13 13:59:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:59:03 --> Total execution time: 0.0710
DEBUG - 2018-02-13 13:59:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 13:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 13:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 19:59:07 --> Total execution time: 0.1090
DEBUG - 2018-02-13 14:03:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:03:26 --> Total execution time: 0.0860
DEBUG - 2018-02-13 14:03:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:03:28 --> Total execution time: 0.1000
DEBUG - 2018-02-13 14:11:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:11:15 --> Total execution time: 0.0750
DEBUG - 2018-02-13 14:11:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:11:44 --> Total execution time: 0.0720
DEBUG - 2018-02-13 14:12:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:12:27 --> Total execution time: 0.0950
DEBUG - 2018-02-13 14:13:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:13:10 --> Total execution time: 0.1030
DEBUG - 2018-02-13 14:13:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:13:28 --> Total execution time: 0.1220
DEBUG - 2018-02-13 14:13:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:13:50 --> Total execution time: 0.1010
DEBUG - 2018-02-13 14:14:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:14:07 --> Total execution time: 0.0780
DEBUG - 2018-02-13 14:14:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:14:53 --> Total execution time: 0.0910
DEBUG - 2018-02-13 14:14:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:14:56 --> Total execution time: 0.0730
DEBUG - 2018-02-13 14:15:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:15:31 --> Total execution time: 0.0810
DEBUG - 2018-02-13 14:16:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:16:01 --> Total execution time: 0.0830
DEBUG - 2018-02-13 14:16:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:16:47 --> Total execution time: 0.0770
DEBUG - 2018-02-13 14:17:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:17:30 --> Total execution time: 0.0750
DEBUG - 2018-02-13 14:17:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:17:46 --> Total execution time: 0.0760
DEBUG - 2018-02-13 14:18:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:18:24 --> Total execution time: 0.1020
DEBUG - 2018-02-13 14:18:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:18:31 --> Total execution time: 0.0660
DEBUG - 2018-02-13 14:19:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:19:53 --> Total execution time: 0.0770
DEBUG - 2018-02-13 14:19:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:19:59 --> Total execution time: 0.0660
DEBUG - 2018-02-13 14:20:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:20:24 --> Total execution time: 0.1040
DEBUG - 2018-02-13 14:20:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:20:29 --> Total execution time: 0.0560
DEBUG - 2018-02-13 14:21:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:21:28 --> Total execution time: 0.0820
DEBUG - 2018-02-13 14:21:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:21:33 --> Total execution time: 0.0590
DEBUG - 2018-02-13 14:21:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:21:34 --> Total execution time: 0.0790
DEBUG - 2018-02-13 14:25:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:25:34 --> Total execution time: 0.0780
DEBUG - 2018-02-13 14:25:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:25:40 --> Total execution time: 0.0650
DEBUG - 2018-02-13 14:25:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:25:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:25:43 --> Total execution time: 0.1260
DEBUG - 2018-02-13 14:25:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:25:56 --> Total execution time: 0.0790
DEBUG - 2018-02-13 14:26:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:26:01 --> Total execution time: 0.0680
DEBUG - 2018-02-13 14:26:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:26:22 --> Total execution time: 0.0880
DEBUG - 2018-02-13 14:27:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:27:02 --> Total execution time: 0.0980
DEBUG - 2018-02-13 14:29:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:29:22 --> Total execution time: 0.1330
DEBUG - 2018-02-13 14:29:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:29:24 --> Total execution time: 0.1200
DEBUG - 2018-02-13 14:29:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:29:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:29:39 --> Total execution time: 0.0690
DEBUG - 2018-02-13 14:29:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:29:42 --> Total execution time: 0.1300
DEBUG - 2018-02-13 14:29:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:29:44 --> Total execution time: 0.1270
DEBUG - 2018-02-13 14:29:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:29:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:29:53 --> Total execution time: 0.0740
DEBUG - 2018-02-13 14:29:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:29:59 --> Total execution time: 0.0780
DEBUG - 2018-02-13 14:30:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:30:03 --> Total execution time: 0.0820
DEBUG - 2018-02-13 14:30:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:30:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:30:08 --> Total execution time: 0.0650
DEBUG - 2018-02-13 14:30:11 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:30:11 --> Total execution time: 0.0780
DEBUG - 2018-02-13 14:30:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:30:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:30:14 --> Total execution time: 0.0730
DEBUG - 2018-02-13 14:30:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:30:18 --> Total execution time: 0.0660
DEBUG - 2018-02-13 14:30:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:30:20 --> Total execution time: 0.0770
DEBUG - 2018-02-13 14:30:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:30:26 --> Total execution time: 0.0960
DEBUG - 2018-02-13 14:30:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:30:31 --> Total execution time: 0.2780
DEBUG - 2018-02-13 14:30:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:30:33 --> Total execution time: 0.0680
DEBUG - 2018-02-13 14:30:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:30:35 --> Total execution time: 0.0970
DEBUG - 2018-02-13 14:30:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:30:37 --> Total execution time: 0.0710
DEBUG - 2018-02-13 14:30:41 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:30:41 --> Total execution time: 0.0720
DEBUG - 2018-02-13 14:30:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:30:44 --> Total execution time: 0.1060
DEBUG - 2018-02-13 14:30:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:30:45 --> Total execution time: 0.1150
DEBUG - 2018-02-13 14:30:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:30:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:30:51 --> Total execution time: 0.0760
DEBUG - 2018-02-13 14:30:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:30:58 --> Total execution time: 0.0700
DEBUG - 2018-02-13 14:31:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:31:06 --> Total execution time: 0.0690
DEBUG - 2018-02-13 14:31:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:31:08 --> Total execution time: 0.1070
DEBUG - 2018-02-13 14:31:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:31:10 --> Total execution time: 0.1040
DEBUG - 2018-02-13 14:31:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:31:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:31:19 --> Total execution time: 0.0720
DEBUG - 2018-02-13 14:31:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:31:21 --> Total execution time: 0.0710
DEBUG - 2018-02-13 14:31:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:31:23 --> Total execution time: 0.0860
DEBUG - 2018-02-13 14:31:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:31:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:31:30 --> Total execution time: 0.0730
DEBUG - 2018-02-13 14:31:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:31:40 --> Total execution time: 0.0750
DEBUG - 2018-02-13 14:31:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:31:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:31:46 --> Total execution time: 0.0680
DEBUG - 2018-02-13 14:31:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:31:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:31:52 --> Total execution time: 0.0650
DEBUG - 2018-02-13 14:31:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:31:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:31:58 --> Total execution time: 0.0640
DEBUG - 2018-02-13 14:32:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:32:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:32:07 --> Total execution time: 0.0520
DEBUG - 2018-02-13 14:32:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:32:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:32:10 --> Total execution time: 0.0790
DEBUG - 2018-02-13 14:32:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:32:13 --> Total execution time: 0.0640
DEBUG - 2018-02-13 14:32:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:32:15 --> Total execution time: 0.0860
DEBUG - 2018-02-13 14:32:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:32:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:32:25 --> Total execution time: 0.0690
DEBUG - 2018-02-13 14:32:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:32:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:32:28 --> Total execution time: 0.0530
DEBUG - 2018-02-13 14:32:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:32:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:32:30 --> Total execution time: 0.0670
DEBUG - 2018-02-13 14:32:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:32:37 --> Total execution time: 0.0610
DEBUG - 2018-02-13 14:32:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:32:45 --> Total execution time: 0.0750
DEBUG - 2018-02-13 14:33:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:33:34 --> Total execution time: 0.0900
DEBUG - 2018-02-13 14:34:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:34:27 --> Total execution time: 0.0700
DEBUG - 2018-02-13 14:36:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:36:04 --> Total execution time: 0.0700
DEBUG - 2018-02-13 14:36:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:36:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:36:08 --> Total execution time: 0.0520
DEBUG - 2018-02-13 14:36:11 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:36:11 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:36:11 --> Total execution time: 0.0700
DEBUG - 2018-02-13 14:36:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:36:14 --> Total execution time: 0.0700
DEBUG - 2018-02-13 14:36:16 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:36:16 --> Total execution time: 0.0600
DEBUG - 2018-02-13 14:36:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:36:59 --> Total execution time: 0.0900
DEBUG - 2018-02-13 14:37:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:37:18 --> Total execution time: 0.0800
DEBUG - 2018-02-13 14:37:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:37:24 --> Total execution time: 0.0740
DEBUG - 2018-02-13 14:37:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:37:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:37:43 --> Total execution time: 0.0600
DEBUG - 2018-02-13 14:37:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:37:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:37:55 --> Total execution time: 0.0700
DEBUG - 2018-02-13 14:37:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:37:59 --> Total execution time: 0.0700
DEBUG - 2018-02-13 14:38:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:38:03 --> Total execution time: 0.1400
DEBUG - 2018-02-13 14:38:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:38:09 --> Total execution time: 0.0700
DEBUG - 2018-02-13 14:38:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:38:18 --> Total execution time: 0.1000
DEBUG - 2018-02-13 14:38:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:38:21 --> Total execution time: 0.0600
DEBUG - 2018-02-13 14:38:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:38:28 --> Total execution time: 0.0700
DEBUG - 2018-02-13 14:38:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:38:32 --> Total execution time: 0.0640
DEBUG - 2018-02-13 14:39:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:39:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:39:29 --> Total execution time: 0.0600
DEBUG - 2018-02-13 14:41:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 14:41:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:41:39 --> Total execution time: 0.0600
DEBUG - 2018-02-13 14:41:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:41:52 --> Total execution time: 0.0700
DEBUG - 2018-02-13 14:45:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:45:36 --> Total execution time: 0.0700
DEBUG - 2018-02-13 14:46:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:46:30 --> Total execution time: 0.0800
DEBUG - 2018-02-13 14:46:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:46:33 --> Total execution time: 0.1800
DEBUG - 2018-02-13 14:46:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:46:39 --> Total execution time: 0.0600
DEBUG - 2018-02-13 14:46:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:46:40 --> Total execution time: 0.0600
DEBUG - 2018-02-13 14:47:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-13 20:47:09 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`klinik`.`pendaftaran`, CONSTRAINT `pasien_pendaftaran` FOREIGN KEY (`id_mst_pasien`) REFERENCES `mst_pasien` (`id_mst_pasien`) ON UPDATE CASCADE) - Invalid query: INSERT INTO `pendaftaran` (`id_trx_pendaftaran`, `id_mst_pasien`, `id_mst_pegawai`, `keterangan`) VALUES ('P00002', '', '6', 'Sakit')
DEBUG - 2018-02-13 20:47:09 --> DB Transaction Failure
DEBUG - 2018-02-13 14:47:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:47:18 --> Total execution time: 0.0700
DEBUG - 2018-02-13 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:47:25 --> Total execution time: 0.0700
DEBUG - 2018-02-13 14:49:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:49:37 --> Total execution time: 0.0600
DEBUG - 2018-02-13 14:49:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:49:40 --> Total execution time: 0.1800
DEBUG - 2018-02-13 14:52:57 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 14:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-13 14:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 20:52:57 --> Total execution time: 0.0800
