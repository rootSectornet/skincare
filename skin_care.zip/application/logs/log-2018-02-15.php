<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-02-15 16:04:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:04:02 --> No URI present. Default controller set.
DEBUG - 2018-02-15 16:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:04:02 --> Total execution time: 0.2124
DEBUG - 2018-02-15 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:04:08 --> No URI present. Default controller set.
DEBUG - 2018-02-15 16:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:04:08 --> Total execution time: 0.0789
DEBUG - 2018-02-15 16:04:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:04:12 --> No URI present. Default controller set.
DEBUG - 2018-02-15 16:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:04:12 --> Total execution time: 0.0351
DEBUG - 2018-02-15 16:04:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:04:17 --> Total execution time: 0.0955
DEBUG - 2018-02-15 16:04:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:04:49 --> Total execution time: 0.0635
DEBUG - 2018-02-15 16:05:05 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:05:05 --> Total execution time: 0.0548
DEBUG - 2018-02-15 16:05:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:05:08 --> Total execution time: 0.0603
DEBUG - 2018-02-15 16:05:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:05:10 --> Total execution time: 0.1203
DEBUG - 2018-02-15 16:06:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:06:50 --> Total execution time: 0.0568
DEBUG - 2018-02-15 16:07:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:07:24 --> Total execution time: 0.0602
DEBUG - 2018-02-15 16:07:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:07:29 --> Total execution time: 0.0610
DEBUG - 2018-02-15 16:07:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:07:48 --> Total execution time: 0.2033
DEBUG - 2018-02-15 16:07:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:07:55 --> Total execution time: 0.0547
DEBUG - 2018-02-15 16:07:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 16:07:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:07:58 --> Total execution time: 0.0714
DEBUG - 2018-02-15 16:08:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:08:15 --> Total execution time: 0.0583
DEBUG - 2018-02-15 16:08:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:08:49 --> Total execution time: 0.0638
DEBUG - 2018-02-15 16:08:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:08:50 --> Total execution time: 0.0953
DEBUG - 2018-02-15 16:17:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:17:45 --> Total execution time: 0.2471
DEBUG - 2018-02-15 16:17:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:17:47 --> Total execution time: 0.0742
DEBUG - 2018-02-15 16:18:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:18:27 --> Total execution time: 0.0533
DEBUG - 2018-02-15 16:24:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:24:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-15 16:24:42 --> Severity: error --> Exception: syntax error, unexpected '}' E:\xampp\htdocs\skin_care\application\controllers\pendaftaran\Pendaftaran.php 152
DEBUG - 2018-02-15 16:24:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:24:53 --> Total execution time: 0.0604
DEBUG - 2018-02-15 16:30:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:30:40 --> Total execution time: 0.0790
DEBUG - 2018-02-15 16:30:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:30:58 --> Total execution time: 0.0646
DEBUG - 2018-02-15 16:31:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:31:17 --> Total execution time: 0.0681
DEBUG - 2018-02-15 16:31:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:31:37 --> Total execution time: 0.0541
DEBUG - 2018-02-15 16:32:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:32:46 --> Total execution time: 0.0823
DEBUG - 2018-02-15 16:34:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:34:07 --> Total execution time: 0.0813
DEBUG - 2018-02-15 16:34:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:34:24 --> Total execution time: 0.0587
DEBUG - 2018-02-15 16:35:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:35:26 --> Total execution time: 0.0557
DEBUG - 2018-02-15 16:35:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:35:48 --> Total execution time: 0.0753
DEBUG - 2018-02-15 16:36:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:36:10 --> Total execution time: 0.0665
DEBUG - 2018-02-15 16:36:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:36:52 --> Total execution time: 0.0711
DEBUG - 2018-02-15 16:38:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:38:40 --> Total execution time: 0.0581
DEBUG - 2018-02-15 16:44:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:44:47 --> Total execution time: 0.0658
DEBUG - 2018-02-15 16:45:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:45:21 --> Total execution time: 0.0566
DEBUG - 2018-02-15 16:45:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:45:23 --> Total execution time: 0.0443
DEBUG - 2018-02-15 16:50:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:50:23 --> Total execution time: 0.0618
DEBUG - 2018-02-15 16:50:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-15 16:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-15 16:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-15 22:50:34 --> Total execution time: 0.0819
