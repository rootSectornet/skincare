<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-02-16 08:22:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 08:22:33 --> No URI present. Default controller set.
DEBUG - 2018-02-16 08:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 08:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 14:22:34 --> Total execution time: 0.4546
DEBUG - 2018-02-16 08:23:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 08:23:59 --> No URI present. Default controller set.
DEBUG - 2018-02-16 08:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 08:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 08:24:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 08:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 08:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 14:24:00 --> Total execution time: 0.4691
DEBUG - 2018-02-16 08:29:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 08:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 08:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 14:29:23 --> Total execution time: 0.2423
DEBUG - 2018-02-16 08:29:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 08:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 08:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 14:29:29 --> Total execution time: 0.2026
DEBUG - 2018-02-16 08:29:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 08:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 08:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 14:29:31 --> Total execution time: 0.2143
DEBUG - 2018-02-16 08:29:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 08:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 08:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 14:29:52 --> Total execution time: 0.0465
DEBUG - 2018-02-16 08:30:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 08:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 08:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 14:30:01 --> Total execution time: 0.2088
DEBUG - 2018-02-16 09:10:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:10:01 --> Total execution time: 0.5313
DEBUG - 2018-02-16 09:10:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:10:03 --> Total execution time: 0.1628
DEBUG - 2018-02-16 09:10:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:10:25 --> Total execution time: 0.4284
DEBUG - 2018-02-16 09:10:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 09:10:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:10:30 --> Total execution time: 0.2954
DEBUG - 2018-02-16 09:10:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:10:52 --> Total execution time: 0.8070
DEBUG - 2018-02-16 09:11:16 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:11:16 --> Total execution time: 0.1496
DEBUG - 2018-02-16 09:11:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:11:18 --> Total execution time: 0.0480
DEBUG - 2018-02-16 09:12:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:12:40 --> Total execution time: 0.1374
DEBUG - 2018-02-16 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:12:49 --> Total execution time: 0.1586
DEBUG - 2018-02-16 09:23:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:23:52 --> Total execution time: 0.1977
DEBUG - 2018-02-16 09:23:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:23:58 --> Total execution time: 0.1256
DEBUG - 2018-02-16 09:23:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:24:00 --> Total execution time: 0.1413
DEBUG - 2018-02-16 09:24:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:24:34 --> Total execution time: 0.2901
DEBUG - 2018-02-16 09:27:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:27:00 --> Total execution time: 0.0947
DEBUG - 2018-02-16 09:29:35 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:29:35 --> Total execution time: 0.1053
DEBUG - 2018-02-16 09:30:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:30:25 --> Total execution time: 0.0861
DEBUG - 2018-02-16 09:30:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:30:33 --> Total execution time: 0.1702
DEBUG - 2018-02-16 09:30:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:30:47 --> Total execution time: 0.0950
DEBUG - 2018-02-16 09:30:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 09:30:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:30:50 --> Total execution time: 0.0505
DEBUG - 2018-02-16 09:31:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:31:26 --> Total execution time: 0.2208
DEBUG - 2018-02-16 09:31:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:31:44 --> Total execution time: 0.0602
DEBUG - 2018-02-16 09:32:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:32:08 --> Total execution time: 0.0450
DEBUG - 2018-02-16 09:32:11 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 09:32:11 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:32:11 --> Total execution time: 0.1108
DEBUG - 2018-02-16 09:35:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:35:55 --> Total execution time: 0.0678
DEBUG - 2018-02-16 09:36:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:36:03 --> Total execution time: 0.0944
DEBUG - 2018-02-16 09:36:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:36:14 --> Total execution time: 0.0645
DEBUG - 2018-02-16 09:36:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:36:20 --> Total execution time: 0.0478
DEBUG - 2018-02-16 09:36:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 09:36:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:36:23 --> Total execution time: 0.1816
DEBUG - 2018-02-16 09:36:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:36:28 --> Total execution time: 0.1239
DEBUG - 2018-02-16 09:37:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:37:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-16 09:37:02 --> Severity: error --> Exception: syntax error, unexpected '}' E:\xampp\htdocs\skin_care\application\controllers\pendaftaran\Pendaftaran.php 162
DEBUG - 2018-02-16 09:37:11 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:37:11 --> Total execution time: 0.1094
DEBUG - 2018-02-16 09:37:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:37:17 --> Total execution time: 0.0921
DEBUG - 2018-02-16 09:37:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 09:37:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:37:20 --> Total execution time: 0.1116
DEBUG - 2018-02-16 09:37:24 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 09:48:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:48:34 --> Total execution time: 0.2006
DEBUG - 2018-02-16 09:48:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:48:46 --> Total execution time: 0.0483
DEBUG - 2018-02-16 09:48:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 09:48:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:48:49 --> Total execution time: 0.1165
DEBUG - 2018-02-16 09:48:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 09:48:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:48:52 --> Total execution time: 0.0640
DEBUG - 2018-02-16 09:49:41 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:49:41 --> Total execution time: 0.1065
DEBUG - 2018-02-16 09:49:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:49:44 --> Total execution time: 0.0487
DEBUG - 2018-02-16 09:49:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 09:49:47 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:49:47 --> Total execution time: 0.0674
DEBUG - 2018-02-16 09:50:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 09:50:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:50:04 --> Total execution time: 0.0499
DEBUG - 2018-02-16 09:50:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 09:50:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:50:18 --> Total execution time: 0.0440
DEBUG - 2018-02-16 09:50:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 09:50:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:50:23 --> Total execution time: 0.1057
DEBUG - 2018-02-16 09:50:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:50:27 --> Total execution time: 0.0576
DEBUG - 2018-02-16 09:50:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:50:31 --> Total execution time: 0.0933
DEBUG - 2018-02-16 09:50:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:50:33 --> Total execution time: 0.0542
DEBUG - 2018-02-16 09:50:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:50:39 --> Total execution time: 0.0383
DEBUG - 2018-02-16 09:50:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 09:50:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:50:42 --> Total execution time: 0.0513
DEBUG - 2018-02-16 09:51:57 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 09:51:57 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:51:57 --> Total execution time: 0.0504
DEBUG - 2018-02-16 09:52:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 09:52:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:52:02 --> Total execution time: 0.1161
DEBUG - 2018-02-16 09:52:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:52:06 --> Total execution time: 0.0458
DEBUG - 2018-02-16 09:52:11 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:52:12 --> Total execution time: 0.0434
DEBUG - 2018-02-16 09:52:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 09:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 09:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 15:52:14 --> Total execution time: 0.0467
DEBUG - 2018-02-16 17:20:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:20:45 --> No URI present. Default controller set.
DEBUG - 2018-02-16 17:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:20:46 --> Total execution time: 0.8972
DEBUG - 2018-02-16 17:21:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:21:03 --> No URI present. Default controller set.
DEBUG - 2018-02-16 17:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 17:21:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:21:04 --> Total execution time: 0.1964
DEBUG - 2018-02-16 17:21:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:21:14 --> Total execution time: 0.2520
DEBUG - 2018-02-16 17:21:25 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:21:25 --> Total execution time: 0.0806
DEBUG - 2018-02-16 17:21:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:21:40 --> Total execution time: 0.0692
DEBUG - 2018-02-16 17:21:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:21:42 --> Total execution time: 0.0846
DEBUG - 2018-02-16 17:24:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:24:19 --> Total execution time: 0.0560
DEBUG - 2018-02-16 17:24:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:24:46 --> Total execution time: 0.1646
DEBUG - 2018-02-16 17:24:49 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:24:49 --> Total execution time: 0.0789
DEBUG - 2018-02-16 17:24:53 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:24:53 --> Total execution time: 0.0566
DEBUG - 2018-02-16 17:25:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 17:25:04 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:25:04 --> Total execution time: 0.0605
DEBUG - 2018-02-16 17:32:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:32:06 --> Total execution time: 0.1173
DEBUG - 2018-02-16 17:32:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:32:15 --> Total execution time: 0.0568
DEBUG - 2018-02-16 17:32:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:32:19 --> Total execution time: 0.1283
DEBUG - 2018-02-16 17:32:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 17:32:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:32:32 --> Total execution time: 0.0722
DEBUG - 2018-02-16 17:32:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:32:36 --> Total execution time: 1.8065
DEBUG - 2018-02-16 17:33:02 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:33:02 --> Total execution time: 0.0647
DEBUG - 2018-02-16 17:33:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 17:33:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:33:10 --> Total execution time: 0.0606
DEBUG - 2018-02-16 17:42:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:42:09 --> Total execution time: 0.0604
DEBUG - 2018-02-16 17:42:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:42:17 --> Total execution time: 0.0517
DEBUG - 2018-02-16 17:42:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-16 23:42:19 --> Severity: Notice --> Undefined variable: pendaftaran E:\xampp\htdocs\skin_care\application\views\pasien\detail.php 21
ERROR - 2018-02-16 23:42:19 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\skin_care\application\views\pasien\detail.php 21
ERROR - 2018-02-16 23:42:19 --> Severity: Notice --> Undefined variable: pendaftaran E:\xampp\htdocs\skin_care\application\views\pasien\detail.php 50
ERROR - 2018-02-16 23:42:19 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\skin_care\application\views\pasien\detail.php 50
ERROR - 2018-02-16 23:42:19 --> Severity: Notice --> Undefined variable: pendaftaran E:\xampp\htdocs\skin_care\application\views\pasien\detail.php 77
ERROR - 2018-02-16 23:42:19 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\skin_care\application\views\pasien\detail.php 77
DEBUG - 2018-02-16 23:42:19 --> Total execution time: 0.1176
DEBUG - 2018-02-16 17:43:13 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:43:13 --> Total execution time: 0.0537
DEBUG - 2018-02-16 17:58:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 17:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 17:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 23:58:08 --> Total execution time: 0.0881
DEBUG - 2018-02-16 18:01:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-16 18:01:23 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ';' E:\xampp\htdocs\skin_care\application\helpers\tanggal_helper.php 20
DEBUG - 2018-02-16 18:01:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:01:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:02:11 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:02:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:03:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:05:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:05:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:07:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:09:54 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:10:27 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:11:06 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:11:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:11:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:12:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:12:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:12:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:13:11 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:13:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:13:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:13:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:13:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:13:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:13:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:13:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-16 18:13:52 --> 404 Page Not Found: pasien/Dist/img
ERROR - 2018-02-16 18:13:52 --> 404 Page Not Found: pasien/Dist/img
ERROR - 2018-02-16 18:13:52 --> 404 Page Not Found: pasien/Dist/img
DEBUG - 2018-02-16 18:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-16 18:13:52 --> 404 Page Not Found: pasien/Dist/img
ERROR - 2018-02-16 18:13:52 --> 404 Page Not Found: pasien/Dist/img
DEBUG - 2018-02-16 18:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-16 18:13:52 --> 404 Page Not Found: pasien/Dist/img
DEBUG - 2018-02-16 18:13:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-16 18:13:52 --> 404 Page Not Found: pasien/Dist/img
DEBUG - 2018-02-16 18:13:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:13:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:13:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:13:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:13:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:13:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-16 18:13:52 --> 404 Page Not Found: pasien/Dist/img
DEBUG - 2018-02-16 18:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-16 18:13:52 --> 404 Page Not Found: pasien/Dist/img
ERROR - 2018-02-16 18:13:52 --> 404 Page Not Found: pasien/Dist/img
ERROR - 2018-02-16 18:13:52 --> 404 Page Not Found: pasien/Dist/img
ERROR - 2018-02-16 18:13:52 --> 404 Page Not Found: pasien/Dist/img
DEBUG - 2018-02-16 18:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-16 18:13:52 --> 404 Page Not Found: pasien/Dist/img
DEBUG - 2018-02-16 18:13:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-16 18:13:52 --> 404 Page Not Found: pasien/Dist/img
DEBUG - 2018-02-16 18:15:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:16:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:28:30 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:29:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:29:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:29:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:31:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:32:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:35:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:37:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:40:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:41:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:41:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:42:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:45:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:45:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:46:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:46:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:46:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:47:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:47:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:48:09 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:51:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:52:08 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:52:11 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:52:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:52:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:52:18 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:52:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:52:34 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:52:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:52:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:52:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:52:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:54:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:58:32 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 18:59:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 18:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 18:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:00:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:01:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:02:56 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:05:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:08:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:09:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:10:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:14:23 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:17:36 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:18:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:18:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:18:16 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:18:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:21:31 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:44:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:44:48 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:45:51 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:45:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:45:57 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:46:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:46:39 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:46:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:46:43 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:46:45 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-16 19:48:33 --> UTF-8 Support Enabled
DEBUG - 2018-02-16 19:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-16 19:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
