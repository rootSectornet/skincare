<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-02-17 00:01:48 --> Total execution time: 0.0567
DEBUG - 2018-02-17 00:02:11 --> Total execution time: 0.0571
DEBUG - 2018-02-17 00:02:44 --> Total execution time: 0.3972
DEBUG - 2018-02-17 00:03:37 --> Total execution time: 0.0514
DEBUG - 2018-02-17 00:05:08 --> Total execution time: 0.0539
DEBUG - 2018-02-17 00:05:58 --> Total execution time: 0.0555
DEBUG - 2018-02-17 00:07:44 --> Total execution time: 0.0582
DEBUG - 2018-02-17 00:09:54 --> Total execution time: 0.0752
DEBUG - 2018-02-17 00:10:27 --> Total execution time: 0.0842
DEBUG - 2018-02-17 00:11:06 --> Total execution time: 0.0727
DEBUG - 2018-02-17 00:11:34 --> Total execution time: 0.0710
DEBUG - 2018-02-17 00:11:50 --> Total execution time: 0.0747
DEBUG - 2018-02-17 00:12:10 --> Total execution time: 0.0690
DEBUG - 2018-02-17 00:12:19 --> Total execution time: 0.0739
DEBUG - 2018-02-17 00:12:37 --> Total execution time: 0.0662
DEBUG - 2018-02-17 00:13:11 --> Total execution time: 0.0727
DEBUG - 2018-02-17 00:13:52 --> Total execution time: 0.0639
DEBUG - 2018-02-17 00:15:45 --> Total execution time: 0.0599
DEBUG - 2018-02-17 00:16:10 --> Total execution time: 0.0755
DEBUG - 2018-02-17 00:28:30 --> Total execution time: 0.0704
DEBUG - 2018-02-17 00:29:04 --> Total execution time: 0.2773
DEBUG - 2018-02-17 00:29:08 --> Total execution time: 0.1252
DEBUG - 2018-02-17 00:29:10 --> Total execution time: 0.0771
DEBUG - 2018-02-17 00:31:10 --> Total execution time: 0.0977
DEBUG - 2018-02-17 00:32:12 --> Total execution time: 0.0749
DEBUG - 2018-02-17 00:35:58 --> Total execution time: 0.1007
DEBUG - 2018-02-17 00:37:09 --> Total execution time: 0.0685
DEBUG - 2018-02-17 00:40:01 --> Total execution time: 0.0761
DEBUG - 2018-02-17 00:41:24 --> Total execution time: 0.1096
DEBUG - 2018-02-17 00:41:48 --> Total execution time: 0.2168
DEBUG - 2018-02-17 00:42:39 --> Total execution time: 0.1609
DEBUG - 2018-02-17 00:45:45 --> Total execution time: 0.0754
DEBUG - 2018-02-17 00:45:51 --> Total execution time: 0.0691
DEBUG - 2018-02-17 00:46:09 --> Total execution time: 0.0594
DEBUG - 2018-02-17 00:46:40 --> Total execution time: 0.0813
DEBUG - 2018-02-17 00:46:53 --> Total execution time: 0.0675
DEBUG - 2018-02-17 00:47:26 --> Total execution time: 0.0576
DEBUG - 2018-02-17 00:47:46 --> Total execution time: 0.0878
DEBUG - 2018-02-17 00:48:09 --> Total execution time: 0.1803
DEBUG - 2018-02-17 00:51:51 --> Total execution time: 0.0592
DEBUG - 2018-02-17 00:52:08 --> Total execution time: 0.0664
DEBUG - 2018-02-17 00:52:11 --> Total execution time: 0.0951
DEBUG - 2018-02-17 00:52:14 --> Total execution time: 0.0556
DEBUG - 2018-02-17 00:52:18 --> Total execution time: 0.0585
DEBUG - 2018-02-17 00:52:29 --> Total execution time: 0.0682
DEBUG - 2018-02-17 00:52:34 --> Total execution time: 0.1274
DEBUG - 2018-02-17 00:52:38 --> Total execution time: 0.0568
DEBUG - 2018-02-17 00:52:39 --> Total execution time: 0.0811
DEBUG - 2018-02-17 00:52:43 --> Total execution time: 0.1127
DEBUG - 2018-02-17 00:54:48 --> Total execution time: 0.0585
ERROR - 2018-02-17 00:58:32 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\skin_care\application\views\pasien\detail.php 65
ERROR - 2018-02-17 00:58:32 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\skin_care\application\views\pasien\detail.php 65
ERROR - 2018-02-17 00:58:32 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\skin_care\application\views\pasien\detail.php 65
ERROR - 2018-02-17 00:58:32 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\skin_care\application\views\pasien\detail.php 65
DEBUG - 2018-02-17 00:58:32 --> Total execution time: 0.1286
DEBUG - 2018-02-17 00:59:45 --> Total execution time: 0.0933
DEBUG - 2018-02-17 01:00:22 --> Total execution time: 0.0739
DEBUG - 2018-02-17 01:01:42 --> Total execution time: 0.0788
DEBUG - 2018-02-17 01:02:56 --> Total execution time: 0.0779
DEBUG - 2018-02-17 01:05:03 --> Total execution time: 0.1849
ERROR - 2018-02-17 01:08:12 --> Severity: Notice --> A non well formed numeric value encountered E:\xampp\htdocs\skin_care\application\views\pasien\detail.php 68
ERROR - 2018-02-17 01:08:12 --> Severity: Notice --> A non well formed numeric value encountered E:\xampp\htdocs\skin_care\application\views\pasien\detail.php 68
ERROR - 2018-02-17 01:08:12 --> Severity: Notice --> A non well formed numeric value encountered E:\xampp\htdocs\skin_care\application\views\pasien\detail.php 68
DEBUG - 2018-02-17 01:08:12 --> Total execution time: 0.1507
DEBUG - 2018-02-17 01:09:21 --> Total execution time: 0.1440
DEBUG - 2018-02-17 01:10:07 --> Total execution time: 0.1187
DEBUG - 2018-02-17 01:14:23 --> Total execution time: 0.1093
DEBUG - 2018-02-17 01:17:36 --> Total execution time: 0.0735
DEBUG - 2018-02-17 01:18:14 --> Total execution time: 0.0538
DEBUG - 2018-02-17 01:18:16 --> Total execution time: 0.0804
DEBUG - 2018-02-17 01:18:19 --> Total execution time: 0.0724
DEBUG - 2018-02-17 01:21:32 --> Total execution time: 0.0968
DEBUG - 2018-02-17 01:44:44 --> Total execution time: 0.0645
DEBUG - 2018-02-17 01:44:48 --> Total execution time: 0.0700
DEBUG - 2018-02-17 01:45:51 --> Total execution time: 0.0644
DEBUG - 2018-02-17 01:45:55 --> Total execution time: 0.4460
DEBUG - 2018-02-17 01:45:58 --> Total execution time: 0.0852
DEBUG - 2018-02-17 01:46:37 --> Total execution time: 0.0726
DEBUG - 2018-02-17 01:46:39 --> Total execution time: 0.0677
DEBUG - 2018-02-17 01:46:42 --> Total execution time: 0.0829
DEBUG - 2018-02-17 01:46:44 --> Total execution time: 0.0795
DEBUG - 2018-02-17 01:46:45 --> Total execution time: 0.0705
DEBUG - 2018-02-17 01:48:33 --> Total execution time: 0.0806
