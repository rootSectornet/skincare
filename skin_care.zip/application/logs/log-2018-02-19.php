<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-02-19 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 15:54:59 --> No URI present. Default controller set.
DEBUG - 2018-02-19 15:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 15:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 21:55:00 --> Total execution time: 0.6981
DEBUG - 2018-02-19 16:04:40 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:04:40 --> No URI present. Default controller set.
DEBUG - 2018-02-19 16:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 16:04:41 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:04:41 --> Total execution time: 0.1422
DEBUG - 2018-02-19 16:05:17 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:05:17 --> Total execution time: 0.4172
DEBUG - 2018-02-19 16:05:19 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:05:19 --> Total execution time: 0.1656
DEBUG - 2018-02-19 16:05:55 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:05:55 --> Total execution time: 0.0702
DEBUG - 2018-02-19 16:05:58 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:05:58 --> Total execution time: 0.1015
DEBUG - 2018-02-19 16:06:03 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:06:03 --> Total execution time: 0.1899
DEBUG - 2018-02-19 16:06:07 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:06:07 --> Total execution time: 0.0757
DEBUG - 2018-02-19 16:06:12 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:06:12 --> Total execution time: 0.0579
DEBUG - 2018-02-19 16:06:15 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:06:15 --> Total execution time: 0.0526
DEBUG - 2018-02-19 16:06:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:06:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-02-19 16:06:20 --> 404 Page Not Found: pendaftaran/Pendaftaran/update
DEBUG - 2018-02-19 16:06:22 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:06:22 --> Total execution time: 0.0791
DEBUG - 2018-02-19 16:06:26 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:06:26 --> Total execution time: 0.0446
DEBUG - 2018-02-19 16:08:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:08:46 --> Total execution time: 0.1024
DEBUG - 2018-02-19 16:08:52 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:08:52 --> Total execution time: 0.0708
DEBUG - 2018-02-19 16:08:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:08:59 --> Total execution time: 0.0753
DEBUG - 2018-02-19 16:09:00 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:09:00 --> Total execution time: 0.0696
DEBUG - 2018-02-19 16:13:20 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:13:20 --> Total execution time: 0.0474
DEBUG - 2018-02-19 16:15:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:15:01 --> Total execution time: 0.0882
DEBUG - 2018-02-19 16:15:28 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:15:28 --> Total execution time: 0.0418
DEBUG - 2018-02-19 16:18:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:18:37 --> Total execution time: 0.0714
DEBUG - 2018-02-19 16:18:41 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:18:41 --> Total execution time: 0.0793
DEBUG - 2018-02-19 16:18:44 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:18:44 --> Total execution time: 0.0657
DEBUG - 2018-02-19 16:18:59 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:18:59 --> Total execution time: 0.0382
DEBUG - 2018-02-19 16:19:01 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:19:01 --> Total execution time: 0.0631
DEBUG - 2018-02-19 16:19:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:19:14 --> Total execution time: 0.0684
DEBUG - 2018-02-19 16:19:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:19:29 --> Total execution time: 0.0566
DEBUG - 2018-02-19 16:20:42 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:20:42 --> Total execution time: 0.0696
DEBUG - 2018-02-19 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:20:46 --> Total execution time: 0.0672
DEBUG - 2018-02-19 16:20:50 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:20:50 --> Total execution time: 0.0779
DEBUG - 2018-02-19 16:20:57 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:20:57 --> Total execution time: 0.0877
DEBUG - 2018-02-19 16:21:29 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:21:29 --> Total execution time: 0.0403
DEBUG - 2018-02-19 16:21:38 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:21:38 --> Total execution time: 0.0727
DEBUG - 2018-02-19 16:23:05 --> UTF-8 Support Enabled
DEBUG - 2018-02-19 16:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-02-19 16:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-19 22:23:05 --> Total execution time: 0.0833
