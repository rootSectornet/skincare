<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-04 18:44:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:44:50 --> No URI present. Default controller set.
DEBUG - 2018-03-04 18:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:44:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:44:59 --> No URI present. Default controller set.
DEBUG - 2018-03-04 18:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:45:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:45:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:45:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:46:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:46:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:46:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:48:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:49:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:49:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:49:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:49:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:49:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:49:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:49:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:49:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-04 18:49:29 --> Severity: error --> Exception: Call to undefined method CI_Loader::mode() E:\xampp\htdocs\skin_care\application\controllers\gudang\Product.php 14
DEBUG - 2018-03-04 18:49:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:50:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:56:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:56:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:57:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:57:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:58:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:59:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:59:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:59:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-04 18:59:08 --> 404 Page Not Found: gudang/Product/edit
DEBUG - 2018-03-04 18:59:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:59:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 18:59:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 18:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 18:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:01:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:05:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:05:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:05:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:05:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:05:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:08:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:08:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:08:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:08:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:09:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:10:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:14:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-04 19:14:15 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' E:\xampp\htdocs\skin_care\application\helpers\tanggal_helper.php 30
DEBUG - 2018-03-04 19:14:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:14:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:14:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-04 19:14:31 --> 404 Page Not Found: gudang/Product/create
DEBUG - 2018-03-04 19:14:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:22:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:22:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:22:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:22:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:22:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:22:46 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:22:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:22:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:22:49 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:22:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:22:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:22:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:27:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:28:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:30:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:30:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:30:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:32:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:32:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:32:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-04 19:32:25 --> 404 Page Not Found: gudang/Product/verifKatalog
DEBUG - 2018-03-04 19:32:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:33:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:33:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-04 19:33:35 --> 404 Page Not Found: gudang/Product/verifKatalog
DEBUG - 2018-03-04 19:33:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:33:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:33:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-04 19:33:38 --> 404 Page Not Found: gudang/Product/verifKatalog
DEBUG - 2018-03-04 19:33:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:35:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:36:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:36:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:36:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:36:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:36:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:36:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:36:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:36:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:36:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:36:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:40:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:40:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:40:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:45:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:46:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:46:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:47:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:47:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:47:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:48:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:48:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:48:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:48:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:50:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:50:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:50:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:51:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:51:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:51:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:51:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:51:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:51:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:52:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:52:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:52:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:52:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:52:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:52:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:52:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:53:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:53:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:53:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:53:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:54:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:54:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:54:46 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:54:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:54:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:54:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-04 19:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-04 19:54:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-04 19:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-04 19:54:59 --> 404 Page Not Found: gudang/Suplier/index
