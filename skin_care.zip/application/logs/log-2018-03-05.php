<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-05 00:44:50 --> Total execution time: 0.2713
DEBUG - 2018-03-05 00:45:00 --> Total execution time: 0.3424
DEBUG - 2018-03-05 00:45:40 --> Total execution time: 0.1050
DEBUG - 2018-03-05 00:45:48 --> Total execution time: 0.0738
DEBUG - 2018-03-05 00:46:18 --> Total execution time: 0.0402
DEBUG - 2018-03-05 00:46:32 --> Total execution time: 0.0663
DEBUG - 2018-03-05 00:48:56 --> Total execution time: 0.0828
DEBUG - 2018-03-05 00:49:02 --> Total execution time: 0.0915
DEBUG - 2018-03-05 00:49:05 --> Total execution time: 0.1087
DEBUG - 2018-03-05 00:49:11 --> Total execution time: 0.0441
DEBUG - 2018-03-05 00:49:13 --> Total execution time: 0.1537
DEBUG - 2018-03-05 00:49:14 --> Total execution time: 0.0554
DEBUG - 2018-03-05 00:49:25 --> Total execution time: 0.0611
DEBUG - 2018-03-05 00:49:39 --> Total execution time: 0.0740
DEBUG - 2018-03-05 00:50:19 --> Total execution time: 0.0732
DEBUG - 2018-03-05 00:56:57 --> Total execution time: 0.0468
DEBUG - 2018-03-05 00:56:58 --> Total execution time: 0.0475
ERROR - 2018-03-05 00:57:16 --> Severity: error --> Exception: Call to undefined function BtnEdit() E:\xampp\htdocs\skin_care\application\views\product\master\table.php 37
DEBUG - 2018-03-05 00:57:47 --> Total execution time: 0.0625
DEBUG - 2018-03-05 00:58:40 --> Total execution time: 0.0534
DEBUG - 2018-03-05 00:59:05 --> Total execution time: 0.0529
DEBUG - 2018-03-05 00:59:10 --> Total execution time: 0.0641
DEBUG - 2018-03-05 00:59:31 --> Total execution time: 0.0860
DEBUG - 2018-03-05 00:59:54 --> Total execution time: 0.0632
DEBUG - 2018-03-05 01:01:12 --> Total execution time: 0.0438
DEBUG - 2018-03-05 01:05:01 --> Total execution time: 0.0290
DEBUG - 2018-03-05 01:05:06 --> Total execution time: 0.1687
DEBUG - 2018-03-05 01:05:07 --> Total execution time: 0.0660
DEBUG - 2018-03-05 01:08:22 --> Total execution time: 0.0318
DEBUG - 2018-03-05 01:08:26 --> Total execution time: 0.1873
DEBUG - 2018-03-05 01:09:59 --> Total execution time: 0.2179
DEBUG - 2018-03-05 01:10:00 --> Total execution time: 0.0879
DEBUG - 2018-03-05 01:14:27 --> Total execution time: 0.0868
DEBUG - 2018-03-05 01:14:32 --> Total execution time: 0.0468
ERROR - 2018-03-05 01:22:11 --> Severity: Notice --> Undefined variable: noRm E:\xampp\htdocs\skin_care\application\views\product\master\create.php 28
DEBUG - 2018-03-05 01:22:11 --> Total execution time: 0.2040
DEBUG - 2018-03-05 01:22:39 --> Total execution time: 0.0434
DEBUG - 2018-03-05 01:22:43 --> Total execution time: 0.0521
DEBUG - 2018-03-05 01:22:44 --> Total execution time: 0.0426
DEBUG - 2018-03-05 01:22:45 --> Total execution time: 0.0354
DEBUG - 2018-03-05 01:22:46 --> Total execution time: 0.0610
DEBUG - 2018-03-05 01:22:47 --> Total execution time: 0.0540
DEBUG - 2018-03-05 01:22:48 --> Total execution time: 0.0441
DEBUG - 2018-03-05 01:22:50 --> Total execution time: 0.0369
DEBUG - 2018-03-05 01:22:51 --> Total execution time: 0.0389
DEBUG - 2018-03-05 01:22:53 --> Total execution time: 0.0616
DEBUG - 2018-03-05 01:22:55 --> Total execution time: 0.0459
DEBUG - 2018-03-05 01:27:51 --> Total execution time: 0.0883
DEBUG - 2018-03-05 01:28:00 --> Total execution time: 0.0684
DEBUG - 2018-03-05 01:30:54 --> Total execution time: 0.0732
DEBUG - 2018-03-05 01:30:59 --> Total execution time: 0.0420
DEBUG - 2018-03-05 01:32:02 --> Total execution time: 0.0847
DEBUG - 2018-03-05 01:32:20 --> Total execution time: 0.0408
DEBUG - 2018-03-05 01:32:27 --> Total execution time: 0.0471
DEBUG - 2018-03-05 01:33:36 --> Total execution time: 0.0451
DEBUG - 2018-03-05 01:33:39 --> Total execution time: 0.0413
DEBUG - 2018-03-05 01:35:58 --> Total execution time: 0.0546
DEBUG - 2018-03-05 01:36:00 --> Total execution time: 0.0552
DEBUG - 2018-03-05 01:36:11 --> Total execution time: 0.0455
DEBUG - 2018-03-05 01:36:25 --> Total execution time: 0.0655
DEBUG - 2018-03-05 01:36:53 --> Total execution time: 0.0384
DEBUG - 2018-03-05 01:36:55 --> Total execution time: 0.0654
DEBUG - 2018-03-05 01:36:59 --> Total execution time: 0.0511
DEBUG - 2018-03-05 01:40:25 --> Total execution time: 0.0644
DEBUG - 2018-03-05 01:40:27 --> Total execution time: 0.0503
DEBUG - 2018-03-05 01:45:59 --> Total execution time: 0.0618
ERROR - 2018-03-05 01:46:01 --> Severity: Notice --> Undefined variable: qty E:\xampp\htdocs\skin_care\application\views\product\master\edit.php 29
DEBUG - 2018-03-05 01:46:01 --> Total execution time: 0.0696
DEBUG - 2018-03-05 01:46:09 --> Total execution time: 0.0618
DEBUG - 2018-03-05 01:47:02 --> Total execution time: 0.0691
DEBUG - 2018-03-05 01:47:15 --> Total execution time: 0.0485
DEBUG - 2018-03-05 01:48:26 --> Total execution time: 0.0454
DEBUG - 2018-03-05 01:48:28 --> Total execution time: 0.0367
DEBUG - 2018-03-05 01:48:35 --> Total execution time: 0.0629
DEBUG - 2018-03-05 01:50:42 --> Total execution time: 0.0514
DEBUG - 2018-03-05 01:50:45 --> Total execution time: 0.0497
DEBUG - 2018-03-05 01:51:26 --> Total execution time: 0.0467
DEBUG - 2018-03-05 01:51:31 --> Total execution time: 0.0508
DEBUG - 2018-03-05 01:51:33 --> Total execution time: 0.0483
DEBUG - 2018-03-05 01:51:37 --> Total execution time: 0.0460
DEBUG - 2018-03-05 01:52:12 --> Total execution time: 0.0402
DEBUG - 2018-03-05 01:52:16 --> Total execution time: 0.0400
DEBUG - 2018-03-05 01:52:37 --> Total execution time: 0.0499
DEBUG - 2018-03-05 01:52:50 --> Total execution time: 0.0509
DEBUG - 2018-03-05 01:52:55 --> Total execution time: 0.0730
DEBUG - 2018-03-05 01:52:56 --> Total execution time: 0.0534
DEBUG - 2018-03-05 01:53:06 --> Total execution time: 0.0588
DEBUG - 2018-03-05 01:53:10 --> Total execution time: 0.0534
DEBUG - 2018-03-05 01:53:22 --> Total execution time: 0.0697
DEBUG - 2018-03-05 01:54:43 --> Total execution time: 0.0452
DEBUG - 2018-03-05 01:54:46 --> Total execution time: 0.0438
DEBUG - 2018-03-05 01:54:52 --> Total execution time: 0.0513
DEBUG - 2018-03-05 01:54:58 --> Total execution time: 0.0615
DEBUG - 2018-03-05 19:23:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-05 19:23:26 --> No URI present. Default controller set.
DEBUG - 2018-03-05 19:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-05 19:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-05 19:23:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-05 19:23:31 --> No URI present. Default controller set.
DEBUG - 2018-03-05 19:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-05 19:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-05 19:23:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-05 19:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-05 19:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-05 19:23:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-05 19:23:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-05 19:23:40 --> 404 Page Not Found: gudang/Suplier/index
