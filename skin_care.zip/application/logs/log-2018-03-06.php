<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-06 01:23:26 --> Total execution time: 0.1085
DEBUG - 2018-03-06 01:23:32 --> Total execution time: 0.4156
DEBUG - 2018-03-06 04:08:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:08:37 --> No URI present. Default controller set.
DEBUG - 2018-03-06 04:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:08:37 --> Total execution time: 0.2931
DEBUG - 2018-03-06 04:12:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:12:43 --> No URI present. Default controller set.
DEBUG - 2018-03-06 04:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 04:12:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:12:44 --> Total execution time: 0.1461
DEBUG - 2018-03-06 04:12:46 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:12:46 --> Total execution time: 0.0687
DEBUG - 2018-03-06 04:16:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:16:16 --> Total execution time: 0.0653
DEBUG - 2018-03-06 04:17:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-06 10:17:36 --> Query error: Unknown column 'id_mst_pegawai' in 'field list' - Invalid query: INSERT INTO `mst_suplier` (`nama_suplier`, `alamat`, `telp`, `id_mst_pegawai`) VALUES ('PT. Farmasi Niaga Utama', 'Jl, Pamulang Raya no 35. Pamulang - Tangerang Selatan', '02198876534', '1')
DEBUG - 2018-03-06 10:17:36 --> DB Transaction Failure
DEBUG - 2018-03-06 04:17:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 04:17:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:17:56 --> Total execution time: 0.0677
DEBUG - 2018-03-06 04:18:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:18:18 --> Total execution time: 0.0534
DEBUG - 2018-03-06 04:21:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:21:30 --> Total execution time: 0.0793
DEBUG - 2018-03-06 04:21:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:21:31 --> Total execution time: 0.0341
DEBUG - 2018-03-06 04:21:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 04:21:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:21:40 --> Total execution time: 0.0745
DEBUG - 2018-03-06 04:22:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:22:01 --> Total execution time: 0.0721
DEBUG - 2018-03-06 04:22:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:22:07 --> Total execution time: 0.0903
DEBUG - 2018-03-06 04:22:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 04:22:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:22:20 --> Total execution time: 0.0445
DEBUG - 2018-03-06 04:22:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-06 10:22:28 --> Severity: error --> Exception: Call to undefined method Suplier_model::delete() E:\xampp\htdocs\skin_care\application\controllers\gudang\Suplier.php 60
DEBUG - 2018-03-06 04:23:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 04:23:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:23:07 --> Total execution time: 0.0493
DEBUG - 2018-03-06 04:26:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:26:51 --> Total execution time: 0.1560
DEBUG - 2018-03-06 04:26:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:26:53 --> Total execution time: 0.0784
DEBUG - 2018-03-06 04:29:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 04:29:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:29:23 --> Total execution time: 0.0571
DEBUG - 2018-03-06 04:29:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 04:29:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:29:28 --> Total execution time: 0.1763
DEBUG - 2018-03-06 04:29:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:29:34 --> Total execution time: 0.0879
DEBUG - 2018-03-06 04:29:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:29:37 --> Total execution time: 0.0415
DEBUG - 2018-03-06 04:29:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 04:29:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:29:54 --> Total execution time: 0.0549
DEBUG - 2018-03-06 04:30:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:30:16 --> Total execution time: 0.0778
DEBUG - 2018-03-06 04:30:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:30:19 --> Total execution time: 0.0714
DEBUG - 2018-03-06 04:30:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 04:30:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 04:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:30:34 --> Total execution time: 0.0591
DEBUG - 2018-03-06 04:30:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 04:30:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-06 04:30:42 --> 404 Page Not Found: gudang/Penerimaan/index
DEBUG - 2018-03-06 05:03:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:03:50 --> Total execution time: 0.1377
DEBUG - 2018-03-06 05:11:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:11:30 --> Total execution time: 0.0435
DEBUG - 2018-03-06 05:27:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-06 11:27:38 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\skin_care\application\controllers\gudang\Penerimaan.php 28
DEBUG - 2018-03-06 11:27:38 --> Total execution time: 0.1849
DEBUG - 2018-03-06 05:27:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:27:57 --> Total execution time: 0.0413
DEBUG - 2018-03-06 05:28:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:28:06 --> Total execution time: 0.0613
DEBUG - 2018-03-06 05:32:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:32:14 --> Total execution time: 0.0738
DEBUG - 2018-03-06 05:38:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:38:30 --> Total execution time: 0.0791
DEBUG - 2018-03-06 05:38:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:38:42 --> Total execution time: 0.0539
DEBUG - 2018-03-06 05:38:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:38:53 --> Total execution time: 0.0568
DEBUG - 2018-03-06 05:39:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:39:03 --> Total execution time: 0.0695
DEBUG - 2018-03-06 05:39:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:39:11 --> Total execution time: 0.0563
DEBUG - 2018-03-06 05:40:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:40:07 --> Total execution time: 0.0521
DEBUG - 2018-03-06 05:41:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:41:29 --> Total execution time: 0.0823
DEBUG - 2018-03-06 05:41:46 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:41:47 --> Total execution time: 0.0860
DEBUG - 2018-03-06 05:41:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:41:50 --> Total execution time: 0.0763
DEBUG - 2018-03-06 05:42:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:42:01 --> Total execution time: 0.0423
DEBUG - 2018-03-06 05:42:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:42:40 --> Total execution time: 0.0478
DEBUG - 2018-03-06 05:43:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:43:34 --> Total execution time: 0.0927
DEBUG - 2018-03-06 05:44:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:44:37 --> Total execution time: 0.0467
DEBUG - 2018-03-06 05:46:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:46:29 --> Total execution time: 0.0388
DEBUG - 2018-03-06 05:46:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:46:58 --> Total execution time: 0.1838
DEBUG - 2018-03-06 05:47:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:47:01 --> Total execution time: 0.1243
DEBUG - 2018-03-06 05:49:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:49:20 --> Total execution time: 0.0795
DEBUG - 2018-03-06 05:49:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 05:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 05:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 11:49:23 --> Total execution time: 0.0985
DEBUG - 2018-03-06 06:14:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 12:14:37 --> Total execution time: 0.0647
DEBUG - 2018-03-06 06:14:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 12:14:42 --> Total execution time: 0.0803
DEBUG - 2018-03-06 06:15:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 12:15:09 --> Total execution time: 0.0762
DEBUG - 2018-03-06 06:16:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 12:16:25 --> Total execution time: 0.0545
DEBUG - 2018-03-06 06:24:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 12:24:48 --> Total execution time: 0.0564
DEBUG - 2018-03-06 06:31:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 06:31:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 12:31:31 --> Total execution time: 0.0284
DEBUG - 2018-03-06 06:31:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 06:31:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 12:31:36 --> Total execution time: 0.1231
DEBUG - 2018-03-06 06:31:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 12:31:40 --> Total execution time: 0.0498
DEBUG - 2018-03-06 06:31:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 12:31:43 --> Total execution time: 0.0694
DEBUG - 2018-03-06 06:32:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 12:32:08 --> Total execution time: 0.0838
DEBUG - 2018-03-06 06:37:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 12:37:47 --> Total execution time: 0.0477
DEBUG - 2018-03-06 06:38:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-06 12:38:36 --> Severity: Notice --> Undefined variable: dir_name_action E:\xampp\htdocs\skin_care\application\views\penerimaan\create.php 68
ERROR - 2018-03-06 12:38:36 --> Severity: Notice --> Undefined variable: dir_name_action E:\xampp\htdocs\skin_care\application\views\penerimaan\create.php 75
DEBUG - 2018-03-06 12:38:36 --> Total execution time: 0.0953
DEBUG - 2018-03-06 06:38:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 12:38:53 --> Total execution time: 0.0558
DEBUG - 2018-03-06 06:40:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 12:40:30 --> Total execution time: 0.1009
DEBUG - 2018-03-06 06:42:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 06:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 06:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 12:42:27 --> Total execution time: 0.0743
DEBUG - 2018-03-06 10:55:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 10:55:58 --> No URI present. Default controller set.
DEBUG - 2018-03-06 10:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 10:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 16:55:58 --> Total execution time: 0.4165
DEBUG - 2018-03-06 10:56:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 10:56:03 --> No URI present. Default controller set.
DEBUG - 2018-03-06 10:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 10:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 10:56:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 10:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 10:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 16:56:04 --> Total execution time: 0.5834
DEBUG - 2018-03-06 10:56:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 10:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 10:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 16:56:10 --> Total execution time: 0.1210
DEBUG - 2018-03-06 10:56:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 10:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 10:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-06 16:56:13 --> Severity: Notice --> Undefined variable: dirNameAction E:\xampp\htdocs\skin_care\application\views\penerimaan\create.php 271
DEBUG - 2018-03-06 16:56:13 --> Total execution time: 0.0780
DEBUG - 2018-03-06 10:56:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 10:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 10:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 16:56:56 --> Total execution time: 0.0427
DEBUG - 2018-03-06 10:57:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 10:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 10:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 16:57:20 --> Total execution time: 0.0747
DEBUG - 2018-03-06 10:57:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 10:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 10:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 16:57:23 --> Total execution time: 0.0423
DEBUG - 2018-03-06 10:57:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 10:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 10:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 16:57:57 --> Total execution time: 0.0428
DEBUG - 2018-03-06 10:58:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 10:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 10:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-06 16:58:57 --> Severity: Notice --> Undefined variable: dir_name_action E:\xampp\htdocs\skin_care\application\views\penerimaan\create.php 213
ERROR - 2018-03-06 16:58:57 --> Severity: Notice --> Undefined variable: dir_name_action E:\xampp\htdocs\skin_care\application\views\penerimaan\create.php 251
ERROR - 2018-03-06 16:58:57 --> Severity: Notice --> Undefined variable: trx_detail_2 E:\xampp\htdocs\skin_care\application\views\penerimaan\create.php 252
ERROR - 2018-03-06 16:58:57 --> Severity: Notice --> Undefined variable: trx_detail_2 E:\xampp\htdocs\skin_care\application\views\penerimaan\create.php 253
ERROR - 2018-03-06 16:58:57 --> Severity: Notice --> Undefined variable: dir_name_action E:\xampp\htdocs\skin_care\application\views\penerimaan\create.php 254
ERROR - 2018-03-06 16:58:57 --> Severity: Notice --> Undefined variable: dir_name_action E:\xampp\htdocs\skin_care\application\views\penerimaan\create.php 260
ERROR - 2018-03-06 16:58:57 --> Severity: Notice --> Undefined variable: dir_name_action E:\xampp\htdocs\skin_care\application\views\penerimaan\create.php 265
ERROR - 2018-03-06 16:58:57 --> Severity: Notice --> Undefined variable: dirNameAction E:\xampp\htdocs\skin_care\application\views\penerimaan\create.php 272
DEBUG - 2018-03-06 16:58:57 --> Total execution time: 0.0540
DEBUG - 2018-03-06 11:00:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 11:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 11:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 17:00:25 --> Total execution time: 0.0346
DEBUG - 2018-03-06 11:05:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 11:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 11:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 17:05:10 --> Total execution time: 0.0361
DEBUG - 2018-03-06 13:20:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 13:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 13:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 13:20:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 13:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 13:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 19:20:42 --> Total execution time: 0.0499
DEBUG - 2018-03-06 13:20:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 13:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 13:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 13:20:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 13:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 13:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 19:20:47 --> Total execution time: 0.0487
DEBUG - 2018-03-06 13:20:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 13:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 13:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 19:20:51 --> Total execution time: 0.0599
DEBUG - 2018-03-06 13:20:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 13:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 13:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 19:20:53 --> Total execution time: 0.0453
DEBUG - 2018-03-06 13:21:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 13:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 13:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 19:21:04 --> Total execution time: 0.0670
DEBUG - 2018-03-06 13:21:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 13:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 13:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 19:21:04 --> Total execution time: 0.0650
DEBUG - 2018-03-06 13:21:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 13:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 13:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 19:21:45 --> Total execution time: 0.0510
DEBUG - 2018-03-06 13:21:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-06 13:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-06 13:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-06 19:21:48 --> Total execution time: 0.0751
