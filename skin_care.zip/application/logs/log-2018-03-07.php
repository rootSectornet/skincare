<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-07 15:43:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 15:43:42 --> No URI present. Default controller set.
DEBUG - 2018-03-07 15:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 15:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 21:43:43 --> Total execution time: 0.4215
DEBUG - 2018-03-07 15:43:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 15:43:52 --> No URI present. Default controller set.
DEBUG - 2018-03-07 15:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 15:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 15:43:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 15:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 15:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 21:43:54 --> Total execution time: 0.6087
DEBUG - 2018-03-07 15:44:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 15:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 15:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 21:44:03 --> Total execution time: 0.3420
DEBUG - 2018-03-07 15:44:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 15:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 15:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 21:44:05 --> Total execution time: 0.1201
DEBUG - 2018-03-07 15:45:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 15:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 15:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 21:45:18 --> Total execution time: 0.0716
DEBUG - 2018-03-07 15:46:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 15:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 15:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 21:46:38 --> Total execution time: 0.0718
DEBUG - 2018-03-07 16:01:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 16:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 16:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 22:01:15 --> Total execution time: 0.0605
DEBUG - 2018-03-07 16:01:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 16:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 16:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-07 22:01:19 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`pendaftaran`, CONSTRAINT `pasien_pendaftaran` FOREIGN KEY (`id_mst_pasien`) REFERENCES `mst_pasien` (`id_mst_pasien`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `mst_pasien`
WHERE `id_mst_pasien` = '1'
DEBUG - 2018-03-07 22:01:19 --> DB Transaction Failure
DEBUG - 2018-03-07 16:01:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 16:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 16:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 22:01:33 --> Total execution time: 0.0894
DEBUG - 2018-03-07 16:01:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 16:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 16:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-07 22:01:53 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`pendaftaran`, CONSTRAINT `pasien_pendaftaran` FOREIGN KEY (`id_mst_pasien`) REFERENCES `mst_pasien` (`id_mst_pasien`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `mst_pasien`
WHERE `id_mst_pasien` = '1'
DEBUG - 2018-03-07 22:01:53 --> DB Transaction Failure
DEBUG - 2018-03-07 16:02:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 16:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 16:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 22:02:07 --> Total execution time: 0.0814
DEBUG - 2018-03-07 16:09:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 16:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 16:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 22:09:30 --> Total execution time: 0.1269
DEBUG - 2018-03-07 17:02:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 17:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 17:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 23:02:16 --> Total execution time: 0.0663
DEBUG - 2018-03-07 17:02:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 17:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 17:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 23:02:17 --> Total execution time: 0.0382
DEBUG - 2018-03-07 17:12:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 17:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 17:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 23:12:38 --> Total execution time: 0.0825
DEBUG - 2018-03-07 17:12:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 17:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 17:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 23:12:48 --> Total execution time: 0.0680
DEBUG - 2018-03-07 17:13:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 17:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 17:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 23:13:33 --> Total execution time: 0.0887
DEBUG - 2018-03-07 17:13:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 17:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 17:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 23:13:35 --> Total execution time: 0.0429
DEBUG - 2018-03-07 17:13:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 17:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 17:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 23:13:36 --> Total execution time: 0.0552
DEBUG - 2018-03-07 17:13:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 17:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 17:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 23:13:39 --> Total execution time: 0.0748
DEBUG - 2018-03-07 17:13:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 17:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 17:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 23:13:40 --> Total execution time: 0.0425
DEBUG - 2018-03-07 17:13:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 17:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 17:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 23:13:41 --> Total execution time: 0.0748
DEBUG - 2018-03-07 17:14:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 17:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 17:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 23:14:23 --> Total execution time: 0.0694
DEBUG - 2018-03-07 17:16:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 17:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 17:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 23:16:16 --> Total execution time: 0.0411
DEBUG - 2018-03-07 17:18:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 17:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 17:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 23:18:57 --> Total execution time: 0.0806
DEBUG - 2018-03-07 17:21:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 17:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 17:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 23:21:05 --> Total execution time: 0.0475
DEBUG - 2018-03-07 17:21:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 17:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 17:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 23:21:21 --> Total execution time: 0.0389
DEBUG - 2018-03-07 17:21:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-07 17:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-07 17:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-07 23:21:45 --> Total execution time: 0.0495
