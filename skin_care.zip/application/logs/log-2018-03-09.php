<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-09 16:40:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:40:56 --> No URI present. Default controller set.
DEBUG - 2018-03-09 16:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-09 16:40:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\xampp\htdocs\skin_care\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-03-09 16:40:59 --> Unable to connect to the database
DEBUG - 2018-03-09 16:42:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:42:30 --> No URI present. Default controller set.
DEBUG - 2018-03-09 16:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:42:31 --> Total execution time: 0.2759
DEBUG - 2018-03-09 16:42:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:42:41 --> No URI present. Default controller set.
DEBUG - 2018-03-09 16:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 16:42:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:42:42 --> Total execution time: 0.3797
DEBUG - 2018-03-09 16:42:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:42:45 --> Total execution time: 0.1450
DEBUG - 2018-03-09 16:42:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:42:47 --> Total execution time: 0.0788
DEBUG - 2018-03-09 16:45:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:45:32 --> Total execution time: 0.0415
DEBUG - 2018-03-09 16:46:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:46:09 --> Total execution time: 0.0525
DEBUG - 2018-03-09 16:47:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:47:06 --> Total execution time: 0.0532
DEBUG - 2018-03-09 16:48:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:48:08 --> Total execution time: 0.0491
DEBUG - 2018-03-09 16:48:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:48:18 --> Total execution time: 0.1037
DEBUG - 2018-03-09 16:48:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:48:27 --> Total execution time: 0.0484
DEBUG - 2018-03-09 16:49:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:49:19 --> Total execution time: 0.0558
DEBUG - 2018-03-09 16:49:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:49:26 --> Total execution time: 0.0295
DEBUG - 2018-03-09 16:49:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:49:36 --> Total execution time: 0.0316
DEBUG - 2018-03-09 16:51:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:51:21 --> Total execution time: 0.0453
DEBUG - 2018-03-09 16:51:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:51:36 --> Total execution time: 0.0662
DEBUG - 2018-03-09 16:51:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:51:40 --> Total execution time: 0.0506
DEBUG - 2018-03-09 16:51:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:51:45 --> Total execution time: 0.0706
DEBUG - 2018-03-09 16:51:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:51:50 --> Total execution time: 0.0393
DEBUG - 2018-03-09 16:51:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:51:51 --> Total execution time: 0.0526
DEBUG - 2018-03-09 16:51:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:51:55 --> Total execution time: 0.0302
DEBUG - 2018-03-09 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:56:42 --> Total execution time: 0.0478
DEBUG - 2018-03-09 16:56:46 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:56:46 --> Total execution time: 0.0439
DEBUG - 2018-03-09 16:57:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:57:57 --> Total execution time: 0.0445
DEBUG - 2018-03-09 16:58:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:58:01 --> Total execution time: 0.0341
DEBUG - 2018-03-09 16:58:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:58:01 --> Total execution time: 0.0333
DEBUG - 2018-03-09 16:58:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:58:15 --> Total execution time: 0.0618
DEBUG - 2018-03-09 16:58:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 16:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 16:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:58:18 --> Total execution time: 0.0392
DEBUG - 2018-03-09 17:02:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:02:56 --> Total execution time: 0.0693
DEBUG - 2018-03-09 17:03:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:03:01 --> Total execution time: 0.0308
DEBUG - 2018-03-09 17:03:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:03:53 --> Total execution time: 0.0689
DEBUG - 2018-03-09 17:03:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:03:57 --> Total execution time: 0.0404
DEBUG - 2018-03-09 17:05:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:05:04 --> Total execution time: 0.0484
DEBUG - 2018-03-09 17:05:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:05:08 --> Total execution time: 0.0349
DEBUG - 2018-03-09 17:09:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:09:24 --> Total execution time: 0.0596
DEBUG - 2018-03-09 17:12:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:12:53 --> Total execution time: 0.0545
DEBUG - 2018-03-09 17:13:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:13:04 --> Total execution time: 0.0332
DEBUG - 2018-03-09 17:13:49 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:13:49 --> Total execution time: 0.0618
DEBUG - 2018-03-09 17:14:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:14:31 --> Total execution time: 0.0706
DEBUG - 2018-03-09 17:14:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:14:36 --> Total execution time: 0.0402
DEBUG - 2018-03-09 17:15:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:15:28 --> Total execution time: 0.0511
DEBUG - 2018-03-09 17:16:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:16:01 --> Total execution time: 0.0498
DEBUG - 2018-03-09 17:16:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:16:10 --> Total execution time: 0.0499
DEBUG - 2018-03-09 17:16:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:16:54 --> Total execution time: 0.0512
DEBUG - 2018-03-09 17:16:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:16:59 --> Total execution time: 0.0451
DEBUG - 2018-03-09 17:17:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:17:42 --> Total execution time: 0.0470
DEBUG - 2018-03-09 17:18:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:18:11 --> Total execution time: 0.0566
DEBUG - 2018-03-09 17:19:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:19:36 --> Total execution time: 0.0578
DEBUG - 2018-03-09 17:20:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:20:27 --> Total execution time: 0.0953
DEBUG - 2018-03-09 17:20:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:20:40 --> Total execution time: 0.0589
DEBUG - 2018-03-09 17:21:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:21:01 --> Total execution time: 0.0569
DEBUG - 2018-03-09 17:21:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:21:47 --> Total execution time: 0.0458
DEBUG - 2018-03-09 17:21:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:21:58 --> Total execution time: 0.0635
DEBUG - 2018-03-09 17:22:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:22:10 --> Total execution time: 0.0558
DEBUG - 2018-03-09 17:29:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:29:17 --> Total execution time: 0.0550
DEBUG - 2018-03-09 17:29:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:29:53 --> Total execution time: 0.0436
DEBUG - 2018-03-09 17:30:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:30:32 --> Total execution time: 0.0436
DEBUG - 2018-03-09 17:30:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:30:40 --> Total execution time: 0.0614
DEBUG - 2018-03-09 17:31:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:31:40 --> Total execution time: 0.0389
DEBUG - 2018-03-09 17:32:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:32:06 --> Total execution time: 0.0540
DEBUG - 2018-03-09 17:34:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:34:04 --> Total execution time: 0.0375
DEBUG - 2018-03-09 17:34:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:34:21 --> Total execution time: 0.0401
DEBUG - 2018-03-09 17:35:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:35:00 --> Total execution time: 0.0448
DEBUG - 2018-03-09 17:35:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:35:58 --> Total execution time: 0.0374
DEBUG - 2018-03-09 17:36:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:36:13 --> Total execution time: 0.0420
DEBUG - 2018-03-09 17:39:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:39:08 --> Total execution time: 0.0439
DEBUG - 2018-03-09 17:39:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:39:48 --> Total execution time: 0.0485
DEBUG - 2018-03-09 17:42:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:42:10 --> Total execution time: 0.0410
DEBUG - 2018-03-09 17:43:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:43:03 --> Total execution time: 0.0442
DEBUG - 2018-03-09 17:43:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:43:40 --> Total execution time: 0.0388
DEBUG - 2018-03-09 17:44:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:44:19 --> Total execution time: 0.0444
DEBUG - 2018-03-09 17:45:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:45:21 --> Total execution time: 0.0437
DEBUG - 2018-03-09 17:45:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:45:45 --> Total execution time: 0.0682
DEBUG - 2018-03-09 17:48:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:48:00 --> Total execution time: 0.0489
DEBUG - 2018-03-09 17:48:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:48:16 --> Total execution time: 0.0428
DEBUG - 2018-03-09 17:49:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:49:43 --> Total execution time: 0.0451
DEBUG - 2018-03-09 17:50:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:50:35 --> Total execution time: 0.0517
DEBUG - 2018-03-09 17:51:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:51:20 --> Total execution time: 0.0494
DEBUG - 2018-03-09 17:52:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:52:03 --> Total execution time: 0.0549
DEBUG - 2018-03-09 17:52:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:52:22 --> Total execution time: 0.0371
DEBUG - 2018-03-09 17:52:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:52:57 --> Total execution time: 0.0511
DEBUG - 2018-03-09 17:53:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:53:11 --> Total execution time: 0.0458
DEBUG - 2018-03-09 17:53:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:53:13 --> Total execution time: 0.0466
DEBUG - 2018-03-09 17:54:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 17:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 17:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 23:54:04 --> Total execution time: 0.0419
DEBUG - 2018-03-09 18:02:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:09:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:09:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:10:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:10:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:11:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:12:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:13:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:15:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:16:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:16:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:17:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:18:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:21:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:21:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:33:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:35:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:38:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:38:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:38:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:39:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:44:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:45:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:45:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:45:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:45:48 --> UTF-8 Support Enabled
ERROR - 2018-03-09 18:45:48 --> 404 Page Not Found: Assets/plugins
DEBUG - 2018-03-09 18:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:45:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-09 18:45:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-03-09 18:45:48 --> 404 Page Not Found: Assets/plugins
DEBUG - 2018-03-09 18:48:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:48:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:48:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:48:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-09 18:48:23 --> 404 Page Not Found: Assets/plugins
DEBUG - 2018-03-09 18:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-09 18:48:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-03-09 18:48:23 --> 404 Page Not Found: Assets/plugins
DEBUG - 2018-03-09 18:49:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:50:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:50:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:51:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:51:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:51:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:52:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:53:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:53:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:53:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:53:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:53:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:54:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:56:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:56:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:56:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:56:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:56:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:59:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:59:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:59:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:59:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:59:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:59:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:59:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 18:59:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 18:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 18:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:06:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:06:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:10:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:10:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:10:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:10:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:10:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:12:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:12:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:12:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:12:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:12:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:12:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:12:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:15:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:15:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:15:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:16:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:16:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:16:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:18:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:20:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:20:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:25:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:25:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:25:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:25:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:25:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:26:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:26:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:29:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:29:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:30:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:31:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:33:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:33:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:35:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:36:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:36:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:36:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:37:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:37:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:37:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:37:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:38:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:38:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:38:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:38:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:38:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:39:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:44:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:44:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:45:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:45:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:45:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:45:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:47:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:48:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:50:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 19:59:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 19:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 19:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:00:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:01:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:02:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:03:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:03:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:03:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:03:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:03:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:03:46 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:03:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:04:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:07:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:07:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:07:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:07:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:07:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:12:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:12:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:13:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:13:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:14:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:15:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:15:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:15:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:16:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:16:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:17:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:21:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:21:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:26:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:26:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:27:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:29:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:30:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:30:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:31:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:31:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:31:46 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:31:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:33:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:33:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:33:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:35:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:36:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:37:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:38:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:39:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:40:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:41:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:41:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:41:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:41:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:41:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:42:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:42:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:44:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:45:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:45:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:45:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:45:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:47:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:47:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:47:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:47:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:49:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:49:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 20:49:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 20:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 20:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:07:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:07:49 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:07:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:10:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:10:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:10:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-09 21:10:44 --> 404 Page Not Found: Penerimaan/edit
DEBUG - 2018-03-09 21:10:46 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:10:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:10:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-09 21:10:48 --> 404 Page Not Found: Penerimaan/edit
DEBUG - 2018-03-09 21:10:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:10:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:11:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:11:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:11:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:14:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:14:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:14:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:14:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:14:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:14:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:14:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:15:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:18:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:19:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:20:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:20:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:21:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:23:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:23:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:23:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:23:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:23:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:23:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:23:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:23:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:23:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:27:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:27:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:27:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:27:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:28:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:28:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:30:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:30:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:30:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:30:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:39:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:40:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:40:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:40:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:40:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:40:46 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:40:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:42:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:42:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:43:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:43:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:43:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:43:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:43:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:43:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:45:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:45:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:45:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:47:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:47:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:47:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:50:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:51:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:51:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:51:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:51:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:52:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:52:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:52:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:52:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:52:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:52:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:52:49 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:52:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:52:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:52:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:55:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:55:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:55:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:55:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:55:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:55:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:55:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:55:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:55:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:56:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:56:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:56:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:57:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:57:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:57:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:57:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:57:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:57:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:58:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:58:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 21:58:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 21:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 21:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:01:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 22:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 22:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 22:01:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-09 22:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-09 22:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
