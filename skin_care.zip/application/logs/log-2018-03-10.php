<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-10 00:02:24 --> Total execution time: 0.0475
DEBUG - 2018-03-10 00:09:24 --> Total execution time: 0.0397
DEBUG - 2018-03-10 00:09:52 --> Total execution time: 0.0905
DEBUG - 2018-03-10 00:10:13 --> Total execution time: 0.0441
DEBUG - 2018-03-10 00:10:40 --> Total execution time: 0.0660
DEBUG - 2018-03-10 00:11:22 --> Total execution time: 0.0641
DEBUG - 2018-03-10 00:12:31 --> Total execution time: 0.0482
DEBUG - 2018-03-10 00:13:04 --> Total execution time: 0.0495
DEBUG - 2018-03-10 00:15:24 --> Total execution time: 0.0436
DEBUG - 2018-03-10 00:16:04 --> Total execution time: 0.0395
DEBUG - 2018-03-10 00:16:38 --> Total execution time: 0.0419
DEBUG - 2018-03-10 00:17:29 --> Total execution time: 0.0432
DEBUG - 2018-03-10 00:18:17 --> Total execution time: 0.0468
DEBUG - 2018-03-10 00:21:01 --> Total execution time: 0.0462
DEBUG - 2018-03-10 00:21:28 --> Total execution time: 0.0446
DEBUG - 2018-03-10 00:33:10 --> Total execution time: 0.0436
DEBUG - 2018-03-10 00:35:15 --> Total execution time: 0.0483
DEBUG - 2018-03-10 00:38:14 --> Total execution time: 0.0499
DEBUG - 2018-03-10 00:38:36 --> Total execution time: 0.0768
DEBUG - 2018-03-10 00:38:56 --> Total execution time: 0.0370
DEBUG - 2018-03-10 00:39:01 --> Total execution time: 0.0364
DEBUG - 2018-03-10 00:44:00 --> Total execution time: 0.0499
DEBUG - 2018-03-10 00:45:47 --> Total execution time: 0.0543
DEBUG - 2018-03-10 00:48:23 --> Total execution time: 0.0499
DEBUG - 2018-03-10 00:49:07 --> Total execution time: 0.0452
DEBUG - 2018-03-10 00:50:21 --> Total execution time: 0.0348
DEBUG - 2018-03-10 00:50:23 --> Total execution time: 0.0396
DEBUG - 2018-03-10 00:51:00 --> Total execution time: 0.0452
DEBUG - 2018-03-10 00:51:16 --> Total execution time: 0.0410
DEBUG - 2018-03-10 00:51:31 --> Total execution time: 0.0439
DEBUG - 2018-03-10 00:52:54 --> Total execution time: 0.0556
DEBUG - 2018-03-10 00:53:04 --> Total execution time: 0.0391
DEBUG - 2018-03-10 00:53:12 --> Total execution time: 0.0324
DEBUG - 2018-03-10 00:53:24 --> Total execution time: 0.0463
DEBUG - 2018-03-10 00:53:33 --> Total execution time: 0.0504
DEBUG - 2018-03-10 00:53:44 --> Total execution time: 0.0447
DEBUG - 2018-03-10 00:54:58 --> Total execution time: 0.0539
DEBUG - 2018-03-10 00:56:14 --> Total execution time: 0.0543
DEBUG - 2018-03-10 00:56:33 --> Total execution time: 0.0430
DEBUG - 2018-03-10 00:56:38 --> Total execution time: 0.0414
DEBUG - 2018-03-10 00:56:39 --> Total execution time: 0.0497
DEBUG - 2018-03-10 00:56:54 --> Total execution time: 0.0519
DEBUG - 2018-03-10 00:59:05 --> Total execution time: 0.0323
DEBUG - 2018-03-10 00:59:10 --> Total execution time: 0.0317
DEBUG - 2018-03-10 00:59:12 --> Total execution time: 0.0399
DEBUG - 2018-03-10 00:59:25 --> Total execution time: 0.0456
DEBUG - 2018-03-10 00:59:32 --> Total execution time: 0.0475
DEBUG - 2018-03-10 00:59:43 --> Total execution time: 0.0347
DEBUG - 2018-03-10 00:59:50 --> Total execution time: 0.0388
DEBUG - 2018-03-10 00:59:51 --> Total execution time: 0.0395
DEBUG - 2018-03-10 01:00:03 --> Total execution time: 0.0587
DEBUG - 2018-03-10 01:06:51 --> Total execution time: 0.0540
DEBUG - 2018-03-10 01:06:59 --> Total execution time: 0.0331
DEBUG - 2018-03-10 01:10:12 --> Total execution time: 0.0454
DEBUG - 2018-03-10 01:10:16 --> Total execution time: 0.0409
DEBUG - 2018-03-10 01:10:21 --> Total execution time: 0.0424
DEBUG - 2018-03-10 01:10:35 --> Total execution time: 0.0332
ERROR - 2018-03-10 01:10:54 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`klinik`.`detail_penerimaan`, CONSTRAINT `faktur_penrimaan` FOREIGN KEY (`faktur_penerimaan`) REFERENCES `penerimaan` (`faktur_penerimaan`) ON UPDATE CASCADE) - Invalid query: INSERT INTO `detail_penerimaan` (`id_product`, `tgl_exp`, `qty`, `harga`, `harga_jual`, `sub_total`, `faktur_penerimaan`) VALUES ('2', '2018-03-30', '2', '25000', '30000', '50,000', '00012')
DEBUG - 2018-03-10 01:10:54 --> DB Transaction Failure
DEBUG - 2018-03-10 01:12:04 --> Total execution time: 0.0510
DEBUG - 2018-03-10 01:12:06 --> Total execution time: 0.0409
DEBUG - 2018-03-10 01:12:10 --> Total execution time: 0.0409
DEBUG - 2018-03-10 01:12:15 --> Total execution time: 0.0480
DEBUG - 2018-03-10 01:12:23 --> Total execution time: 0.0391
ERROR - 2018-03-10 01:12:41 --> Severity: Notice --> Undefined index: ppn E:\xampp\htdocs\skin_care\application\controllers\gudang\Penerimaan.php 35
ERROR - 2018-03-10 01:12:42 --> Severity: Notice --> Undefined property: stdClass::$nama_suplier E:\xampp\htdocs\skin_care\application\views\penerimaan\table.php 33
DEBUG - 2018-03-10 01:12:42 --> Total execution time: 0.0608
DEBUG - 2018-03-10 01:15:11 --> Total execution time: 0.0477
DEBUG - 2018-03-10 01:15:41 --> Total execution time: 0.0463
DEBUG - 2018-03-10 01:15:51 --> Total execution time: 0.0506
DEBUG - 2018-03-10 01:16:33 --> Total execution time: 0.0444
ERROR - 2018-03-10 01:16:53 --> Severity: Notice --> Undefined index: ppn E:\xampp\htdocs\skin_care\application\controllers\gudang\Penerimaan.php 35
ERROR - 2018-03-10 01:16:53 --> Severity: Notice --> Undefined property: stdClass::$nama_suplier E:\xampp\htdocs\skin_care\application\views\penerimaan\table.php 33
ERROR - 2018-03-10 01:16:53 --> Severity: Notice --> Undefined property: stdClass::$nama_suplier E:\xampp\htdocs\skin_care\application\views\penerimaan\table.php 33
DEBUG - 2018-03-10 01:16:53 --> Total execution time: 0.0688
DEBUG - 2018-03-10 01:18:40 --> Total execution time: 0.0446
DEBUG - 2018-03-10 01:20:27 --> Total execution time: 0.0525
DEBUG - 2018-03-10 01:20:33 --> Total execution time: 0.0466
DEBUG - 2018-03-10 01:25:11 --> Total execution time: 0.0475
DEBUG - 2018-03-10 01:25:14 --> Total execution time: 0.0373
DEBUG - 2018-03-10 01:25:25 --> Total execution time: 0.0443
DEBUG - 2018-03-10 01:25:30 --> Total execution time: 0.0493
DEBUG - 2018-03-10 01:26:00 --> Total execution time: 0.0487
DEBUG - 2018-03-10 01:26:00 --> Total execution time: 0.0497
DEBUG - 2018-03-10 01:26:02 --> Total execution time: 0.0397
DEBUG - 2018-03-10 01:29:10 --> Total execution time: 0.0412
DEBUG - 2018-03-10 01:29:54 --> Total execution time: 0.0473
DEBUG - 2018-03-10 01:30:08 --> Total execution time: 0.0408
DEBUG - 2018-03-10 01:31:21 --> Total execution time: 0.0540
DEBUG - 2018-03-10 01:33:06 --> Total execution time: 0.0458
DEBUG - 2018-03-10 01:33:14 --> Total execution time: 0.0526
DEBUG - 2018-03-10 01:35:22 --> Total execution time: 0.0479
DEBUG - 2018-03-10 01:36:05 --> Total execution time: 0.0447
DEBUG - 2018-03-10 01:36:19 --> Total execution time: 0.0611
ERROR - 2018-03-10 01:36:58 --> Severity: Notice --> Undefined variable: total E:\xampp\htdocs\skin_care\application\views\penerimaan\detail.php 58
ERROR - 2018-03-10 01:36:58 --> Severity: error --> Exception: Cannot access empty property E:\xampp\htdocs\skin_care\application\views\penerimaan\detail.php 58
DEBUG - 2018-03-10 01:37:14 --> Total execution time: 0.0816
DEBUG - 2018-03-10 01:37:27 --> Total execution time: 0.0471
DEBUG - 2018-03-10 01:37:28 --> Total execution time: 0.0568
DEBUG - 2018-03-10 01:37:44 --> Total execution time: 0.0441
DEBUG - 2018-03-10 01:38:16 --> Total execution time: 0.0584
DEBUG - 2018-03-10 01:38:33 --> Total execution time: 0.0546
DEBUG - 2018-03-10 01:38:33 --> Total execution time: 0.0556
DEBUG - 2018-03-10 01:38:42 --> Total execution time: 0.0405
DEBUG - 2018-03-10 01:38:52 --> Total execution time: 0.0469
DEBUG - 2018-03-10 01:39:19 --> Total execution time: 0.0468
DEBUG - 2018-03-10 01:44:39 --> Total execution time: 0.1289
DEBUG - 2018-03-10 01:44:41 --> Total execution time: 0.1178
DEBUG - 2018-03-10 01:45:19 --> Total execution time: 0.0437
DEBUG - 2018-03-10 01:45:31 --> Total execution time: 0.0417
DEBUG - 2018-03-10 01:45:32 --> Total execution time: 0.0542
DEBUG - 2018-03-10 01:45:39 --> Total execution time: 0.0441
DEBUG - 2018-03-10 01:47:03 --> Total execution time: 0.0496
DEBUG - 2018-03-10 01:48:29 --> Total execution time: 0.0475
DEBUG - 2018-03-10 01:50:18 --> Total execution time: 0.0433
DEBUG - 2018-03-10 01:59:51 --> Total execution time: 0.0467
DEBUG - 2018-03-10 02:00:16 --> Total execution time: 0.0452
DEBUG - 2018-03-10 02:01:52 --> Total execution time: 0.0446
ERROR - 2018-03-10 02:02:45 --> Severity: Notice --> A non well formed numeric value encountered E:\xampp\htdocs\skin_care\application\views\penerimaan\detail.php 91
ERROR - 2018-03-10 02:02:45 --> Severity: Notice --> A non well formed numeric value encountered E:\xampp\htdocs\skin_care\application\views\penerimaan\detail.php 91
DEBUG - 2018-03-10 02:02:45 --> Total execution time: 0.0586
DEBUG - 2018-03-10 02:03:06 --> Total execution time: 0.0534
DEBUG - 2018-03-10 02:03:11 --> Total execution time: 0.0455
DEBUG - 2018-03-10 02:03:13 --> Total execution time: 0.0411
DEBUG - 2018-03-10 02:03:40 --> Total execution time: 0.0403
DEBUG - 2018-03-10 02:03:43 --> Total execution time: 0.0490
DEBUG - 2018-03-10 02:03:46 --> Total execution time: 0.0568
DEBUG - 2018-03-10 02:03:47 --> Total execution time: 0.0424
DEBUG - 2018-03-10 02:04:31 --> Total execution time: 0.0427
DEBUG - 2018-03-10 02:07:29 --> Total execution time: 0.0352
DEBUG - 2018-03-10 02:07:33 --> Total execution time: 0.0773
DEBUG - 2018-03-10 02:07:36 --> Total execution time: 0.0936
ERROR - 2018-03-10 02:12:30 --> Severity: Notice --> Undefined index: nama_suplier E:\xampp\htdocs\skin_care\application\views\penerimaan\edit.php 113
DEBUG - 2018-03-10 02:12:30 --> Total execution time: 0.1195
ERROR - 2018-03-10 02:12:45 --> Severity: Notice --> Undefined index: nama_suplier E:\xampp\htdocs\skin_care\application\views\penerimaan\edit.php 113
DEBUG - 2018-03-10 02:12:45 --> Total execution time: 0.0578
ERROR - 2018-03-10 02:13:07 --> Severity: Notice --> Undefined index: nama_suplier E:\xampp\htdocs\skin_care\application\views\penerimaan\edit.php 113
DEBUG - 2018-03-10 02:13:07 --> Total execution time: 0.0580
ERROR - 2018-03-10 02:13:18 --> Severity: Notice --> Use of undefined constant head - assumed 'head' E:\xampp\htdocs\skin_care\application\views\penerimaan\edit.php 113
ERROR - 2018-03-10 02:13:18 --> Severity: Notice --> Use of undefined constant nama_suplier - assumed 'nama_suplier' E:\xampp\htdocs\skin_care\application\views\penerimaan\edit.php 113
ERROR - 2018-03-10 02:13:18 --> Severity: Notice --> Undefined index: nama_suplier E:\xampp\htdocs\skin_care\application\views\penerimaan\edit.php 113
DEBUG - 2018-03-10 02:13:18 --> Total execution time: 0.0559
ERROR - 2018-03-10 02:14:07 --> Severity: Notice --> Use of undefined constant head - assumed 'head' E:\xampp\htdocs\skin_care\application\views\penerimaan\edit.php 113
ERROR - 2018-03-10 02:14:07 --> Severity: Notice --> Use of undefined constant nama_suplier - assumed 'nama_suplier' E:\xampp\htdocs\skin_care\application\views\penerimaan\edit.php 113
ERROR - 2018-03-10 02:14:07 --> Severity: Notice --> Undefined index: nama_suplier E:\xampp\htdocs\skin_care\application\views\penerimaan\edit.php 113
DEBUG - 2018-03-10 02:14:07 --> Total execution time: 0.0730
ERROR - 2018-03-10 02:15:16 --> Severity: Notice --> Undefined index: nama_suplier E:\xampp\htdocs\skin_care\application\views\penerimaan\edit.php 9
DEBUG - 2018-03-10 02:15:16 --> Total execution time: 0.0660
ERROR - 2018-03-10 02:15:42 --> Severity: Notice --> Undefined index: nama_suplier E:\xampp\htdocs\skin_care\application\views\penerimaan\edit.php 9
DEBUG - 2018-03-10 02:15:42 --> Total execution time: 0.0411
ERROR - 2018-03-10 02:15:51 --> Severity: error --> Exception: Cannot use object of type stdClass as array E:\xampp\htdocs\skin_care\application\views\penerimaan\edit.php 9
DEBUG - 2018-03-10 02:16:01 --> Total execution time: 0.0461
DEBUG - 2018-03-10 02:16:33 --> Total execution time: 0.0547
DEBUG - 2018-03-10 02:17:00 --> Total execution time: 0.0567
DEBUG - 2018-03-10 02:21:23 --> Total execution time: 0.0423
DEBUG - 2018-03-10 02:21:42 --> Total execution time: 0.0452
DEBUG - 2018-03-10 02:26:10 --> Total execution time: 0.0470
DEBUG - 2018-03-10 02:26:35 --> Total execution time: 0.0527
DEBUG - 2018-03-10 02:27:51 --> Total execution time: 0.0655
DEBUG - 2018-03-10 02:29:48 --> Total execution time: 0.0568
DEBUG - 2018-03-10 02:30:17 --> Total execution time: 0.0531
DEBUG - 2018-03-10 02:30:56 --> Total execution time: 0.0426
DEBUG - 2018-03-10 02:31:10 --> Total execution time: 0.0459
DEBUG - 2018-03-10 02:31:28 --> Total execution time: 0.0492
DEBUG - 2018-03-10 02:31:46 --> Total execution time: 0.0547
DEBUG - 2018-03-10 02:31:58 --> Total execution time: 0.0470
DEBUG - 2018-03-10 02:33:05 --> Total execution time: 0.0523
DEBUG - 2018-03-10 02:33:08 --> Total execution time: 0.0393
DEBUG - 2018-03-10 02:33:58 --> Total execution time: 0.0499
DEBUG - 2018-03-10 02:35:33 --> Total execution time: 0.0549
DEBUG - 2018-03-10 02:36:45 --> Total execution time: 0.0480
DEBUG - 2018-03-10 02:37:10 --> Total execution time: 0.0473
DEBUG - 2018-03-10 02:38:33 --> Total execution time: 0.0481
DEBUG - 2018-03-10 02:39:40 --> Total execution time: 0.0457
DEBUG - 2018-03-10 02:40:12 --> Total execution time: 0.0529
DEBUG - 2018-03-10 02:41:06 --> Total execution time: 0.0517
DEBUG - 2018-03-10 02:41:08 --> Total execution time: 0.0508
DEBUG - 2018-03-10 02:41:10 --> Total execution time: 0.0489
DEBUG - 2018-03-10 02:41:12 --> Total execution time: 0.0511
DEBUG - 2018-03-10 02:41:56 --> Total execution time: 0.0473
DEBUG - 2018-03-10 02:42:28 --> Total execution time: 0.0553
DEBUG - 2018-03-10 02:42:48 --> Total execution time: 0.0489
ERROR - 2018-03-10 02:44:53 --> Query error: Unknown column 'nama_pegawai' in 'field list' - Invalid query: SELECT `detail_penerimaan`.*, `nama_product`, `nama_pegawai`
FROM `detail_penerimaan`
INNER JOIN `product` ON `product`.`id_product` = `detail_penerimaan`.`id_product`
WHERE `faktur_penerimaan` = '00012'
DEBUG - 2018-03-10 02:45:06 --> Total execution time: 0.0545
DEBUG - 2018-03-10 02:45:06 --> Total execution time: 0.0789
DEBUG - 2018-03-10 02:45:32 --> Total execution time: 0.0419
DEBUG - 2018-03-10 02:45:44 --> Total execution time: 0.0407
DEBUG - 2018-03-10 02:47:32 --> Total execution time: 0.0478
DEBUG - 2018-03-10 02:47:38 --> Total execution time: 0.0547
DEBUG - 2018-03-10 02:47:40 --> Total execution time: 0.0500
DEBUG - 2018-03-10 02:47:56 --> Total execution time: 0.0469
DEBUG - 2018-03-10 02:49:11 --> Total execution time: 0.0521
DEBUG - 2018-03-10 02:49:17 --> Total execution time: 0.0316
DEBUG - 2018-03-10 02:49:28 --> Total execution time: 0.0447
DEBUG - 2018-03-10 03:07:30 --> Total execution time: 0.0422
DEBUG - 2018-03-10 03:07:50 --> Total execution time: 0.0505
DEBUG - 2018-03-10 03:10:35 --> Total execution time: 0.0412
DEBUG - 2018-03-10 03:10:46 --> Total execution time: 0.0479
DEBUG - 2018-03-10 03:10:50 --> Total execution time: 0.0499
DEBUG - 2018-03-10 03:10:59 --> Total execution time: 0.0447
DEBUG - 2018-03-10 03:11:01 --> Total execution time: 0.0459
DEBUG - 2018-03-10 03:11:10 --> Total execution time: 0.0570
DEBUG - 2018-03-10 03:14:12 --> Total execution time: 0.0433
DEBUG - 2018-03-10 03:14:20 --> Total execution time: 0.0462
DEBUG - 2018-03-10 03:14:26 --> Total execution time: 0.0422
DEBUG - 2018-03-10 03:14:29 --> Total execution time: 0.0387
DEBUG - 2018-03-10 03:14:43 --> Total execution time: 0.0461
DEBUG - 2018-03-10 03:15:33 --> Total execution time: 0.0390
DEBUG - 2018-03-10 03:18:51 --> Total execution time: 0.0528
DEBUG - 2018-03-10 03:19:19 --> Total execution time: 0.0518
DEBUG - 2018-03-10 03:20:20 --> Total execution time: 0.0717
DEBUG - 2018-03-10 03:20:59 --> Total execution time: 0.1124
DEBUG - 2018-03-10 03:21:03 --> Total execution time: 0.0487
ERROR - 2018-03-10 03:23:11 --> Severity: Notice --> Undefined variable: id E:\xampp\htdocs\skin_care\application\models\Penerimaan_model.php 24
DEBUG - 2018-03-10 03:23:11 --> Total execution time: 0.0491
DEBUG - 2018-03-10 03:23:27 --> Total execution time: 0.0509
DEBUG - 2018-03-10 03:23:31 --> Total execution time: 0.0431
DEBUG - 2018-03-10 03:23:34 --> Total execution time: 0.0386
DEBUG - 2018-03-10 03:23:36 --> Total execution time: 0.0513
DEBUG - 2018-03-10 03:23:48 --> Total execution time: 0.0501
DEBUG - 2018-03-10 03:23:51 --> Total execution time: 0.0379
DEBUG - 2018-03-10 03:23:54 --> Total execution time: 0.0416
DEBUG - 2018-03-10 03:23:57 --> Total execution time: 0.0444
DEBUG - 2018-03-10 03:27:04 --> Total execution time: 0.0496
DEBUG - 2018-03-10 03:27:08 --> Total execution time: 0.0326
DEBUG - 2018-03-10 03:27:21 --> Total execution time: 0.0451
DEBUG - 2018-03-10 03:27:24 --> Total execution time: 0.0400
DEBUG - 2018-03-10 03:28:21 --> Total execution time: 0.0517
DEBUG - 2018-03-10 03:28:27 --> Total execution time: 0.0462
DEBUG - 2018-03-10 03:30:01 --> Total execution time: 0.0420
DEBUG - 2018-03-10 03:30:04 --> Total execution time: 0.0359
DEBUG - 2018-03-10 03:30:17 --> Total execution time: 0.0452
DEBUG - 2018-03-10 03:30:20 --> Total execution time: 0.0392
DEBUG - 2018-03-10 03:39:27 --> Total execution time: 0.0482
DEBUG - 2018-03-10 03:40:01 --> Total execution time: 0.0340
DEBUG - 2018-03-10 03:40:27 --> Total execution time: 0.0966
DEBUG - 2018-03-10 03:40:32 --> Total execution time: 0.0417
DEBUG - 2018-03-10 03:40:46 --> Total execution time: 0.0410
DEBUG - 2018-03-10 03:40:50 --> Total execution time: 0.0513
DEBUG - 2018-03-10 03:42:57 --> Total execution time: 0.0633
DEBUG - 2018-03-10 03:43:01 --> Total execution time: 0.0364
DEBUG - 2018-03-10 03:43:10 --> Total execution time: 0.0524
DEBUG - 2018-03-10 03:43:13 --> Total execution time: 0.0411
DEBUG - 2018-03-10 03:43:16 --> Total execution time: 0.0438
DEBUG - 2018-03-10 03:43:18 --> Total execution time: 0.0505
DEBUG - 2018-03-10 03:43:37 --> Total execution time: 0.0489
DEBUG - 2018-03-10 03:45:02 --> Total execution time: 0.0593
DEBUG - 2018-03-10 03:45:06 --> Total execution time: 0.0365
DEBUG - 2018-03-10 03:45:11 --> Total execution time: 0.0456
DEBUG - 2018-03-10 03:47:04 --> Total execution time: 0.0599
DEBUG - 2018-03-10 03:47:08 --> Total execution time: 0.0338
ERROR - 2018-03-10 03:47:11 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`detail_penerimaan`, CONSTRAINT `faktur_penrimaan` FOREIGN KEY (`faktur_penerimaan`) REFERENCES `penerimaan` (`faktur_penerimaan`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `penerimaan`
WHERE `faktur_penerimaan` = '00012'
DEBUG - 2018-03-10 03:47:11 --> DB Transaction Failure
DEBUG - 2018-03-10 03:50:58 --> Total execution time: 0.0576
DEBUG - 2018-03-10 03:51:03 --> Total execution time: 0.0423
DEBUG - 2018-03-10 03:51:08 --> Total execution time: 0.0369
ERROR - 2018-03-10 03:51:10 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`detail_penerimaan`, CONSTRAINT `faktur_penrimaan` FOREIGN KEY (`faktur_penerimaan`) REFERENCES `penerimaan` (`faktur_penerimaan`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `penerimaan`
WHERE `faktur_penerimaan` = '00012'
DEBUG - 2018-03-10 03:51:10 --> DB Transaction Failure
DEBUG - 2018-03-10 03:51:10 --> Total execution time: 0.1078
DEBUG - 2018-03-10 03:51:20 --> Total execution time: 0.0461
DEBUG - 2018-03-10 03:52:06 --> Total execution time: 0.0323
ERROR - 2018-03-10 03:52:09 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`detail_penerimaan`, CONSTRAINT `faktur_penrimaan` FOREIGN KEY (`faktur_penerimaan`) REFERENCES `penerimaan` (`faktur_penerimaan`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `penerimaan`
WHERE `faktur_penerimaan` = '00012'
DEBUG - 2018-03-10 03:52:09 --> DB Transaction Failure
DEBUG - 2018-03-10 03:52:09 --> Total execution time: 0.0805
DEBUG - 2018-03-10 03:52:36 --> Total execution time: 0.0430
DEBUG - 2018-03-10 03:52:39 --> Total execution time: 0.0566
ERROR - 2018-03-10 03:52:41 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`detail_penerimaan`, CONSTRAINT `faktur_penrimaan` FOREIGN KEY (`faktur_penerimaan`) REFERENCES `penerimaan` (`faktur_penerimaan`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `penerimaan`
WHERE `faktur_penerimaan` = '00012'
DEBUG - 2018-03-10 03:52:41 --> DB Transaction Failure
DEBUG - 2018-03-10 03:52:49 --> Total execution time: 0.0658
DEBUG - 2018-03-10 03:52:53 --> Total execution time: 0.0497
ERROR - 2018-03-10 03:52:55 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`detail_penerimaan`, CONSTRAINT `faktur_penrimaan` FOREIGN KEY (`faktur_penerimaan`) REFERENCES `penerimaan` (`faktur_penerimaan`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `penerimaan`
WHERE `faktur_penerimaan` = '00012'
DEBUG - 2018-03-10 03:52:55 --> DB Transaction Failure
DEBUG - 2018-03-10 03:52:55 --> Total execution time: 0.0646
DEBUG - 2018-03-10 03:55:23 --> Total execution time: 0.0507
DEBUG - 2018-03-10 03:55:26 --> Total execution time: 0.0413
DEBUG - 2018-03-10 03:55:28 --> Total execution time: 0.0443
DEBUG - 2018-03-10 03:55:37 --> Total execution time: 0.0480
DEBUG - 2018-03-10 03:55:40 --> Total execution time: 0.0452
DEBUG - 2018-03-10 03:55:42 --> Total execution time: 0.0422
DEBUG - 2018-03-10 03:55:51 --> Total execution time: 0.0673
DEBUG - 2018-03-10 03:55:53 --> Total execution time: 0.0546
DEBUG - 2018-03-10 03:56:04 --> Total execution time: 0.0767
DEBUG - 2018-03-10 03:56:25 --> Total execution time: 0.0468
DEBUG - 2018-03-10 03:57:40 --> Total execution time: 0.1182
DEBUG - 2018-03-10 03:57:42 --> Total execution time: 0.0784
DEBUG - 2018-03-10 03:57:44 --> Total execution time: 0.0347
DEBUG - 2018-03-10 03:57:53 --> Total execution time: 0.0444
DEBUG - 2018-03-10 03:57:59 --> Total execution time: 0.0534
DEBUG - 2018-03-10 03:58:09 --> Total execution time: 0.0510
DEBUG - 2018-03-10 03:58:13 --> Total execution time: 0.1076
DEBUG - 2018-03-10 04:01:36 --> Total execution time: 0.0424
DEBUG - 2018-03-10 04:01:41 --> Total execution time: 0.0420
DEBUG - 2018-03-10 08:59:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-10 08:59:12 --> No URI present. Default controller set.
DEBUG - 2018-03-10 08:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-10 08:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-10 14:59:12 --> Total execution time: 0.1270
DEBUG - 2018-03-10 08:59:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-10 08:59:21 --> No URI present. Default controller set.
DEBUG - 2018-03-10 08:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-10 08:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-10 08:59:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-10 08:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-10 08:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-10 14:59:22 --> Total execution time: 0.2783
DEBUG - 2018-03-10 08:59:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-10 08:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-10 08:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-10 14:59:27 --> Total execution time: 0.2287
DEBUG - 2018-03-10 08:59:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-10 08:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-10 08:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-10 14:59:30 --> Total execution time: 0.1657
DEBUG - 2018-03-10 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-10 09:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-10 09:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-10 15:07:25 --> Total execution time: 0.0498
DEBUG - 2018-03-10 09:07:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-10 09:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-10 09:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-10 15:07:32 --> Total execution time: 0.1012
DEBUG - 2018-03-10 09:07:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-10 09:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-10 09:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-10 15:07:39 --> Total execution time: 0.1631
DEBUG - 2018-03-10 15:27:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-10 15:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-10 15:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-10 15:27:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-10 15:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-10 15:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-10 21:27:40 --> Total execution time: 0.0356
