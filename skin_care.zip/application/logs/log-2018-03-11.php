<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-11 17:29:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:29:03 --> No URI present. Default controller set.
DEBUG - 2018-03-11 17:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:29:03 --> Total execution time: 0.0344
DEBUG - 2018-03-11 17:29:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:29:08 --> No URI present. Default controller set.
DEBUG - 2018-03-11 17:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 17:29:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:29:08 --> Total execution time: 0.0687
DEBUG - 2018-03-11 17:33:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:33:10 --> Total execution time: 0.1094
DEBUG - 2018-03-11 17:33:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:33:14 --> Total execution time: 0.0537
DEBUG - 2018-03-11 17:33:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 17:33:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:33:45 --> Total execution time: 0.0674
DEBUG - 2018-03-11 17:33:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:33:50 --> Total execution time: 0.0588
DEBUG - 2018-03-11 17:33:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:33:52 --> Total execution time: 0.0499
DEBUG - 2018-03-11 17:33:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 17:33:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:33:57 --> Total execution time: 0.0625
DEBUG - 2018-03-11 17:34:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 17:34:00 --> Severity: error --> Exception: E:\xampp\htdocs\skin_care\application\models/Penjualan_model.php exists, but doesn't declare class Penjualan_model E:\xampp\htdocs\skin_care\system\core\Loader.php 336
DEBUG - 2018-03-11 17:34:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 17:34:20 --> Severity: error --> Exception: E:\xampp\htdocs\skin_care\application\models/Penjualan_model.php exists, but doesn't declare class Penjualan_model E:\xampp\htdocs\skin_care\system\core\Loader.php 336
DEBUG - 2018-03-11 17:34:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 17:34:35 --> Severity: error --> Exception: E:\xampp\htdocs\skin_care\application\models/Detail_penjualan_model.php exists, but doesn't declare class Detail_penjualan_model E:\xampp\htdocs\skin_care\system\core\Loader.php 336
DEBUG - 2018-03-11 17:34:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 23:34:50 --> Query error: Unknown column 'penerimaan.tgl_penerimaan' in 'where clause' - Invalid query: SELECT `penjualan`.*, `nama_suplier`, `nama_pegawai`
FROM `penjualan`
INNER JOIN `mst_pegawai` ON `mst_pegawai`.`id_mst_pegawai` = `penjualan`.`id_mst_pegawai`
INNER JOIN `mst_suplier` ON `mst_suplier`.`id_suplier` = `penjualan`.`id_suplier`
WHERE `penerimaan`.`tgl_penerimaan` = '2018-03-11'
ERROR - 2018-03-11 23:34:50 --> Severity: error --> Exception: Call to a member function result() on boolean E:\xampp\htdocs\skin_care\application\models\Penjualan_model.php 26
DEBUG - 2018-03-11 17:35:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 23:35:44 --> Query error: Unknown column 'penerimaan.tgl_penerimaan' in 'where clause' - Invalid query: SELECT `penjualan`.*, `nama_suplier`, `nama_pegawai`
FROM `penjualan`
INNER JOIN `mst_pegawai` ON `mst_pegawai`.`id_mst_pegawai` = `penjualan`.`id_mst_pegawai`
INNER JOIN `mst_suplier` ON `mst_suplier`.`id_suplier` = `penjualan`.`id_suplier`
WHERE `penerimaan`.`tgl_penerimaan` = '2018-03-11'
ERROR - 2018-03-11 23:35:44 --> Severity: error --> Exception: Call to a member function result() on boolean E:\xampp\htdocs\skin_care\application\models\Penjualan_model.php 26
DEBUG - 2018-03-11 17:36:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 23:36:07 --> Query error: Unknown column 'penerimaan.tgl_penjualan' in 'where clause' - Invalid query: SELECT `penjualan`.*, `nama_suplier`, `nama_pegawai`
FROM `penjualan`
INNER JOIN `mst_pegawai` ON `mst_pegawai`.`id_mst_pegawai` = `penjualan`.`id_mst_pegawai`
INNER JOIN `mst_suplier` ON `mst_suplier`.`id_suplier` = `penjualan`.`id_suplier`
WHERE `penerimaan`.`tgl_penjualan` = '2018-03-11'
ERROR - 2018-03-11 23:36:07 --> Severity: error --> Exception: Call to a member function result() on boolean E:\xampp\htdocs\skin_care\application\models\Penjualan_model.php 26
DEBUG - 2018-03-11 17:36:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 23:36:08 --> Query error: Unknown column 'penerimaan.tgl_penjualan' in 'where clause' - Invalid query: SELECT `penjualan`.*, `nama_suplier`, `nama_pegawai`
FROM `penjualan`
INNER JOIN `mst_pegawai` ON `mst_pegawai`.`id_mst_pegawai` = `penjualan`.`id_mst_pegawai`
INNER JOIN `mst_suplier` ON `mst_suplier`.`id_suplier` = `penjualan`.`id_suplier`
WHERE `penerimaan`.`tgl_penjualan` = '2018-03-11'
ERROR - 2018-03-11 23:36:08 --> Severity: error --> Exception: Call to a member function result() on boolean E:\xampp\htdocs\skin_care\application\models\Penjualan_model.php 26
DEBUG - 2018-03-11 17:36:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 23:36:08 --> Query error: Unknown column 'penerimaan.tgl_penjualan' in 'where clause' - Invalid query: SELECT `penjualan`.*, `nama_suplier`, `nama_pegawai`
FROM `penjualan`
INNER JOIN `mst_pegawai` ON `mst_pegawai`.`id_mst_pegawai` = `penjualan`.`id_mst_pegawai`
INNER JOIN `mst_suplier` ON `mst_suplier`.`id_suplier` = `penjualan`.`id_suplier`
WHERE `penerimaan`.`tgl_penjualan` = '2018-03-11'
ERROR - 2018-03-11 23:36:08 --> Severity: error --> Exception: Call to a member function result() on boolean E:\xampp\htdocs\skin_care\application\models\Penjualan_model.php 26
DEBUG - 2018-03-11 17:36:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 23:36:20 --> Query error: Unknown column 'penjualan.id_suplier' in 'on clause' - Invalid query: SELECT `penjualan`.*, `nama_suplier`, `nama_pegawai`
FROM `penjualan`
INNER JOIN `mst_pegawai` ON `mst_pegawai`.`id_mst_pegawai` = `penjualan`.`id_mst_pegawai`
INNER JOIN `mst_suplier` ON `mst_suplier`.`id_suplier` = `penjualan`.`id_suplier`
WHERE `penjualan`.`tgl_penjualan` = '2018-03-11'
ERROR - 2018-03-11 23:36:20 --> Severity: error --> Exception: Call to a member function result() on boolean E:\xampp\htdocs\skin_care\application\models\Penjualan_model.php 26
DEBUG - 2018-03-11 17:36:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:36:41 --> Total execution time: 0.0421
DEBUG - 2018-03-11 17:39:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:39:12 --> Total execution time: 0.0477
DEBUG - 2018-03-11 17:39:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:39:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-11 17:39:16 --> 404 Page Not Found: gudang/Penjualan/create
DEBUG - 2018-03-11 17:39:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:39:18 --> Total execution time: 0.0470
DEBUG - 2018-03-11 17:44:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:44:08 --> Total execution time: 0.1059
DEBUG - 2018-03-11 17:44:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:44:13 --> Total execution time: 0.0736
DEBUG - 2018-03-11 17:44:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:44:26 --> Total execution time: 0.0616
DEBUG - 2018-03-11 17:44:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:44:32 --> Total execution time: 0.0606
DEBUG - 2018-03-11 17:44:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:44:33 --> Total execution time: 0.0530
DEBUG - 2018-03-11 17:44:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 17:44:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:44:56 --> Total execution time: 0.1146
DEBUG - 2018-03-11 17:45:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:45:43 --> Total execution time: 0.1007
DEBUG - 2018-03-11 17:45:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 17:45:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:45:48 --> Total execution time: 0.0551
DEBUG - 2018-03-11 17:45:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:45:57 --> Total execution time: 0.0452
DEBUG - 2018-03-11 17:45:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:45:58 --> Total execution time: 0.0493
DEBUG - 2018-03-11 17:46:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:46:05 --> Total execution time: 0.0444
DEBUG - 2018-03-11 17:46:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:46:19 --> Total execution time: 0.0426
DEBUG - 2018-03-11 17:46:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 17:46:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:46:32 --> Total execution time: 0.0469
DEBUG - 2018-03-11 17:46:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:46:44 --> Total execution time: 0.0445
DEBUG - 2018-03-11 17:46:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 23:46:47 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`detail_penerimaan`, CONSTRAINT `faktur_penrimaan` FOREIGN KEY (`faktur_penerimaan`) REFERENCES `penerimaan` (`faktur_penerimaan`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `penerimaan`
WHERE `faktur_penerimaan` = '00015'
DEBUG - 2018-03-11 23:46:47 --> DB Transaction Failure
DEBUG - 2018-03-11 17:46:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:46:47 --> Total execution time: 0.0500
DEBUG - 2018-03-11 17:46:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:46:53 --> Total execution time: 0.0388
DEBUG - 2018-03-11 17:46:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:46:56 --> Total execution time: 0.0437
DEBUG - 2018-03-11 17:46:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 23:46:58 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`detail_penerimaan`, CONSTRAINT `faktur_penrimaan` FOREIGN KEY (`faktur_penerimaan`) REFERENCES `penerimaan` (`faktur_penerimaan`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `penerimaan`
WHERE `faktur_penerimaan` = '00015'
DEBUG - 2018-03-11 23:46:58 --> DB Transaction Failure
DEBUG - 2018-03-11 17:46:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:46:58 --> Total execution time: 0.0548
DEBUG - 2018-03-11 17:47:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:47:04 --> Total execution time: 0.0534
DEBUG - 2018-03-11 17:47:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:47:08 --> Total execution time: 0.0530
DEBUG - 2018-03-11 17:48:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:48:47 --> Total execution time: 0.0396
DEBUG - 2018-03-11 17:48:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 23:48:50 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`detail_penerimaan`, CONSTRAINT `faktur_penrimaan` FOREIGN KEY (`faktur_penerimaan`) REFERENCES `penerimaan` (`faktur_penerimaan`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `mst_suplier`
WHERE `id_suplier` = '1'
DEBUG - 2018-03-11 23:48:50 --> DB Transaction Failure
DEBUG - 2018-03-11 17:48:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:48:50 --> Total execution time: 0.0446
DEBUG - 2018-03-11 17:49:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 23:49:05 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`detail_penerimaan`, CONSTRAINT `faktur_penrimaan` FOREIGN KEY (`faktur_penerimaan`) REFERENCES `penerimaan` (`faktur_penerimaan`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `mst_suplier`
WHERE `id_suplier` = '1'
DEBUG - 2018-03-11 23:49:05 --> DB Transaction Failure
DEBUG - 2018-03-11 17:49:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:49:05 --> Total execution time: 0.0496
DEBUG - 2018-03-11 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 23:49:25 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`penerimaan`, CONSTRAINT `suplier_penerimaan` FOREIGN KEY (`id_suplier`) REFERENCES `mst_suplier` (`id_suplier`)) - Invalid query: DELETE FROM `mst_suplier`
WHERE `id_suplier` = '1'
DEBUG - 2018-03-11 23:49:25 --> DB Transaction Failure
DEBUG - 2018-03-11 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:49:25 --> Total execution time: 0.1631
DEBUG - 2018-03-11 17:49:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:49:39 --> Total execution time: 0.0492
DEBUG - 2018-03-11 17:49:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 23:49:42 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`detail_penerimaan`, CONSTRAINT `faktur_penrimaan` FOREIGN KEY (`faktur_penerimaan`) REFERENCES `penerimaan` (`faktur_penerimaan`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `mst_suplier`
WHERE `id_suplier` = '1'
DEBUG - 2018-03-11 23:49:42 --> DB Transaction Failure
DEBUG - 2018-03-11 17:49:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:49:42 --> Total execution time: 0.0579
DEBUG - 2018-03-11 17:50:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 23:50:20 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`penerimaan`, CONSTRAINT `suplier_penerimaan` FOREIGN KEY (`id_suplier`) REFERENCES `mst_suplier` (`id_suplier`) ON DELETE NO ACTION ON UPDATE CASCADE) - Invalid query: DELETE FROM `mst_suplier`
WHERE `id_suplier` = '1'
DEBUG - 2018-03-11 23:50:20 --> DB Transaction Failure
DEBUG - 2018-03-11 17:50:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:50:20 --> Total execution time: 0.0506
DEBUG - 2018-03-11 17:50:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:50:22 --> Total execution time: 0.0388
DEBUG - 2018-03-11 17:50:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-11 23:50:25 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`detail_penerimaan`, CONSTRAINT `faktur_penrimaan` FOREIGN KEY (`faktur_penerimaan`) REFERENCES `penerimaan` (`faktur_penerimaan`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `penerimaan`
WHERE `faktur_penerimaan` = '00015'
DEBUG - 2018-03-11 23:50:25 --> DB Transaction Failure
DEBUG - 2018-03-11 17:50:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:50:25 --> Total execution time: 0.0469
DEBUG - 2018-03-11 17:50:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:50:48 --> Total execution time: 0.0995
DEBUG - 2018-03-11 17:50:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:50:59 --> Total execution time: 0.0608
DEBUG - 2018-03-11 17:51:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 17:51:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:51:06 --> Total execution time: 0.0653
DEBUG - 2018-03-11 17:51:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:51:08 --> Total execution time: 0.0449
DEBUG - 2018-03-11 17:51:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 17:51:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:51:11 --> Total execution time: 0.0877
DEBUG - 2018-03-11 17:51:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:51:28 --> Total execution time: 0.1785
DEBUG - 2018-03-11 17:51:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:51:29 --> Total execution time: 0.0545
DEBUG - 2018-03-11 17:54:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:54:31 --> Total execution time: 0.0450
DEBUG - 2018-03-11 17:57:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:57:22 --> Total execution time: 0.0424
DEBUG - 2018-03-11 17:57:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:57:26 --> Total execution time: 0.0405
DEBUG - 2018-03-11 17:59:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:59:14 --> Total execution time: 0.0451
DEBUG - 2018-03-11 17:59:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:59:17 --> Total execution time: 0.0307
DEBUG - 2018-03-11 17:59:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:59:55 --> Total execution time: 0.0514
DEBUG - 2018-03-11 17:59:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 17:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 17:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 23:59:58 --> Total execution time: 0.0464
DEBUG - 2018-03-11 18:00:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:00:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:01:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:01:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:03:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:03:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:04:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:04:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:07:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:07:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:07:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:07:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:08:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:08:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:08:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:08:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:08:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:08:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-11 18:08:37 --> 404 Page Not Found: gudang/Penjualan/detail
DEBUG - 2018-03-11 18:09:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:15:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:15:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:15:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-11 18:15:59 --> 404 Page Not Found: gudang/Penjualan/detail
ERROR - 2018-03-11 18:15:59 --> Severity: error --> Exception: Call to undefined function base_url() E:\xampp\htdocs\skin_care\application\views\errors\html\error_404.php 2
DEBUG - 2018-03-11 18:15:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:16:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:16:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-11 18:16:09 --> 404 Page Not Found: gudang/Penjualan/detail
ERROR - 2018-03-11 18:16:09 --> Severity: error --> Exception: Call to undefined function base_url() E:\xampp\htdocs\skin_care\application\views\errors\html\error_404.php 2
DEBUG - 2018-03-11 18:16:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:16:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:16:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-11 18:16:10 --> 404 Page Not Found: gudang/Penjualan/detail
ERROR - 2018-03-11 18:16:10 --> Severity: error --> Exception: Call to undefined function base_url() E:\xampp\htdocs\skin_care\application\views\errors\html\error_404.php 2
DEBUG - 2018-03-11 18:16:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:16:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:16:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-11 18:16:25 --> 404 Page Not Found: gudang/Penjualan/detail
DEBUG - 2018-03-11 18:17:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:17:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:17:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:18:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:19:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:19:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-11 18:19:06 --> 404 Page Not Found: gudang/Penjualan/edit
DEBUG - 2018-03-11 18:29:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:29:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:29:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:29:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:32:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:32:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:33:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:33:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:34:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:35:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:35:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:35:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:35:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-11 18:35:43 --> 404 Page Not Found: gudang/Penjualan/detail
DEBUG - 2018-03-11 18:35:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:36:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:36:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:39:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:39:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:40:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:40:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:40:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:41:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:41:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:41:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:41:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:43:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:43:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:43:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:44:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:44:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:45:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:45:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:51:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:51:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:51:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:51:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:51:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:51:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:51:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:52:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:52:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:52:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:52:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:52:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:53:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:53:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:53:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:53:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-11 18:53:32 --> 404 Page Not Found: gudang/Penjualan/detail
DEBUG - 2018-03-11 18:53:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 18:54:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:54:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-11 18:54:53 --> 404 Page Not Found: gudang/Penjualan/delete
DEBUG - 2018-03-11 18:54:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 18:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 18:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 19:01:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 19:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 19:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-11 19:01:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-11 19:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-11 19:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
