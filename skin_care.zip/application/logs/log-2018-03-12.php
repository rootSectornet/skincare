<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-12 00:00:23 --> Total execution time: 0.0405
DEBUG - 2018-03-12 00:00:26 --> Total execution time: 0.0458
DEBUG - 2018-03-12 00:01:22 --> Total execution time: 0.0324
DEBUG - 2018-03-12 00:01:33 --> Total execution time: 0.0435
DEBUG - 2018-03-12 00:03:34 --> Total execution time: 0.0481
DEBUG - 2018-03-12 00:03:58 --> Total execution time: 0.0439
DEBUG - 2018-03-12 00:04:15 --> Total execution time: 0.0455
DEBUG - 2018-03-12 00:04:28 --> Total execution time: 0.0568
DEBUG - 2018-03-12 00:07:02 --> Total execution time: 0.0434
DEBUG - 2018-03-12 00:07:06 --> Total execution time: 0.0371
DEBUG - 2018-03-12 00:07:16 --> Total execution time: 0.0390
ERROR - 2018-03-12 00:07:20 --> Query error: Unknown column 'harga_beli' in 'field list' - Invalid query: INSERT INTO `detail_penjualan` (`id_product`, `qty`, `harga`, `sub_total`, `harga_beli`, `faktur_penjualan`) VALUES ('2', '3', '20000', '60000', '10000', 'FP00001')
ERROR - 2018-03-12 00:07:20 --> Query error: Unknown column 'harga_beli' in 'field list' - Invalid query: INSERT INTO `detail_penjualan` (`id_product`, `qty`, `harga`, `sub_total`, `harga_beli`, `faktur_penjualan`) VALUES ('2', '1', '20000', '20000', '10000', 'FP00001')
DEBUG - 2018-03-12 00:07:20 --> DB Transaction Failure
DEBUG - 2018-03-12 00:07:20 --> Total execution time: 0.0488
DEBUG - 2018-03-12 00:08:22 --> Total execution time: 0.0517
DEBUG - 2018-03-12 00:08:29 --> Total execution time: 0.0405
DEBUG - 2018-03-12 00:08:33 --> Total execution time: 0.0403
DEBUG - 2018-03-12 00:09:42 --> Total execution time: 0.1267
DEBUG - 2018-03-12 00:15:56 --> Total execution time: 0.0534
DEBUG - 2018-03-12 00:17:02 --> Total execution time: 0.0474
DEBUG - 2018-03-12 00:17:18 --> Total execution time: 0.0653
DEBUG - 2018-03-12 00:17:34 --> Total execution time: 0.0494
DEBUG - 2018-03-12 00:18:55 --> Total execution time: 0.0524
DEBUG - 2018-03-12 00:29:07 --> Total execution time: 0.0903
DEBUG - 2018-03-12 00:29:11 --> Total execution time: 0.0327
DEBUG - 2018-03-12 00:29:32 --> Total execution time: 0.0465
DEBUG - 2018-03-12 00:29:39 --> Total execution time: 0.0307
DEBUG - 2018-03-12 00:32:54 --> Total execution time: 0.0502
DEBUG - 2018-03-12 00:32:57 --> Total execution time: 0.0402
DEBUG - 2018-03-12 00:33:38 --> Total execution time: 0.0753
DEBUG - 2018-03-12 00:33:48 --> Total execution time: 0.0347
DEBUG - 2018-03-12 00:34:20 --> Total execution time: 0.0565
DEBUG - 2018-03-12 00:35:35 --> Total execution time: 0.0445
DEBUG - 2018-03-12 00:35:47 --> Total execution time: 0.0472
DEBUG - 2018-03-12 00:36:05 --> Total execution time: 0.0444
DEBUG - 2018-03-12 00:36:17 --> Total execution time: 0.0532
DEBUG - 2018-03-12 00:39:01 --> Total execution time: 0.0774
DEBUG - 2018-03-12 00:39:05 --> Total execution time: 0.0775
DEBUG - 2018-03-12 00:40:41 --> Total execution time: 0.0578
DEBUG - 2018-03-12 00:40:45 --> Total execution time: 0.0661
DEBUG - 2018-03-12 00:40:48 --> Total execution time: 0.1440
DEBUG - 2018-03-12 00:41:02 --> Total execution time: 0.0478
DEBUG - 2018-03-12 00:41:05 --> Total execution time: 0.0533
DEBUG - 2018-03-12 00:41:09 --> Total execution time: 0.0378
DEBUG - 2018-03-12 00:43:54 --> Total execution time: 0.0435
DEBUG - 2018-03-12 00:43:56 --> Total execution time: 0.0585
DEBUG - 2018-03-12 00:44:00 --> Total execution time: 0.0366
DEBUG - 2018-03-12 00:44:39 --> Total execution time: 0.0514
DEBUG - 2018-03-12 00:44:49 --> Total execution time: 0.0435
DEBUG - 2018-03-12 00:45:32 --> Total execution time: 0.0610
DEBUG - 2018-03-12 00:45:36 --> Total execution time: 0.0355
DEBUG - 2018-03-12 00:51:29 --> Total execution time: 0.0452
DEBUG - 2018-03-12 00:51:33 --> Total execution time: 0.0315
DEBUG - 2018-03-12 00:51:35 --> Total execution time: 0.0410
DEBUG - 2018-03-12 00:51:38 --> Total execution time: 0.0372
DEBUG - 2018-03-12 00:51:38 --> Total execution time: 0.0609
DEBUG - 2018-03-12 00:51:40 --> Total execution time: 0.0299
DEBUG - 2018-03-12 00:51:41 --> Total execution time: 0.0403
DEBUG - 2018-03-12 00:52:01 --> Total execution time: 0.0682
DEBUG - 2018-03-12 00:52:05 --> Total execution time: 0.0400
DEBUG - 2018-03-12 00:52:53 --> Total execution time: 0.0666
DEBUG - 2018-03-12 00:52:56 --> Total execution time: 0.0408
DEBUG - 2018-03-12 00:52:59 --> Total execution time: 0.0677
DEBUG - 2018-03-12 00:53:03 --> Total execution time: 0.0564
DEBUG - 2018-03-12 00:53:05 --> Total execution time: 0.0540
DEBUG - 2018-03-12 00:53:33 --> Total execution time: 0.0447
DEBUG - 2018-03-12 00:54:55 --> Total execution time: 0.0478
DEBUG - 2018-03-12 01:01:26 --> Total execution time: 0.0640
DEBUG - 2018-03-12 01:01:28 --> Total execution time: 0.0558
DEBUG - 2018-03-12 14:12:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:12:31 --> No URI present. Default controller set.
DEBUG - 2018-03-12 14:12:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-12 14:12:33 --> Unable to connect to the database
DEBUG - 2018-03-12 14:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:12:34 --> Total execution time: 4.5567
DEBUG - 2018-03-12 14:13:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:13:02 --> No URI present. Default controller set.
DEBUG - 2018-03-12 14:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 14:13:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:13:06 --> Total execution time: 1.3376
DEBUG - 2018-03-12 14:13:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:13:23 --> Total execution time: 0.8053
DEBUG - 2018-03-12 14:13:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:13:25 --> Total execution time: 0.1011
DEBUG - 2018-03-12 14:13:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:13:35 --> Total execution time: 0.1261
DEBUG - 2018-03-12 14:13:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:13:45 --> Total execution time: 0.1614
DEBUG - 2018-03-12 14:14:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:14:23 --> Total execution time: 0.0748
DEBUG - 2018-03-12 14:14:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:14:23 --> Total execution time: 0.0875
DEBUG - 2018-03-12 14:16:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:16:35 --> Total execution time: 0.0874
DEBUG - 2018-03-12 14:16:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:16:52 --> Total execution time: 0.3306
DEBUG - 2018-03-12 14:16:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:16:55 --> Total execution time: 0.1942
DEBUG - 2018-03-12 14:17:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:17:13 --> Total execution time: 0.0943
DEBUG - 2018-03-12 14:17:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:17:29 --> Total execution time: 0.1991
DEBUG - 2018-03-12 14:17:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:17:32 --> Total execution time: 0.2513
DEBUG - 2018-03-12 14:17:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:17:35 --> Total execution time: 0.0903
DEBUG - 2018-03-12 14:17:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:17:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-12 14:17:41 --> 404 Page Not Found: gudang/Penjualan/delete
DEBUG - 2018-03-12 14:17:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:17:44 --> Total execution time: 0.1101
DEBUG - 2018-03-12 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:17:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-12 14:17:46 --> 404 Page Not Found: gudang/Penjualan/detail
DEBUG - 2018-03-12 14:17:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:17:48 --> Total execution time: 0.0944
DEBUG - 2018-03-12 14:19:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 14:19:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 14:19:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 14:19:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 14:20:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:20:13 --> Total execution time: 0.0878
DEBUG - 2018-03-12 14:21:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:21:25 --> Total execution time: 0.0933
DEBUG - 2018-03-12 14:21:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:21:30 --> Total execution time: 0.0725
DEBUG - 2018-03-12 14:21:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:21:34 --> Total execution time: 0.0832
DEBUG - 2018-03-12 14:21:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 14:21:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:21:41 --> Total execution time: 0.0948
DEBUG - 2018-03-12 14:21:46 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:21:46 --> Total execution time: 0.0852
DEBUG - 2018-03-12 14:21:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:21:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-12 14:21:48 --> 404 Page Not Found: gudang/Penerimaan/print00014
DEBUG - 2018-03-12 14:21:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:21:50 --> Total execution time: 0.1068
DEBUG - 2018-03-12 14:25:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:25:31 --> Total execution time: 0.0781
DEBUG - 2018-03-12 14:28:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:28:16 --> Total execution time: 0.0537
DEBUG - 2018-03-12 14:28:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:28:30 --> Total execution time: 0.0745
DEBUG - 2018-03-12 14:28:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:28:36 --> Total execution time: 0.0590
DEBUG - 2018-03-12 14:29:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:29:02 --> Total execution time: 0.0782
DEBUG - 2018-03-12 14:29:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:29:06 --> Total execution time: 0.1167
DEBUG - 2018-03-12 14:30:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:30:21 --> Total execution time: 0.0660
DEBUG - 2018-03-12 14:30:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:30:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-12 14:30:32 --> 404 Page Not Found: gudang/Penjualan/detail
DEBUG - 2018-03-12 14:32:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:32:32 --> Total execution time: 0.0633
DEBUG - 2018-03-12 14:33:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:33:48 --> Total execution time: 0.0662
DEBUG - 2018-03-12 14:36:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:36:03 --> Total execution time: 0.0835
DEBUG - 2018-03-12 14:36:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:36:30 --> Total execution time: 0.0856
DEBUG - 2018-03-12 14:37:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:37:02 --> Total execution time: 0.0805
DEBUG - 2018-03-12 14:37:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:37:28 --> Total execution time: 0.0858
DEBUG - 2018-03-12 14:38:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:38:29 --> Total execution time: 0.1006
DEBUG - 2018-03-12 14:38:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 14:38:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:38:44 --> Total execution time: 0.0952
DEBUG - 2018-03-12 14:38:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 14:38:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:38:59 --> Total execution time: 0.0829
DEBUG - 2018-03-12 14:39:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:39:06 --> Total execution time: 0.0944
DEBUG - 2018-03-12 14:39:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:39:10 --> Total execution time: 0.0942
DEBUG - 2018-03-12 14:39:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:39:14 --> Total execution time: 0.1075
DEBUG - 2018-03-12 14:39:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:39:20 --> Total execution time: 0.0650
DEBUG - 2018-03-12 14:39:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:39:25 --> Total execution time: 0.0718
DEBUG - 2018-03-12 14:39:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:39:27 --> Total execution time: 0.0967
DEBUG - 2018-03-12 14:40:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:40:22 --> Total execution time: 0.0906
DEBUG - 2018-03-12 14:40:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:40:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-12 14:40:25 --> 404 Page Not Found: gudang/Penjualan/printFP00001
DEBUG - 2018-03-12 14:40:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:40:26 --> Total execution time: 0.0610
DEBUG - 2018-03-12 14:40:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:40:45 --> Total execution time: 0.0598
DEBUG - 2018-03-12 14:42:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:42:34 --> Total execution time: 0.0596
DEBUG - 2018-03-12 14:42:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:42:39 --> Total execution time: 0.0704
DEBUG - 2018-03-12 14:42:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-12 20:42:43 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`detail_penjualan`, CONSTRAINT `faktur_penjualan` FOREIGN KEY (`faktur_penjualan`) REFERENCES `penjualan` (`faktur_penjualan`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `penjualan`
WHERE `faktur_penjualan` = 'FP00001'
DEBUG - 2018-03-12 20:42:43 --> DB Transaction Failure
DEBUG - 2018-03-12 14:42:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:42:44 --> Total execution time: 0.1194
DEBUG - 2018-03-12 14:43:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:43:19 --> Total execution time: 0.1626
DEBUG - 2018-03-12 14:43:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:43:25 --> Total execution time: 0.1310
DEBUG - 2018-03-12 14:43:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:43:28 --> Total execution time: 0.0909
DEBUG - 2018-03-12 14:43:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 14:43:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:43:48 --> Total execution time: 0.1269
DEBUG - 2018-03-12 14:44:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:44:05 --> Total execution time: 0.1432
DEBUG - 2018-03-12 14:45:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:45:12 --> Total execution time: 0.0798
DEBUG - 2018-03-12 14:45:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:45:19 --> Total execution time: 0.0634
DEBUG - 2018-03-12 14:45:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:45:21 --> Total execution time: 0.0789
DEBUG - 2018-03-12 14:45:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 14:45:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:45:25 --> Total execution time: 0.1276
DEBUG - 2018-03-12 14:45:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 14:45:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:45:31 --> Total execution time: 0.1282
DEBUG - 2018-03-12 14:45:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:45:35 --> Total execution time: 0.0750
DEBUG - 2018-03-12 14:45:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 14:45:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:45:38 --> Total execution time: 0.0932
DEBUG - 2018-03-12 14:46:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:46:51 --> Total execution time: 0.0823
DEBUG - 2018-03-12 14:47:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 14:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 14:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 20:47:09 --> Total execution time: 0.0687
DEBUG - 2018-03-12 15:02:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 15:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 15:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 15:02:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-12 15:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-12 15:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-12 21:02:44 --> Total execution time: 0.0926
