<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-14 15:40:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 15:40:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:40:18 --> Total execution time: 0.0720
DEBUG - 2018-03-14 15:40:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 15:40:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:40:25 --> Total execution time: 0.2357
DEBUG - 2018-03-14 15:40:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:40:32 --> Total execution time: 0.3992
DEBUG - 2018-03-14 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:40:41 --> Total execution time: 0.1130
DEBUG - 2018-03-14 15:40:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:40:47 --> Total execution time: 0.0813
DEBUG - 2018-03-14 15:40:49 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:40:49 --> Total execution time: 0.0907
DEBUG - 2018-03-14 15:41:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:41:22 --> Total execution time: 0.1067
DEBUG - 2018-03-14 15:41:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-14 21:41:27 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`detail_penjualan`, CONSTRAINT `faktur_penjualan` FOREIGN KEY (`faktur_penjualan`) REFERENCES `penjualan` (`faktur_penjualan`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `penjualan`
WHERE `faktur_penjualan` = 'FP00001'
DEBUG - 2018-03-14 21:41:27 --> DB Transaction Failure
DEBUG - 2018-03-14 15:41:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:41:27 --> Total execution time: 0.1004
DEBUG - 2018-03-14 15:41:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:41:34 --> Total execution time: 0.0932
DEBUG - 2018-03-14 15:41:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:41:37 --> Total execution time: 0.1466
DEBUG - 2018-03-14 15:41:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:41:47 --> Total execution time: 0.0756
DEBUG - 2018-03-14 15:41:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:41:52 --> Total execution time: 0.0894
DEBUG - 2018-03-14 15:41:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-14 21:41:57 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`detail_penjualan`, CONSTRAINT `faktur_penjualan` FOREIGN KEY (`faktur_penjualan`) REFERENCES `penjualan` (`faktur_penjualan`) ON UPDATE CASCADE) - Invalid query: DELETE FROM `penjualan`
WHERE `faktur_penjualan` = 'FP00001'
DEBUG - 2018-03-14 21:41:57 --> DB Transaction Failure
DEBUG - 2018-03-14 15:41:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:41:57 --> Total execution time: 0.0801
DEBUG - 2018-03-14 15:42:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:42:03 --> Total execution time: 0.1013
DEBUG - 2018-03-14 15:42:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:42:10 --> Total execution time: 0.1600
DEBUG - 2018-03-14 15:42:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:42:17 --> Total execution time: 0.0851
DEBUG - 2018-03-14 15:42:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:42:23 --> Total execution time: 0.0788
DEBUG - 2018-03-14 15:42:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:42:25 --> Total execution time: 0.0801
DEBUG - 2018-03-14 15:42:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 15:42:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:42:42 --> Total execution time: 0.0837
DEBUG - 2018-03-14 15:42:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:42:44 --> Total execution time: 0.1396
DEBUG - 2018-03-14 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:42:48 --> Total execution time: 0.1049
DEBUG - 2018-03-14 15:43:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:43:02 --> Total execution time: 0.1578
DEBUG - 2018-03-14 15:43:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:43:07 --> Total execution time: 0.0657
DEBUG - 2018-03-14 15:43:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:43:09 --> Total execution time: 0.1441
DEBUG - 2018-03-14 15:43:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:43:15 --> Total execution time: 0.1900
DEBUG - 2018-03-14 15:43:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:43:36 --> Total execution time: 0.0955
DEBUG - 2018-03-14 15:43:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-14 15:43:45 --> 404 Page Not Found: pendaftaran/Pendaftaran/update
DEBUG - 2018-03-14 15:43:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:43:48 --> Total execution time: 0.0738
DEBUG - 2018-03-14 15:43:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:43:55 --> Total execution time: 0.0740
DEBUG - 2018-03-14 15:43:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:43:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-14 15:43:58 --> 404 Page Not Found: pendaftaran/Pendaftaran/delete
DEBUG - 2018-03-14 15:44:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:44:02 --> Total execution time: 0.0904
DEBUG - 2018-03-14 15:48:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:48:26 --> Total execution time: 0.0689
DEBUG - 2018-03-14 15:48:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:48:28 --> Total execution time: 0.0592
DEBUG - 2018-03-14 15:48:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:48:50 --> Total execution time: 0.1210
DEBUG - 2018-03-14 15:49:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:49:28 --> Total execution time: 0.0829
DEBUG - 2018-03-14 15:50:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:50:07 --> Total execution time: 0.0653
DEBUG - 2018-03-14 15:50:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:50:14 --> Total execution time: 0.0841
DEBUG - 2018-03-14 15:50:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:50:16 --> Total execution time: 0.1156
DEBUG - 2018-03-14 15:51:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:51:24 --> Total execution time: 0.0838
DEBUG - 2018-03-14 15:52:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:52:29 --> Total execution time: 0.0712
DEBUG - 2018-03-14 15:53:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:53:05 --> Total execution time: 0.1024
DEBUG - 2018-03-14 15:53:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:53:33 --> Total execution time: 0.0642
DEBUG - 2018-03-14 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:54:51 --> Total execution time: 0.0874
DEBUG - 2018-03-14 15:55:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 15:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 15:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 21:55:07 --> Total execution time: 0.0668
DEBUG - 2018-03-14 16:55:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:55:56 --> Total execution time: 0.0656
DEBUG - 2018-03-14 16:55:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:55:58 --> Total execution time: 0.0713
DEBUG - 2018-03-14 16:56:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:00 --> Total execution time: 0.0648
DEBUG - 2018-03-14 16:56:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:01 --> Total execution time: 0.0670
DEBUG - 2018-03-14 16:56:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:02 --> Total execution time: 0.0644
DEBUG - 2018-03-14 16:56:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:03 --> Total execution time: 0.0893
DEBUG - 2018-03-14 16:56:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:05 --> Total execution time: 0.1690
DEBUG - 2018-03-14 16:56:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:06 --> Total execution time: 0.1428
DEBUG - 2018-03-14 16:56:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:07 --> Total execution time: 0.0933
DEBUG - 2018-03-14 16:56:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:12 --> Total execution time: 0.0821
DEBUG - 2018-03-14 16:56:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:38 --> Total execution time: 0.0764
DEBUG - 2018-03-14 16:56:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:39 --> Total execution time: 0.0747
DEBUG - 2018-03-14 16:56:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:40 --> Total execution time: 0.0662
DEBUG - 2018-03-14 16:56:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:41 --> Total execution time: 0.1169
DEBUG - 2018-03-14 16:56:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:45 --> Total execution time: 0.0593
DEBUG - 2018-03-14 16:56:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:47 --> Total execution time: 0.0633
DEBUG - 2018-03-14 16:56:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:50 --> Total execution time: 0.0599
DEBUG - 2018-03-14 16:56:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:52 --> Total execution time: 0.0967
DEBUG - 2018-03-14 16:56:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:53 --> Total execution time: 0.0762
DEBUG - 2018-03-14 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 16:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 22:56:54 --> Total execution time: 0.1150
DEBUG - 2018-03-14 17:01:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-14 23:01:31 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`klinik`.`pendaftaran`, CONSTRAINT `pasien_pendaftaran` FOREIGN KEY (`id_mst_pasien`) REFERENCES `mst_pasien` (`id_mst_pasien`) ON UPDATE CASCADE) - Invalid query: UPDATE `pendaftaran` SET `id_trx_pendaftaran` = 'P00005', `id_mst_pasien` = '', `id_mst_pegawai` = '1', `keterangan` = 'getde', `tgl` = '2018-03-14'
WHERE `id_trx_pendaftaran` = 'P00005'
DEBUG - 2018-03-14 23:01:31 --> DB Transaction Failure
DEBUG - 2018-03-14 17:01:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:01:31 --> Total execution time: 0.0839
DEBUG - 2018-03-14 17:02:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:02:52 --> Total execution time: 0.0987
DEBUG - 2018-03-14 17:02:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:02:55 --> Total execution time: 0.1217
DEBUG - 2018-03-14 17:03:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:03:01 --> Total execution time: 0.0875
DEBUG - 2018-03-14 17:03:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 17:03:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:03:07 --> Total execution time: 0.0821
DEBUG - 2018-03-14 17:03:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:03:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-14 17:03:31 --> 404 Page Not Found: pendaftaran/Pendaftaran/delete
DEBUG - 2018-03-14 17:03:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:03:33 --> Total execution time: 0.0643
DEBUG - 2018-03-14 17:13:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:13:04 --> Total execution time: 0.0683
DEBUG - 2018-03-14 17:13:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-03-14 23:13:12 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`klinik`.`trx_tindakan`, CONSTRAINT `pendaftaran_tindakan` FOREIGN KEY (`id_trx_pendaftaran`) REFERENCES `pendaftaran` (`id_trx_pendaftaran`)) - Invalid query: DELETE FROM `pendaftaran`
WHERE `id_trx_pendaftaran` = 'P00005'
DEBUG - 2018-03-14 23:13:12 --> DB Transaction Failure
DEBUG - 2018-03-14 17:13:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:13:12 --> Total execution time: 0.0812
DEBUG - 2018-03-14 17:13:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:13:17 --> Total execution time: 0.0904
DEBUG - 2018-03-14 17:13:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:13:19 --> Total execution time: 0.0844
DEBUG - 2018-03-14 17:13:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 17:13:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:13:23 --> Total execution time: 0.1168
DEBUG - 2018-03-14 17:13:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 17:13:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:13:29 --> Total execution time: 0.1267
DEBUG - 2018-03-14 17:14:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:14:27 --> Total execution time: 0.0990
DEBUG - 2018-03-14 17:16:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:16:10 --> Total execution time: 0.1361
DEBUG - 2018-03-14 17:16:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:16:33 --> Total execution time: 0.0982
DEBUG - 2018-03-14 17:16:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:16:47 --> Total execution time: 0.0851
DEBUG - 2018-03-14 17:17:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:17:20 --> Total execution time: 0.0776
DEBUG - 2018-03-14 17:17:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:17:22 --> Total execution time: 0.0815
DEBUG - 2018-03-14 17:18:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:18:06 --> Total execution time: 0.0759
DEBUG - 2018-03-14 17:19:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:19:07 --> Total execution time: 0.0733
DEBUG - 2018-03-14 17:45:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:45:13 --> Total execution time: 0.0889
DEBUG - 2018-03-14 17:45:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:45:19 --> Total execution time: 0.0911
DEBUG - 2018-03-14 17:45:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:45:23 --> Total execution time: 0.0676
DEBUG - 2018-03-14 17:46:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:46:39 --> Total execution time: 0.1139
DEBUG - 2018-03-14 17:46:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:46:43 --> Total execution time: 0.0679
DEBUG - 2018-03-14 17:46:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:46:52 --> Total execution time: 0.0821
DEBUG - 2018-03-14 17:48:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:48:27 --> Total execution time: 0.0922
DEBUG - 2018-03-14 17:50:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:50:07 --> Total execution time: 0.0963
DEBUG - 2018-03-14 17:50:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:50:09 --> Total execution time: 0.1189
DEBUG - 2018-03-14 17:50:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 17:50:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:50:17 --> Total execution time: 0.1083
DEBUG - 2018-03-14 17:50:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 17:50:25 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:50:25 --> Total execution time: 0.1046
DEBUG - 2018-03-14 17:50:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:50:29 --> Total execution time: 0.1344
DEBUG - 2018-03-14 17:50:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:50:31 --> Total execution time: 0.0785
DEBUG - 2018-03-14 17:50:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:50:38 --> Total execution time: 0.2013
DEBUG - 2018-03-14 17:50:46 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:50:46 --> Total execution time: 0.1228
DEBUG - 2018-03-14 17:51:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 17:51:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:51:10 --> Total execution time: 0.0729
DEBUG - 2018-03-14 17:51:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:51:13 --> Total execution time: 0.0927
DEBUG - 2018-03-14 17:51:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:51:20 --> Total execution time: 0.0887
DEBUG - 2018-03-14 17:51:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 17:51:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:51:24 --> Total execution time: 0.0728
DEBUG - 2018-03-14 17:51:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:51:26 --> Total execution time: 0.1136
DEBUG - 2018-03-14 17:51:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:51:36 --> Total execution time: 0.0944
DEBUG - 2018-03-14 17:51:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 17:51:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:51:39 --> Total execution time: 0.1075
DEBUG - 2018-03-14 17:51:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:51:50 --> Total execution time: 0.2908
DEBUG - 2018-03-14 17:51:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:51:52 --> Total execution time: 0.2059
DEBUG - 2018-03-14 17:51:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:51:55 --> Total execution time: 0.0816
DEBUG - 2018-03-14 17:51:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:51:59 --> Total execution time: 0.0800
DEBUG - 2018-03-14 17:52:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:52:01 --> Total execution time: 0.0823
DEBUG - 2018-03-14 17:52:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:52:02 --> Total execution time: 0.0842
DEBUG - 2018-03-14 17:52:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:52:08 --> Total execution time: 0.0878
DEBUG - 2018-03-14 17:52:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:52:09 --> Total execution time: 0.0882
DEBUG - 2018-03-14 17:52:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:52:14 --> Total execution time: 0.1034
DEBUG - 2018-03-14 17:53:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:53:13 --> Total execution time: 0.0863
DEBUG - 2018-03-14 17:53:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:53:15 --> Total execution time: 0.0698
DEBUG - 2018-03-14 17:53:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:53:18 --> Total execution time: 0.0753
DEBUG - 2018-03-14 17:53:49 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:53:49 --> Total execution time: 0.0860
DEBUG - 2018-03-14 17:53:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:53:53 --> Total execution time: 0.0679
DEBUG - 2018-03-14 17:54:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:54:20 --> Total execution time: 0.0837
DEBUG - 2018-03-14 17:54:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:54:21 --> Total execution time: 0.1031
DEBUG - 2018-03-14 17:54:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 17:54:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:54:28 --> Total execution time: 0.0746
DEBUG - 2018-03-14 17:54:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 17:54:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:54:30 --> Total execution time: 0.1175
DEBUG - 2018-03-14 17:54:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:54:33 --> Total execution time: 0.0956
DEBUG - 2018-03-14 17:54:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:54:35 --> Total execution time: 0.1187
DEBUG - 2018-03-14 17:54:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:54:38 --> Total execution time: 0.0800
DEBUG - 2018-03-14 17:54:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:54:45 --> Total execution time: 0.0729
DEBUG - 2018-03-14 17:54:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:54:47 --> Total execution time: 0.0839
DEBUG - 2018-03-14 17:54:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:54:53 --> Total execution time: 0.0701
DEBUG - 2018-03-14 17:55:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:55:01 --> Total execution time: 0.0733
DEBUG - 2018-03-14 17:55:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:55:03 --> Total execution time: 0.0747
DEBUG - 2018-03-14 17:55:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 17:55:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:55:15 --> Total execution time: 0.1155
DEBUG - 2018-03-14 17:55:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:55:17 --> Total execution time: 0.1029
DEBUG - 2018-03-14 17:55:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 17:55:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:55:20 --> Total execution time: 0.1199
DEBUG - 2018-03-14 17:55:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:55:23 --> Total execution time: 0.0754
DEBUG - 2018-03-14 17:55:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:55:24 --> Total execution time: 0.1153
DEBUG - 2018-03-14 17:55:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:55:28 --> Total execution time: 0.0837
DEBUG - 2018-03-14 17:56:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:56:31 --> Total execution time: 0.0926
DEBUG - 2018-03-14 17:56:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:56:34 --> Total execution time: 0.0634
DEBUG - 2018-03-14 17:57:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:57:01 --> Total execution time: 0.0927
DEBUG - 2018-03-14 17:57:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:57:17 --> Total execution time: 0.0991
DEBUG - 2018-03-14 17:57:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:57:19 --> Total execution time: 0.0672
DEBUG - 2018-03-14 17:57:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 17:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 17:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 23:57:22 --> Total execution time: 0.0717
DEBUG - 2018-03-14 18:01:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:01:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:02:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:02:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:02:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:02:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:02:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:12:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:13:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:13:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:13:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:13:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:23:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:24:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:24:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:24:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:31:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:31:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:31:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:31:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:35:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:41:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:44:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:46:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:47:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:47:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:47:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:48:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:48:57 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:49:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:49:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:50:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:50:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:50:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:50:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:50:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:51:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:54:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:55:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:57:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:57:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:58:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:59:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 18:59:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 18:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 18:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:00:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:00:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:01:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:02:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:02:29 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:02:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:02:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:05:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:07:37 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:08:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:08:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:54:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:54:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:54:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:54:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:56:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:56:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:56:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:57:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:58:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:58:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:58:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:58:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:58:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 19:58:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 19:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 19:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:00:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:00:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:00:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:00:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:00:49 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:01:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:02:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:02:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:02:12 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:04:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:04:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:04:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:04:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:04:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:04:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:05:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:05:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:05:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:05:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:05:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:05:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:05:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:05:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:06:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:06:07 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:06:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:06:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:06:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:06:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:06:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:06:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:06:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:06:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:06:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:06:59 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:07:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:07:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:07:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:07:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:07:14 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:07:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:07:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:07:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:07:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:08:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:08:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:08:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:08:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:08:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:09:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:09:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:10:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:10:19 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:10:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:10:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:10:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:11:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:11:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:11:04 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:11:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:11:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:11:49 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:11:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:11:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:11:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:12:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:12:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:12:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:12:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:12:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:12:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:12:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:12:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:12:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:12:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:12:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:12:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:12:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:12:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:12:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-14 20:14:16 --> UTF-8 Support Enabled
DEBUG - 2018-03-14 20:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-14 20:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
