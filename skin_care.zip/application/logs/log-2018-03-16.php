<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-16 16:57:26 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 16:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 16:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 16:57:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 16:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 16:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 22:57:28 --> Total execution time: 0.1261
DEBUG - 2018-03-16 16:57:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 16:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 16:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 16:57:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 16:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 16:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 22:57:39 --> Total execution time: 0.2182
DEBUG - 2018-03-16 16:57:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 16:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 16:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 22:57:43 --> Total execution time: 0.3151
DEBUG - 2018-03-16 16:57:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 16:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 16:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 22:57:48 --> Total execution time: 0.1062
DEBUG - 2018-03-16 16:57:50 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 16:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 16:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 22:57:50 --> Total execution time: 0.0451
DEBUG - 2018-03-16 16:57:55 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 16:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 16:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 22:57:56 --> Total execution time: 0.5708
DEBUG - 2018-03-16 17:47:41 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 17:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 17:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 23:47:41 --> Total execution time: 0.1368
DEBUG - 2018-03-16 17:47:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 17:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 17:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 23:47:45 --> Total execution time: 0.0823
DEBUG - 2018-03-16 17:47:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 17:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 17:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 23:47:48 --> Total execution time: 0.1198
DEBUG - 2018-03-16 17:50:18 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 17:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 17:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 23:50:19 --> Total execution time: 0.0452
DEBUG - 2018-03-16 17:50:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 17:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 17:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 23:50:22 --> Total execution time: 0.0545
DEBUG - 2018-03-16 17:50:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 17:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 17:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 23:50:23 --> Total execution time: 0.0988
DEBUG - 2018-03-16 17:50:28 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 17:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 17:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 23:50:28 --> Total execution time: 0.0421
DEBUG - 2018-03-16 17:50:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 17:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 17:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 23:50:31 --> Total execution time: 0.0593
DEBUG - 2018-03-16 17:50:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 17:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 17:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 23:50:32 --> Total execution time: 0.0515
DEBUG - 2018-03-16 17:56:10 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 17:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 17:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 23:56:10 --> Total execution time: 0.1763
DEBUG - 2018-03-16 17:56:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 17:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 17:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 23:56:13 --> Total execution time: 0.1301
DEBUG - 2018-03-16 17:56:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 17:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 17:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 23:56:15 --> Total execution time: 0.0492
DEBUG - 2018-03-16 17:56:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 17:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 17:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 23:56:17 --> Total execution time: 0.1767
DEBUG - 2018-03-16 18:02:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:02:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:03:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:03:20 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:05:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:05:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:05:47 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:12:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:12:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:12:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:12:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:13:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:13:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:15:30 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:15:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:15:36 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:16:21 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:16:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:16:24 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:16:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:17:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:17:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:18:00 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:18:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:18:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:18:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:18:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:18:17 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:18:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:18:51 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:19:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:19:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:19:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:19:08 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:19:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:19:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:20:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:20:38 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:20:42 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:20:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:20:45 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:20:48 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:20:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:20:53 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:20:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:20:58 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:21:01 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:21:03 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:21:09 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:21:13 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:21:15 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:21:44 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:21:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-16 18:21:44 --> 404 Page Not Found: gudang/Penjualan/print
DEBUG - 2018-03-16 18:21:46 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:21:56 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:22:11 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:51:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:51:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:51:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:51:34 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:51:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-16 18:51:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-16 18:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-16 18:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
