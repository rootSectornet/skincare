<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-17 00:02:54 --> Total execution time: 0.0688
ERROR - 2018-03-17 00:02:59 --> Severity: error --> Exception: Call to a member function row() on array E:\xampp\htdocs\skin_care\application\models\PemakaianObat_model.php 23
DEBUG - 2018-03-17 00:03:13 --> Total execution time: 0.0645
DEBUG - 2018-03-17 00:03:20 --> Total execution time: 0.0609
DEBUG - 2018-03-17 00:05:39 --> Total execution time: 0.0660
DEBUG - 2018-03-17 00:05:43 --> Total execution time: 0.1119
DEBUG - 2018-03-17 00:05:47 --> Total execution time: 0.0654
ERROR - 2018-03-17 00:12:43 --> Query error: Unknown column 'id_trx_tindakan' in 'where clause' - Invalid query: DELETE FROM `pemakaian_obat`
WHERE `id_trx_tindakan` = '7'
AND `id_pemakaian_obat` = '2'
DEBUG - 2018-03-17 00:12:43 --> DB Transaction Failure
DEBUG - 2018-03-17 00:12:43 --> Total execution time: 0.0792
ERROR - 2018-03-17 00:12:53 --> Query error: Unknown column 'id_trx_tindakan' in 'where clause' - Invalid query: DELETE FROM `pemakaian_obat`
WHERE `id_trx_tindakan` = '7'
AND `id_pemakaian_obat` = '2'
DEBUG - 2018-03-17 00:12:54 --> DB Transaction Failure
DEBUG - 2018-03-17 00:12:54 --> Total execution time: 0.0611
ERROR - 2018-03-17 00:13:38 --> Query error: Unknown column 'id_trx_tindakan' in 'where clause' - Invalid query: DELETE FROM `pemakaian_obat`
WHERE `id_trx_tindakan` = '7'
AND `id_pemakaian_obat` = '2'
DEBUG - 2018-03-17 00:13:38 --> DB Transaction Failure
DEBUG - 2018-03-17 00:13:38 --> Total execution time: 0.0971
DEBUG - 2018-03-17 00:15:30 --> Total execution time: 0.0590
ERROR - 2018-03-17 00:15:36 --> Query error: Unknown column 'id_trx_tindakan' in 'where clause' - Invalid query: DELETE FROM `pemakaian_obat`
WHERE `id_trx_tindakan` = '7'
AND `id_pemakaian_obat` = '2'
DEBUG - 2018-03-17 00:15:36 --> DB Transaction Failure
DEBUG - 2018-03-17 00:15:36 --> Total execution time: 0.0646
DEBUG - 2018-03-17 00:16:21 --> Total execution time: 0.0648
DEBUG - 2018-03-17 00:16:24 --> Total execution time: 0.0743
DEBUG - 2018-03-17 00:16:56 --> Total execution time: 0.0617
DEBUG - 2018-03-17 00:17:05 --> Total execution time: 0.0848
DEBUG - 2018-03-17 00:18:00 --> Total execution time: 0.0592
DEBUG - 2018-03-17 00:18:05 --> Total execution time: 0.1060
DEBUG - 2018-03-17 00:18:09 --> Total execution time: 0.0677
DEBUG - 2018-03-17 00:18:17 --> Total execution time: 0.0879
DEBUG - 2018-03-17 00:18:45 --> Total execution time: 0.0716
DEBUG - 2018-03-17 00:18:51 --> Total execution time: 0.0508
DEBUG - 2018-03-17 00:19:02 --> Total execution time: 0.0681
DEBUG - 2018-03-17 00:19:08 --> Total execution time: 0.0803
DEBUG - 2018-03-17 00:19:35 --> Total execution time: 0.0804
DEBUG - 2018-03-17 00:19:53 --> Total execution time: 0.1394
DEBUG - 2018-03-17 00:20:35 --> Total execution time: 0.0655
DEBUG - 2018-03-17 00:20:38 --> Total execution time: 0.0686
DEBUG - 2018-03-17 00:20:42 --> Total execution time: 0.0814
DEBUG - 2018-03-17 00:20:45 --> Total execution time: 0.0590
DEBUG - 2018-03-17 00:20:45 --> Total execution time: 0.0642
DEBUG - 2018-03-17 00:20:49 --> Total execution time: 0.0579
DEBUG - 2018-03-17 00:20:52 --> Total execution time: 0.0602
DEBUG - 2018-03-17 00:20:53 --> Total execution time: 0.0472
DEBUG - 2018-03-17 00:20:54 --> Total execution time: 0.0683
DEBUG - 2018-03-17 00:20:58 --> Total execution time: 0.0482
DEBUG - 2018-03-17 00:21:01 --> Total execution time: 0.0566
DEBUG - 2018-03-17 00:21:03 --> Total execution time: 0.0687
DEBUG - 2018-03-17 00:21:09 --> Total execution time: 0.0681
DEBUG - 2018-03-17 00:21:13 --> Total execution time: 0.0463
DEBUG - 2018-03-17 00:21:15 --> Total execution time: 0.0504
DEBUG - 2018-03-17 00:21:46 --> Total execution time: 0.0840
DEBUG - 2018-03-17 00:21:56 --> Total execution time: 0.0613
DEBUG - 2018-03-17 00:22:11 --> Total execution time: 0.0511
DEBUG - 2018-03-17 00:51:31 --> Total execution time: 0.1457
DEBUG - 2018-03-17 00:51:34 --> Total execution time: 0.0895
DEBUG - 2018-03-17 00:51:39 --> Total execution time: 0.1161
DEBUG - 2018-03-17 00:51:40 --> Total execution time: 0.1644
DEBUG - 2018-03-17 07:26:02 --> UTF-8 Support Enabled
DEBUG - 2018-03-17 07:26:02 --> No URI present. Default controller set.
DEBUG - 2018-03-17 07:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-17 07:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-17 13:26:03 --> Total execution time: 0.4800
