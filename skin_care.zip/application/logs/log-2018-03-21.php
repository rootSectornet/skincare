<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-21 16:06:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 16:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 16:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-21 16:06:35 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 16:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 16:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-21 22:06:35 --> Total execution time: 0.1037
DEBUG - 2018-03-21 16:06:39 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 16:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 16:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-21 16:06:40 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 16:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 16:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-21 22:06:40 --> Total execution time: 0.0920
DEBUG - 2018-03-21 16:06:43 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 16:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 16:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-21 22:06:43 --> Total execution time: 0.0815
DEBUG - 2018-03-21 16:07:05 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 16:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 16:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-21 22:07:05 --> Total execution time: 0.0801
DEBUG - 2018-03-21 16:07:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 16:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 16:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-21 22:07:31 --> Total execution time: 0.0528
DEBUG - 2018-03-21 16:15:52 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 16:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 16:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-21 22:15:52 --> Total execution time: 0.2094
DEBUG - 2018-03-21 16:15:54 --> UTF-8 Support Enabled
DEBUG - 2018-03-21 16:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-21 16:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-21 22:15:54 --> Total execution time: 0.0841
INFO - 2018-03-21 16:16:21 --> Config Class Initialized
INFO - 2018-03-21 16:16:21 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:16:21 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:16:21 --> Utf8 Class Initialized
INFO - 2018-03-21 16:16:21 --> URI Class Initialized
INFO - 2018-03-21 16:16:21 --> Router Class Initialized
INFO - 2018-03-21 16:16:21 --> Output Class Initialized
INFO - 2018-03-21 16:16:21 --> Security Class Initialized
DEBUG - 2018-03-21 16:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:16:21 --> Input Class Initialized
INFO - 2018-03-21 16:16:21 --> Language Class Initialized
INFO - 2018-03-21 16:16:21 --> Loader Class Initialized
INFO - 2018-03-21 16:16:21 --> Helper loaded: url_helper
INFO - 2018-03-21 16:16:21 --> Helper loaded: form_helper
INFO - 2018-03-21 16:16:21 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:16:21 --> Controller Class Initialized
INFO - 2018-03-21 16:16:21 --> Model Class Initialized
INFO - 2018-03-21 16:16:21 --> Model Class Initialized
INFO - 2018-03-21 16:16:21 --> Model Class Initialized
INFO - 2018-03-21 16:16:21 --> Model Class Initialized
INFO - 2018-03-21 16:16:21 --> Model Class Initialized
INFO - 2018-03-21 16:16:21 --> Model Class Initialized
INFO - 2018-03-21 16:16:21 --> Model Class Initialized
INFO - 2018-03-21 16:16:21 --> Model Class Initialized
INFO - 2018-03-21 16:16:21 --> Model Class Initialized
INFO - 2018-03-21 16:16:21 --> Model Class Initialized
INFO - 2018-03-21 16:16:21 --> Helper loaded: date_helper
INFO - 2018-03-21 16:16:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:16:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:16:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:16:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/update.php
INFO - 2018-03-21 22:16:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:16:21 --> Final output sent to browser
DEBUG - 2018-03-21 22:16:21 --> Total execution time: 0.1248
INFO - 2018-03-21 16:17:01 --> Config Class Initialized
INFO - 2018-03-21 16:17:01 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:17:01 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:17:01 --> Utf8 Class Initialized
INFO - 2018-03-21 16:17:01 --> URI Class Initialized
INFO - 2018-03-21 16:17:01 --> Router Class Initialized
INFO - 2018-03-21 16:17:01 --> Output Class Initialized
INFO - 2018-03-21 16:17:01 --> Security Class Initialized
DEBUG - 2018-03-21 16:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:17:01 --> Input Class Initialized
INFO - 2018-03-21 16:17:01 --> Language Class Initialized
INFO - 2018-03-21 16:17:01 --> Loader Class Initialized
INFO - 2018-03-21 16:17:01 --> Helper loaded: url_helper
INFO - 2018-03-21 16:17:01 --> Helper loaded: form_helper
INFO - 2018-03-21 16:17:01 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:17:01 --> Controller Class Initialized
INFO - 2018-03-21 16:17:01 --> Model Class Initialized
INFO - 2018-03-21 16:17:01 --> Model Class Initialized
INFO - 2018-03-21 16:17:01 --> Model Class Initialized
INFO - 2018-03-21 16:17:01 --> Model Class Initialized
INFO - 2018-03-21 16:17:01 --> Model Class Initialized
INFO - 2018-03-21 16:17:01 --> Model Class Initialized
INFO - 2018-03-21 16:17:01 --> Model Class Initialized
INFO - 2018-03-21 16:17:01 --> Model Class Initialized
INFO - 2018-03-21 16:17:01 --> Model Class Initialized
INFO - 2018-03-21 16:17:01 --> Model Class Initialized
INFO - 2018-03-21 16:17:01 --> Helper loaded: date_helper
INFO - 2018-03-21 16:17:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:17:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:17:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:17:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/update.php
INFO - 2018-03-21 22:17:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:17:01 --> Final output sent to browser
DEBUG - 2018-03-21 22:17:01 --> Total execution time: 0.1080
INFO - 2018-03-21 16:17:20 --> Config Class Initialized
INFO - 2018-03-21 16:17:20 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:17:20 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:17:20 --> Utf8 Class Initialized
INFO - 2018-03-21 16:17:20 --> URI Class Initialized
INFO - 2018-03-21 16:17:20 --> Router Class Initialized
INFO - 2018-03-21 16:17:20 --> Output Class Initialized
INFO - 2018-03-21 16:17:20 --> Security Class Initialized
DEBUG - 2018-03-21 16:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:17:20 --> Input Class Initialized
INFO - 2018-03-21 16:17:20 --> Language Class Initialized
INFO - 2018-03-21 16:17:20 --> Loader Class Initialized
INFO - 2018-03-21 16:17:20 --> Helper loaded: url_helper
INFO - 2018-03-21 16:17:20 --> Helper loaded: form_helper
INFO - 2018-03-21 16:17:20 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:17:20 --> Controller Class Initialized
INFO - 2018-03-21 16:17:20 --> Model Class Initialized
INFO - 2018-03-21 16:17:20 --> Model Class Initialized
INFO - 2018-03-21 16:17:20 --> Model Class Initialized
INFO - 2018-03-21 16:17:20 --> Model Class Initialized
INFO - 2018-03-21 16:17:20 --> Model Class Initialized
INFO - 2018-03-21 16:17:20 --> Model Class Initialized
INFO - 2018-03-21 16:17:20 --> Model Class Initialized
INFO - 2018-03-21 16:17:20 --> Model Class Initialized
INFO - 2018-03-21 16:17:20 --> Model Class Initialized
INFO - 2018-03-21 16:17:20 --> Model Class Initialized
INFO - 2018-03-21 16:17:20 --> Helper loaded: date_helper
INFO - 2018-03-21 16:17:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:17:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:17:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:17:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/update.php
INFO - 2018-03-21 22:17:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:17:20 --> Final output sent to browser
DEBUG - 2018-03-21 22:17:20 --> Total execution time: 0.0664
INFO - 2018-03-21 16:18:22 --> Config Class Initialized
INFO - 2018-03-21 16:18:22 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:18:22 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:18:22 --> Utf8 Class Initialized
INFO - 2018-03-21 16:18:22 --> URI Class Initialized
INFO - 2018-03-21 16:18:22 --> Router Class Initialized
INFO - 2018-03-21 16:18:22 --> Output Class Initialized
INFO - 2018-03-21 16:18:22 --> Security Class Initialized
DEBUG - 2018-03-21 16:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:18:22 --> Input Class Initialized
INFO - 2018-03-21 16:18:22 --> Language Class Initialized
INFO - 2018-03-21 16:18:22 --> Loader Class Initialized
INFO - 2018-03-21 16:18:22 --> Helper loaded: url_helper
INFO - 2018-03-21 16:18:22 --> Helper loaded: form_helper
INFO - 2018-03-21 16:18:22 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:18:22 --> Controller Class Initialized
INFO - 2018-03-21 16:18:22 --> Model Class Initialized
INFO - 2018-03-21 16:18:22 --> Model Class Initialized
INFO - 2018-03-21 16:18:22 --> Model Class Initialized
INFO - 2018-03-21 16:18:22 --> Model Class Initialized
INFO - 2018-03-21 16:18:22 --> Model Class Initialized
INFO - 2018-03-21 16:18:22 --> Model Class Initialized
INFO - 2018-03-21 16:18:22 --> Model Class Initialized
INFO - 2018-03-21 16:18:22 --> Model Class Initialized
INFO - 2018-03-21 16:18:22 --> Model Class Initialized
INFO - 2018-03-21 16:18:22 --> Model Class Initialized
INFO - 2018-03-21 16:18:22 --> Helper loaded: date_helper
INFO - 2018-03-21 16:18:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:18:22 --> Final output sent to browser
DEBUG - 2018-03-21 22:18:22 --> Total execution time: 0.0583
INFO - 2018-03-21 16:18:35 --> Config Class Initialized
INFO - 2018-03-21 16:18:35 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:18:35 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:18:35 --> Utf8 Class Initialized
INFO - 2018-03-21 16:18:35 --> URI Class Initialized
INFO - 2018-03-21 16:18:35 --> Router Class Initialized
INFO - 2018-03-21 16:18:35 --> Output Class Initialized
INFO - 2018-03-21 16:18:35 --> Security Class Initialized
DEBUG - 2018-03-21 16:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:18:35 --> Input Class Initialized
INFO - 2018-03-21 16:18:35 --> Language Class Initialized
INFO - 2018-03-21 16:18:35 --> Loader Class Initialized
INFO - 2018-03-21 16:18:35 --> Helper loaded: url_helper
INFO - 2018-03-21 16:18:35 --> Helper loaded: form_helper
INFO - 2018-03-21 16:18:35 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:18:35 --> Controller Class Initialized
INFO - 2018-03-21 16:18:35 --> Model Class Initialized
INFO - 2018-03-21 16:18:35 --> Model Class Initialized
INFO - 2018-03-21 16:18:35 --> Model Class Initialized
INFO - 2018-03-21 16:18:35 --> Model Class Initialized
INFO - 2018-03-21 16:18:35 --> Model Class Initialized
INFO - 2018-03-21 16:18:35 --> Model Class Initialized
INFO - 2018-03-21 16:18:35 --> Model Class Initialized
INFO - 2018-03-21 16:18:35 --> Model Class Initialized
INFO - 2018-03-21 16:18:35 --> Model Class Initialized
INFO - 2018-03-21 16:18:35 --> Model Class Initialized
INFO - 2018-03-21 16:18:35 --> Helper loaded: date_helper
INFO - 2018-03-21 16:18:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:18:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:18:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:18:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/update.php
INFO - 2018-03-21 22:18:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:18:35 --> Final output sent to browser
DEBUG - 2018-03-21 22:18:35 --> Total execution time: 0.0703
INFO - 2018-03-21 16:19:33 --> Config Class Initialized
INFO - 2018-03-21 16:19:33 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:19:33 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:19:33 --> Utf8 Class Initialized
INFO - 2018-03-21 16:19:33 --> URI Class Initialized
INFO - 2018-03-21 16:19:33 --> Router Class Initialized
INFO - 2018-03-21 16:19:33 --> Output Class Initialized
INFO - 2018-03-21 16:19:33 --> Security Class Initialized
DEBUG - 2018-03-21 16:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:19:33 --> Input Class Initialized
INFO - 2018-03-21 16:19:33 --> Language Class Initialized
INFO - 2018-03-21 16:19:33 --> Loader Class Initialized
INFO - 2018-03-21 16:19:33 --> Helper loaded: url_helper
INFO - 2018-03-21 16:19:33 --> Helper loaded: form_helper
INFO - 2018-03-21 16:19:33 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:19:33 --> Controller Class Initialized
INFO - 2018-03-21 16:19:33 --> Model Class Initialized
INFO - 2018-03-21 16:19:33 --> Model Class Initialized
INFO - 2018-03-21 16:19:33 --> Model Class Initialized
INFO - 2018-03-21 16:19:33 --> Model Class Initialized
INFO - 2018-03-21 16:19:33 --> Model Class Initialized
INFO - 2018-03-21 16:19:33 --> Model Class Initialized
INFO - 2018-03-21 16:19:33 --> Model Class Initialized
INFO - 2018-03-21 16:19:33 --> Model Class Initialized
INFO - 2018-03-21 16:19:33 --> Model Class Initialized
INFO - 2018-03-21 16:19:33 --> Model Class Initialized
INFO - 2018-03-21 16:19:33 --> Helper loaded: date_helper
INFO - 2018-03-21 16:19:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:19:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:19:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:19:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/update.php
INFO - 2018-03-21 22:19:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:19:33 --> Final output sent to browser
DEBUG - 2018-03-21 22:19:33 --> Total execution time: 0.0795
INFO - 2018-03-21 16:19:47 --> Config Class Initialized
INFO - 2018-03-21 16:19:47 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:19:47 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:19:47 --> Utf8 Class Initialized
INFO - 2018-03-21 16:19:47 --> URI Class Initialized
INFO - 2018-03-21 16:19:47 --> Router Class Initialized
INFO - 2018-03-21 16:19:47 --> Output Class Initialized
INFO - 2018-03-21 16:19:47 --> Security Class Initialized
DEBUG - 2018-03-21 16:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:19:47 --> Input Class Initialized
INFO - 2018-03-21 16:19:47 --> Language Class Initialized
INFO - 2018-03-21 16:19:47 --> Loader Class Initialized
INFO - 2018-03-21 16:19:47 --> Helper loaded: url_helper
INFO - 2018-03-21 16:19:47 --> Helper loaded: form_helper
INFO - 2018-03-21 16:19:47 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:19:47 --> Controller Class Initialized
INFO - 2018-03-21 16:19:47 --> Model Class Initialized
INFO - 2018-03-21 16:19:47 --> Model Class Initialized
INFO - 2018-03-21 16:19:47 --> Model Class Initialized
INFO - 2018-03-21 16:19:47 --> Model Class Initialized
INFO - 2018-03-21 16:19:47 --> Model Class Initialized
INFO - 2018-03-21 16:19:47 --> Model Class Initialized
INFO - 2018-03-21 16:19:47 --> Model Class Initialized
INFO - 2018-03-21 16:19:47 --> Model Class Initialized
INFO - 2018-03-21 16:19:47 --> Model Class Initialized
INFO - 2018-03-21 16:19:47 --> Model Class Initialized
INFO - 2018-03-21 16:19:47 --> Helper loaded: date_helper
INFO - 2018-03-21 16:19:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:19:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:19:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:19:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/update.php
INFO - 2018-03-21 22:19:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:19:47 --> Final output sent to browser
DEBUG - 2018-03-21 22:19:47 --> Total execution time: 0.1111
INFO - 2018-03-21 16:20:22 --> Config Class Initialized
INFO - 2018-03-21 16:20:22 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:20:22 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:20:22 --> Utf8 Class Initialized
INFO - 2018-03-21 16:20:22 --> URI Class Initialized
INFO - 2018-03-21 16:20:22 --> Router Class Initialized
INFO - 2018-03-21 16:20:22 --> Output Class Initialized
INFO - 2018-03-21 16:20:22 --> Security Class Initialized
DEBUG - 2018-03-21 16:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:20:22 --> Input Class Initialized
INFO - 2018-03-21 16:20:22 --> Language Class Initialized
INFO - 2018-03-21 16:20:22 --> Loader Class Initialized
INFO - 2018-03-21 16:20:22 --> Helper loaded: url_helper
INFO - 2018-03-21 16:20:22 --> Helper loaded: form_helper
INFO - 2018-03-21 16:20:22 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:20:22 --> Controller Class Initialized
INFO - 2018-03-21 16:20:22 --> Model Class Initialized
INFO - 2018-03-21 16:20:22 --> Model Class Initialized
INFO - 2018-03-21 16:20:22 --> Model Class Initialized
INFO - 2018-03-21 16:20:22 --> Model Class Initialized
INFO - 2018-03-21 16:20:22 --> Model Class Initialized
INFO - 2018-03-21 16:20:22 --> Model Class Initialized
INFO - 2018-03-21 16:20:22 --> Model Class Initialized
INFO - 2018-03-21 16:20:22 --> Model Class Initialized
INFO - 2018-03-21 16:20:22 --> Model Class Initialized
INFO - 2018-03-21 16:20:22 --> Model Class Initialized
INFO - 2018-03-21 16:20:22 --> Helper loaded: date_helper
INFO - 2018-03-21 16:20:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:20:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:20:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:20:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/update.php
INFO - 2018-03-21 22:20:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:20:22 --> Final output sent to browser
DEBUG - 2018-03-21 22:20:22 --> Total execution time: 0.0943
INFO - 2018-03-21 16:20:45 --> Config Class Initialized
INFO - 2018-03-21 16:20:45 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:20:45 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:20:45 --> Utf8 Class Initialized
INFO - 2018-03-21 16:20:45 --> URI Class Initialized
INFO - 2018-03-21 16:20:45 --> Router Class Initialized
INFO - 2018-03-21 16:20:45 --> Output Class Initialized
INFO - 2018-03-21 16:20:45 --> Security Class Initialized
DEBUG - 2018-03-21 16:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:20:45 --> Input Class Initialized
INFO - 2018-03-21 16:20:45 --> Language Class Initialized
INFO - 2018-03-21 16:20:45 --> Loader Class Initialized
INFO - 2018-03-21 16:20:45 --> Helper loaded: url_helper
INFO - 2018-03-21 16:20:45 --> Helper loaded: form_helper
INFO - 2018-03-21 16:20:45 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:20:45 --> Controller Class Initialized
INFO - 2018-03-21 16:20:45 --> Model Class Initialized
INFO - 2018-03-21 16:20:45 --> Model Class Initialized
INFO - 2018-03-21 16:20:45 --> Model Class Initialized
INFO - 2018-03-21 16:20:45 --> Model Class Initialized
INFO - 2018-03-21 16:20:45 --> Model Class Initialized
INFO - 2018-03-21 16:20:45 --> Model Class Initialized
INFO - 2018-03-21 16:20:45 --> Model Class Initialized
INFO - 2018-03-21 16:20:45 --> Model Class Initialized
INFO - 2018-03-21 16:20:45 --> Model Class Initialized
INFO - 2018-03-21 16:20:45 --> Model Class Initialized
INFO - 2018-03-21 16:20:45 --> Helper loaded: date_helper
INFO - 2018-03-21 16:20:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:20:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:20:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:20:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/update.php
INFO - 2018-03-21 22:20:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:20:45 --> Final output sent to browser
DEBUG - 2018-03-21 22:20:45 --> Total execution time: 0.1124
INFO - 2018-03-21 16:21:53 --> Config Class Initialized
INFO - 2018-03-21 16:21:53 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:21:53 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:21:53 --> Utf8 Class Initialized
INFO - 2018-03-21 16:21:53 --> URI Class Initialized
INFO - 2018-03-21 16:21:53 --> Router Class Initialized
INFO - 2018-03-21 16:21:53 --> Output Class Initialized
INFO - 2018-03-21 16:21:53 --> Security Class Initialized
DEBUG - 2018-03-21 16:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:21:53 --> Input Class Initialized
INFO - 2018-03-21 16:21:53 --> Language Class Initialized
INFO - 2018-03-21 16:21:53 --> Loader Class Initialized
INFO - 2018-03-21 16:21:53 --> Helper loaded: url_helper
INFO - 2018-03-21 16:21:53 --> Helper loaded: form_helper
INFO - 2018-03-21 16:21:53 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:21:53 --> Controller Class Initialized
INFO - 2018-03-21 16:21:53 --> Model Class Initialized
INFO - 2018-03-21 16:21:53 --> Model Class Initialized
INFO - 2018-03-21 16:21:53 --> Model Class Initialized
INFO - 2018-03-21 16:21:53 --> Model Class Initialized
INFO - 2018-03-21 16:21:53 --> Model Class Initialized
INFO - 2018-03-21 16:21:53 --> Model Class Initialized
INFO - 2018-03-21 16:21:53 --> Model Class Initialized
INFO - 2018-03-21 16:21:53 --> Model Class Initialized
INFO - 2018-03-21 16:21:53 --> Model Class Initialized
INFO - 2018-03-21 16:21:53 --> Model Class Initialized
INFO - 2018-03-21 16:21:53 --> Helper loaded: date_helper
INFO - 2018-03-21 16:21:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:21:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:21:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:21:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/update.php
INFO - 2018-03-21 22:21:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:21:53 --> Final output sent to browser
DEBUG - 2018-03-21 22:21:53 --> Total execution time: 0.1358
INFO - 2018-03-21 16:22:31 --> Config Class Initialized
INFO - 2018-03-21 16:22:31 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:22:31 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:22:31 --> Utf8 Class Initialized
INFO - 2018-03-21 16:22:31 --> URI Class Initialized
INFO - 2018-03-21 16:22:31 --> Router Class Initialized
INFO - 2018-03-21 16:22:31 --> Output Class Initialized
INFO - 2018-03-21 16:22:31 --> Security Class Initialized
DEBUG - 2018-03-21 16:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:22:31 --> Input Class Initialized
INFO - 2018-03-21 16:22:31 --> Language Class Initialized
INFO - 2018-03-21 16:22:31 --> Loader Class Initialized
INFO - 2018-03-21 16:22:31 --> Helper loaded: url_helper
INFO - 2018-03-21 16:22:31 --> Helper loaded: form_helper
INFO - 2018-03-21 16:22:31 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:22:31 --> Controller Class Initialized
INFO - 2018-03-21 16:22:31 --> Model Class Initialized
INFO - 2018-03-21 16:22:31 --> Model Class Initialized
INFO - 2018-03-21 16:22:31 --> Model Class Initialized
INFO - 2018-03-21 16:22:31 --> Model Class Initialized
INFO - 2018-03-21 16:22:31 --> Model Class Initialized
INFO - 2018-03-21 16:22:31 --> Model Class Initialized
INFO - 2018-03-21 16:22:31 --> Model Class Initialized
INFO - 2018-03-21 16:22:31 --> Model Class Initialized
INFO - 2018-03-21 16:22:31 --> Model Class Initialized
INFO - 2018-03-21 16:22:31 --> Model Class Initialized
INFO - 2018-03-21 16:22:31 --> Helper loaded: date_helper
INFO - 2018-03-21 16:22:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:22:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:22:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:22:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/update.php
INFO - 2018-03-21 22:22:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:22:31 --> Final output sent to browser
DEBUG - 2018-03-21 22:22:31 --> Total execution time: 0.0873
INFO - 2018-03-21 16:22:45 --> Config Class Initialized
INFO - 2018-03-21 16:22:45 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:22:45 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:22:45 --> Utf8 Class Initialized
INFO - 2018-03-21 16:22:45 --> URI Class Initialized
INFO - 2018-03-21 16:22:45 --> Router Class Initialized
INFO - 2018-03-21 16:22:45 --> Output Class Initialized
INFO - 2018-03-21 16:22:45 --> Security Class Initialized
DEBUG - 2018-03-21 16:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:22:45 --> Input Class Initialized
INFO - 2018-03-21 16:22:45 --> Language Class Initialized
INFO - 2018-03-21 16:22:45 --> Loader Class Initialized
INFO - 2018-03-21 16:22:45 --> Helper loaded: url_helper
INFO - 2018-03-21 16:22:45 --> Helper loaded: form_helper
INFO - 2018-03-21 16:22:45 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:22:45 --> Controller Class Initialized
INFO - 2018-03-21 16:22:45 --> Model Class Initialized
INFO - 2018-03-21 16:22:45 --> Model Class Initialized
INFO - 2018-03-21 16:22:45 --> Model Class Initialized
INFO - 2018-03-21 16:22:45 --> Model Class Initialized
INFO - 2018-03-21 16:22:45 --> Model Class Initialized
INFO - 2018-03-21 16:22:45 --> Model Class Initialized
INFO - 2018-03-21 16:22:45 --> Model Class Initialized
INFO - 2018-03-21 16:22:45 --> Model Class Initialized
INFO - 2018-03-21 16:22:45 --> Model Class Initialized
INFO - 2018-03-21 16:22:45 --> Model Class Initialized
INFO - 2018-03-21 16:22:45 --> Helper loaded: date_helper
INFO - 2018-03-21 16:22:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:22:45 --> Final output sent to browser
DEBUG - 2018-03-21 22:22:45 --> Total execution time: 0.0808
INFO - 2018-03-21 16:22:46 --> Config Class Initialized
INFO - 2018-03-21 16:22:46 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:22:46 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:22:46 --> Utf8 Class Initialized
INFO - 2018-03-21 16:22:46 --> URI Class Initialized
INFO - 2018-03-21 16:22:46 --> Router Class Initialized
INFO - 2018-03-21 16:22:46 --> Output Class Initialized
INFO - 2018-03-21 16:22:46 --> Security Class Initialized
DEBUG - 2018-03-21 16:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:22:46 --> Input Class Initialized
INFO - 2018-03-21 16:22:46 --> Language Class Initialized
INFO - 2018-03-21 16:22:46 --> Loader Class Initialized
INFO - 2018-03-21 16:22:46 --> Helper loaded: url_helper
INFO - 2018-03-21 16:22:46 --> Helper loaded: form_helper
INFO - 2018-03-21 16:22:46 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:22:46 --> Controller Class Initialized
INFO - 2018-03-21 16:22:46 --> Model Class Initialized
INFO - 2018-03-21 16:22:46 --> Model Class Initialized
INFO - 2018-03-21 16:22:46 --> Model Class Initialized
INFO - 2018-03-21 16:22:46 --> Model Class Initialized
INFO - 2018-03-21 16:22:46 --> Model Class Initialized
INFO - 2018-03-21 16:22:46 --> Model Class Initialized
INFO - 2018-03-21 16:22:46 --> Model Class Initialized
INFO - 2018-03-21 16:22:46 --> Model Class Initialized
INFO - 2018-03-21 16:22:46 --> Model Class Initialized
INFO - 2018-03-21 16:22:46 --> Model Class Initialized
INFO - 2018-03-21 16:22:46 --> Helper loaded: date_helper
INFO - 2018-03-21 16:22:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:22:46 --> Final output sent to browser
DEBUG - 2018-03-21 22:22:46 --> Total execution time: 0.0851
INFO - 2018-03-21 16:22:48 --> Config Class Initialized
INFO - 2018-03-21 16:22:48 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:22:48 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:22:48 --> Utf8 Class Initialized
INFO - 2018-03-21 16:22:48 --> URI Class Initialized
INFO - 2018-03-21 16:22:48 --> Router Class Initialized
INFO - 2018-03-21 16:22:48 --> Output Class Initialized
INFO - 2018-03-21 16:22:48 --> Security Class Initialized
DEBUG - 2018-03-21 16:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:22:48 --> Input Class Initialized
INFO - 2018-03-21 16:22:48 --> Language Class Initialized
INFO - 2018-03-21 16:22:48 --> Loader Class Initialized
INFO - 2018-03-21 16:22:48 --> Helper loaded: url_helper
INFO - 2018-03-21 16:22:48 --> Helper loaded: form_helper
INFO - 2018-03-21 16:22:48 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:22:48 --> Controller Class Initialized
INFO - 2018-03-21 16:22:48 --> Model Class Initialized
INFO - 2018-03-21 16:22:48 --> Model Class Initialized
INFO - 2018-03-21 16:22:48 --> Model Class Initialized
INFO - 2018-03-21 16:22:48 --> Model Class Initialized
INFO - 2018-03-21 16:22:48 --> Model Class Initialized
INFO - 2018-03-21 16:22:48 --> Model Class Initialized
INFO - 2018-03-21 16:22:48 --> Model Class Initialized
INFO - 2018-03-21 16:22:48 --> Model Class Initialized
INFO - 2018-03-21 16:22:48 --> Model Class Initialized
INFO - 2018-03-21 16:22:48 --> Model Class Initialized
INFO - 2018-03-21 16:22:48 --> Helper loaded: date_helper
INFO - 2018-03-21 16:22:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:22:48 --> Final output sent to browser
DEBUG - 2018-03-21 22:22:48 --> Total execution time: 0.0543
INFO - 2018-03-21 16:24:38 --> Config Class Initialized
INFO - 2018-03-21 16:24:38 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:24:38 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:24:38 --> Utf8 Class Initialized
INFO - 2018-03-21 16:24:38 --> URI Class Initialized
INFO - 2018-03-21 16:24:38 --> Router Class Initialized
INFO - 2018-03-21 16:24:38 --> Output Class Initialized
INFO - 2018-03-21 16:24:38 --> Security Class Initialized
DEBUG - 2018-03-21 16:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:24:38 --> Input Class Initialized
INFO - 2018-03-21 16:24:38 --> Language Class Initialized
INFO - 2018-03-21 16:24:38 --> Loader Class Initialized
INFO - 2018-03-21 16:24:38 --> Helper loaded: url_helper
INFO - 2018-03-21 16:24:38 --> Helper loaded: form_helper
INFO - 2018-03-21 16:24:38 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:24:38 --> Controller Class Initialized
INFO - 2018-03-21 16:24:38 --> Model Class Initialized
INFO - 2018-03-21 16:24:38 --> Model Class Initialized
INFO - 2018-03-21 16:24:38 --> Model Class Initialized
INFO - 2018-03-21 16:24:38 --> Model Class Initialized
INFO - 2018-03-21 16:24:38 --> Model Class Initialized
INFO - 2018-03-21 16:24:38 --> Model Class Initialized
INFO - 2018-03-21 16:24:38 --> Model Class Initialized
INFO - 2018-03-21 16:24:38 --> Model Class Initialized
INFO - 2018-03-21 16:24:38 --> Model Class Initialized
INFO - 2018-03-21 16:24:38 --> Model Class Initialized
INFO - 2018-03-21 16:24:38 --> Helper loaded: date_helper
INFO - 2018-03-21 16:24:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:24:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:24:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:24:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/update.php
INFO - 2018-03-21 22:24:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:24:38 --> Final output sent to browser
DEBUG - 2018-03-21 22:24:38 --> Total execution time: 0.1373
INFO - 2018-03-21 16:25:03 --> Config Class Initialized
INFO - 2018-03-21 16:25:03 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:25:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:25:03 --> Utf8 Class Initialized
INFO - 2018-03-21 16:25:03 --> URI Class Initialized
INFO - 2018-03-21 16:25:03 --> Router Class Initialized
INFO - 2018-03-21 16:25:03 --> Output Class Initialized
INFO - 2018-03-21 16:25:03 --> Security Class Initialized
DEBUG - 2018-03-21 16:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:25:03 --> Input Class Initialized
INFO - 2018-03-21 16:25:03 --> Language Class Initialized
INFO - 2018-03-21 16:25:03 --> Loader Class Initialized
INFO - 2018-03-21 16:25:03 --> Helper loaded: url_helper
INFO - 2018-03-21 16:25:03 --> Helper loaded: form_helper
INFO - 2018-03-21 16:25:03 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:25:03 --> Controller Class Initialized
INFO - 2018-03-21 16:25:03 --> Model Class Initialized
INFO - 2018-03-21 16:25:03 --> Model Class Initialized
INFO - 2018-03-21 16:25:03 --> Model Class Initialized
INFO - 2018-03-21 16:25:03 --> Model Class Initialized
INFO - 2018-03-21 16:25:03 --> Model Class Initialized
INFO - 2018-03-21 16:25:03 --> Model Class Initialized
INFO - 2018-03-21 16:25:03 --> Model Class Initialized
INFO - 2018-03-21 16:25:03 --> Model Class Initialized
INFO - 2018-03-21 16:25:03 --> Model Class Initialized
INFO - 2018-03-21 16:25:03 --> Model Class Initialized
INFO - 2018-03-21 16:25:03 --> Model Class Initialized
INFO - 2018-03-21 16:25:03 --> Model Class Initialized
INFO - 2018-03-21 16:25:03 --> Model Class Initialized
INFO - 2018-03-21 16:25:03 --> Helper loaded: date_helper
INFO - 2018-03-21 16:25:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:25:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:25:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:25:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-21 22:25:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:25:03 --> Final output sent to browser
DEBUG - 2018-03-21 22:25:03 --> Total execution time: 0.2465
INFO - 2018-03-21 16:25:04 --> Config Class Initialized
INFO - 2018-03-21 16:25:04 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:25:04 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:25:04 --> Utf8 Class Initialized
INFO - 2018-03-21 16:25:04 --> URI Class Initialized
INFO - 2018-03-21 16:25:04 --> Router Class Initialized
INFO - 2018-03-21 16:25:04 --> Output Class Initialized
INFO - 2018-03-21 16:25:04 --> Security Class Initialized
DEBUG - 2018-03-21 16:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:25:04 --> Input Class Initialized
INFO - 2018-03-21 16:25:04 --> Language Class Initialized
INFO - 2018-03-21 16:25:04 --> Loader Class Initialized
INFO - 2018-03-21 16:25:04 --> Helper loaded: url_helper
INFO - 2018-03-21 16:25:04 --> Helper loaded: form_helper
INFO - 2018-03-21 16:25:04 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:25:04 --> Controller Class Initialized
INFO - 2018-03-21 16:25:04 --> Model Class Initialized
INFO - 2018-03-21 16:25:04 --> Model Class Initialized
INFO - 2018-03-21 16:25:04 --> Model Class Initialized
INFO - 2018-03-21 16:25:04 --> Model Class Initialized
INFO - 2018-03-21 16:25:04 --> Model Class Initialized
INFO - 2018-03-21 16:25:04 --> Model Class Initialized
INFO - 2018-03-21 16:25:04 --> Model Class Initialized
INFO - 2018-03-21 16:25:04 --> Model Class Initialized
INFO - 2018-03-21 16:25:04 --> Model Class Initialized
INFO - 2018-03-21 16:25:04 --> Model Class Initialized
INFO - 2018-03-21 16:25:04 --> Model Class Initialized
INFO - 2018-03-21 16:25:04 --> Model Class Initialized
INFO - 2018-03-21 16:25:04 --> Model Class Initialized
INFO - 2018-03-21 16:25:04 --> Helper loaded: date_helper
INFO - 2018-03-21 16:25:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:25:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:25:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:25:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/create.php
INFO - 2018-03-21 22:25:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:25:04 --> Final output sent to browser
DEBUG - 2018-03-21 22:25:04 --> Total execution time: 0.1638
INFO - 2018-03-21 16:25:08 --> Config Class Initialized
INFO - 2018-03-21 16:25:08 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:25:08 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:25:08 --> Utf8 Class Initialized
INFO - 2018-03-21 16:25:08 --> URI Class Initialized
INFO - 2018-03-21 16:25:08 --> Router Class Initialized
INFO - 2018-03-21 16:25:08 --> Output Class Initialized
INFO - 2018-03-21 16:25:08 --> Security Class Initialized
DEBUG - 2018-03-21 16:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:25:08 --> Input Class Initialized
INFO - 2018-03-21 16:25:08 --> Language Class Initialized
INFO - 2018-03-21 16:25:08 --> Loader Class Initialized
INFO - 2018-03-21 16:25:08 --> Helper loaded: url_helper
INFO - 2018-03-21 16:25:08 --> Helper loaded: form_helper
INFO - 2018-03-21 16:25:08 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:25:08 --> Controller Class Initialized
INFO - 2018-03-21 16:25:08 --> Model Class Initialized
INFO - 2018-03-21 16:25:08 --> Model Class Initialized
INFO - 2018-03-21 16:25:08 --> Model Class Initialized
INFO - 2018-03-21 16:25:08 --> Model Class Initialized
INFO - 2018-03-21 16:25:08 --> Model Class Initialized
INFO - 2018-03-21 16:25:08 --> Model Class Initialized
INFO - 2018-03-21 16:25:08 --> Model Class Initialized
INFO - 2018-03-21 16:25:08 --> Model Class Initialized
INFO - 2018-03-21 16:25:08 --> Model Class Initialized
INFO - 2018-03-21 16:25:08 --> Model Class Initialized
INFO - 2018-03-21 16:25:08 --> Model Class Initialized
INFO - 2018-03-21 16:25:08 --> Model Class Initialized
INFO - 2018-03-21 16:25:08 --> Model Class Initialized
INFO - 2018-03-21 16:25:08 --> Helper loaded: date_helper
INFO - 2018-03-21 16:25:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:25:08 --> Final output sent to browser
DEBUG - 2018-03-21 22:25:08 --> Total execution time: 0.0895
INFO - 2018-03-21 16:25:42 --> Config Class Initialized
INFO - 2018-03-21 16:25:42 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:25:42 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:25:42 --> Utf8 Class Initialized
INFO - 2018-03-21 16:25:42 --> URI Class Initialized
INFO - 2018-03-21 16:25:42 --> Router Class Initialized
INFO - 2018-03-21 16:25:42 --> Output Class Initialized
INFO - 2018-03-21 16:25:42 --> Security Class Initialized
DEBUG - 2018-03-21 16:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:25:42 --> Input Class Initialized
INFO - 2018-03-21 16:25:42 --> Language Class Initialized
INFO - 2018-03-21 16:25:42 --> Loader Class Initialized
INFO - 2018-03-21 16:25:42 --> Helper loaded: url_helper
INFO - 2018-03-21 16:25:42 --> Helper loaded: form_helper
INFO - 2018-03-21 16:25:42 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:25:42 --> Controller Class Initialized
INFO - 2018-03-21 16:25:42 --> Model Class Initialized
INFO - 2018-03-21 16:25:42 --> Model Class Initialized
INFO - 2018-03-21 16:25:42 --> Model Class Initialized
INFO - 2018-03-21 16:25:42 --> Model Class Initialized
INFO - 2018-03-21 16:25:42 --> Model Class Initialized
INFO - 2018-03-21 16:25:42 --> Model Class Initialized
INFO - 2018-03-21 16:25:42 --> Model Class Initialized
INFO - 2018-03-21 16:25:42 --> Model Class Initialized
INFO - 2018-03-21 16:25:42 --> Model Class Initialized
INFO - 2018-03-21 16:25:42 --> Model Class Initialized
INFO - 2018-03-21 16:25:42 --> Helper loaded: date_helper
INFO - 2018-03-21 16:25:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:25:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:25:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:25:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-21 22:25:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:25:42 --> Final output sent to browser
DEBUG - 2018-03-21 22:25:42 --> Total execution time: 0.1172
INFO - 2018-03-21 16:25:44 --> Config Class Initialized
INFO - 2018-03-21 16:25:44 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:25:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:25:44 --> Utf8 Class Initialized
INFO - 2018-03-21 16:25:44 --> URI Class Initialized
INFO - 2018-03-21 16:25:44 --> Router Class Initialized
INFO - 2018-03-21 16:25:44 --> Output Class Initialized
INFO - 2018-03-21 16:25:44 --> Security Class Initialized
DEBUG - 2018-03-21 16:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:25:44 --> Input Class Initialized
INFO - 2018-03-21 16:25:44 --> Language Class Initialized
INFO - 2018-03-21 16:25:44 --> Loader Class Initialized
INFO - 2018-03-21 16:25:44 --> Helper loaded: url_helper
INFO - 2018-03-21 16:25:44 --> Helper loaded: form_helper
INFO - 2018-03-21 16:25:44 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:25:44 --> Controller Class Initialized
INFO - 2018-03-21 16:25:44 --> Model Class Initialized
INFO - 2018-03-21 16:25:44 --> Model Class Initialized
INFO - 2018-03-21 16:25:44 --> Model Class Initialized
INFO - 2018-03-21 16:25:44 --> Model Class Initialized
INFO - 2018-03-21 16:25:44 --> Model Class Initialized
INFO - 2018-03-21 16:25:44 --> Model Class Initialized
INFO - 2018-03-21 16:25:44 --> Model Class Initialized
INFO - 2018-03-21 16:25:44 --> Model Class Initialized
INFO - 2018-03-21 16:25:44 --> Model Class Initialized
INFO - 2018-03-21 16:25:44 --> Model Class Initialized
INFO - 2018-03-21 16:25:44 --> Helper loaded: date_helper
INFO - 2018-03-21 16:25:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:25:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:25:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:25:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/create.php
INFO - 2018-03-21 22:25:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:25:44 --> Final output sent to browser
DEBUG - 2018-03-21 22:25:44 --> Total execution time: 0.1188
INFO - 2018-03-21 16:25:49 --> Config Class Initialized
INFO - 2018-03-21 16:25:49 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:25:49 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:25:49 --> Utf8 Class Initialized
INFO - 2018-03-21 16:25:49 --> URI Class Initialized
INFO - 2018-03-21 16:25:49 --> Router Class Initialized
INFO - 2018-03-21 16:25:49 --> Output Class Initialized
INFO - 2018-03-21 16:25:49 --> Security Class Initialized
DEBUG - 2018-03-21 16:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:25:49 --> Input Class Initialized
INFO - 2018-03-21 16:25:49 --> Language Class Initialized
INFO - 2018-03-21 16:25:49 --> Loader Class Initialized
INFO - 2018-03-21 16:25:49 --> Helper loaded: url_helper
INFO - 2018-03-21 16:25:49 --> Helper loaded: form_helper
INFO - 2018-03-21 16:25:49 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:25:49 --> Controller Class Initialized
INFO - 2018-03-21 16:25:49 --> Model Class Initialized
INFO - 2018-03-21 16:25:49 --> Model Class Initialized
INFO - 2018-03-21 16:25:49 --> Model Class Initialized
INFO - 2018-03-21 16:25:49 --> Model Class Initialized
INFO - 2018-03-21 16:25:49 --> Model Class Initialized
INFO - 2018-03-21 16:25:49 --> Model Class Initialized
INFO - 2018-03-21 16:25:49 --> Model Class Initialized
INFO - 2018-03-21 16:25:49 --> Model Class Initialized
INFO - 2018-03-21 16:25:49 --> Model Class Initialized
INFO - 2018-03-21 16:25:49 --> Model Class Initialized
INFO - 2018-03-21 16:25:49 --> Helper loaded: date_helper
INFO - 2018-03-21 16:25:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:25:49 --> Final output sent to browser
DEBUG - 2018-03-21 22:25:49 --> Total execution time: 0.1238
INFO - 2018-03-21 16:26:51 --> Config Class Initialized
INFO - 2018-03-21 16:26:51 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:26:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:26:51 --> Utf8 Class Initialized
INFO - 2018-03-21 16:26:51 --> URI Class Initialized
INFO - 2018-03-21 16:26:51 --> Router Class Initialized
INFO - 2018-03-21 16:26:51 --> Output Class Initialized
INFO - 2018-03-21 16:26:51 --> Security Class Initialized
DEBUG - 2018-03-21 16:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:26:51 --> Input Class Initialized
INFO - 2018-03-21 16:26:51 --> Language Class Initialized
INFO - 2018-03-21 16:26:51 --> Loader Class Initialized
INFO - 2018-03-21 16:26:51 --> Helper loaded: url_helper
INFO - 2018-03-21 16:26:51 --> Helper loaded: form_helper
INFO - 2018-03-21 16:26:51 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:26:51 --> Controller Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Helper loaded: date_helper
INFO - 2018-03-21 16:26:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:26:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:26:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:26:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-21 22:26:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:26:51 --> Final output sent to browser
DEBUG - 2018-03-21 22:26:51 --> Total execution time: 0.1184
INFO - 2018-03-21 16:26:51 --> Config Class Initialized
INFO - 2018-03-21 16:26:51 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:26:51 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:26:51 --> Utf8 Class Initialized
INFO - 2018-03-21 16:26:51 --> URI Class Initialized
INFO - 2018-03-21 16:26:51 --> Router Class Initialized
INFO - 2018-03-21 16:26:51 --> Output Class Initialized
INFO - 2018-03-21 16:26:51 --> Security Class Initialized
DEBUG - 2018-03-21 16:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:26:51 --> Input Class Initialized
INFO - 2018-03-21 16:26:51 --> Language Class Initialized
INFO - 2018-03-21 16:26:51 --> Loader Class Initialized
INFO - 2018-03-21 16:26:51 --> Helper loaded: url_helper
INFO - 2018-03-21 16:26:51 --> Helper loaded: form_helper
INFO - 2018-03-21 16:26:51 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:26:51 --> Controller Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:51 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Helper loaded: date_helper
INFO - 2018-03-21 16:26:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:26:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:26:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:26:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/create.php
INFO - 2018-03-21 22:26:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:26:52 --> Final output sent to browser
DEBUG - 2018-03-21 22:26:52 --> Total execution time: 0.1144
INFO - 2018-03-21 16:26:52 --> Config Class Initialized
INFO - 2018-03-21 16:26:52 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:26:52 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:26:52 --> Utf8 Class Initialized
INFO - 2018-03-21 16:26:52 --> URI Class Initialized
INFO - 2018-03-21 16:26:52 --> Router Class Initialized
INFO - 2018-03-21 16:26:52 --> Output Class Initialized
INFO - 2018-03-21 16:26:52 --> Security Class Initialized
DEBUG - 2018-03-21 16:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:26:52 --> Input Class Initialized
INFO - 2018-03-21 16:26:52 --> Language Class Initialized
INFO - 2018-03-21 16:26:52 --> Loader Class Initialized
INFO - 2018-03-21 16:26:52 --> Helper loaded: url_helper
INFO - 2018-03-21 16:26:52 --> Helper loaded: form_helper
INFO - 2018-03-21 16:26:52 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:26:52 --> Controller Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Model Class Initialized
INFO - 2018-03-21 16:26:52 --> Helper loaded: date_helper
INFO - 2018-03-21 16:26:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:26:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:26:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:26:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-21 22:26:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:26:52 --> Final output sent to browser
DEBUG - 2018-03-21 22:26:52 --> Total execution time: 0.1075
INFO - 2018-03-21 16:26:53 --> Config Class Initialized
INFO - 2018-03-21 16:26:53 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:26:53 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:26:53 --> Utf8 Class Initialized
INFO - 2018-03-21 16:26:53 --> URI Class Initialized
INFO - 2018-03-21 16:26:53 --> Router Class Initialized
INFO - 2018-03-21 16:26:53 --> Output Class Initialized
INFO - 2018-03-21 16:26:53 --> Security Class Initialized
DEBUG - 2018-03-21 16:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:26:53 --> Input Class Initialized
INFO - 2018-03-21 16:26:53 --> Language Class Initialized
INFO - 2018-03-21 16:26:53 --> Loader Class Initialized
INFO - 2018-03-21 16:26:53 --> Helper loaded: url_helper
INFO - 2018-03-21 16:26:53 --> Helper loaded: form_helper
INFO - 2018-03-21 16:26:53 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:26:53 --> Controller Class Initialized
INFO - 2018-03-21 16:26:53 --> Model Class Initialized
INFO - 2018-03-21 16:26:53 --> Model Class Initialized
INFO - 2018-03-21 16:26:53 --> Model Class Initialized
INFO - 2018-03-21 16:26:53 --> Model Class Initialized
INFO - 2018-03-21 16:26:53 --> Model Class Initialized
INFO - 2018-03-21 16:26:53 --> Model Class Initialized
INFO - 2018-03-21 16:26:53 --> Model Class Initialized
INFO - 2018-03-21 16:26:53 --> Model Class Initialized
INFO - 2018-03-21 16:26:53 --> Model Class Initialized
INFO - 2018-03-21 16:26:53 --> Model Class Initialized
INFO - 2018-03-21 16:26:53 --> Helper loaded: date_helper
INFO - 2018-03-21 16:26:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:26:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:26:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:26:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/update.php
INFO - 2018-03-21 22:26:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:26:53 --> Final output sent to browser
DEBUG - 2018-03-21 22:26:53 --> Total execution time: 0.1151
INFO - 2018-03-21 16:27:44 --> Config Class Initialized
INFO - 2018-03-21 16:27:44 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:27:44 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:27:44 --> Utf8 Class Initialized
INFO - 2018-03-21 16:27:44 --> URI Class Initialized
INFO - 2018-03-21 16:27:44 --> Router Class Initialized
INFO - 2018-03-21 16:27:45 --> Output Class Initialized
INFO - 2018-03-21 16:27:45 --> Security Class Initialized
DEBUG - 2018-03-21 16:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:27:45 --> Input Class Initialized
INFO - 2018-03-21 16:27:45 --> Language Class Initialized
INFO - 2018-03-21 16:27:45 --> Loader Class Initialized
INFO - 2018-03-21 16:27:45 --> Helper loaded: url_helper
INFO - 2018-03-21 16:27:45 --> Helper loaded: form_helper
INFO - 2018-03-21 16:27:45 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:27:45 --> Controller Class Initialized
INFO - 2018-03-21 16:27:45 --> Model Class Initialized
INFO - 2018-03-21 16:27:45 --> Model Class Initialized
INFO - 2018-03-21 16:27:45 --> Model Class Initialized
INFO - 2018-03-21 16:27:45 --> Model Class Initialized
INFO - 2018-03-21 16:27:45 --> Model Class Initialized
INFO - 2018-03-21 16:27:45 --> Model Class Initialized
INFO - 2018-03-21 16:27:45 --> Model Class Initialized
INFO - 2018-03-21 16:27:45 --> Model Class Initialized
INFO - 2018-03-21 16:27:45 --> Model Class Initialized
INFO - 2018-03-21 16:27:45 --> Model Class Initialized
INFO - 2018-03-21 16:27:45 --> Helper loaded: date_helper
INFO - 2018-03-21 16:27:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:27:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:27:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:27:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/update.php
INFO - 2018-03-21 22:27:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:27:45 --> Final output sent to browser
DEBUG - 2018-03-21 22:27:45 --> Total execution time: 0.0747
INFO - 2018-03-21 16:28:25 --> Config Class Initialized
INFO - 2018-03-21 16:28:25 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:28:25 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:28:25 --> Utf8 Class Initialized
INFO - 2018-03-21 16:28:25 --> URI Class Initialized
INFO - 2018-03-21 16:28:25 --> Router Class Initialized
INFO - 2018-03-21 16:28:25 --> Output Class Initialized
INFO - 2018-03-21 16:28:25 --> Security Class Initialized
DEBUG - 2018-03-21 16:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:28:25 --> Input Class Initialized
INFO - 2018-03-21 16:28:25 --> Language Class Initialized
INFO - 2018-03-21 16:28:25 --> Loader Class Initialized
INFO - 2018-03-21 16:28:25 --> Helper loaded: url_helper
INFO - 2018-03-21 16:28:25 --> Helper loaded: form_helper
INFO - 2018-03-21 16:28:25 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:28:25 --> Controller Class Initialized
INFO - 2018-03-21 16:28:25 --> Model Class Initialized
INFO - 2018-03-21 16:28:25 --> Model Class Initialized
INFO - 2018-03-21 16:28:25 --> Model Class Initialized
INFO - 2018-03-21 16:28:25 --> Model Class Initialized
INFO - 2018-03-21 16:28:25 --> Model Class Initialized
INFO - 2018-03-21 16:28:25 --> Model Class Initialized
INFO - 2018-03-21 16:28:25 --> Model Class Initialized
INFO - 2018-03-21 16:28:25 --> Model Class Initialized
INFO - 2018-03-21 16:28:25 --> Model Class Initialized
INFO - 2018-03-21 16:28:25 --> Model Class Initialized
INFO - 2018-03-21 16:28:25 --> Helper loaded: date_helper
INFO - 2018-03-21 16:28:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:28:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:28:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:28:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/update.php
INFO - 2018-03-21 22:28:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:28:25 --> Final output sent to browser
DEBUG - 2018-03-21 22:28:25 --> Total execution time: 0.0897
INFO - 2018-03-21 16:29:10 --> Config Class Initialized
INFO - 2018-03-21 16:29:10 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:29:10 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:29:10 --> Utf8 Class Initialized
INFO - 2018-03-21 16:29:11 --> URI Class Initialized
INFO - 2018-03-21 16:29:11 --> Router Class Initialized
INFO - 2018-03-21 16:29:11 --> Output Class Initialized
INFO - 2018-03-21 16:29:11 --> Security Class Initialized
DEBUG - 2018-03-21 16:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:29:11 --> Input Class Initialized
INFO - 2018-03-21 16:29:11 --> Language Class Initialized
INFO - 2018-03-21 16:29:11 --> Loader Class Initialized
INFO - 2018-03-21 16:29:11 --> Helper loaded: url_helper
INFO - 2018-03-21 16:29:11 --> Helper loaded: form_helper
INFO - 2018-03-21 16:29:11 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:29:11 --> Controller Class Initialized
INFO - 2018-03-21 16:29:11 --> Model Class Initialized
INFO - 2018-03-21 16:29:11 --> Model Class Initialized
INFO - 2018-03-21 16:29:11 --> Model Class Initialized
INFO - 2018-03-21 16:29:11 --> Model Class Initialized
INFO - 2018-03-21 16:29:11 --> Model Class Initialized
INFO - 2018-03-21 16:29:11 --> Model Class Initialized
INFO - 2018-03-21 16:29:11 --> Model Class Initialized
INFO - 2018-03-21 16:29:11 --> Model Class Initialized
INFO - 2018-03-21 16:29:11 --> Model Class Initialized
INFO - 2018-03-21 16:29:11 --> Model Class Initialized
INFO - 2018-03-21 16:29:11 --> Helper loaded: date_helper
INFO - 2018-03-21 16:29:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:29:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:29:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:29:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/update.php
INFO - 2018-03-21 22:29:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:29:11 --> Final output sent to browser
DEBUG - 2018-03-21 22:29:11 --> Total execution time: 0.1111
INFO - 2018-03-21 16:29:15 --> Config Class Initialized
INFO - 2018-03-21 16:29:15 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:29:15 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:29:15 --> Utf8 Class Initialized
INFO - 2018-03-21 16:29:15 --> URI Class Initialized
INFO - 2018-03-21 16:29:15 --> Router Class Initialized
INFO - 2018-03-21 16:29:15 --> Output Class Initialized
INFO - 2018-03-21 16:29:15 --> Security Class Initialized
DEBUG - 2018-03-21 16:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:29:15 --> Input Class Initialized
INFO - 2018-03-21 16:29:15 --> Language Class Initialized
INFO - 2018-03-21 16:29:15 --> Loader Class Initialized
INFO - 2018-03-21 16:29:15 --> Helper loaded: url_helper
INFO - 2018-03-21 16:29:15 --> Helper loaded: form_helper
INFO - 2018-03-21 16:29:15 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:29:15 --> Controller Class Initialized
INFO - 2018-03-21 16:29:15 --> Model Class Initialized
INFO - 2018-03-21 16:29:15 --> Model Class Initialized
INFO - 2018-03-21 16:29:15 --> Model Class Initialized
INFO - 2018-03-21 16:29:15 --> Model Class Initialized
INFO - 2018-03-21 16:29:15 --> Model Class Initialized
INFO - 2018-03-21 16:29:15 --> Model Class Initialized
INFO - 2018-03-21 16:29:15 --> Model Class Initialized
INFO - 2018-03-21 16:29:15 --> Model Class Initialized
INFO - 2018-03-21 16:29:15 --> Model Class Initialized
INFO - 2018-03-21 16:29:15 --> Model Class Initialized
INFO - 2018-03-21 16:29:15 --> Helper loaded: date_helper
INFO - 2018-03-21 16:29:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:29:15 --> Final output sent to browser
DEBUG - 2018-03-21 22:29:15 --> Total execution time: 0.0770
INFO - 2018-03-21 16:29:32 --> Config Class Initialized
INFO - 2018-03-21 16:29:32 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:29:32 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:29:32 --> Utf8 Class Initialized
INFO - 2018-03-21 16:29:32 --> URI Class Initialized
INFO - 2018-03-21 16:29:32 --> Router Class Initialized
INFO - 2018-03-21 16:29:32 --> Output Class Initialized
INFO - 2018-03-21 16:29:32 --> Security Class Initialized
DEBUG - 2018-03-21 16:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:29:32 --> Input Class Initialized
INFO - 2018-03-21 16:29:32 --> Language Class Initialized
INFO - 2018-03-21 16:29:32 --> Loader Class Initialized
INFO - 2018-03-21 16:29:32 --> Helper loaded: url_helper
INFO - 2018-03-21 16:29:32 --> Helper loaded: form_helper
INFO - 2018-03-21 16:29:32 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:29:32 --> Controller Class Initialized
INFO - 2018-03-21 16:29:32 --> Model Class Initialized
INFO - 2018-03-21 16:29:32 --> Model Class Initialized
INFO - 2018-03-21 16:29:32 --> Model Class Initialized
INFO - 2018-03-21 16:29:32 --> Model Class Initialized
INFO - 2018-03-21 16:29:32 --> Model Class Initialized
INFO - 2018-03-21 16:29:32 --> Model Class Initialized
INFO - 2018-03-21 16:29:32 --> Model Class Initialized
INFO - 2018-03-21 16:29:32 --> Model Class Initialized
INFO - 2018-03-21 16:29:32 --> Model Class Initialized
INFO - 2018-03-21 16:29:32 --> Model Class Initialized
INFO - 2018-03-21 16:29:32 --> Helper loaded: date_helper
INFO - 2018-03-21 16:29:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:29:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:29:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:29:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-21 22:29:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:29:32 --> Final output sent to browser
DEBUG - 2018-03-21 22:29:32 --> Total execution time: 0.0923
INFO - 2018-03-21 16:33:03 --> Config Class Initialized
INFO - 2018-03-21 16:33:03 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:33:03 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:33:03 --> Utf8 Class Initialized
INFO - 2018-03-21 16:33:03 --> URI Class Initialized
INFO - 2018-03-21 16:33:03 --> Router Class Initialized
INFO - 2018-03-21 16:33:03 --> Output Class Initialized
INFO - 2018-03-21 16:33:03 --> Security Class Initialized
DEBUG - 2018-03-21 16:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:33:03 --> Input Class Initialized
INFO - 2018-03-21 16:33:03 --> Language Class Initialized
INFO - 2018-03-21 16:33:03 --> Loader Class Initialized
INFO - 2018-03-21 16:33:03 --> Helper loaded: url_helper
INFO - 2018-03-21 16:33:03 --> Helper loaded: form_helper
INFO - 2018-03-21 16:33:03 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:33:03 --> Controller Class Initialized
INFO - 2018-03-21 16:33:03 --> Model Class Initialized
INFO - 2018-03-21 16:33:03 --> Model Class Initialized
INFO - 2018-03-21 16:33:03 --> Model Class Initialized
INFO - 2018-03-21 16:33:03 --> Model Class Initialized
INFO - 2018-03-21 16:33:03 --> Model Class Initialized
INFO - 2018-03-21 16:33:03 --> Model Class Initialized
INFO - 2018-03-21 16:33:03 --> Model Class Initialized
INFO - 2018-03-21 16:33:03 --> Model Class Initialized
INFO - 2018-03-21 16:33:03 --> Model Class Initialized
INFO - 2018-03-21 16:33:03 --> Model Class Initialized
INFO - 2018-03-21 16:33:03 --> Helper loaded: date_helper
INFO - 2018-03-21 16:33:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:33:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:33:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:33:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-21 22:33:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:33:03 --> Final output sent to browser
DEBUG - 2018-03-21 22:33:03 --> Total execution time: 0.1230
INFO - 2018-03-21 16:33:04 --> Config Class Initialized
INFO - 2018-03-21 16:33:04 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:33:04 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:33:04 --> Utf8 Class Initialized
INFO - 2018-03-21 16:33:04 --> URI Class Initialized
INFO - 2018-03-21 16:33:04 --> Router Class Initialized
INFO - 2018-03-21 16:33:04 --> Output Class Initialized
INFO - 2018-03-21 16:33:04 --> Security Class Initialized
DEBUG - 2018-03-21 16:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:33:04 --> Input Class Initialized
INFO - 2018-03-21 16:33:04 --> Language Class Initialized
INFO - 2018-03-21 16:33:04 --> Loader Class Initialized
INFO - 2018-03-21 16:33:04 --> Helper loaded: url_helper
INFO - 2018-03-21 16:33:04 --> Helper loaded: form_helper
INFO - 2018-03-21 16:33:04 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:33:04 --> Controller Class Initialized
INFO - 2018-03-21 16:33:04 --> Model Class Initialized
INFO - 2018-03-21 16:33:04 --> Model Class Initialized
INFO - 2018-03-21 16:33:04 --> Model Class Initialized
INFO - 2018-03-21 16:33:04 --> Model Class Initialized
INFO - 2018-03-21 16:33:04 --> Model Class Initialized
INFO - 2018-03-21 16:33:04 --> Model Class Initialized
INFO - 2018-03-21 16:33:04 --> Model Class Initialized
INFO - 2018-03-21 16:33:04 --> Model Class Initialized
INFO - 2018-03-21 16:33:04 --> Model Class Initialized
INFO - 2018-03-21 16:33:04 --> Model Class Initialized
INFO - 2018-03-21 16:33:04 --> Helper loaded: date_helper
INFO - 2018-03-21 16:33:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:33:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:33:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:33:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/create.php
INFO - 2018-03-21 22:33:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:33:04 --> Final output sent to browser
DEBUG - 2018-03-21 22:33:04 --> Total execution time: 0.0767
INFO - 2018-03-21 16:33:07 --> Config Class Initialized
INFO - 2018-03-21 16:33:07 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:33:07 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:33:07 --> Utf8 Class Initialized
INFO - 2018-03-21 16:33:07 --> URI Class Initialized
INFO - 2018-03-21 16:33:07 --> Router Class Initialized
INFO - 2018-03-21 16:33:07 --> Output Class Initialized
INFO - 2018-03-21 16:33:07 --> Security Class Initialized
DEBUG - 2018-03-21 16:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:33:07 --> Input Class Initialized
INFO - 2018-03-21 16:33:07 --> Language Class Initialized
INFO - 2018-03-21 16:33:07 --> Loader Class Initialized
INFO - 2018-03-21 16:33:07 --> Helper loaded: url_helper
INFO - 2018-03-21 16:33:07 --> Helper loaded: form_helper
INFO - 2018-03-21 16:33:07 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:33:07 --> Controller Class Initialized
INFO - 2018-03-21 16:33:07 --> Model Class Initialized
INFO - 2018-03-21 16:33:07 --> Model Class Initialized
INFO - 2018-03-21 16:33:07 --> Model Class Initialized
INFO - 2018-03-21 16:33:07 --> Model Class Initialized
INFO - 2018-03-21 16:33:07 --> Model Class Initialized
INFO - 2018-03-21 16:33:07 --> Model Class Initialized
INFO - 2018-03-21 16:33:07 --> Model Class Initialized
INFO - 2018-03-21 16:33:07 --> Model Class Initialized
INFO - 2018-03-21 16:33:07 --> Model Class Initialized
INFO - 2018-03-21 16:33:07 --> Model Class Initialized
INFO - 2018-03-21 16:33:07 --> Helper loaded: date_helper
INFO - 2018-03-21 16:33:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:33:08 --> Final output sent to browser
DEBUG - 2018-03-21 22:33:08 --> Total execution time: 0.1235
INFO - 2018-03-21 16:33:52 --> Config Class Initialized
INFO - 2018-03-21 16:33:52 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:33:52 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:33:52 --> Utf8 Class Initialized
INFO - 2018-03-21 16:33:52 --> URI Class Initialized
INFO - 2018-03-21 16:33:52 --> Router Class Initialized
INFO - 2018-03-21 16:33:52 --> Output Class Initialized
INFO - 2018-03-21 16:33:52 --> Security Class Initialized
DEBUG - 2018-03-21 16:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:33:52 --> Input Class Initialized
INFO - 2018-03-21 16:33:52 --> Language Class Initialized
INFO - 2018-03-21 16:33:52 --> Loader Class Initialized
INFO - 2018-03-21 16:33:52 --> Helper loaded: url_helper
INFO - 2018-03-21 16:33:52 --> Helper loaded: form_helper
INFO - 2018-03-21 16:33:52 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:33:52 --> Controller Class Initialized
INFO - 2018-03-21 16:33:52 --> Model Class Initialized
INFO - 2018-03-21 16:33:52 --> Model Class Initialized
INFO - 2018-03-21 16:33:52 --> Model Class Initialized
INFO - 2018-03-21 16:33:52 --> Model Class Initialized
INFO - 2018-03-21 16:33:52 --> Model Class Initialized
INFO - 2018-03-21 16:33:52 --> Model Class Initialized
INFO - 2018-03-21 16:33:52 --> Model Class Initialized
INFO - 2018-03-21 16:33:52 --> Model Class Initialized
INFO - 2018-03-21 16:33:52 --> Model Class Initialized
INFO - 2018-03-21 16:33:52 --> Model Class Initialized
INFO - 2018-03-21 16:33:52 --> Helper loaded: date_helper
INFO - 2018-03-21 16:33:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:33:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:33:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:33:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-21 22:33:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:33:52 --> Final output sent to browser
DEBUG - 2018-03-21 22:33:52 --> Total execution time: 0.1119
INFO - 2018-03-21 16:33:54 --> Config Class Initialized
INFO - 2018-03-21 16:33:54 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:33:54 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:33:54 --> Utf8 Class Initialized
INFO - 2018-03-21 16:33:54 --> URI Class Initialized
INFO - 2018-03-21 16:33:54 --> Router Class Initialized
INFO - 2018-03-21 16:33:54 --> Output Class Initialized
INFO - 2018-03-21 16:33:54 --> Security Class Initialized
DEBUG - 2018-03-21 16:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:33:54 --> Input Class Initialized
INFO - 2018-03-21 16:33:54 --> Language Class Initialized
INFO - 2018-03-21 16:33:54 --> Loader Class Initialized
INFO - 2018-03-21 16:33:55 --> Helper loaded: url_helper
INFO - 2018-03-21 16:33:55 --> Helper loaded: form_helper
INFO - 2018-03-21 16:33:55 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:33:55 --> Controller Class Initialized
INFO - 2018-03-21 16:33:55 --> Model Class Initialized
INFO - 2018-03-21 16:33:55 --> Model Class Initialized
INFO - 2018-03-21 16:33:55 --> Model Class Initialized
INFO - 2018-03-21 16:33:55 --> Model Class Initialized
INFO - 2018-03-21 16:33:55 --> Model Class Initialized
INFO - 2018-03-21 16:33:55 --> Model Class Initialized
INFO - 2018-03-21 16:33:55 --> Model Class Initialized
INFO - 2018-03-21 16:33:55 --> Model Class Initialized
INFO - 2018-03-21 16:33:55 --> Model Class Initialized
INFO - 2018-03-21 16:33:55 --> Model Class Initialized
INFO - 2018-03-21 16:33:55 --> Helper loaded: date_helper
INFO - 2018-03-21 16:33:55 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:33:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:33:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:33:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/update.php
INFO - 2018-03-21 22:33:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:33:55 --> Final output sent to browser
DEBUG - 2018-03-21 22:33:55 --> Total execution time: 0.1151
INFO - 2018-03-21 16:33:57 --> Config Class Initialized
INFO - 2018-03-21 16:33:57 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:33:57 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:33:57 --> Utf8 Class Initialized
INFO - 2018-03-21 16:33:57 --> URI Class Initialized
INFO - 2018-03-21 16:33:57 --> Router Class Initialized
INFO - 2018-03-21 16:33:57 --> Output Class Initialized
INFO - 2018-03-21 16:33:57 --> Security Class Initialized
DEBUG - 2018-03-21 16:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:33:57 --> Input Class Initialized
INFO - 2018-03-21 16:33:57 --> Language Class Initialized
INFO - 2018-03-21 16:33:57 --> Loader Class Initialized
INFO - 2018-03-21 16:33:57 --> Helper loaded: url_helper
INFO - 2018-03-21 16:33:57 --> Helper loaded: form_helper
INFO - 2018-03-21 16:33:57 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:33:57 --> Controller Class Initialized
INFO - 2018-03-21 16:33:57 --> Model Class Initialized
INFO - 2018-03-21 16:33:57 --> Model Class Initialized
INFO - 2018-03-21 16:33:57 --> Model Class Initialized
INFO - 2018-03-21 16:33:57 --> Model Class Initialized
INFO - 2018-03-21 16:33:57 --> Model Class Initialized
INFO - 2018-03-21 16:33:57 --> Model Class Initialized
INFO - 2018-03-21 16:33:57 --> Model Class Initialized
INFO - 2018-03-21 16:33:57 --> Model Class Initialized
INFO - 2018-03-21 16:33:57 --> Model Class Initialized
INFO - 2018-03-21 16:33:57 --> Model Class Initialized
INFO - 2018-03-21 16:33:57 --> Helper loaded: date_helper
INFO - 2018-03-21 16:33:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:33:57 --> Final output sent to browser
DEBUG - 2018-03-21 22:33:57 --> Total execution time: 0.1162
INFO - 2018-03-21 16:34:23 --> Config Class Initialized
INFO - 2018-03-21 16:34:23 --> Hooks Class Initialized
DEBUG - 2018-03-21 16:34:23 --> UTF-8 Support Enabled
INFO - 2018-03-21 16:34:23 --> Utf8 Class Initialized
INFO - 2018-03-21 16:34:23 --> URI Class Initialized
INFO - 2018-03-21 16:34:23 --> Router Class Initialized
INFO - 2018-03-21 16:34:23 --> Output Class Initialized
INFO - 2018-03-21 16:34:23 --> Security Class Initialized
DEBUG - 2018-03-21 16:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-21 16:34:23 --> Input Class Initialized
INFO - 2018-03-21 16:34:23 --> Language Class Initialized
INFO - 2018-03-21 16:34:23 --> Loader Class Initialized
INFO - 2018-03-21 16:34:23 --> Helper loaded: url_helper
INFO - 2018-03-21 16:34:23 --> Helper loaded: form_helper
INFO - 2018-03-21 16:34:23 --> Database Driver Class Initialized
DEBUG - 2018-03-21 16:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-21 16:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-21 16:34:23 --> Controller Class Initialized
INFO - 2018-03-21 16:34:23 --> Model Class Initialized
INFO - 2018-03-21 16:34:23 --> Model Class Initialized
INFO - 2018-03-21 16:34:23 --> Model Class Initialized
INFO - 2018-03-21 16:34:23 --> Model Class Initialized
INFO - 2018-03-21 16:34:23 --> Model Class Initialized
INFO - 2018-03-21 16:34:23 --> Model Class Initialized
INFO - 2018-03-21 16:34:23 --> Model Class Initialized
INFO - 2018-03-21 16:34:23 --> Model Class Initialized
INFO - 2018-03-21 16:34:23 --> Model Class Initialized
INFO - 2018-03-21 16:34:23 --> Model Class Initialized
INFO - 2018-03-21 16:34:23 --> Model Class Initialized
INFO - 2018-03-21 16:34:23 --> Model Class Initialized
INFO - 2018-03-21 16:34:23 --> Model Class Initialized
INFO - 2018-03-21 16:34:23 --> Helper loaded: date_helper
INFO - 2018-03-21 16:34:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-21 22:34:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-21 22:34:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-21 22:34:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-21 22:34:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-21 22:34:23 --> Final output sent to browser
DEBUG - 2018-03-21 22:34:23 --> Total execution time: 0.1029
