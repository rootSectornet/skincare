<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-23 20:38:43 --> Config Class Initialized
INFO - 2018-03-23 20:38:43 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:38:43 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:38:43 --> Utf8 Class Initialized
INFO - 2018-03-23 20:38:43 --> URI Class Initialized
INFO - 2018-03-23 20:38:43 --> Router Class Initialized
INFO - 2018-03-23 20:38:43 --> Output Class Initialized
INFO - 2018-03-23 20:38:43 --> Security Class Initialized
DEBUG - 2018-03-23 20:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:38:43 --> Input Class Initialized
INFO - 2018-03-23 20:38:43 --> Language Class Initialized
INFO - 2018-03-23 20:38:43 --> Loader Class Initialized
INFO - 2018-03-23 20:38:43 --> Helper loaded: url_helper
INFO - 2018-03-23 20:38:43 --> Helper loaded: form_helper
INFO - 2018-03-23 20:38:43 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:38:43 --> Controller Class Initialized
INFO - 2018-03-23 20:38:44 --> Config Class Initialized
INFO - 2018-03-23 20:38:44 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:38:44 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:38:44 --> Utf8 Class Initialized
INFO - 2018-03-23 20:38:44 --> URI Class Initialized
INFO - 2018-03-23 20:38:44 --> Router Class Initialized
INFO - 2018-03-23 20:38:44 --> Output Class Initialized
INFO - 2018-03-23 20:38:44 --> Security Class Initialized
DEBUG - 2018-03-23 20:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:38:44 --> Input Class Initialized
INFO - 2018-03-23 20:38:44 --> Language Class Initialized
INFO - 2018-03-23 20:38:44 --> Loader Class Initialized
INFO - 2018-03-23 20:38:44 --> Helper loaded: url_helper
INFO - 2018-03-23 20:38:44 --> Helper loaded: form_helper
INFO - 2018-03-23 20:38:44 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:38:44 --> Controller Class Initialized
INFO - 2018-03-23 20:38:44 --> Model Class Initialized
INFO - 2018-03-23 20:38:44 --> Model Class Initialized
INFO - 2018-03-23 20:38:44 --> Model Class Initialized
INFO - 2018-03-23 20:38:44 --> Helper loaded: date_helper
INFO - 2018-03-23 20:38:50 --> Config Class Initialized
INFO - 2018-03-23 20:38:50 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:38:50 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:38:50 --> Utf8 Class Initialized
INFO - 2018-03-23 20:38:50 --> URI Class Initialized
INFO - 2018-03-23 20:38:50 --> Router Class Initialized
INFO - 2018-03-23 20:38:50 --> Output Class Initialized
INFO - 2018-03-23 20:38:50 --> Security Class Initialized
DEBUG - 2018-03-23 20:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:38:50 --> Input Class Initialized
INFO - 2018-03-23 20:38:50 --> Language Class Initialized
INFO - 2018-03-23 20:38:50 --> Loader Class Initialized
INFO - 2018-03-23 20:38:50 --> Helper loaded: url_helper
INFO - 2018-03-23 20:38:50 --> Helper loaded: form_helper
INFO - 2018-03-23 20:38:50 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:38:50 --> Controller Class Initialized
INFO - 2018-03-23 20:38:50 --> Model Class Initialized
INFO - 2018-03-23 20:38:50 --> Model Class Initialized
INFO - 2018-03-23 20:38:50 --> Model Class Initialized
INFO - 2018-03-23 20:38:50 --> Helper loaded: date_helper
INFO - 2018-03-23 20:38:50 --> Config Class Initialized
INFO - 2018-03-23 20:38:50 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:38:50 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:38:50 --> Utf8 Class Initialized
INFO - 2018-03-23 20:38:50 --> URI Class Initialized
INFO - 2018-03-23 20:38:50 --> Router Class Initialized
INFO - 2018-03-23 20:38:50 --> Output Class Initialized
INFO - 2018-03-23 20:38:50 --> Security Class Initialized
DEBUG - 2018-03-23 20:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:38:50 --> Input Class Initialized
INFO - 2018-03-23 20:38:50 --> Language Class Initialized
INFO - 2018-03-23 20:38:50 --> Loader Class Initialized
INFO - 2018-03-23 20:38:50 --> Helper loaded: url_helper
INFO - 2018-03-23 20:38:50 --> Helper loaded: form_helper
INFO - 2018-03-23 20:38:50 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:38:50 --> Controller Class Initialized
INFO - 2018-03-23 20:38:51 --> Model Class Initialized
INFO - 2018-03-23 20:38:51 --> Model Class Initialized
INFO - 2018-03-23 20:38:51 --> Model Class Initialized
INFO - 2018-03-23 20:38:51 --> Model Class Initialized
INFO - 2018-03-23 20:38:51 --> Model Class Initialized
INFO - 2018-03-23 20:38:51 --> Helper loaded: date_helper
INFO - 2018-03-23 20:38:57 --> Config Class Initialized
INFO - 2018-03-23 20:38:57 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:38:57 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:38:57 --> Utf8 Class Initialized
INFO - 2018-03-23 20:38:57 --> URI Class Initialized
INFO - 2018-03-23 20:38:57 --> Router Class Initialized
INFO - 2018-03-23 20:38:57 --> Output Class Initialized
INFO - 2018-03-23 20:38:57 --> Security Class Initialized
DEBUG - 2018-03-23 20:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:38:57 --> Input Class Initialized
INFO - 2018-03-23 20:38:57 --> Language Class Initialized
INFO - 2018-03-23 20:38:57 --> Loader Class Initialized
INFO - 2018-03-23 20:38:57 --> Helper loaded: url_helper
INFO - 2018-03-23 20:38:57 --> Helper loaded: form_helper
INFO - 2018-03-23 20:38:57 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:38:57 --> Controller Class Initialized
INFO - 2018-03-23 20:38:57 --> Model Class Initialized
INFO - 2018-03-23 20:38:57 --> Model Class Initialized
INFO - 2018-03-23 20:38:57 --> Model Class Initialized
INFO - 2018-03-23 20:38:57 --> Model Class Initialized
INFO - 2018-03-23 20:38:57 --> Model Class Initialized
INFO - 2018-03-23 20:38:57 --> Helper loaded: date_helper
INFO - 2018-03-23 20:38:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:38:59 --> Config Class Initialized
INFO - 2018-03-23 20:38:59 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:38:59 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:38:59 --> Utf8 Class Initialized
INFO - 2018-03-23 20:38:59 --> URI Class Initialized
INFO - 2018-03-23 20:38:59 --> Router Class Initialized
INFO - 2018-03-23 20:38:59 --> Output Class Initialized
INFO - 2018-03-23 20:38:59 --> Security Class Initialized
DEBUG - 2018-03-23 20:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:38:59 --> Input Class Initialized
INFO - 2018-03-23 20:38:59 --> Language Class Initialized
INFO - 2018-03-23 20:38:59 --> Loader Class Initialized
INFO - 2018-03-23 20:38:59 --> Helper loaded: url_helper
INFO - 2018-03-23 20:38:59 --> Helper loaded: form_helper
INFO - 2018-03-23 20:38:59 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:38:59 --> Controller Class Initialized
INFO - 2018-03-23 20:38:59 --> Model Class Initialized
INFO - 2018-03-23 20:38:59 --> Model Class Initialized
INFO - 2018-03-23 20:38:59 --> Model Class Initialized
INFO - 2018-03-23 20:38:59 --> Model Class Initialized
INFO - 2018-03-23 20:38:59 --> Model Class Initialized
INFO - 2018-03-23 20:38:59 --> Helper loaded: date_helper
INFO - 2018-03-23 20:38:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:39:01 --> Config Class Initialized
INFO - 2018-03-23 20:39:01 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:39:01 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:39:01 --> Utf8 Class Initialized
INFO - 2018-03-23 20:39:01 --> URI Class Initialized
INFO - 2018-03-23 20:39:01 --> Router Class Initialized
INFO - 2018-03-23 20:39:01 --> Output Class Initialized
INFO - 2018-03-23 20:39:01 --> Security Class Initialized
DEBUG - 2018-03-23 20:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:39:01 --> Input Class Initialized
INFO - 2018-03-23 20:39:01 --> Language Class Initialized
INFO - 2018-03-23 20:39:01 --> Loader Class Initialized
INFO - 2018-03-23 20:39:01 --> Helper loaded: url_helper
INFO - 2018-03-23 20:39:01 --> Helper loaded: form_helper
INFO - 2018-03-23 20:39:01 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:39:01 --> Controller Class Initialized
INFO - 2018-03-23 20:39:01 --> Model Class Initialized
INFO - 2018-03-23 20:39:01 --> Model Class Initialized
INFO - 2018-03-23 20:39:01 --> Model Class Initialized
INFO - 2018-03-23 20:39:01 --> Model Class Initialized
INFO - 2018-03-23 20:39:01 --> Model Class Initialized
INFO - 2018-03-23 20:39:01 --> Helper loaded: date_helper
INFO - 2018-03-23 20:39:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:39:06 --> Config Class Initialized
INFO - 2018-03-23 20:39:06 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:39:06 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:39:06 --> Utf8 Class Initialized
INFO - 2018-03-23 20:39:06 --> URI Class Initialized
INFO - 2018-03-23 20:39:06 --> Router Class Initialized
INFO - 2018-03-23 20:39:06 --> Output Class Initialized
INFO - 2018-03-23 20:39:06 --> Security Class Initialized
DEBUG - 2018-03-23 20:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:39:06 --> Input Class Initialized
INFO - 2018-03-23 20:39:06 --> Language Class Initialized
INFO - 2018-03-23 20:39:06 --> Loader Class Initialized
INFO - 2018-03-23 20:39:06 --> Helper loaded: url_helper
INFO - 2018-03-23 20:39:06 --> Helper loaded: form_helper
INFO - 2018-03-23 20:39:06 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:39:06 --> Controller Class Initialized
INFO - 2018-03-23 20:39:06 --> Model Class Initialized
INFO - 2018-03-23 20:39:06 --> Model Class Initialized
INFO - 2018-03-23 20:39:06 --> Model Class Initialized
INFO - 2018-03-23 20:39:06 --> Model Class Initialized
INFO - 2018-03-23 20:39:06 --> Model Class Initialized
INFO - 2018-03-23 20:39:06 --> Helper loaded: date_helper
INFO - 2018-03-23 20:39:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:39:08 --> Config Class Initialized
INFO - 2018-03-23 20:39:08 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:39:08 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:39:08 --> Utf8 Class Initialized
INFO - 2018-03-23 20:39:08 --> URI Class Initialized
INFO - 2018-03-23 20:39:08 --> Router Class Initialized
INFO - 2018-03-23 20:39:08 --> Output Class Initialized
INFO - 2018-03-23 20:39:08 --> Security Class Initialized
DEBUG - 2018-03-23 20:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:39:08 --> Input Class Initialized
INFO - 2018-03-23 20:39:08 --> Language Class Initialized
INFO - 2018-03-23 20:39:08 --> Loader Class Initialized
INFO - 2018-03-23 20:39:08 --> Helper loaded: url_helper
INFO - 2018-03-23 20:39:08 --> Helper loaded: form_helper
INFO - 2018-03-23 20:39:08 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:39:08 --> Controller Class Initialized
INFO - 2018-03-23 20:39:09 --> Model Class Initialized
INFO - 2018-03-23 20:39:09 --> Model Class Initialized
INFO - 2018-03-23 20:39:09 --> Model Class Initialized
INFO - 2018-03-23 20:39:09 --> Model Class Initialized
INFO - 2018-03-23 20:39:09 --> Model Class Initialized
INFO - 2018-03-23 20:39:09 --> Helper loaded: date_helper
INFO - 2018-03-23 20:39:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:39:10 --> Config Class Initialized
INFO - 2018-03-23 20:39:10 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:39:10 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:39:10 --> Utf8 Class Initialized
INFO - 2018-03-23 20:39:10 --> URI Class Initialized
INFO - 2018-03-23 20:39:10 --> Router Class Initialized
INFO - 2018-03-23 20:39:10 --> Output Class Initialized
INFO - 2018-03-23 20:39:10 --> Security Class Initialized
DEBUG - 2018-03-23 20:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:39:10 --> Input Class Initialized
INFO - 2018-03-23 20:39:10 --> Language Class Initialized
INFO - 2018-03-23 20:39:10 --> Loader Class Initialized
INFO - 2018-03-23 20:39:10 --> Helper loaded: url_helper
INFO - 2018-03-23 20:39:10 --> Helper loaded: form_helper
INFO - 2018-03-23 20:39:10 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:39:10 --> Controller Class Initialized
INFO - 2018-03-23 20:39:10 --> Model Class Initialized
INFO - 2018-03-23 20:39:10 --> Model Class Initialized
INFO - 2018-03-23 20:39:10 --> Model Class Initialized
INFO - 2018-03-23 20:39:10 --> Model Class Initialized
INFO - 2018-03-23 20:39:10 --> Model Class Initialized
INFO - 2018-03-23 20:39:10 --> Helper loaded: date_helper
INFO - 2018-03-23 20:39:10 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:39:13 --> Config Class Initialized
INFO - 2018-03-23 20:39:13 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:39:13 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:39:13 --> Utf8 Class Initialized
INFO - 2018-03-23 20:39:13 --> URI Class Initialized
INFO - 2018-03-23 20:39:13 --> Router Class Initialized
INFO - 2018-03-23 20:39:13 --> Output Class Initialized
INFO - 2018-03-23 20:39:13 --> Security Class Initialized
DEBUG - 2018-03-23 20:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:39:13 --> Input Class Initialized
INFO - 2018-03-23 20:39:13 --> Language Class Initialized
INFO - 2018-03-23 20:39:13 --> Loader Class Initialized
INFO - 2018-03-23 20:39:13 --> Helper loaded: url_helper
INFO - 2018-03-23 20:39:13 --> Helper loaded: form_helper
INFO - 2018-03-23 20:39:13 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:39:13 --> Controller Class Initialized
INFO - 2018-03-23 20:39:13 --> Model Class Initialized
INFO - 2018-03-23 20:39:13 --> Model Class Initialized
INFO - 2018-03-23 20:39:13 --> Model Class Initialized
INFO - 2018-03-23 20:39:13 --> Model Class Initialized
INFO - 2018-03-23 20:39:13 --> Model Class Initialized
INFO - 2018-03-23 20:39:13 --> Helper loaded: date_helper
INFO - 2018-03-23 20:39:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:39:19 --> Config Class Initialized
INFO - 2018-03-23 20:39:19 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:39:19 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:39:19 --> Utf8 Class Initialized
INFO - 2018-03-23 20:39:19 --> URI Class Initialized
INFO - 2018-03-23 20:39:19 --> Router Class Initialized
INFO - 2018-03-23 20:39:19 --> Output Class Initialized
INFO - 2018-03-23 20:39:19 --> Security Class Initialized
DEBUG - 2018-03-23 20:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:39:19 --> Input Class Initialized
INFO - 2018-03-23 20:39:19 --> Language Class Initialized
INFO - 2018-03-23 20:39:19 --> Loader Class Initialized
INFO - 2018-03-23 20:39:19 --> Helper loaded: url_helper
INFO - 2018-03-23 20:39:19 --> Helper loaded: form_helper
INFO - 2018-03-23 20:39:19 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:39:19 --> Controller Class Initialized
INFO - 2018-03-23 20:39:19 --> Model Class Initialized
INFO - 2018-03-23 20:39:19 --> Model Class Initialized
INFO - 2018-03-23 20:39:19 --> Model Class Initialized
INFO - 2018-03-23 20:39:19 --> Model Class Initialized
INFO - 2018-03-23 20:39:19 --> Model Class Initialized
INFO - 2018-03-23 20:39:19 --> Helper loaded: date_helper
INFO - 2018-03-23 20:39:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:39:22 --> Config Class Initialized
INFO - 2018-03-23 20:39:22 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:39:22 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:39:22 --> Utf8 Class Initialized
INFO - 2018-03-23 20:39:22 --> URI Class Initialized
INFO - 2018-03-23 20:39:22 --> Router Class Initialized
INFO - 2018-03-23 20:39:22 --> Output Class Initialized
INFO - 2018-03-23 20:39:22 --> Security Class Initialized
DEBUG - 2018-03-23 20:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:39:22 --> Input Class Initialized
INFO - 2018-03-23 20:39:22 --> Language Class Initialized
INFO - 2018-03-23 20:39:22 --> Loader Class Initialized
INFO - 2018-03-23 20:39:22 --> Helper loaded: url_helper
INFO - 2018-03-23 20:39:22 --> Helper loaded: form_helper
INFO - 2018-03-23 20:39:22 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:39:22 --> Controller Class Initialized
INFO - 2018-03-23 20:39:22 --> Model Class Initialized
INFO - 2018-03-23 20:39:22 --> Model Class Initialized
INFO - 2018-03-23 20:39:22 --> Model Class Initialized
INFO - 2018-03-23 20:39:22 --> Model Class Initialized
INFO - 2018-03-23 20:39:22 --> Model Class Initialized
INFO - 2018-03-23 20:39:22 --> Helper loaded: date_helper
INFO - 2018-03-23 20:39:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:39:26 --> Config Class Initialized
INFO - 2018-03-23 20:39:26 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:39:26 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:39:26 --> Utf8 Class Initialized
INFO - 2018-03-23 20:39:26 --> URI Class Initialized
INFO - 2018-03-23 20:39:26 --> Router Class Initialized
INFO - 2018-03-23 20:39:26 --> Output Class Initialized
INFO - 2018-03-23 20:39:26 --> Security Class Initialized
DEBUG - 2018-03-23 20:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:39:26 --> Input Class Initialized
INFO - 2018-03-23 20:39:26 --> Language Class Initialized
INFO - 2018-03-23 20:39:26 --> Loader Class Initialized
INFO - 2018-03-23 20:39:26 --> Helper loaded: url_helper
INFO - 2018-03-23 20:39:26 --> Helper loaded: form_helper
INFO - 2018-03-23 20:39:26 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:39:26 --> Controller Class Initialized
INFO - 2018-03-23 20:39:26 --> Model Class Initialized
INFO - 2018-03-23 20:39:26 --> Model Class Initialized
INFO - 2018-03-23 20:39:26 --> Model Class Initialized
INFO - 2018-03-23 20:39:26 --> Model Class Initialized
INFO - 2018-03-23 20:39:26 --> Model Class Initialized
INFO - 2018-03-23 20:39:26 --> Helper loaded: date_helper
INFO - 2018-03-23 20:39:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:39:28 --> Config Class Initialized
INFO - 2018-03-23 20:39:28 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:39:28 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:39:28 --> Utf8 Class Initialized
INFO - 2018-03-23 20:39:28 --> URI Class Initialized
INFO - 2018-03-23 20:39:28 --> Router Class Initialized
INFO - 2018-03-23 20:39:28 --> Output Class Initialized
INFO - 2018-03-23 20:39:28 --> Security Class Initialized
DEBUG - 2018-03-23 20:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:39:28 --> Input Class Initialized
INFO - 2018-03-23 20:39:28 --> Language Class Initialized
INFO - 2018-03-23 20:39:28 --> Loader Class Initialized
INFO - 2018-03-23 20:39:28 --> Helper loaded: url_helper
INFO - 2018-03-23 20:39:28 --> Helper loaded: form_helper
INFO - 2018-03-23 20:39:28 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:39:28 --> Controller Class Initialized
INFO - 2018-03-23 20:39:28 --> Model Class Initialized
INFO - 2018-03-23 20:39:28 --> Model Class Initialized
INFO - 2018-03-23 20:39:28 --> Model Class Initialized
INFO - 2018-03-23 20:39:28 --> Model Class Initialized
INFO - 2018-03-23 20:39:28 --> Model Class Initialized
INFO - 2018-03-23 20:39:28 --> Helper loaded: date_helper
INFO - 2018-03-23 20:39:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:39:31 --> Config Class Initialized
INFO - 2018-03-23 20:39:31 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:39:31 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:39:31 --> Utf8 Class Initialized
INFO - 2018-03-23 20:39:31 --> URI Class Initialized
INFO - 2018-03-23 20:39:31 --> Router Class Initialized
INFO - 2018-03-23 20:39:31 --> Output Class Initialized
INFO - 2018-03-23 20:39:31 --> Security Class Initialized
DEBUG - 2018-03-23 20:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:39:31 --> Input Class Initialized
INFO - 2018-03-23 20:39:31 --> Language Class Initialized
INFO - 2018-03-23 20:39:31 --> Loader Class Initialized
INFO - 2018-03-23 20:39:31 --> Helper loaded: url_helper
INFO - 2018-03-23 20:39:31 --> Helper loaded: form_helper
INFO - 2018-03-23 20:39:31 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:39:31 --> Controller Class Initialized
INFO - 2018-03-23 20:39:31 --> Model Class Initialized
INFO - 2018-03-23 20:39:31 --> Model Class Initialized
INFO - 2018-03-23 20:39:31 --> Model Class Initialized
INFO - 2018-03-23 20:39:31 --> Model Class Initialized
INFO - 2018-03-23 20:39:31 --> Model Class Initialized
INFO - 2018-03-23 20:39:31 --> Helper loaded: date_helper
INFO - 2018-03-23 20:39:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:39:50 --> Config Class Initialized
INFO - 2018-03-23 20:39:50 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:39:50 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:39:50 --> Utf8 Class Initialized
INFO - 2018-03-23 20:39:50 --> URI Class Initialized
INFO - 2018-03-23 20:39:50 --> Router Class Initialized
INFO - 2018-03-23 20:39:50 --> Output Class Initialized
INFO - 2018-03-23 20:39:50 --> Security Class Initialized
DEBUG - 2018-03-23 20:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:39:50 --> Input Class Initialized
INFO - 2018-03-23 20:39:50 --> Language Class Initialized
INFO - 2018-03-23 20:39:50 --> Loader Class Initialized
INFO - 2018-03-23 20:39:50 --> Helper loaded: url_helper
INFO - 2018-03-23 20:39:50 --> Helper loaded: form_helper
INFO - 2018-03-23 20:39:50 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:39:50 --> Controller Class Initialized
INFO - 2018-03-23 20:39:50 --> Model Class Initialized
INFO - 2018-03-23 20:39:50 --> Model Class Initialized
INFO - 2018-03-23 20:39:50 --> Model Class Initialized
INFO - 2018-03-23 20:39:50 --> Model Class Initialized
INFO - 2018-03-23 20:39:50 --> Model Class Initialized
INFO - 2018-03-23 20:39:50 --> Helper loaded: date_helper
INFO - 2018-03-23 20:39:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:39:52 --> Config Class Initialized
INFO - 2018-03-23 20:39:52 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:39:52 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:39:52 --> Utf8 Class Initialized
INFO - 2018-03-23 20:39:52 --> URI Class Initialized
INFO - 2018-03-23 20:39:52 --> Router Class Initialized
INFO - 2018-03-23 20:39:52 --> Output Class Initialized
INFO - 2018-03-23 20:39:52 --> Security Class Initialized
DEBUG - 2018-03-23 20:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:39:52 --> Input Class Initialized
INFO - 2018-03-23 20:39:52 --> Language Class Initialized
INFO - 2018-03-23 20:39:52 --> Loader Class Initialized
INFO - 2018-03-23 20:39:52 --> Helper loaded: url_helper
INFO - 2018-03-23 20:39:52 --> Helper loaded: form_helper
INFO - 2018-03-23 20:39:52 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:39:52 --> Controller Class Initialized
INFO - 2018-03-23 20:39:52 --> Model Class Initialized
INFO - 2018-03-23 20:39:52 --> Model Class Initialized
INFO - 2018-03-23 20:39:52 --> Model Class Initialized
INFO - 2018-03-23 20:39:52 --> Model Class Initialized
INFO - 2018-03-23 20:39:52 --> Model Class Initialized
INFO - 2018-03-23 20:39:52 --> Helper loaded: date_helper
INFO - 2018-03-23 20:39:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:39:56 --> Config Class Initialized
INFO - 2018-03-23 20:39:56 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:39:56 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:39:56 --> Utf8 Class Initialized
INFO - 2018-03-23 20:39:56 --> URI Class Initialized
INFO - 2018-03-23 20:39:56 --> Router Class Initialized
INFO - 2018-03-23 20:39:56 --> Output Class Initialized
INFO - 2018-03-23 20:39:56 --> Security Class Initialized
DEBUG - 2018-03-23 20:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:39:56 --> Input Class Initialized
INFO - 2018-03-23 20:39:56 --> Language Class Initialized
INFO - 2018-03-23 20:39:56 --> Loader Class Initialized
INFO - 2018-03-23 20:39:56 --> Helper loaded: url_helper
INFO - 2018-03-23 20:39:56 --> Helper loaded: form_helper
INFO - 2018-03-23 20:39:56 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:39:56 --> Controller Class Initialized
INFO - 2018-03-23 20:39:56 --> Model Class Initialized
INFO - 2018-03-23 20:39:56 --> Model Class Initialized
INFO - 2018-03-23 20:39:56 --> Model Class Initialized
INFO - 2018-03-23 20:39:56 --> Model Class Initialized
INFO - 2018-03-23 20:39:56 --> Model Class Initialized
INFO - 2018-03-23 20:39:56 --> Helper loaded: date_helper
INFO - 2018-03-23 20:39:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:40:00 --> Config Class Initialized
INFO - 2018-03-23 20:40:00 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:40:00 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:40:00 --> Utf8 Class Initialized
INFO - 2018-03-23 20:40:00 --> URI Class Initialized
INFO - 2018-03-23 20:40:00 --> Router Class Initialized
INFO - 2018-03-23 20:40:00 --> Output Class Initialized
INFO - 2018-03-23 20:40:00 --> Security Class Initialized
DEBUG - 2018-03-23 20:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:40:00 --> Input Class Initialized
INFO - 2018-03-23 20:40:00 --> Language Class Initialized
INFO - 2018-03-23 20:40:00 --> Loader Class Initialized
INFO - 2018-03-23 20:40:00 --> Helper loaded: url_helper
INFO - 2018-03-23 20:40:00 --> Helper loaded: form_helper
INFO - 2018-03-23 20:40:00 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:40:00 --> Controller Class Initialized
INFO - 2018-03-23 20:40:00 --> Model Class Initialized
INFO - 2018-03-23 20:40:00 --> Model Class Initialized
INFO - 2018-03-23 20:40:00 --> Model Class Initialized
INFO - 2018-03-23 20:40:00 --> Model Class Initialized
INFO - 2018-03-23 20:40:00 --> Model Class Initialized
INFO - 2018-03-23 20:40:00 --> Helper loaded: date_helper
INFO - 2018-03-23 20:40:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:40:02 --> Config Class Initialized
INFO - 2018-03-23 20:40:02 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:40:02 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:40:02 --> Utf8 Class Initialized
INFO - 2018-03-23 20:40:02 --> URI Class Initialized
INFO - 2018-03-23 20:40:02 --> Router Class Initialized
INFO - 2018-03-23 20:40:02 --> Output Class Initialized
INFO - 2018-03-23 20:40:02 --> Security Class Initialized
DEBUG - 2018-03-23 20:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:40:02 --> Input Class Initialized
INFO - 2018-03-23 20:40:02 --> Language Class Initialized
INFO - 2018-03-23 20:40:02 --> Loader Class Initialized
INFO - 2018-03-23 20:40:02 --> Helper loaded: url_helper
INFO - 2018-03-23 20:40:02 --> Helper loaded: form_helper
INFO - 2018-03-23 20:40:02 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:40:02 --> Controller Class Initialized
INFO - 2018-03-23 20:40:02 --> Model Class Initialized
INFO - 2018-03-23 20:40:02 --> Model Class Initialized
INFO - 2018-03-23 20:40:02 --> Model Class Initialized
INFO - 2018-03-23 20:40:02 --> Model Class Initialized
INFO - 2018-03-23 20:40:02 --> Model Class Initialized
INFO - 2018-03-23 20:40:02 --> Helper loaded: date_helper
INFO - 2018-03-23 20:40:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:47:42 --> Config Class Initialized
INFO - 2018-03-23 20:47:42 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:47:42 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:47:42 --> Utf8 Class Initialized
INFO - 2018-03-23 20:47:42 --> URI Class Initialized
INFO - 2018-03-23 20:47:42 --> Router Class Initialized
INFO - 2018-03-23 20:47:42 --> Output Class Initialized
INFO - 2018-03-23 20:47:42 --> Security Class Initialized
DEBUG - 2018-03-23 20:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:47:42 --> Input Class Initialized
INFO - 2018-03-23 20:47:42 --> Language Class Initialized
INFO - 2018-03-23 20:47:42 --> Loader Class Initialized
INFO - 2018-03-23 20:47:42 --> Helper loaded: url_helper
INFO - 2018-03-23 20:47:42 --> Helper loaded: form_helper
INFO - 2018-03-23 20:47:42 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:47:42 --> Controller Class Initialized
INFO - 2018-03-23 20:47:42 --> Model Class Initialized
INFO - 2018-03-23 20:47:42 --> Model Class Initialized
INFO - 2018-03-23 20:47:42 --> Model Class Initialized
INFO - 2018-03-23 20:47:42 --> Model Class Initialized
INFO - 2018-03-23 20:47:42 --> Model Class Initialized
INFO - 2018-03-23 20:47:42 --> Helper loaded: date_helper
INFO - 2018-03-23 20:47:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:50:22 --> Config Class Initialized
INFO - 2018-03-23 20:50:22 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:50:22 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:50:22 --> Utf8 Class Initialized
INFO - 2018-03-23 20:50:22 --> URI Class Initialized
INFO - 2018-03-23 20:50:22 --> Router Class Initialized
INFO - 2018-03-23 20:50:22 --> Output Class Initialized
INFO - 2018-03-23 20:50:22 --> Security Class Initialized
DEBUG - 2018-03-23 20:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:50:22 --> Input Class Initialized
INFO - 2018-03-23 20:50:22 --> Language Class Initialized
INFO - 2018-03-23 20:50:22 --> Loader Class Initialized
INFO - 2018-03-23 20:50:22 --> Helper loaded: url_helper
INFO - 2018-03-23 20:50:22 --> Helper loaded: form_helper
INFO - 2018-03-23 20:50:22 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:50:22 --> Controller Class Initialized
INFO - 2018-03-23 20:50:22 --> Model Class Initialized
INFO - 2018-03-23 20:50:22 --> Model Class Initialized
INFO - 2018-03-23 20:50:22 --> Model Class Initialized
INFO - 2018-03-23 20:50:22 --> Model Class Initialized
INFO - 2018-03-23 20:50:22 --> Model Class Initialized
INFO - 2018-03-23 20:50:22 --> Helper loaded: date_helper
INFO - 2018-03-23 20:50:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:52:53 --> Config Class Initialized
INFO - 2018-03-23 20:52:53 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:52:53 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:52:53 --> Utf8 Class Initialized
INFO - 2018-03-23 20:52:53 --> URI Class Initialized
INFO - 2018-03-23 20:52:53 --> Router Class Initialized
INFO - 2018-03-23 20:52:53 --> Output Class Initialized
INFO - 2018-03-23 20:52:53 --> Security Class Initialized
DEBUG - 2018-03-23 20:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:52:53 --> Input Class Initialized
INFO - 2018-03-23 20:52:53 --> Language Class Initialized
INFO - 2018-03-23 20:52:53 --> Loader Class Initialized
INFO - 2018-03-23 20:52:53 --> Helper loaded: url_helper
INFO - 2018-03-23 20:52:53 --> Helper loaded: form_helper
INFO - 2018-03-23 20:52:53 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:52:53 --> Controller Class Initialized
INFO - 2018-03-23 20:52:53 --> Model Class Initialized
INFO - 2018-03-23 20:52:53 --> Model Class Initialized
INFO - 2018-03-23 20:52:53 --> Model Class Initialized
INFO - 2018-03-23 20:52:53 --> Model Class Initialized
INFO - 2018-03-23 20:52:53 --> Model Class Initialized
INFO - 2018-03-23 20:52:53 --> Helper loaded: date_helper
INFO - 2018-03-23 20:52:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:53:01 --> Config Class Initialized
INFO - 2018-03-23 20:53:01 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:53:01 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:53:01 --> Utf8 Class Initialized
INFO - 2018-03-23 20:53:01 --> URI Class Initialized
INFO - 2018-03-23 20:53:01 --> Router Class Initialized
INFO - 2018-03-23 20:53:01 --> Output Class Initialized
INFO - 2018-03-23 20:53:01 --> Security Class Initialized
DEBUG - 2018-03-23 20:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:53:01 --> Input Class Initialized
INFO - 2018-03-23 20:53:01 --> Language Class Initialized
INFO - 2018-03-23 20:53:01 --> Loader Class Initialized
INFO - 2018-03-23 20:53:01 --> Helper loaded: url_helper
INFO - 2018-03-23 20:53:01 --> Helper loaded: form_helper
INFO - 2018-03-23 20:53:01 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:53:01 --> Controller Class Initialized
INFO - 2018-03-23 20:53:01 --> Model Class Initialized
INFO - 2018-03-23 20:53:01 --> Model Class Initialized
INFO - 2018-03-23 20:53:01 --> Helper loaded: date_helper
INFO - 2018-03-23 20:53:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:58:41 --> Config Class Initialized
INFO - 2018-03-23 20:58:41 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:58:41 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:58:41 --> Utf8 Class Initialized
INFO - 2018-03-23 20:58:41 --> URI Class Initialized
INFO - 2018-03-23 20:58:41 --> Router Class Initialized
INFO - 2018-03-23 20:58:41 --> Output Class Initialized
INFO - 2018-03-23 20:58:41 --> Security Class Initialized
DEBUG - 2018-03-23 20:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:58:41 --> Input Class Initialized
INFO - 2018-03-23 20:58:41 --> Language Class Initialized
INFO - 2018-03-23 20:58:41 --> Loader Class Initialized
INFO - 2018-03-23 20:58:41 --> Helper loaded: url_helper
INFO - 2018-03-23 20:58:41 --> Helper loaded: form_helper
INFO - 2018-03-23 20:58:41 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:58:41 --> Controller Class Initialized
INFO - 2018-03-23 20:58:41 --> Model Class Initialized
INFO - 2018-03-23 20:58:41 --> Model Class Initialized
INFO - 2018-03-23 20:58:41 --> Model Class Initialized
INFO - 2018-03-23 20:58:41 --> Model Class Initialized
INFO - 2018-03-23 20:58:41 --> Model Class Initialized
INFO - 2018-03-23 20:58:41 --> Helper loaded: date_helper
INFO - 2018-03-23 20:58:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 20:58:45 --> Config Class Initialized
INFO - 2018-03-23 20:58:45 --> Hooks Class Initialized
DEBUG - 2018-03-23 20:58:45 --> UTF-8 Support Enabled
INFO - 2018-03-23 20:58:45 --> Utf8 Class Initialized
INFO - 2018-03-23 20:58:45 --> URI Class Initialized
INFO - 2018-03-23 20:58:45 --> Router Class Initialized
INFO - 2018-03-23 20:58:45 --> Output Class Initialized
INFO - 2018-03-23 20:58:45 --> Security Class Initialized
DEBUG - 2018-03-23 20:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 20:58:45 --> Input Class Initialized
INFO - 2018-03-23 20:58:45 --> Language Class Initialized
INFO - 2018-03-23 20:58:45 --> Loader Class Initialized
INFO - 2018-03-23 20:58:45 --> Helper loaded: url_helper
INFO - 2018-03-23 20:58:45 --> Helper loaded: form_helper
INFO - 2018-03-23 20:58:45 --> Database Driver Class Initialized
DEBUG - 2018-03-23 20:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 20:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 20:58:45 --> Controller Class Initialized
INFO - 2018-03-23 20:58:45 --> Model Class Initialized
INFO - 2018-03-23 20:58:45 --> Model Class Initialized
INFO - 2018-03-23 20:58:45 --> Helper loaded: date_helper
INFO - 2018-03-23 20:58:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:01:03 --> Config Class Initialized
INFO - 2018-03-23 21:01:03 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:01:03 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:01:03 --> Utf8 Class Initialized
INFO - 2018-03-23 21:01:03 --> URI Class Initialized
INFO - 2018-03-23 21:01:03 --> Router Class Initialized
INFO - 2018-03-23 21:01:03 --> Output Class Initialized
INFO - 2018-03-23 21:01:03 --> Security Class Initialized
DEBUG - 2018-03-23 21:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:01:03 --> Input Class Initialized
INFO - 2018-03-23 21:01:03 --> Language Class Initialized
INFO - 2018-03-23 21:01:03 --> Loader Class Initialized
INFO - 2018-03-23 21:01:03 --> Helper loaded: url_helper
INFO - 2018-03-23 21:01:03 --> Helper loaded: form_helper
INFO - 2018-03-23 21:01:03 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:01:03 --> Controller Class Initialized
INFO - 2018-03-23 21:01:03 --> Model Class Initialized
INFO - 2018-03-23 21:01:03 --> Model Class Initialized
INFO - 2018-03-23 21:01:03 --> Model Class Initialized
INFO - 2018-03-23 21:01:03 --> Model Class Initialized
INFO - 2018-03-23 21:01:03 --> Model Class Initialized
INFO - 2018-03-23 21:01:03 --> Helper loaded: date_helper
INFO - 2018-03-23 21:01:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:01:17 --> Config Class Initialized
INFO - 2018-03-23 21:01:17 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:01:17 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:01:17 --> Utf8 Class Initialized
INFO - 2018-03-23 21:01:17 --> URI Class Initialized
INFO - 2018-03-23 21:01:17 --> Router Class Initialized
INFO - 2018-03-23 21:01:17 --> Output Class Initialized
INFO - 2018-03-23 21:01:17 --> Security Class Initialized
DEBUG - 2018-03-23 21:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:01:17 --> Input Class Initialized
INFO - 2018-03-23 21:01:17 --> Language Class Initialized
INFO - 2018-03-23 21:01:17 --> Loader Class Initialized
INFO - 2018-03-23 21:01:17 --> Helper loaded: url_helper
INFO - 2018-03-23 21:01:17 --> Helper loaded: form_helper
INFO - 2018-03-23 21:01:17 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:01:17 --> Controller Class Initialized
INFO - 2018-03-23 21:01:17 --> Model Class Initialized
INFO - 2018-03-23 21:01:17 --> Model Class Initialized
INFO - 2018-03-23 21:01:17 --> Model Class Initialized
INFO - 2018-03-23 21:01:17 --> Model Class Initialized
INFO - 2018-03-23 21:01:17 --> Model Class Initialized
INFO - 2018-03-23 21:01:17 --> Helper loaded: date_helper
INFO - 2018-03-23 21:01:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:01:26 --> Config Class Initialized
INFO - 2018-03-23 21:01:26 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:01:26 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:01:26 --> Utf8 Class Initialized
INFO - 2018-03-23 21:01:26 --> URI Class Initialized
INFO - 2018-03-23 21:01:26 --> Router Class Initialized
INFO - 2018-03-23 21:01:26 --> Output Class Initialized
INFO - 2018-03-23 21:01:26 --> Security Class Initialized
DEBUG - 2018-03-23 21:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:01:26 --> Input Class Initialized
INFO - 2018-03-23 21:01:26 --> Language Class Initialized
INFO - 2018-03-23 21:01:26 --> Loader Class Initialized
INFO - 2018-03-23 21:01:26 --> Helper loaded: url_helper
INFO - 2018-03-23 21:01:26 --> Helper loaded: form_helper
INFO - 2018-03-23 21:01:26 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:01:26 --> Controller Class Initialized
INFO - 2018-03-23 21:01:26 --> Model Class Initialized
INFO - 2018-03-23 21:01:26 --> Model Class Initialized
INFO - 2018-03-23 21:01:26 --> Model Class Initialized
INFO - 2018-03-23 21:01:26 --> Model Class Initialized
INFO - 2018-03-23 21:01:26 --> Model Class Initialized
INFO - 2018-03-23 21:01:26 --> Helper loaded: date_helper
INFO - 2018-03-23 21:01:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:01:33 --> Config Class Initialized
INFO - 2018-03-23 21:01:33 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:01:33 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:01:33 --> Utf8 Class Initialized
INFO - 2018-03-23 21:01:33 --> URI Class Initialized
INFO - 2018-03-23 21:01:33 --> Router Class Initialized
INFO - 2018-03-23 21:01:33 --> Output Class Initialized
INFO - 2018-03-23 21:01:33 --> Security Class Initialized
DEBUG - 2018-03-23 21:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:01:33 --> Input Class Initialized
INFO - 2018-03-23 21:01:33 --> Language Class Initialized
INFO - 2018-03-23 21:01:33 --> Loader Class Initialized
INFO - 2018-03-23 21:01:33 --> Helper loaded: url_helper
INFO - 2018-03-23 21:01:33 --> Helper loaded: form_helper
INFO - 2018-03-23 21:01:33 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:01:33 --> Controller Class Initialized
INFO - 2018-03-23 21:01:33 --> Model Class Initialized
INFO - 2018-03-23 21:01:33 --> Model Class Initialized
INFO - 2018-03-23 21:01:33 --> Model Class Initialized
INFO - 2018-03-23 21:01:33 --> Model Class Initialized
INFO - 2018-03-23 21:01:33 --> Model Class Initialized
INFO - 2018-03-23 21:01:33 --> Helper loaded: date_helper
INFO - 2018-03-23 21:01:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:01:45 --> Config Class Initialized
INFO - 2018-03-23 21:01:45 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:01:45 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:01:45 --> Utf8 Class Initialized
INFO - 2018-03-23 21:01:45 --> URI Class Initialized
INFO - 2018-03-23 21:01:45 --> Router Class Initialized
INFO - 2018-03-23 21:01:45 --> Output Class Initialized
INFO - 2018-03-23 21:01:45 --> Security Class Initialized
DEBUG - 2018-03-23 21:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:01:45 --> Input Class Initialized
INFO - 2018-03-23 21:01:45 --> Language Class Initialized
INFO - 2018-03-23 21:01:45 --> Loader Class Initialized
INFO - 2018-03-23 21:01:45 --> Helper loaded: url_helper
INFO - 2018-03-23 21:01:45 --> Helper loaded: form_helper
INFO - 2018-03-23 21:01:45 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:01:45 --> Controller Class Initialized
INFO - 2018-03-23 21:01:45 --> Model Class Initialized
INFO - 2018-03-23 21:01:45 --> Model Class Initialized
INFO - 2018-03-23 21:01:45 --> Helper loaded: date_helper
INFO - 2018-03-23 21:01:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:01:49 --> Config Class Initialized
INFO - 2018-03-23 21:01:49 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:01:49 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:01:49 --> Utf8 Class Initialized
INFO - 2018-03-23 21:01:49 --> URI Class Initialized
INFO - 2018-03-23 21:01:49 --> Router Class Initialized
INFO - 2018-03-23 21:01:49 --> Output Class Initialized
INFO - 2018-03-23 21:01:49 --> Security Class Initialized
DEBUG - 2018-03-23 21:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:01:49 --> Input Class Initialized
INFO - 2018-03-23 21:01:49 --> Language Class Initialized
INFO - 2018-03-23 21:01:49 --> Loader Class Initialized
INFO - 2018-03-23 21:01:49 --> Helper loaded: url_helper
INFO - 2018-03-23 21:01:49 --> Helper loaded: form_helper
INFO - 2018-03-23 21:01:49 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:01:49 --> Controller Class Initialized
INFO - 2018-03-23 21:01:49 --> Model Class Initialized
INFO - 2018-03-23 21:01:49 --> Model Class Initialized
INFO - 2018-03-23 21:01:49 --> Helper loaded: date_helper
INFO - 2018-03-23 21:01:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:03:09 --> Config Class Initialized
INFO - 2018-03-23 21:03:09 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:03:09 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:03:09 --> Utf8 Class Initialized
INFO - 2018-03-23 21:03:09 --> URI Class Initialized
INFO - 2018-03-23 21:03:09 --> Router Class Initialized
INFO - 2018-03-23 21:03:09 --> Output Class Initialized
INFO - 2018-03-23 21:03:09 --> Security Class Initialized
DEBUG - 2018-03-23 21:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:03:09 --> Input Class Initialized
INFO - 2018-03-23 21:03:09 --> Language Class Initialized
INFO - 2018-03-23 21:03:09 --> Loader Class Initialized
INFO - 2018-03-23 21:03:09 --> Helper loaded: url_helper
INFO - 2018-03-23 21:03:09 --> Helper loaded: form_helper
INFO - 2018-03-23 21:03:09 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:03:09 --> Controller Class Initialized
INFO - 2018-03-23 21:03:09 --> Model Class Initialized
INFO - 2018-03-23 21:03:09 --> Model Class Initialized
INFO - 2018-03-23 21:03:09 --> Model Class Initialized
INFO - 2018-03-23 21:03:09 --> Model Class Initialized
INFO - 2018-03-23 21:03:09 --> Model Class Initialized
INFO - 2018-03-23 21:03:09 --> Helper loaded: date_helper
INFO - 2018-03-23 21:03:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:09:11 --> Config Class Initialized
INFO - 2018-03-23 21:09:11 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:09:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:09:11 --> Utf8 Class Initialized
INFO - 2018-03-23 21:09:11 --> URI Class Initialized
INFO - 2018-03-23 21:09:11 --> Router Class Initialized
INFO - 2018-03-23 21:09:11 --> Output Class Initialized
INFO - 2018-03-23 21:09:11 --> Security Class Initialized
DEBUG - 2018-03-23 21:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:09:11 --> Input Class Initialized
INFO - 2018-03-23 21:09:11 --> Language Class Initialized
INFO - 2018-03-23 21:09:11 --> Loader Class Initialized
INFO - 2018-03-23 21:09:11 --> Helper loaded: url_helper
INFO - 2018-03-23 21:09:11 --> Helper loaded: form_helper
INFO - 2018-03-23 21:09:11 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:09:11 --> Controller Class Initialized
INFO - 2018-03-23 21:09:11 --> Config Class Initialized
INFO - 2018-03-23 21:09:11 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:09:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:09:11 --> Utf8 Class Initialized
INFO - 2018-03-23 21:09:11 --> URI Class Initialized
INFO - 2018-03-23 21:09:11 --> Router Class Initialized
INFO - 2018-03-23 21:09:11 --> Output Class Initialized
INFO - 2018-03-23 21:09:11 --> Security Class Initialized
DEBUG - 2018-03-23 21:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:09:11 --> Input Class Initialized
INFO - 2018-03-23 21:09:11 --> Language Class Initialized
INFO - 2018-03-23 21:09:11 --> Loader Class Initialized
INFO - 2018-03-23 21:09:11 --> Helper loaded: url_helper
INFO - 2018-03-23 21:09:11 --> Helper loaded: form_helper
INFO - 2018-03-23 21:09:11 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:09:11 --> Controller Class Initialized
INFO - 2018-03-23 21:09:11 --> Model Class Initialized
INFO - 2018-03-23 21:09:11 --> Model Class Initialized
INFO - 2018-03-23 21:09:11 --> Model Class Initialized
INFO - 2018-03-23 21:09:11 --> Helper loaded: date_helper
INFO - 2018-03-23 21:09:13 --> Config Class Initialized
INFO - 2018-03-23 21:09:13 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:09:13 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:09:13 --> Utf8 Class Initialized
INFO - 2018-03-23 21:09:13 --> URI Class Initialized
INFO - 2018-03-23 21:09:13 --> Router Class Initialized
INFO - 2018-03-23 21:09:13 --> Output Class Initialized
INFO - 2018-03-23 21:09:13 --> Security Class Initialized
DEBUG - 2018-03-23 21:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:09:13 --> Input Class Initialized
INFO - 2018-03-23 21:09:13 --> Language Class Initialized
INFO - 2018-03-23 21:09:13 --> Loader Class Initialized
INFO - 2018-03-23 21:09:13 --> Helper loaded: url_helper
INFO - 2018-03-23 21:09:13 --> Helper loaded: form_helper
INFO - 2018-03-23 21:09:13 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:09:13 --> Controller Class Initialized
INFO - 2018-03-23 21:09:13 --> Model Class Initialized
INFO - 2018-03-23 21:09:13 --> Model Class Initialized
INFO - 2018-03-23 21:09:13 --> Model Class Initialized
INFO - 2018-03-23 21:09:13 --> Helper loaded: date_helper
INFO - 2018-03-23 21:09:13 --> Config Class Initialized
INFO - 2018-03-23 21:09:13 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:09:13 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:09:13 --> Utf8 Class Initialized
INFO - 2018-03-23 21:09:13 --> URI Class Initialized
INFO - 2018-03-23 21:09:13 --> Router Class Initialized
INFO - 2018-03-23 21:09:13 --> Output Class Initialized
INFO - 2018-03-23 21:09:13 --> Security Class Initialized
DEBUG - 2018-03-23 21:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:09:13 --> Input Class Initialized
INFO - 2018-03-23 21:09:13 --> Language Class Initialized
INFO - 2018-03-23 21:09:13 --> Loader Class Initialized
INFO - 2018-03-23 21:09:13 --> Helper loaded: url_helper
INFO - 2018-03-23 21:09:13 --> Helper loaded: form_helper
INFO - 2018-03-23 21:09:13 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:09:13 --> Controller Class Initialized
INFO - 2018-03-23 21:09:13 --> Model Class Initialized
INFO - 2018-03-23 21:09:13 --> Model Class Initialized
INFO - 2018-03-23 21:09:13 --> Model Class Initialized
INFO - 2018-03-23 21:09:13 --> Model Class Initialized
INFO - 2018-03-23 21:09:13 --> Model Class Initialized
INFO - 2018-03-23 21:09:13 --> Helper loaded: date_helper
INFO - 2018-03-23 21:09:16 --> Config Class Initialized
INFO - 2018-03-23 21:09:16 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:09:16 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:09:16 --> Utf8 Class Initialized
INFO - 2018-03-23 21:09:16 --> URI Class Initialized
INFO - 2018-03-23 21:09:16 --> Router Class Initialized
INFO - 2018-03-23 21:09:16 --> Output Class Initialized
INFO - 2018-03-23 21:09:16 --> Security Class Initialized
DEBUG - 2018-03-23 21:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:09:16 --> Input Class Initialized
INFO - 2018-03-23 21:09:16 --> Language Class Initialized
INFO - 2018-03-23 21:09:16 --> Loader Class Initialized
INFO - 2018-03-23 21:09:16 --> Helper loaded: url_helper
INFO - 2018-03-23 21:09:16 --> Helper loaded: form_helper
INFO - 2018-03-23 21:09:16 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:09:16 --> Controller Class Initialized
INFO - 2018-03-23 21:09:16 --> Model Class Initialized
INFO - 2018-03-23 21:09:16 --> Model Class Initialized
INFO - 2018-03-23 21:09:16 --> Model Class Initialized
INFO - 2018-03-23 21:09:16 --> Model Class Initialized
INFO - 2018-03-23 21:09:16 --> Model Class Initialized
INFO - 2018-03-23 21:09:16 --> Helper loaded: date_helper
INFO - 2018-03-23 21:09:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:09:19 --> Config Class Initialized
INFO - 2018-03-23 21:09:19 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:09:19 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:09:19 --> Utf8 Class Initialized
INFO - 2018-03-23 21:09:19 --> URI Class Initialized
INFO - 2018-03-23 21:09:19 --> Router Class Initialized
INFO - 2018-03-23 21:09:19 --> Output Class Initialized
INFO - 2018-03-23 21:09:19 --> Security Class Initialized
DEBUG - 2018-03-23 21:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:09:19 --> Input Class Initialized
INFO - 2018-03-23 21:09:19 --> Language Class Initialized
INFO - 2018-03-23 21:09:19 --> Loader Class Initialized
INFO - 2018-03-23 21:09:19 --> Helper loaded: url_helper
INFO - 2018-03-23 21:09:19 --> Helper loaded: form_helper
INFO - 2018-03-23 21:09:19 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:09:19 --> Controller Class Initialized
INFO - 2018-03-23 21:09:19 --> Model Class Initialized
INFO - 2018-03-23 21:09:19 --> Model Class Initialized
INFO - 2018-03-23 21:09:19 --> Model Class Initialized
INFO - 2018-03-23 21:09:19 --> Model Class Initialized
INFO - 2018-03-23 21:09:19 --> Model Class Initialized
INFO - 2018-03-23 21:09:19 --> Helper loaded: date_helper
INFO - 2018-03-23 21:09:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:09:20 --> Config Class Initialized
INFO - 2018-03-23 21:09:20 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:09:20 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:09:20 --> Utf8 Class Initialized
INFO - 2018-03-23 21:09:20 --> URI Class Initialized
INFO - 2018-03-23 21:09:20 --> Router Class Initialized
INFO - 2018-03-23 21:09:20 --> Output Class Initialized
INFO - 2018-03-23 21:09:20 --> Security Class Initialized
DEBUG - 2018-03-23 21:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:09:20 --> Input Class Initialized
INFO - 2018-03-23 21:09:20 --> Language Class Initialized
INFO - 2018-03-23 21:09:20 --> Loader Class Initialized
INFO - 2018-03-23 21:09:20 --> Helper loaded: url_helper
INFO - 2018-03-23 21:09:20 --> Helper loaded: form_helper
INFO - 2018-03-23 21:09:20 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:09:20 --> Controller Class Initialized
INFO - 2018-03-23 21:09:20 --> Model Class Initialized
INFO - 2018-03-23 21:09:20 --> Model Class Initialized
INFO - 2018-03-23 21:09:20 --> Model Class Initialized
INFO - 2018-03-23 21:09:20 --> Model Class Initialized
INFO - 2018-03-23 21:09:20 --> Model Class Initialized
INFO - 2018-03-23 21:09:20 --> Helper loaded: date_helper
INFO - 2018-03-23 21:09:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:09:58 --> Config Class Initialized
INFO - 2018-03-23 21:09:58 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:09:58 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:09:58 --> Utf8 Class Initialized
INFO - 2018-03-23 21:09:58 --> URI Class Initialized
INFO - 2018-03-23 21:09:58 --> Router Class Initialized
INFO - 2018-03-23 21:09:58 --> Output Class Initialized
INFO - 2018-03-23 21:09:58 --> Security Class Initialized
DEBUG - 2018-03-23 21:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:09:58 --> Input Class Initialized
INFO - 2018-03-23 21:09:58 --> Language Class Initialized
INFO - 2018-03-23 21:09:58 --> Loader Class Initialized
INFO - 2018-03-23 21:09:58 --> Helper loaded: url_helper
INFO - 2018-03-23 21:09:58 --> Helper loaded: form_helper
INFO - 2018-03-23 21:09:58 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:09:58 --> Controller Class Initialized
INFO - 2018-03-23 21:09:58 --> Model Class Initialized
INFO - 2018-03-23 21:09:58 --> Model Class Initialized
INFO - 2018-03-23 21:09:58 --> Model Class Initialized
INFO - 2018-03-23 21:09:58 --> Model Class Initialized
INFO - 2018-03-23 21:09:58 --> Model Class Initialized
INFO - 2018-03-23 21:09:58 --> Helper loaded: date_helper
INFO - 2018-03-23 21:09:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:22:04 --> Config Class Initialized
INFO - 2018-03-23 21:22:04 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:22:04 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:22:04 --> Utf8 Class Initialized
INFO - 2018-03-23 21:22:04 --> URI Class Initialized
INFO - 2018-03-23 21:22:04 --> Router Class Initialized
INFO - 2018-03-23 21:22:04 --> Output Class Initialized
INFO - 2018-03-23 21:22:04 --> Security Class Initialized
DEBUG - 2018-03-23 21:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:22:04 --> Input Class Initialized
INFO - 2018-03-23 21:22:04 --> Language Class Initialized
INFO - 2018-03-23 21:22:04 --> Loader Class Initialized
INFO - 2018-03-23 21:22:04 --> Helper loaded: url_helper
INFO - 2018-03-23 21:22:04 --> Helper loaded: form_helper
INFO - 2018-03-23 21:22:04 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:22:04 --> Controller Class Initialized
INFO - 2018-03-23 21:22:04 --> Model Class Initialized
INFO - 2018-03-23 21:22:04 --> Model Class Initialized
INFO - 2018-03-23 21:22:04 --> Helper loaded: date_helper
INFO - 2018-03-23 21:22:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:25:11 --> Config Class Initialized
INFO - 2018-03-23 21:25:11 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:25:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:25:11 --> Utf8 Class Initialized
INFO - 2018-03-23 21:25:11 --> URI Class Initialized
INFO - 2018-03-23 21:25:11 --> Router Class Initialized
INFO - 2018-03-23 21:25:11 --> Output Class Initialized
INFO - 2018-03-23 21:25:11 --> Security Class Initialized
DEBUG - 2018-03-23 21:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:25:11 --> Input Class Initialized
INFO - 2018-03-23 21:25:11 --> Language Class Initialized
INFO - 2018-03-23 21:25:11 --> Loader Class Initialized
INFO - 2018-03-23 21:25:11 --> Helper loaded: url_helper
INFO - 2018-03-23 21:25:11 --> Helper loaded: form_helper
INFO - 2018-03-23 21:25:11 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:25:11 --> Controller Class Initialized
INFO - 2018-03-23 21:25:11 --> Model Class Initialized
INFO - 2018-03-23 21:25:11 --> Model Class Initialized
INFO - 2018-03-23 21:25:11 --> Model Class Initialized
INFO - 2018-03-23 21:25:11 --> Model Class Initialized
INFO - 2018-03-23 21:25:11 --> Model Class Initialized
INFO - 2018-03-23 21:25:11 --> Helper loaded: date_helper
INFO - 2018-03-23 21:25:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:25:15 --> Config Class Initialized
INFO - 2018-03-23 21:25:15 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:25:15 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:25:15 --> Utf8 Class Initialized
INFO - 2018-03-23 21:25:15 --> URI Class Initialized
INFO - 2018-03-23 21:25:15 --> Router Class Initialized
INFO - 2018-03-23 21:25:15 --> Output Class Initialized
INFO - 2018-03-23 21:25:15 --> Security Class Initialized
DEBUG - 2018-03-23 21:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:25:15 --> Input Class Initialized
INFO - 2018-03-23 21:25:15 --> Language Class Initialized
INFO - 2018-03-23 21:25:15 --> Loader Class Initialized
INFO - 2018-03-23 21:25:15 --> Helper loaded: url_helper
INFO - 2018-03-23 21:25:15 --> Helper loaded: form_helper
INFO - 2018-03-23 21:25:15 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:25:15 --> Controller Class Initialized
INFO - 2018-03-23 21:25:15 --> Model Class Initialized
INFO - 2018-03-23 21:25:15 --> Model Class Initialized
INFO - 2018-03-23 21:25:15 --> Helper loaded: date_helper
INFO - 2018-03-23 21:25:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:30:07 --> Config Class Initialized
INFO - 2018-03-23 21:30:07 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:30:07 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:30:07 --> Utf8 Class Initialized
INFO - 2018-03-23 21:30:07 --> URI Class Initialized
INFO - 2018-03-23 21:30:07 --> Router Class Initialized
INFO - 2018-03-23 21:30:07 --> Output Class Initialized
INFO - 2018-03-23 21:30:07 --> Security Class Initialized
DEBUG - 2018-03-23 21:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:30:07 --> Input Class Initialized
INFO - 2018-03-23 21:30:07 --> Language Class Initialized
INFO - 2018-03-23 21:30:07 --> Loader Class Initialized
INFO - 2018-03-23 21:30:07 --> Helper loaded: url_helper
INFO - 2018-03-23 21:30:07 --> Helper loaded: form_helper
INFO - 2018-03-23 21:30:07 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:30:07 --> Controller Class Initialized
INFO - 2018-03-23 21:30:07 --> Model Class Initialized
INFO - 2018-03-23 21:30:07 --> Model Class Initialized
INFO - 2018-03-23 21:30:07 --> Model Class Initialized
INFO - 2018-03-23 21:30:07 --> Model Class Initialized
INFO - 2018-03-23 21:30:07 --> Model Class Initialized
INFO - 2018-03-23 21:30:07 --> Helper loaded: date_helper
INFO - 2018-03-23 21:30:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:30:11 --> Config Class Initialized
INFO - 2018-03-23 21:30:11 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:30:11 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:30:11 --> Utf8 Class Initialized
INFO - 2018-03-23 21:30:11 --> URI Class Initialized
INFO - 2018-03-23 21:30:11 --> Router Class Initialized
INFO - 2018-03-23 21:30:11 --> Output Class Initialized
INFO - 2018-03-23 21:30:11 --> Security Class Initialized
DEBUG - 2018-03-23 21:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:30:11 --> Input Class Initialized
INFO - 2018-03-23 21:30:11 --> Language Class Initialized
INFO - 2018-03-23 21:30:11 --> Loader Class Initialized
INFO - 2018-03-23 21:30:11 --> Helper loaded: url_helper
INFO - 2018-03-23 21:30:11 --> Helper loaded: form_helper
INFO - 2018-03-23 21:30:11 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:30:11 --> Controller Class Initialized
INFO - 2018-03-23 21:30:11 --> Model Class Initialized
INFO - 2018-03-23 21:30:11 --> Model Class Initialized
INFO - 2018-03-23 21:30:11 --> Helper loaded: date_helper
INFO - 2018-03-23 21:30:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:30:41 --> Config Class Initialized
INFO - 2018-03-23 21:30:41 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:30:41 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:30:41 --> Utf8 Class Initialized
INFO - 2018-03-23 21:30:41 --> URI Class Initialized
INFO - 2018-03-23 21:30:41 --> Router Class Initialized
INFO - 2018-03-23 21:30:41 --> Output Class Initialized
INFO - 2018-03-23 21:30:41 --> Security Class Initialized
DEBUG - 2018-03-23 21:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:30:41 --> Input Class Initialized
INFO - 2018-03-23 21:30:41 --> Language Class Initialized
INFO - 2018-03-23 21:30:41 --> Loader Class Initialized
INFO - 2018-03-23 21:30:41 --> Helper loaded: url_helper
INFO - 2018-03-23 21:30:41 --> Helper loaded: form_helper
INFO - 2018-03-23 21:30:41 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:30:41 --> Controller Class Initialized
INFO - 2018-03-23 21:30:41 --> Model Class Initialized
INFO - 2018-03-23 21:30:41 --> Model Class Initialized
INFO - 2018-03-23 21:30:41 --> Model Class Initialized
INFO - 2018-03-23 21:30:41 --> Model Class Initialized
INFO - 2018-03-23 21:30:41 --> Model Class Initialized
INFO - 2018-03-23 21:30:41 --> Helper loaded: date_helper
INFO - 2018-03-23 21:30:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:30:46 --> Config Class Initialized
INFO - 2018-03-23 21:30:46 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:30:46 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:30:46 --> Utf8 Class Initialized
INFO - 2018-03-23 21:30:46 --> URI Class Initialized
INFO - 2018-03-23 21:30:46 --> Router Class Initialized
INFO - 2018-03-23 21:30:46 --> Output Class Initialized
INFO - 2018-03-23 21:30:46 --> Security Class Initialized
DEBUG - 2018-03-23 21:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:30:46 --> Input Class Initialized
INFO - 2018-03-23 21:30:46 --> Language Class Initialized
INFO - 2018-03-23 21:30:46 --> Loader Class Initialized
INFO - 2018-03-23 21:30:46 --> Helper loaded: url_helper
INFO - 2018-03-23 21:30:46 --> Helper loaded: form_helper
INFO - 2018-03-23 21:30:46 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:30:46 --> Controller Class Initialized
INFO - 2018-03-23 21:30:46 --> Model Class Initialized
INFO - 2018-03-23 21:30:46 --> Model Class Initialized
INFO - 2018-03-23 21:30:46 --> Helper loaded: date_helper
INFO - 2018-03-23 21:30:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:31:17 --> Config Class Initialized
INFO - 2018-03-23 21:31:17 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:31:17 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:31:17 --> Utf8 Class Initialized
INFO - 2018-03-23 21:31:17 --> URI Class Initialized
INFO - 2018-03-23 21:31:17 --> Router Class Initialized
INFO - 2018-03-23 21:31:17 --> Output Class Initialized
INFO - 2018-03-23 21:31:17 --> Security Class Initialized
DEBUG - 2018-03-23 21:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:31:17 --> Input Class Initialized
INFO - 2018-03-23 21:31:17 --> Language Class Initialized
INFO - 2018-03-23 21:31:17 --> Loader Class Initialized
INFO - 2018-03-23 21:31:17 --> Helper loaded: url_helper
INFO - 2018-03-23 21:31:17 --> Helper loaded: form_helper
INFO - 2018-03-23 21:31:17 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:31:17 --> Controller Class Initialized
INFO - 2018-03-23 21:31:17 --> Model Class Initialized
INFO - 2018-03-23 21:31:17 --> Model Class Initialized
INFO - 2018-03-23 21:31:17 --> Model Class Initialized
INFO - 2018-03-23 21:31:17 --> Model Class Initialized
INFO - 2018-03-23 21:31:17 --> Model Class Initialized
INFO - 2018-03-23 21:31:17 --> Helper loaded: date_helper
INFO - 2018-03-23 21:31:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:31:22 --> Config Class Initialized
INFO - 2018-03-23 21:31:22 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:31:22 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:31:22 --> Utf8 Class Initialized
INFO - 2018-03-23 21:31:22 --> URI Class Initialized
INFO - 2018-03-23 21:31:22 --> Router Class Initialized
INFO - 2018-03-23 21:31:22 --> Output Class Initialized
INFO - 2018-03-23 21:31:22 --> Security Class Initialized
DEBUG - 2018-03-23 21:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:31:22 --> Input Class Initialized
INFO - 2018-03-23 21:31:22 --> Language Class Initialized
INFO - 2018-03-23 21:31:22 --> Loader Class Initialized
INFO - 2018-03-23 21:31:22 --> Helper loaded: url_helper
INFO - 2018-03-23 21:31:22 --> Helper loaded: form_helper
INFO - 2018-03-23 21:31:22 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:31:22 --> Controller Class Initialized
INFO - 2018-03-23 21:31:22 --> Model Class Initialized
INFO - 2018-03-23 21:31:22 --> Model Class Initialized
INFO - 2018-03-23 21:31:22 --> Helper loaded: date_helper
INFO - 2018-03-23 21:31:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:32:17 --> Config Class Initialized
INFO - 2018-03-23 21:32:17 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:32:17 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:32:17 --> Utf8 Class Initialized
INFO - 2018-03-23 21:32:17 --> URI Class Initialized
INFO - 2018-03-23 21:32:17 --> Router Class Initialized
INFO - 2018-03-23 21:32:17 --> Output Class Initialized
INFO - 2018-03-23 21:32:17 --> Security Class Initialized
DEBUG - 2018-03-23 21:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:32:17 --> Input Class Initialized
INFO - 2018-03-23 21:32:17 --> Language Class Initialized
INFO - 2018-03-23 21:32:17 --> Loader Class Initialized
INFO - 2018-03-23 21:32:17 --> Helper loaded: url_helper
INFO - 2018-03-23 21:32:17 --> Helper loaded: form_helper
INFO - 2018-03-23 21:32:17 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:32:17 --> Controller Class Initialized
INFO - 2018-03-23 21:32:17 --> Model Class Initialized
INFO - 2018-03-23 21:32:17 --> Model Class Initialized
INFO - 2018-03-23 21:32:17 --> Model Class Initialized
INFO - 2018-03-23 21:32:17 --> Model Class Initialized
INFO - 2018-03-23 21:32:17 --> Model Class Initialized
INFO - 2018-03-23 21:32:17 --> Helper loaded: date_helper
INFO - 2018-03-23 21:32:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:32:21 --> Config Class Initialized
INFO - 2018-03-23 21:32:21 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:32:21 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:32:21 --> Utf8 Class Initialized
INFO - 2018-03-23 21:32:21 --> URI Class Initialized
INFO - 2018-03-23 21:32:21 --> Router Class Initialized
INFO - 2018-03-23 21:32:21 --> Output Class Initialized
INFO - 2018-03-23 21:32:21 --> Security Class Initialized
DEBUG - 2018-03-23 21:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:32:21 --> Input Class Initialized
INFO - 2018-03-23 21:32:21 --> Language Class Initialized
INFO - 2018-03-23 21:32:21 --> Loader Class Initialized
INFO - 2018-03-23 21:32:21 --> Helper loaded: url_helper
INFO - 2018-03-23 21:32:21 --> Helper loaded: form_helper
INFO - 2018-03-23 21:32:21 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:32:21 --> Controller Class Initialized
INFO - 2018-03-23 21:32:21 --> Model Class Initialized
INFO - 2018-03-23 21:32:21 --> Model Class Initialized
INFO - 2018-03-23 21:32:21 --> Helper loaded: date_helper
INFO - 2018-03-23 21:32:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:32:48 --> Config Class Initialized
INFO - 2018-03-23 21:32:48 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:32:48 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:32:48 --> Utf8 Class Initialized
INFO - 2018-03-23 21:32:48 --> URI Class Initialized
INFO - 2018-03-23 21:32:48 --> Router Class Initialized
INFO - 2018-03-23 21:32:48 --> Output Class Initialized
INFO - 2018-03-23 21:32:48 --> Security Class Initialized
DEBUG - 2018-03-23 21:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:32:48 --> Input Class Initialized
INFO - 2018-03-23 21:32:48 --> Language Class Initialized
INFO - 2018-03-23 21:32:48 --> Loader Class Initialized
INFO - 2018-03-23 21:32:48 --> Helper loaded: url_helper
INFO - 2018-03-23 21:32:48 --> Helper loaded: form_helper
INFO - 2018-03-23 21:32:48 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:32:48 --> Controller Class Initialized
INFO - 2018-03-23 21:32:48 --> Model Class Initialized
INFO - 2018-03-23 21:32:48 --> Model Class Initialized
INFO - 2018-03-23 21:32:48 --> Model Class Initialized
INFO - 2018-03-23 21:32:48 --> Model Class Initialized
INFO - 2018-03-23 21:32:48 --> Model Class Initialized
INFO - 2018-03-23 21:32:48 --> Helper loaded: date_helper
INFO - 2018-03-23 21:32:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:32:53 --> Config Class Initialized
INFO - 2018-03-23 21:32:53 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:32:53 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:32:53 --> Utf8 Class Initialized
INFO - 2018-03-23 21:32:53 --> URI Class Initialized
INFO - 2018-03-23 21:32:53 --> Router Class Initialized
INFO - 2018-03-23 21:32:53 --> Output Class Initialized
INFO - 2018-03-23 21:32:53 --> Security Class Initialized
DEBUG - 2018-03-23 21:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:32:53 --> Input Class Initialized
INFO - 2018-03-23 21:32:53 --> Language Class Initialized
INFO - 2018-03-23 21:32:53 --> Loader Class Initialized
INFO - 2018-03-23 21:32:53 --> Helper loaded: url_helper
INFO - 2018-03-23 21:32:53 --> Helper loaded: form_helper
INFO - 2018-03-23 21:32:53 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:32:53 --> Controller Class Initialized
INFO - 2018-03-23 21:32:53 --> Model Class Initialized
INFO - 2018-03-23 21:32:53 --> Model Class Initialized
INFO - 2018-03-23 21:32:53 --> Helper loaded: date_helper
INFO - 2018-03-23 21:32:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:33:20 --> Config Class Initialized
INFO - 2018-03-23 21:33:20 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:33:20 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:33:20 --> Utf8 Class Initialized
INFO - 2018-03-23 21:33:20 --> URI Class Initialized
INFO - 2018-03-23 21:33:20 --> Router Class Initialized
INFO - 2018-03-23 21:33:20 --> Output Class Initialized
INFO - 2018-03-23 21:33:20 --> Security Class Initialized
DEBUG - 2018-03-23 21:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:33:20 --> Input Class Initialized
INFO - 2018-03-23 21:33:20 --> Language Class Initialized
INFO - 2018-03-23 21:33:20 --> Loader Class Initialized
INFO - 2018-03-23 21:33:20 --> Helper loaded: url_helper
INFO - 2018-03-23 21:33:20 --> Helper loaded: form_helper
INFO - 2018-03-23 21:33:20 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:33:20 --> Controller Class Initialized
INFO - 2018-03-23 21:33:20 --> Model Class Initialized
INFO - 2018-03-23 21:33:20 --> Model Class Initialized
INFO - 2018-03-23 21:33:20 --> Model Class Initialized
INFO - 2018-03-23 21:33:20 --> Model Class Initialized
INFO - 2018-03-23 21:33:20 --> Model Class Initialized
INFO - 2018-03-23 21:33:20 --> Helper loaded: date_helper
INFO - 2018-03-23 21:33:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:33:25 --> Config Class Initialized
INFO - 2018-03-23 21:33:25 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:33:25 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:33:25 --> Utf8 Class Initialized
INFO - 2018-03-23 21:33:25 --> URI Class Initialized
INFO - 2018-03-23 21:33:25 --> Router Class Initialized
INFO - 2018-03-23 21:33:25 --> Output Class Initialized
INFO - 2018-03-23 21:33:25 --> Security Class Initialized
DEBUG - 2018-03-23 21:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:33:25 --> Input Class Initialized
INFO - 2018-03-23 21:33:25 --> Language Class Initialized
INFO - 2018-03-23 21:33:25 --> Loader Class Initialized
INFO - 2018-03-23 21:33:25 --> Helper loaded: url_helper
INFO - 2018-03-23 21:33:25 --> Helper loaded: form_helper
INFO - 2018-03-23 21:33:25 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:33:25 --> Controller Class Initialized
INFO - 2018-03-23 21:33:25 --> Model Class Initialized
INFO - 2018-03-23 21:33:25 --> Model Class Initialized
INFO - 2018-03-23 21:33:25 --> Helper loaded: date_helper
INFO - 2018-03-23 21:33:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:42:45 --> Config Class Initialized
INFO - 2018-03-23 21:42:45 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:42:45 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:42:45 --> Utf8 Class Initialized
INFO - 2018-03-23 21:42:45 --> URI Class Initialized
INFO - 2018-03-23 21:42:45 --> Router Class Initialized
INFO - 2018-03-23 21:42:45 --> Output Class Initialized
INFO - 2018-03-23 21:42:45 --> Security Class Initialized
DEBUG - 2018-03-23 21:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:42:45 --> Input Class Initialized
INFO - 2018-03-23 21:42:45 --> Language Class Initialized
INFO - 2018-03-23 21:42:45 --> Loader Class Initialized
INFO - 2018-03-23 21:42:45 --> Helper loaded: url_helper
INFO - 2018-03-23 21:42:45 --> Helper loaded: form_helper
INFO - 2018-03-23 21:42:45 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:42:45 --> Controller Class Initialized
INFO - 2018-03-23 21:42:45 --> Config Class Initialized
INFO - 2018-03-23 21:42:45 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:42:45 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:42:45 --> Utf8 Class Initialized
INFO - 2018-03-23 21:42:45 --> URI Class Initialized
INFO - 2018-03-23 21:42:45 --> Router Class Initialized
INFO - 2018-03-23 21:42:45 --> Output Class Initialized
INFO - 2018-03-23 21:42:45 --> Security Class Initialized
DEBUG - 2018-03-23 21:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:42:45 --> Input Class Initialized
INFO - 2018-03-23 21:42:45 --> Language Class Initialized
INFO - 2018-03-23 21:42:45 --> Loader Class Initialized
INFO - 2018-03-23 21:42:45 --> Helper loaded: url_helper
INFO - 2018-03-23 21:42:45 --> Helper loaded: form_helper
INFO - 2018-03-23 21:42:45 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:42:45 --> Controller Class Initialized
INFO - 2018-03-23 21:42:45 --> Model Class Initialized
INFO - 2018-03-23 21:42:45 --> Model Class Initialized
INFO - 2018-03-23 21:42:45 --> Model Class Initialized
INFO - 2018-03-23 21:42:45 --> Helper loaded: date_helper
INFO - 2018-03-23 21:42:48 --> Config Class Initialized
INFO - 2018-03-23 21:42:48 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:42:48 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:42:48 --> Utf8 Class Initialized
INFO - 2018-03-23 21:42:48 --> URI Class Initialized
INFO - 2018-03-23 21:42:48 --> Router Class Initialized
INFO - 2018-03-23 21:42:48 --> Output Class Initialized
INFO - 2018-03-23 21:42:48 --> Security Class Initialized
DEBUG - 2018-03-23 21:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:42:48 --> Input Class Initialized
INFO - 2018-03-23 21:42:48 --> Language Class Initialized
INFO - 2018-03-23 21:42:48 --> Loader Class Initialized
INFO - 2018-03-23 21:42:48 --> Helper loaded: url_helper
INFO - 2018-03-23 21:42:48 --> Helper loaded: form_helper
INFO - 2018-03-23 21:42:48 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:42:48 --> Controller Class Initialized
INFO - 2018-03-23 21:42:48 --> Model Class Initialized
INFO - 2018-03-23 21:42:48 --> Model Class Initialized
INFO - 2018-03-23 21:42:48 --> Model Class Initialized
INFO - 2018-03-23 21:42:48 --> Helper loaded: date_helper
INFO - 2018-03-23 21:42:48 --> Config Class Initialized
INFO - 2018-03-23 21:42:48 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:42:48 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:42:48 --> Utf8 Class Initialized
INFO - 2018-03-23 21:42:48 --> URI Class Initialized
INFO - 2018-03-23 21:42:48 --> Router Class Initialized
INFO - 2018-03-23 21:42:48 --> Output Class Initialized
INFO - 2018-03-23 21:42:48 --> Security Class Initialized
DEBUG - 2018-03-23 21:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:42:48 --> Input Class Initialized
INFO - 2018-03-23 21:42:48 --> Language Class Initialized
INFO - 2018-03-23 21:42:48 --> Loader Class Initialized
INFO - 2018-03-23 21:42:48 --> Helper loaded: url_helper
INFO - 2018-03-23 21:42:48 --> Helper loaded: form_helper
INFO - 2018-03-23 21:42:48 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:42:48 --> Controller Class Initialized
INFO - 2018-03-23 21:42:48 --> Model Class Initialized
INFO - 2018-03-23 21:42:48 --> Model Class Initialized
INFO - 2018-03-23 21:42:48 --> Model Class Initialized
INFO - 2018-03-23 21:42:48 --> Model Class Initialized
INFO - 2018-03-23 21:42:48 --> Model Class Initialized
INFO - 2018-03-23 21:42:48 --> Helper loaded: date_helper
INFO - 2018-03-23 21:42:52 --> Config Class Initialized
INFO - 2018-03-23 21:42:52 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:42:52 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:42:52 --> Utf8 Class Initialized
INFO - 2018-03-23 21:42:52 --> URI Class Initialized
INFO - 2018-03-23 21:42:52 --> Router Class Initialized
INFO - 2018-03-23 21:42:52 --> Output Class Initialized
INFO - 2018-03-23 21:42:52 --> Security Class Initialized
DEBUG - 2018-03-23 21:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:42:52 --> Input Class Initialized
INFO - 2018-03-23 21:42:52 --> Language Class Initialized
INFO - 2018-03-23 21:42:52 --> Loader Class Initialized
INFO - 2018-03-23 21:42:52 --> Helper loaded: url_helper
INFO - 2018-03-23 21:42:52 --> Helper loaded: form_helper
INFO - 2018-03-23 21:42:52 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:42:52 --> Controller Class Initialized
INFO - 2018-03-23 21:42:52 --> Model Class Initialized
INFO - 2018-03-23 21:42:52 --> Model Class Initialized
INFO - 2018-03-23 21:42:52 --> Model Class Initialized
INFO - 2018-03-23 21:42:52 --> Model Class Initialized
INFO - 2018-03-23 21:42:52 --> Model Class Initialized
INFO - 2018-03-23 21:42:52 --> Helper loaded: date_helper
INFO - 2018-03-23 21:42:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:42:55 --> Config Class Initialized
INFO - 2018-03-23 21:42:55 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:42:55 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:42:55 --> Utf8 Class Initialized
INFO - 2018-03-23 21:42:55 --> URI Class Initialized
INFO - 2018-03-23 21:42:55 --> Router Class Initialized
INFO - 2018-03-23 21:42:55 --> Output Class Initialized
INFO - 2018-03-23 21:42:55 --> Security Class Initialized
DEBUG - 2018-03-23 21:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:42:55 --> Input Class Initialized
INFO - 2018-03-23 21:42:55 --> Language Class Initialized
INFO - 2018-03-23 21:42:55 --> Loader Class Initialized
INFO - 2018-03-23 21:42:55 --> Helper loaded: url_helper
INFO - 2018-03-23 21:42:55 --> Helper loaded: form_helper
INFO - 2018-03-23 21:42:55 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:42:55 --> Controller Class Initialized
INFO - 2018-03-23 21:42:55 --> Model Class Initialized
INFO - 2018-03-23 21:42:55 --> Model Class Initialized
INFO - 2018-03-23 21:42:55 --> Model Class Initialized
INFO - 2018-03-23 21:42:55 --> Model Class Initialized
INFO - 2018-03-23 21:42:55 --> Model Class Initialized
INFO - 2018-03-23 21:42:55 --> Helper loaded: date_helper
INFO - 2018-03-23 21:42:55 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:42:56 --> Config Class Initialized
INFO - 2018-03-23 21:42:56 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:42:56 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:42:56 --> Utf8 Class Initialized
INFO - 2018-03-23 21:42:56 --> URI Class Initialized
INFO - 2018-03-23 21:42:56 --> Router Class Initialized
INFO - 2018-03-23 21:42:56 --> Output Class Initialized
INFO - 2018-03-23 21:42:56 --> Security Class Initialized
DEBUG - 2018-03-23 21:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:42:56 --> Input Class Initialized
INFO - 2018-03-23 21:42:56 --> Language Class Initialized
INFO - 2018-03-23 21:42:56 --> Loader Class Initialized
INFO - 2018-03-23 21:42:56 --> Helper loaded: url_helper
INFO - 2018-03-23 21:42:56 --> Helper loaded: form_helper
INFO - 2018-03-23 21:42:56 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:42:56 --> Controller Class Initialized
INFO - 2018-03-23 21:42:56 --> Model Class Initialized
INFO - 2018-03-23 21:42:56 --> Model Class Initialized
INFO - 2018-03-23 21:42:56 --> Model Class Initialized
INFO - 2018-03-23 21:42:56 --> Model Class Initialized
INFO - 2018-03-23 21:42:56 --> Model Class Initialized
INFO - 2018-03-23 21:42:56 --> Helper loaded: date_helper
INFO - 2018-03-23 21:42:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:43:20 --> Config Class Initialized
INFO - 2018-03-23 21:43:20 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:43:20 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:43:20 --> Utf8 Class Initialized
INFO - 2018-03-23 21:43:20 --> URI Class Initialized
INFO - 2018-03-23 21:43:20 --> Router Class Initialized
INFO - 2018-03-23 21:43:20 --> Output Class Initialized
INFO - 2018-03-23 21:43:20 --> Security Class Initialized
DEBUG - 2018-03-23 21:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:43:20 --> Input Class Initialized
INFO - 2018-03-23 21:43:20 --> Language Class Initialized
INFO - 2018-03-23 21:43:20 --> Loader Class Initialized
INFO - 2018-03-23 21:43:20 --> Helper loaded: url_helper
INFO - 2018-03-23 21:43:20 --> Helper loaded: form_helper
INFO - 2018-03-23 21:43:20 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:43:20 --> Controller Class Initialized
INFO - 2018-03-23 21:43:20 --> Model Class Initialized
INFO - 2018-03-23 21:43:20 --> Model Class Initialized
INFO - 2018-03-23 21:43:20 --> Model Class Initialized
INFO - 2018-03-23 21:43:20 --> Model Class Initialized
INFO - 2018-03-23 21:43:20 --> Model Class Initialized
INFO - 2018-03-23 21:43:20 --> Helper loaded: date_helper
INFO - 2018-03-23 21:43:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:43:33 --> Config Class Initialized
INFO - 2018-03-23 21:43:33 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:43:33 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:43:33 --> Utf8 Class Initialized
INFO - 2018-03-23 21:43:33 --> URI Class Initialized
INFO - 2018-03-23 21:43:33 --> Router Class Initialized
INFO - 2018-03-23 21:43:33 --> Output Class Initialized
INFO - 2018-03-23 21:43:33 --> Security Class Initialized
DEBUG - 2018-03-23 21:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:43:33 --> Input Class Initialized
INFO - 2018-03-23 21:43:33 --> Language Class Initialized
INFO - 2018-03-23 21:43:33 --> Loader Class Initialized
INFO - 2018-03-23 21:43:33 --> Helper loaded: url_helper
INFO - 2018-03-23 21:43:33 --> Helper loaded: form_helper
INFO - 2018-03-23 21:43:33 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:43:33 --> Controller Class Initialized
INFO - 2018-03-23 21:43:33 --> Model Class Initialized
INFO - 2018-03-23 21:43:33 --> Model Class Initialized
INFO - 2018-03-23 21:43:33 --> Helper loaded: date_helper
INFO - 2018-03-23 21:43:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:45:05 --> Config Class Initialized
INFO - 2018-03-23 21:45:05 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:45:05 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:45:05 --> Utf8 Class Initialized
INFO - 2018-03-23 21:45:05 --> URI Class Initialized
INFO - 2018-03-23 21:45:05 --> Router Class Initialized
INFO - 2018-03-23 21:45:05 --> Output Class Initialized
INFO - 2018-03-23 21:45:05 --> Security Class Initialized
DEBUG - 2018-03-23 21:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:45:05 --> Input Class Initialized
INFO - 2018-03-23 21:45:05 --> Language Class Initialized
INFO - 2018-03-23 21:45:05 --> Loader Class Initialized
INFO - 2018-03-23 21:45:05 --> Helper loaded: url_helper
INFO - 2018-03-23 21:45:05 --> Helper loaded: form_helper
INFO - 2018-03-23 21:45:05 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:45:05 --> Controller Class Initialized
INFO - 2018-03-23 21:45:05 --> Model Class Initialized
INFO - 2018-03-23 21:45:05 --> Model Class Initialized
INFO - 2018-03-23 21:45:05 --> Helper loaded: date_helper
INFO - 2018-03-23 21:45:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:45:30 --> Config Class Initialized
INFO - 2018-03-23 21:45:30 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:45:30 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:45:30 --> Utf8 Class Initialized
INFO - 2018-03-23 21:45:30 --> URI Class Initialized
INFO - 2018-03-23 21:45:30 --> Router Class Initialized
INFO - 2018-03-23 21:45:30 --> Output Class Initialized
INFO - 2018-03-23 21:45:30 --> Security Class Initialized
DEBUG - 2018-03-23 21:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:45:30 --> Input Class Initialized
INFO - 2018-03-23 21:45:30 --> Language Class Initialized
INFO - 2018-03-23 21:45:30 --> Loader Class Initialized
INFO - 2018-03-23 21:45:30 --> Helper loaded: url_helper
INFO - 2018-03-23 21:45:30 --> Helper loaded: form_helper
INFO - 2018-03-23 21:45:30 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:45:30 --> Controller Class Initialized
INFO - 2018-03-23 21:45:30 --> Model Class Initialized
INFO - 2018-03-23 21:45:30 --> Model Class Initialized
INFO - 2018-03-23 21:45:30 --> Helper loaded: date_helper
INFO - 2018-03-23 21:45:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-23 21:45:33 --> Config Class Initialized
INFO - 2018-03-23 21:45:33 --> Hooks Class Initialized
DEBUG - 2018-03-23 21:45:33 --> UTF-8 Support Enabled
INFO - 2018-03-23 21:45:33 --> Utf8 Class Initialized
INFO - 2018-03-23 21:45:33 --> URI Class Initialized
INFO - 2018-03-23 21:45:33 --> Router Class Initialized
INFO - 2018-03-23 21:45:33 --> Output Class Initialized
INFO - 2018-03-23 21:45:33 --> Security Class Initialized
DEBUG - 2018-03-23 21:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-23 21:45:33 --> Input Class Initialized
INFO - 2018-03-23 21:45:33 --> Language Class Initialized
INFO - 2018-03-23 21:45:33 --> Loader Class Initialized
INFO - 2018-03-23 21:45:33 --> Helper loaded: url_helper
INFO - 2018-03-23 21:45:33 --> Helper loaded: form_helper
INFO - 2018-03-23 21:45:33 --> Database Driver Class Initialized
DEBUG - 2018-03-23 21:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-23 21:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-23 21:45:33 --> Controller Class Initialized
INFO - 2018-03-23 21:45:33 --> Model Class Initialized
INFO - 2018-03-23 21:45:33 --> Model Class Initialized
INFO - 2018-03-23 21:45:33 --> Helper loaded: date_helper
INFO - 2018-03-23 21:45:33 --> Helper loaded: tanggal_helper
