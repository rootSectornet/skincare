<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-24 02:38:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-24 02:38:44 --> Final output sent to browser
DEBUG - 2018-03-24 02:38:44 --> Total execution time: 0.2705
INFO - 2018-03-24 02:38:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 02:38:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 02:38:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-24 02:38:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 02:38:51 --> Final output sent to browser
DEBUG - 2018-03-24 02:38:51 --> Total execution time: 1.0200
INFO - 2018-03-24 02:38:58 --> Model Class Initialized
INFO - 2018-03-24 02:38:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 02:38:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 02:38:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-24 02:38:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 02:38:58 --> Final output sent to browser
DEBUG - 2018-03-24 02:38:58 --> Total execution time: 0.3156
INFO - 2018-03-24 02:38:59 --> Model Class Initialized
INFO - 2018-03-24 02:38:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 02:38:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 02:38:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/create.php
INFO - 2018-03-24 02:38:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 02:38:59 --> Final output sent to browser
DEBUG - 2018-03-24 02:38:59 --> Total execution time: 0.1467
INFO - 2018-03-24 02:39:01 --> Model Class Initialized
INFO - 2018-03-24 02:39:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 02:39:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 02:39:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-24 02:39:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 02:39:01 --> Final output sent to browser
DEBUG - 2018-03-24 02:39:01 --> Total execution time: 0.0845
INFO - 2018-03-24 02:39:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 02:39:06 --> Final output sent to browser
DEBUG - 2018-03-24 02:39:06 --> Total execution time: 0.1045
INFO - 2018-03-24 02:39:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 02:39:09 --> Final output sent to browser
DEBUG - 2018-03-24 02:39:09 --> Total execution time: 0.0809
INFO - 2018-03-24 02:39:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 02:39:10 --> Final output sent to browser
DEBUG - 2018-03-24 02:39:10 --> Total execution time: 0.0651
INFO - 2018-03-24 02:39:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 02:39:13 --> Final output sent to browser
DEBUG - 2018-03-24 02:39:13 --> Total execution time: 0.0726
INFO - 2018-03-24 02:39:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 02:39:19 --> Final output sent to browser
DEBUG - 2018-03-24 02:39:19 --> Total execution time: 0.0620
INFO - 2018-03-24 02:39:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 02:39:22 --> Final output sent to browser
DEBUG - 2018-03-24 02:39:22 --> Total execution time: 0.0703
INFO - 2018-03-24 02:39:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 02:39:26 --> Final output sent to browser
DEBUG - 2018-03-24 02:39:26 --> Total execution time: 0.0695
INFO - 2018-03-24 02:39:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 02:39:28 --> Final output sent to browser
DEBUG - 2018-03-24 02:39:28 --> Total execution time: 0.0646
INFO - 2018-03-24 02:39:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 02:39:31 --> Final output sent to browser
DEBUG - 2018-03-24 02:39:31 --> Total execution time: 0.0734
INFO - 2018-03-24 02:39:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 02:39:50 --> Final output sent to browser
DEBUG - 2018-03-24 02:39:50 --> Total execution time: 0.0762
INFO - 2018-03-24 02:39:52 --> Model Class Initialized
INFO - 2018-03-24 02:39:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 02:39:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 02:39:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/edit.php
INFO - 2018-03-24 02:39:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 02:39:52 --> Final output sent to browser
DEBUG - 2018-03-24 02:39:52 --> Total execution time: 0.1420
INFO - 2018-03-24 02:39:56 --> Model Class Initialized
INFO - 2018-03-24 02:39:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 02:39:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 02:39:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-24 02:39:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 02:39:56 --> Final output sent to browser
DEBUG - 2018-03-24 02:39:56 --> Total execution time: 0.0877
INFO - 2018-03-24 02:40:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 02:40:00 --> Final output sent to browser
DEBUG - 2018-03-24 02:40:00 --> Total execution time: 0.0962
INFO - 2018-03-24 02:40:02 --> Model Class Initialized
INFO - 2018-03-24 02:40:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 02:40:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 02:40:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 02:40:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 02:40:02 --> Final output sent to browser
DEBUG - 2018-03-24 02:40:02 --> Total execution time: 0.1216
INFO - 2018-03-24 02:47:42 --> Model Class Initialized
INFO - 2018-03-24 02:47:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 02:47:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 02:47:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 02:47:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 02:47:42 --> Final output sent to browser
DEBUG - 2018-03-24 02:47:42 --> Total execution time: 0.0749
INFO - 2018-03-24 02:50:22 --> Model Class Initialized
INFO - 2018-03-24 02:50:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 02:50:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 02:50:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 02:50:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 02:50:22 --> Final output sent to browser
DEBUG - 2018-03-24 02:50:22 --> Total execution time: 0.0753
INFO - 2018-03-24 02:52:53 --> Model Class Initialized
INFO - 2018-03-24 02:52:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 02:52:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 02:52:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 02:52:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 02:52:53 --> Final output sent to browser
DEBUG - 2018-03-24 02:52:53 --> Total execution time: 0.0788
INFO - 2018-03-24 02:53:01 --> Final output sent to browser
DEBUG - 2018-03-24 02:53:01 --> Total execution time: 0.0771
INFO - 2018-03-24 02:58:41 --> Model Class Initialized
INFO - 2018-03-24 02:58:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 02:58:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 02:58:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 02:58:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 02:58:41 --> Final output sent to browser
DEBUG - 2018-03-24 02:58:41 --> Total execution time: 0.0893
INFO - 2018-03-24 02:58:45 --> Final output sent to browser
DEBUG - 2018-03-24 02:58:45 --> Total execution time: 0.0534
INFO - 2018-03-24 03:01:03 --> Model Class Initialized
INFO - 2018-03-24 03:01:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:01:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:01:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 03:01:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:01:03 --> Final output sent to browser
DEBUG - 2018-03-24 03:01:03 --> Total execution time: 0.0782
INFO - 2018-03-24 03:01:17 --> Model Class Initialized
INFO - 2018-03-24 03:01:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:01:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:01:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 03:01:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:01:17 --> Final output sent to browser
DEBUG - 2018-03-24 03:01:17 --> Total execution time: 0.0768
INFO - 2018-03-24 03:01:26 --> Model Class Initialized
INFO - 2018-03-24 03:01:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:01:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:01:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 03:01:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:01:26 --> Final output sent to browser
DEBUG - 2018-03-24 03:01:26 --> Total execution time: 0.0822
INFO - 2018-03-24 03:01:33 --> Model Class Initialized
INFO - 2018-03-24 03:01:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:01:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:01:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 03:01:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:01:33 --> Final output sent to browser
DEBUG - 2018-03-24 03:01:33 --> Total execution time: 0.0855
INFO - 2018-03-24 03:01:45 --> Final output sent to browser
DEBUG - 2018-03-24 03:01:45 --> Total execution time: 0.0522
INFO - 2018-03-24 03:01:49 --> Final output sent to browser
DEBUG - 2018-03-24 03:01:49 --> Total execution time: 0.0504
INFO - 2018-03-24 03:03:09 --> Model Class Initialized
INFO - 2018-03-24 03:03:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:03:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:03:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 03:03:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:03:09 --> Final output sent to browser
DEBUG - 2018-03-24 03:03:09 --> Total execution time: 0.0836
INFO - 2018-03-24 03:09:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-24 03:09:11 --> Final output sent to browser
DEBUG - 2018-03-24 03:09:11 --> Total execution time: 0.0603
INFO - 2018-03-24 03:09:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:09:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:09:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-24 03:09:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:09:13 --> Final output sent to browser
DEBUG - 2018-03-24 03:09:13 --> Total execution time: 0.1142
INFO - 2018-03-24 03:09:16 --> Model Class Initialized
INFO - 2018-03-24 03:09:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:09:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:09:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-24 03:09:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:09:16 --> Final output sent to browser
DEBUG - 2018-03-24 03:09:16 --> Total execution time: 0.1025
INFO - 2018-03-24 03:09:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 03:09:19 --> Final output sent to browser
DEBUG - 2018-03-24 03:09:19 --> Total execution time: 0.0764
INFO - 2018-03-24 03:09:20 --> Model Class Initialized
INFO - 2018-03-24 03:09:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:09:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:09:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 03:09:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:09:20 --> Final output sent to browser
DEBUG - 2018-03-24 03:09:20 --> Total execution time: 0.1527
INFO - 2018-03-24 03:09:58 --> Model Class Initialized
INFO - 2018-03-24 03:09:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:09:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:09:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 03:09:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:09:58 --> Final output sent to browser
DEBUG - 2018-03-24 03:09:58 --> Total execution time: 0.0870
INFO - 2018-03-24 03:22:04 --> Final output sent to browser
DEBUG - 2018-03-24 03:22:04 --> Total execution time: 0.0610
INFO - 2018-03-24 03:25:11 --> Model Class Initialized
INFO - 2018-03-24 03:25:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:25:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:25:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 03:25:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:25:11 --> Final output sent to browser
DEBUG - 2018-03-24 03:25:11 --> Total execution time: 0.0854
INFO - 2018-03-24 03:25:15 --> Final output sent to browser
DEBUG - 2018-03-24 03:25:15 --> Total execution time: 0.0602
INFO - 2018-03-24 03:30:07 --> Model Class Initialized
INFO - 2018-03-24 03:30:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:30:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:30:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 03:30:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:30:07 --> Final output sent to browser
DEBUG - 2018-03-24 03:30:07 --> Total execution time: 0.0756
INFO - 2018-03-24 03:30:11 --> Final output sent to browser
DEBUG - 2018-03-24 03:30:11 --> Total execution time: 0.0514
INFO - 2018-03-24 03:30:41 --> Model Class Initialized
INFO - 2018-03-24 03:30:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:30:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:30:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 03:30:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:30:41 --> Final output sent to browser
DEBUG - 2018-03-24 03:30:41 --> Total execution time: 0.0946
INFO - 2018-03-24 03:30:46 --> Final output sent to browser
DEBUG - 2018-03-24 03:30:46 --> Total execution time: 0.0561
INFO - 2018-03-24 03:31:17 --> Model Class Initialized
INFO - 2018-03-24 03:31:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:31:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:31:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 03:31:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:31:17 --> Final output sent to browser
DEBUG - 2018-03-24 03:31:17 --> Total execution time: 0.1037
INFO - 2018-03-24 03:31:22 --> Final output sent to browser
DEBUG - 2018-03-24 03:31:22 --> Total execution time: 0.0620
INFO - 2018-03-24 03:32:17 --> Model Class Initialized
INFO - 2018-03-24 03:32:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:32:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:32:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 03:32:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:32:17 --> Final output sent to browser
DEBUG - 2018-03-24 03:32:17 --> Total execution time: 0.1069
INFO - 2018-03-24 03:32:21 --> Final output sent to browser
DEBUG - 2018-03-24 03:32:21 --> Total execution time: 0.0593
INFO - 2018-03-24 03:32:48 --> Model Class Initialized
INFO - 2018-03-24 03:32:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:32:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:32:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 03:32:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:32:49 --> Final output sent to browser
DEBUG - 2018-03-24 03:32:49 --> Total execution time: 0.0765
INFO - 2018-03-24 03:32:53 --> Final output sent to browser
DEBUG - 2018-03-24 03:32:53 --> Total execution time: 0.0508
INFO - 2018-03-24 03:33:20 --> Model Class Initialized
INFO - 2018-03-24 03:33:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:33:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:33:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 03:33:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:33:20 --> Final output sent to browser
DEBUG - 2018-03-24 03:33:20 --> Total execution time: 0.0967
INFO - 2018-03-24 03:33:25 --> Final output sent to browser
DEBUG - 2018-03-24 03:33:25 --> Total execution time: 0.0601
INFO - 2018-03-24 03:42:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-24 03:42:45 --> Final output sent to browser
DEBUG - 2018-03-24 03:42:45 --> Total execution time: 0.0717
INFO - 2018-03-24 03:42:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:42:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:42:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-24 03:42:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:42:48 --> Final output sent to browser
DEBUG - 2018-03-24 03:42:48 --> Total execution time: 0.1952
INFO - 2018-03-24 03:42:52 --> Model Class Initialized
INFO - 2018-03-24 03:42:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:42:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:42:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-24 03:42:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:42:52 --> Final output sent to browser
DEBUG - 2018-03-24 03:42:52 --> Total execution time: 0.0949
INFO - 2018-03-24 03:42:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 03:42:55 --> Final output sent to browser
DEBUG - 2018-03-24 03:42:55 --> Total execution time: 0.0865
INFO - 2018-03-24 03:42:57 --> Model Class Initialized
INFO - 2018-03-24 03:42:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:42:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:42:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 03:42:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:42:57 --> Final output sent to browser
DEBUG - 2018-03-24 03:42:57 --> Total execution time: 0.1933
INFO - 2018-03-24 03:43:20 --> Model Class Initialized
INFO - 2018-03-24 03:43:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:43:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:43:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 03:43:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:43:20 --> Final output sent to browser
DEBUG - 2018-03-24 03:43:20 --> Total execution time: 0.0855
INFO - 2018-03-24 03:43:33 --> Final output sent to browser
DEBUG - 2018-03-24 03:43:33 --> Total execution time: 0.0534
INFO - 2018-03-24 03:45:05 --> Model Class Initialized
INFO - 2018-03-24 03:45:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:45:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:45:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-24 03:45:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:45:05 --> Final output sent to browser
DEBUG - 2018-03-24 03:45:05 --> Total execution time: 0.2083
INFO - 2018-03-24 03:45:30 --> Model Class Initialized
INFO - 2018-03-24 03:45:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:45:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:45:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-24 03:45:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:45:30 --> Final output sent to browser
DEBUG - 2018-03-24 03:45:30 --> Total execution time: 0.1451
INFO - 2018-03-24 03:45:33 --> Model Class Initialized
INFO - 2018-03-24 03:45:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 03:45:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 03:45:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-24 03:45:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 03:45:33 --> Final output sent to browser
DEBUG - 2018-03-24 03:45:33 --> Total execution time: 0.0709
INFO - 2018-03-24 09:07:47 --> Config Class Initialized
INFO - 2018-03-24 09:07:47 --> Hooks Class Initialized
DEBUG - 2018-03-24 09:07:47 --> UTF-8 Support Enabled
INFO - 2018-03-24 09:07:47 --> Utf8 Class Initialized
INFO - 2018-03-24 09:07:47 --> URI Class Initialized
INFO - 2018-03-24 09:07:47 --> Router Class Initialized
INFO - 2018-03-24 09:07:47 --> Output Class Initialized
INFO - 2018-03-24 09:07:47 --> Security Class Initialized
DEBUG - 2018-03-24 09:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 09:07:47 --> Input Class Initialized
INFO - 2018-03-24 09:07:47 --> Language Class Initialized
INFO - 2018-03-24 09:07:47 --> Loader Class Initialized
INFO - 2018-03-24 09:07:48 --> Helper loaded: url_helper
INFO - 2018-03-24 09:07:48 --> Helper loaded: form_helper
INFO - 2018-03-24 09:07:48 --> Database Driver Class Initialized
DEBUG - 2018-03-24 09:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 09:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 09:07:48 --> Controller Class Initialized
INFO - 2018-03-24 09:07:48 --> Config Class Initialized
INFO - 2018-03-24 09:07:48 --> Hooks Class Initialized
DEBUG - 2018-03-24 09:07:48 --> UTF-8 Support Enabled
INFO - 2018-03-24 09:07:48 --> Utf8 Class Initialized
INFO - 2018-03-24 09:07:48 --> URI Class Initialized
INFO - 2018-03-24 09:07:48 --> Router Class Initialized
INFO - 2018-03-24 09:07:48 --> Output Class Initialized
INFO - 2018-03-24 09:07:48 --> Security Class Initialized
DEBUG - 2018-03-24 09:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 09:07:48 --> Input Class Initialized
INFO - 2018-03-24 09:07:48 --> Language Class Initialized
INFO - 2018-03-24 09:07:48 --> Loader Class Initialized
INFO - 2018-03-24 09:07:48 --> Helper loaded: url_helper
INFO - 2018-03-24 09:07:48 --> Helper loaded: form_helper
INFO - 2018-03-24 09:07:48 --> Database Driver Class Initialized
DEBUG - 2018-03-24 09:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 09:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 09:07:48 --> Controller Class Initialized
INFO - 2018-03-24 09:07:48 --> Model Class Initialized
INFO - 2018-03-24 09:07:48 --> Model Class Initialized
INFO - 2018-03-24 09:07:48 --> Model Class Initialized
INFO - 2018-03-24 09:07:48 --> Helper loaded: date_helper
INFO - 2018-03-24 15:07:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-24 15:07:48 --> Final output sent to browser
DEBUG - 2018-03-24 15:07:48 --> Total execution time: 0.3928
INFO - 2018-03-24 09:07:52 --> Config Class Initialized
INFO - 2018-03-24 09:07:52 --> Hooks Class Initialized
DEBUG - 2018-03-24 09:07:52 --> UTF-8 Support Enabled
INFO - 2018-03-24 09:07:52 --> Utf8 Class Initialized
INFO - 2018-03-24 09:07:52 --> URI Class Initialized
INFO - 2018-03-24 09:07:52 --> Router Class Initialized
INFO - 2018-03-24 09:07:52 --> Output Class Initialized
INFO - 2018-03-24 09:07:52 --> Security Class Initialized
DEBUG - 2018-03-24 09:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 09:07:52 --> Input Class Initialized
INFO - 2018-03-24 09:07:52 --> Language Class Initialized
INFO - 2018-03-24 09:07:52 --> Loader Class Initialized
INFO - 2018-03-24 09:07:52 --> Helper loaded: url_helper
INFO - 2018-03-24 09:07:52 --> Helper loaded: form_helper
INFO - 2018-03-24 09:07:52 --> Database Driver Class Initialized
DEBUG - 2018-03-24 09:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 09:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 09:07:52 --> Controller Class Initialized
INFO - 2018-03-24 09:07:52 --> Model Class Initialized
INFO - 2018-03-24 09:07:52 --> Model Class Initialized
INFO - 2018-03-24 09:07:52 --> Model Class Initialized
INFO - 2018-03-24 09:07:52 --> Helper loaded: date_helper
INFO - 2018-03-24 09:07:52 --> Config Class Initialized
INFO - 2018-03-24 09:07:52 --> Hooks Class Initialized
DEBUG - 2018-03-24 09:07:52 --> UTF-8 Support Enabled
INFO - 2018-03-24 09:07:52 --> Utf8 Class Initialized
INFO - 2018-03-24 09:07:52 --> URI Class Initialized
INFO - 2018-03-24 09:07:52 --> Router Class Initialized
INFO - 2018-03-24 09:07:52 --> Output Class Initialized
INFO - 2018-03-24 09:07:52 --> Security Class Initialized
DEBUG - 2018-03-24 09:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 09:07:52 --> Input Class Initialized
INFO - 2018-03-24 09:07:52 --> Language Class Initialized
INFO - 2018-03-24 09:07:52 --> Loader Class Initialized
INFO - 2018-03-24 09:07:52 --> Helper loaded: url_helper
INFO - 2018-03-24 09:07:52 --> Helper loaded: form_helper
INFO - 2018-03-24 09:07:52 --> Database Driver Class Initialized
DEBUG - 2018-03-24 09:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 09:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 09:07:52 --> Controller Class Initialized
INFO - 2018-03-24 09:07:52 --> Model Class Initialized
INFO - 2018-03-24 09:07:52 --> Model Class Initialized
INFO - 2018-03-24 09:07:52 --> Model Class Initialized
INFO - 2018-03-24 09:07:53 --> Model Class Initialized
INFO - 2018-03-24 09:07:53 --> Model Class Initialized
INFO - 2018-03-24 09:07:53 --> Helper loaded: date_helper
INFO - 2018-03-24 15:07:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 15:07:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 15:07:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-24 15:07:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 15:07:53 --> Final output sent to browser
DEBUG - 2018-03-24 15:07:53 --> Total execution time: 0.1989
INFO - 2018-03-24 12:46:57 --> Config Class Initialized
INFO - 2018-03-24 12:46:57 --> Hooks Class Initialized
DEBUG - 2018-03-24 12:46:57 --> UTF-8 Support Enabled
INFO - 2018-03-24 12:46:57 --> Utf8 Class Initialized
INFO - 2018-03-24 12:46:57 --> URI Class Initialized
INFO - 2018-03-24 12:46:57 --> Router Class Initialized
INFO - 2018-03-24 12:46:57 --> Output Class Initialized
INFO - 2018-03-24 12:46:57 --> Security Class Initialized
DEBUG - 2018-03-24 12:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 12:46:57 --> Input Class Initialized
INFO - 2018-03-24 12:46:57 --> Language Class Initialized
INFO - 2018-03-24 12:46:57 --> Loader Class Initialized
INFO - 2018-03-24 12:46:57 --> Helper loaded: url_helper
INFO - 2018-03-24 12:46:57 --> Helper loaded: form_helper
INFO - 2018-03-24 12:46:57 --> Database Driver Class Initialized
DEBUG - 2018-03-24 12:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 12:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 12:46:57 --> Controller Class Initialized
INFO - 2018-03-24 12:46:57 --> Config Class Initialized
INFO - 2018-03-24 12:46:57 --> Hooks Class Initialized
DEBUG - 2018-03-24 12:46:57 --> UTF-8 Support Enabled
INFO - 2018-03-24 12:46:57 --> Utf8 Class Initialized
INFO - 2018-03-24 12:46:57 --> URI Class Initialized
INFO - 2018-03-24 12:46:57 --> Router Class Initialized
INFO - 2018-03-24 12:46:57 --> Output Class Initialized
INFO - 2018-03-24 12:46:57 --> Security Class Initialized
DEBUG - 2018-03-24 12:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 12:46:57 --> Input Class Initialized
INFO - 2018-03-24 12:46:57 --> Language Class Initialized
INFO - 2018-03-24 12:46:57 --> Loader Class Initialized
INFO - 2018-03-24 12:46:57 --> Helper loaded: url_helper
INFO - 2018-03-24 12:46:57 --> Helper loaded: form_helper
INFO - 2018-03-24 12:46:57 --> Database Driver Class Initialized
DEBUG - 2018-03-24 12:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 12:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 12:46:57 --> Controller Class Initialized
INFO - 2018-03-24 12:46:57 --> Model Class Initialized
INFO - 2018-03-24 12:46:57 --> Model Class Initialized
INFO - 2018-03-24 12:46:57 --> Model Class Initialized
INFO - 2018-03-24 12:46:58 --> Helper loaded: date_helper
INFO - 2018-03-24 18:46:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-24 18:46:58 --> Final output sent to browser
DEBUG - 2018-03-24 18:46:58 --> Total execution time: 0.2195
INFO - 2018-03-24 12:47:03 --> Config Class Initialized
INFO - 2018-03-24 12:47:03 --> Hooks Class Initialized
DEBUG - 2018-03-24 12:47:03 --> UTF-8 Support Enabled
INFO - 2018-03-24 12:47:03 --> Utf8 Class Initialized
INFO - 2018-03-24 12:47:03 --> URI Class Initialized
INFO - 2018-03-24 12:47:03 --> Router Class Initialized
INFO - 2018-03-24 12:47:03 --> Output Class Initialized
INFO - 2018-03-24 12:47:03 --> Security Class Initialized
DEBUG - 2018-03-24 12:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 12:47:03 --> Input Class Initialized
INFO - 2018-03-24 12:47:03 --> Language Class Initialized
INFO - 2018-03-24 12:47:03 --> Loader Class Initialized
INFO - 2018-03-24 12:47:03 --> Helper loaded: url_helper
INFO - 2018-03-24 12:47:03 --> Helper loaded: form_helper
INFO - 2018-03-24 12:47:03 --> Database Driver Class Initialized
DEBUG - 2018-03-24 12:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 12:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 12:47:03 --> Controller Class Initialized
INFO - 2018-03-24 12:47:03 --> Model Class Initialized
INFO - 2018-03-24 12:47:03 --> Model Class Initialized
INFO - 2018-03-24 12:47:03 --> Model Class Initialized
INFO - 2018-03-24 12:47:03 --> Helper loaded: date_helper
INFO - 2018-03-24 12:47:03 --> Config Class Initialized
INFO - 2018-03-24 12:47:03 --> Hooks Class Initialized
DEBUG - 2018-03-24 12:47:03 --> UTF-8 Support Enabled
INFO - 2018-03-24 12:47:03 --> Utf8 Class Initialized
INFO - 2018-03-24 12:47:03 --> URI Class Initialized
INFO - 2018-03-24 12:47:03 --> Router Class Initialized
INFO - 2018-03-24 12:47:03 --> Output Class Initialized
INFO - 2018-03-24 12:47:03 --> Security Class Initialized
DEBUG - 2018-03-24 12:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 12:47:03 --> Input Class Initialized
INFO - 2018-03-24 12:47:03 --> Language Class Initialized
INFO - 2018-03-24 12:47:03 --> Loader Class Initialized
INFO - 2018-03-24 12:47:03 --> Helper loaded: url_helper
INFO - 2018-03-24 12:47:03 --> Helper loaded: form_helper
INFO - 2018-03-24 12:47:03 --> Database Driver Class Initialized
DEBUG - 2018-03-24 12:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 12:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 12:47:03 --> Controller Class Initialized
INFO - 2018-03-24 12:47:03 --> Model Class Initialized
INFO - 2018-03-24 12:47:03 --> Model Class Initialized
INFO - 2018-03-24 12:47:03 --> Model Class Initialized
INFO - 2018-03-24 12:47:03 --> Model Class Initialized
INFO - 2018-03-24 12:47:03 --> Model Class Initialized
INFO - 2018-03-24 12:47:03 --> Helper loaded: date_helper
INFO - 2018-03-24 18:47:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 18:47:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 18:47:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-24 18:47:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 18:47:03 --> Final output sent to browser
DEBUG - 2018-03-24 18:47:03 --> Total execution time: 0.5094
INFO - 2018-03-24 12:47:08 --> Config Class Initialized
INFO - 2018-03-24 12:47:08 --> Hooks Class Initialized
DEBUG - 2018-03-24 12:47:08 --> UTF-8 Support Enabled
INFO - 2018-03-24 12:47:08 --> Utf8 Class Initialized
INFO - 2018-03-24 12:47:08 --> URI Class Initialized
INFO - 2018-03-24 12:47:08 --> Router Class Initialized
INFO - 2018-03-24 12:47:08 --> Output Class Initialized
INFO - 2018-03-24 12:47:08 --> Security Class Initialized
DEBUG - 2018-03-24 12:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 12:47:08 --> Input Class Initialized
INFO - 2018-03-24 12:47:08 --> Language Class Initialized
INFO - 2018-03-24 12:47:08 --> Loader Class Initialized
INFO - 2018-03-24 12:47:08 --> Helper loaded: url_helper
INFO - 2018-03-24 12:47:08 --> Helper loaded: form_helper
INFO - 2018-03-24 12:47:08 --> Database Driver Class Initialized
DEBUG - 2018-03-24 12:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 12:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 12:47:08 --> Controller Class Initialized
INFO - 2018-03-24 12:47:08 --> Model Class Initialized
INFO - 2018-03-24 12:47:08 --> Model Class Initialized
INFO - 2018-03-24 12:47:08 --> Model Class Initialized
INFO - 2018-03-24 12:47:08 --> Model Class Initialized
INFO - 2018-03-24 12:47:08 --> Model Class Initialized
INFO - 2018-03-24 12:47:08 --> Helper loaded: date_helper
INFO - 2018-03-24 12:47:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:47:08 --> Model Class Initialized
INFO - 2018-03-24 18:47:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 18:47:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 18:47:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-24 18:47:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 18:47:08 --> Final output sent to browser
DEBUG - 2018-03-24 18:47:08 --> Total execution time: 0.2162
INFO - 2018-03-24 12:47:13 --> Config Class Initialized
INFO - 2018-03-24 12:47:13 --> Hooks Class Initialized
DEBUG - 2018-03-24 12:47:13 --> UTF-8 Support Enabled
INFO - 2018-03-24 12:47:13 --> Utf8 Class Initialized
INFO - 2018-03-24 12:47:13 --> URI Class Initialized
INFO - 2018-03-24 12:47:13 --> Router Class Initialized
INFO - 2018-03-24 12:47:13 --> Output Class Initialized
INFO - 2018-03-24 12:47:13 --> Security Class Initialized
DEBUG - 2018-03-24 12:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 12:47:13 --> Input Class Initialized
INFO - 2018-03-24 12:47:13 --> Language Class Initialized
INFO - 2018-03-24 12:47:13 --> Loader Class Initialized
INFO - 2018-03-24 12:47:13 --> Helper loaded: url_helper
INFO - 2018-03-24 12:47:13 --> Helper loaded: form_helper
INFO - 2018-03-24 12:47:13 --> Database Driver Class Initialized
DEBUG - 2018-03-24 12:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 12:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 12:47:13 --> Controller Class Initialized
INFO - 2018-03-24 12:47:13 --> Model Class Initialized
INFO - 2018-03-24 12:47:13 --> Model Class Initialized
INFO - 2018-03-24 12:47:13 --> Model Class Initialized
INFO - 2018-03-24 12:47:13 --> Model Class Initialized
INFO - 2018-03-24 12:47:13 --> Model Class Initialized
INFO - 2018-03-24 12:47:13 --> Helper loaded: date_helper
INFO - 2018-03-24 12:47:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:47:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 18:47:13 --> Final output sent to browser
DEBUG - 2018-03-24 18:47:13 --> Total execution time: 0.1183
INFO - 2018-03-24 12:47:14 --> Config Class Initialized
INFO - 2018-03-24 12:47:14 --> Hooks Class Initialized
DEBUG - 2018-03-24 12:47:14 --> UTF-8 Support Enabled
INFO - 2018-03-24 12:47:14 --> Utf8 Class Initialized
INFO - 2018-03-24 12:47:14 --> URI Class Initialized
INFO - 2018-03-24 12:47:14 --> Router Class Initialized
INFO - 2018-03-24 12:47:14 --> Output Class Initialized
INFO - 2018-03-24 12:47:14 --> Security Class Initialized
DEBUG - 2018-03-24 12:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 12:47:14 --> Input Class Initialized
INFO - 2018-03-24 12:47:14 --> Language Class Initialized
INFO - 2018-03-24 12:47:14 --> Loader Class Initialized
INFO - 2018-03-24 12:47:14 --> Helper loaded: url_helper
INFO - 2018-03-24 12:47:14 --> Helper loaded: form_helper
INFO - 2018-03-24 12:47:15 --> Database Driver Class Initialized
DEBUG - 2018-03-24 12:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 12:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 12:47:15 --> Controller Class Initialized
INFO - 2018-03-24 12:47:15 --> Model Class Initialized
INFO - 2018-03-24 12:47:15 --> Model Class Initialized
INFO - 2018-03-24 12:47:15 --> Model Class Initialized
INFO - 2018-03-24 12:47:15 --> Model Class Initialized
INFO - 2018-03-24 12:47:15 --> Model Class Initialized
INFO - 2018-03-24 12:47:15 --> Helper loaded: date_helper
INFO - 2018-03-24 12:47:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:47:15 --> Model Class Initialized
INFO - 2018-03-24 18:47:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 18:47:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 18:47:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 18:47:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 18:47:15 --> Final output sent to browser
DEBUG - 2018-03-24 18:47:15 --> Total execution time: 0.1151
INFO - 2018-03-24 12:48:29 --> Config Class Initialized
INFO - 2018-03-24 12:48:29 --> Hooks Class Initialized
DEBUG - 2018-03-24 12:48:29 --> UTF-8 Support Enabled
INFO - 2018-03-24 12:48:29 --> Utf8 Class Initialized
INFO - 2018-03-24 12:48:29 --> URI Class Initialized
INFO - 2018-03-24 12:48:29 --> Router Class Initialized
INFO - 2018-03-24 12:48:29 --> Output Class Initialized
INFO - 2018-03-24 12:48:29 --> Security Class Initialized
DEBUG - 2018-03-24 12:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 12:48:29 --> Input Class Initialized
INFO - 2018-03-24 12:48:29 --> Language Class Initialized
INFO - 2018-03-24 12:48:29 --> Loader Class Initialized
INFO - 2018-03-24 12:48:29 --> Helper loaded: url_helper
INFO - 2018-03-24 12:48:29 --> Helper loaded: form_helper
INFO - 2018-03-24 12:48:29 --> Database Driver Class Initialized
DEBUG - 2018-03-24 12:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 12:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 12:48:29 --> Controller Class Initialized
INFO - 2018-03-24 12:48:29 --> Model Class Initialized
INFO - 2018-03-24 12:48:29 --> Model Class Initialized
INFO - 2018-03-24 12:48:29 --> Model Class Initialized
INFO - 2018-03-24 12:48:29 --> Model Class Initialized
INFO - 2018-03-24 12:48:29 --> Model Class Initialized
INFO - 2018-03-24 12:48:29 --> Helper loaded: date_helper
INFO - 2018-03-24 12:48:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:48:29 --> Model Class Initialized
INFO - 2018-03-24 18:48:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 18:48:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 18:48:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 18:48:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 18:48:29 --> Final output sent to browser
DEBUG - 2018-03-24 18:48:29 --> Total execution time: 0.0914
INFO - 2018-03-24 12:48:44 --> Config Class Initialized
INFO - 2018-03-24 12:48:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 12:48:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 12:48:44 --> Utf8 Class Initialized
INFO - 2018-03-24 12:48:44 --> URI Class Initialized
INFO - 2018-03-24 12:48:44 --> Router Class Initialized
INFO - 2018-03-24 12:48:44 --> Output Class Initialized
INFO - 2018-03-24 12:48:44 --> Security Class Initialized
DEBUG - 2018-03-24 12:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 12:48:44 --> Input Class Initialized
INFO - 2018-03-24 12:48:44 --> Language Class Initialized
INFO - 2018-03-24 12:48:44 --> Loader Class Initialized
INFO - 2018-03-24 12:48:44 --> Helper loaded: url_helper
INFO - 2018-03-24 12:48:44 --> Helper loaded: form_helper
INFO - 2018-03-24 12:48:44 --> Database Driver Class Initialized
DEBUG - 2018-03-24 12:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 12:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 12:48:44 --> Controller Class Initialized
INFO - 2018-03-24 12:48:44 --> Model Class Initialized
INFO - 2018-03-24 12:48:44 --> Model Class Initialized
INFO - 2018-03-24 12:48:44 --> Helper loaded: date_helper
INFO - 2018-03-24 12:48:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:48:44 --> Final output sent to browser
DEBUG - 2018-03-24 18:48:44 --> Total execution time: 0.1263
INFO - 2018-03-24 12:48:44 --> Config Class Initialized
INFO - 2018-03-24 12:48:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 12:48:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 12:48:44 --> Utf8 Class Initialized
INFO - 2018-03-24 12:48:44 --> URI Class Initialized
INFO - 2018-03-24 12:48:44 --> Router Class Initialized
INFO - 2018-03-24 12:48:44 --> Output Class Initialized
INFO - 2018-03-24 12:48:44 --> Security Class Initialized
DEBUG - 2018-03-24 12:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 12:48:44 --> Input Class Initialized
INFO - 2018-03-24 12:48:44 --> Language Class Initialized
INFO - 2018-03-24 12:48:44 --> Loader Class Initialized
INFO - 2018-03-24 12:48:44 --> Helper loaded: url_helper
INFO - 2018-03-24 12:48:44 --> Helper loaded: form_helper
INFO - 2018-03-24 12:48:44 --> Database Driver Class Initialized
DEBUG - 2018-03-24 12:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 12:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 12:48:44 --> Controller Class Initialized
INFO - 2018-03-24 12:48:44 --> Model Class Initialized
INFO - 2018-03-24 12:48:44 --> Model Class Initialized
INFO - 2018-03-24 12:48:44 --> Helper loaded: date_helper
INFO - 2018-03-24 12:48:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:48:44 --> Final output sent to browser
DEBUG - 2018-03-24 18:48:44 --> Total execution time: 0.0926
INFO - 2018-03-24 12:59:39 --> Config Class Initialized
INFO - 2018-03-24 12:59:39 --> Hooks Class Initialized
DEBUG - 2018-03-24 12:59:39 --> UTF-8 Support Enabled
INFO - 2018-03-24 12:59:39 --> Utf8 Class Initialized
INFO - 2018-03-24 12:59:39 --> URI Class Initialized
INFO - 2018-03-24 12:59:39 --> Router Class Initialized
INFO - 2018-03-24 12:59:39 --> Output Class Initialized
INFO - 2018-03-24 12:59:39 --> Security Class Initialized
DEBUG - 2018-03-24 12:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 12:59:39 --> Input Class Initialized
INFO - 2018-03-24 12:59:39 --> Language Class Initialized
INFO - 2018-03-24 12:59:39 --> Loader Class Initialized
INFO - 2018-03-24 12:59:39 --> Helper loaded: url_helper
INFO - 2018-03-24 12:59:39 --> Helper loaded: form_helper
INFO - 2018-03-24 12:59:39 --> Database Driver Class Initialized
DEBUG - 2018-03-24 12:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 12:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 12:59:39 --> Controller Class Initialized
INFO - 2018-03-24 12:59:39 --> Model Class Initialized
INFO - 2018-03-24 12:59:39 --> Model Class Initialized
INFO - 2018-03-24 12:59:39 --> Model Class Initialized
INFO - 2018-03-24 12:59:39 --> Model Class Initialized
INFO - 2018-03-24 12:59:39 --> Model Class Initialized
INFO - 2018-03-24 12:59:39 --> Helper loaded: date_helper
INFO - 2018-03-24 12:59:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:59:39 --> Model Class Initialized
INFO - 2018-03-24 18:59:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 18:59:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 18:59:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 18:59:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 18:59:39 --> Final output sent to browser
DEBUG - 2018-03-24 18:59:39 --> Total execution time: 0.0988
INFO - 2018-03-24 12:59:44 --> Config Class Initialized
INFO - 2018-03-24 12:59:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 12:59:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 12:59:44 --> Utf8 Class Initialized
INFO - 2018-03-24 12:59:44 --> URI Class Initialized
INFO - 2018-03-24 12:59:44 --> Router Class Initialized
INFO - 2018-03-24 12:59:44 --> Output Class Initialized
INFO - 2018-03-24 12:59:44 --> Security Class Initialized
DEBUG - 2018-03-24 12:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 12:59:44 --> Input Class Initialized
INFO - 2018-03-24 12:59:44 --> Language Class Initialized
INFO - 2018-03-24 12:59:44 --> Loader Class Initialized
INFO - 2018-03-24 12:59:44 --> Helper loaded: url_helper
INFO - 2018-03-24 12:59:44 --> Helper loaded: form_helper
INFO - 2018-03-24 12:59:44 --> Database Driver Class Initialized
DEBUG - 2018-03-24 12:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 12:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 12:59:44 --> Controller Class Initialized
INFO - 2018-03-24 12:59:44 --> Model Class Initialized
INFO - 2018-03-24 12:59:44 --> Model Class Initialized
INFO - 2018-03-24 12:59:44 --> Helper loaded: date_helper
INFO - 2018-03-24 12:59:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:59:44 --> Final output sent to browser
DEBUG - 2018-03-24 18:59:44 --> Total execution time: 0.0633
INFO - 2018-03-24 12:59:50 --> Config Class Initialized
INFO - 2018-03-24 12:59:50 --> Hooks Class Initialized
DEBUG - 2018-03-24 12:59:50 --> UTF-8 Support Enabled
INFO - 2018-03-24 12:59:50 --> Utf8 Class Initialized
INFO - 2018-03-24 12:59:50 --> URI Class Initialized
INFO - 2018-03-24 12:59:50 --> Router Class Initialized
INFO - 2018-03-24 12:59:50 --> Output Class Initialized
INFO - 2018-03-24 12:59:50 --> Security Class Initialized
DEBUG - 2018-03-24 12:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 12:59:50 --> Input Class Initialized
INFO - 2018-03-24 12:59:50 --> Language Class Initialized
INFO - 2018-03-24 12:59:50 --> Loader Class Initialized
INFO - 2018-03-24 12:59:50 --> Helper loaded: url_helper
INFO - 2018-03-24 12:59:50 --> Helper loaded: form_helper
INFO - 2018-03-24 12:59:50 --> Database Driver Class Initialized
DEBUG - 2018-03-24 12:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 12:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 12:59:50 --> Controller Class Initialized
INFO - 2018-03-24 12:59:50 --> Model Class Initialized
INFO - 2018-03-24 12:59:50 --> Model Class Initialized
INFO - 2018-03-24 12:59:50 --> Model Class Initialized
INFO - 2018-03-24 12:59:50 --> Model Class Initialized
INFO - 2018-03-24 12:59:50 --> Model Class Initialized
INFO - 2018-03-24 12:59:50 --> Helper loaded: date_helper
INFO - 2018-03-24 12:59:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:59:50 --> Final output sent to browser
DEBUG - 2018-03-24 18:59:50 --> Total execution time: 0.1036
INFO - 2018-03-24 13:00:12 --> Config Class Initialized
INFO - 2018-03-24 13:00:12 --> Hooks Class Initialized
DEBUG - 2018-03-24 13:00:12 --> UTF-8 Support Enabled
INFO - 2018-03-24 13:00:12 --> Utf8 Class Initialized
INFO - 2018-03-24 13:00:12 --> URI Class Initialized
INFO - 2018-03-24 13:00:12 --> Router Class Initialized
INFO - 2018-03-24 13:00:12 --> Output Class Initialized
INFO - 2018-03-24 13:00:12 --> Security Class Initialized
DEBUG - 2018-03-24 13:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 13:00:12 --> Input Class Initialized
INFO - 2018-03-24 13:00:12 --> Language Class Initialized
INFO - 2018-03-24 13:00:12 --> Loader Class Initialized
INFO - 2018-03-24 13:00:12 --> Helper loaded: url_helper
INFO - 2018-03-24 13:00:12 --> Helper loaded: form_helper
INFO - 2018-03-24 13:00:12 --> Database Driver Class Initialized
DEBUG - 2018-03-24 13:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 13:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 13:00:12 --> Controller Class Initialized
INFO - 2018-03-24 13:00:12 --> Model Class Initialized
INFO - 2018-03-24 13:00:12 --> Model Class Initialized
INFO - 2018-03-24 13:00:12 --> Model Class Initialized
INFO - 2018-03-24 13:00:12 --> Model Class Initialized
INFO - 2018-03-24 13:00:12 --> Model Class Initialized
INFO - 2018-03-24 13:00:12 --> Helper loaded: date_helper
INFO - 2018-03-24 13:00:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 19:00:12 --> Model Class Initialized
INFO - 2018-03-24 19:00:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 19:00:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 19:00:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 19:00:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 19:00:12 --> Final output sent to browser
DEBUG - 2018-03-24 19:00:12 --> Total execution time: 0.0912
INFO - 2018-03-24 13:00:16 --> Config Class Initialized
INFO - 2018-03-24 13:00:16 --> Hooks Class Initialized
DEBUG - 2018-03-24 13:00:16 --> UTF-8 Support Enabled
INFO - 2018-03-24 13:00:16 --> Utf8 Class Initialized
INFO - 2018-03-24 13:00:16 --> URI Class Initialized
INFO - 2018-03-24 13:00:16 --> Router Class Initialized
INFO - 2018-03-24 13:00:16 --> Output Class Initialized
INFO - 2018-03-24 13:00:16 --> Security Class Initialized
DEBUG - 2018-03-24 13:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 13:00:16 --> Input Class Initialized
INFO - 2018-03-24 13:00:16 --> Language Class Initialized
INFO - 2018-03-24 13:00:16 --> Loader Class Initialized
INFO - 2018-03-24 13:00:16 --> Helper loaded: url_helper
INFO - 2018-03-24 13:00:16 --> Helper loaded: form_helper
INFO - 2018-03-24 13:00:16 --> Database Driver Class Initialized
DEBUG - 2018-03-24 13:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 13:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 13:00:16 --> Controller Class Initialized
INFO - 2018-03-24 13:00:16 --> Model Class Initialized
INFO - 2018-03-24 13:00:16 --> Model Class Initialized
INFO - 2018-03-24 13:00:16 --> Helper loaded: date_helper
INFO - 2018-03-24 13:00:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 19:00:16 --> Final output sent to browser
DEBUG - 2018-03-24 19:00:16 --> Total execution time: 0.0867
INFO - 2018-03-24 13:00:22 --> Config Class Initialized
INFO - 2018-03-24 13:00:22 --> Hooks Class Initialized
DEBUG - 2018-03-24 13:00:22 --> UTF-8 Support Enabled
INFO - 2018-03-24 13:00:22 --> Utf8 Class Initialized
INFO - 2018-03-24 13:00:22 --> URI Class Initialized
INFO - 2018-03-24 13:00:22 --> Router Class Initialized
INFO - 2018-03-24 13:00:22 --> Output Class Initialized
INFO - 2018-03-24 13:00:22 --> Security Class Initialized
DEBUG - 2018-03-24 13:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 13:00:22 --> Input Class Initialized
INFO - 2018-03-24 13:00:22 --> Language Class Initialized
INFO - 2018-03-24 13:00:22 --> Loader Class Initialized
INFO - 2018-03-24 13:00:22 --> Helper loaded: url_helper
INFO - 2018-03-24 13:00:22 --> Helper loaded: form_helper
INFO - 2018-03-24 13:00:22 --> Database Driver Class Initialized
DEBUG - 2018-03-24 13:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 13:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 13:00:22 --> Controller Class Initialized
INFO - 2018-03-24 13:00:22 --> Model Class Initialized
INFO - 2018-03-24 13:00:22 --> Model Class Initialized
INFO - 2018-03-24 13:00:22 --> Model Class Initialized
INFO - 2018-03-24 13:00:22 --> Model Class Initialized
INFO - 2018-03-24 13:00:22 --> Model Class Initialized
INFO - 2018-03-24 13:00:22 --> Helper loaded: date_helper
INFO - 2018-03-24 13:00:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 19:00:22 --> Final output sent to browser
DEBUG - 2018-03-24 19:00:22 --> Total execution time: 0.0840
INFO - 2018-03-24 13:00:38 --> Config Class Initialized
INFO - 2018-03-24 13:00:38 --> Hooks Class Initialized
DEBUG - 2018-03-24 13:00:38 --> UTF-8 Support Enabled
INFO - 2018-03-24 13:00:38 --> Utf8 Class Initialized
INFO - 2018-03-24 13:00:38 --> URI Class Initialized
INFO - 2018-03-24 13:00:38 --> Router Class Initialized
INFO - 2018-03-24 13:00:38 --> Output Class Initialized
INFO - 2018-03-24 13:00:38 --> Security Class Initialized
DEBUG - 2018-03-24 13:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 13:00:38 --> Input Class Initialized
INFO - 2018-03-24 13:00:38 --> Language Class Initialized
INFO - 2018-03-24 13:00:38 --> Loader Class Initialized
INFO - 2018-03-24 13:00:38 --> Helper loaded: url_helper
INFO - 2018-03-24 13:00:38 --> Helper loaded: form_helper
INFO - 2018-03-24 13:00:38 --> Database Driver Class Initialized
DEBUG - 2018-03-24 13:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 13:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 13:00:38 --> Controller Class Initialized
INFO - 2018-03-24 13:00:38 --> Model Class Initialized
INFO - 2018-03-24 13:00:38 --> Model Class Initialized
INFO - 2018-03-24 13:00:38 --> Model Class Initialized
INFO - 2018-03-24 13:00:38 --> Model Class Initialized
INFO - 2018-03-24 13:00:38 --> Model Class Initialized
INFO - 2018-03-24 13:00:38 --> Helper loaded: date_helper
INFO - 2018-03-24 13:00:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 19:00:38 --> Final output sent to browser
DEBUG - 2018-03-24 19:00:38 --> Total execution time: 0.0691
INFO - 2018-03-24 13:01:53 --> Config Class Initialized
INFO - 2018-03-24 13:01:53 --> Hooks Class Initialized
DEBUG - 2018-03-24 13:01:53 --> UTF-8 Support Enabled
INFO - 2018-03-24 13:01:53 --> Utf8 Class Initialized
INFO - 2018-03-24 13:01:53 --> URI Class Initialized
INFO - 2018-03-24 13:01:53 --> Router Class Initialized
INFO - 2018-03-24 13:01:53 --> Output Class Initialized
INFO - 2018-03-24 13:01:53 --> Security Class Initialized
DEBUG - 2018-03-24 13:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 13:01:53 --> Input Class Initialized
INFO - 2018-03-24 13:01:53 --> Language Class Initialized
INFO - 2018-03-24 13:01:53 --> Loader Class Initialized
INFO - 2018-03-24 13:01:53 --> Helper loaded: url_helper
INFO - 2018-03-24 13:01:53 --> Helper loaded: form_helper
INFO - 2018-03-24 13:01:53 --> Database Driver Class Initialized
DEBUG - 2018-03-24 13:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 13:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 13:01:53 --> Controller Class Initialized
INFO - 2018-03-24 13:01:53 --> Model Class Initialized
INFO - 2018-03-24 13:01:53 --> Model Class Initialized
INFO - 2018-03-24 13:01:53 --> Model Class Initialized
INFO - 2018-03-24 13:01:53 --> Model Class Initialized
INFO - 2018-03-24 13:01:53 --> Model Class Initialized
INFO - 2018-03-24 13:01:53 --> Helper loaded: date_helper
INFO - 2018-03-24 13:01:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 19:01:53 --> Model Class Initialized
INFO - 2018-03-24 19:01:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 19:01:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 19:01:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 19:01:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 19:01:53 --> Final output sent to browser
DEBUG - 2018-03-24 19:01:53 --> Total execution time: 0.0976
INFO - 2018-03-24 13:01:58 --> Config Class Initialized
INFO - 2018-03-24 13:01:58 --> Hooks Class Initialized
DEBUG - 2018-03-24 13:01:58 --> UTF-8 Support Enabled
INFO - 2018-03-24 13:01:58 --> Utf8 Class Initialized
INFO - 2018-03-24 13:01:58 --> URI Class Initialized
INFO - 2018-03-24 13:01:58 --> Router Class Initialized
INFO - 2018-03-24 13:01:58 --> Output Class Initialized
INFO - 2018-03-24 13:01:58 --> Security Class Initialized
DEBUG - 2018-03-24 13:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 13:01:58 --> Input Class Initialized
INFO - 2018-03-24 13:01:58 --> Language Class Initialized
INFO - 2018-03-24 13:01:58 --> Loader Class Initialized
INFO - 2018-03-24 13:01:58 --> Helper loaded: url_helper
INFO - 2018-03-24 13:01:58 --> Helper loaded: form_helper
INFO - 2018-03-24 13:01:58 --> Database Driver Class Initialized
DEBUG - 2018-03-24 13:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 13:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 13:01:58 --> Controller Class Initialized
INFO - 2018-03-24 13:01:58 --> Model Class Initialized
INFO - 2018-03-24 13:01:58 --> Model Class Initialized
INFO - 2018-03-24 13:01:58 --> Helper loaded: date_helper
INFO - 2018-03-24 13:01:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 19:01:58 --> Final output sent to browser
DEBUG - 2018-03-24 19:01:58 --> Total execution time: 0.0758
INFO - 2018-03-24 13:02:02 --> Config Class Initialized
INFO - 2018-03-24 13:02:02 --> Hooks Class Initialized
DEBUG - 2018-03-24 13:02:02 --> UTF-8 Support Enabled
INFO - 2018-03-24 13:02:02 --> Utf8 Class Initialized
INFO - 2018-03-24 13:02:02 --> URI Class Initialized
INFO - 2018-03-24 13:02:02 --> Router Class Initialized
INFO - 2018-03-24 13:02:02 --> Output Class Initialized
INFO - 2018-03-24 13:02:02 --> Security Class Initialized
DEBUG - 2018-03-24 13:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 13:02:02 --> Input Class Initialized
INFO - 2018-03-24 13:02:02 --> Language Class Initialized
INFO - 2018-03-24 13:02:02 --> Loader Class Initialized
INFO - 2018-03-24 13:02:02 --> Helper loaded: url_helper
INFO - 2018-03-24 13:02:02 --> Helper loaded: form_helper
INFO - 2018-03-24 13:02:02 --> Database Driver Class Initialized
DEBUG - 2018-03-24 13:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 13:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 13:02:02 --> Controller Class Initialized
INFO - 2018-03-24 13:02:02 --> Model Class Initialized
INFO - 2018-03-24 13:02:02 --> Model Class Initialized
INFO - 2018-03-24 13:02:02 --> Model Class Initialized
INFO - 2018-03-24 13:02:02 --> Model Class Initialized
INFO - 2018-03-24 13:02:02 --> Model Class Initialized
INFO - 2018-03-24 13:02:02 --> Helper loaded: date_helper
INFO - 2018-03-24 13:02:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 19:02:02 --> Final output sent to browser
DEBUG - 2018-03-24 19:02:02 --> Total execution time: 0.0744
INFO - 2018-03-24 15:34:05 --> Config Class Initialized
INFO - 2018-03-24 15:34:05 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:34:05 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:34:05 --> Utf8 Class Initialized
INFO - 2018-03-24 15:34:05 --> URI Class Initialized
INFO - 2018-03-24 15:34:05 --> Router Class Initialized
INFO - 2018-03-24 15:34:05 --> Output Class Initialized
INFO - 2018-03-24 15:34:05 --> Security Class Initialized
DEBUG - 2018-03-24 15:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:34:05 --> Input Class Initialized
INFO - 2018-03-24 15:34:05 --> Language Class Initialized
INFO - 2018-03-24 15:34:05 --> Loader Class Initialized
INFO - 2018-03-24 15:34:05 --> Helper loaded: url_helper
INFO - 2018-03-24 15:34:05 --> Helper loaded: form_helper
INFO - 2018-03-24 15:34:05 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:34:05 --> Controller Class Initialized
INFO - 2018-03-24 15:34:05 --> Config Class Initialized
INFO - 2018-03-24 15:34:05 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:34:05 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:34:05 --> Utf8 Class Initialized
INFO - 2018-03-24 15:34:05 --> URI Class Initialized
INFO - 2018-03-24 15:34:05 --> Router Class Initialized
INFO - 2018-03-24 15:34:05 --> Output Class Initialized
INFO - 2018-03-24 15:34:05 --> Security Class Initialized
DEBUG - 2018-03-24 15:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:34:05 --> Input Class Initialized
INFO - 2018-03-24 15:34:05 --> Language Class Initialized
INFO - 2018-03-24 15:34:05 --> Loader Class Initialized
INFO - 2018-03-24 15:34:05 --> Helper loaded: url_helper
INFO - 2018-03-24 15:34:05 --> Helper loaded: form_helper
INFO - 2018-03-24 15:34:05 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:34:05 --> Controller Class Initialized
INFO - 2018-03-24 15:34:05 --> Model Class Initialized
INFO - 2018-03-24 15:34:05 --> Model Class Initialized
INFO - 2018-03-24 15:34:05 --> Model Class Initialized
INFO - 2018-03-24 15:34:05 --> Helper loaded: date_helper
INFO - 2018-03-24 21:34:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-24 21:34:05 --> Final output sent to browser
DEBUG - 2018-03-24 21:34:05 --> Total execution time: 0.0844
INFO - 2018-03-24 15:34:40 --> Config Class Initialized
INFO - 2018-03-24 15:34:40 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:34:40 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:34:40 --> Utf8 Class Initialized
INFO - 2018-03-24 15:34:40 --> URI Class Initialized
INFO - 2018-03-24 15:34:40 --> Router Class Initialized
INFO - 2018-03-24 15:34:40 --> Output Class Initialized
INFO - 2018-03-24 15:34:40 --> Security Class Initialized
DEBUG - 2018-03-24 15:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:34:40 --> Input Class Initialized
INFO - 2018-03-24 15:34:40 --> Language Class Initialized
INFO - 2018-03-24 15:34:40 --> Loader Class Initialized
INFO - 2018-03-24 15:34:40 --> Helper loaded: url_helper
INFO - 2018-03-24 15:34:40 --> Helper loaded: form_helper
INFO - 2018-03-24 15:34:40 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:34:40 --> Controller Class Initialized
INFO - 2018-03-24 15:34:40 --> Model Class Initialized
INFO - 2018-03-24 15:34:40 --> Model Class Initialized
INFO - 2018-03-24 15:34:40 --> Model Class Initialized
INFO - 2018-03-24 15:34:40 --> Helper loaded: date_helper
INFO - 2018-03-24 15:34:40 --> Config Class Initialized
INFO - 2018-03-24 15:34:40 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:34:40 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:34:40 --> Utf8 Class Initialized
INFO - 2018-03-24 15:34:40 --> URI Class Initialized
INFO - 2018-03-24 15:34:40 --> Router Class Initialized
INFO - 2018-03-24 15:34:40 --> Output Class Initialized
INFO - 2018-03-24 15:34:40 --> Security Class Initialized
DEBUG - 2018-03-24 15:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:34:40 --> Input Class Initialized
INFO - 2018-03-24 15:34:40 --> Language Class Initialized
INFO - 2018-03-24 15:34:40 --> Loader Class Initialized
INFO - 2018-03-24 15:34:40 --> Helper loaded: url_helper
INFO - 2018-03-24 15:34:40 --> Helper loaded: form_helper
INFO - 2018-03-24 15:34:40 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:34:40 --> Controller Class Initialized
INFO - 2018-03-24 15:34:40 --> Model Class Initialized
INFO - 2018-03-24 15:34:40 --> Model Class Initialized
INFO - 2018-03-24 15:34:40 --> Model Class Initialized
INFO - 2018-03-24 15:34:40 --> Model Class Initialized
INFO - 2018-03-24 15:34:40 --> Model Class Initialized
INFO - 2018-03-24 15:34:40 --> Helper loaded: date_helper
INFO - 2018-03-24 21:34:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 21:34:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 21:34:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-24 21:34:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 21:34:40 --> Final output sent to browser
DEBUG - 2018-03-24 21:34:40 --> Total execution time: 0.0889
INFO - 2018-03-24 15:34:52 --> Config Class Initialized
INFO - 2018-03-24 15:34:52 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:34:52 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:34:52 --> Utf8 Class Initialized
INFO - 2018-03-24 15:34:52 --> URI Class Initialized
INFO - 2018-03-24 15:34:52 --> Router Class Initialized
INFO - 2018-03-24 15:34:52 --> Output Class Initialized
INFO - 2018-03-24 15:34:52 --> Security Class Initialized
DEBUG - 2018-03-24 15:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:34:52 --> Input Class Initialized
INFO - 2018-03-24 15:34:52 --> Language Class Initialized
INFO - 2018-03-24 15:34:52 --> Loader Class Initialized
INFO - 2018-03-24 15:34:52 --> Helper loaded: url_helper
INFO - 2018-03-24 15:34:52 --> Helper loaded: form_helper
INFO - 2018-03-24 15:34:52 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:34:52 --> Controller Class Initialized
INFO - 2018-03-24 15:34:52 --> Model Class Initialized
INFO - 2018-03-24 15:34:52 --> Model Class Initialized
INFO - 2018-03-24 15:34:52 --> Helper loaded: date_helper
INFO - 2018-03-24 15:34:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:34:52 --> Model Class Initialized
INFO - 2018-03-24 21:34:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 21:34:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 21:34:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\suplier/table.php
INFO - 2018-03-24 21:34:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 21:34:52 --> Final output sent to browser
DEBUG - 2018-03-24 21:34:52 --> Total execution time: 0.2259
INFO - 2018-03-24 15:34:56 --> Config Class Initialized
INFO - 2018-03-24 15:34:56 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:34:56 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:34:56 --> Utf8 Class Initialized
INFO - 2018-03-24 15:34:56 --> URI Class Initialized
INFO - 2018-03-24 15:34:56 --> Router Class Initialized
INFO - 2018-03-24 15:34:56 --> Output Class Initialized
INFO - 2018-03-24 15:34:56 --> Security Class Initialized
DEBUG - 2018-03-24 15:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:34:56 --> Input Class Initialized
INFO - 2018-03-24 15:34:56 --> Language Class Initialized
INFO - 2018-03-24 15:34:56 --> Loader Class Initialized
INFO - 2018-03-24 15:34:56 --> Helper loaded: url_helper
INFO - 2018-03-24 15:34:56 --> Helper loaded: form_helper
INFO - 2018-03-24 15:34:56 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:34:56 --> Controller Class Initialized
INFO - 2018-03-24 15:34:56 --> Model Class Initialized
INFO - 2018-03-24 15:34:56 --> Model Class Initialized
INFO - 2018-03-24 15:34:56 --> Helper loaded: date_helper
INFO - 2018-03-24 15:34:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:34:56 --> Model Class Initialized
INFO - 2018-03-24 21:34:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 21:34:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 21:34:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-24 21:34:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 21:34:56 --> Final output sent to browser
DEBUG - 2018-03-24 21:34:56 --> Total execution time: 0.1617
INFO - 2018-03-24 15:34:59 --> Config Class Initialized
INFO - 2018-03-24 15:34:59 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:34:59 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:34:59 --> Utf8 Class Initialized
INFO - 2018-03-24 15:34:59 --> URI Class Initialized
INFO - 2018-03-24 15:34:59 --> Router Class Initialized
INFO - 2018-03-24 15:34:59 --> Output Class Initialized
INFO - 2018-03-24 15:34:59 --> Security Class Initialized
DEBUG - 2018-03-24 15:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:34:59 --> Input Class Initialized
INFO - 2018-03-24 15:34:59 --> Language Class Initialized
INFO - 2018-03-24 15:34:59 --> Loader Class Initialized
INFO - 2018-03-24 15:34:59 --> Helper loaded: url_helper
INFO - 2018-03-24 15:34:59 --> Helper loaded: form_helper
INFO - 2018-03-24 15:34:59 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:34:59 --> Controller Class Initialized
INFO - 2018-03-24 15:34:59 --> Model Class Initialized
INFO - 2018-03-24 15:34:59 --> Model Class Initialized
INFO - 2018-03-24 15:34:59 --> Model Class Initialized
INFO - 2018-03-24 15:34:59 --> Model Class Initialized
INFO - 2018-03-24 15:34:59 --> Model Class Initialized
INFO - 2018-03-24 15:34:59 --> Helper loaded: date_helper
INFO - 2018-03-24 15:34:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:34:59 --> Model Class Initialized
INFO - 2018-03-24 21:34:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 21:34:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 21:34:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-24 21:34:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 21:34:59 --> Final output sent to browser
DEBUG - 2018-03-24 21:34:59 --> Total execution time: 0.1002
INFO - 2018-03-24 15:35:08 --> Config Class Initialized
INFO - 2018-03-24 15:35:08 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:35:08 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:35:08 --> Utf8 Class Initialized
INFO - 2018-03-24 15:35:08 --> URI Class Initialized
INFO - 2018-03-24 15:35:08 --> Router Class Initialized
INFO - 2018-03-24 15:35:08 --> Output Class Initialized
INFO - 2018-03-24 15:35:08 --> Security Class Initialized
DEBUG - 2018-03-24 15:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:35:08 --> Input Class Initialized
INFO - 2018-03-24 15:35:08 --> Language Class Initialized
INFO - 2018-03-24 15:35:08 --> Loader Class Initialized
INFO - 2018-03-24 15:35:08 --> Helper loaded: url_helper
INFO - 2018-03-24 15:35:08 --> Helper loaded: form_helper
INFO - 2018-03-24 15:35:08 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:35:08 --> Controller Class Initialized
INFO - 2018-03-24 15:35:08 --> Model Class Initialized
INFO - 2018-03-24 15:35:08 --> Model Class Initialized
INFO - 2018-03-24 15:35:08 --> Model Class Initialized
INFO - 2018-03-24 15:35:08 --> Model Class Initialized
INFO - 2018-03-24 15:35:08 --> Model Class Initialized
INFO - 2018-03-24 15:35:08 --> Helper loaded: date_helper
INFO - 2018-03-24 15:35:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:35:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 21:35:08 --> Final output sent to browser
DEBUG - 2018-03-24 21:35:08 --> Total execution time: 0.0919
INFO - 2018-03-24 15:35:11 --> Config Class Initialized
INFO - 2018-03-24 15:35:11 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:35:11 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:35:11 --> Utf8 Class Initialized
INFO - 2018-03-24 15:35:11 --> URI Class Initialized
INFO - 2018-03-24 15:35:11 --> Router Class Initialized
INFO - 2018-03-24 15:35:11 --> Output Class Initialized
INFO - 2018-03-24 15:35:11 --> Security Class Initialized
DEBUG - 2018-03-24 15:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:35:11 --> Input Class Initialized
INFO - 2018-03-24 15:35:11 --> Language Class Initialized
INFO - 2018-03-24 15:35:11 --> Loader Class Initialized
INFO - 2018-03-24 15:35:11 --> Helper loaded: url_helper
INFO - 2018-03-24 15:35:11 --> Helper loaded: form_helper
INFO - 2018-03-24 15:35:11 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:35:11 --> Controller Class Initialized
INFO - 2018-03-24 15:35:11 --> Model Class Initialized
INFO - 2018-03-24 15:35:11 --> Model Class Initialized
INFO - 2018-03-24 15:35:11 --> Model Class Initialized
INFO - 2018-03-24 15:35:11 --> Model Class Initialized
INFO - 2018-03-24 15:35:11 --> Model Class Initialized
INFO - 2018-03-24 15:35:11 --> Helper loaded: date_helper
INFO - 2018-03-24 15:35:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:35:11 --> Model Class Initialized
INFO - 2018-03-24 21:35:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 21:35:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 21:35:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 21:35:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 21:35:11 --> Final output sent to browser
DEBUG - 2018-03-24 21:35:11 --> Total execution time: 0.0947
INFO - 2018-03-24 15:35:33 --> Config Class Initialized
INFO - 2018-03-24 15:35:33 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:35:33 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:35:33 --> Utf8 Class Initialized
INFO - 2018-03-24 15:35:33 --> URI Class Initialized
INFO - 2018-03-24 15:35:33 --> Router Class Initialized
INFO - 2018-03-24 15:35:33 --> Output Class Initialized
INFO - 2018-03-24 15:35:33 --> Security Class Initialized
DEBUG - 2018-03-24 15:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:35:33 --> Input Class Initialized
INFO - 2018-03-24 15:35:33 --> Language Class Initialized
INFO - 2018-03-24 15:35:33 --> Loader Class Initialized
INFO - 2018-03-24 15:35:33 --> Helper loaded: url_helper
INFO - 2018-03-24 15:35:33 --> Helper loaded: form_helper
INFO - 2018-03-24 15:35:33 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:35:33 --> Controller Class Initialized
INFO - 2018-03-24 15:35:33 --> Model Class Initialized
INFO - 2018-03-24 15:35:33 --> Model Class Initialized
INFO - 2018-03-24 15:35:33 --> Helper loaded: date_helper
INFO - 2018-03-24 15:35:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:35:33 --> Final output sent to browser
DEBUG - 2018-03-24 21:35:33 --> Total execution time: 0.0891
INFO - 2018-03-24 15:35:41 --> Config Class Initialized
INFO - 2018-03-24 15:35:41 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:35:41 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:35:41 --> Utf8 Class Initialized
INFO - 2018-03-24 15:35:41 --> URI Class Initialized
INFO - 2018-03-24 15:35:41 --> Router Class Initialized
INFO - 2018-03-24 15:35:41 --> Output Class Initialized
INFO - 2018-03-24 15:35:41 --> Security Class Initialized
DEBUG - 2018-03-24 15:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:35:41 --> Input Class Initialized
INFO - 2018-03-24 15:35:41 --> Language Class Initialized
INFO - 2018-03-24 15:35:41 --> Loader Class Initialized
INFO - 2018-03-24 15:35:41 --> Helper loaded: url_helper
INFO - 2018-03-24 15:35:41 --> Helper loaded: form_helper
INFO - 2018-03-24 15:35:41 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:35:41 --> Controller Class Initialized
INFO - 2018-03-24 15:35:41 --> Model Class Initialized
INFO - 2018-03-24 15:35:41 --> Model Class Initialized
INFO - 2018-03-24 15:35:41 --> Model Class Initialized
INFO - 2018-03-24 15:35:41 --> Model Class Initialized
INFO - 2018-03-24 15:35:41 --> Model Class Initialized
INFO - 2018-03-24 15:35:41 --> Helper loaded: date_helper
INFO - 2018-03-24 15:35:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:35:41 --> Final output sent to browser
DEBUG - 2018-03-24 21:35:41 --> Total execution time: 0.0693
INFO - 2018-03-24 15:44:12 --> Config Class Initialized
INFO - 2018-03-24 15:44:12 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:44:12 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:44:12 --> Utf8 Class Initialized
INFO - 2018-03-24 15:44:12 --> URI Class Initialized
INFO - 2018-03-24 15:44:12 --> Router Class Initialized
INFO - 2018-03-24 15:44:12 --> Output Class Initialized
INFO - 2018-03-24 15:44:12 --> Security Class Initialized
DEBUG - 2018-03-24 15:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:44:12 --> Input Class Initialized
INFO - 2018-03-24 15:44:12 --> Language Class Initialized
INFO - 2018-03-24 15:44:12 --> Loader Class Initialized
INFO - 2018-03-24 15:44:12 --> Helper loaded: url_helper
INFO - 2018-03-24 15:44:12 --> Helper loaded: form_helper
INFO - 2018-03-24 15:44:12 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:44:12 --> Controller Class Initialized
INFO - 2018-03-24 15:44:12 --> Model Class Initialized
INFO - 2018-03-24 15:44:12 --> Model Class Initialized
INFO - 2018-03-24 15:44:12 --> Model Class Initialized
INFO - 2018-03-24 15:44:12 --> Model Class Initialized
INFO - 2018-03-24 15:44:12 --> Model Class Initialized
INFO - 2018-03-24 15:44:12 --> Helper loaded: date_helper
INFO - 2018-03-24 15:44:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:44:12 --> Model Class Initialized
INFO - 2018-03-24 21:44:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 21:44:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 21:44:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-24 21:44:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 21:44:12 --> Final output sent to browser
DEBUG - 2018-03-24 21:44:12 --> Total execution time: 0.0728
INFO - 2018-03-24 15:44:16 --> Config Class Initialized
INFO - 2018-03-24 15:44:16 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:44:16 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:44:16 --> Utf8 Class Initialized
INFO - 2018-03-24 15:44:16 --> URI Class Initialized
INFO - 2018-03-24 15:44:16 --> Router Class Initialized
INFO - 2018-03-24 15:44:16 --> Output Class Initialized
INFO - 2018-03-24 15:44:16 --> Security Class Initialized
DEBUG - 2018-03-24 15:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:44:16 --> Input Class Initialized
INFO - 2018-03-24 15:44:16 --> Language Class Initialized
INFO - 2018-03-24 15:44:16 --> Loader Class Initialized
INFO - 2018-03-24 15:44:16 --> Helper loaded: url_helper
INFO - 2018-03-24 15:44:16 --> Helper loaded: form_helper
INFO - 2018-03-24 15:44:16 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:44:16 --> Controller Class Initialized
INFO - 2018-03-24 15:44:16 --> Model Class Initialized
INFO - 2018-03-24 15:44:16 --> Model Class Initialized
INFO - 2018-03-24 15:44:16 --> Model Class Initialized
INFO - 2018-03-24 15:44:16 --> Model Class Initialized
INFO - 2018-03-24 15:44:16 --> Model Class Initialized
INFO - 2018-03-24 15:44:16 --> Helper loaded: date_helper
INFO - 2018-03-24 15:44:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:44:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 21:44:16 --> Final output sent to browser
DEBUG - 2018-03-24 21:44:16 --> Total execution time: 0.0981
INFO - 2018-03-24 15:44:17 --> Config Class Initialized
INFO - 2018-03-24 15:44:17 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:44:17 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:44:17 --> Utf8 Class Initialized
INFO - 2018-03-24 15:44:17 --> URI Class Initialized
INFO - 2018-03-24 15:44:17 --> Router Class Initialized
INFO - 2018-03-24 15:44:17 --> Output Class Initialized
INFO - 2018-03-24 15:44:17 --> Security Class Initialized
DEBUG - 2018-03-24 15:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:44:17 --> Input Class Initialized
INFO - 2018-03-24 15:44:17 --> Language Class Initialized
INFO - 2018-03-24 15:44:17 --> Loader Class Initialized
INFO - 2018-03-24 15:44:17 --> Helper loaded: url_helper
INFO - 2018-03-24 15:44:17 --> Helper loaded: form_helper
INFO - 2018-03-24 15:44:17 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:44:17 --> Controller Class Initialized
INFO - 2018-03-24 15:44:17 --> Model Class Initialized
INFO - 2018-03-24 15:44:17 --> Model Class Initialized
INFO - 2018-03-24 15:44:17 --> Model Class Initialized
INFO - 2018-03-24 15:44:17 --> Model Class Initialized
INFO - 2018-03-24 15:44:17 --> Model Class Initialized
INFO - 2018-03-24 15:44:17 --> Helper loaded: date_helper
INFO - 2018-03-24 15:44:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:44:17 --> Model Class Initialized
INFO - 2018-03-24 21:44:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 21:44:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 21:44:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 21:44:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 21:44:17 --> Final output sent to browser
DEBUG - 2018-03-24 21:44:17 --> Total execution time: 0.0994
INFO - 2018-03-24 15:44:21 --> Config Class Initialized
INFO - 2018-03-24 15:44:21 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:44:21 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:44:21 --> Utf8 Class Initialized
INFO - 2018-03-24 15:44:21 --> URI Class Initialized
INFO - 2018-03-24 15:44:21 --> Router Class Initialized
INFO - 2018-03-24 15:44:21 --> Output Class Initialized
INFO - 2018-03-24 15:44:21 --> Security Class Initialized
DEBUG - 2018-03-24 15:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:44:21 --> Input Class Initialized
INFO - 2018-03-24 15:44:21 --> Language Class Initialized
INFO - 2018-03-24 15:44:21 --> Loader Class Initialized
INFO - 2018-03-24 15:44:21 --> Helper loaded: url_helper
INFO - 2018-03-24 15:44:21 --> Helper loaded: form_helper
INFO - 2018-03-24 15:44:21 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:44:21 --> Controller Class Initialized
INFO - 2018-03-24 15:44:21 --> Model Class Initialized
INFO - 2018-03-24 15:44:21 --> Model Class Initialized
INFO - 2018-03-24 15:44:21 --> Helper loaded: date_helper
INFO - 2018-03-24 15:44:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:44:21 --> Final output sent to browser
DEBUG - 2018-03-24 21:44:21 --> Total execution time: 0.1022
INFO - 2018-03-24 15:44:26 --> Config Class Initialized
INFO - 2018-03-24 15:44:26 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:44:26 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:44:26 --> Utf8 Class Initialized
INFO - 2018-03-24 15:44:26 --> URI Class Initialized
INFO - 2018-03-24 15:44:26 --> Router Class Initialized
INFO - 2018-03-24 15:44:26 --> Output Class Initialized
INFO - 2018-03-24 15:44:26 --> Security Class Initialized
DEBUG - 2018-03-24 15:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:44:26 --> Input Class Initialized
INFO - 2018-03-24 15:44:26 --> Language Class Initialized
INFO - 2018-03-24 15:44:26 --> Loader Class Initialized
INFO - 2018-03-24 15:44:26 --> Helper loaded: url_helper
INFO - 2018-03-24 15:44:26 --> Helper loaded: form_helper
INFO - 2018-03-24 15:44:26 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:44:26 --> Controller Class Initialized
INFO - 2018-03-24 15:44:26 --> Model Class Initialized
INFO - 2018-03-24 15:44:26 --> Model Class Initialized
INFO - 2018-03-24 15:44:26 --> Model Class Initialized
INFO - 2018-03-24 15:44:26 --> Model Class Initialized
INFO - 2018-03-24 15:44:26 --> Model Class Initialized
INFO - 2018-03-24 15:44:26 --> Helper loaded: date_helper
INFO - 2018-03-24 15:44:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:44:26 --> Final output sent to browser
DEBUG - 2018-03-24 21:44:26 --> Total execution time: 0.1123
INFO - 2018-03-24 15:44:27 --> Config Class Initialized
INFO - 2018-03-24 15:44:27 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:44:27 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:44:27 --> Utf8 Class Initialized
INFO - 2018-03-24 15:44:27 --> URI Class Initialized
INFO - 2018-03-24 15:44:27 --> Router Class Initialized
INFO - 2018-03-24 15:44:27 --> Output Class Initialized
INFO - 2018-03-24 15:44:27 --> Security Class Initialized
DEBUG - 2018-03-24 15:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:44:27 --> Input Class Initialized
INFO - 2018-03-24 15:44:27 --> Language Class Initialized
INFO - 2018-03-24 15:44:27 --> Loader Class Initialized
INFO - 2018-03-24 15:44:27 --> Helper loaded: url_helper
INFO - 2018-03-24 15:44:27 --> Helper loaded: form_helper
INFO - 2018-03-24 15:44:27 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:44:27 --> Controller Class Initialized
INFO - 2018-03-24 15:44:28 --> Model Class Initialized
INFO - 2018-03-24 15:44:28 --> Model Class Initialized
INFO - 2018-03-24 15:44:28 --> Model Class Initialized
INFO - 2018-03-24 15:44:28 --> Model Class Initialized
INFO - 2018-03-24 15:44:28 --> Model Class Initialized
INFO - 2018-03-24 15:44:28 --> Helper loaded: date_helper
INFO - 2018-03-24 15:44:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:44:28 --> Final output sent to browser
DEBUG - 2018-03-24 21:44:28 --> Total execution time: 0.0927
INFO - 2018-03-24 15:44:28 --> Config Class Initialized
INFO - 2018-03-24 15:44:28 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:44:28 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:44:28 --> Utf8 Class Initialized
INFO - 2018-03-24 15:44:28 --> URI Class Initialized
INFO - 2018-03-24 15:44:28 --> Router Class Initialized
INFO - 2018-03-24 15:44:28 --> Output Class Initialized
INFO - 2018-03-24 15:44:28 --> Security Class Initialized
DEBUG - 2018-03-24 15:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:44:28 --> Input Class Initialized
INFO - 2018-03-24 15:44:28 --> Language Class Initialized
INFO - 2018-03-24 15:44:28 --> Loader Class Initialized
INFO - 2018-03-24 15:44:28 --> Helper loaded: url_helper
INFO - 2018-03-24 15:44:28 --> Helper loaded: form_helper
INFO - 2018-03-24 15:44:28 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:44:28 --> Controller Class Initialized
INFO - 2018-03-24 15:44:28 --> Model Class Initialized
INFO - 2018-03-24 15:44:28 --> Model Class Initialized
INFO - 2018-03-24 15:44:28 --> Model Class Initialized
INFO - 2018-03-24 15:44:28 --> Model Class Initialized
INFO - 2018-03-24 15:44:28 --> Model Class Initialized
INFO - 2018-03-24 15:44:28 --> Helper loaded: date_helper
INFO - 2018-03-24 15:44:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:44:28 --> Final output sent to browser
DEBUG - 2018-03-24 21:44:28 --> Total execution time: 0.1123
INFO - 2018-03-24 15:44:28 --> Config Class Initialized
INFO - 2018-03-24 15:44:28 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:44:28 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:44:28 --> Utf8 Class Initialized
INFO - 2018-03-24 15:44:28 --> URI Class Initialized
INFO - 2018-03-24 15:44:28 --> Router Class Initialized
INFO - 2018-03-24 15:44:28 --> Output Class Initialized
INFO - 2018-03-24 15:44:28 --> Security Class Initialized
DEBUG - 2018-03-24 15:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:44:28 --> Input Class Initialized
INFO - 2018-03-24 15:44:28 --> Language Class Initialized
INFO - 2018-03-24 15:44:28 --> Loader Class Initialized
INFO - 2018-03-24 15:44:28 --> Helper loaded: url_helper
INFO - 2018-03-24 15:44:28 --> Helper loaded: form_helper
INFO - 2018-03-24 15:44:28 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:44:28 --> Controller Class Initialized
INFO - 2018-03-24 15:44:28 --> Model Class Initialized
INFO - 2018-03-24 15:44:28 --> Model Class Initialized
INFO - 2018-03-24 15:44:28 --> Model Class Initialized
INFO - 2018-03-24 15:44:28 --> Model Class Initialized
INFO - 2018-03-24 15:44:28 --> Model Class Initialized
INFO - 2018-03-24 15:44:28 --> Helper loaded: date_helper
INFO - 2018-03-24 15:44:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:44:28 --> Final output sent to browser
DEBUG - 2018-03-24 21:44:28 --> Total execution time: 0.0759
INFO - 2018-03-24 15:44:36 --> Config Class Initialized
INFO - 2018-03-24 15:44:36 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:44:36 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:44:36 --> Utf8 Class Initialized
INFO - 2018-03-24 15:44:36 --> URI Class Initialized
INFO - 2018-03-24 15:44:36 --> Router Class Initialized
INFO - 2018-03-24 15:44:36 --> Output Class Initialized
INFO - 2018-03-24 15:44:36 --> Security Class Initialized
DEBUG - 2018-03-24 15:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:44:36 --> Input Class Initialized
INFO - 2018-03-24 15:44:36 --> Language Class Initialized
INFO - 2018-03-24 15:44:36 --> Loader Class Initialized
INFO - 2018-03-24 15:44:36 --> Helper loaded: url_helper
INFO - 2018-03-24 15:44:36 --> Helper loaded: form_helper
INFO - 2018-03-24 15:44:36 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:44:36 --> Controller Class Initialized
INFO - 2018-03-24 15:44:36 --> Model Class Initialized
INFO - 2018-03-24 15:44:36 --> Model Class Initialized
INFO - 2018-03-24 15:44:36 --> Model Class Initialized
INFO - 2018-03-24 15:44:36 --> Model Class Initialized
INFO - 2018-03-24 15:44:36 --> Model Class Initialized
INFO - 2018-03-24 15:44:36 --> Helper loaded: date_helper
INFO - 2018-03-24 15:44:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:44:36 --> Final output sent to browser
DEBUG - 2018-03-24 21:44:36 --> Total execution time: 0.0972
INFO - 2018-03-24 15:45:05 --> Config Class Initialized
INFO - 2018-03-24 15:45:05 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:45:05 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:45:05 --> Utf8 Class Initialized
INFO - 2018-03-24 15:45:05 --> URI Class Initialized
INFO - 2018-03-24 15:45:05 --> Router Class Initialized
INFO - 2018-03-24 15:45:05 --> Output Class Initialized
INFO - 2018-03-24 15:45:05 --> Security Class Initialized
DEBUG - 2018-03-24 15:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:45:05 --> Input Class Initialized
INFO - 2018-03-24 15:45:05 --> Language Class Initialized
INFO - 2018-03-24 15:45:05 --> Loader Class Initialized
INFO - 2018-03-24 15:45:05 --> Helper loaded: url_helper
INFO - 2018-03-24 15:45:05 --> Helper loaded: form_helper
INFO - 2018-03-24 15:45:05 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:45:05 --> Controller Class Initialized
INFO - 2018-03-24 15:45:05 --> Model Class Initialized
INFO - 2018-03-24 15:45:05 --> Model Class Initialized
INFO - 2018-03-24 15:45:05 --> Model Class Initialized
INFO - 2018-03-24 15:45:05 --> Model Class Initialized
INFO - 2018-03-24 15:45:05 --> Model Class Initialized
INFO - 2018-03-24 15:45:05 --> Helper loaded: date_helper
INFO - 2018-03-24 15:45:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:45:05 --> Model Class Initialized
INFO - 2018-03-24 21:45:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 21:45:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 21:45:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 21:45:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 21:45:05 --> Final output sent to browser
DEBUG - 2018-03-24 21:45:05 --> Total execution time: 0.0987
INFO - 2018-03-24 15:45:09 --> Config Class Initialized
INFO - 2018-03-24 15:45:09 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:45:09 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:45:09 --> Utf8 Class Initialized
INFO - 2018-03-24 15:45:09 --> URI Class Initialized
INFO - 2018-03-24 15:45:09 --> Router Class Initialized
INFO - 2018-03-24 15:45:09 --> Output Class Initialized
INFO - 2018-03-24 15:45:09 --> Security Class Initialized
DEBUG - 2018-03-24 15:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:45:09 --> Input Class Initialized
INFO - 2018-03-24 15:45:09 --> Language Class Initialized
INFO - 2018-03-24 15:45:09 --> Loader Class Initialized
INFO - 2018-03-24 15:45:09 --> Helper loaded: url_helper
INFO - 2018-03-24 15:45:09 --> Helper loaded: form_helper
INFO - 2018-03-24 15:45:09 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:45:09 --> Controller Class Initialized
INFO - 2018-03-24 15:45:09 --> Model Class Initialized
INFO - 2018-03-24 15:45:09 --> Model Class Initialized
INFO - 2018-03-24 15:45:09 --> Model Class Initialized
INFO - 2018-03-24 15:45:09 --> Model Class Initialized
INFO - 2018-03-24 15:45:09 --> Model Class Initialized
INFO - 2018-03-24 15:45:09 --> Helper loaded: date_helper
INFO - 2018-03-24 15:45:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:45:09 --> Final output sent to browser
DEBUG - 2018-03-24 21:45:09 --> Total execution time: 0.0803
INFO - 2018-03-24 15:45:45 --> Config Class Initialized
INFO - 2018-03-24 15:45:45 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:45:45 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:45:45 --> Utf8 Class Initialized
INFO - 2018-03-24 15:45:45 --> URI Class Initialized
INFO - 2018-03-24 15:45:45 --> Router Class Initialized
INFO - 2018-03-24 15:45:45 --> Output Class Initialized
INFO - 2018-03-24 15:45:45 --> Security Class Initialized
DEBUG - 2018-03-24 15:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:45:45 --> Input Class Initialized
INFO - 2018-03-24 15:45:45 --> Language Class Initialized
INFO - 2018-03-24 15:45:45 --> Loader Class Initialized
INFO - 2018-03-24 15:45:45 --> Helper loaded: url_helper
INFO - 2018-03-24 15:45:45 --> Helper loaded: form_helper
INFO - 2018-03-24 15:45:45 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:45:45 --> Controller Class Initialized
INFO - 2018-03-24 15:45:45 --> Model Class Initialized
INFO - 2018-03-24 15:45:45 --> Model Class Initialized
INFO - 2018-03-24 15:45:45 --> Model Class Initialized
INFO - 2018-03-24 15:45:45 --> Model Class Initialized
INFO - 2018-03-24 15:45:45 --> Model Class Initialized
INFO - 2018-03-24 15:45:45 --> Helper loaded: date_helper
INFO - 2018-03-24 15:45:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:45:45 --> Model Class Initialized
INFO - 2018-03-24 21:45:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 21:45:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 21:45:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 21:45:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 21:45:45 --> Final output sent to browser
DEBUG - 2018-03-24 21:45:45 --> Total execution time: 0.0834
INFO - 2018-03-24 15:45:50 --> Config Class Initialized
INFO - 2018-03-24 15:45:50 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:45:50 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:45:50 --> Utf8 Class Initialized
INFO - 2018-03-24 15:45:50 --> URI Class Initialized
INFO - 2018-03-24 15:45:50 --> Router Class Initialized
INFO - 2018-03-24 15:45:50 --> Output Class Initialized
INFO - 2018-03-24 15:45:51 --> Security Class Initialized
DEBUG - 2018-03-24 15:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:45:51 --> Input Class Initialized
INFO - 2018-03-24 15:45:51 --> Language Class Initialized
INFO - 2018-03-24 15:45:51 --> Loader Class Initialized
INFO - 2018-03-24 15:45:51 --> Helper loaded: url_helper
INFO - 2018-03-24 15:45:51 --> Helper loaded: form_helper
INFO - 2018-03-24 15:45:51 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:45:51 --> Controller Class Initialized
INFO - 2018-03-24 15:45:51 --> Model Class Initialized
INFO - 2018-03-24 15:45:51 --> Model Class Initialized
INFO - 2018-03-24 15:45:51 --> Model Class Initialized
INFO - 2018-03-24 15:45:51 --> Model Class Initialized
INFO - 2018-03-24 15:45:51 --> Model Class Initialized
INFO - 2018-03-24 15:45:51 --> Helper loaded: date_helper
INFO - 2018-03-24 15:45:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:45:51 --> Model Class Initialized
INFO - 2018-03-24 21:45:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 21:45:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 21:45:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 21:45:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 21:45:51 --> Final output sent to browser
DEBUG - 2018-03-24 21:45:51 --> Total execution time: 0.1032
INFO - 2018-03-24 15:45:56 --> Config Class Initialized
INFO - 2018-03-24 15:45:56 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:45:56 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:45:56 --> Utf8 Class Initialized
INFO - 2018-03-24 15:45:56 --> URI Class Initialized
INFO - 2018-03-24 15:45:56 --> Router Class Initialized
INFO - 2018-03-24 15:45:56 --> Output Class Initialized
INFO - 2018-03-24 15:45:56 --> Security Class Initialized
DEBUG - 2018-03-24 15:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:45:56 --> Input Class Initialized
INFO - 2018-03-24 15:45:56 --> Language Class Initialized
INFO - 2018-03-24 15:45:56 --> Loader Class Initialized
INFO - 2018-03-24 15:45:56 --> Helper loaded: url_helper
INFO - 2018-03-24 15:45:56 --> Helper loaded: form_helper
INFO - 2018-03-24 15:45:56 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:45:56 --> Controller Class Initialized
INFO - 2018-03-24 15:45:56 --> Model Class Initialized
INFO - 2018-03-24 15:45:56 --> Model Class Initialized
INFO - 2018-03-24 15:45:56 --> Helper loaded: date_helper
INFO - 2018-03-24 15:45:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:45:56 --> Final output sent to browser
DEBUG - 2018-03-24 21:45:56 --> Total execution time: 0.0696
INFO - 2018-03-24 15:46:00 --> Config Class Initialized
INFO - 2018-03-24 15:46:00 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:46:00 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:46:00 --> Utf8 Class Initialized
INFO - 2018-03-24 15:46:00 --> URI Class Initialized
INFO - 2018-03-24 15:46:00 --> Router Class Initialized
INFO - 2018-03-24 15:46:00 --> Output Class Initialized
INFO - 2018-03-24 15:46:00 --> Security Class Initialized
DEBUG - 2018-03-24 15:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:46:00 --> Input Class Initialized
INFO - 2018-03-24 15:46:00 --> Language Class Initialized
INFO - 2018-03-24 15:46:00 --> Loader Class Initialized
INFO - 2018-03-24 15:46:00 --> Helper loaded: url_helper
INFO - 2018-03-24 15:46:00 --> Helper loaded: form_helper
INFO - 2018-03-24 15:46:00 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:46:00 --> Controller Class Initialized
INFO - 2018-03-24 15:46:00 --> Model Class Initialized
INFO - 2018-03-24 15:46:00 --> Model Class Initialized
INFO - 2018-03-24 15:46:00 --> Model Class Initialized
INFO - 2018-03-24 15:46:00 --> Model Class Initialized
INFO - 2018-03-24 15:46:00 --> Model Class Initialized
INFO - 2018-03-24 15:46:00 --> Helper loaded: date_helper
INFO - 2018-03-24 15:46:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:46:00 --> Final output sent to browser
DEBUG - 2018-03-24 21:46:00 --> Total execution time: 0.0908
INFO - 2018-03-24 15:49:50 --> Config Class Initialized
INFO - 2018-03-24 15:49:50 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:49:50 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:49:50 --> Utf8 Class Initialized
INFO - 2018-03-24 15:49:50 --> URI Class Initialized
INFO - 2018-03-24 15:49:50 --> Router Class Initialized
INFO - 2018-03-24 15:49:50 --> Output Class Initialized
INFO - 2018-03-24 15:49:50 --> Security Class Initialized
DEBUG - 2018-03-24 15:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:49:50 --> Input Class Initialized
INFO - 2018-03-24 15:49:50 --> Language Class Initialized
INFO - 2018-03-24 15:49:50 --> Loader Class Initialized
INFO - 2018-03-24 15:49:50 --> Helper loaded: url_helper
INFO - 2018-03-24 15:49:50 --> Helper loaded: form_helper
INFO - 2018-03-24 15:49:50 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:49:50 --> Controller Class Initialized
INFO - 2018-03-24 15:49:50 --> Model Class Initialized
INFO - 2018-03-24 15:49:50 --> Model Class Initialized
INFO - 2018-03-24 15:49:50 --> Model Class Initialized
INFO - 2018-03-24 15:49:50 --> Model Class Initialized
INFO - 2018-03-24 15:49:50 --> Model Class Initialized
INFO - 2018-03-24 15:49:50 --> Helper loaded: date_helper
INFO - 2018-03-24 15:49:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:49:50 --> Final output sent to browser
DEBUG - 2018-03-24 21:49:50 --> Total execution time: 0.1077
INFO - 2018-03-24 15:49:53 --> Config Class Initialized
INFO - 2018-03-24 15:49:53 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:49:53 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:49:53 --> Utf8 Class Initialized
INFO - 2018-03-24 15:49:53 --> URI Class Initialized
INFO - 2018-03-24 15:49:53 --> Router Class Initialized
INFO - 2018-03-24 15:49:53 --> Output Class Initialized
INFO - 2018-03-24 15:49:53 --> Security Class Initialized
DEBUG - 2018-03-24 15:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:49:53 --> Input Class Initialized
INFO - 2018-03-24 15:49:53 --> Language Class Initialized
INFO - 2018-03-24 15:49:53 --> Loader Class Initialized
INFO - 2018-03-24 15:49:53 --> Helper loaded: url_helper
INFO - 2018-03-24 15:49:53 --> Helper loaded: form_helper
INFO - 2018-03-24 15:49:53 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:49:53 --> Controller Class Initialized
INFO - 2018-03-24 15:49:53 --> Model Class Initialized
INFO - 2018-03-24 15:49:53 --> Model Class Initialized
INFO - 2018-03-24 15:49:53 --> Model Class Initialized
INFO - 2018-03-24 15:49:53 --> Model Class Initialized
INFO - 2018-03-24 15:49:53 --> Model Class Initialized
INFO - 2018-03-24 15:49:53 --> Helper loaded: date_helper
INFO - 2018-03-24 15:49:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:49:53 --> Model Class Initialized
INFO - 2018-03-24 21:49:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 21:49:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 21:49:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 21:49:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 21:49:53 --> Final output sent to browser
DEBUG - 2018-03-24 21:49:53 --> Total execution time: 0.1040
INFO - 2018-03-24 15:49:57 --> Config Class Initialized
INFO - 2018-03-24 15:49:57 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:49:57 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:49:57 --> Utf8 Class Initialized
INFO - 2018-03-24 15:49:57 --> URI Class Initialized
INFO - 2018-03-24 15:49:57 --> Router Class Initialized
INFO - 2018-03-24 15:49:57 --> Output Class Initialized
INFO - 2018-03-24 15:49:57 --> Security Class Initialized
DEBUG - 2018-03-24 15:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:49:57 --> Input Class Initialized
INFO - 2018-03-24 15:49:57 --> Language Class Initialized
INFO - 2018-03-24 15:49:57 --> Loader Class Initialized
INFO - 2018-03-24 15:49:57 --> Helper loaded: url_helper
INFO - 2018-03-24 15:49:57 --> Helper loaded: form_helper
INFO - 2018-03-24 15:49:57 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:49:57 --> Controller Class Initialized
INFO - 2018-03-24 15:49:57 --> Model Class Initialized
INFO - 2018-03-24 15:49:57 --> Model Class Initialized
INFO - 2018-03-24 15:49:57 --> Model Class Initialized
INFO - 2018-03-24 15:49:57 --> Model Class Initialized
INFO - 2018-03-24 15:49:57 --> Model Class Initialized
INFO - 2018-03-24 15:49:57 --> Helper loaded: date_helper
INFO - 2018-03-24 15:49:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:49:57 --> Final output sent to browser
DEBUG - 2018-03-24 21:49:57 --> Total execution time: 0.0728
INFO - 2018-03-24 15:50:12 --> Config Class Initialized
INFO - 2018-03-24 15:50:12 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:50:12 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:50:12 --> Utf8 Class Initialized
INFO - 2018-03-24 15:50:12 --> URI Class Initialized
INFO - 2018-03-24 15:50:12 --> Router Class Initialized
INFO - 2018-03-24 15:50:12 --> Output Class Initialized
INFO - 2018-03-24 15:50:12 --> Security Class Initialized
DEBUG - 2018-03-24 15:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:50:12 --> Input Class Initialized
INFO - 2018-03-24 15:50:12 --> Language Class Initialized
INFO - 2018-03-24 15:50:12 --> Loader Class Initialized
INFO - 2018-03-24 15:50:12 --> Helper loaded: url_helper
INFO - 2018-03-24 15:50:12 --> Helper loaded: form_helper
INFO - 2018-03-24 15:50:12 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:50:12 --> Controller Class Initialized
INFO - 2018-03-24 15:50:12 --> Model Class Initialized
INFO - 2018-03-24 15:50:12 --> Model Class Initialized
INFO - 2018-03-24 15:50:12 --> Model Class Initialized
INFO - 2018-03-24 15:50:12 --> Model Class Initialized
INFO - 2018-03-24 15:50:12 --> Model Class Initialized
INFO - 2018-03-24 15:50:12 --> Helper loaded: date_helper
INFO - 2018-03-24 15:50:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:50:12 --> Model Class Initialized
INFO - 2018-03-24 21:50:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 21:50:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 21:50:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 21:50:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 21:50:12 --> Final output sent to browser
DEBUG - 2018-03-24 21:50:12 --> Total execution time: 0.0953
INFO - 2018-03-24 15:50:21 --> Config Class Initialized
INFO - 2018-03-24 15:50:21 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:50:21 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:50:21 --> Utf8 Class Initialized
INFO - 2018-03-24 15:50:21 --> URI Class Initialized
INFO - 2018-03-24 15:50:21 --> Router Class Initialized
INFO - 2018-03-24 15:50:21 --> Output Class Initialized
INFO - 2018-03-24 15:50:21 --> Security Class Initialized
DEBUG - 2018-03-24 15:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:50:21 --> Input Class Initialized
INFO - 2018-03-24 15:50:21 --> Language Class Initialized
INFO - 2018-03-24 15:50:21 --> Loader Class Initialized
INFO - 2018-03-24 15:50:21 --> Helper loaded: url_helper
INFO - 2018-03-24 15:50:21 --> Helper loaded: form_helper
INFO - 2018-03-24 15:50:21 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:50:21 --> Controller Class Initialized
INFO - 2018-03-24 15:50:21 --> Model Class Initialized
INFO - 2018-03-24 15:50:21 --> Model Class Initialized
INFO - 2018-03-24 15:50:21 --> Model Class Initialized
INFO - 2018-03-24 15:50:21 --> Model Class Initialized
INFO - 2018-03-24 15:50:21 --> Model Class Initialized
INFO - 2018-03-24 15:50:21 --> Helper loaded: date_helper
INFO - 2018-03-24 15:50:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:50:21 --> Model Class Initialized
INFO - 2018-03-24 21:50:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 21:50:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 21:50:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 21:50:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 21:50:21 --> Final output sent to browser
DEBUG - 2018-03-24 21:50:21 --> Total execution time: 0.1076
INFO - 2018-03-24 15:59:22 --> Config Class Initialized
INFO - 2018-03-24 15:59:22 --> Hooks Class Initialized
DEBUG - 2018-03-24 15:59:22 --> UTF-8 Support Enabled
INFO - 2018-03-24 15:59:22 --> Utf8 Class Initialized
INFO - 2018-03-24 15:59:22 --> URI Class Initialized
INFO - 2018-03-24 15:59:22 --> Router Class Initialized
INFO - 2018-03-24 15:59:22 --> Output Class Initialized
INFO - 2018-03-24 15:59:22 --> Security Class Initialized
DEBUG - 2018-03-24 15:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 15:59:22 --> Input Class Initialized
INFO - 2018-03-24 15:59:22 --> Language Class Initialized
INFO - 2018-03-24 15:59:22 --> Loader Class Initialized
INFO - 2018-03-24 15:59:22 --> Helper loaded: url_helper
INFO - 2018-03-24 15:59:22 --> Helper loaded: form_helper
INFO - 2018-03-24 15:59:22 --> Database Driver Class Initialized
DEBUG - 2018-03-24 15:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 15:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 15:59:22 --> Controller Class Initialized
INFO - 2018-03-24 15:59:22 --> Model Class Initialized
INFO - 2018-03-24 15:59:22 --> Model Class Initialized
INFO - 2018-03-24 15:59:22 --> Model Class Initialized
INFO - 2018-03-24 15:59:22 --> Model Class Initialized
INFO - 2018-03-24 15:59:22 --> Model Class Initialized
INFO - 2018-03-24 15:59:22 --> Helper loaded: date_helper
INFO - 2018-03-24 15:59:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 21:59:22 --> Model Class Initialized
INFO - 2018-03-24 21:59:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 21:59:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 21:59:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 21:59:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 21:59:22 --> Final output sent to browser
DEBUG - 2018-03-24 21:59:22 --> Total execution time: 0.0910
INFO - 2018-03-24 16:03:41 --> Config Class Initialized
INFO - 2018-03-24 16:03:41 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:03:41 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:03:41 --> Utf8 Class Initialized
INFO - 2018-03-24 16:03:41 --> URI Class Initialized
INFO - 2018-03-24 16:03:41 --> Router Class Initialized
INFO - 2018-03-24 16:03:41 --> Output Class Initialized
INFO - 2018-03-24 16:03:41 --> Security Class Initialized
DEBUG - 2018-03-24 16:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:03:41 --> Input Class Initialized
INFO - 2018-03-24 16:03:41 --> Language Class Initialized
INFO - 2018-03-24 16:03:41 --> Loader Class Initialized
INFO - 2018-03-24 16:03:41 --> Helper loaded: url_helper
INFO - 2018-03-24 16:03:41 --> Helper loaded: form_helper
INFO - 2018-03-24 16:03:41 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:03:41 --> Controller Class Initialized
INFO - 2018-03-24 16:03:41 --> Model Class Initialized
INFO - 2018-03-24 16:03:41 --> Model Class Initialized
INFO - 2018-03-24 16:03:41 --> Model Class Initialized
INFO - 2018-03-24 16:03:41 --> Model Class Initialized
INFO - 2018-03-24 16:03:41 --> Model Class Initialized
INFO - 2018-03-24 16:03:41 --> Helper loaded: date_helper
INFO - 2018-03-24 16:03:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 22:03:41 --> Model Class Initialized
INFO - 2018-03-24 22:03:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 22:03:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 22:03:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 22:03:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 22:03:41 --> Final output sent to browser
DEBUG - 2018-03-24 22:03:41 --> Total execution time: 0.0942
INFO - 2018-03-24 16:03:45 --> Config Class Initialized
INFO - 2018-03-24 16:03:45 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:03:45 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:03:45 --> Utf8 Class Initialized
INFO - 2018-03-24 16:03:45 --> URI Class Initialized
INFO - 2018-03-24 16:03:45 --> Router Class Initialized
INFO - 2018-03-24 16:03:45 --> Output Class Initialized
INFO - 2018-03-24 16:03:45 --> Security Class Initialized
DEBUG - 2018-03-24 16:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:03:45 --> Input Class Initialized
INFO - 2018-03-24 16:03:45 --> Language Class Initialized
INFO - 2018-03-24 16:03:45 --> Loader Class Initialized
INFO - 2018-03-24 16:03:45 --> Helper loaded: url_helper
INFO - 2018-03-24 16:03:45 --> Helper loaded: form_helper
INFO - 2018-03-24 16:03:45 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:03:45 --> Controller Class Initialized
INFO - 2018-03-24 16:03:45 --> Model Class Initialized
INFO - 2018-03-24 16:03:45 --> Model Class Initialized
INFO - 2018-03-24 16:03:45 --> Model Class Initialized
INFO - 2018-03-24 16:03:45 --> Model Class Initialized
INFO - 2018-03-24 16:03:45 --> Model Class Initialized
INFO - 2018-03-24 16:03:45 --> Helper loaded: date_helper
INFO - 2018-03-24 16:03:45 --> Helper loaded: tanggal_helper
ERROR - 2018-03-24 22:03:46 --> Severity: error --> Exception: Call to undefined method stdClass::total() E:\xampp\htdocs\skin_care\application\models\Penjualan_model.php 59
INFO - 2018-03-24 16:03:52 --> Config Class Initialized
INFO - 2018-03-24 16:03:52 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:03:52 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:03:52 --> Utf8 Class Initialized
INFO - 2018-03-24 16:03:52 --> URI Class Initialized
INFO - 2018-03-24 16:03:52 --> Router Class Initialized
INFO - 2018-03-24 16:03:52 --> Output Class Initialized
INFO - 2018-03-24 16:03:52 --> Security Class Initialized
DEBUG - 2018-03-24 16:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:03:52 --> Input Class Initialized
INFO - 2018-03-24 16:03:52 --> Language Class Initialized
INFO - 2018-03-24 16:03:52 --> Loader Class Initialized
INFO - 2018-03-24 16:03:52 --> Helper loaded: url_helper
INFO - 2018-03-24 16:03:52 --> Helper loaded: form_helper
INFO - 2018-03-24 16:03:52 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:03:52 --> Controller Class Initialized
INFO - 2018-03-24 16:03:52 --> Model Class Initialized
INFO - 2018-03-24 16:03:52 --> Model Class Initialized
INFO - 2018-03-24 16:03:52 --> Model Class Initialized
INFO - 2018-03-24 16:03:52 --> Model Class Initialized
INFO - 2018-03-24 16:03:52 --> Model Class Initialized
INFO - 2018-03-24 16:03:52 --> Helper loaded: date_helper
INFO - 2018-03-24 16:03:52 --> Helper loaded: tanggal_helper
ERROR - 2018-03-24 22:03:52 --> Severity: error --> Exception: Call to undefined method stdClass::total() E:\xampp\htdocs\skin_care\application\models\Penjualan_model.php 59
INFO - 2018-03-24 16:04:37 --> Config Class Initialized
INFO - 2018-03-24 16:04:37 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:04:37 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:04:37 --> Utf8 Class Initialized
INFO - 2018-03-24 16:04:37 --> URI Class Initialized
INFO - 2018-03-24 16:04:37 --> Router Class Initialized
INFO - 2018-03-24 16:04:37 --> Output Class Initialized
INFO - 2018-03-24 16:04:37 --> Security Class Initialized
DEBUG - 2018-03-24 16:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:04:37 --> Input Class Initialized
INFO - 2018-03-24 16:04:37 --> Language Class Initialized
INFO - 2018-03-24 16:04:37 --> Loader Class Initialized
INFO - 2018-03-24 16:04:37 --> Helper loaded: url_helper
INFO - 2018-03-24 16:04:37 --> Helper loaded: form_helper
INFO - 2018-03-24 16:04:37 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:04:37 --> Controller Class Initialized
INFO - 2018-03-24 16:04:37 --> Model Class Initialized
INFO - 2018-03-24 16:04:37 --> Model Class Initialized
INFO - 2018-03-24 16:04:37 --> Model Class Initialized
INFO - 2018-03-24 16:04:37 --> Model Class Initialized
INFO - 2018-03-24 16:04:37 --> Model Class Initialized
INFO - 2018-03-24 16:04:37 --> Helper loaded: date_helper
INFO - 2018-03-24 16:04:37 --> Helper loaded: tanggal_helper
ERROR - 2018-03-24 22:04:37 --> Severity: error --> Exception: Call to undefined method stdClass::stockRusak() E:\xampp\htdocs\skin_care\application\models\Product_model.php 42
INFO - 2018-03-24 16:04:41 --> Config Class Initialized
INFO - 2018-03-24 16:04:41 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:04:41 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:04:41 --> Utf8 Class Initialized
INFO - 2018-03-24 16:04:41 --> URI Class Initialized
INFO - 2018-03-24 16:04:41 --> Router Class Initialized
INFO - 2018-03-24 16:04:41 --> Output Class Initialized
INFO - 2018-03-24 16:04:41 --> Security Class Initialized
DEBUG - 2018-03-24 16:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:04:41 --> Input Class Initialized
INFO - 2018-03-24 16:04:41 --> Language Class Initialized
INFO - 2018-03-24 16:04:41 --> Loader Class Initialized
INFO - 2018-03-24 16:04:41 --> Helper loaded: url_helper
INFO - 2018-03-24 16:04:41 --> Helper loaded: form_helper
INFO - 2018-03-24 16:04:41 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:04:41 --> Controller Class Initialized
INFO - 2018-03-24 16:04:41 --> Model Class Initialized
INFO - 2018-03-24 16:04:41 --> Model Class Initialized
INFO - 2018-03-24 16:04:41 --> Model Class Initialized
INFO - 2018-03-24 16:04:41 --> Model Class Initialized
INFO - 2018-03-24 16:04:41 --> Model Class Initialized
INFO - 2018-03-24 16:04:41 --> Helper loaded: date_helper
INFO - 2018-03-24 16:04:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 22:04:41 --> Model Class Initialized
INFO - 2018-03-24 22:04:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 22:04:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 22:04:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 22:04:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 22:04:41 --> Final output sent to browser
DEBUG - 2018-03-24 22:04:41 --> Total execution time: 0.0962
INFO - 2018-03-24 16:04:45 --> Config Class Initialized
INFO - 2018-03-24 16:04:45 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:04:45 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:04:45 --> Utf8 Class Initialized
INFO - 2018-03-24 16:04:45 --> URI Class Initialized
INFO - 2018-03-24 16:04:45 --> Router Class Initialized
INFO - 2018-03-24 16:04:45 --> Output Class Initialized
INFO - 2018-03-24 16:04:45 --> Security Class Initialized
DEBUG - 2018-03-24 16:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:04:45 --> Input Class Initialized
INFO - 2018-03-24 16:04:45 --> Language Class Initialized
INFO - 2018-03-24 16:04:45 --> Loader Class Initialized
INFO - 2018-03-24 16:04:45 --> Helper loaded: url_helper
INFO - 2018-03-24 16:04:45 --> Helper loaded: form_helper
INFO - 2018-03-24 16:04:45 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:04:45 --> Controller Class Initialized
INFO - 2018-03-24 16:04:45 --> Model Class Initialized
INFO - 2018-03-24 16:04:45 --> Model Class Initialized
INFO - 2018-03-24 16:04:45 --> Model Class Initialized
INFO - 2018-03-24 16:04:45 --> Model Class Initialized
INFO - 2018-03-24 16:04:45 --> Model Class Initialized
INFO - 2018-03-24 16:04:45 --> Helper loaded: date_helper
INFO - 2018-03-24 16:04:45 --> Helper loaded: tanggal_helper
ERROR - 2018-03-24 22:04:45 --> Severity: error --> Exception: Call to undefined method stdClass::stockRusak() E:\xampp\htdocs\skin_care\application\models\Product_model.php 42
INFO - 2018-03-24 16:05:27 --> Config Class Initialized
INFO - 2018-03-24 16:05:27 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:05:27 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:05:27 --> Utf8 Class Initialized
INFO - 2018-03-24 16:05:27 --> URI Class Initialized
INFO - 2018-03-24 16:05:27 --> Router Class Initialized
INFO - 2018-03-24 16:05:27 --> Output Class Initialized
INFO - 2018-03-24 16:05:27 --> Security Class Initialized
DEBUG - 2018-03-24 16:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:05:27 --> Input Class Initialized
INFO - 2018-03-24 16:05:27 --> Language Class Initialized
INFO - 2018-03-24 16:05:27 --> Loader Class Initialized
INFO - 2018-03-24 16:05:27 --> Helper loaded: url_helper
INFO - 2018-03-24 16:05:27 --> Helper loaded: form_helper
INFO - 2018-03-24 16:05:27 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:05:27 --> Controller Class Initialized
INFO - 2018-03-24 16:05:27 --> Model Class Initialized
INFO - 2018-03-24 16:05:27 --> Model Class Initialized
INFO - 2018-03-24 16:05:27 --> Model Class Initialized
INFO - 2018-03-24 16:05:27 --> Model Class Initialized
INFO - 2018-03-24 16:05:27 --> Model Class Initialized
INFO - 2018-03-24 16:05:27 --> Helper loaded: date_helper
INFO - 2018-03-24 16:05:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 22:05:27 --> Model Class Initialized
INFO - 2018-03-24 22:05:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 22:05:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 22:05:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 22:05:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 22:05:27 --> Final output sent to browser
DEBUG - 2018-03-24 22:05:27 --> Total execution time: 0.1065
INFO - 2018-03-24 16:05:32 --> Config Class Initialized
INFO - 2018-03-24 16:05:32 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:05:32 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:05:32 --> Utf8 Class Initialized
INFO - 2018-03-24 16:05:32 --> URI Class Initialized
INFO - 2018-03-24 16:05:32 --> Router Class Initialized
INFO - 2018-03-24 16:05:32 --> Output Class Initialized
INFO - 2018-03-24 16:05:32 --> Security Class Initialized
DEBUG - 2018-03-24 16:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:05:32 --> Input Class Initialized
INFO - 2018-03-24 16:05:32 --> Language Class Initialized
INFO - 2018-03-24 16:05:32 --> Loader Class Initialized
INFO - 2018-03-24 16:05:32 --> Helper loaded: url_helper
INFO - 2018-03-24 16:05:32 --> Helper loaded: form_helper
INFO - 2018-03-24 16:05:32 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:05:32 --> Controller Class Initialized
INFO - 2018-03-24 16:05:32 --> Model Class Initialized
INFO - 2018-03-24 16:05:32 --> Model Class Initialized
INFO - 2018-03-24 16:05:32 --> Helper loaded: date_helper
INFO - 2018-03-24 16:05:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 22:05:32 --> Final output sent to browser
DEBUG - 2018-03-24 22:05:32 --> Total execution time: 0.0800
INFO - 2018-03-24 16:05:36 --> Config Class Initialized
INFO - 2018-03-24 16:05:36 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:05:36 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:05:36 --> Utf8 Class Initialized
INFO - 2018-03-24 16:05:36 --> URI Class Initialized
INFO - 2018-03-24 16:05:36 --> Router Class Initialized
INFO - 2018-03-24 16:05:36 --> Output Class Initialized
INFO - 2018-03-24 16:05:36 --> Security Class Initialized
DEBUG - 2018-03-24 16:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:05:36 --> Input Class Initialized
INFO - 2018-03-24 16:05:36 --> Language Class Initialized
INFO - 2018-03-24 16:05:36 --> Loader Class Initialized
INFO - 2018-03-24 16:05:36 --> Helper loaded: url_helper
INFO - 2018-03-24 16:05:36 --> Helper loaded: form_helper
INFO - 2018-03-24 16:05:36 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:05:36 --> Controller Class Initialized
INFO - 2018-03-24 16:05:36 --> Model Class Initialized
INFO - 2018-03-24 16:05:36 --> Model Class Initialized
INFO - 2018-03-24 16:05:36 --> Model Class Initialized
INFO - 2018-03-24 16:05:36 --> Model Class Initialized
INFO - 2018-03-24 16:05:36 --> Model Class Initialized
INFO - 2018-03-24 16:05:36 --> Helper loaded: date_helper
INFO - 2018-03-24 16:05:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 22:05:36 --> Final output sent to browser
DEBUG - 2018-03-24 22:05:36 --> Total execution time: 0.0899
INFO - 2018-03-24 16:30:31 --> Config Class Initialized
INFO - 2018-03-24 16:30:31 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:30:31 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:30:31 --> Utf8 Class Initialized
INFO - 2018-03-24 16:30:31 --> URI Class Initialized
INFO - 2018-03-24 16:30:31 --> Router Class Initialized
INFO - 2018-03-24 16:30:31 --> Output Class Initialized
INFO - 2018-03-24 16:30:31 --> Security Class Initialized
DEBUG - 2018-03-24 16:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:30:31 --> Input Class Initialized
INFO - 2018-03-24 16:30:31 --> Language Class Initialized
INFO - 2018-03-24 16:30:31 --> Loader Class Initialized
INFO - 2018-03-24 16:30:31 --> Helper loaded: url_helper
INFO - 2018-03-24 16:30:31 --> Helper loaded: form_helper
INFO - 2018-03-24 16:30:31 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:30:31 --> Controller Class Initialized
INFO - 2018-03-24 16:30:31 --> Model Class Initialized
INFO - 2018-03-24 16:30:31 --> Model Class Initialized
INFO - 2018-03-24 16:30:31 --> Model Class Initialized
INFO - 2018-03-24 16:30:31 --> Model Class Initialized
INFO - 2018-03-24 16:30:31 --> Model Class Initialized
INFO - 2018-03-24 16:30:31 --> Helper loaded: date_helper
INFO - 2018-03-24 16:30:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 22:30:31 --> Final output sent to browser
DEBUG - 2018-03-24 22:30:31 --> Total execution time: 0.0783
INFO - 2018-03-24 16:30:34 --> Config Class Initialized
INFO - 2018-03-24 16:30:34 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:30:34 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:30:34 --> Utf8 Class Initialized
INFO - 2018-03-24 16:30:34 --> URI Class Initialized
INFO - 2018-03-24 16:30:34 --> Router Class Initialized
INFO - 2018-03-24 16:30:34 --> Output Class Initialized
INFO - 2018-03-24 16:30:34 --> Security Class Initialized
DEBUG - 2018-03-24 16:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:30:34 --> Input Class Initialized
INFO - 2018-03-24 16:30:34 --> Language Class Initialized
INFO - 2018-03-24 16:30:34 --> Loader Class Initialized
INFO - 2018-03-24 16:30:34 --> Helper loaded: url_helper
INFO - 2018-03-24 16:30:34 --> Helper loaded: form_helper
INFO - 2018-03-24 16:30:34 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:30:34 --> Controller Class Initialized
INFO - 2018-03-24 16:30:34 --> Model Class Initialized
INFO - 2018-03-24 16:30:34 --> Model Class Initialized
INFO - 2018-03-24 16:30:34 --> Model Class Initialized
INFO - 2018-03-24 16:30:34 --> Model Class Initialized
INFO - 2018-03-24 16:30:34 --> Model Class Initialized
INFO - 2018-03-24 16:30:34 --> Helper loaded: date_helper
INFO - 2018-03-24 16:30:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 22:30:34 --> Model Class Initialized
INFO - 2018-03-24 22:30:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 22:30:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 22:30:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-24 22:30:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 22:30:34 --> Final output sent to browser
DEBUG - 2018-03-24 22:30:34 --> Total execution time: 0.1022
INFO - 2018-03-24 16:30:38 --> Config Class Initialized
INFO - 2018-03-24 16:30:38 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:30:38 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:30:38 --> Utf8 Class Initialized
INFO - 2018-03-24 16:30:38 --> URI Class Initialized
INFO - 2018-03-24 16:30:38 --> Router Class Initialized
INFO - 2018-03-24 16:30:38 --> Output Class Initialized
INFO - 2018-03-24 16:30:38 --> Security Class Initialized
DEBUG - 2018-03-24 16:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:30:38 --> Input Class Initialized
INFO - 2018-03-24 16:30:38 --> Language Class Initialized
INFO - 2018-03-24 16:30:38 --> Loader Class Initialized
INFO - 2018-03-24 16:30:38 --> Helper loaded: url_helper
INFO - 2018-03-24 16:30:38 --> Helper loaded: form_helper
INFO - 2018-03-24 16:30:38 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:30:38 --> Controller Class Initialized
INFO - 2018-03-24 16:30:38 --> Model Class Initialized
INFO - 2018-03-24 16:30:38 --> Model Class Initialized
INFO - 2018-03-24 16:30:38 --> Model Class Initialized
INFO - 2018-03-24 16:30:38 --> Model Class Initialized
INFO - 2018-03-24 16:30:38 --> Model Class Initialized
INFO - 2018-03-24 16:30:39 --> Helper loaded: date_helper
INFO - 2018-03-24 16:30:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 22:30:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-24 22:30:39 --> Final output sent to browser
DEBUG - 2018-03-24 22:30:39 --> Total execution time: 0.0692
INFO - 2018-03-24 16:30:40 --> Config Class Initialized
INFO - 2018-03-24 16:30:40 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:30:40 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:30:40 --> Utf8 Class Initialized
INFO - 2018-03-24 16:30:40 --> URI Class Initialized
INFO - 2018-03-24 16:30:40 --> Router Class Initialized
INFO - 2018-03-24 16:30:40 --> Output Class Initialized
INFO - 2018-03-24 16:30:40 --> Security Class Initialized
DEBUG - 2018-03-24 16:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:30:40 --> Input Class Initialized
INFO - 2018-03-24 16:30:40 --> Language Class Initialized
INFO - 2018-03-24 16:30:40 --> Loader Class Initialized
INFO - 2018-03-24 16:30:40 --> Helper loaded: url_helper
INFO - 2018-03-24 16:30:40 --> Helper loaded: form_helper
INFO - 2018-03-24 16:30:40 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:30:40 --> Controller Class Initialized
INFO - 2018-03-24 16:30:40 --> Model Class Initialized
INFO - 2018-03-24 16:30:40 --> Model Class Initialized
INFO - 2018-03-24 16:30:40 --> Model Class Initialized
INFO - 2018-03-24 16:30:40 --> Model Class Initialized
INFO - 2018-03-24 16:30:40 --> Model Class Initialized
INFO - 2018-03-24 16:30:40 --> Helper loaded: date_helper
INFO - 2018-03-24 16:30:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 22:30:40 --> Model Class Initialized
INFO - 2018-03-24 22:30:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 22:30:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 22:30:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 22:30:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 22:30:40 --> Final output sent to browser
DEBUG - 2018-03-24 22:30:40 --> Total execution time: 0.1204
INFO - 2018-03-24 16:53:35 --> Config Class Initialized
INFO - 2018-03-24 16:53:35 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:53:35 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:53:35 --> Utf8 Class Initialized
INFO - 2018-03-24 16:53:35 --> URI Class Initialized
INFO - 2018-03-24 16:53:35 --> Router Class Initialized
INFO - 2018-03-24 16:53:35 --> Output Class Initialized
INFO - 2018-03-24 16:53:35 --> Security Class Initialized
DEBUG - 2018-03-24 16:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:53:35 --> Input Class Initialized
INFO - 2018-03-24 16:53:35 --> Language Class Initialized
INFO - 2018-03-24 16:53:35 --> Loader Class Initialized
INFO - 2018-03-24 16:53:35 --> Helper loaded: url_helper
INFO - 2018-03-24 16:53:35 --> Helper loaded: form_helper
INFO - 2018-03-24 16:53:35 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:53:35 --> Controller Class Initialized
INFO - 2018-03-24 16:53:35 --> Model Class Initialized
INFO - 2018-03-24 16:53:35 --> Model Class Initialized
INFO - 2018-03-24 16:53:35 --> Model Class Initialized
INFO - 2018-03-24 16:53:35 --> Model Class Initialized
INFO - 2018-03-24 16:53:35 --> Model Class Initialized
INFO - 2018-03-24 16:53:35 --> Model Class Initialized
INFO - 2018-03-24 16:53:35 --> Helper loaded: date_helper
INFO - 2018-03-24 16:53:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 22:53:35 --> Model Class Initialized
INFO - 2018-03-24 22:53:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 22:53:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 22:53:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 22:53:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 22:53:35 --> Final output sent to browser
DEBUG - 2018-03-24 22:53:35 --> Total execution time: 0.0933
INFO - 2018-03-24 16:53:53 --> Config Class Initialized
INFO - 2018-03-24 16:53:53 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:53:53 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:53:53 --> Utf8 Class Initialized
INFO - 2018-03-24 16:53:53 --> URI Class Initialized
INFO - 2018-03-24 16:53:53 --> Router Class Initialized
INFO - 2018-03-24 16:53:53 --> Output Class Initialized
INFO - 2018-03-24 16:53:53 --> Security Class Initialized
DEBUG - 2018-03-24 16:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:53:53 --> Input Class Initialized
INFO - 2018-03-24 16:53:53 --> Language Class Initialized
INFO - 2018-03-24 16:53:53 --> Loader Class Initialized
INFO - 2018-03-24 16:53:53 --> Helper loaded: url_helper
INFO - 2018-03-24 16:53:53 --> Helper loaded: form_helper
INFO - 2018-03-24 16:53:53 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:53:53 --> Controller Class Initialized
INFO - 2018-03-24 16:53:53 --> Model Class Initialized
INFO - 2018-03-24 16:53:53 --> Model Class Initialized
INFO - 2018-03-24 16:53:53 --> Helper loaded: date_helper
INFO - 2018-03-24 16:53:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 22:53:53 --> Final output sent to browser
DEBUG - 2018-03-24 22:53:53 --> Total execution time: 0.0858
INFO - 2018-03-24 16:54:03 --> Config Class Initialized
INFO - 2018-03-24 16:54:03 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:54:03 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:54:03 --> Utf8 Class Initialized
INFO - 2018-03-24 16:54:03 --> URI Class Initialized
INFO - 2018-03-24 16:54:03 --> Router Class Initialized
INFO - 2018-03-24 16:54:03 --> Output Class Initialized
INFO - 2018-03-24 16:54:03 --> Security Class Initialized
DEBUG - 2018-03-24 16:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:54:03 --> Input Class Initialized
INFO - 2018-03-24 16:54:03 --> Language Class Initialized
INFO - 2018-03-24 16:54:03 --> Loader Class Initialized
INFO - 2018-03-24 16:54:03 --> Helper loaded: url_helper
INFO - 2018-03-24 16:54:03 --> Helper loaded: form_helper
INFO - 2018-03-24 16:54:03 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:54:03 --> Controller Class Initialized
INFO - 2018-03-24 16:54:03 --> Model Class Initialized
INFO - 2018-03-24 16:54:03 --> Model Class Initialized
INFO - 2018-03-24 16:54:03 --> Model Class Initialized
INFO - 2018-03-24 16:54:03 --> Model Class Initialized
INFO - 2018-03-24 16:54:03 --> Model Class Initialized
INFO - 2018-03-24 16:54:03 --> Model Class Initialized
INFO - 2018-03-24 16:54:03 --> Helper loaded: date_helper
INFO - 2018-03-24 16:54:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 22:54:03 --> Final output sent to browser
DEBUG - 2018-03-24 22:54:03 --> Total execution time: 0.2235
INFO - 2018-03-24 16:54:16 --> Config Class Initialized
INFO - 2018-03-24 16:54:16 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:54:16 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:54:16 --> Utf8 Class Initialized
INFO - 2018-03-24 16:54:16 --> URI Class Initialized
INFO - 2018-03-24 16:54:16 --> Router Class Initialized
INFO - 2018-03-24 16:54:16 --> Output Class Initialized
INFO - 2018-03-24 16:54:16 --> Security Class Initialized
DEBUG - 2018-03-24 16:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:54:16 --> Input Class Initialized
INFO - 2018-03-24 16:54:16 --> Language Class Initialized
INFO - 2018-03-24 16:54:16 --> Loader Class Initialized
INFO - 2018-03-24 16:54:16 --> Helper loaded: url_helper
INFO - 2018-03-24 16:54:16 --> Helper loaded: form_helper
INFO - 2018-03-24 16:54:16 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:54:16 --> Controller Class Initialized
INFO - 2018-03-24 16:54:16 --> Model Class Initialized
INFO - 2018-03-24 16:54:16 --> Model Class Initialized
INFO - 2018-03-24 16:54:16 --> Model Class Initialized
INFO - 2018-03-24 16:54:16 --> Model Class Initialized
INFO - 2018-03-24 16:54:16 --> Model Class Initialized
INFO - 2018-03-24 16:54:16 --> Model Class Initialized
INFO - 2018-03-24 16:54:16 --> Helper loaded: date_helper
INFO - 2018-03-24 16:54:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 22:54:16 --> Model Class Initialized
INFO - 2018-03-24 22:54:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 22:54:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 22:54:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 22:54:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 22:54:16 --> Final output sent to browser
DEBUG - 2018-03-24 22:54:16 --> Total execution time: 0.1103
INFO - 2018-03-24 16:56:02 --> Config Class Initialized
INFO - 2018-03-24 16:56:02 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:56:02 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:56:02 --> Utf8 Class Initialized
INFO - 2018-03-24 16:56:02 --> URI Class Initialized
INFO - 2018-03-24 16:56:02 --> Router Class Initialized
INFO - 2018-03-24 16:56:02 --> Output Class Initialized
INFO - 2018-03-24 16:56:02 --> Security Class Initialized
DEBUG - 2018-03-24 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:56:02 --> Input Class Initialized
INFO - 2018-03-24 16:56:02 --> Language Class Initialized
INFO - 2018-03-24 16:56:02 --> Loader Class Initialized
INFO - 2018-03-24 16:56:02 --> Helper loaded: url_helper
INFO - 2018-03-24 16:56:02 --> Helper loaded: form_helper
INFO - 2018-03-24 16:56:02 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:56:02 --> Controller Class Initialized
INFO - 2018-03-24 16:56:02 --> Model Class Initialized
INFO - 2018-03-24 16:56:02 --> Model Class Initialized
INFO - 2018-03-24 16:56:02 --> Model Class Initialized
INFO - 2018-03-24 16:56:02 --> Model Class Initialized
INFO - 2018-03-24 16:56:02 --> Model Class Initialized
INFO - 2018-03-24 16:56:02 --> Model Class Initialized
INFO - 2018-03-24 16:56:02 --> Helper loaded: date_helper
INFO - 2018-03-24 16:56:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 22:56:02 --> Model Class Initialized
INFO - 2018-03-24 22:56:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 22:56:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 22:56:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 22:56:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 22:56:02 --> Final output sent to browser
DEBUG - 2018-03-24 22:56:02 --> Total execution time: 0.1186
INFO - 2018-03-24 16:57:00 --> Config Class Initialized
INFO - 2018-03-24 16:57:00 --> Hooks Class Initialized
DEBUG - 2018-03-24 16:57:00 --> UTF-8 Support Enabled
INFO - 2018-03-24 16:57:00 --> Utf8 Class Initialized
INFO - 2018-03-24 16:57:00 --> URI Class Initialized
INFO - 2018-03-24 16:57:00 --> Router Class Initialized
INFO - 2018-03-24 16:57:00 --> Output Class Initialized
INFO - 2018-03-24 16:57:00 --> Security Class Initialized
DEBUG - 2018-03-24 16:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 16:57:00 --> Input Class Initialized
INFO - 2018-03-24 16:57:00 --> Language Class Initialized
INFO - 2018-03-24 16:57:00 --> Loader Class Initialized
INFO - 2018-03-24 16:57:00 --> Helper loaded: url_helper
INFO - 2018-03-24 16:57:00 --> Helper loaded: form_helper
INFO - 2018-03-24 16:57:00 --> Database Driver Class Initialized
DEBUG - 2018-03-24 16:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 16:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 16:57:00 --> Controller Class Initialized
INFO - 2018-03-24 16:57:00 --> Model Class Initialized
INFO - 2018-03-24 16:57:00 --> Model Class Initialized
INFO - 2018-03-24 16:57:00 --> Model Class Initialized
INFO - 2018-03-24 16:57:00 --> Model Class Initialized
INFO - 2018-03-24 16:57:00 --> Model Class Initialized
INFO - 2018-03-24 16:57:00 --> Model Class Initialized
INFO - 2018-03-24 16:57:00 --> Helper loaded: date_helper
INFO - 2018-03-24 16:57:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 22:57:00 --> Model Class Initialized
INFO - 2018-03-24 22:57:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 22:57:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 22:57:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 22:57:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 22:57:00 --> Final output sent to browser
DEBUG - 2018-03-24 22:57:00 --> Total execution time: 0.1138
INFO - 2018-03-24 17:02:18 --> Config Class Initialized
INFO - 2018-03-24 17:02:18 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:02:18 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:02:18 --> Utf8 Class Initialized
INFO - 2018-03-24 17:02:18 --> URI Class Initialized
INFO - 2018-03-24 17:02:18 --> Router Class Initialized
INFO - 2018-03-24 17:02:18 --> Output Class Initialized
INFO - 2018-03-24 17:02:18 --> Security Class Initialized
DEBUG - 2018-03-24 17:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:02:18 --> Input Class Initialized
INFO - 2018-03-24 17:02:18 --> Language Class Initialized
INFO - 2018-03-24 17:02:18 --> Loader Class Initialized
INFO - 2018-03-24 17:02:18 --> Helper loaded: url_helper
INFO - 2018-03-24 17:02:18 --> Helper loaded: form_helper
INFO - 2018-03-24 17:02:18 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:02:18 --> Controller Class Initialized
INFO - 2018-03-24 17:02:18 --> Model Class Initialized
INFO - 2018-03-24 17:02:18 --> Model Class Initialized
INFO - 2018-03-24 17:02:18 --> Model Class Initialized
INFO - 2018-03-24 17:02:18 --> Model Class Initialized
INFO - 2018-03-24 17:02:18 --> Model Class Initialized
INFO - 2018-03-24 17:02:18 --> Model Class Initialized
INFO - 2018-03-24 17:02:18 --> Helper loaded: date_helper
INFO - 2018-03-24 17:02:18 --> Helper loaded: tanggal_helper
ERROR - 2018-03-24 23:02:18 --> Query error: Table 'klinik.pegawai' doesn't exist - Invalid query: SELECT *
FROM `retur`
INNER JOIN `product` ON `product`.`id_product` = `retur`.`id_product`
INNER JOIN `pegawai` ON `pegawai`.`id_mst_pegawai` = `retur`.`id_mst_pegawai`
WHERE `id_detail` = '15'
ERROR - 2018-03-24 23:02:18 --> Severity: error --> Exception: Call to a member function row() on boolean E:\xampp\htdocs\skin_care\application\models\Retur_model.php 31
INFO - 2018-03-24 17:04:24 --> Config Class Initialized
INFO - 2018-03-24 17:04:24 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:04:24 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:04:24 --> Utf8 Class Initialized
INFO - 2018-03-24 17:04:24 --> URI Class Initialized
INFO - 2018-03-24 17:04:24 --> Router Class Initialized
INFO - 2018-03-24 17:04:24 --> Output Class Initialized
INFO - 2018-03-24 17:04:24 --> Security Class Initialized
DEBUG - 2018-03-24 17:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:04:24 --> Input Class Initialized
INFO - 2018-03-24 17:04:24 --> Language Class Initialized
INFO - 2018-03-24 17:04:24 --> Loader Class Initialized
INFO - 2018-03-24 17:04:24 --> Helper loaded: url_helper
INFO - 2018-03-24 17:04:24 --> Helper loaded: form_helper
INFO - 2018-03-24 17:04:24 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:04:25 --> Controller Class Initialized
INFO - 2018-03-24 17:04:25 --> Model Class Initialized
INFO - 2018-03-24 17:04:25 --> Model Class Initialized
INFO - 2018-03-24 17:04:25 --> Model Class Initialized
INFO - 2018-03-24 17:04:25 --> Model Class Initialized
INFO - 2018-03-24 17:04:25 --> Model Class Initialized
INFO - 2018-03-24 17:04:25 --> Model Class Initialized
INFO - 2018-03-24 17:04:25 --> Helper loaded: date_helper
INFO - 2018-03-24 17:04:25 --> Helper loaded: tanggal_helper
ERROR - 2018-03-24 23:04:25 --> Query error: Table 'klinik.pegawai' doesn't exist - Invalid query: SELECT *
FROM `retur`
INNER JOIN `product` ON `product`.`id_product` = `retur`.`id_product`
INNER JOIN `pegawai` ON `pegawai`.`id_mst_pegawai` = `retur`.`id_mst_pegawai`
WHERE `id_detail` = '15'
ERROR - 2018-03-24 23:04:25 --> Severity: error --> Exception: Call to a member function result() on boolean E:\xampp\htdocs\skin_care\application\models\Retur_model.php 30
INFO - 2018-03-24 17:04:58 --> Config Class Initialized
INFO - 2018-03-24 17:04:58 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:04:58 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:04:58 --> Utf8 Class Initialized
INFO - 2018-03-24 17:04:58 --> URI Class Initialized
INFO - 2018-03-24 17:04:58 --> Router Class Initialized
INFO - 2018-03-24 17:04:58 --> Output Class Initialized
INFO - 2018-03-24 17:04:58 --> Security Class Initialized
DEBUG - 2018-03-24 17:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:04:58 --> Input Class Initialized
INFO - 2018-03-24 17:04:58 --> Language Class Initialized
INFO - 2018-03-24 17:04:58 --> Loader Class Initialized
INFO - 2018-03-24 17:04:58 --> Helper loaded: url_helper
INFO - 2018-03-24 17:04:58 --> Helper loaded: form_helper
INFO - 2018-03-24 17:04:58 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:04:58 --> Controller Class Initialized
INFO - 2018-03-24 17:04:58 --> Model Class Initialized
INFO - 2018-03-24 17:04:58 --> Model Class Initialized
INFO - 2018-03-24 17:04:58 --> Model Class Initialized
INFO - 2018-03-24 17:04:58 --> Model Class Initialized
INFO - 2018-03-24 17:04:58 --> Model Class Initialized
INFO - 2018-03-24 17:04:58 --> Model Class Initialized
INFO - 2018-03-24 17:04:58 --> Helper loaded: date_helper
INFO - 2018-03-24 17:04:58 --> Helper loaded: tanggal_helper
ERROR - 2018-03-24 23:04:58 --> Query error: Table 'klinik.pegawai' doesn't exist - Invalid query: SELECT *
FROM `retur`
INNER JOIN `product` ON `product`.`id_product` = `retur`.`id_product`
INNER JOIN `pegawai` ON `pegawai`.`id_mst_pegawai` = `retur`.`id_mst_pegawai`
WHERE `id_detail` = '15'
ERROR - 2018-03-24 23:04:58 --> Severity: error --> Exception: Call to a member function result() on boolean E:\xampp\htdocs\skin_care\application\models\Retur_model.php 30
INFO - 2018-03-24 17:05:38 --> Config Class Initialized
INFO - 2018-03-24 17:05:38 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:05:38 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:05:38 --> Utf8 Class Initialized
INFO - 2018-03-24 17:05:38 --> URI Class Initialized
INFO - 2018-03-24 17:05:38 --> Router Class Initialized
INFO - 2018-03-24 17:05:38 --> Output Class Initialized
INFO - 2018-03-24 17:05:38 --> Security Class Initialized
DEBUG - 2018-03-24 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:05:38 --> Input Class Initialized
INFO - 2018-03-24 17:05:38 --> Language Class Initialized
INFO - 2018-03-24 17:05:38 --> Loader Class Initialized
INFO - 2018-03-24 17:05:38 --> Helper loaded: url_helper
INFO - 2018-03-24 17:05:38 --> Helper loaded: form_helper
INFO - 2018-03-24 17:05:38 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:05:38 --> Controller Class Initialized
INFO - 2018-03-24 17:05:38 --> Model Class Initialized
INFO - 2018-03-24 17:05:38 --> Model Class Initialized
INFO - 2018-03-24 17:05:38 --> Model Class Initialized
INFO - 2018-03-24 17:05:38 --> Model Class Initialized
INFO - 2018-03-24 17:05:38 --> Model Class Initialized
INFO - 2018-03-24 17:05:38 --> Model Class Initialized
INFO - 2018-03-24 17:05:38 --> Helper loaded: date_helper
INFO - 2018-03-24 17:05:38 --> Helper loaded: tanggal_helper
ERROR - 2018-03-24 23:05:38 --> Query error: Table 'klinik.pegawai' doesn't exist - Invalid query: SELECT *
FROM `retur`
INNER JOIN `product` ON `product`.`id_product` = `retur`.`id_product`
INNER JOIN `pegawai` ON `pegawai`.`id_mst_pegawai` = `retur`.`id_mst_pegawai`
WHERE `id_detail` = '15'
ERROR - 2018-03-24 23:05:38 --> Severity: error --> Exception: Call to a member function result() on boolean E:\xampp\htdocs\skin_care\application\models\Retur_model.php 30
INFO - 2018-03-24 17:06:14 --> Config Class Initialized
INFO - 2018-03-24 17:06:14 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:06:14 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:06:14 --> Utf8 Class Initialized
INFO - 2018-03-24 17:06:14 --> URI Class Initialized
INFO - 2018-03-24 17:06:14 --> Router Class Initialized
INFO - 2018-03-24 17:06:14 --> Output Class Initialized
INFO - 2018-03-24 17:06:14 --> Security Class Initialized
DEBUG - 2018-03-24 17:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:06:14 --> Input Class Initialized
INFO - 2018-03-24 17:06:14 --> Language Class Initialized
INFO - 2018-03-24 17:06:14 --> Loader Class Initialized
INFO - 2018-03-24 17:06:14 --> Helper loaded: url_helper
INFO - 2018-03-24 17:06:14 --> Helper loaded: form_helper
INFO - 2018-03-24 17:06:14 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:06:14 --> Controller Class Initialized
INFO - 2018-03-24 17:06:14 --> Model Class Initialized
INFO - 2018-03-24 17:06:14 --> Model Class Initialized
INFO - 2018-03-24 17:06:14 --> Model Class Initialized
INFO - 2018-03-24 17:06:14 --> Model Class Initialized
INFO - 2018-03-24 17:06:14 --> Model Class Initialized
INFO - 2018-03-24 17:06:14 --> Model Class Initialized
INFO - 2018-03-24 17:06:14 --> Helper loaded: date_helper
INFO - 2018-03-24 17:06:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:06:14 --> Model Class Initialized
INFO - 2018-03-24 23:06:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:06:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:06:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:06:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:06:14 --> Final output sent to browser
DEBUG - 2018-03-24 23:06:15 --> Total execution time: 0.0939
INFO - 2018-03-24 17:06:44 --> Config Class Initialized
INFO - 2018-03-24 17:06:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:06:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:06:44 --> Utf8 Class Initialized
INFO - 2018-03-24 17:06:44 --> URI Class Initialized
INFO - 2018-03-24 17:06:44 --> Router Class Initialized
INFO - 2018-03-24 17:06:44 --> Output Class Initialized
INFO - 2018-03-24 17:06:44 --> Security Class Initialized
DEBUG - 2018-03-24 17:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:06:44 --> Input Class Initialized
INFO - 2018-03-24 17:06:44 --> Language Class Initialized
INFO - 2018-03-24 17:06:44 --> Loader Class Initialized
INFO - 2018-03-24 17:06:44 --> Helper loaded: url_helper
INFO - 2018-03-24 17:06:44 --> Helper loaded: form_helper
INFO - 2018-03-24 17:06:44 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:06:44 --> Controller Class Initialized
INFO - 2018-03-24 17:06:44 --> Model Class Initialized
INFO - 2018-03-24 17:06:44 --> Model Class Initialized
INFO - 2018-03-24 17:06:44 --> Model Class Initialized
INFO - 2018-03-24 17:06:44 --> Model Class Initialized
INFO - 2018-03-24 17:06:44 --> Model Class Initialized
INFO - 2018-03-24 17:06:44 --> Model Class Initialized
INFO - 2018-03-24 17:06:44 --> Helper loaded: date_helper
INFO - 2018-03-24 17:06:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:06:44 --> Model Class Initialized
INFO - 2018-03-24 23:06:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:06:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:06:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:06:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:06:44 --> Final output sent to browser
DEBUG - 2018-03-24 23:06:44 --> Total execution time: 0.1337
INFO - 2018-03-24 17:07:51 --> Config Class Initialized
INFO - 2018-03-24 17:07:51 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:07:51 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:07:51 --> Utf8 Class Initialized
INFO - 2018-03-24 17:07:51 --> URI Class Initialized
INFO - 2018-03-24 17:07:51 --> Router Class Initialized
INFO - 2018-03-24 17:07:51 --> Output Class Initialized
INFO - 2018-03-24 17:07:51 --> Security Class Initialized
DEBUG - 2018-03-24 17:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:07:51 --> Input Class Initialized
INFO - 2018-03-24 17:07:51 --> Language Class Initialized
INFO - 2018-03-24 17:07:51 --> Loader Class Initialized
INFO - 2018-03-24 17:07:51 --> Helper loaded: url_helper
INFO - 2018-03-24 17:07:51 --> Helper loaded: form_helper
INFO - 2018-03-24 17:07:51 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:07:51 --> Controller Class Initialized
INFO - 2018-03-24 17:07:51 --> Model Class Initialized
INFO - 2018-03-24 17:07:51 --> Model Class Initialized
INFO - 2018-03-24 17:07:51 --> Model Class Initialized
INFO - 2018-03-24 17:07:51 --> Model Class Initialized
INFO - 2018-03-24 17:07:51 --> Model Class Initialized
INFO - 2018-03-24 17:07:51 --> Model Class Initialized
INFO - 2018-03-24 17:07:51 --> Helper loaded: date_helper
INFO - 2018-03-24 17:07:51 --> Helper loaded: tanggal_helper
ERROR - 2018-03-24 23:07:51 --> Severity: error --> Exception: Cannot use object of type stdClass as array E:\xampp\htdocs\skin_care\application\controllers\gudang\Penjualan.php 118
INFO - 2018-03-24 17:08:07 --> Config Class Initialized
INFO - 2018-03-24 17:08:07 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:08:07 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:08:07 --> Utf8 Class Initialized
INFO - 2018-03-24 17:08:07 --> URI Class Initialized
INFO - 2018-03-24 17:08:07 --> Router Class Initialized
INFO - 2018-03-24 17:08:07 --> Output Class Initialized
INFO - 2018-03-24 17:08:07 --> Security Class Initialized
DEBUG - 2018-03-24 17:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:08:07 --> Input Class Initialized
INFO - 2018-03-24 17:08:07 --> Language Class Initialized
INFO - 2018-03-24 17:08:07 --> Loader Class Initialized
INFO - 2018-03-24 17:08:07 --> Helper loaded: url_helper
INFO - 2018-03-24 17:08:07 --> Helper loaded: form_helper
INFO - 2018-03-24 17:08:07 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:08:07 --> Controller Class Initialized
INFO - 2018-03-24 17:08:07 --> Model Class Initialized
INFO - 2018-03-24 17:08:07 --> Model Class Initialized
INFO - 2018-03-24 17:08:07 --> Model Class Initialized
INFO - 2018-03-24 17:08:07 --> Model Class Initialized
INFO - 2018-03-24 17:08:07 --> Model Class Initialized
INFO - 2018-03-24 17:08:07 --> Model Class Initialized
INFO - 2018-03-24 17:08:07 --> Helper loaded: date_helper
INFO - 2018-03-24 17:08:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:08:07 --> Model Class Initialized
INFO - 2018-03-24 23:08:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:08:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:08:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:08:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:08:07 --> Final output sent to browser
DEBUG - 2018-03-24 23:08:07 --> Total execution time: 0.1079
INFO - 2018-03-24 17:08:36 --> Config Class Initialized
INFO - 2018-03-24 17:08:36 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:08:36 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:08:36 --> Utf8 Class Initialized
INFO - 2018-03-24 17:08:36 --> URI Class Initialized
INFO - 2018-03-24 17:08:36 --> Router Class Initialized
INFO - 2018-03-24 17:08:36 --> Output Class Initialized
INFO - 2018-03-24 17:08:36 --> Security Class Initialized
DEBUG - 2018-03-24 17:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:08:36 --> Input Class Initialized
INFO - 2018-03-24 17:08:36 --> Language Class Initialized
INFO - 2018-03-24 17:08:36 --> Loader Class Initialized
INFO - 2018-03-24 17:08:36 --> Helper loaded: url_helper
INFO - 2018-03-24 17:08:36 --> Helper loaded: form_helper
INFO - 2018-03-24 17:08:36 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:08:36 --> Controller Class Initialized
INFO - 2018-03-24 17:08:36 --> Model Class Initialized
INFO - 2018-03-24 17:08:36 --> Model Class Initialized
INFO - 2018-03-24 17:08:36 --> Model Class Initialized
INFO - 2018-03-24 17:08:36 --> Model Class Initialized
INFO - 2018-03-24 17:08:36 --> Model Class Initialized
INFO - 2018-03-24 17:08:36 --> Model Class Initialized
INFO - 2018-03-24 17:08:36 --> Helper loaded: date_helper
INFO - 2018-03-24 17:08:36 --> Helper loaded: tanggal_helper
ERROR - 2018-03-24 23:08:36 --> Query error: Table 'klinik.pegawai' doesn't exist - Invalid query: SELECT *
FROM `retur`
INNER JOIN `product` ON `product`.`id_product` = `retur`.`id_product`
INNER JOIN `pegawai` ON `pegawai`.`id_mst_pegawai` = `retur`.`id_mst_pegawai`
WHERE `id_detail` = '15'
ERROR - 2018-03-24 23:08:36 --> Severity: error --> Exception: Call to a member function result() on boolean E:\xampp\htdocs\skin_care\application\models\Retur_model.php 30
INFO - 2018-03-24 17:09:05 --> Config Class Initialized
INFO - 2018-03-24 17:09:05 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:09:05 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:09:05 --> Utf8 Class Initialized
INFO - 2018-03-24 17:09:05 --> URI Class Initialized
INFO - 2018-03-24 17:09:05 --> Router Class Initialized
INFO - 2018-03-24 17:09:05 --> Output Class Initialized
INFO - 2018-03-24 17:09:05 --> Security Class Initialized
DEBUG - 2018-03-24 17:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:09:05 --> Input Class Initialized
INFO - 2018-03-24 17:09:05 --> Language Class Initialized
INFO - 2018-03-24 17:09:05 --> Loader Class Initialized
INFO - 2018-03-24 17:09:05 --> Helper loaded: url_helper
INFO - 2018-03-24 17:09:05 --> Helper loaded: form_helper
INFO - 2018-03-24 17:09:05 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:09:05 --> Controller Class Initialized
INFO - 2018-03-24 17:09:05 --> Model Class Initialized
INFO - 2018-03-24 17:09:05 --> Model Class Initialized
INFO - 2018-03-24 17:09:05 --> Model Class Initialized
INFO - 2018-03-24 17:09:05 --> Model Class Initialized
INFO - 2018-03-24 17:09:05 --> Model Class Initialized
INFO - 2018-03-24 17:09:05 --> Model Class Initialized
INFO - 2018-03-24 17:09:05 --> Helper loaded: date_helper
INFO - 2018-03-24 17:09:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:09:05 --> Model Class Initialized
INFO - 2018-03-24 23:09:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:09:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:09:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:09:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:09:05 --> Final output sent to browser
DEBUG - 2018-03-24 23:09:05 --> Total execution time: 0.1182
INFO - 2018-03-24 17:09:37 --> Config Class Initialized
INFO - 2018-03-24 17:09:37 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:09:37 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:09:37 --> Utf8 Class Initialized
INFO - 2018-03-24 17:09:37 --> URI Class Initialized
INFO - 2018-03-24 17:09:37 --> Router Class Initialized
INFO - 2018-03-24 17:09:37 --> Output Class Initialized
INFO - 2018-03-24 17:09:37 --> Security Class Initialized
DEBUG - 2018-03-24 17:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:09:37 --> Input Class Initialized
INFO - 2018-03-24 17:09:37 --> Language Class Initialized
INFO - 2018-03-24 17:09:37 --> Loader Class Initialized
INFO - 2018-03-24 17:09:37 --> Helper loaded: url_helper
INFO - 2018-03-24 17:09:37 --> Helper loaded: form_helper
INFO - 2018-03-24 17:09:37 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:09:37 --> Controller Class Initialized
INFO - 2018-03-24 17:09:37 --> Model Class Initialized
INFO - 2018-03-24 17:09:37 --> Model Class Initialized
INFO - 2018-03-24 17:09:37 --> Model Class Initialized
INFO - 2018-03-24 17:09:37 --> Model Class Initialized
INFO - 2018-03-24 17:09:37 --> Model Class Initialized
INFO - 2018-03-24 17:09:37 --> Model Class Initialized
INFO - 2018-03-24 17:09:37 --> Helper loaded: date_helper
INFO - 2018-03-24 17:09:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:09:37 --> Model Class Initialized
INFO - 2018-03-24 23:09:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:09:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:09:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:09:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:09:37 --> Final output sent to browser
DEBUG - 2018-03-24 23:09:37 --> Total execution time: 0.1103
INFO - 2018-03-24 17:10:03 --> Config Class Initialized
INFO - 2018-03-24 17:10:03 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:10:03 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:10:03 --> Utf8 Class Initialized
INFO - 2018-03-24 17:10:03 --> URI Class Initialized
INFO - 2018-03-24 17:10:03 --> Router Class Initialized
INFO - 2018-03-24 17:10:03 --> Output Class Initialized
INFO - 2018-03-24 17:10:03 --> Security Class Initialized
DEBUG - 2018-03-24 17:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:10:03 --> Input Class Initialized
INFO - 2018-03-24 17:10:03 --> Language Class Initialized
INFO - 2018-03-24 17:10:03 --> Loader Class Initialized
INFO - 2018-03-24 17:10:03 --> Helper loaded: url_helper
INFO - 2018-03-24 17:10:03 --> Helper loaded: form_helper
INFO - 2018-03-24 17:10:03 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:10:03 --> Controller Class Initialized
INFO - 2018-03-24 17:10:03 --> Model Class Initialized
INFO - 2018-03-24 17:10:03 --> Model Class Initialized
INFO - 2018-03-24 17:10:03 --> Model Class Initialized
INFO - 2018-03-24 17:10:03 --> Model Class Initialized
INFO - 2018-03-24 17:10:03 --> Model Class Initialized
INFO - 2018-03-24 17:10:03 --> Model Class Initialized
INFO - 2018-03-24 17:10:03 --> Helper loaded: date_helper
INFO - 2018-03-24 17:10:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:10:03 --> Model Class Initialized
INFO - 2018-03-24 23:10:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:10:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:10:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:10:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:10:03 --> Final output sent to browser
DEBUG - 2018-03-24 23:10:03 --> Total execution time: 0.1083
INFO - 2018-03-24 17:10:24 --> Config Class Initialized
INFO - 2018-03-24 17:10:24 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:10:24 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:10:24 --> Utf8 Class Initialized
INFO - 2018-03-24 17:10:24 --> URI Class Initialized
INFO - 2018-03-24 17:10:24 --> Router Class Initialized
INFO - 2018-03-24 17:10:24 --> Output Class Initialized
INFO - 2018-03-24 17:10:24 --> Security Class Initialized
DEBUG - 2018-03-24 17:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:10:24 --> Input Class Initialized
INFO - 2018-03-24 17:10:24 --> Language Class Initialized
INFO - 2018-03-24 17:10:24 --> Loader Class Initialized
INFO - 2018-03-24 17:10:24 --> Helper loaded: url_helper
INFO - 2018-03-24 17:10:24 --> Helper loaded: form_helper
INFO - 2018-03-24 17:10:24 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:10:24 --> Controller Class Initialized
INFO - 2018-03-24 17:10:24 --> Model Class Initialized
INFO - 2018-03-24 17:10:24 --> Model Class Initialized
INFO - 2018-03-24 17:10:24 --> Model Class Initialized
INFO - 2018-03-24 17:10:24 --> Model Class Initialized
INFO - 2018-03-24 17:10:24 --> Model Class Initialized
INFO - 2018-03-24 17:10:24 --> Model Class Initialized
INFO - 2018-03-24 17:10:24 --> Helper loaded: date_helper
INFO - 2018-03-24 17:10:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:10:24 --> Model Class Initialized
INFO - 2018-03-24 23:10:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:10:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:10:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:10:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:10:24 --> Final output sent to browser
DEBUG - 2018-03-24 23:10:24 --> Total execution time: 0.1024
INFO - 2018-03-24 17:10:35 --> Config Class Initialized
INFO - 2018-03-24 17:10:35 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:10:35 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:10:35 --> Utf8 Class Initialized
INFO - 2018-03-24 17:10:35 --> URI Class Initialized
INFO - 2018-03-24 17:10:35 --> Router Class Initialized
INFO - 2018-03-24 17:10:35 --> Output Class Initialized
INFO - 2018-03-24 17:10:35 --> Security Class Initialized
DEBUG - 2018-03-24 17:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:10:35 --> Input Class Initialized
INFO - 2018-03-24 17:10:35 --> Language Class Initialized
INFO - 2018-03-24 17:10:35 --> Loader Class Initialized
INFO - 2018-03-24 17:10:35 --> Helper loaded: url_helper
INFO - 2018-03-24 17:10:35 --> Helper loaded: form_helper
INFO - 2018-03-24 17:10:35 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:10:35 --> Controller Class Initialized
INFO - 2018-03-24 17:10:35 --> Model Class Initialized
INFO - 2018-03-24 17:10:35 --> Model Class Initialized
INFO - 2018-03-24 17:10:35 --> Model Class Initialized
INFO - 2018-03-24 17:10:35 --> Model Class Initialized
INFO - 2018-03-24 17:10:35 --> Model Class Initialized
INFO - 2018-03-24 17:10:35 --> Model Class Initialized
INFO - 2018-03-24 17:10:35 --> Helper loaded: date_helper
INFO - 2018-03-24 17:10:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:10:35 --> Model Class Initialized
INFO - 2018-03-24 23:10:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:10:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:10:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:10:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:10:35 --> Final output sent to browser
DEBUG - 2018-03-24 23:10:35 --> Total execution time: 0.0989
INFO - 2018-03-24 17:11:45 --> Config Class Initialized
INFO - 2018-03-24 17:11:45 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:11:45 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:11:45 --> Utf8 Class Initialized
INFO - 2018-03-24 17:11:45 --> URI Class Initialized
INFO - 2018-03-24 17:11:45 --> Router Class Initialized
INFO - 2018-03-24 17:11:45 --> Output Class Initialized
INFO - 2018-03-24 17:11:45 --> Security Class Initialized
DEBUG - 2018-03-24 17:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:11:45 --> Input Class Initialized
INFO - 2018-03-24 17:11:45 --> Language Class Initialized
INFO - 2018-03-24 17:11:45 --> Loader Class Initialized
INFO - 2018-03-24 17:11:45 --> Helper loaded: url_helper
INFO - 2018-03-24 17:11:45 --> Helper loaded: form_helper
INFO - 2018-03-24 17:11:45 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:11:45 --> Controller Class Initialized
INFO - 2018-03-24 17:11:45 --> Model Class Initialized
INFO - 2018-03-24 17:11:45 --> Model Class Initialized
INFO - 2018-03-24 17:11:45 --> Model Class Initialized
INFO - 2018-03-24 17:11:45 --> Model Class Initialized
INFO - 2018-03-24 17:11:45 --> Model Class Initialized
INFO - 2018-03-24 17:11:45 --> Model Class Initialized
INFO - 2018-03-24 17:11:45 --> Helper loaded: date_helper
INFO - 2018-03-24 17:11:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:11:45 --> Model Class Initialized
INFO - 2018-03-24 23:11:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:11:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:11:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:11:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:11:45 --> Final output sent to browser
DEBUG - 2018-03-24 23:11:45 --> Total execution time: 0.1002
INFO - 2018-03-24 17:13:11 --> Config Class Initialized
INFO - 2018-03-24 17:13:11 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:13:11 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:13:11 --> Utf8 Class Initialized
INFO - 2018-03-24 17:13:11 --> URI Class Initialized
INFO - 2018-03-24 17:13:11 --> Router Class Initialized
INFO - 2018-03-24 17:13:11 --> Output Class Initialized
INFO - 2018-03-24 17:13:11 --> Security Class Initialized
DEBUG - 2018-03-24 17:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:13:11 --> Input Class Initialized
INFO - 2018-03-24 17:13:11 --> Language Class Initialized
INFO - 2018-03-24 17:13:11 --> Loader Class Initialized
INFO - 2018-03-24 17:13:11 --> Helper loaded: url_helper
INFO - 2018-03-24 17:13:11 --> Helper loaded: form_helper
INFO - 2018-03-24 17:13:11 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:13:11 --> Controller Class Initialized
INFO - 2018-03-24 17:13:11 --> Model Class Initialized
INFO - 2018-03-24 17:13:11 --> Model Class Initialized
INFO - 2018-03-24 17:13:11 --> Model Class Initialized
INFO - 2018-03-24 17:13:11 --> Model Class Initialized
INFO - 2018-03-24 17:13:11 --> Model Class Initialized
INFO - 2018-03-24 17:13:11 --> Model Class Initialized
INFO - 2018-03-24 17:13:11 --> Helper loaded: date_helper
INFO - 2018-03-24 17:13:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:13:11 --> Model Class Initialized
INFO - 2018-03-24 23:13:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:13:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:13:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:13:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:13:11 --> Final output sent to browser
DEBUG - 2018-03-24 23:13:11 --> Total execution time: 0.0871
INFO - 2018-03-24 17:13:28 --> Config Class Initialized
INFO - 2018-03-24 17:13:28 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:13:28 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:13:28 --> Utf8 Class Initialized
INFO - 2018-03-24 17:13:28 --> URI Class Initialized
INFO - 2018-03-24 17:13:28 --> Router Class Initialized
INFO - 2018-03-24 17:13:28 --> Output Class Initialized
INFO - 2018-03-24 17:13:28 --> Security Class Initialized
DEBUG - 2018-03-24 17:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:13:28 --> Input Class Initialized
INFO - 2018-03-24 17:13:28 --> Language Class Initialized
INFO - 2018-03-24 17:13:28 --> Loader Class Initialized
INFO - 2018-03-24 17:13:28 --> Helper loaded: url_helper
INFO - 2018-03-24 17:13:28 --> Helper loaded: form_helper
INFO - 2018-03-24 17:13:28 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:13:28 --> Controller Class Initialized
INFO - 2018-03-24 17:13:28 --> Model Class Initialized
INFO - 2018-03-24 17:13:28 --> Model Class Initialized
INFO - 2018-03-24 17:13:28 --> Model Class Initialized
INFO - 2018-03-24 17:13:28 --> Model Class Initialized
INFO - 2018-03-24 17:13:28 --> Model Class Initialized
INFO - 2018-03-24 17:13:28 --> Model Class Initialized
INFO - 2018-03-24 17:13:28 --> Helper loaded: date_helper
INFO - 2018-03-24 17:13:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:13:28 --> Model Class Initialized
INFO - 2018-03-24 23:13:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:13:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:13:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:13:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:13:28 --> Final output sent to browser
DEBUG - 2018-03-24 23:13:28 --> Total execution time: 0.1125
INFO - 2018-03-24 17:13:40 --> Config Class Initialized
INFO - 2018-03-24 17:13:40 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:13:40 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:13:40 --> Utf8 Class Initialized
INFO - 2018-03-24 17:13:40 --> URI Class Initialized
INFO - 2018-03-24 17:13:40 --> Router Class Initialized
INFO - 2018-03-24 17:13:40 --> Output Class Initialized
INFO - 2018-03-24 17:13:40 --> Security Class Initialized
DEBUG - 2018-03-24 17:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:13:40 --> Input Class Initialized
INFO - 2018-03-24 17:13:40 --> Language Class Initialized
INFO - 2018-03-24 17:13:40 --> Loader Class Initialized
INFO - 2018-03-24 17:13:40 --> Helper loaded: url_helper
INFO - 2018-03-24 17:13:40 --> Helper loaded: form_helper
INFO - 2018-03-24 17:13:40 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:13:40 --> Controller Class Initialized
INFO - 2018-03-24 17:13:40 --> Model Class Initialized
INFO - 2018-03-24 17:13:40 --> Model Class Initialized
INFO - 2018-03-24 17:13:40 --> Model Class Initialized
INFO - 2018-03-24 17:13:40 --> Model Class Initialized
INFO - 2018-03-24 17:13:40 --> Model Class Initialized
INFO - 2018-03-24 17:13:40 --> Model Class Initialized
INFO - 2018-03-24 17:13:40 --> Helper loaded: date_helper
INFO - 2018-03-24 17:13:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:13:40 --> Model Class Initialized
INFO - 2018-03-24 23:13:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:13:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:13:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:13:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:13:40 --> Final output sent to browser
DEBUG - 2018-03-24 23:13:40 --> Total execution time: 0.1143
INFO - 2018-03-24 17:14:27 --> Config Class Initialized
INFO - 2018-03-24 17:14:27 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:14:27 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:14:27 --> Utf8 Class Initialized
INFO - 2018-03-24 17:14:27 --> URI Class Initialized
INFO - 2018-03-24 17:14:27 --> Router Class Initialized
INFO - 2018-03-24 17:14:27 --> Output Class Initialized
INFO - 2018-03-24 17:14:27 --> Security Class Initialized
DEBUG - 2018-03-24 17:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:14:27 --> Input Class Initialized
INFO - 2018-03-24 17:14:27 --> Language Class Initialized
INFO - 2018-03-24 17:14:27 --> Loader Class Initialized
INFO - 2018-03-24 17:14:27 --> Helper loaded: url_helper
INFO - 2018-03-24 17:14:27 --> Helper loaded: form_helper
INFO - 2018-03-24 17:14:27 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:14:27 --> Controller Class Initialized
INFO - 2018-03-24 17:14:27 --> Model Class Initialized
INFO - 2018-03-24 17:14:27 --> Model Class Initialized
INFO - 2018-03-24 17:14:27 --> Model Class Initialized
INFO - 2018-03-24 17:14:27 --> Model Class Initialized
INFO - 2018-03-24 17:14:27 --> Model Class Initialized
INFO - 2018-03-24 17:14:27 --> Model Class Initialized
INFO - 2018-03-24 17:14:27 --> Helper loaded: date_helper
INFO - 2018-03-24 17:14:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:14:27 --> Model Class Initialized
INFO - 2018-03-24 23:14:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:14:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:14:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:14:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:14:27 --> Final output sent to browser
DEBUG - 2018-03-24 23:14:27 --> Total execution time: 0.1011
INFO - 2018-03-24 17:15:10 --> Config Class Initialized
INFO - 2018-03-24 17:15:10 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:15:10 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:15:10 --> Utf8 Class Initialized
INFO - 2018-03-24 17:15:10 --> URI Class Initialized
INFO - 2018-03-24 17:15:10 --> Router Class Initialized
INFO - 2018-03-24 17:15:10 --> Output Class Initialized
INFO - 2018-03-24 17:15:10 --> Security Class Initialized
DEBUG - 2018-03-24 17:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:15:10 --> Input Class Initialized
INFO - 2018-03-24 17:15:10 --> Language Class Initialized
INFO - 2018-03-24 17:15:10 --> Loader Class Initialized
INFO - 2018-03-24 17:15:10 --> Helper loaded: url_helper
INFO - 2018-03-24 17:15:10 --> Helper loaded: form_helper
INFO - 2018-03-24 17:15:10 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:15:10 --> Controller Class Initialized
INFO - 2018-03-24 17:15:10 --> Model Class Initialized
INFO - 2018-03-24 17:15:10 --> Model Class Initialized
INFO - 2018-03-24 17:15:10 --> Model Class Initialized
INFO - 2018-03-24 17:15:10 --> Model Class Initialized
INFO - 2018-03-24 17:15:10 --> Model Class Initialized
INFO - 2018-03-24 17:15:10 --> Model Class Initialized
INFO - 2018-03-24 17:15:10 --> Helper loaded: date_helper
INFO - 2018-03-24 17:15:10 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:15:10 --> Model Class Initialized
INFO - 2018-03-24 23:15:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:15:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:15:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:15:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:15:10 --> Final output sent to browser
DEBUG - 2018-03-24 23:15:10 --> Total execution time: 0.0990
INFO - 2018-03-24 17:15:38 --> Config Class Initialized
INFO - 2018-03-24 17:15:38 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:15:38 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:15:38 --> Utf8 Class Initialized
INFO - 2018-03-24 17:15:38 --> URI Class Initialized
INFO - 2018-03-24 17:15:38 --> Router Class Initialized
INFO - 2018-03-24 17:15:38 --> Output Class Initialized
INFO - 2018-03-24 17:15:38 --> Security Class Initialized
DEBUG - 2018-03-24 17:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:15:38 --> Input Class Initialized
INFO - 2018-03-24 17:15:38 --> Language Class Initialized
INFO - 2018-03-24 17:15:38 --> Loader Class Initialized
INFO - 2018-03-24 17:15:38 --> Helper loaded: url_helper
INFO - 2018-03-24 17:15:38 --> Helper loaded: form_helper
INFO - 2018-03-24 17:15:38 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:15:38 --> Controller Class Initialized
INFO - 2018-03-24 17:15:38 --> Model Class Initialized
INFO - 2018-03-24 17:15:38 --> Model Class Initialized
INFO - 2018-03-24 17:15:38 --> Model Class Initialized
INFO - 2018-03-24 17:15:38 --> Model Class Initialized
INFO - 2018-03-24 17:15:38 --> Model Class Initialized
INFO - 2018-03-24 17:15:38 --> Model Class Initialized
INFO - 2018-03-24 17:15:38 --> Helper loaded: date_helper
INFO - 2018-03-24 17:15:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:15:38 --> Model Class Initialized
INFO - 2018-03-24 23:15:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:15:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:15:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:15:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:15:38 --> Final output sent to browser
DEBUG - 2018-03-24 23:15:38 --> Total execution time: 0.1003
INFO - 2018-03-24 17:16:18 --> Config Class Initialized
INFO - 2018-03-24 17:16:18 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:16:18 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:16:18 --> Utf8 Class Initialized
INFO - 2018-03-24 17:16:18 --> URI Class Initialized
INFO - 2018-03-24 17:16:18 --> Router Class Initialized
INFO - 2018-03-24 17:16:18 --> Output Class Initialized
INFO - 2018-03-24 17:16:18 --> Security Class Initialized
DEBUG - 2018-03-24 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:16:18 --> Input Class Initialized
INFO - 2018-03-24 17:16:18 --> Language Class Initialized
INFO - 2018-03-24 17:16:18 --> Loader Class Initialized
INFO - 2018-03-24 17:16:18 --> Helper loaded: url_helper
INFO - 2018-03-24 17:16:18 --> Helper loaded: form_helper
INFO - 2018-03-24 17:16:18 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:16:18 --> Controller Class Initialized
INFO - 2018-03-24 17:16:18 --> Model Class Initialized
INFO - 2018-03-24 17:16:18 --> Model Class Initialized
INFO - 2018-03-24 17:16:18 --> Model Class Initialized
INFO - 2018-03-24 17:16:18 --> Model Class Initialized
INFO - 2018-03-24 17:16:18 --> Model Class Initialized
INFO - 2018-03-24 17:16:18 --> Model Class Initialized
INFO - 2018-03-24 17:16:18 --> Helper loaded: date_helper
INFO - 2018-03-24 17:16:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:16:18 --> Model Class Initialized
INFO - 2018-03-24 23:16:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:16:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:16:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:16:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:16:18 --> Final output sent to browser
DEBUG - 2018-03-24 23:16:18 --> Total execution time: 0.0960
INFO - 2018-03-24 17:18:07 --> Config Class Initialized
INFO - 2018-03-24 17:18:07 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:18:07 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:18:07 --> Utf8 Class Initialized
INFO - 2018-03-24 17:18:07 --> URI Class Initialized
INFO - 2018-03-24 17:18:07 --> Router Class Initialized
INFO - 2018-03-24 17:18:07 --> Output Class Initialized
INFO - 2018-03-24 17:18:07 --> Security Class Initialized
DEBUG - 2018-03-24 17:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:18:07 --> Input Class Initialized
INFO - 2018-03-24 17:18:07 --> Language Class Initialized
INFO - 2018-03-24 17:18:07 --> Loader Class Initialized
INFO - 2018-03-24 17:18:07 --> Helper loaded: url_helper
INFO - 2018-03-24 17:18:07 --> Helper loaded: form_helper
INFO - 2018-03-24 17:18:07 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:18:07 --> Controller Class Initialized
INFO - 2018-03-24 17:18:07 --> Model Class Initialized
INFO - 2018-03-24 17:18:07 --> Model Class Initialized
INFO - 2018-03-24 17:18:07 --> Model Class Initialized
INFO - 2018-03-24 17:18:07 --> Model Class Initialized
INFO - 2018-03-24 17:18:07 --> Model Class Initialized
INFO - 2018-03-24 17:18:07 --> Model Class Initialized
INFO - 2018-03-24 17:18:07 --> Helper loaded: date_helper
INFO - 2018-03-24 17:18:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:18:07 --> Model Class Initialized
INFO - 2018-03-24 23:18:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:18:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:18:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:18:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:18:07 --> Final output sent to browser
DEBUG - 2018-03-24 23:18:07 --> Total execution time: 0.0905
INFO - 2018-03-24 17:19:09 --> Config Class Initialized
INFO - 2018-03-24 17:19:09 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:19:09 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:19:09 --> Utf8 Class Initialized
INFO - 2018-03-24 17:19:09 --> URI Class Initialized
INFO - 2018-03-24 17:19:09 --> Router Class Initialized
INFO - 2018-03-24 17:19:09 --> Output Class Initialized
INFO - 2018-03-24 17:19:09 --> Security Class Initialized
DEBUG - 2018-03-24 17:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:19:09 --> Input Class Initialized
INFO - 2018-03-24 17:19:09 --> Language Class Initialized
INFO - 2018-03-24 17:19:09 --> Loader Class Initialized
INFO - 2018-03-24 17:19:09 --> Helper loaded: url_helper
INFO - 2018-03-24 17:19:09 --> Helper loaded: form_helper
INFO - 2018-03-24 17:19:09 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:19:09 --> Controller Class Initialized
INFO - 2018-03-24 17:19:09 --> Model Class Initialized
INFO - 2018-03-24 17:19:09 --> Model Class Initialized
INFO - 2018-03-24 17:19:09 --> Model Class Initialized
INFO - 2018-03-24 17:19:09 --> Model Class Initialized
INFO - 2018-03-24 17:19:09 --> Model Class Initialized
INFO - 2018-03-24 17:19:09 --> Model Class Initialized
INFO - 2018-03-24 17:19:09 --> Helper loaded: date_helper
INFO - 2018-03-24 17:19:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:19:09 --> Model Class Initialized
INFO - 2018-03-24 23:19:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:19:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:19:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:19:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:19:09 --> Final output sent to browser
DEBUG - 2018-03-24 23:19:09 --> Total execution time: 0.0938
INFO - 2018-03-24 17:19:26 --> Config Class Initialized
INFO - 2018-03-24 17:19:26 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:19:26 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:19:26 --> Utf8 Class Initialized
INFO - 2018-03-24 17:19:26 --> URI Class Initialized
INFO - 2018-03-24 17:19:26 --> Router Class Initialized
INFO - 2018-03-24 17:19:26 --> Output Class Initialized
INFO - 2018-03-24 17:19:26 --> Security Class Initialized
DEBUG - 2018-03-24 17:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:19:26 --> Input Class Initialized
INFO - 2018-03-24 17:19:26 --> Language Class Initialized
INFO - 2018-03-24 17:19:26 --> Loader Class Initialized
INFO - 2018-03-24 17:19:26 --> Helper loaded: url_helper
INFO - 2018-03-24 17:19:26 --> Helper loaded: form_helper
INFO - 2018-03-24 17:19:26 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:19:26 --> Controller Class Initialized
INFO - 2018-03-24 17:19:26 --> Model Class Initialized
INFO - 2018-03-24 17:19:26 --> Model Class Initialized
INFO - 2018-03-24 17:19:26 --> Model Class Initialized
INFO - 2018-03-24 17:19:26 --> Model Class Initialized
INFO - 2018-03-24 17:19:26 --> Model Class Initialized
INFO - 2018-03-24 17:19:26 --> Model Class Initialized
INFO - 2018-03-24 17:19:26 --> Helper loaded: date_helper
INFO - 2018-03-24 17:19:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:19:26 --> Model Class Initialized
INFO - 2018-03-24 23:19:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:19:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:19:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:19:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:19:26 --> Final output sent to browser
DEBUG - 2018-03-24 23:19:26 --> Total execution time: 0.0933
INFO - 2018-03-24 17:19:39 --> Config Class Initialized
INFO - 2018-03-24 17:19:39 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:19:39 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:19:39 --> Utf8 Class Initialized
INFO - 2018-03-24 17:19:39 --> URI Class Initialized
INFO - 2018-03-24 17:19:39 --> Router Class Initialized
INFO - 2018-03-24 17:19:39 --> Output Class Initialized
INFO - 2018-03-24 17:19:39 --> Security Class Initialized
DEBUG - 2018-03-24 17:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:19:39 --> Input Class Initialized
INFO - 2018-03-24 17:19:39 --> Language Class Initialized
INFO - 2018-03-24 17:19:39 --> Loader Class Initialized
INFO - 2018-03-24 17:19:39 --> Helper loaded: url_helper
INFO - 2018-03-24 17:19:39 --> Helper loaded: form_helper
INFO - 2018-03-24 17:19:39 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:19:39 --> Controller Class Initialized
INFO - 2018-03-24 17:19:39 --> Model Class Initialized
INFO - 2018-03-24 17:19:39 --> Model Class Initialized
INFO - 2018-03-24 17:19:39 --> Model Class Initialized
INFO - 2018-03-24 17:19:39 --> Model Class Initialized
INFO - 2018-03-24 17:19:39 --> Model Class Initialized
INFO - 2018-03-24 17:19:39 --> Model Class Initialized
INFO - 2018-03-24 17:19:39 --> Helper loaded: date_helper
INFO - 2018-03-24 17:19:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:19:39 --> Model Class Initialized
INFO - 2018-03-24 23:19:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:19:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:19:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:19:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:19:39 --> Final output sent to browser
DEBUG - 2018-03-24 23:19:39 --> Total execution time: 0.1030
INFO - 2018-03-24 17:21:01 --> Config Class Initialized
INFO - 2018-03-24 17:21:01 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:21:01 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:21:01 --> Utf8 Class Initialized
INFO - 2018-03-24 17:21:01 --> URI Class Initialized
INFO - 2018-03-24 17:21:01 --> Router Class Initialized
INFO - 2018-03-24 17:21:01 --> Output Class Initialized
INFO - 2018-03-24 17:21:01 --> Security Class Initialized
DEBUG - 2018-03-24 17:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:21:01 --> Input Class Initialized
INFO - 2018-03-24 17:21:01 --> Language Class Initialized
INFO - 2018-03-24 17:21:01 --> Loader Class Initialized
INFO - 2018-03-24 17:21:01 --> Helper loaded: url_helper
INFO - 2018-03-24 17:21:01 --> Helper loaded: form_helper
INFO - 2018-03-24 17:21:01 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:21:01 --> Controller Class Initialized
INFO - 2018-03-24 17:21:01 --> Model Class Initialized
INFO - 2018-03-24 17:21:01 --> Model Class Initialized
INFO - 2018-03-24 17:21:01 --> Model Class Initialized
INFO - 2018-03-24 17:21:01 --> Model Class Initialized
INFO - 2018-03-24 17:21:01 --> Model Class Initialized
INFO - 2018-03-24 17:21:01 --> Model Class Initialized
INFO - 2018-03-24 17:21:01 --> Helper loaded: date_helper
INFO - 2018-03-24 17:21:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:21:01 --> Model Class Initialized
INFO - 2018-03-24 23:21:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:21:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:21:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:21:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:21:01 --> Final output sent to browser
DEBUG - 2018-03-24 23:21:01 --> Total execution time: 0.0957
INFO - 2018-03-24 17:21:03 --> Config Class Initialized
INFO - 2018-03-24 17:21:03 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:21:03 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:21:03 --> Utf8 Class Initialized
INFO - 2018-03-24 17:21:03 --> URI Class Initialized
INFO - 2018-03-24 17:21:03 --> Router Class Initialized
INFO - 2018-03-24 17:21:03 --> Output Class Initialized
INFO - 2018-03-24 17:21:03 --> Security Class Initialized
DEBUG - 2018-03-24 17:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:21:03 --> Input Class Initialized
INFO - 2018-03-24 17:21:03 --> Language Class Initialized
INFO - 2018-03-24 17:21:03 --> Loader Class Initialized
INFO - 2018-03-24 17:21:03 --> Helper loaded: url_helper
INFO - 2018-03-24 17:21:03 --> Helper loaded: form_helper
INFO - 2018-03-24 17:21:03 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:21:03 --> Controller Class Initialized
INFO - 2018-03-24 17:21:03 --> Model Class Initialized
INFO - 2018-03-24 17:21:03 --> Model Class Initialized
INFO - 2018-03-24 17:21:03 --> Model Class Initialized
INFO - 2018-03-24 17:21:03 --> Model Class Initialized
INFO - 2018-03-24 17:21:03 --> Model Class Initialized
INFO - 2018-03-24 17:21:03 --> Model Class Initialized
INFO - 2018-03-24 17:21:03 --> Helper loaded: date_helper
INFO - 2018-03-24 17:21:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:21:03 --> Model Class Initialized
INFO - 2018-03-24 23:21:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:21:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:21:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:21:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:21:03 --> Final output sent to browser
DEBUG - 2018-03-24 23:21:03 --> Total execution time: 0.1137
INFO - 2018-03-24 17:21:29 --> Config Class Initialized
INFO - 2018-03-24 17:21:29 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:21:29 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:21:29 --> Utf8 Class Initialized
INFO - 2018-03-24 17:21:29 --> URI Class Initialized
INFO - 2018-03-24 17:21:29 --> Router Class Initialized
INFO - 2018-03-24 17:21:29 --> Output Class Initialized
INFO - 2018-03-24 17:21:29 --> Security Class Initialized
DEBUG - 2018-03-24 17:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:21:29 --> Input Class Initialized
INFO - 2018-03-24 17:21:29 --> Language Class Initialized
INFO - 2018-03-24 17:21:29 --> Loader Class Initialized
INFO - 2018-03-24 17:21:29 --> Helper loaded: url_helper
INFO - 2018-03-24 17:21:29 --> Helper loaded: form_helper
INFO - 2018-03-24 17:21:29 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:21:29 --> Controller Class Initialized
INFO - 2018-03-24 17:21:29 --> Model Class Initialized
INFO - 2018-03-24 17:21:29 --> Model Class Initialized
INFO - 2018-03-24 17:21:29 --> Model Class Initialized
INFO - 2018-03-24 17:21:29 --> Model Class Initialized
INFO - 2018-03-24 17:21:29 --> Model Class Initialized
INFO - 2018-03-24 17:21:29 --> Model Class Initialized
INFO - 2018-03-24 17:21:29 --> Helper loaded: date_helper
INFO - 2018-03-24 17:21:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:21:29 --> Model Class Initialized
INFO - 2018-03-24 23:21:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:21:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:21:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:21:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:21:29 --> Final output sent to browser
DEBUG - 2018-03-24 23:21:29 --> Total execution time: 0.0967
INFO - 2018-03-24 17:22:27 --> Config Class Initialized
INFO - 2018-03-24 17:22:27 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:22:27 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:22:27 --> Utf8 Class Initialized
INFO - 2018-03-24 17:22:27 --> URI Class Initialized
INFO - 2018-03-24 17:22:27 --> Router Class Initialized
INFO - 2018-03-24 17:22:27 --> Output Class Initialized
INFO - 2018-03-24 17:22:27 --> Security Class Initialized
DEBUG - 2018-03-24 17:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:22:27 --> Input Class Initialized
INFO - 2018-03-24 17:22:27 --> Language Class Initialized
INFO - 2018-03-24 17:22:27 --> Loader Class Initialized
INFO - 2018-03-24 17:22:27 --> Helper loaded: url_helper
INFO - 2018-03-24 17:22:27 --> Helper loaded: form_helper
INFO - 2018-03-24 17:22:27 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:22:27 --> Controller Class Initialized
INFO - 2018-03-24 17:22:27 --> Model Class Initialized
INFO - 2018-03-24 17:22:27 --> Model Class Initialized
INFO - 2018-03-24 17:22:27 --> Model Class Initialized
INFO - 2018-03-24 17:22:27 --> Model Class Initialized
INFO - 2018-03-24 17:22:27 --> Model Class Initialized
INFO - 2018-03-24 17:22:27 --> Model Class Initialized
INFO - 2018-03-24 17:22:27 --> Helper loaded: date_helper
INFO - 2018-03-24 17:22:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:22:27 --> Model Class Initialized
INFO - 2018-03-24 23:22:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:22:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:22:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:22:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:22:27 --> Final output sent to browser
DEBUG - 2018-03-24 23:22:27 --> Total execution time: 0.0931
INFO - 2018-03-24 17:22:38 --> Config Class Initialized
INFO - 2018-03-24 17:22:38 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:22:38 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:22:38 --> Utf8 Class Initialized
INFO - 2018-03-24 17:22:38 --> URI Class Initialized
INFO - 2018-03-24 17:22:38 --> Router Class Initialized
INFO - 2018-03-24 17:22:38 --> Output Class Initialized
INFO - 2018-03-24 17:22:38 --> Security Class Initialized
DEBUG - 2018-03-24 17:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:22:38 --> Input Class Initialized
INFO - 2018-03-24 17:22:38 --> Language Class Initialized
INFO - 2018-03-24 17:22:38 --> Loader Class Initialized
INFO - 2018-03-24 17:22:38 --> Helper loaded: url_helper
INFO - 2018-03-24 17:22:38 --> Helper loaded: form_helper
INFO - 2018-03-24 17:22:38 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:22:38 --> Controller Class Initialized
INFO - 2018-03-24 17:22:38 --> Model Class Initialized
INFO - 2018-03-24 17:22:38 --> Model Class Initialized
INFO - 2018-03-24 17:22:38 --> Model Class Initialized
INFO - 2018-03-24 17:22:38 --> Model Class Initialized
INFO - 2018-03-24 17:22:38 --> Model Class Initialized
INFO - 2018-03-24 17:22:38 --> Model Class Initialized
INFO - 2018-03-24 17:22:38 --> Helper loaded: date_helper
INFO - 2018-03-24 17:22:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:22:38 --> Model Class Initialized
INFO - 2018-03-24 23:22:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:22:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:22:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:22:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:22:38 --> Final output sent to browser
DEBUG - 2018-03-24 23:22:38 --> Total execution time: 0.0832
INFO - 2018-03-24 17:22:45 --> Config Class Initialized
INFO - 2018-03-24 17:22:45 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:22:45 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:22:45 --> Utf8 Class Initialized
INFO - 2018-03-24 17:22:45 --> URI Class Initialized
INFO - 2018-03-24 17:22:45 --> Router Class Initialized
INFO - 2018-03-24 17:22:45 --> Output Class Initialized
INFO - 2018-03-24 17:22:45 --> Security Class Initialized
DEBUG - 2018-03-24 17:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:22:45 --> Input Class Initialized
INFO - 2018-03-24 17:22:45 --> Language Class Initialized
INFO - 2018-03-24 17:22:45 --> Loader Class Initialized
INFO - 2018-03-24 17:22:45 --> Helper loaded: url_helper
INFO - 2018-03-24 17:22:45 --> Helper loaded: form_helper
INFO - 2018-03-24 17:22:45 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:22:45 --> Controller Class Initialized
INFO - 2018-03-24 17:22:45 --> Model Class Initialized
INFO - 2018-03-24 17:22:45 --> Model Class Initialized
INFO - 2018-03-24 17:22:45 --> Model Class Initialized
INFO - 2018-03-24 17:22:45 --> Model Class Initialized
INFO - 2018-03-24 17:22:45 --> Model Class Initialized
INFO - 2018-03-24 17:22:45 --> Model Class Initialized
INFO - 2018-03-24 17:22:45 --> Helper loaded: date_helper
INFO - 2018-03-24 17:22:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:22:45 --> Model Class Initialized
INFO - 2018-03-24 23:22:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:22:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:22:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:22:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:22:45 --> Final output sent to browser
DEBUG - 2018-03-24 23:22:45 --> Total execution time: 0.1073
INFO - 2018-03-24 17:24:25 --> Config Class Initialized
INFO - 2018-03-24 17:24:25 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:24:25 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:24:25 --> Utf8 Class Initialized
INFO - 2018-03-24 17:24:25 --> URI Class Initialized
INFO - 2018-03-24 17:24:25 --> Router Class Initialized
INFO - 2018-03-24 17:24:25 --> Output Class Initialized
INFO - 2018-03-24 17:24:25 --> Security Class Initialized
DEBUG - 2018-03-24 17:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:24:25 --> Input Class Initialized
INFO - 2018-03-24 17:24:25 --> Language Class Initialized
INFO - 2018-03-24 17:24:25 --> Loader Class Initialized
INFO - 2018-03-24 17:24:25 --> Helper loaded: url_helper
INFO - 2018-03-24 17:24:25 --> Helper loaded: form_helper
INFO - 2018-03-24 17:24:25 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:24:25 --> Controller Class Initialized
INFO - 2018-03-24 17:24:25 --> Model Class Initialized
INFO - 2018-03-24 17:24:25 --> Model Class Initialized
INFO - 2018-03-24 17:24:25 --> Model Class Initialized
INFO - 2018-03-24 17:24:25 --> Model Class Initialized
INFO - 2018-03-24 17:24:25 --> Model Class Initialized
INFO - 2018-03-24 17:24:25 --> Model Class Initialized
INFO - 2018-03-24 17:24:25 --> Helper loaded: date_helper
INFO - 2018-03-24 17:24:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:24:25 --> Model Class Initialized
INFO - 2018-03-24 23:24:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:24:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:24:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:24:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:24:25 --> Final output sent to browser
DEBUG - 2018-03-24 23:24:25 --> Total execution time: 0.1040
INFO - 2018-03-24 17:24:56 --> Config Class Initialized
INFO - 2018-03-24 17:24:56 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:24:56 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:24:56 --> Utf8 Class Initialized
INFO - 2018-03-24 17:24:56 --> URI Class Initialized
INFO - 2018-03-24 17:24:56 --> Router Class Initialized
INFO - 2018-03-24 17:24:56 --> Output Class Initialized
INFO - 2018-03-24 17:24:56 --> Security Class Initialized
DEBUG - 2018-03-24 17:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:24:56 --> Input Class Initialized
INFO - 2018-03-24 17:24:56 --> Language Class Initialized
ERROR - 2018-03-24 17:24:56 --> 404 Page Not Found: gudang/Penjualan/print
INFO - 2018-03-24 17:24:57 --> Config Class Initialized
INFO - 2018-03-24 17:24:57 --> Hooks Class Initialized
DEBUG - 2018-03-24 17:24:57 --> UTF-8 Support Enabled
INFO - 2018-03-24 17:24:57 --> Utf8 Class Initialized
INFO - 2018-03-24 17:24:57 --> URI Class Initialized
INFO - 2018-03-24 17:24:57 --> Router Class Initialized
INFO - 2018-03-24 17:24:57 --> Output Class Initialized
INFO - 2018-03-24 17:24:57 --> Security Class Initialized
DEBUG - 2018-03-24 17:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 17:24:57 --> Input Class Initialized
INFO - 2018-03-24 17:24:57 --> Language Class Initialized
INFO - 2018-03-24 17:24:57 --> Loader Class Initialized
INFO - 2018-03-24 17:24:57 --> Helper loaded: url_helper
INFO - 2018-03-24 17:24:57 --> Helper loaded: form_helper
INFO - 2018-03-24 17:24:57 --> Database Driver Class Initialized
DEBUG - 2018-03-24 17:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 17:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 17:24:57 --> Controller Class Initialized
INFO - 2018-03-24 17:24:57 --> Model Class Initialized
INFO - 2018-03-24 17:24:57 --> Model Class Initialized
INFO - 2018-03-24 17:24:57 --> Model Class Initialized
INFO - 2018-03-24 17:24:57 --> Model Class Initialized
INFO - 2018-03-24 17:24:57 --> Model Class Initialized
INFO - 2018-03-24 17:24:57 --> Model Class Initialized
INFO - 2018-03-24 17:24:57 --> Helper loaded: date_helper
INFO - 2018-03-24 17:24:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 23:24:57 --> Model Class Initialized
INFO - 2018-03-24 23:24:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-24 23:24:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-24 23:24:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-24 23:24:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-24 23:24:57 --> Final output sent to browser
DEBUG - 2018-03-24 23:24:57 --> Total execution time: 0.0903
INFO - 2018-03-24 18:33:16 --> Config Class Initialized
INFO - 2018-03-24 18:33:16 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:33:16 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:33:16 --> Utf8 Class Initialized
INFO - 2018-03-24 18:33:16 --> URI Class Initialized
INFO - 2018-03-24 18:33:16 --> Router Class Initialized
INFO - 2018-03-24 18:33:16 --> Output Class Initialized
INFO - 2018-03-24 18:33:16 --> Security Class Initialized
DEBUG - 2018-03-24 18:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:33:16 --> Input Class Initialized
INFO - 2018-03-24 18:33:16 --> Language Class Initialized
INFO - 2018-03-24 18:33:16 --> Loader Class Initialized
INFO - 2018-03-24 18:33:16 --> Helper loaded: url_helper
INFO - 2018-03-24 18:33:16 --> Helper loaded: form_helper
INFO - 2018-03-24 18:33:16 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:33:16 --> Controller Class Initialized
INFO - 2018-03-24 18:33:16 --> Config Class Initialized
INFO - 2018-03-24 18:33:16 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:33:16 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:33:16 --> Utf8 Class Initialized
INFO - 2018-03-24 18:33:16 --> URI Class Initialized
INFO - 2018-03-24 18:33:16 --> Router Class Initialized
INFO - 2018-03-24 18:33:16 --> Output Class Initialized
INFO - 2018-03-24 18:33:16 --> Security Class Initialized
DEBUG - 2018-03-24 18:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:33:16 --> Input Class Initialized
INFO - 2018-03-24 18:33:16 --> Language Class Initialized
INFO - 2018-03-24 18:33:16 --> Loader Class Initialized
INFO - 2018-03-24 18:33:16 --> Helper loaded: url_helper
INFO - 2018-03-24 18:33:16 --> Helper loaded: form_helper
INFO - 2018-03-24 18:33:16 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:33:16 --> Controller Class Initialized
INFO - 2018-03-24 18:33:16 --> Model Class Initialized
INFO - 2018-03-24 18:33:16 --> Model Class Initialized
INFO - 2018-03-24 18:33:16 --> Model Class Initialized
INFO - 2018-03-24 18:33:16 --> Helper loaded: date_helper
INFO - 2018-03-24 18:33:19 --> Config Class Initialized
INFO - 2018-03-24 18:33:19 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:33:19 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:33:19 --> Utf8 Class Initialized
INFO - 2018-03-24 18:33:19 --> URI Class Initialized
INFO - 2018-03-24 18:33:19 --> Router Class Initialized
INFO - 2018-03-24 18:33:19 --> Output Class Initialized
INFO - 2018-03-24 18:33:19 --> Security Class Initialized
DEBUG - 2018-03-24 18:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:33:19 --> Input Class Initialized
INFO - 2018-03-24 18:33:19 --> Language Class Initialized
INFO - 2018-03-24 18:33:19 --> Loader Class Initialized
INFO - 2018-03-24 18:33:19 --> Helper loaded: url_helper
INFO - 2018-03-24 18:33:19 --> Helper loaded: form_helper
INFO - 2018-03-24 18:33:19 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:33:19 --> Controller Class Initialized
INFO - 2018-03-24 18:33:19 --> Model Class Initialized
INFO - 2018-03-24 18:33:19 --> Model Class Initialized
INFO - 2018-03-24 18:33:19 --> Model Class Initialized
INFO - 2018-03-24 18:33:19 --> Helper loaded: date_helper
INFO - 2018-03-24 18:33:19 --> Config Class Initialized
INFO - 2018-03-24 18:33:19 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:33:19 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:33:19 --> Utf8 Class Initialized
INFO - 2018-03-24 18:33:19 --> URI Class Initialized
INFO - 2018-03-24 18:33:19 --> Router Class Initialized
INFO - 2018-03-24 18:33:19 --> Output Class Initialized
INFO - 2018-03-24 18:33:19 --> Security Class Initialized
DEBUG - 2018-03-24 18:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:33:19 --> Input Class Initialized
INFO - 2018-03-24 18:33:19 --> Language Class Initialized
INFO - 2018-03-24 18:33:19 --> Loader Class Initialized
INFO - 2018-03-24 18:33:19 --> Helper loaded: url_helper
INFO - 2018-03-24 18:33:19 --> Helper loaded: form_helper
INFO - 2018-03-24 18:33:19 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:33:19 --> Controller Class Initialized
INFO - 2018-03-24 18:33:19 --> Model Class Initialized
INFO - 2018-03-24 18:33:19 --> Model Class Initialized
INFO - 2018-03-24 18:33:19 --> Model Class Initialized
INFO - 2018-03-24 18:33:19 --> Model Class Initialized
INFO - 2018-03-24 18:33:19 --> Model Class Initialized
INFO - 2018-03-24 18:33:19 --> Helper loaded: date_helper
INFO - 2018-03-24 18:33:23 --> Config Class Initialized
INFO - 2018-03-24 18:33:23 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:33:23 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:33:23 --> Utf8 Class Initialized
INFO - 2018-03-24 18:33:23 --> URI Class Initialized
INFO - 2018-03-24 18:33:23 --> Router Class Initialized
INFO - 2018-03-24 18:33:23 --> Output Class Initialized
INFO - 2018-03-24 18:33:23 --> Security Class Initialized
DEBUG - 2018-03-24 18:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:33:23 --> Input Class Initialized
INFO - 2018-03-24 18:33:23 --> Language Class Initialized
INFO - 2018-03-24 18:33:23 --> Loader Class Initialized
INFO - 2018-03-24 18:33:23 --> Helper loaded: url_helper
INFO - 2018-03-24 18:33:23 --> Helper loaded: form_helper
INFO - 2018-03-24 18:33:23 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:33:23 --> Controller Class Initialized
INFO - 2018-03-24 18:33:23 --> Model Class Initialized
INFO - 2018-03-24 18:33:23 --> Model Class Initialized
INFO - 2018-03-24 18:33:23 --> Model Class Initialized
INFO - 2018-03-24 18:33:23 --> Model Class Initialized
INFO - 2018-03-24 18:33:23 --> Model Class Initialized
INFO - 2018-03-24 18:33:23 --> Model Class Initialized
INFO - 2018-03-24 18:33:23 --> Helper loaded: date_helper
INFO - 2018-03-24 18:33:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:34:22 --> Config Class Initialized
INFO - 2018-03-24 18:34:22 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:34:22 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:34:22 --> Utf8 Class Initialized
INFO - 2018-03-24 18:34:22 --> URI Class Initialized
INFO - 2018-03-24 18:34:22 --> Router Class Initialized
INFO - 2018-03-24 18:34:22 --> Output Class Initialized
INFO - 2018-03-24 18:34:22 --> Security Class Initialized
DEBUG - 2018-03-24 18:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:34:22 --> Input Class Initialized
INFO - 2018-03-24 18:34:22 --> Language Class Initialized
INFO - 2018-03-24 18:34:22 --> Loader Class Initialized
INFO - 2018-03-24 18:34:22 --> Helper loaded: url_helper
INFO - 2018-03-24 18:34:22 --> Helper loaded: form_helper
INFO - 2018-03-24 18:34:22 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:34:22 --> Controller Class Initialized
INFO - 2018-03-24 18:34:22 --> Model Class Initialized
INFO - 2018-03-24 18:34:22 --> Model Class Initialized
INFO - 2018-03-24 18:34:22 --> Model Class Initialized
INFO - 2018-03-24 18:34:22 --> Model Class Initialized
INFO - 2018-03-24 18:34:22 --> Model Class Initialized
INFO - 2018-03-24 18:34:22 --> Model Class Initialized
INFO - 2018-03-24 18:34:22 --> Helper loaded: date_helper
INFO - 2018-03-24 18:34:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:34:59 --> Config Class Initialized
INFO - 2018-03-24 18:34:59 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:34:59 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:34:59 --> Utf8 Class Initialized
INFO - 2018-03-24 18:34:59 --> URI Class Initialized
INFO - 2018-03-24 18:34:59 --> Router Class Initialized
INFO - 2018-03-24 18:34:59 --> Output Class Initialized
INFO - 2018-03-24 18:34:59 --> Security Class Initialized
DEBUG - 2018-03-24 18:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:34:59 --> Input Class Initialized
INFO - 2018-03-24 18:34:59 --> Language Class Initialized
INFO - 2018-03-24 18:34:59 --> Loader Class Initialized
INFO - 2018-03-24 18:34:59 --> Helper loaded: url_helper
INFO - 2018-03-24 18:34:59 --> Helper loaded: form_helper
INFO - 2018-03-24 18:34:59 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:34:59 --> Controller Class Initialized
INFO - 2018-03-24 18:34:59 --> Model Class Initialized
INFO - 2018-03-24 18:34:59 --> Model Class Initialized
INFO - 2018-03-24 18:34:59 --> Model Class Initialized
INFO - 2018-03-24 18:34:59 --> Model Class Initialized
INFO - 2018-03-24 18:34:59 --> Model Class Initialized
INFO - 2018-03-24 18:34:59 --> Model Class Initialized
INFO - 2018-03-24 18:34:59 --> Helper loaded: date_helper
INFO - 2018-03-24 18:34:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:35:20 --> Config Class Initialized
INFO - 2018-03-24 18:35:20 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:35:20 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:35:20 --> Utf8 Class Initialized
INFO - 2018-03-24 18:35:20 --> URI Class Initialized
INFO - 2018-03-24 18:35:20 --> Router Class Initialized
INFO - 2018-03-24 18:35:20 --> Output Class Initialized
INFO - 2018-03-24 18:35:20 --> Security Class Initialized
DEBUG - 2018-03-24 18:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:35:20 --> Input Class Initialized
INFO - 2018-03-24 18:35:20 --> Language Class Initialized
INFO - 2018-03-24 18:35:20 --> Loader Class Initialized
INFO - 2018-03-24 18:35:20 --> Helper loaded: url_helper
INFO - 2018-03-24 18:35:20 --> Helper loaded: form_helper
INFO - 2018-03-24 18:35:20 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:35:20 --> Controller Class Initialized
INFO - 2018-03-24 18:35:20 --> Model Class Initialized
INFO - 2018-03-24 18:35:20 --> Model Class Initialized
INFO - 2018-03-24 18:35:20 --> Model Class Initialized
INFO - 2018-03-24 18:35:20 --> Model Class Initialized
INFO - 2018-03-24 18:35:20 --> Model Class Initialized
INFO - 2018-03-24 18:35:20 --> Model Class Initialized
INFO - 2018-03-24 18:35:20 --> Helper loaded: date_helper
INFO - 2018-03-24 18:35:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:36:12 --> Config Class Initialized
INFO - 2018-03-24 18:36:12 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:36:12 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:36:12 --> Utf8 Class Initialized
INFO - 2018-03-24 18:36:12 --> URI Class Initialized
INFO - 2018-03-24 18:36:12 --> Router Class Initialized
INFO - 2018-03-24 18:36:12 --> Output Class Initialized
INFO - 2018-03-24 18:36:12 --> Security Class Initialized
DEBUG - 2018-03-24 18:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:36:12 --> Input Class Initialized
INFO - 2018-03-24 18:36:12 --> Language Class Initialized
INFO - 2018-03-24 18:36:12 --> Loader Class Initialized
INFO - 2018-03-24 18:36:12 --> Helper loaded: url_helper
INFO - 2018-03-24 18:36:12 --> Helper loaded: form_helper
INFO - 2018-03-24 18:36:12 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:36:12 --> Controller Class Initialized
INFO - 2018-03-24 18:36:12 --> Model Class Initialized
INFO - 2018-03-24 18:36:12 --> Model Class Initialized
INFO - 2018-03-24 18:36:12 --> Model Class Initialized
INFO - 2018-03-24 18:36:12 --> Model Class Initialized
INFO - 2018-03-24 18:36:12 --> Model Class Initialized
INFO - 2018-03-24 18:36:12 --> Model Class Initialized
INFO - 2018-03-24 18:36:12 --> Helper loaded: date_helper
INFO - 2018-03-24 18:36:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:37:02 --> Config Class Initialized
INFO - 2018-03-24 18:37:02 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:37:02 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:37:02 --> Utf8 Class Initialized
INFO - 2018-03-24 18:37:02 --> URI Class Initialized
INFO - 2018-03-24 18:37:02 --> Router Class Initialized
INFO - 2018-03-24 18:37:02 --> Output Class Initialized
INFO - 2018-03-24 18:37:02 --> Security Class Initialized
DEBUG - 2018-03-24 18:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:37:02 --> Input Class Initialized
INFO - 2018-03-24 18:37:02 --> Language Class Initialized
INFO - 2018-03-24 18:37:02 --> Loader Class Initialized
INFO - 2018-03-24 18:37:02 --> Helper loaded: url_helper
INFO - 2018-03-24 18:37:02 --> Helper loaded: form_helper
INFO - 2018-03-24 18:37:02 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:37:02 --> Controller Class Initialized
INFO - 2018-03-24 18:37:02 --> Model Class Initialized
INFO - 2018-03-24 18:37:02 --> Model Class Initialized
INFO - 2018-03-24 18:37:02 --> Model Class Initialized
INFO - 2018-03-24 18:37:02 --> Model Class Initialized
INFO - 2018-03-24 18:37:02 --> Model Class Initialized
INFO - 2018-03-24 18:37:02 --> Model Class Initialized
INFO - 2018-03-24 18:37:02 --> Helper loaded: date_helper
INFO - 2018-03-24 18:37:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:38:11 --> Config Class Initialized
INFO - 2018-03-24 18:38:11 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:38:11 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:38:11 --> Utf8 Class Initialized
INFO - 2018-03-24 18:38:11 --> URI Class Initialized
INFO - 2018-03-24 18:38:11 --> Router Class Initialized
INFO - 2018-03-24 18:38:11 --> Output Class Initialized
INFO - 2018-03-24 18:38:11 --> Security Class Initialized
DEBUG - 2018-03-24 18:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:38:11 --> Input Class Initialized
INFO - 2018-03-24 18:38:11 --> Language Class Initialized
INFO - 2018-03-24 18:38:11 --> Loader Class Initialized
INFO - 2018-03-24 18:38:11 --> Helper loaded: url_helper
INFO - 2018-03-24 18:38:11 --> Helper loaded: form_helper
INFO - 2018-03-24 18:38:11 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:38:11 --> Controller Class Initialized
INFO - 2018-03-24 18:38:11 --> Model Class Initialized
INFO - 2018-03-24 18:38:11 --> Model Class Initialized
INFO - 2018-03-24 18:38:11 --> Model Class Initialized
INFO - 2018-03-24 18:38:11 --> Model Class Initialized
INFO - 2018-03-24 18:38:11 --> Model Class Initialized
INFO - 2018-03-24 18:38:11 --> Model Class Initialized
INFO - 2018-03-24 18:38:11 --> Helper loaded: date_helper
INFO - 2018-03-24 18:38:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:39:47 --> Config Class Initialized
INFO - 2018-03-24 18:39:47 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:39:47 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:39:47 --> Utf8 Class Initialized
INFO - 2018-03-24 18:39:47 --> URI Class Initialized
INFO - 2018-03-24 18:39:47 --> Router Class Initialized
INFO - 2018-03-24 18:39:47 --> Output Class Initialized
INFO - 2018-03-24 18:39:47 --> Security Class Initialized
DEBUG - 2018-03-24 18:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:39:47 --> Input Class Initialized
INFO - 2018-03-24 18:39:47 --> Language Class Initialized
INFO - 2018-03-24 18:39:47 --> Loader Class Initialized
INFO - 2018-03-24 18:39:47 --> Helper loaded: url_helper
INFO - 2018-03-24 18:39:47 --> Helper loaded: form_helper
INFO - 2018-03-24 18:39:47 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:39:47 --> Controller Class Initialized
INFO - 2018-03-24 18:39:47 --> Model Class Initialized
INFO - 2018-03-24 18:39:47 --> Model Class Initialized
INFO - 2018-03-24 18:39:47 --> Model Class Initialized
INFO - 2018-03-24 18:39:47 --> Model Class Initialized
INFO - 2018-03-24 18:39:47 --> Model Class Initialized
INFO - 2018-03-24 18:39:47 --> Model Class Initialized
INFO - 2018-03-24 18:39:47 --> Helper loaded: date_helper
INFO - 2018-03-24 18:39:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:40:05 --> Config Class Initialized
INFO - 2018-03-24 18:40:05 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:40:05 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:40:05 --> Utf8 Class Initialized
INFO - 2018-03-24 18:40:05 --> URI Class Initialized
INFO - 2018-03-24 18:40:05 --> Router Class Initialized
INFO - 2018-03-24 18:40:05 --> Output Class Initialized
INFO - 2018-03-24 18:40:05 --> Security Class Initialized
DEBUG - 2018-03-24 18:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:40:05 --> Input Class Initialized
INFO - 2018-03-24 18:40:05 --> Language Class Initialized
INFO - 2018-03-24 18:40:05 --> Loader Class Initialized
INFO - 2018-03-24 18:40:05 --> Helper loaded: url_helper
INFO - 2018-03-24 18:40:05 --> Helper loaded: form_helper
INFO - 2018-03-24 18:40:05 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:40:05 --> Controller Class Initialized
INFO - 2018-03-24 18:40:05 --> Model Class Initialized
INFO - 2018-03-24 18:40:05 --> Model Class Initialized
INFO - 2018-03-24 18:40:05 --> Model Class Initialized
INFO - 2018-03-24 18:40:05 --> Model Class Initialized
INFO - 2018-03-24 18:40:05 --> Model Class Initialized
INFO - 2018-03-24 18:40:05 --> Model Class Initialized
INFO - 2018-03-24 18:40:05 --> Helper loaded: date_helper
INFO - 2018-03-24 18:40:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:40:24 --> Config Class Initialized
INFO - 2018-03-24 18:40:24 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:40:24 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:40:24 --> Utf8 Class Initialized
INFO - 2018-03-24 18:40:24 --> URI Class Initialized
INFO - 2018-03-24 18:40:24 --> Router Class Initialized
INFO - 2018-03-24 18:40:24 --> Output Class Initialized
INFO - 2018-03-24 18:40:24 --> Security Class Initialized
DEBUG - 2018-03-24 18:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:40:25 --> Input Class Initialized
INFO - 2018-03-24 18:40:25 --> Language Class Initialized
INFO - 2018-03-24 18:40:25 --> Loader Class Initialized
INFO - 2018-03-24 18:40:25 --> Helper loaded: url_helper
INFO - 2018-03-24 18:40:25 --> Helper loaded: form_helper
INFO - 2018-03-24 18:40:25 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:40:25 --> Controller Class Initialized
INFO - 2018-03-24 18:40:25 --> Model Class Initialized
INFO - 2018-03-24 18:40:25 --> Model Class Initialized
INFO - 2018-03-24 18:40:25 --> Model Class Initialized
INFO - 2018-03-24 18:40:25 --> Model Class Initialized
INFO - 2018-03-24 18:40:25 --> Model Class Initialized
INFO - 2018-03-24 18:40:25 --> Model Class Initialized
INFO - 2018-03-24 18:40:25 --> Helper loaded: date_helper
INFO - 2018-03-24 18:40:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:41:01 --> Config Class Initialized
INFO - 2018-03-24 18:41:01 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:41:01 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:41:01 --> Utf8 Class Initialized
INFO - 2018-03-24 18:41:01 --> URI Class Initialized
INFO - 2018-03-24 18:41:01 --> Router Class Initialized
INFO - 2018-03-24 18:41:01 --> Output Class Initialized
INFO - 2018-03-24 18:41:01 --> Security Class Initialized
DEBUG - 2018-03-24 18:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:41:01 --> Input Class Initialized
INFO - 2018-03-24 18:41:01 --> Language Class Initialized
INFO - 2018-03-24 18:41:01 --> Loader Class Initialized
INFO - 2018-03-24 18:41:01 --> Helper loaded: url_helper
INFO - 2018-03-24 18:41:01 --> Helper loaded: form_helper
INFO - 2018-03-24 18:41:01 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:41:01 --> Controller Class Initialized
INFO - 2018-03-24 18:41:01 --> Model Class Initialized
INFO - 2018-03-24 18:41:01 --> Model Class Initialized
INFO - 2018-03-24 18:41:01 --> Model Class Initialized
INFO - 2018-03-24 18:41:01 --> Model Class Initialized
INFO - 2018-03-24 18:41:01 --> Model Class Initialized
INFO - 2018-03-24 18:41:01 --> Model Class Initialized
INFO - 2018-03-24 18:41:01 --> Helper loaded: date_helper
INFO - 2018-03-24 18:41:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:41:17 --> Config Class Initialized
INFO - 2018-03-24 18:41:17 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:41:17 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:41:17 --> Utf8 Class Initialized
INFO - 2018-03-24 18:41:17 --> URI Class Initialized
INFO - 2018-03-24 18:41:17 --> Router Class Initialized
INFO - 2018-03-24 18:41:17 --> Output Class Initialized
INFO - 2018-03-24 18:41:17 --> Security Class Initialized
DEBUG - 2018-03-24 18:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:41:17 --> Input Class Initialized
INFO - 2018-03-24 18:41:17 --> Language Class Initialized
INFO - 2018-03-24 18:41:17 --> Loader Class Initialized
INFO - 2018-03-24 18:41:17 --> Helper loaded: url_helper
INFO - 2018-03-24 18:41:17 --> Helper loaded: form_helper
INFO - 2018-03-24 18:41:17 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:41:17 --> Controller Class Initialized
INFO - 2018-03-24 18:41:17 --> Model Class Initialized
INFO - 2018-03-24 18:41:17 --> Model Class Initialized
INFO - 2018-03-24 18:41:17 --> Model Class Initialized
INFO - 2018-03-24 18:41:17 --> Model Class Initialized
INFO - 2018-03-24 18:41:17 --> Model Class Initialized
INFO - 2018-03-24 18:41:17 --> Model Class Initialized
INFO - 2018-03-24 18:41:17 --> Helper loaded: date_helper
INFO - 2018-03-24 18:41:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:42:12 --> Config Class Initialized
INFO - 2018-03-24 18:42:12 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:42:12 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:42:12 --> Utf8 Class Initialized
INFO - 2018-03-24 18:42:12 --> URI Class Initialized
INFO - 2018-03-24 18:42:12 --> Router Class Initialized
INFO - 2018-03-24 18:42:12 --> Output Class Initialized
INFO - 2018-03-24 18:42:12 --> Security Class Initialized
DEBUG - 2018-03-24 18:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:42:12 --> Input Class Initialized
INFO - 2018-03-24 18:42:12 --> Language Class Initialized
INFO - 2018-03-24 18:42:12 --> Loader Class Initialized
INFO - 2018-03-24 18:42:12 --> Helper loaded: url_helper
INFO - 2018-03-24 18:42:12 --> Helper loaded: form_helper
INFO - 2018-03-24 18:42:12 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:42:12 --> Controller Class Initialized
INFO - 2018-03-24 18:42:12 --> Model Class Initialized
INFO - 2018-03-24 18:42:12 --> Model Class Initialized
INFO - 2018-03-24 18:42:12 --> Model Class Initialized
INFO - 2018-03-24 18:42:12 --> Model Class Initialized
INFO - 2018-03-24 18:42:12 --> Model Class Initialized
INFO - 2018-03-24 18:42:12 --> Model Class Initialized
INFO - 2018-03-24 18:42:12 --> Helper loaded: date_helper
INFO - 2018-03-24 18:42:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:43:01 --> Config Class Initialized
INFO - 2018-03-24 18:43:01 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:43:01 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:43:01 --> Utf8 Class Initialized
INFO - 2018-03-24 18:43:01 --> URI Class Initialized
INFO - 2018-03-24 18:43:01 --> Router Class Initialized
INFO - 2018-03-24 18:43:01 --> Output Class Initialized
INFO - 2018-03-24 18:43:01 --> Security Class Initialized
DEBUG - 2018-03-24 18:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:43:01 --> Input Class Initialized
INFO - 2018-03-24 18:43:01 --> Language Class Initialized
INFO - 2018-03-24 18:43:01 --> Loader Class Initialized
INFO - 2018-03-24 18:43:01 --> Helper loaded: url_helper
INFO - 2018-03-24 18:43:01 --> Helper loaded: form_helper
INFO - 2018-03-24 18:43:01 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:43:01 --> Controller Class Initialized
INFO - 2018-03-24 18:43:01 --> Model Class Initialized
INFO - 2018-03-24 18:43:01 --> Model Class Initialized
INFO - 2018-03-24 18:43:01 --> Model Class Initialized
INFO - 2018-03-24 18:43:01 --> Model Class Initialized
INFO - 2018-03-24 18:43:01 --> Model Class Initialized
INFO - 2018-03-24 18:43:01 --> Model Class Initialized
INFO - 2018-03-24 18:43:01 --> Helper loaded: date_helper
INFO - 2018-03-24 18:43:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:43:07 --> Config Class Initialized
INFO - 2018-03-24 18:43:07 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:43:07 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:43:07 --> Utf8 Class Initialized
INFO - 2018-03-24 18:43:07 --> URI Class Initialized
INFO - 2018-03-24 18:43:07 --> Router Class Initialized
INFO - 2018-03-24 18:43:07 --> Output Class Initialized
INFO - 2018-03-24 18:43:07 --> Security Class Initialized
DEBUG - 2018-03-24 18:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:43:07 --> Input Class Initialized
INFO - 2018-03-24 18:43:07 --> Language Class Initialized
INFO - 2018-03-24 18:43:07 --> Loader Class Initialized
INFO - 2018-03-24 18:43:07 --> Helper loaded: url_helper
INFO - 2018-03-24 18:43:07 --> Helper loaded: form_helper
INFO - 2018-03-24 18:43:07 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:43:07 --> Controller Class Initialized
INFO - 2018-03-24 18:43:07 --> Model Class Initialized
INFO - 2018-03-24 18:43:07 --> Model Class Initialized
INFO - 2018-03-24 18:43:07 --> Model Class Initialized
INFO - 2018-03-24 18:43:07 --> Model Class Initialized
INFO - 2018-03-24 18:43:07 --> Model Class Initialized
INFO - 2018-03-24 18:43:07 --> Model Class Initialized
INFO - 2018-03-24 18:43:07 --> Helper loaded: date_helper
INFO - 2018-03-24 18:43:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:43:18 --> Config Class Initialized
INFO - 2018-03-24 18:43:18 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:43:18 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:43:18 --> Utf8 Class Initialized
INFO - 2018-03-24 18:43:18 --> URI Class Initialized
INFO - 2018-03-24 18:43:18 --> Router Class Initialized
INFO - 2018-03-24 18:43:18 --> Output Class Initialized
INFO - 2018-03-24 18:43:18 --> Security Class Initialized
DEBUG - 2018-03-24 18:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:43:18 --> Input Class Initialized
INFO - 2018-03-24 18:43:18 --> Language Class Initialized
INFO - 2018-03-24 18:43:18 --> Loader Class Initialized
INFO - 2018-03-24 18:43:18 --> Helper loaded: url_helper
INFO - 2018-03-24 18:43:18 --> Helper loaded: form_helper
INFO - 2018-03-24 18:43:18 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:43:18 --> Controller Class Initialized
INFO - 2018-03-24 18:43:18 --> Model Class Initialized
INFO - 2018-03-24 18:43:18 --> Model Class Initialized
INFO - 2018-03-24 18:43:18 --> Model Class Initialized
INFO - 2018-03-24 18:43:18 --> Model Class Initialized
INFO - 2018-03-24 18:43:18 --> Model Class Initialized
INFO - 2018-03-24 18:43:18 --> Model Class Initialized
INFO - 2018-03-24 18:43:18 --> Helper loaded: date_helper
INFO - 2018-03-24 18:43:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:43:43 --> Config Class Initialized
INFO - 2018-03-24 18:43:43 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:43:43 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:43:43 --> Utf8 Class Initialized
INFO - 2018-03-24 18:43:43 --> URI Class Initialized
INFO - 2018-03-24 18:43:43 --> Router Class Initialized
INFO - 2018-03-24 18:43:43 --> Output Class Initialized
INFO - 2018-03-24 18:43:43 --> Security Class Initialized
DEBUG - 2018-03-24 18:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:43:43 --> Input Class Initialized
INFO - 2018-03-24 18:43:43 --> Language Class Initialized
INFO - 2018-03-24 18:43:43 --> Loader Class Initialized
INFO - 2018-03-24 18:43:43 --> Helper loaded: url_helper
INFO - 2018-03-24 18:43:43 --> Helper loaded: form_helper
INFO - 2018-03-24 18:43:43 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:43:43 --> Controller Class Initialized
INFO - 2018-03-24 18:43:43 --> Model Class Initialized
INFO - 2018-03-24 18:43:43 --> Model Class Initialized
INFO - 2018-03-24 18:43:43 --> Model Class Initialized
INFO - 2018-03-24 18:43:43 --> Model Class Initialized
INFO - 2018-03-24 18:43:43 --> Model Class Initialized
INFO - 2018-03-24 18:43:43 --> Model Class Initialized
INFO - 2018-03-24 18:43:43 --> Helper loaded: date_helper
INFO - 2018-03-24 18:43:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:43:58 --> Config Class Initialized
INFO - 2018-03-24 18:43:58 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:43:58 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:43:58 --> Utf8 Class Initialized
INFO - 2018-03-24 18:43:58 --> URI Class Initialized
INFO - 2018-03-24 18:43:58 --> Router Class Initialized
INFO - 2018-03-24 18:43:58 --> Output Class Initialized
INFO - 2018-03-24 18:43:58 --> Security Class Initialized
DEBUG - 2018-03-24 18:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:43:58 --> Input Class Initialized
INFO - 2018-03-24 18:43:58 --> Language Class Initialized
INFO - 2018-03-24 18:43:58 --> Loader Class Initialized
INFO - 2018-03-24 18:43:58 --> Helper loaded: url_helper
INFO - 2018-03-24 18:43:58 --> Helper loaded: form_helper
INFO - 2018-03-24 18:43:58 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:43:58 --> Controller Class Initialized
INFO - 2018-03-24 18:43:58 --> Model Class Initialized
INFO - 2018-03-24 18:43:58 --> Model Class Initialized
INFO - 2018-03-24 18:43:58 --> Model Class Initialized
INFO - 2018-03-24 18:43:58 --> Model Class Initialized
INFO - 2018-03-24 18:43:58 --> Model Class Initialized
INFO - 2018-03-24 18:43:58 --> Model Class Initialized
INFO - 2018-03-24 18:43:58 --> Helper loaded: date_helper
INFO - 2018-03-24 18:43:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:44:03 --> Config Class Initialized
INFO - 2018-03-24 18:44:03 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:44:03 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:44:03 --> Utf8 Class Initialized
INFO - 2018-03-24 18:44:03 --> URI Class Initialized
INFO - 2018-03-24 18:44:03 --> Router Class Initialized
INFO - 2018-03-24 18:44:03 --> Output Class Initialized
INFO - 2018-03-24 18:44:03 --> Security Class Initialized
DEBUG - 2018-03-24 18:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:44:03 --> Input Class Initialized
INFO - 2018-03-24 18:44:03 --> Language Class Initialized
INFO - 2018-03-24 18:44:03 --> Loader Class Initialized
INFO - 2018-03-24 18:44:03 --> Helper loaded: url_helper
INFO - 2018-03-24 18:44:03 --> Helper loaded: form_helper
INFO - 2018-03-24 18:44:03 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:44:03 --> Controller Class Initialized
INFO - 2018-03-24 18:44:03 --> Model Class Initialized
INFO - 2018-03-24 18:44:03 --> Model Class Initialized
INFO - 2018-03-24 18:44:03 --> Model Class Initialized
INFO - 2018-03-24 18:44:03 --> Model Class Initialized
INFO - 2018-03-24 18:44:03 --> Model Class Initialized
INFO - 2018-03-24 18:44:03 --> Model Class Initialized
INFO - 2018-03-24 18:44:03 --> Helper loaded: date_helper
INFO - 2018-03-24 18:44:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:44:06 --> Config Class Initialized
INFO - 2018-03-24 18:44:06 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:44:07 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:44:07 --> Utf8 Class Initialized
INFO - 2018-03-24 18:44:07 --> URI Class Initialized
INFO - 2018-03-24 18:44:07 --> Router Class Initialized
INFO - 2018-03-24 18:44:07 --> Output Class Initialized
INFO - 2018-03-24 18:44:07 --> Security Class Initialized
DEBUG - 2018-03-24 18:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:44:07 --> Input Class Initialized
INFO - 2018-03-24 18:44:07 --> Language Class Initialized
INFO - 2018-03-24 18:44:07 --> Loader Class Initialized
INFO - 2018-03-24 18:44:07 --> Helper loaded: url_helper
INFO - 2018-03-24 18:44:07 --> Helper loaded: form_helper
INFO - 2018-03-24 18:44:07 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:44:07 --> Controller Class Initialized
INFO - 2018-03-24 18:44:07 --> Model Class Initialized
INFO - 2018-03-24 18:44:07 --> Model Class Initialized
INFO - 2018-03-24 18:44:07 --> Model Class Initialized
INFO - 2018-03-24 18:44:07 --> Model Class Initialized
INFO - 2018-03-24 18:44:07 --> Model Class Initialized
INFO - 2018-03-24 18:44:07 --> Model Class Initialized
INFO - 2018-03-24 18:44:07 --> Helper loaded: date_helper
INFO - 2018-03-24 18:44:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:44:08 --> Config Class Initialized
INFO - 2018-03-24 18:44:08 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:44:08 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:44:08 --> Utf8 Class Initialized
INFO - 2018-03-24 18:44:08 --> URI Class Initialized
INFO - 2018-03-24 18:44:08 --> Router Class Initialized
INFO - 2018-03-24 18:44:08 --> Output Class Initialized
INFO - 2018-03-24 18:44:08 --> Security Class Initialized
DEBUG - 2018-03-24 18:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:44:08 --> Input Class Initialized
INFO - 2018-03-24 18:44:08 --> Language Class Initialized
INFO - 2018-03-24 18:44:08 --> Loader Class Initialized
INFO - 2018-03-24 18:44:08 --> Helper loaded: url_helper
INFO - 2018-03-24 18:44:08 --> Helper loaded: form_helper
INFO - 2018-03-24 18:44:08 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:44:08 --> Controller Class Initialized
INFO - 2018-03-24 18:44:08 --> Model Class Initialized
INFO - 2018-03-24 18:44:08 --> Model Class Initialized
INFO - 2018-03-24 18:44:08 --> Model Class Initialized
INFO - 2018-03-24 18:44:08 --> Model Class Initialized
INFO - 2018-03-24 18:44:08 --> Model Class Initialized
INFO - 2018-03-24 18:44:08 --> Model Class Initialized
INFO - 2018-03-24 18:44:08 --> Helper loaded: date_helper
INFO - 2018-03-24 18:44:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:44:08 --> Config Class Initialized
INFO - 2018-03-24 18:44:08 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:44:08 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:44:08 --> Utf8 Class Initialized
INFO - 2018-03-24 18:44:08 --> URI Class Initialized
INFO - 2018-03-24 18:44:08 --> Router Class Initialized
INFO - 2018-03-24 18:44:08 --> Output Class Initialized
INFO - 2018-03-24 18:44:08 --> Security Class Initialized
DEBUG - 2018-03-24 18:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:44:08 --> Input Class Initialized
INFO - 2018-03-24 18:44:08 --> Language Class Initialized
INFO - 2018-03-24 18:44:08 --> Loader Class Initialized
INFO - 2018-03-24 18:44:08 --> Helper loaded: url_helper
INFO - 2018-03-24 18:44:08 --> Helper loaded: form_helper
INFO - 2018-03-24 18:44:08 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:44:08 --> Controller Class Initialized
INFO - 2018-03-24 18:44:08 --> Model Class Initialized
INFO - 2018-03-24 18:44:08 --> Model Class Initialized
INFO - 2018-03-24 18:44:08 --> Model Class Initialized
INFO - 2018-03-24 18:44:08 --> Model Class Initialized
INFO - 2018-03-24 18:44:08 --> Model Class Initialized
INFO - 2018-03-24 18:44:08 --> Model Class Initialized
INFO - 2018-03-24 18:44:08 --> Helper loaded: date_helper
INFO - 2018-03-24 18:44:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:44:08 --> Config Class Initialized
INFO - 2018-03-24 18:44:08 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:44:08 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:44:08 --> Utf8 Class Initialized
INFO - 2018-03-24 18:44:08 --> URI Class Initialized
INFO - 2018-03-24 18:44:08 --> Router Class Initialized
INFO - 2018-03-24 18:44:08 --> Output Class Initialized
INFO - 2018-03-24 18:44:08 --> Security Class Initialized
DEBUG - 2018-03-24 18:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:44:08 --> Input Class Initialized
INFO - 2018-03-24 18:44:08 --> Language Class Initialized
INFO - 2018-03-24 18:44:08 --> Loader Class Initialized
INFO - 2018-03-24 18:44:09 --> Helper loaded: url_helper
INFO - 2018-03-24 18:44:09 --> Helper loaded: form_helper
INFO - 2018-03-24 18:44:09 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:44:09 --> Controller Class Initialized
INFO - 2018-03-24 18:44:09 --> Model Class Initialized
INFO - 2018-03-24 18:44:09 --> Model Class Initialized
INFO - 2018-03-24 18:44:09 --> Model Class Initialized
INFO - 2018-03-24 18:44:09 --> Model Class Initialized
INFO - 2018-03-24 18:44:09 --> Model Class Initialized
INFO - 2018-03-24 18:44:09 --> Model Class Initialized
INFO - 2018-03-24 18:44:09 --> Helper loaded: date_helper
INFO - 2018-03-24 18:44:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:44:09 --> Config Class Initialized
INFO - 2018-03-24 18:44:09 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:44:09 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:44:09 --> Utf8 Class Initialized
INFO - 2018-03-24 18:44:09 --> URI Class Initialized
INFO - 2018-03-24 18:44:09 --> Router Class Initialized
INFO - 2018-03-24 18:44:09 --> Output Class Initialized
INFO - 2018-03-24 18:44:09 --> Security Class Initialized
DEBUG - 2018-03-24 18:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:44:09 --> Input Class Initialized
INFO - 2018-03-24 18:44:09 --> Language Class Initialized
INFO - 2018-03-24 18:44:09 --> Loader Class Initialized
INFO - 2018-03-24 18:44:09 --> Helper loaded: url_helper
INFO - 2018-03-24 18:44:09 --> Helper loaded: form_helper
INFO - 2018-03-24 18:44:09 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:44:09 --> Controller Class Initialized
INFO - 2018-03-24 18:44:09 --> Model Class Initialized
INFO - 2018-03-24 18:44:09 --> Model Class Initialized
INFO - 2018-03-24 18:44:09 --> Model Class Initialized
INFO - 2018-03-24 18:44:09 --> Model Class Initialized
INFO - 2018-03-24 18:44:09 --> Model Class Initialized
INFO - 2018-03-24 18:44:09 --> Model Class Initialized
INFO - 2018-03-24 18:44:09 --> Helper loaded: date_helper
INFO - 2018-03-24 18:44:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:44:20 --> Config Class Initialized
INFO - 2018-03-24 18:44:20 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:44:20 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:44:20 --> Utf8 Class Initialized
INFO - 2018-03-24 18:44:20 --> URI Class Initialized
INFO - 2018-03-24 18:44:20 --> Router Class Initialized
INFO - 2018-03-24 18:44:20 --> Output Class Initialized
INFO - 2018-03-24 18:44:20 --> Security Class Initialized
DEBUG - 2018-03-24 18:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:44:20 --> Input Class Initialized
INFO - 2018-03-24 18:44:20 --> Language Class Initialized
INFO - 2018-03-24 18:44:20 --> Loader Class Initialized
INFO - 2018-03-24 18:44:20 --> Helper loaded: url_helper
INFO - 2018-03-24 18:44:20 --> Helper loaded: form_helper
INFO - 2018-03-24 18:44:20 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:44:20 --> Controller Class Initialized
INFO - 2018-03-24 18:44:20 --> Model Class Initialized
INFO - 2018-03-24 18:44:20 --> Model Class Initialized
INFO - 2018-03-24 18:44:20 --> Model Class Initialized
INFO - 2018-03-24 18:44:20 --> Model Class Initialized
INFO - 2018-03-24 18:44:20 --> Model Class Initialized
INFO - 2018-03-24 18:44:20 --> Model Class Initialized
INFO - 2018-03-24 18:44:20 --> Helper loaded: date_helper
INFO - 2018-03-24 18:44:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:44:59 --> Config Class Initialized
INFO - 2018-03-24 18:44:59 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:44:59 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:44:59 --> Utf8 Class Initialized
INFO - 2018-03-24 18:44:59 --> URI Class Initialized
INFO - 2018-03-24 18:44:59 --> Router Class Initialized
INFO - 2018-03-24 18:44:59 --> Output Class Initialized
INFO - 2018-03-24 18:44:59 --> Security Class Initialized
DEBUG - 2018-03-24 18:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:44:59 --> Input Class Initialized
INFO - 2018-03-24 18:44:59 --> Language Class Initialized
INFO - 2018-03-24 18:44:59 --> Loader Class Initialized
INFO - 2018-03-24 18:44:59 --> Helper loaded: url_helper
INFO - 2018-03-24 18:44:59 --> Helper loaded: form_helper
INFO - 2018-03-24 18:44:59 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:44:59 --> Controller Class Initialized
INFO - 2018-03-24 18:44:59 --> Model Class Initialized
INFO - 2018-03-24 18:44:59 --> Model Class Initialized
INFO - 2018-03-24 18:44:59 --> Model Class Initialized
INFO - 2018-03-24 18:44:59 --> Model Class Initialized
INFO - 2018-03-24 18:44:59 --> Model Class Initialized
INFO - 2018-03-24 18:44:59 --> Model Class Initialized
INFO - 2018-03-24 18:44:59 --> Helper loaded: date_helper
INFO - 2018-03-24 18:44:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:45:14 --> Config Class Initialized
INFO - 2018-03-24 18:45:14 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:45:14 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:45:14 --> Utf8 Class Initialized
INFO - 2018-03-24 18:45:14 --> URI Class Initialized
INFO - 2018-03-24 18:45:14 --> Router Class Initialized
INFO - 2018-03-24 18:45:14 --> Output Class Initialized
INFO - 2018-03-24 18:45:14 --> Security Class Initialized
DEBUG - 2018-03-24 18:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:45:14 --> Input Class Initialized
INFO - 2018-03-24 18:45:14 --> Language Class Initialized
INFO - 2018-03-24 18:45:14 --> Loader Class Initialized
INFO - 2018-03-24 18:45:14 --> Helper loaded: url_helper
INFO - 2018-03-24 18:45:14 --> Helper loaded: form_helper
INFO - 2018-03-24 18:45:14 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:45:14 --> Controller Class Initialized
INFO - 2018-03-24 18:45:14 --> Model Class Initialized
INFO - 2018-03-24 18:45:14 --> Model Class Initialized
INFO - 2018-03-24 18:45:14 --> Helper loaded: date_helper
INFO - 2018-03-24 18:45:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:45:16 --> Config Class Initialized
INFO - 2018-03-24 18:45:16 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:45:16 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:45:16 --> Utf8 Class Initialized
INFO - 2018-03-24 18:45:16 --> URI Class Initialized
INFO - 2018-03-24 18:45:16 --> Router Class Initialized
INFO - 2018-03-24 18:45:16 --> Output Class Initialized
INFO - 2018-03-24 18:45:16 --> Security Class Initialized
DEBUG - 2018-03-24 18:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:45:16 --> Input Class Initialized
INFO - 2018-03-24 18:45:16 --> Language Class Initialized
INFO - 2018-03-24 18:45:16 --> Loader Class Initialized
INFO - 2018-03-24 18:45:16 --> Helper loaded: url_helper
INFO - 2018-03-24 18:45:16 --> Helper loaded: form_helper
INFO - 2018-03-24 18:45:16 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:45:16 --> Controller Class Initialized
INFO - 2018-03-24 18:45:16 --> Model Class Initialized
INFO - 2018-03-24 18:45:16 --> Model Class Initialized
INFO - 2018-03-24 18:45:16 --> Model Class Initialized
INFO - 2018-03-24 18:45:16 --> Model Class Initialized
INFO - 2018-03-24 18:45:16 --> Model Class Initialized
INFO - 2018-03-24 18:45:16 --> Model Class Initialized
INFO - 2018-03-24 18:45:16 --> Helper loaded: date_helper
INFO - 2018-03-24 18:45:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:45:27 --> Config Class Initialized
INFO - 2018-03-24 18:45:27 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:45:27 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:45:27 --> Utf8 Class Initialized
INFO - 2018-03-24 18:45:27 --> URI Class Initialized
INFO - 2018-03-24 18:45:27 --> Router Class Initialized
INFO - 2018-03-24 18:45:27 --> Output Class Initialized
INFO - 2018-03-24 18:45:27 --> Security Class Initialized
DEBUG - 2018-03-24 18:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:45:27 --> Input Class Initialized
INFO - 2018-03-24 18:45:27 --> Language Class Initialized
INFO - 2018-03-24 18:45:27 --> Loader Class Initialized
INFO - 2018-03-24 18:45:27 --> Helper loaded: url_helper
INFO - 2018-03-24 18:45:27 --> Helper loaded: form_helper
INFO - 2018-03-24 18:45:27 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:45:27 --> Controller Class Initialized
INFO - 2018-03-24 18:45:27 --> Model Class Initialized
INFO - 2018-03-24 18:45:27 --> Model Class Initialized
INFO - 2018-03-24 18:45:27 --> Model Class Initialized
INFO - 2018-03-24 18:45:27 --> Model Class Initialized
INFO - 2018-03-24 18:45:27 --> Model Class Initialized
INFO - 2018-03-24 18:45:27 --> Model Class Initialized
INFO - 2018-03-24 18:45:27 --> Helper loaded: date_helper
INFO - 2018-03-24 18:45:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:45:39 --> Config Class Initialized
INFO - 2018-03-24 18:45:39 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:45:39 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:45:39 --> Utf8 Class Initialized
INFO - 2018-03-24 18:45:39 --> URI Class Initialized
INFO - 2018-03-24 18:45:39 --> Router Class Initialized
INFO - 2018-03-24 18:45:39 --> Output Class Initialized
INFO - 2018-03-24 18:45:39 --> Security Class Initialized
DEBUG - 2018-03-24 18:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:45:39 --> Input Class Initialized
INFO - 2018-03-24 18:45:39 --> Language Class Initialized
INFO - 2018-03-24 18:45:39 --> Loader Class Initialized
INFO - 2018-03-24 18:45:39 --> Helper loaded: url_helper
INFO - 2018-03-24 18:45:39 --> Helper loaded: form_helper
INFO - 2018-03-24 18:45:39 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:45:39 --> Controller Class Initialized
INFO - 2018-03-24 18:45:39 --> Model Class Initialized
INFO - 2018-03-24 18:45:39 --> Model Class Initialized
INFO - 2018-03-24 18:45:39 --> Model Class Initialized
INFO - 2018-03-24 18:45:39 --> Model Class Initialized
INFO - 2018-03-24 18:45:39 --> Model Class Initialized
INFO - 2018-03-24 18:45:39 --> Model Class Initialized
INFO - 2018-03-24 18:45:39 --> Helper loaded: date_helper
INFO - 2018-03-24 18:45:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:45:57 --> Config Class Initialized
INFO - 2018-03-24 18:45:57 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:45:57 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:45:57 --> Utf8 Class Initialized
INFO - 2018-03-24 18:45:57 --> URI Class Initialized
INFO - 2018-03-24 18:45:57 --> Router Class Initialized
INFO - 2018-03-24 18:45:57 --> Output Class Initialized
INFO - 2018-03-24 18:45:57 --> Security Class Initialized
DEBUG - 2018-03-24 18:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:45:57 --> Input Class Initialized
INFO - 2018-03-24 18:45:57 --> Language Class Initialized
INFO - 2018-03-24 18:45:57 --> Loader Class Initialized
INFO - 2018-03-24 18:45:57 --> Helper loaded: url_helper
INFO - 2018-03-24 18:45:57 --> Helper loaded: form_helper
INFO - 2018-03-24 18:45:57 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:45:57 --> Controller Class Initialized
INFO - 2018-03-24 18:45:57 --> Model Class Initialized
INFO - 2018-03-24 18:45:57 --> Model Class Initialized
INFO - 2018-03-24 18:45:57 --> Model Class Initialized
INFO - 2018-03-24 18:45:57 --> Model Class Initialized
INFO - 2018-03-24 18:45:57 --> Model Class Initialized
INFO - 2018-03-24 18:45:57 --> Model Class Initialized
INFO - 2018-03-24 18:45:57 --> Helper loaded: date_helper
INFO - 2018-03-24 18:45:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:46:07 --> Config Class Initialized
INFO - 2018-03-24 18:46:07 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:46:07 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:46:07 --> Utf8 Class Initialized
INFO - 2018-03-24 18:46:07 --> URI Class Initialized
INFO - 2018-03-24 18:46:07 --> Router Class Initialized
INFO - 2018-03-24 18:46:07 --> Output Class Initialized
INFO - 2018-03-24 18:46:07 --> Security Class Initialized
DEBUG - 2018-03-24 18:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:46:07 --> Input Class Initialized
INFO - 2018-03-24 18:46:07 --> Language Class Initialized
INFO - 2018-03-24 18:46:07 --> Loader Class Initialized
INFO - 2018-03-24 18:46:07 --> Helper loaded: url_helper
INFO - 2018-03-24 18:46:07 --> Helper loaded: form_helper
INFO - 2018-03-24 18:46:07 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:46:07 --> Controller Class Initialized
INFO - 2018-03-24 18:46:07 --> Model Class Initialized
INFO - 2018-03-24 18:46:07 --> Model Class Initialized
INFO - 2018-03-24 18:46:07 --> Helper loaded: date_helper
INFO - 2018-03-24 18:46:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:46:14 --> Config Class Initialized
INFO - 2018-03-24 18:46:14 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:46:14 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:46:14 --> Utf8 Class Initialized
INFO - 2018-03-24 18:46:14 --> URI Class Initialized
INFO - 2018-03-24 18:46:14 --> Router Class Initialized
INFO - 2018-03-24 18:46:14 --> Output Class Initialized
INFO - 2018-03-24 18:46:14 --> Security Class Initialized
DEBUG - 2018-03-24 18:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:46:14 --> Input Class Initialized
INFO - 2018-03-24 18:46:14 --> Language Class Initialized
INFO - 2018-03-24 18:46:14 --> Loader Class Initialized
INFO - 2018-03-24 18:46:14 --> Helper loaded: url_helper
INFO - 2018-03-24 18:46:14 --> Helper loaded: form_helper
INFO - 2018-03-24 18:46:14 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:46:14 --> Controller Class Initialized
INFO - 2018-03-24 18:46:14 --> Model Class Initialized
INFO - 2018-03-24 18:46:14 --> Model Class Initialized
INFO - 2018-03-24 18:46:14 --> Helper loaded: date_helper
INFO - 2018-03-24 18:46:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:46:19 --> Config Class Initialized
INFO - 2018-03-24 18:46:19 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:46:19 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:46:19 --> Utf8 Class Initialized
INFO - 2018-03-24 18:46:19 --> URI Class Initialized
INFO - 2018-03-24 18:46:19 --> Router Class Initialized
INFO - 2018-03-24 18:46:19 --> Output Class Initialized
INFO - 2018-03-24 18:46:19 --> Security Class Initialized
DEBUG - 2018-03-24 18:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:46:19 --> Input Class Initialized
INFO - 2018-03-24 18:46:19 --> Language Class Initialized
INFO - 2018-03-24 18:46:19 --> Loader Class Initialized
INFO - 2018-03-24 18:46:19 --> Helper loaded: url_helper
INFO - 2018-03-24 18:46:19 --> Helper loaded: form_helper
INFO - 2018-03-24 18:46:19 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:46:19 --> Controller Class Initialized
INFO - 2018-03-24 18:46:19 --> Model Class Initialized
INFO - 2018-03-24 18:46:19 --> Model Class Initialized
INFO - 2018-03-24 18:46:19 --> Model Class Initialized
INFO - 2018-03-24 18:46:19 --> Model Class Initialized
INFO - 2018-03-24 18:46:19 --> Model Class Initialized
INFO - 2018-03-24 18:46:19 --> Model Class Initialized
INFO - 2018-03-24 18:46:19 --> Helper loaded: date_helper
INFO - 2018-03-24 18:46:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:46:20 --> Config Class Initialized
INFO - 2018-03-24 18:46:20 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:46:20 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:46:20 --> Utf8 Class Initialized
INFO - 2018-03-24 18:46:20 --> URI Class Initialized
INFO - 2018-03-24 18:46:20 --> Router Class Initialized
INFO - 2018-03-24 18:46:20 --> Output Class Initialized
INFO - 2018-03-24 18:46:20 --> Security Class Initialized
DEBUG - 2018-03-24 18:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:46:20 --> Input Class Initialized
INFO - 2018-03-24 18:46:20 --> Language Class Initialized
INFO - 2018-03-24 18:46:20 --> Loader Class Initialized
INFO - 2018-03-24 18:46:20 --> Helper loaded: url_helper
INFO - 2018-03-24 18:46:20 --> Helper loaded: form_helper
INFO - 2018-03-24 18:46:20 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:46:20 --> Controller Class Initialized
INFO - 2018-03-24 18:46:20 --> Model Class Initialized
INFO - 2018-03-24 18:46:20 --> Model Class Initialized
INFO - 2018-03-24 18:46:20 --> Model Class Initialized
INFO - 2018-03-24 18:46:20 --> Model Class Initialized
INFO - 2018-03-24 18:46:20 --> Model Class Initialized
INFO - 2018-03-24 18:46:20 --> Model Class Initialized
INFO - 2018-03-24 18:46:20 --> Helper loaded: date_helper
INFO - 2018-03-24 18:46:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:46:41 --> Config Class Initialized
INFO - 2018-03-24 18:46:41 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:46:41 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:46:41 --> Utf8 Class Initialized
INFO - 2018-03-24 18:46:41 --> URI Class Initialized
INFO - 2018-03-24 18:46:41 --> Router Class Initialized
INFO - 2018-03-24 18:46:41 --> Output Class Initialized
INFO - 2018-03-24 18:46:41 --> Security Class Initialized
DEBUG - 2018-03-24 18:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:46:41 --> Input Class Initialized
INFO - 2018-03-24 18:46:41 --> Language Class Initialized
INFO - 2018-03-24 18:46:41 --> Loader Class Initialized
INFO - 2018-03-24 18:46:41 --> Helper loaded: url_helper
INFO - 2018-03-24 18:46:41 --> Helper loaded: form_helper
INFO - 2018-03-24 18:46:41 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:46:41 --> Controller Class Initialized
INFO - 2018-03-24 18:46:41 --> Model Class Initialized
INFO - 2018-03-24 18:46:41 --> Model Class Initialized
INFO - 2018-03-24 18:46:41 --> Model Class Initialized
INFO - 2018-03-24 18:46:41 --> Model Class Initialized
INFO - 2018-03-24 18:46:41 --> Model Class Initialized
INFO - 2018-03-24 18:46:41 --> Model Class Initialized
INFO - 2018-03-24 18:46:41 --> Helper loaded: date_helper
INFO - 2018-03-24 18:46:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:47:24 --> Config Class Initialized
INFO - 2018-03-24 18:47:24 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:47:24 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:47:24 --> Utf8 Class Initialized
INFO - 2018-03-24 18:47:24 --> URI Class Initialized
INFO - 2018-03-24 18:47:24 --> Router Class Initialized
INFO - 2018-03-24 18:47:24 --> Output Class Initialized
INFO - 2018-03-24 18:47:24 --> Security Class Initialized
DEBUG - 2018-03-24 18:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:47:24 --> Input Class Initialized
INFO - 2018-03-24 18:47:24 --> Language Class Initialized
INFO - 2018-03-24 18:47:24 --> Loader Class Initialized
INFO - 2018-03-24 18:47:24 --> Helper loaded: url_helper
INFO - 2018-03-24 18:47:24 --> Helper loaded: form_helper
INFO - 2018-03-24 18:47:24 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:47:24 --> Controller Class Initialized
INFO - 2018-03-24 18:47:24 --> Model Class Initialized
INFO - 2018-03-24 18:47:24 --> Model Class Initialized
INFO - 2018-03-24 18:47:24 --> Model Class Initialized
INFO - 2018-03-24 18:47:24 --> Model Class Initialized
INFO - 2018-03-24 18:47:24 --> Model Class Initialized
INFO - 2018-03-24 18:47:24 --> Model Class Initialized
INFO - 2018-03-24 18:47:24 --> Helper loaded: date_helper
INFO - 2018-03-24 18:47:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:47:34 --> Config Class Initialized
INFO - 2018-03-24 18:47:34 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:47:34 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:47:34 --> Utf8 Class Initialized
INFO - 2018-03-24 18:47:34 --> URI Class Initialized
INFO - 2018-03-24 18:47:34 --> Router Class Initialized
INFO - 2018-03-24 18:47:34 --> Output Class Initialized
INFO - 2018-03-24 18:47:34 --> Security Class Initialized
DEBUG - 2018-03-24 18:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:47:34 --> Input Class Initialized
INFO - 2018-03-24 18:47:34 --> Language Class Initialized
INFO - 2018-03-24 18:47:34 --> Loader Class Initialized
INFO - 2018-03-24 18:47:34 --> Helper loaded: url_helper
INFO - 2018-03-24 18:47:34 --> Helper loaded: form_helper
INFO - 2018-03-24 18:47:34 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:47:34 --> Controller Class Initialized
INFO - 2018-03-24 18:47:34 --> Model Class Initialized
INFO - 2018-03-24 18:47:34 --> Model Class Initialized
INFO - 2018-03-24 18:47:34 --> Helper loaded: date_helper
INFO - 2018-03-24 18:47:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:47:38 --> Config Class Initialized
INFO - 2018-03-24 18:47:38 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:47:38 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:47:38 --> Utf8 Class Initialized
INFO - 2018-03-24 18:47:38 --> URI Class Initialized
INFO - 2018-03-24 18:47:38 --> Router Class Initialized
INFO - 2018-03-24 18:47:38 --> Output Class Initialized
INFO - 2018-03-24 18:47:38 --> Security Class Initialized
DEBUG - 2018-03-24 18:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:47:38 --> Input Class Initialized
INFO - 2018-03-24 18:47:38 --> Language Class Initialized
INFO - 2018-03-24 18:47:38 --> Loader Class Initialized
INFO - 2018-03-24 18:47:38 --> Helper loaded: url_helper
INFO - 2018-03-24 18:47:38 --> Helper loaded: form_helper
INFO - 2018-03-24 18:47:38 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:47:38 --> Controller Class Initialized
INFO - 2018-03-24 18:47:38 --> Model Class Initialized
INFO - 2018-03-24 18:47:38 --> Model Class Initialized
INFO - 2018-03-24 18:47:38 --> Helper loaded: date_helper
INFO - 2018-03-24 18:47:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:47:44 --> Config Class Initialized
INFO - 2018-03-24 18:47:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:47:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:47:44 --> Utf8 Class Initialized
INFO - 2018-03-24 18:47:44 --> URI Class Initialized
INFO - 2018-03-24 18:47:44 --> Router Class Initialized
INFO - 2018-03-24 18:47:44 --> Output Class Initialized
INFO - 2018-03-24 18:47:44 --> Security Class Initialized
DEBUG - 2018-03-24 18:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:47:44 --> Input Class Initialized
INFO - 2018-03-24 18:47:44 --> Language Class Initialized
INFO - 2018-03-24 18:47:44 --> Loader Class Initialized
INFO - 2018-03-24 18:47:44 --> Helper loaded: url_helper
INFO - 2018-03-24 18:47:44 --> Helper loaded: form_helper
INFO - 2018-03-24 18:47:44 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:47:44 --> Controller Class Initialized
INFO - 2018-03-24 18:47:44 --> Model Class Initialized
INFO - 2018-03-24 18:47:44 --> Model Class Initialized
INFO - 2018-03-24 18:47:44 --> Model Class Initialized
INFO - 2018-03-24 18:47:44 --> Model Class Initialized
INFO - 2018-03-24 18:47:44 --> Model Class Initialized
INFO - 2018-03-24 18:47:44 --> Model Class Initialized
INFO - 2018-03-24 18:47:44 --> Helper loaded: date_helper
INFO - 2018-03-24 18:47:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:47:44 --> Config Class Initialized
INFO - 2018-03-24 18:47:44 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:47:44 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:47:44 --> Utf8 Class Initialized
INFO - 2018-03-24 18:47:44 --> URI Class Initialized
INFO - 2018-03-24 18:47:44 --> Router Class Initialized
INFO - 2018-03-24 18:47:44 --> Output Class Initialized
INFO - 2018-03-24 18:47:44 --> Security Class Initialized
DEBUG - 2018-03-24 18:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:47:44 --> Input Class Initialized
INFO - 2018-03-24 18:47:44 --> Language Class Initialized
INFO - 2018-03-24 18:47:44 --> Loader Class Initialized
INFO - 2018-03-24 18:47:44 --> Helper loaded: url_helper
INFO - 2018-03-24 18:47:44 --> Helper loaded: form_helper
INFO - 2018-03-24 18:47:44 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:47:44 --> Controller Class Initialized
INFO - 2018-03-24 18:47:44 --> Model Class Initialized
INFO - 2018-03-24 18:47:44 --> Model Class Initialized
INFO - 2018-03-24 18:47:44 --> Model Class Initialized
INFO - 2018-03-24 18:47:44 --> Model Class Initialized
INFO - 2018-03-24 18:47:44 --> Model Class Initialized
INFO - 2018-03-24 18:47:44 --> Model Class Initialized
INFO - 2018-03-24 18:47:44 --> Helper loaded: date_helper
INFO - 2018-03-24 18:47:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:50:26 --> Config Class Initialized
INFO - 2018-03-24 18:50:26 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:50:26 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:50:26 --> Utf8 Class Initialized
INFO - 2018-03-24 18:50:26 --> URI Class Initialized
INFO - 2018-03-24 18:50:26 --> Router Class Initialized
INFO - 2018-03-24 18:50:26 --> Output Class Initialized
INFO - 2018-03-24 18:50:26 --> Security Class Initialized
DEBUG - 2018-03-24 18:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:50:26 --> Input Class Initialized
INFO - 2018-03-24 18:50:26 --> Language Class Initialized
INFO - 2018-03-24 18:50:26 --> Loader Class Initialized
INFO - 2018-03-24 18:50:26 --> Helper loaded: url_helper
INFO - 2018-03-24 18:50:26 --> Helper loaded: form_helper
INFO - 2018-03-24 18:50:26 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:50:26 --> Controller Class Initialized
INFO - 2018-03-24 18:50:26 --> Model Class Initialized
INFO - 2018-03-24 18:50:26 --> Model Class Initialized
INFO - 2018-03-24 18:50:26 --> Model Class Initialized
INFO - 2018-03-24 18:50:26 --> Model Class Initialized
INFO - 2018-03-24 18:50:26 --> Model Class Initialized
INFO - 2018-03-24 18:50:26 --> Model Class Initialized
INFO - 2018-03-24 18:50:26 --> Helper loaded: date_helper
INFO - 2018-03-24 18:50:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:51:12 --> Config Class Initialized
INFO - 2018-03-24 18:51:12 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:51:12 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:51:12 --> Utf8 Class Initialized
INFO - 2018-03-24 18:51:12 --> URI Class Initialized
INFO - 2018-03-24 18:51:12 --> Router Class Initialized
INFO - 2018-03-24 18:51:12 --> Output Class Initialized
INFO - 2018-03-24 18:51:12 --> Security Class Initialized
DEBUG - 2018-03-24 18:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:51:12 --> Input Class Initialized
INFO - 2018-03-24 18:51:12 --> Language Class Initialized
INFO - 2018-03-24 18:51:12 --> Loader Class Initialized
INFO - 2018-03-24 18:51:12 --> Helper loaded: url_helper
INFO - 2018-03-24 18:51:12 --> Helper loaded: form_helper
INFO - 2018-03-24 18:51:12 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:51:12 --> Controller Class Initialized
INFO - 2018-03-24 18:51:12 --> Model Class Initialized
INFO - 2018-03-24 18:51:12 --> Model Class Initialized
INFO - 2018-03-24 18:51:12 --> Model Class Initialized
INFO - 2018-03-24 18:51:12 --> Model Class Initialized
INFO - 2018-03-24 18:51:12 --> Model Class Initialized
INFO - 2018-03-24 18:51:12 --> Model Class Initialized
INFO - 2018-03-24 18:51:12 --> Helper loaded: date_helper
INFO - 2018-03-24 18:51:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:52:15 --> Config Class Initialized
INFO - 2018-03-24 18:52:15 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:52:15 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:52:15 --> Utf8 Class Initialized
INFO - 2018-03-24 18:52:15 --> URI Class Initialized
INFO - 2018-03-24 18:52:15 --> Router Class Initialized
INFO - 2018-03-24 18:52:15 --> Output Class Initialized
INFO - 2018-03-24 18:52:15 --> Security Class Initialized
DEBUG - 2018-03-24 18:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:52:15 --> Input Class Initialized
INFO - 2018-03-24 18:52:15 --> Language Class Initialized
INFO - 2018-03-24 18:52:15 --> Loader Class Initialized
INFO - 2018-03-24 18:52:15 --> Helper loaded: url_helper
INFO - 2018-03-24 18:52:15 --> Helper loaded: form_helper
INFO - 2018-03-24 18:52:15 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:52:15 --> Controller Class Initialized
INFO - 2018-03-24 18:52:15 --> Model Class Initialized
INFO - 2018-03-24 18:52:15 --> Model Class Initialized
INFO - 2018-03-24 18:52:15 --> Model Class Initialized
INFO - 2018-03-24 18:52:15 --> Model Class Initialized
INFO - 2018-03-24 18:52:15 --> Model Class Initialized
INFO - 2018-03-24 18:52:15 --> Model Class Initialized
INFO - 2018-03-24 18:52:15 --> Helper loaded: date_helper
INFO - 2018-03-24 18:52:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:52:35 --> Config Class Initialized
INFO - 2018-03-24 18:52:35 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:52:35 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:52:35 --> Utf8 Class Initialized
INFO - 2018-03-24 18:52:35 --> URI Class Initialized
INFO - 2018-03-24 18:52:35 --> Router Class Initialized
INFO - 2018-03-24 18:52:35 --> Output Class Initialized
INFO - 2018-03-24 18:52:35 --> Security Class Initialized
DEBUG - 2018-03-24 18:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:52:35 --> Input Class Initialized
INFO - 2018-03-24 18:52:35 --> Language Class Initialized
INFO - 2018-03-24 18:52:35 --> Loader Class Initialized
INFO - 2018-03-24 18:52:35 --> Helper loaded: url_helper
INFO - 2018-03-24 18:52:35 --> Helper loaded: form_helper
INFO - 2018-03-24 18:52:35 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:52:35 --> Controller Class Initialized
INFO - 2018-03-24 18:52:35 --> Model Class Initialized
INFO - 2018-03-24 18:52:35 --> Model Class Initialized
INFO - 2018-03-24 18:52:35 --> Model Class Initialized
INFO - 2018-03-24 18:52:35 --> Model Class Initialized
INFO - 2018-03-24 18:52:35 --> Model Class Initialized
INFO - 2018-03-24 18:52:36 --> Model Class Initialized
INFO - 2018-03-24 18:52:36 --> Helper loaded: date_helper
INFO - 2018-03-24 18:52:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:53:37 --> Config Class Initialized
INFO - 2018-03-24 18:53:37 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:53:37 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:53:37 --> Utf8 Class Initialized
INFO - 2018-03-24 18:53:37 --> URI Class Initialized
INFO - 2018-03-24 18:53:37 --> Router Class Initialized
INFO - 2018-03-24 18:53:37 --> Output Class Initialized
INFO - 2018-03-24 18:53:37 --> Security Class Initialized
DEBUG - 2018-03-24 18:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:53:37 --> Input Class Initialized
INFO - 2018-03-24 18:53:37 --> Language Class Initialized
INFO - 2018-03-24 18:53:37 --> Loader Class Initialized
INFO - 2018-03-24 18:53:37 --> Helper loaded: url_helper
INFO - 2018-03-24 18:53:37 --> Helper loaded: form_helper
INFO - 2018-03-24 18:53:37 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:53:37 --> Controller Class Initialized
INFO - 2018-03-24 18:53:37 --> Model Class Initialized
INFO - 2018-03-24 18:53:37 --> Model Class Initialized
INFO - 2018-03-24 18:53:37 --> Model Class Initialized
INFO - 2018-03-24 18:53:37 --> Model Class Initialized
INFO - 2018-03-24 18:53:37 --> Model Class Initialized
INFO - 2018-03-24 18:53:37 --> Model Class Initialized
INFO - 2018-03-24 18:53:37 --> Helper loaded: date_helper
INFO - 2018-03-24 18:53:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:53:47 --> Config Class Initialized
INFO - 2018-03-24 18:53:47 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:53:47 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:53:47 --> Utf8 Class Initialized
INFO - 2018-03-24 18:53:47 --> URI Class Initialized
INFO - 2018-03-24 18:53:47 --> Router Class Initialized
INFO - 2018-03-24 18:53:47 --> Output Class Initialized
INFO - 2018-03-24 18:53:47 --> Security Class Initialized
DEBUG - 2018-03-24 18:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:53:47 --> Input Class Initialized
INFO - 2018-03-24 18:53:47 --> Language Class Initialized
INFO - 2018-03-24 18:53:47 --> Loader Class Initialized
INFO - 2018-03-24 18:53:47 --> Helper loaded: url_helper
INFO - 2018-03-24 18:53:47 --> Helper loaded: form_helper
INFO - 2018-03-24 18:53:47 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:53:47 --> Controller Class Initialized
INFO - 2018-03-24 18:53:47 --> Model Class Initialized
INFO - 2018-03-24 18:53:47 --> Model Class Initialized
INFO - 2018-03-24 18:53:47 --> Model Class Initialized
INFO - 2018-03-24 18:53:47 --> Model Class Initialized
INFO - 2018-03-24 18:53:47 --> Model Class Initialized
INFO - 2018-03-24 18:53:47 --> Model Class Initialized
INFO - 2018-03-24 18:53:47 --> Helper loaded: date_helper
INFO - 2018-03-24 18:53:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:54:52 --> Config Class Initialized
INFO - 2018-03-24 18:54:52 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:54:52 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:54:52 --> Utf8 Class Initialized
INFO - 2018-03-24 18:54:52 --> URI Class Initialized
INFO - 2018-03-24 18:54:52 --> Router Class Initialized
INFO - 2018-03-24 18:54:52 --> Output Class Initialized
INFO - 2018-03-24 18:54:52 --> Security Class Initialized
DEBUG - 2018-03-24 18:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:54:52 --> Input Class Initialized
INFO - 2018-03-24 18:54:52 --> Language Class Initialized
INFO - 2018-03-24 18:54:52 --> Loader Class Initialized
INFO - 2018-03-24 18:54:52 --> Helper loaded: url_helper
INFO - 2018-03-24 18:54:52 --> Helper loaded: form_helper
INFO - 2018-03-24 18:54:52 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:54:52 --> Controller Class Initialized
INFO - 2018-03-24 18:54:52 --> Model Class Initialized
INFO - 2018-03-24 18:54:52 --> Model Class Initialized
INFO - 2018-03-24 18:54:52 --> Model Class Initialized
INFO - 2018-03-24 18:54:52 --> Model Class Initialized
INFO - 2018-03-24 18:54:52 --> Model Class Initialized
INFO - 2018-03-24 18:54:52 --> Model Class Initialized
INFO - 2018-03-24 18:54:52 --> Helper loaded: date_helper
INFO - 2018-03-24 18:54:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:54:55 --> Config Class Initialized
INFO - 2018-03-24 18:54:55 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:54:55 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:54:55 --> Utf8 Class Initialized
INFO - 2018-03-24 18:54:55 --> URI Class Initialized
INFO - 2018-03-24 18:54:55 --> Router Class Initialized
INFO - 2018-03-24 18:54:55 --> Output Class Initialized
INFO - 2018-03-24 18:54:55 --> Security Class Initialized
DEBUG - 2018-03-24 18:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:54:55 --> Input Class Initialized
INFO - 2018-03-24 18:54:55 --> Language Class Initialized
INFO - 2018-03-24 18:54:55 --> Loader Class Initialized
INFO - 2018-03-24 18:54:55 --> Helper loaded: url_helper
INFO - 2018-03-24 18:54:55 --> Helper loaded: form_helper
INFO - 2018-03-24 18:54:55 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:54:55 --> Controller Class Initialized
INFO - 2018-03-24 18:54:55 --> Model Class Initialized
INFO - 2018-03-24 18:54:56 --> Model Class Initialized
INFO - 2018-03-24 18:54:56 --> Model Class Initialized
INFO - 2018-03-24 18:54:56 --> Model Class Initialized
INFO - 2018-03-24 18:54:56 --> Model Class Initialized
INFO - 2018-03-24 18:54:56 --> Model Class Initialized
INFO - 2018-03-24 18:54:56 --> Helper loaded: date_helper
INFO - 2018-03-24 18:54:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:54:57 --> Config Class Initialized
INFO - 2018-03-24 18:54:57 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:54:57 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:54:57 --> Utf8 Class Initialized
INFO - 2018-03-24 18:54:57 --> URI Class Initialized
INFO - 2018-03-24 18:54:57 --> Router Class Initialized
INFO - 2018-03-24 18:54:57 --> Output Class Initialized
INFO - 2018-03-24 18:54:57 --> Security Class Initialized
DEBUG - 2018-03-24 18:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:54:57 --> Input Class Initialized
INFO - 2018-03-24 18:54:57 --> Language Class Initialized
INFO - 2018-03-24 18:54:57 --> Loader Class Initialized
INFO - 2018-03-24 18:54:57 --> Helper loaded: url_helper
INFO - 2018-03-24 18:54:57 --> Helper loaded: form_helper
INFO - 2018-03-24 18:54:57 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:54:57 --> Controller Class Initialized
INFO - 2018-03-24 18:54:57 --> Model Class Initialized
INFO - 2018-03-24 18:54:57 --> Model Class Initialized
INFO - 2018-03-24 18:54:57 --> Model Class Initialized
INFO - 2018-03-24 18:54:57 --> Model Class Initialized
INFO - 2018-03-24 18:54:57 --> Model Class Initialized
INFO - 2018-03-24 18:54:57 --> Model Class Initialized
INFO - 2018-03-24 18:54:57 --> Helper loaded: date_helper
INFO - 2018-03-24 18:54:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:56:18 --> Config Class Initialized
INFO - 2018-03-24 18:56:18 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:56:18 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:56:18 --> Utf8 Class Initialized
INFO - 2018-03-24 18:56:18 --> URI Class Initialized
INFO - 2018-03-24 18:56:18 --> Router Class Initialized
INFO - 2018-03-24 18:56:18 --> Output Class Initialized
INFO - 2018-03-24 18:56:18 --> Security Class Initialized
DEBUG - 2018-03-24 18:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:56:18 --> Input Class Initialized
INFO - 2018-03-24 18:56:18 --> Language Class Initialized
INFO - 2018-03-24 18:56:18 --> Loader Class Initialized
INFO - 2018-03-24 18:56:18 --> Helper loaded: url_helper
INFO - 2018-03-24 18:56:18 --> Helper loaded: form_helper
INFO - 2018-03-24 18:56:18 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:56:18 --> Controller Class Initialized
INFO - 2018-03-24 18:56:18 --> Model Class Initialized
INFO - 2018-03-24 18:56:18 --> Model Class Initialized
INFO - 2018-03-24 18:56:18 --> Model Class Initialized
INFO - 2018-03-24 18:56:18 --> Model Class Initialized
INFO - 2018-03-24 18:56:18 --> Model Class Initialized
INFO - 2018-03-24 18:56:18 --> Model Class Initialized
INFO - 2018-03-24 18:56:18 --> Helper loaded: date_helper
INFO - 2018-03-24 18:56:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-24 18:57:08 --> Config Class Initialized
INFO - 2018-03-24 18:57:08 --> Hooks Class Initialized
DEBUG - 2018-03-24 18:57:08 --> UTF-8 Support Enabled
INFO - 2018-03-24 18:57:08 --> Utf8 Class Initialized
INFO - 2018-03-24 18:57:08 --> URI Class Initialized
INFO - 2018-03-24 18:57:08 --> Router Class Initialized
INFO - 2018-03-24 18:57:08 --> Output Class Initialized
INFO - 2018-03-24 18:57:08 --> Security Class Initialized
DEBUG - 2018-03-24 18:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-24 18:57:08 --> Input Class Initialized
INFO - 2018-03-24 18:57:08 --> Language Class Initialized
INFO - 2018-03-24 18:57:08 --> Loader Class Initialized
INFO - 2018-03-24 18:57:08 --> Helper loaded: url_helper
INFO - 2018-03-24 18:57:08 --> Helper loaded: form_helper
INFO - 2018-03-24 18:57:08 --> Database Driver Class Initialized
DEBUG - 2018-03-24 18:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-24 18:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-24 18:57:08 --> Controller Class Initialized
INFO - 2018-03-24 18:57:08 --> Model Class Initialized
INFO - 2018-03-24 18:57:08 --> Model Class Initialized
INFO - 2018-03-24 18:57:08 --> Model Class Initialized
INFO - 2018-03-24 18:57:08 --> Model Class Initialized
INFO - 2018-03-24 18:57:08 --> Model Class Initialized
INFO - 2018-03-24 18:57:08 --> Model Class Initialized
INFO - 2018-03-24 18:57:08 --> Helper loaded: date_helper
INFO - 2018-03-24 18:57:08 --> Helper loaded: tanggal_helper
