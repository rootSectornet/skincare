<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-25 00:33:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-25 00:33:16 --> Final output sent to browser
DEBUG - 2018-03-25 00:33:16 --> Total execution time: 0.0732
INFO - 2018-03-25 00:33:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:33:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:33:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-25 00:33:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:33:19 --> Final output sent to browser
DEBUG - 2018-03-25 00:33:19 --> Total execution time: 0.0989
INFO - 2018-03-25 00:33:23 --> Model Class Initialized
INFO - 2018-03-25 00:33:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:33:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:33:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:33:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:33:23 --> Final output sent to browser
DEBUG - 2018-03-25 00:33:23 --> Total execution time: 0.0981
INFO - 2018-03-25 00:34:22 --> Model Class Initialized
INFO - 2018-03-25 00:34:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:34:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:34:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:34:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:34:22 --> Final output sent to browser
DEBUG - 2018-03-25 00:34:22 --> Total execution time: 0.0933
INFO - 2018-03-25 00:34:59 --> Model Class Initialized
INFO - 2018-03-25 00:34:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:34:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:34:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:34:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:34:59 --> Final output sent to browser
DEBUG - 2018-03-25 00:34:59 --> Total execution time: 0.1042
INFO - 2018-03-25 00:35:20 --> Model Class Initialized
INFO - 2018-03-25 00:35:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:35:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:35:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:35:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:35:20 --> Final output sent to browser
DEBUG - 2018-03-25 00:35:20 --> Total execution time: 0.1068
INFO - 2018-03-25 00:36:12 --> Model Class Initialized
INFO - 2018-03-25 00:36:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:36:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:36:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:36:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:36:12 --> Final output sent to browser
DEBUG - 2018-03-25 00:36:12 --> Total execution time: 0.0949
INFO - 2018-03-25 00:37:02 --> Model Class Initialized
INFO - 2018-03-25 00:37:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:37:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:37:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:37:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:37:02 --> Final output sent to browser
DEBUG - 2018-03-25 00:37:02 --> Total execution time: 0.1055
INFO - 2018-03-25 00:38:11 --> Model Class Initialized
INFO - 2018-03-25 00:38:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:38:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:38:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:38:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:38:11 --> Final output sent to browser
DEBUG - 2018-03-25 00:38:11 --> Total execution time: 0.1495
INFO - 2018-03-25 00:39:47 --> Model Class Initialized
INFO - 2018-03-25 00:39:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:39:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:39:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:39:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:39:47 --> Final output sent to browser
DEBUG - 2018-03-25 00:39:47 --> Total execution time: 0.0978
INFO - 2018-03-25 00:40:05 --> Model Class Initialized
INFO - 2018-03-25 00:40:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:40:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:40:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:40:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:40:05 --> Final output sent to browser
DEBUG - 2018-03-25 00:40:05 --> Total execution time: 0.0991
INFO - 2018-03-25 00:40:25 --> Model Class Initialized
INFO - 2018-03-25 00:40:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:40:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:40:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:40:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:40:25 --> Final output sent to browser
DEBUG - 2018-03-25 00:40:25 --> Total execution time: 0.1401
INFO - 2018-03-25 00:41:02 --> Model Class Initialized
INFO - 2018-03-25 00:41:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:41:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:41:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:41:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:41:02 --> Final output sent to browser
DEBUG - 2018-03-25 00:41:02 --> Total execution time: 0.1031
INFO - 2018-03-25 00:41:17 --> Model Class Initialized
INFO - 2018-03-25 00:41:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:41:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:41:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:41:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:41:17 --> Final output sent to browser
DEBUG - 2018-03-25 00:41:17 --> Total execution time: 0.1191
INFO - 2018-03-25 00:42:12 --> Model Class Initialized
INFO - 2018-03-25 00:42:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:42:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:42:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:42:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:42:12 --> Final output sent to browser
DEBUG - 2018-03-25 00:42:12 --> Total execution time: 0.1036
INFO - 2018-03-25 00:43:01 --> Model Class Initialized
INFO - 2018-03-25 00:43:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:43:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:43:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:43:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:43:01 --> Final output sent to browser
DEBUG - 2018-03-25 00:43:01 --> Total execution time: 0.0899
INFO - 2018-03-25 00:43:07 --> Final output sent to browser
DEBUG - 2018-03-25 00:43:07 --> Total execution time: 0.2642
INFO - 2018-03-25 00:43:18 --> Model Class Initialized
INFO - 2018-03-25 00:43:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:43:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:43:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:43:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:43:18 --> Final output sent to browser
DEBUG - 2018-03-25 00:43:18 --> Total execution time: 0.1073
INFO - 2018-03-25 00:43:43 --> Model Class Initialized
INFO - 2018-03-25 00:43:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:43:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:43:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:43:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:43:43 --> Final output sent to browser
DEBUG - 2018-03-25 00:43:43 --> Total execution time: 0.1052
INFO - 2018-03-25 00:43:58 --> Model Class Initialized
INFO - 2018-03-25 00:43:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:43:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:43:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:43:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:43:58 --> Final output sent to browser
DEBUG - 2018-03-25 00:43:58 --> Total execution time: 0.1118
INFO - 2018-03-25 00:44:03 --> Final output sent to browser
DEBUG - 2018-03-25 00:44:03 --> Total execution time: 0.2591
INFO - 2018-03-25 00:44:07 --> Final output sent to browser
DEBUG - 2018-03-25 00:44:07 --> Total execution time: 0.2698
INFO - 2018-03-25 00:44:08 --> Final output sent to browser
DEBUG - 2018-03-25 00:44:08 --> Total execution time: 0.2258
INFO - 2018-03-25 00:44:08 --> Final output sent to browser
DEBUG - 2018-03-25 00:44:08 --> Total execution time: 0.1984
INFO - 2018-03-25 00:44:09 --> Final output sent to browser
DEBUG - 2018-03-25 00:44:09 --> Total execution time: 0.3448
INFO - 2018-03-25 00:44:09 --> Final output sent to browser
DEBUG - 2018-03-25 00:44:09 --> Total execution time: 0.1976
INFO - 2018-03-25 00:44:20 --> Model Class Initialized
INFO - 2018-03-25 00:44:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:44:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:44:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:44:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:44:20 --> Final output sent to browser
DEBUG - 2018-03-25 00:44:20 --> Total execution time: 0.1768
INFO - 2018-03-25 00:44:59 --> Model Class Initialized
INFO - 2018-03-25 00:44:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:44:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:44:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:44:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:44:59 --> Final output sent to browser
DEBUG - 2018-03-25 00:44:59 --> Total execution time: 0.1119
INFO - 2018-03-25 00:45:14 --> Final output sent to browser
DEBUG - 2018-03-25 00:45:14 --> Total execution time: 0.0754
INFO - 2018-03-25 00:45:16 --> Final output sent to browser
DEBUG - 2018-03-25 00:45:16 --> Total execution time: 0.1853
INFO - 2018-03-25 00:45:27 --> Model Class Initialized
INFO - 2018-03-25 00:45:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:45:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:45:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:45:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:45:27 --> Final output sent to browser
DEBUG - 2018-03-25 00:45:27 --> Total execution time: 0.1108
INFO - 2018-03-25 00:45:40 --> Model Class Initialized
INFO - 2018-03-25 00:45:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:45:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:45:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-25 00:45:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:45:40 --> Final output sent to browser
DEBUG - 2018-03-25 00:45:40 --> Total execution time: 0.1212
INFO - 2018-03-25 00:45:57 --> Model Class Initialized
INFO - 2018-03-25 00:45:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:45:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:45:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/create.php
INFO - 2018-03-25 00:45:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:45:57 --> Final output sent to browser
DEBUG - 2018-03-25 00:45:57 --> Total execution time: 0.1496
INFO - 2018-03-25 00:46:07 --> Final output sent to browser
DEBUG - 2018-03-25 00:46:07 --> Total execution time: 0.0680
INFO - 2018-03-25 00:46:14 --> Final output sent to browser
DEBUG - 2018-03-25 00:46:14 --> Total execution time: 0.0724
ERROR - 2018-03-25 00:46:19 --> Query error: Duplicate entry 'FP00001' for key 'PRIMARY' - Invalid query: INSERT INTO `penjualan` (`faktur_penjualan`, `tgl_penjualan`, `cara_bayar`, `total`, `id_mst_pegawai`) VALUES ('FP00001', '2018-03-25', 'Tunai', 799998, '1')
DEBUG - 2018-03-25 00:46:19 --> DB Transaction Failure
INFO - 2018-03-25 00:46:20 --> Model Class Initialized
INFO - 2018-03-25 00:46:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:46:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:46:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-25 00:46:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:46:20 --> Final output sent to browser
DEBUG - 2018-03-25 00:46:20 --> Total execution time: 0.4027
INFO - 2018-03-25 00:46:41 --> Model Class Initialized
INFO - 2018-03-25 00:46:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:46:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:46:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/create.php
INFO - 2018-03-25 00:46:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:46:41 --> Final output sent to browser
DEBUG - 2018-03-25 00:46:41 --> Total execution time: 0.0984
INFO - 2018-03-25 00:47:24 --> Model Class Initialized
INFO - 2018-03-25 00:47:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:47:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:47:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/create.php
INFO - 2018-03-25 00:47:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:47:24 --> Final output sent to browser
DEBUG - 2018-03-25 00:47:24 --> Total execution time: 0.1065
INFO - 2018-03-25 00:47:34 --> Final output sent to browser
DEBUG - 2018-03-25 00:47:34 --> Total execution time: 0.0749
INFO - 2018-03-25 00:47:38 --> Final output sent to browser
DEBUG - 2018-03-25 00:47:38 --> Total execution time: 0.0593
INFO - 2018-03-25 00:47:44 --> Model Class Initialized
INFO - 2018-03-25 00:47:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:47:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:47:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:47:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:47:44 --> Final output sent to browser
DEBUG - 2018-03-25 00:47:44 --> Total execution time: 0.1148
INFO - 2018-03-25 00:50:26 --> Model Class Initialized
INFO - 2018-03-25 00:50:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:50:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:50:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:50:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:50:26 --> Final output sent to browser
DEBUG - 2018-03-25 00:50:26 --> Total execution time: 0.0807
INFO - 2018-03-25 00:51:12 --> Model Class Initialized
INFO - 2018-03-25 00:51:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:51:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:51:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:51:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:51:12 --> Final output sent to browser
DEBUG - 2018-03-25 00:51:12 --> Total execution time: 0.0911
INFO - 2018-03-25 00:52:15 --> Model Class Initialized
INFO - 2018-03-25 00:52:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:52:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:52:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:52:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:52:15 --> Final output sent to browser
DEBUG - 2018-03-25 00:52:15 --> Total execution time: 0.0908
INFO - 2018-03-25 00:52:36 --> Model Class Initialized
INFO - 2018-03-25 00:52:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:52:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:52:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:52:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:52:36 --> Final output sent to browser
DEBUG - 2018-03-25 00:52:36 --> Total execution time: 0.0920
INFO - 2018-03-25 00:53:37 --> Model Class Initialized
INFO - 2018-03-25 00:53:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:53:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:53:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:53:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:53:37 --> Final output sent to browser
DEBUG - 2018-03-25 00:53:37 --> Total execution time: 0.1058
INFO - 2018-03-25 00:53:47 --> Model Class Initialized
INFO - 2018-03-25 00:53:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:53:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:53:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:53:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:53:47 --> Final output sent to browser
DEBUG - 2018-03-25 00:53:47 --> Total execution time: 0.0994
INFO - 2018-03-25 00:54:52 --> Model Class Initialized
INFO - 2018-03-25 00:54:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:54:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:54:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-25 00:54:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:54:52 --> Final output sent to browser
DEBUG - 2018-03-25 00:54:52 --> Total execution time: 0.0760
INFO - 2018-03-25 00:54:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-25 00:54:56 --> Final output sent to browser
DEBUG - 2018-03-25 00:54:56 --> Total execution time: 0.0855
INFO - 2018-03-25 00:54:57 --> Model Class Initialized
INFO - 2018-03-25 00:54:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:54:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:54:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:54:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:54:57 --> Final output sent to browser
DEBUG - 2018-03-25 00:54:57 --> Total execution time: 0.0774
INFO - 2018-03-25 00:56:18 --> Model Class Initialized
INFO - 2018-03-25 00:56:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:56:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:56:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:56:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:56:18 --> Final output sent to browser
DEBUG - 2018-03-25 00:56:18 --> Total execution time: 0.0834
INFO - 2018-03-25 00:57:08 --> Model Class Initialized
INFO - 2018-03-25 00:57:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 00:57:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 00:57:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 00:57:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 00:57:08 --> Final output sent to browser
DEBUG - 2018-03-25 00:57:08 --> Total execution time: 0.0871
INFO - 2018-03-25 06:23:13 --> Config Class Initialized
INFO - 2018-03-25 06:23:13 --> Hooks Class Initialized
DEBUG - 2018-03-25 06:23:13 --> UTF-8 Support Enabled
INFO - 2018-03-25 06:23:13 --> Utf8 Class Initialized
INFO - 2018-03-25 06:23:13 --> URI Class Initialized
INFO - 2018-03-25 06:23:13 --> Router Class Initialized
INFO - 2018-03-25 06:23:13 --> Output Class Initialized
INFO - 2018-03-25 06:23:13 --> Security Class Initialized
DEBUG - 2018-03-25 06:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 06:23:13 --> Input Class Initialized
INFO - 2018-03-25 06:23:13 --> Language Class Initialized
INFO - 2018-03-25 06:23:13 --> Loader Class Initialized
INFO - 2018-03-25 06:23:13 --> Helper loaded: url_helper
INFO - 2018-03-25 06:23:13 --> Helper loaded: form_helper
INFO - 2018-03-25 06:23:13 --> Database Driver Class Initialized
DEBUG - 2018-03-25 06:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 06:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 06:23:13 --> Controller Class Initialized
INFO - 2018-03-25 06:23:13 --> Config Class Initialized
INFO - 2018-03-25 06:23:13 --> Hooks Class Initialized
DEBUG - 2018-03-25 06:23:13 --> UTF-8 Support Enabled
INFO - 2018-03-25 06:23:13 --> Utf8 Class Initialized
INFO - 2018-03-25 06:23:13 --> URI Class Initialized
INFO - 2018-03-25 06:23:13 --> Router Class Initialized
INFO - 2018-03-25 06:23:13 --> Output Class Initialized
INFO - 2018-03-25 06:23:13 --> Security Class Initialized
DEBUG - 2018-03-25 06:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 06:23:13 --> Input Class Initialized
INFO - 2018-03-25 06:23:13 --> Language Class Initialized
INFO - 2018-03-25 06:23:13 --> Loader Class Initialized
INFO - 2018-03-25 06:23:13 --> Helper loaded: url_helper
INFO - 2018-03-25 06:23:13 --> Helper loaded: form_helper
INFO - 2018-03-25 06:23:13 --> Database Driver Class Initialized
DEBUG - 2018-03-25 06:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 06:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 06:23:13 --> Controller Class Initialized
INFO - 2018-03-25 06:23:13 --> Model Class Initialized
INFO - 2018-03-25 06:23:13 --> Model Class Initialized
INFO - 2018-03-25 06:23:13 --> Model Class Initialized
INFO - 2018-03-25 06:23:13 --> Helper loaded: date_helper
INFO - 2018-03-25 11:23:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-25 11:23:13 --> Final output sent to browser
DEBUG - 2018-03-25 11:23:13 --> Total execution time: 0.1333
INFO - 2018-03-25 06:23:46 --> Config Class Initialized
INFO - 2018-03-25 06:23:46 --> Hooks Class Initialized
DEBUG - 2018-03-25 06:23:46 --> UTF-8 Support Enabled
INFO - 2018-03-25 06:23:46 --> Utf8 Class Initialized
INFO - 2018-03-25 06:23:46 --> URI Class Initialized
INFO - 2018-03-25 06:23:46 --> Router Class Initialized
INFO - 2018-03-25 06:23:46 --> Output Class Initialized
INFO - 2018-03-25 06:23:46 --> Security Class Initialized
DEBUG - 2018-03-25 06:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 06:23:46 --> Input Class Initialized
INFO - 2018-03-25 06:23:46 --> Language Class Initialized
INFO - 2018-03-25 06:23:46 --> Loader Class Initialized
INFO - 2018-03-25 06:23:46 --> Helper loaded: url_helper
INFO - 2018-03-25 06:23:46 --> Helper loaded: form_helper
INFO - 2018-03-25 06:23:46 --> Database Driver Class Initialized
DEBUG - 2018-03-25 06:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 06:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 06:23:46 --> Controller Class Initialized
INFO - 2018-03-25 06:23:46 --> Model Class Initialized
INFO - 2018-03-25 06:23:46 --> Model Class Initialized
INFO - 2018-03-25 06:23:46 --> Model Class Initialized
INFO - 2018-03-25 06:23:46 --> Helper loaded: date_helper
INFO - 2018-03-25 06:23:47 --> Config Class Initialized
INFO - 2018-03-25 06:23:47 --> Hooks Class Initialized
DEBUG - 2018-03-25 06:23:47 --> UTF-8 Support Enabled
INFO - 2018-03-25 06:23:47 --> Utf8 Class Initialized
INFO - 2018-03-25 06:23:47 --> URI Class Initialized
INFO - 2018-03-25 06:23:47 --> Router Class Initialized
INFO - 2018-03-25 06:23:47 --> Output Class Initialized
INFO - 2018-03-25 06:23:47 --> Security Class Initialized
DEBUG - 2018-03-25 06:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 06:23:47 --> Input Class Initialized
INFO - 2018-03-25 06:23:47 --> Language Class Initialized
INFO - 2018-03-25 06:23:47 --> Loader Class Initialized
INFO - 2018-03-25 06:23:47 --> Helper loaded: url_helper
INFO - 2018-03-25 06:23:47 --> Helper loaded: form_helper
INFO - 2018-03-25 06:23:47 --> Database Driver Class Initialized
DEBUG - 2018-03-25 06:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 06:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 06:23:47 --> Controller Class Initialized
INFO - 2018-03-25 06:23:47 --> Model Class Initialized
INFO - 2018-03-25 06:23:47 --> Model Class Initialized
INFO - 2018-03-25 06:23:47 --> Model Class Initialized
INFO - 2018-03-25 06:23:47 --> Model Class Initialized
INFO - 2018-03-25 06:23:47 --> Model Class Initialized
INFO - 2018-03-25 06:23:47 --> Helper loaded: date_helper
INFO - 2018-03-25 11:23:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 11:23:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 11:23:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-25 11:23:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 11:23:47 --> Final output sent to browser
DEBUG - 2018-03-25 11:23:47 --> Total execution time: 0.5549
INFO - 2018-03-25 06:23:56 --> Config Class Initialized
INFO - 2018-03-25 06:23:56 --> Hooks Class Initialized
DEBUG - 2018-03-25 06:23:56 --> UTF-8 Support Enabled
INFO - 2018-03-25 06:23:56 --> Utf8 Class Initialized
INFO - 2018-03-25 06:23:56 --> URI Class Initialized
INFO - 2018-03-25 06:23:56 --> Router Class Initialized
INFO - 2018-03-25 06:23:56 --> Output Class Initialized
INFO - 2018-03-25 06:23:56 --> Security Class Initialized
DEBUG - 2018-03-25 06:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 06:23:56 --> Input Class Initialized
INFO - 2018-03-25 06:23:56 --> Language Class Initialized
INFO - 2018-03-25 06:23:56 --> Loader Class Initialized
INFO - 2018-03-25 06:23:56 --> Helper loaded: url_helper
INFO - 2018-03-25 06:23:56 --> Helper loaded: form_helper
INFO - 2018-03-25 06:23:56 --> Database Driver Class Initialized
DEBUG - 2018-03-25 06:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 06:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 06:23:56 --> Controller Class Initialized
INFO - 2018-03-25 06:23:56 --> Model Class Initialized
INFO - 2018-03-25 06:23:56 --> Model Class Initialized
INFO - 2018-03-25 06:23:56 --> Model Class Initialized
INFO - 2018-03-25 06:23:56 --> Model Class Initialized
INFO - 2018-03-25 06:23:56 --> Model Class Initialized
INFO - 2018-03-25 06:23:56 --> Model Class Initialized
INFO - 2018-03-25 06:23:56 --> Helper loaded: date_helper
INFO - 2018-03-25 06:23:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 11:23:56 --> Model Class Initialized
INFO - 2018-03-25 11:23:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 11:23:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 11:23:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-25 11:23:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 11:23:56 --> Final output sent to browser
DEBUG - 2018-03-25 11:23:56 --> Total execution time: 0.2097
INFO - 2018-03-25 06:23:58 --> Config Class Initialized
INFO - 2018-03-25 06:23:58 --> Hooks Class Initialized
DEBUG - 2018-03-25 06:23:59 --> UTF-8 Support Enabled
INFO - 2018-03-25 06:23:59 --> Utf8 Class Initialized
INFO - 2018-03-25 06:23:59 --> URI Class Initialized
INFO - 2018-03-25 06:23:59 --> Router Class Initialized
INFO - 2018-03-25 06:23:59 --> Output Class Initialized
INFO - 2018-03-25 06:23:59 --> Security Class Initialized
DEBUG - 2018-03-25 06:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 06:23:59 --> Input Class Initialized
INFO - 2018-03-25 06:23:59 --> Language Class Initialized
INFO - 2018-03-25 06:23:59 --> Loader Class Initialized
INFO - 2018-03-25 06:23:59 --> Helper loaded: url_helper
INFO - 2018-03-25 06:23:59 --> Helper loaded: form_helper
INFO - 2018-03-25 06:23:59 --> Database Driver Class Initialized
DEBUG - 2018-03-25 06:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 06:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 06:23:59 --> Controller Class Initialized
INFO - 2018-03-25 06:23:59 --> Model Class Initialized
INFO - 2018-03-25 06:23:59 --> Model Class Initialized
INFO - 2018-03-25 06:23:59 --> Model Class Initialized
INFO - 2018-03-25 06:23:59 --> Model Class Initialized
INFO - 2018-03-25 06:23:59 --> Model Class Initialized
INFO - 2018-03-25 06:23:59 --> Model Class Initialized
INFO - 2018-03-25 06:23:59 --> Helper loaded: date_helper
INFO - 2018-03-25 06:23:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 11:23:59 --> Model Class Initialized
INFO - 2018-03-25 11:23:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 11:23:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 11:23:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 11:23:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 11:23:59 --> Final output sent to browser
DEBUG - 2018-03-25 11:23:59 --> Total execution time: 0.5559
INFO - 2018-03-25 06:27:28 --> Config Class Initialized
INFO - 2018-03-25 06:27:28 --> Hooks Class Initialized
DEBUG - 2018-03-25 06:27:28 --> UTF-8 Support Enabled
INFO - 2018-03-25 06:27:28 --> Utf8 Class Initialized
INFO - 2018-03-25 06:27:28 --> URI Class Initialized
INFO - 2018-03-25 06:27:28 --> Router Class Initialized
INFO - 2018-03-25 06:27:28 --> Output Class Initialized
INFO - 2018-03-25 06:27:28 --> Security Class Initialized
DEBUG - 2018-03-25 06:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 06:27:28 --> Input Class Initialized
INFO - 2018-03-25 06:27:28 --> Language Class Initialized
INFO - 2018-03-25 06:27:28 --> Loader Class Initialized
INFO - 2018-03-25 06:27:28 --> Helper loaded: url_helper
INFO - 2018-03-25 06:27:28 --> Helper loaded: form_helper
INFO - 2018-03-25 06:27:28 --> Database Driver Class Initialized
DEBUG - 2018-03-25 06:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 06:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 06:27:28 --> Controller Class Initialized
INFO - 2018-03-25 06:27:28 --> Model Class Initialized
INFO - 2018-03-25 06:27:28 --> Model Class Initialized
INFO - 2018-03-25 06:27:28 --> Model Class Initialized
INFO - 2018-03-25 06:27:28 --> Model Class Initialized
INFO - 2018-03-25 06:27:28 --> Model Class Initialized
INFO - 2018-03-25 06:27:28 --> Model Class Initialized
INFO - 2018-03-25 06:27:28 --> Helper loaded: date_helper
INFO - 2018-03-25 06:27:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 11:27:28 --> Model Class Initialized
INFO - 2018-03-25 11:27:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 11:27:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 11:27:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 11:27:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 11:27:28 --> Final output sent to browser
DEBUG - 2018-03-25 11:27:28 --> Total execution time: 0.0805
INFO - 2018-03-25 07:07:12 --> Config Class Initialized
INFO - 2018-03-25 07:07:12 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:07:12 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:07:12 --> Utf8 Class Initialized
INFO - 2018-03-25 07:07:12 --> URI Class Initialized
INFO - 2018-03-25 07:07:12 --> Router Class Initialized
INFO - 2018-03-25 07:07:12 --> Output Class Initialized
INFO - 2018-03-25 07:07:12 --> Security Class Initialized
DEBUG - 2018-03-25 07:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:07:12 --> Input Class Initialized
INFO - 2018-03-25 07:07:12 --> Language Class Initialized
INFO - 2018-03-25 07:07:12 --> Loader Class Initialized
INFO - 2018-03-25 07:07:12 --> Helper loaded: url_helper
INFO - 2018-03-25 07:07:12 --> Helper loaded: form_helper
INFO - 2018-03-25 07:07:12 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:07:12 --> Controller Class Initialized
INFO - 2018-03-25 07:07:12 --> Model Class Initialized
INFO - 2018-03-25 07:07:12 --> Model Class Initialized
INFO - 2018-03-25 07:07:12 --> Model Class Initialized
INFO - 2018-03-25 07:07:12 --> Model Class Initialized
INFO - 2018-03-25 07:07:12 --> Model Class Initialized
INFO - 2018-03-25 07:07:12 --> Model Class Initialized
INFO - 2018-03-25 07:07:12 --> Helper loaded: date_helper
INFO - 2018-03-25 07:07:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:07:12 --> Model Class Initialized
INFO - 2018-03-25 12:07:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 12:07:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 12:07:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 12:07:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 12:07:12 --> Final output sent to browser
DEBUG - 2018-03-25 12:07:12 --> Total execution time: 0.1127
INFO - 2018-03-25 07:07:36 --> Config Class Initialized
INFO - 2018-03-25 07:07:36 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:07:36 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:07:36 --> Utf8 Class Initialized
INFO - 2018-03-25 07:07:36 --> URI Class Initialized
INFO - 2018-03-25 07:07:36 --> Router Class Initialized
INFO - 2018-03-25 07:07:36 --> Output Class Initialized
INFO - 2018-03-25 07:07:36 --> Security Class Initialized
DEBUG - 2018-03-25 07:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:07:36 --> Input Class Initialized
INFO - 2018-03-25 07:07:36 --> Language Class Initialized
INFO - 2018-03-25 07:07:36 --> Loader Class Initialized
INFO - 2018-03-25 07:07:36 --> Helper loaded: url_helper
INFO - 2018-03-25 07:07:36 --> Helper loaded: form_helper
INFO - 2018-03-25 07:07:36 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:07:36 --> Controller Class Initialized
INFO - 2018-03-25 07:07:36 --> Model Class Initialized
INFO - 2018-03-25 07:07:36 --> Model Class Initialized
INFO - 2018-03-25 07:07:36 --> Model Class Initialized
INFO - 2018-03-25 07:07:36 --> Model Class Initialized
INFO - 2018-03-25 07:07:36 --> Model Class Initialized
INFO - 2018-03-25 07:07:36 --> Model Class Initialized
INFO - 2018-03-25 07:07:36 --> Helper loaded: date_helper
INFO - 2018-03-25 07:07:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:07:36 --> Model Class Initialized
INFO - 2018-03-25 12:07:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 12:07:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 12:07:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 12:07:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 12:07:36 --> Final output sent to browser
DEBUG - 2018-03-25 12:07:36 --> Total execution time: 0.1158
INFO - 2018-03-25 07:07:43 --> Config Class Initialized
INFO - 2018-03-25 07:07:43 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:07:43 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:07:43 --> Utf8 Class Initialized
INFO - 2018-03-25 07:07:43 --> URI Class Initialized
INFO - 2018-03-25 07:07:43 --> Router Class Initialized
INFO - 2018-03-25 07:07:43 --> Output Class Initialized
INFO - 2018-03-25 07:07:43 --> Security Class Initialized
DEBUG - 2018-03-25 07:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:07:43 --> Input Class Initialized
INFO - 2018-03-25 07:07:43 --> Language Class Initialized
INFO - 2018-03-25 07:07:43 --> Loader Class Initialized
INFO - 2018-03-25 07:07:43 --> Helper loaded: url_helper
INFO - 2018-03-25 07:07:43 --> Helper loaded: form_helper
INFO - 2018-03-25 07:07:43 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:07:43 --> Controller Class Initialized
INFO - 2018-03-25 07:07:43 --> Model Class Initialized
INFO - 2018-03-25 07:07:43 --> Model Class Initialized
INFO - 2018-03-25 07:07:43 --> Helper loaded: date_helper
INFO - 2018-03-25 07:07:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:07:43 --> Final output sent to browser
DEBUG - 2018-03-25 12:07:43 --> Total execution time: 0.0777
INFO - 2018-03-25 07:07:53 --> Config Class Initialized
INFO - 2018-03-25 07:07:53 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:07:53 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:07:53 --> Utf8 Class Initialized
INFO - 2018-03-25 07:07:53 --> URI Class Initialized
INFO - 2018-03-25 07:07:53 --> Router Class Initialized
INFO - 2018-03-25 07:07:53 --> Output Class Initialized
INFO - 2018-03-25 07:07:53 --> Security Class Initialized
DEBUG - 2018-03-25 07:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:07:53 --> Input Class Initialized
INFO - 2018-03-25 07:07:53 --> Language Class Initialized
INFO - 2018-03-25 07:07:53 --> Loader Class Initialized
INFO - 2018-03-25 07:07:53 --> Helper loaded: url_helper
INFO - 2018-03-25 07:07:53 --> Helper loaded: form_helper
INFO - 2018-03-25 07:07:53 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:07:53 --> Controller Class Initialized
INFO - 2018-03-25 07:07:53 --> Model Class Initialized
INFO - 2018-03-25 07:07:53 --> Model Class Initialized
INFO - 2018-03-25 07:07:53 --> Model Class Initialized
INFO - 2018-03-25 07:07:53 --> Model Class Initialized
INFO - 2018-03-25 07:07:53 --> Model Class Initialized
INFO - 2018-03-25 07:07:53 --> Model Class Initialized
INFO - 2018-03-25 07:07:53 --> Helper loaded: date_helper
INFO - 2018-03-25 07:07:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:07:53 --> Final output sent to browser
DEBUG - 2018-03-25 12:07:53 --> Total execution time: 0.1315
INFO - 2018-03-25 07:08:38 --> Config Class Initialized
INFO - 2018-03-25 07:08:38 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:08:38 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:08:38 --> Utf8 Class Initialized
INFO - 2018-03-25 07:08:38 --> URI Class Initialized
INFO - 2018-03-25 07:08:38 --> Router Class Initialized
INFO - 2018-03-25 07:08:39 --> Output Class Initialized
INFO - 2018-03-25 07:08:39 --> Security Class Initialized
DEBUG - 2018-03-25 07:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:08:39 --> Input Class Initialized
INFO - 2018-03-25 07:08:39 --> Language Class Initialized
INFO - 2018-03-25 07:08:39 --> Loader Class Initialized
INFO - 2018-03-25 07:08:39 --> Helper loaded: url_helper
INFO - 2018-03-25 07:08:39 --> Helper loaded: form_helper
INFO - 2018-03-25 07:08:39 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:08:39 --> Controller Class Initialized
INFO - 2018-03-25 07:08:39 --> Model Class Initialized
INFO - 2018-03-25 07:08:39 --> Model Class Initialized
INFO - 2018-03-25 07:08:39 --> Model Class Initialized
INFO - 2018-03-25 07:08:39 --> Model Class Initialized
INFO - 2018-03-25 07:08:39 --> Model Class Initialized
INFO - 2018-03-25 07:08:39 --> Model Class Initialized
INFO - 2018-03-25 07:08:39 --> Helper loaded: date_helper
INFO - 2018-03-25 07:08:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:08:39 --> Model Class Initialized
INFO - 2018-03-25 12:08:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 12:08:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 12:08:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 12:08:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 12:08:39 --> Final output sent to browser
DEBUG - 2018-03-25 12:08:39 --> Total execution time: 0.1080
INFO - 2018-03-25 07:08:46 --> Config Class Initialized
INFO - 2018-03-25 07:08:46 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:08:46 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:08:46 --> Utf8 Class Initialized
INFO - 2018-03-25 07:08:46 --> URI Class Initialized
INFO - 2018-03-25 07:08:47 --> Router Class Initialized
INFO - 2018-03-25 07:08:47 --> Output Class Initialized
INFO - 2018-03-25 07:08:47 --> Security Class Initialized
DEBUG - 2018-03-25 07:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:08:47 --> Input Class Initialized
INFO - 2018-03-25 07:08:47 --> Language Class Initialized
INFO - 2018-03-25 07:08:47 --> Loader Class Initialized
INFO - 2018-03-25 07:08:47 --> Helper loaded: url_helper
INFO - 2018-03-25 07:08:47 --> Helper loaded: form_helper
INFO - 2018-03-25 07:08:47 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:08:47 --> Controller Class Initialized
INFO - 2018-03-25 07:08:47 --> Model Class Initialized
INFO - 2018-03-25 07:08:47 --> Model Class Initialized
INFO - 2018-03-25 07:08:47 --> Helper loaded: date_helper
INFO - 2018-03-25 07:08:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:08:47 --> Final output sent to browser
DEBUG - 2018-03-25 12:08:47 --> Total execution time: 0.1111
INFO - 2018-03-25 07:08:54 --> Config Class Initialized
INFO - 2018-03-25 07:08:54 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:08:54 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:08:54 --> Utf8 Class Initialized
INFO - 2018-03-25 07:08:54 --> URI Class Initialized
INFO - 2018-03-25 07:08:54 --> Router Class Initialized
INFO - 2018-03-25 07:08:54 --> Output Class Initialized
INFO - 2018-03-25 07:08:54 --> Security Class Initialized
DEBUG - 2018-03-25 07:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:08:54 --> Input Class Initialized
INFO - 2018-03-25 07:08:54 --> Language Class Initialized
INFO - 2018-03-25 07:08:54 --> Loader Class Initialized
INFO - 2018-03-25 07:08:54 --> Helper loaded: url_helper
INFO - 2018-03-25 07:08:54 --> Helper loaded: form_helper
INFO - 2018-03-25 07:08:54 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:08:54 --> Controller Class Initialized
INFO - 2018-03-25 07:08:54 --> Model Class Initialized
INFO - 2018-03-25 07:08:54 --> Model Class Initialized
INFO - 2018-03-25 07:08:54 --> Model Class Initialized
INFO - 2018-03-25 07:08:54 --> Model Class Initialized
INFO - 2018-03-25 07:08:54 --> Model Class Initialized
INFO - 2018-03-25 07:08:54 --> Model Class Initialized
INFO - 2018-03-25 07:08:54 --> Helper loaded: date_helper
INFO - 2018-03-25 07:08:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:08:54 --> Final output sent to browser
DEBUG - 2018-03-25 12:08:54 --> Total execution time: 0.0838
INFO - 2018-03-25 07:09:44 --> Config Class Initialized
INFO - 2018-03-25 07:09:44 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:09:44 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:09:44 --> Utf8 Class Initialized
INFO - 2018-03-25 07:09:44 --> URI Class Initialized
INFO - 2018-03-25 07:09:44 --> Router Class Initialized
INFO - 2018-03-25 07:09:44 --> Output Class Initialized
INFO - 2018-03-25 07:09:44 --> Security Class Initialized
DEBUG - 2018-03-25 07:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:09:44 --> Input Class Initialized
INFO - 2018-03-25 07:09:44 --> Language Class Initialized
INFO - 2018-03-25 07:09:44 --> Loader Class Initialized
INFO - 2018-03-25 07:09:44 --> Helper loaded: url_helper
INFO - 2018-03-25 07:09:44 --> Helper loaded: form_helper
INFO - 2018-03-25 07:09:44 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:09:44 --> Controller Class Initialized
INFO - 2018-03-25 07:09:44 --> Model Class Initialized
INFO - 2018-03-25 07:09:44 --> Model Class Initialized
INFO - 2018-03-25 07:09:44 --> Model Class Initialized
INFO - 2018-03-25 07:09:44 --> Model Class Initialized
INFO - 2018-03-25 07:09:44 --> Model Class Initialized
INFO - 2018-03-25 07:09:44 --> Model Class Initialized
INFO - 2018-03-25 07:09:44 --> Helper loaded: date_helper
INFO - 2018-03-25 07:09:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:09:44 --> Final output sent to browser
DEBUG - 2018-03-25 12:09:44 --> Total execution time: 0.1127
INFO - 2018-03-25 07:13:12 --> Config Class Initialized
INFO - 2018-03-25 07:13:12 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:13:12 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:13:12 --> Utf8 Class Initialized
INFO - 2018-03-25 07:13:12 --> URI Class Initialized
INFO - 2018-03-25 07:13:12 --> Router Class Initialized
INFO - 2018-03-25 07:13:12 --> Output Class Initialized
INFO - 2018-03-25 07:13:12 --> Security Class Initialized
DEBUG - 2018-03-25 07:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:13:12 --> Input Class Initialized
INFO - 2018-03-25 07:13:12 --> Language Class Initialized
INFO - 2018-03-25 07:13:12 --> Loader Class Initialized
INFO - 2018-03-25 07:13:12 --> Helper loaded: url_helper
INFO - 2018-03-25 07:13:12 --> Helper loaded: form_helper
INFO - 2018-03-25 07:13:12 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:13:12 --> Controller Class Initialized
INFO - 2018-03-25 07:13:12 --> Model Class Initialized
INFO - 2018-03-25 07:13:12 --> Model Class Initialized
INFO - 2018-03-25 07:13:12 --> Model Class Initialized
INFO - 2018-03-25 07:13:12 --> Model Class Initialized
INFO - 2018-03-25 07:13:12 --> Model Class Initialized
INFO - 2018-03-25 07:13:12 --> Model Class Initialized
INFO - 2018-03-25 07:13:12 --> Helper loaded: date_helper
INFO - 2018-03-25 07:13:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:13:12 --> Model Class Initialized
INFO - 2018-03-25 12:13:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 12:13:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 12:13:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 12:13:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 12:13:12 --> Final output sent to browser
DEBUG - 2018-03-25 12:13:12 --> Total execution time: 0.1108
INFO - 2018-03-25 07:13:22 --> Config Class Initialized
INFO - 2018-03-25 07:13:22 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:13:22 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:13:22 --> Utf8 Class Initialized
INFO - 2018-03-25 07:13:22 --> URI Class Initialized
INFO - 2018-03-25 07:13:22 --> Router Class Initialized
INFO - 2018-03-25 07:13:22 --> Output Class Initialized
INFO - 2018-03-25 07:13:22 --> Security Class Initialized
DEBUG - 2018-03-25 07:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:13:22 --> Input Class Initialized
INFO - 2018-03-25 07:13:22 --> Language Class Initialized
INFO - 2018-03-25 07:13:22 --> Loader Class Initialized
INFO - 2018-03-25 07:13:22 --> Helper loaded: url_helper
INFO - 2018-03-25 07:13:22 --> Helper loaded: form_helper
INFO - 2018-03-25 07:13:22 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:13:22 --> Controller Class Initialized
INFO - 2018-03-25 07:13:22 --> Model Class Initialized
INFO - 2018-03-25 07:13:22 --> Model Class Initialized
INFO - 2018-03-25 07:13:22 --> Helper loaded: date_helper
INFO - 2018-03-25 07:13:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:13:22 --> Final output sent to browser
DEBUG - 2018-03-25 12:13:22 --> Total execution time: 0.0961
INFO - 2018-03-25 07:13:30 --> Config Class Initialized
INFO - 2018-03-25 07:13:30 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:13:30 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:13:30 --> Utf8 Class Initialized
INFO - 2018-03-25 07:13:30 --> URI Class Initialized
INFO - 2018-03-25 07:13:30 --> Router Class Initialized
INFO - 2018-03-25 07:13:30 --> Output Class Initialized
INFO - 2018-03-25 07:13:30 --> Security Class Initialized
DEBUG - 2018-03-25 07:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:13:30 --> Input Class Initialized
INFO - 2018-03-25 07:13:30 --> Language Class Initialized
INFO - 2018-03-25 07:13:30 --> Loader Class Initialized
INFO - 2018-03-25 07:13:30 --> Helper loaded: url_helper
INFO - 2018-03-25 07:13:30 --> Helper loaded: form_helper
INFO - 2018-03-25 07:13:30 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:13:30 --> Controller Class Initialized
INFO - 2018-03-25 07:13:30 --> Model Class Initialized
INFO - 2018-03-25 07:13:30 --> Model Class Initialized
INFO - 2018-03-25 07:13:30 --> Model Class Initialized
INFO - 2018-03-25 07:13:30 --> Model Class Initialized
INFO - 2018-03-25 07:13:30 --> Model Class Initialized
INFO - 2018-03-25 07:13:30 --> Model Class Initialized
INFO - 2018-03-25 07:13:30 --> Helper loaded: date_helper
INFO - 2018-03-25 07:13:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:13:30 --> Final output sent to browser
DEBUG - 2018-03-25 12:13:30 --> Total execution time: 0.1047
INFO - 2018-03-25 07:13:47 --> Config Class Initialized
INFO - 2018-03-25 07:13:47 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:13:47 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:13:47 --> Utf8 Class Initialized
INFO - 2018-03-25 07:13:47 --> URI Class Initialized
INFO - 2018-03-25 07:13:47 --> Router Class Initialized
INFO - 2018-03-25 07:13:47 --> Output Class Initialized
INFO - 2018-03-25 07:13:47 --> Security Class Initialized
DEBUG - 2018-03-25 07:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:13:47 --> Input Class Initialized
INFO - 2018-03-25 07:13:47 --> Language Class Initialized
INFO - 2018-03-25 07:13:47 --> Loader Class Initialized
INFO - 2018-03-25 07:13:47 --> Helper loaded: url_helper
INFO - 2018-03-25 07:13:47 --> Helper loaded: form_helper
INFO - 2018-03-25 07:13:47 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:13:47 --> Controller Class Initialized
INFO - 2018-03-25 07:13:47 --> Model Class Initialized
INFO - 2018-03-25 07:13:47 --> Model Class Initialized
INFO - 2018-03-25 07:13:47 --> Model Class Initialized
INFO - 2018-03-25 07:13:47 --> Model Class Initialized
INFO - 2018-03-25 07:13:47 --> Model Class Initialized
INFO - 2018-03-25 07:13:47 --> Model Class Initialized
INFO - 2018-03-25 07:13:47 --> Helper loaded: date_helper
INFO - 2018-03-25 07:13:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:13:47 --> Model Class Initialized
INFO - 2018-03-25 12:13:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 12:13:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 12:13:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 12:13:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 12:13:47 --> Final output sent to browser
DEBUG - 2018-03-25 12:13:47 --> Total execution time: 0.1408
INFO - 2018-03-25 07:13:57 --> Config Class Initialized
INFO - 2018-03-25 07:13:57 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:13:57 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:13:57 --> Utf8 Class Initialized
INFO - 2018-03-25 07:13:57 --> URI Class Initialized
INFO - 2018-03-25 07:13:57 --> Router Class Initialized
INFO - 2018-03-25 07:13:57 --> Output Class Initialized
INFO - 2018-03-25 07:13:57 --> Security Class Initialized
DEBUG - 2018-03-25 07:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:13:57 --> Input Class Initialized
INFO - 2018-03-25 07:13:57 --> Language Class Initialized
INFO - 2018-03-25 07:13:57 --> Loader Class Initialized
INFO - 2018-03-25 07:13:57 --> Helper loaded: url_helper
INFO - 2018-03-25 07:13:57 --> Helper loaded: form_helper
INFO - 2018-03-25 07:13:57 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:13:57 --> Controller Class Initialized
INFO - 2018-03-25 07:13:57 --> Model Class Initialized
INFO - 2018-03-25 07:13:57 --> Model Class Initialized
INFO - 2018-03-25 07:13:57 --> Helper loaded: date_helper
INFO - 2018-03-25 07:13:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:13:57 --> Final output sent to browser
DEBUG - 2018-03-25 12:13:57 --> Total execution time: 0.0901
INFO - 2018-03-25 07:14:01 --> Config Class Initialized
INFO - 2018-03-25 07:14:01 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:14:01 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:14:01 --> Utf8 Class Initialized
INFO - 2018-03-25 07:14:01 --> URI Class Initialized
INFO - 2018-03-25 07:14:01 --> Router Class Initialized
INFO - 2018-03-25 07:14:01 --> Output Class Initialized
INFO - 2018-03-25 07:14:01 --> Security Class Initialized
DEBUG - 2018-03-25 07:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:14:01 --> Input Class Initialized
INFO - 2018-03-25 07:14:01 --> Language Class Initialized
INFO - 2018-03-25 07:14:01 --> Loader Class Initialized
INFO - 2018-03-25 07:14:01 --> Helper loaded: url_helper
INFO - 2018-03-25 07:14:01 --> Helper loaded: form_helper
INFO - 2018-03-25 07:14:01 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:14:01 --> Controller Class Initialized
INFO - 2018-03-25 07:14:01 --> Model Class Initialized
INFO - 2018-03-25 07:14:01 --> Model Class Initialized
INFO - 2018-03-25 07:14:01 --> Model Class Initialized
INFO - 2018-03-25 07:14:02 --> Model Class Initialized
INFO - 2018-03-25 07:14:02 --> Model Class Initialized
INFO - 2018-03-25 07:14:02 --> Model Class Initialized
INFO - 2018-03-25 07:14:02 --> Helper loaded: date_helper
INFO - 2018-03-25 07:14:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:14:02 --> Final output sent to browser
DEBUG - 2018-03-25 12:14:02 --> Total execution time: 0.0943
INFO - 2018-03-25 07:23:26 --> Config Class Initialized
INFO - 2018-03-25 07:23:26 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:23:26 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:23:26 --> Utf8 Class Initialized
INFO - 2018-03-25 07:23:26 --> URI Class Initialized
INFO - 2018-03-25 07:23:26 --> Router Class Initialized
INFO - 2018-03-25 07:23:26 --> Output Class Initialized
INFO - 2018-03-25 07:23:26 --> Security Class Initialized
DEBUG - 2018-03-25 07:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:23:26 --> Input Class Initialized
INFO - 2018-03-25 07:23:26 --> Language Class Initialized
INFO - 2018-03-25 07:23:26 --> Loader Class Initialized
INFO - 2018-03-25 07:23:26 --> Helper loaded: url_helper
INFO - 2018-03-25 07:23:26 --> Helper loaded: form_helper
INFO - 2018-03-25 07:23:26 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:23:26 --> Controller Class Initialized
INFO - 2018-03-25 07:23:26 --> Model Class Initialized
INFO - 2018-03-25 07:23:26 --> Model Class Initialized
INFO - 2018-03-25 07:23:26 --> Model Class Initialized
INFO - 2018-03-25 07:23:26 --> Model Class Initialized
INFO - 2018-03-25 07:23:26 --> Model Class Initialized
INFO - 2018-03-25 07:23:26 --> Model Class Initialized
INFO - 2018-03-25 07:23:26 --> Helper loaded: date_helper
INFO - 2018-03-25 07:23:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:23:26 --> Model Class Initialized
INFO - 2018-03-25 12:23:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 12:23:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 12:23:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 12:23:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 12:23:26 --> Final output sent to browser
DEBUG - 2018-03-25 12:23:26 --> Total execution time: 0.0993
INFO - 2018-03-25 07:23:53 --> Config Class Initialized
INFO - 2018-03-25 07:23:53 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:23:53 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:23:53 --> Utf8 Class Initialized
INFO - 2018-03-25 07:23:53 --> URI Class Initialized
INFO - 2018-03-25 07:23:53 --> Router Class Initialized
INFO - 2018-03-25 07:23:53 --> Output Class Initialized
INFO - 2018-03-25 07:23:53 --> Security Class Initialized
DEBUG - 2018-03-25 07:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:23:53 --> Input Class Initialized
INFO - 2018-03-25 07:23:53 --> Language Class Initialized
INFO - 2018-03-25 07:23:53 --> Loader Class Initialized
INFO - 2018-03-25 07:23:53 --> Helper loaded: url_helper
INFO - 2018-03-25 07:23:53 --> Helper loaded: form_helper
INFO - 2018-03-25 07:23:53 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:23:53 --> Controller Class Initialized
INFO - 2018-03-25 07:23:53 --> Model Class Initialized
INFO - 2018-03-25 07:23:53 --> Model Class Initialized
INFO - 2018-03-25 07:23:53 --> Model Class Initialized
INFO - 2018-03-25 07:23:53 --> Model Class Initialized
INFO - 2018-03-25 07:23:53 --> Model Class Initialized
INFO - 2018-03-25 07:23:53 --> Model Class Initialized
INFO - 2018-03-25 07:23:53 --> Helper loaded: date_helper
INFO - 2018-03-25 07:23:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:23:53 --> Model Class Initialized
INFO - 2018-03-25 12:23:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 12:23:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 12:23:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 12:23:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 12:23:53 --> Final output sent to browser
DEBUG - 2018-03-25 12:23:53 --> Total execution time: 0.1063
INFO - 2018-03-25 07:23:58 --> Config Class Initialized
INFO - 2018-03-25 07:23:58 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:23:58 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:23:58 --> Utf8 Class Initialized
INFO - 2018-03-25 07:23:58 --> URI Class Initialized
INFO - 2018-03-25 07:23:58 --> Router Class Initialized
INFO - 2018-03-25 07:23:58 --> Output Class Initialized
INFO - 2018-03-25 07:23:58 --> Security Class Initialized
DEBUG - 2018-03-25 07:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:23:58 --> Input Class Initialized
INFO - 2018-03-25 07:23:58 --> Language Class Initialized
INFO - 2018-03-25 07:23:58 --> Loader Class Initialized
INFO - 2018-03-25 07:23:58 --> Helper loaded: url_helper
INFO - 2018-03-25 07:23:58 --> Helper loaded: form_helper
INFO - 2018-03-25 07:23:58 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:23:58 --> Controller Class Initialized
INFO - 2018-03-25 07:23:58 --> Model Class Initialized
INFO - 2018-03-25 07:23:58 --> Model Class Initialized
INFO - 2018-03-25 07:23:58 --> Helper loaded: date_helper
INFO - 2018-03-25 07:23:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:23:58 --> Final output sent to browser
DEBUG - 2018-03-25 12:23:58 --> Total execution time: 0.0856
INFO - 2018-03-25 07:24:00 --> Config Class Initialized
INFO - 2018-03-25 07:24:00 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:24:00 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:24:00 --> Utf8 Class Initialized
INFO - 2018-03-25 07:24:00 --> URI Class Initialized
INFO - 2018-03-25 07:24:00 --> Router Class Initialized
INFO - 2018-03-25 07:24:00 --> Output Class Initialized
INFO - 2018-03-25 07:24:00 --> Security Class Initialized
DEBUG - 2018-03-25 07:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:24:00 --> Input Class Initialized
INFO - 2018-03-25 07:24:00 --> Language Class Initialized
INFO - 2018-03-25 07:24:00 --> Loader Class Initialized
INFO - 2018-03-25 07:24:00 --> Helper loaded: url_helper
INFO - 2018-03-25 07:24:00 --> Helper loaded: form_helper
INFO - 2018-03-25 07:24:00 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:24:00 --> Controller Class Initialized
INFO - 2018-03-25 07:24:00 --> Model Class Initialized
INFO - 2018-03-25 07:24:00 --> Model Class Initialized
INFO - 2018-03-25 07:24:00 --> Model Class Initialized
INFO - 2018-03-25 07:24:00 --> Model Class Initialized
INFO - 2018-03-25 07:24:00 --> Model Class Initialized
INFO - 2018-03-25 07:24:00 --> Model Class Initialized
INFO - 2018-03-25 07:24:00 --> Helper loaded: date_helper
INFO - 2018-03-25 07:24:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:24:00 --> Final output sent to browser
DEBUG - 2018-03-25 12:24:00 --> Total execution time: 0.0754
INFO - 2018-03-25 07:34:01 --> Config Class Initialized
INFO - 2018-03-25 07:34:01 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:34:01 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:34:01 --> Utf8 Class Initialized
INFO - 2018-03-25 07:34:01 --> URI Class Initialized
INFO - 2018-03-25 07:34:01 --> Router Class Initialized
INFO - 2018-03-25 07:34:01 --> Output Class Initialized
INFO - 2018-03-25 07:34:01 --> Security Class Initialized
DEBUG - 2018-03-25 07:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:34:01 --> Input Class Initialized
INFO - 2018-03-25 07:34:01 --> Language Class Initialized
INFO - 2018-03-25 07:34:01 --> Loader Class Initialized
INFO - 2018-03-25 07:34:01 --> Helper loaded: url_helper
INFO - 2018-03-25 07:34:01 --> Helper loaded: form_helper
INFO - 2018-03-25 07:34:01 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:34:01 --> Controller Class Initialized
INFO - 2018-03-25 07:34:01 --> Model Class Initialized
INFO - 2018-03-25 07:34:01 --> Model Class Initialized
INFO - 2018-03-25 07:34:01 --> Model Class Initialized
INFO - 2018-03-25 07:34:01 --> Model Class Initialized
INFO - 2018-03-25 07:34:01 --> Model Class Initialized
INFO - 2018-03-25 07:34:01 --> Model Class Initialized
INFO - 2018-03-25 07:34:01 --> Helper loaded: date_helper
INFO - 2018-03-25 07:34:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:34:01 --> Model Class Initialized
INFO - 2018-03-25 12:34:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 12:34:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 12:34:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 12:34:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 12:34:01 --> Final output sent to browser
DEBUG - 2018-03-25 12:34:01 --> Total execution time: 0.1069
INFO - 2018-03-25 07:34:09 --> Config Class Initialized
INFO - 2018-03-25 07:34:09 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:34:09 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:34:09 --> Utf8 Class Initialized
INFO - 2018-03-25 07:34:09 --> URI Class Initialized
INFO - 2018-03-25 07:34:09 --> Router Class Initialized
INFO - 2018-03-25 07:34:09 --> Output Class Initialized
INFO - 2018-03-25 07:34:10 --> Security Class Initialized
DEBUG - 2018-03-25 07:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:34:10 --> Input Class Initialized
INFO - 2018-03-25 07:34:10 --> Language Class Initialized
INFO - 2018-03-25 07:34:10 --> Loader Class Initialized
INFO - 2018-03-25 07:34:10 --> Helper loaded: url_helper
INFO - 2018-03-25 07:34:10 --> Helper loaded: form_helper
INFO - 2018-03-25 07:34:10 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:34:10 --> Controller Class Initialized
INFO - 2018-03-25 07:34:10 --> Model Class Initialized
INFO - 2018-03-25 07:34:10 --> Model Class Initialized
INFO - 2018-03-25 07:34:10 --> Helper loaded: date_helper
INFO - 2018-03-25 07:34:10 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:34:10 --> Final output sent to browser
DEBUG - 2018-03-25 12:34:10 --> Total execution time: 0.0996
INFO - 2018-03-25 07:34:12 --> Config Class Initialized
INFO - 2018-03-25 07:34:12 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:34:12 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:34:12 --> Utf8 Class Initialized
INFO - 2018-03-25 07:34:12 --> URI Class Initialized
INFO - 2018-03-25 07:34:12 --> Router Class Initialized
INFO - 2018-03-25 07:34:12 --> Output Class Initialized
INFO - 2018-03-25 07:34:12 --> Security Class Initialized
DEBUG - 2018-03-25 07:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:34:12 --> Input Class Initialized
INFO - 2018-03-25 07:34:12 --> Language Class Initialized
INFO - 2018-03-25 07:34:12 --> Loader Class Initialized
INFO - 2018-03-25 07:34:12 --> Helper loaded: url_helper
INFO - 2018-03-25 07:34:12 --> Helper loaded: form_helper
INFO - 2018-03-25 07:34:13 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:34:13 --> Controller Class Initialized
INFO - 2018-03-25 07:34:13 --> Model Class Initialized
INFO - 2018-03-25 07:34:13 --> Model Class Initialized
INFO - 2018-03-25 07:34:13 --> Model Class Initialized
INFO - 2018-03-25 07:34:13 --> Model Class Initialized
INFO - 2018-03-25 07:34:13 --> Model Class Initialized
INFO - 2018-03-25 07:34:13 --> Model Class Initialized
INFO - 2018-03-25 07:34:13 --> Helper loaded: date_helper
INFO - 2018-03-25 07:34:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:34:13 --> Final output sent to browser
DEBUG - 2018-03-25 12:34:13 --> Total execution time: 0.1166
INFO - 2018-03-25 07:35:35 --> Config Class Initialized
INFO - 2018-03-25 07:35:35 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:35:35 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:35:35 --> Utf8 Class Initialized
INFO - 2018-03-25 07:35:35 --> URI Class Initialized
INFO - 2018-03-25 07:35:35 --> Router Class Initialized
INFO - 2018-03-25 07:35:35 --> Output Class Initialized
INFO - 2018-03-25 07:35:35 --> Security Class Initialized
DEBUG - 2018-03-25 07:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:35:35 --> Input Class Initialized
INFO - 2018-03-25 07:35:35 --> Language Class Initialized
INFO - 2018-03-25 07:35:35 --> Loader Class Initialized
INFO - 2018-03-25 07:35:35 --> Helper loaded: url_helper
INFO - 2018-03-25 07:35:35 --> Helper loaded: form_helper
INFO - 2018-03-25 07:35:35 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:35:35 --> Controller Class Initialized
INFO - 2018-03-25 07:35:35 --> Model Class Initialized
INFO - 2018-03-25 07:35:35 --> Model Class Initialized
INFO - 2018-03-25 07:35:35 --> Model Class Initialized
INFO - 2018-03-25 07:35:35 --> Model Class Initialized
INFO - 2018-03-25 07:35:35 --> Model Class Initialized
INFO - 2018-03-25 07:35:35 --> Model Class Initialized
INFO - 2018-03-25 07:35:35 --> Helper loaded: date_helper
INFO - 2018-03-25 07:35:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:35:35 --> Model Class Initialized
INFO - 2018-03-25 12:35:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 12:35:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 12:35:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 12:35:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 12:35:35 --> Final output sent to browser
DEBUG - 2018-03-25 12:35:35 --> Total execution time: 0.1165
INFO - 2018-03-25 07:35:44 --> Config Class Initialized
INFO - 2018-03-25 07:35:44 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:35:44 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:35:44 --> Utf8 Class Initialized
INFO - 2018-03-25 07:35:44 --> URI Class Initialized
INFO - 2018-03-25 07:35:44 --> Router Class Initialized
INFO - 2018-03-25 07:35:44 --> Output Class Initialized
INFO - 2018-03-25 07:35:44 --> Security Class Initialized
DEBUG - 2018-03-25 07:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:35:44 --> Input Class Initialized
INFO - 2018-03-25 07:35:44 --> Language Class Initialized
INFO - 2018-03-25 07:35:44 --> Loader Class Initialized
INFO - 2018-03-25 07:35:44 --> Helper loaded: url_helper
INFO - 2018-03-25 07:35:44 --> Helper loaded: form_helper
INFO - 2018-03-25 07:35:44 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:35:44 --> Controller Class Initialized
INFO - 2018-03-25 07:35:44 --> Model Class Initialized
INFO - 2018-03-25 07:35:44 --> Model Class Initialized
INFO - 2018-03-25 07:35:44 --> Helper loaded: date_helper
INFO - 2018-03-25 07:35:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:35:44 --> Final output sent to browser
DEBUG - 2018-03-25 12:35:44 --> Total execution time: 0.0924
INFO - 2018-03-25 07:35:46 --> Config Class Initialized
INFO - 2018-03-25 07:35:46 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:35:46 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:35:46 --> Utf8 Class Initialized
INFO - 2018-03-25 07:35:46 --> URI Class Initialized
INFO - 2018-03-25 07:35:46 --> Router Class Initialized
INFO - 2018-03-25 07:35:46 --> Output Class Initialized
INFO - 2018-03-25 07:35:46 --> Security Class Initialized
DEBUG - 2018-03-25 07:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:35:46 --> Input Class Initialized
INFO - 2018-03-25 07:35:46 --> Language Class Initialized
INFO - 2018-03-25 07:35:46 --> Loader Class Initialized
INFO - 2018-03-25 07:35:46 --> Helper loaded: url_helper
INFO - 2018-03-25 07:35:46 --> Helper loaded: form_helper
INFO - 2018-03-25 07:35:46 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:35:46 --> Controller Class Initialized
INFO - 2018-03-25 07:35:46 --> Model Class Initialized
INFO - 2018-03-25 07:35:46 --> Model Class Initialized
INFO - 2018-03-25 07:35:46 --> Model Class Initialized
INFO - 2018-03-25 07:35:46 --> Model Class Initialized
INFO - 2018-03-25 07:35:46 --> Model Class Initialized
INFO - 2018-03-25 07:35:46 --> Model Class Initialized
INFO - 2018-03-25 07:35:46 --> Helper loaded: date_helper
INFO - 2018-03-25 07:35:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:35:46 --> Final output sent to browser
DEBUG - 2018-03-25 12:35:46 --> Total execution time: 0.1061
INFO - 2018-03-25 07:36:23 --> Config Class Initialized
INFO - 2018-03-25 07:36:23 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:36:23 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:36:23 --> Utf8 Class Initialized
INFO - 2018-03-25 07:36:23 --> URI Class Initialized
INFO - 2018-03-25 07:36:23 --> Router Class Initialized
INFO - 2018-03-25 07:36:23 --> Output Class Initialized
INFO - 2018-03-25 07:36:23 --> Security Class Initialized
DEBUG - 2018-03-25 07:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:36:23 --> Input Class Initialized
INFO - 2018-03-25 07:36:23 --> Language Class Initialized
INFO - 2018-03-25 07:36:23 --> Loader Class Initialized
INFO - 2018-03-25 07:36:23 --> Helper loaded: url_helper
INFO - 2018-03-25 07:36:23 --> Helper loaded: form_helper
INFO - 2018-03-25 07:36:23 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:36:23 --> Controller Class Initialized
INFO - 2018-03-25 07:36:23 --> Model Class Initialized
INFO - 2018-03-25 07:36:23 --> Model Class Initialized
INFO - 2018-03-25 07:36:23 --> Model Class Initialized
INFO - 2018-03-25 07:36:23 --> Model Class Initialized
INFO - 2018-03-25 07:36:23 --> Model Class Initialized
INFO - 2018-03-25 07:36:23 --> Model Class Initialized
INFO - 2018-03-25 07:36:23 --> Helper loaded: date_helper
INFO - 2018-03-25 07:36:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:36:23 --> Model Class Initialized
INFO - 2018-03-25 12:36:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 12:36:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 12:36:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 12:36:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 12:36:23 --> Final output sent to browser
DEBUG - 2018-03-25 12:36:23 --> Total execution time: 0.1092
INFO - 2018-03-25 07:36:30 --> Config Class Initialized
INFO - 2018-03-25 07:36:30 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:36:30 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:36:30 --> Utf8 Class Initialized
INFO - 2018-03-25 07:36:30 --> URI Class Initialized
INFO - 2018-03-25 07:36:30 --> Router Class Initialized
INFO - 2018-03-25 07:36:30 --> Output Class Initialized
INFO - 2018-03-25 07:36:30 --> Security Class Initialized
DEBUG - 2018-03-25 07:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:36:30 --> Input Class Initialized
INFO - 2018-03-25 07:36:30 --> Language Class Initialized
INFO - 2018-03-25 07:36:30 --> Loader Class Initialized
INFO - 2018-03-25 07:36:30 --> Helper loaded: url_helper
INFO - 2018-03-25 07:36:30 --> Helper loaded: form_helper
INFO - 2018-03-25 07:36:30 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:36:30 --> Controller Class Initialized
INFO - 2018-03-25 07:36:30 --> Model Class Initialized
INFO - 2018-03-25 07:36:30 --> Model Class Initialized
INFO - 2018-03-25 07:36:30 --> Helper loaded: date_helper
INFO - 2018-03-25 07:36:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:36:30 --> Final output sent to browser
DEBUG - 2018-03-25 12:36:30 --> Total execution time: 0.0778
INFO - 2018-03-25 07:37:51 --> Config Class Initialized
INFO - 2018-03-25 07:37:51 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:37:51 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:37:51 --> Utf8 Class Initialized
INFO - 2018-03-25 07:37:51 --> URI Class Initialized
INFO - 2018-03-25 07:37:51 --> Router Class Initialized
INFO - 2018-03-25 07:37:51 --> Output Class Initialized
INFO - 2018-03-25 07:37:51 --> Security Class Initialized
DEBUG - 2018-03-25 07:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:37:51 --> Input Class Initialized
INFO - 2018-03-25 07:37:51 --> Language Class Initialized
INFO - 2018-03-25 07:37:51 --> Loader Class Initialized
INFO - 2018-03-25 07:37:51 --> Helper loaded: url_helper
INFO - 2018-03-25 07:37:51 --> Helper loaded: form_helper
INFO - 2018-03-25 07:37:51 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:37:51 --> Controller Class Initialized
INFO - 2018-03-25 07:37:51 --> Model Class Initialized
INFO - 2018-03-25 07:37:51 --> Model Class Initialized
INFO - 2018-03-25 07:37:51 --> Model Class Initialized
INFO - 2018-03-25 07:37:51 --> Model Class Initialized
INFO - 2018-03-25 07:37:51 --> Model Class Initialized
INFO - 2018-03-25 07:37:51 --> Model Class Initialized
INFO - 2018-03-25 07:37:51 --> Helper loaded: date_helper
INFO - 2018-03-25 07:37:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:37:51 --> Final output sent to browser
DEBUG - 2018-03-25 12:37:51 --> Total execution time: 0.0826
INFO - 2018-03-25 07:46:38 --> Config Class Initialized
INFO - 2018-03-25 07:46:38 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:46:38 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:46:38 --> Utf8 Class Initialized
INFO - 2018-03-25 07:46:38 --> URI Class Initialized
INFO - 2018-03-25 07:46:38 --> Router Class Initialized
INFO - 2018-03-25 07:46:38 --> Output Class Initialized
INFO - 2018-03-25 07:46:38 --> Security Class Initialized
DEBUG - 2018-03-25 07:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:46:38 --> Input Class Initialized
INFO - 2018-03-25 07:46:38 --> Language Class Initialized
INFO - 2018-03-25 07:46:38 --> Loader Class Initialized
INFO - 2018-03-25 07:46:38 --> Helper loaded: url_helper
INFO - 2018-03-25 07:46:38 --> Helper loaded: form_helper
INFO - 2018-03-25 07:46:38 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:46:38 --> Controller Class Initialized
INFO - 2018-03-25 07:46:38 --> Model Class Initialized
INFO - 2018-03-25 07:46:38 --> Model Class Initialized
INFO - 2018-03-25 07:46:38 --> Model Class Initialized
INFO - 2018-03-25 07:46:38 --> Model Class Initialized
INFO - 2018-03-25 07:46:38 --> Model Class Initialized
INFO - 2018-03-25 07:46:38 --> Model Class Initialized
INFO - 2018-03-25 07:46:38 --> Helper loaded: date_helper
INFO - 2018-03-25 07:46:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:46:38 --> Model Class Initialized
INFO - 2018-03-25 12:46:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 12:46:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 12:46:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 12:46:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 12:46:38 --> Final output sent to browser
DEBUG - 2018-03-25 12:46:38 --> Total execution time: 0.1068
INFO - 2018-03-25 07:46:44 --> Config Class Initialized
INFO - 2018-03-25 07:46:44 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:46:44 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:46:44 --> Utf8 Class Initialized
INFO - 2018-03-25 07:46:44 --> URI Class Initialized
INFO - 2018-03-25 07:46:44 --> Router Class Initialized
INFO - 2018-03-25 07:46:44 --> Output Class Initialized
INFO - 2018-03-25 07:46:44 --> Security Class Initialized
DEBUG - 2018-03-25 07:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:46:44 --> Input Class Initialized
INFO - 2018-03-25 07:46:44 --> Language Class Initialized
INFO - 2018-03-25 07:46:44 --> Loader Class Initialized
INFO - 2018-03-25 07:46:44 --> Helper loaded: url_helper
INFO - 2018-03-25 07:46:44 --> Helper loaded: form_helper
INFO - 2018-03-25 07:46:44 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:46:44 --> Controller Class Initialized
INFO - 2018-03-25 07:46:44 --> Model Class Initialized
INFO - 2018-03-25 07:46:44 --> Model Class Initialized
INFO - 2018-03-25 07:46:45 --> Helper loaded: date_helper
INFO - 2018-03-25 07:46:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:46:45 --> Final output sent to browser
DEBUG - 2018-03-25 12:46:45 --> Total execution time: 0.0667
INFO - 2018-03-25 07:46:48 --> Config Class Initialized
INFO - 2018-03-25 07:46:48 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:46:48 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:46:48 --> Utf8 Class Initialized
INFO - 2018-03-25 07:46:48 --> URI Class Initialized
INFO - 2018-03-25 07:46:48 --> Router Class Initialized
INFO - 2018-03-25 07:46:48 --> Output Class Initialized
INFO - 2018-03-25 07:46:48 --> Security Class Initialized
DEBUG - 2018-03-25 07:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:46:48 --> Input Class Initialized
INFO - 2018-03-25 07:46:48 --> Language Class Initialized
INFO - 2018-03-25 07:46:48 --> Loader Class Initialized
INFO - 2018-03-25 07:46:48 --> Helper loaded: url_helper
INFO - 2018-03-25 07:46:48 --> Helper loaded: form_helper
INFO - 2018-03-25 07:46:48 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:46:48 --> Controller Class Initialized
INFO - 2018-03-25 07:46:48 --> Model Class Initialized
INFO - 2018-03-25 07:46:48 --> Model Class Initialized
INFO - 2018-03-25 07:46:48 --> Model Class Initialized
INFO - 2018-03-25 07:46:48 --> Model Class Initialized
INFO - 2018-03-25 07:46:48 --> Model Class Initialized
INFO - 2018-03-25 07:46:48 --> Model Class Initialized
INFO - 2018-03-25 07:46:48 --> Helper loaded: date_helper
INFO - 2018-03-25 07:46:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:46:48 --> Final output sent to browser
DEBUG - 2018-03-25 12:46:48 --> Total execution time: 0.1225
INFO - 2018-03-25 07:47:35 --> Config Class Initialized
INFO - 2018-03-25 07:47:35 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:47:35 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:47:35 --> Utf8 Class Initialized
INFO - 2018-03-25 07:47:35 --> URI Class Initialized
INFO - 2018-03-25 07:47:35 --> Router Class Initialized
INFO - 2018-03-25 07:47:35 --> Output Class Initialized
INFO - 2018-03-25 07:47:35 --> Security Class Initialized
DEBUG - 2018-03-25 07:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:47:35 --> Input Class Initialized
INFO - 2018-03-25 07:47:35 --> Language Class Initialized
INFO - 2018-03-25 07:47:35 --> Loader Class Initialized
INFO - 2018-03-25 07:47:35 --> Helper loaded: url_helper
INFO - 2018-03-25 07:47:35 --> Helper loaded: form_helper
INFO - 2018-03-25 07:47:36 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:47:36 --> Controller Class Initialized
INFO - 2018-03-25 07:47:36 --> Model Class Initialized
INFO - 2018-03-25 07:47:36 --> Model Class Initialized
INFO - 2018-03-25 07:47:36 --> Model Class Initialized
INFO - 2018-03-25 07:47:36 --> Model Class Initialized
INFO - 2018-03-25 07:47:36 --> Model Class Initialized
INFO - 2018-03-25 07:47:36 --> Model Class Initialized
INFO - 2018-03-25 07:47:36 --> Helper loaded: date_helper
INFO - 2018-03-25 07:47:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:47:36 --> Model Class Initialized
INFO - 2018-03-25 12:47:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 12:47:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 12:47:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 12:47:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 12:47:36 --> Final output sent to browser
DEBUG - 2018-03-25 12:47:36 --> Total execution time: 0.1052
INFO - 2018-03-25 07:47:44 --> Config Class Initialized
INFO - 2018-03-25 07:47:44 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:47:44 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:47:44 --> Utf8 Class Initialized
INFO - 2018-03-25 07:47:44 --> URI Class Initialized
INFO - 2018-03-25 07:47:44 --> Router Class Initialized
INFO - 2018-03-25 07:47:44 --> Output Class Initialized
INFO - 2018-03-25 07:47:44 --> Security Class Initialized
DEBUG - 2018-03-25 07:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:47:44 --> Input Class Initialized
INFO - 2018-03-25 07:47:44 --> Language Class Initialized
INFO - 2018-03-25 07:47:44 --> Loader Class Initialized
INFO - 2018-03-25 07:47:44 --> Helper loaded: url_helper
INFO - 2018-03-25 07:47:44 --> Helper loaded: form_helper
INFO - 2018-03-25 07:47:44 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:47:44 --> Controller Class Initialized
INFO - 2018-03-25 07:47:44 --> Model Class Initialized
INFO - 2018-03-25 07:47:44 --> Model Class Initialized
INFO - 2018-03-25 07:47:44 --> Helper loaded: date_helper
INFO - 2018-03-25 07:47:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:47:44 --> Final output sent to browser
DEBUG - 2018-03-25 12:47:44 --> Total execution time: 0.1004
INFO - 2018-03-25 07:47:48 --> Config Class Initialized
INFO - 2018-03-25 07:47:48 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:47:48 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:47:48 --> Utf8 Class Initialized
INFO - 2018-03-25 07:47:48 --> URI Class Initialized
INFO - 2018-03-25 07:47:48 --> Router Class Initialized
INFO - 2018-03-25 07:47:48 --> Output Class Initialized
INFO - 2018-03-25 07:47:48 --> Security Class Initialized
DEBUG - 2018-03-25 07:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:47:48 --> Input Class Initialized
INFO - 2018-03-25 07:47:48 --> Language Class Initialized
INFO - 2018-03-25 07:47:48 --> Loader Class Initialized
INFO - 2018-03-25 07:47:48 --> Helper loaded: url_helper
INFO - 2018-03-25 07:47:48 --> Helper loaded: form_helper
INFO - 2018-03-25 07:47:48 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:47:48 --> Controller Class Initialized
INFO - 2018-03-25 07:47:48 --> Model Class Initialized
INFO - 2018-03-25 07:47:48 --> Model Class Initialized
INFO - 2018-03-25 07:47:48 --> Model Class Initialized
INFO - 2018-03-25 07:47:48 --> Model Class Initialized
INFO - 2018-03-25 07:47:48 --> Model Class Initialized
INFO - 2018-03-25 07:47:48 --> Model Class Initialized
INFO - 2018-03-25 07:47:48 --> Helper loaded: date_helper
INFO - 2018-03-25 07:47:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:47:48 --> Final output sent to browser
DEBUG - 2018-03-25 12:47:48 --> Total execution time: 0.1070
INFO - 2018-03-25 07:50:24 --> Config Class Initialized
INFO - 2018-03-25 07:50:24 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:50:24 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:50:24 --> Utf8 Class Initialized
INFO - 2018-03-25 07:50:24 --> URI Class Initialized
INFO - 2018-03-25 07:50:24 --> Router Class Initialized
INFO - 2018-03-25 07:50:24 --> Output Class Initialized
INFO - 2018-03-25 07:50:24 --> Security Class Initialized
DEBUG - 2018-03-25 07:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:50:24 --> Input Class Initialized
INFO - 2018-03-25 07:50:24 --> Language Class Initialized
INFO - 2018-03-25 07:50:24 --> Loader Class Initialized
INFO - 2018-03-25 07:50:24 --> Helper loaded: url_helper
INFO - 2018-03-25 07:50:24 --> Helper loaded: form_helper
INFO - 2018-03-25 07:50:24 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:50:24 --> Controller Class Initialized
INFO - 2018-03-25 07:50:24 --> Model Class Initialized
INFO - 2018-03-25 07:50:24 --> Model Class Initialized
INFO - 2018-03-25 07:50:24 --> Model Class Initialized
INFO - 2018-03-25 07:50:24 --> Model Class Initialized
INFO - 2018-03-25 07:50:24 --> Model Class Initialized
INFO - 2018-03-25 07:50:24 --> Model Class Initialized
INFO - 2018-03-25 07:50:24 --> Helper loaded: date_helper
INFO - 2018-03-25 07:50:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:50:24 --> Model Class Initialized
INFO - 2018-03-25 12:50:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 12:50:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 12:50:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 12:50:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 12:50:24 --> Final output sent to browser
DEBUG - 2018-03-25 12:50:24 --> Total execution time: 0.1165
INFO - 2018-03-25 07:50:30 --> Config Class Initialized
INFO - 2018-03-25 07:50:30 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:50:30 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:50:30 --> Utf8 Class Initialized
INFO - 2018-03-25 07:50:30 --> URI Class Initialized
INFO - 2018-03-25 07:50:30 --> Router Class Initialized
INFO - 2018-03-25 07:50:30 --> Output Class Initialized
INFO - 2018-03-25 07:50:30 --> Security Class Initialized
DEBUG - 2018-03-25 07:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:50:30 --> Input Class Initialized
INFO - 2018-03-25 07:50:30 --> Language Class Initialized
INFO - 2018-03-25 07:50:30 --> Loader Class Initialized
INFO - 2018-03-25 07:50:30 --> Helper loaded: url_helper
INFO - 2018-03-25 07:50:30 --> Helper loaded: form_helper
INFO - 2018-03-25 07:50:30 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:50:30 --> Controller Class Initialized
INFO - 2018-03-25 07:50:30 --> Model Class Initialized
INFO - 2018-03-25 07:50:30 --> Model Class Initialized
INFO - 2018-03-25 07:50:30 --> Helper loaded: date_helper
INFO - 2018-03-25 07:50:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:50:30 --> Final output sent to browser
DEBUG - 2018-03-25 12:50:30 --> Total execution time: 0.0839
INFO - 2018-03-25 07:50:35 --> Config Class Initialized
INFO - 2018-03-25 07:50:35 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:50:35 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:50:35 --> Utf8 Class Initialized
INFO - 2018-03-25 07:50:35 --> URI Class Initialized
INFO - 2018-03-25 07:50:35 --> Router Class Initialized
INFO - 2018-03-25 07:50:35 --> Output Class Initialized
INFO - 2018-03-25 07:50:35 --> Security Class Initialized
DEBUG - 2018-03-25 07:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:50:35 --> Input Class Initialized
INFO - 2018-03-25 07:50:35 --> Language Class Initialized
INFO - 2018-03-25 07:50:35 --> Loader Class Initialized
INFO - 2018-03-25 07:50:35 --> Helper loaded: url_helper
INFO - 2018-03-25 07:50:35 --> Helper loaded: form_helper
INFO - 2018-03-25 07:50:35 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:50:35 --> Controller Class Initialized
INFO - 2018-03-25 07:50:35 --> Model Class Initialized
INFO - 2018-03-25 07:50:35 --> Model Class Initialized
INFO - 2018-03-25 07:50:35 --> Model Class Initialized
INFO - 2018-03-25 07:50:35 --> Model Class Initialized
INFO - 2018-03-25 07:50:35 --> Model Class Initialized
INFO - 2018-03-25 07:50:35 --> Model Class Initialized
INFO - 2018-03-25 07:50:35 --> Helper loaded: date_helper
INFO - 2018-03-25 07:50:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:50:35 --> Final output sent to browser
DEBUG - 2018-03-25 12:50:35 --> Total execution time: 0.0693
INFO - 2018-03-25 07:51:05 --> Config Class Initialized
INFO - 2018-03-25 07:51:05 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:51:05 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:51:05 --> Utf8 Class Initialized
INFO - 2018-03-25 07:51:05 --> URI Class Initialized
INFO - 2018-03-25 07:51:05 --> Router Class Initialized
INFO - 2018-03-25 07:51:05 --> Output Class Initialized
INFO - 2018-03-25 07:51:05 --> Security Class Initialized
DEBUG - 2018-03-25 07:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:51:05 --> Input Class Initialized
INFO - 2018-03-25 07:51:05 --> Language Class Initialized
INFO - 2018-03-25 07:51:05 --> Loader Class Initialized
INFO - 2018-03-25 07:51:05 --> Helper loaded: url_helper
INFO - 2018-03-25 07:51:05 --> Helper loaded: form_helper
INFO - 2018-03-25 07:51:05 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:51:05 --> Controller Class Initialized
INFO - 2018-03-25 07:51:05 --> Model Class Initialized
INFO - 2018-03-25 07:51:05 --> Model Class Initialized
INFO - 2018-03-25 07:51:05 --> Model Class Initialized
INFO - 2018-03-25 07:51:05 --> Model Class Initialized
INFO - 2018-03-25 07:51:05 --> Model Class Initialized
INFO - 2018-03-25 07:51:05 --> Model Class Initialized
INFO - 2018-03-25 07:51:05 --> Helper loaded: date_helper
INFO - 2018-03-25 07:51:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:51:05 --> Model Class Initialized
INFO - 2018-03-25 12:51:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 12:51:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 12:51:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 12:51:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 12:51:05 --> Final output sent to browser
DEBUG - 2018-03-25 12:51:05 --> Total execution time: 0.0844
INFO - 2018-03-25 07:51:12 --> Config Class Initialized
INFO - 2018-03-25 07:51:12 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:51:12 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:51:12 --> Utf8 Class Initialized
INFO - 2018-03-25 07:51:12 --> URI Class Initialized
INFO - 2018-03-25 07:51:12 --> Router Class Initialized
INFO - 2018-03-25 07:51:12 --> Output Class Initialized
INFO - 2018-03-25 07:51:12 --> Security Class Initialized
DEBUG - 2018-03-25 07:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:51:12 --> Input Class Initialized
INFO - 2018-03-25 07:51:12 --> Language Class Initialized
INFO - 2018-03-25 07:51:12 --> Loader Class Initialized
INFO - 2018-03-25 07:51:12 --> Helper loaded: url_helper
INFO - 2018-03-25 07:51:12 --> Helper loaded: form_helper
INFO - 2018-03-25 07:51:12 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:51:12 --> Controller Class Initialized
INFO - 2018-03-25 07:51:12 --> Model Class Initialized
INFO - 2018-03-25 07:51:12 --> Model Class Initialized
INFO - 2018-03-25 07:51:12 --> Helper loaded: date_helper
INFO - 2018-03-25 07:51:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:51:12 --> Final output sent to browser
DEBUG - 2018-03-25 12:51:12 --> Total execution time: 0.0839
INFO - 2018-03-25 07:51:15 --> Config Class Initialized
INFO - 2018-03-25 07:51:15 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:51:15 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:51:15 --> Utf8 Class Initialized
INFO - 2018-03-25 07:51:15 --> URI Class Initialized
INFO - 2018-03-25 07:51:15 --> Router Class Initialized
INFO - 2018-03-25 07:51:15 --> Output Class Initialized
INFO - 2018-03-25 07:51:15 --> Security Class Initialized
DEBUG - 2018-03-25 07:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:51:15 --> Input Class Initialized
INFO - 2018-03-25 07:51:15 --> Language Class Initialized
INFO - 2018-03-25 07:51:15 --> Loader Class Initialized
INFO - 2018-03-25 07:51:15 --> Helper loaded: url_helper
INFO - 2018-03-25 07:51:15 --> Helper loaded: form_helper
INFO - 2018-03-25 07:51:15 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:51:15 --> Controller Class Initialized
INFO - 2018-03-25 07:51:15 --> Model Class Initialized
INFO - 2018-03-25 07:51:15 --> Model Class Initialized
INFO - 2018-03-25 07:51:15 --> Model Class Initialized
INFO - 2018-03-25 07:51:15 --> Model Class Initialized
INFO - 2018-03-25 07:51:15 --> Model Class Initialized
INFO - 2018-03-25 07:51:15 --> Model Class Initialized
INFO - 2018-03-25 07:51:15 --> Helper loaded: date_helper
INFO - 2018-03-25 07:51:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:51:16 --> Final output sent to browser
DEBUG - 2018-03-25 12:51:16 --> Total execution time: 0.0845
INFO - 2018-03-25 07:55:45 --> Config Class Initialized
INFO - 2018-03-25 07:55:45 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:55:45 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:55:45 --> Utf8 Class Initialized
INFO - 2018-03-25 07:55:45 --> URI Class Initialized
INFO - 2018-03-25 07:55:45 --> Router Class Initialized
INFO - 2018-03-25 07:55:45 --> Output Class Initialized
INFO - 2018-03-25 07:55:45 --> Security Class Initialized
DEBUG - 2018-03-25 07:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:55:45 --> Input Class Initialized
INFO - 2018-03-25 07:55:45 --> Language Class Initialized
INFO - 2018-03-25 07:55:45 --> Loader Class Initialized
INFO - 2018-03-25 07:55:45 --> Helper loaded: url_helper
INFO - 2018-03-25 07:55:45 --> Helper loaded: form_helper
INFO - 2018-03-25 07:55:45 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:55:45 --> Controller Class Initialized
INFO - 2018-03-25 07:55:45 --> Model Class Initialized
INFO - 2018-03-25 07:55:45 --> Model Class Initialized
INFO - 2018-03-25 07:55:45 --> Model Class Initialized
INFO - 2018-03-25 07:55:46 --> Model Class Initialized
INFO - 2018-03-25 07:55:46 --> Model Class Initialized
INFO - 2018-03-25 07:55:46 --> Model Class Initialized
INFO - 2018-03-25 07:55:46 --> Helper loaded: date_helper
INFO - 2018-03-25 07:55:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:55:46 --> Model Class Initialized
INFO - 2018-03-25 12:55:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 12:55:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 12:55:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 12:55:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 12:55:46 --> Final output sent to browser
DEBUG - 2018-03-25 12:55:46 --> Total execution time: 0.1114
INFO - 2018-03-25 07:55:56 --> Config Class Initialized
INFO - 2018-03-25 07:55:56 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:55:56 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:55:56 --> Utf8 Class Initialized
INFO - 2018-03-25 07:55:56 --> URI Class Initialized
INFO - 2018-03-25 07:55:56 --> Router Class Initialized
INFO - 2018-03-25 07:55:56 --> Output Class Initialized
INFO - 2018-03-25 07:55:56 --> Security Class Initialized
DEBUG - 2018-03-25 07:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:55:56 --> Input Class Initialized
INFO - 2018-03-25 07:55:56 --> Language Class Initialized
INFO - 2018-03-25 07:55:56 --> Loader Class Initialized
INFO - 2018-03-25 07:55:56 --> Helper loaded: url_helper
INFO - 2018-03-25 07:55:56 --> Helper loaded: form_helper
INFO - 2018-03-25 07:55:56 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:55:56 --> Controller Class Initialized
INFO - 2018-03-25 07:55:56 --> Model Class Initialized
INFO - 2018-03-25 07:55:56 --> Model Class Initialized
INFO - 2018-03-25 07:55:56 --> Helper loaded: date_helper
INFO - 2018-03-25 07:55:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:55:56 --> Final output sent to browser
DEBUG - 2018-03-25 12:55:56 --> Total execution time: 0.0840
INFO - 2018-03-25 07:56:07 --> Config Class Initialized
INFO - 2018-03-25 07:56:07 --> Hooks Class Initialized
DEBUG - 2018-03-25 07:56:07 --> UTF-8 Support Enabled
INFO - 2018-03-25 07:56:07 --> Utf8 Class Initialized
INFO - 2018-03-25 07:56:07 --> URI Class Initialized
INFO - 2018-03-25 07:56:07 --> Router Class Initialized
INFO - 2018-03-25 07:56:07 --> Output Class Initialized
INFO - 2018-03-25 07:56:07 --> Security Class Initialized
DEBUG - 2018-03-25 07:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 07:56:07 --> Input Class Initialized
INFO - 2018-03-25 07:56:07 --> Language Class Initialized
INFO - 2018-03-25 07:56:07 --> Loader Class Initialized
INFO - 2018-03-25 07:56:07 --> Helper loaded: url_helper
INFO - 2018-03-25 07:56:07 --> Helper loaded: form_helper
INFO - 2018-03-25 07:56:07 --> Database Driver Class Initialized
DEBUG - 2018-03-25 07:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 07:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 07:56:07 --> Controller Class Initialized
INFO - 2018-03-25 07:56:07 --> Model Class Initialized
INFO - 2018-03-25 07:56:07 --> Model Class Initialized
INFO - 2018-03-25 07:56:07 --> Model Class Initialized
INFO - 2018-03-25 07:56:07 --> Model Class Initialized
INFO - 2018-03-25 07:56:07 --> Model Class Initialized
INFO - 2018-03-25 07:56:07 --> Model Class Initialized
INFO - 2018-03-25 07:56:07 --> Helper loaded: date_helper
INFO - 2018-03-25 07:56:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 12:56:07 --> Final output sent to browser
DEBUG - 2018-03-25 12:56:07 --> Total execution time: 0.0889
INFO - 2018-03-25 08:00:18 --> Config Class Initialized
INFO - 2018-03-25 08:00:18 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:00:18 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:00:18 --> Utf8 Class Initialized
INFO - 2018-03-25 08:00:18 --> URI Class Initialized
INFO - 2018-03-25 08:00:18 --> Router Class Initialized
INFO - 2018-03-25 08:00:18 --> Output Class Initialized
INFO - 2018-03-25 08:00:18 --> Security Class Initialized
DEBUG - 2018-03-25 08:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:00:18 --> Input Class Initialized
INFO - 2018-03-25 08:00:18 --> Language Class Initialized
INFO - 2018-03-25 08:00:18 --> Loader Class Initialized
INFO - 2018-03-25 08:00:18 --> Helper loaded: url_helper
INFO - 2018-03-25 08:00:18 --> Helper loaded: form_helper
INFO - 2018-03-25 08:00:18 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:00:18 --> Controller Class Initialized
INFO - 2018-03-25 08:00:18 --> Model Class Initialized
INFO - 2018-03-25 08:00:18 --> Model Class Initialized
INFO - 2018-03-25 08:00:18 --> Model Class Initialized
INFO - 2018-03-25 08:00:18 --> Model Class Initialized
INFO - 2018-03-25 08:00:18 --> Model Class Initialized
INFO - 2018-03-25 08:00:18 --> Model Class Initialized
INFO - 2018-03-25 08:00:18 --> Helper loaded: date_helper
INFO - 2018-03-25 08:00:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:00:18 --> Model Class Initialized
INFO - 2018-03-25 13:00:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:00:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:00:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:00:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:00:18 --> Final output sent to browser
DEBUG - 2018-03-25 13:00:18 --> Total execution time: 0.1251
INFO - 2018-03-25 08:01:04 --> Config Class Initialized
INFO - 2018-03-25 08:01:04 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:01:04 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:01:04 --> Utf8 Class Initialized
INFO - 2018-03-25 08:01:04 --> URI Class Initialized
INFO - 2018-03-25 08:01:04 --> Router Class Initialized
INFO - 2018-03-25 08:01:04 --> Output Class Initialized
INFO - 2018-03-25 08:01:04 --> Security Class Initialized
DEBUG - 2018-03-25 08:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:01:04 --> Input Class Initialized
INFO - 2018-03-25 08:01:04 --> Language Class Initialized
INFO - 2018-03-25 08:01:04 --> Loader Class Initialized
INFO - 2018-03-25 08:01:04 --> Helper loaded: url_helper
INFO - 2018-03-25 08:01:04 --> Helper loaded: form_helper
INFO - 2018-03-25 08:01:04 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:01:04 --> Controller Class Initialized
INFO - 2018-03-25 08:01:04 --> Model Class Initialized
INFO - 2018-03-25 08:01:04 --> Model Class Initialized
INFO - 2018-03-25 08:01:04 --> Model Class Initialized
INFO - 2018-03-25 08:01:04 --> Model Class Initialized
INFO - 2018-03-25 08:01:04 --> Model Class Initialized
INFO - 2018-03-25 08:01:04 --> Model Class Initialized
INFO - 2018-03-25 08:01:04 --> Helper loaded: date_helper
INFO - 2018-03-25 08:01:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:01:04 --> Model Class Initialized
INFO - 2018-03-25 13:01:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:01:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:01:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:01:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:01:04 --> Final output sent to browser
DEBUG - 2018-03-25 13:01:04 --> Total execution time: 0.1191
INFO - 2018-03-25 08:01:18 --> Config Class Initialized
INFO - 2018-03-25 08:01:18 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:01:18 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:01:18 --> Utf8 Class Initialized
INFO - 2018-03-25 08:01:18 --> URI Class Initialized
INFO - 2018-03-25 08:01:18 --> Router Class Initialized
INFO - 2018-03-25 08:01:18 --> Output Class Initialized
INFO - 2018-03-25 08:01:18 --> Security Class Initialized
DEBUG - 2018-03-25 08:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:01:18 --> Input Class Initialized
INFO - 2018-03-25 08:01:18 --> Language Class Initialized
INFO - 2018-03-25 08:01:18 --> Loader Class Initialized
INFO - 2018-03-25 08:01:18 --> Helper loaded: url_helper
INFO - 2018-03-25 08:01:18 --> Helper loaded: form_helper
INFO - 2018-03-25 08:01:18 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:01:18 --> Controller Class Initialized
INFO - 2018-03-25 08:01:18 --> Model Class Initialized
INFO - 2018-03-25 08:01:18 --> Model Class Initialized
INFO - 2018-03-25 08:01:18 --> Model Class Initialized
INFO - 2018-03-25 08:01:18 --> Model Class Initialized
INFO - 2018-03-25 08:01:18 --> Model Class Initialized
INFO - 2018-03-25 08:01:18 --> Model Class Initialized
INFO - 2018-03-25 08:01:18 --> Helper loaded: date_helper
INFO - 2018-03-25 08:01:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:01:18 --> Model Class Initialized
INFO - 2018-03-25 13:01:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:01:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:01:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:01:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:01:18 --> Final output sent to browser
DEBUG - 2018-03-25 13:01:18 --> Total execution time: 0.1157
INFO - 2018-03-25 08:01:51 --> Config Class Initialized
INFO - 2018-03-25 08:01:51 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:01:51 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:01:51 --> Utf8 Class Initialized
INFO - 2018-03-25 08:01:51 --> URI Class Initialized
INFO - 2018-03-25 08:01:51 --> Router Class Initialized
INFO - 2018-03-25 08:01:51 --> Output Class Initialized
INFO - 2018-03-25 08:01:51 --> Security Class Initialized
DEBUG - 2018-03-25 08:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:01:51 --> Input Class Initialized
INFO - 2018-03-25 08:01:51 --> Language Class Initialized
INFO - 2018-03-25 08:01:51 --> Loader Class Initialized
INFO - 2018-03-25 08:01:51 --> Helper loaded: url_helper
INFO - 2018-03-25 08:01:51 --> Helper loaded: form_helper
INFO - 2018-03-25 08:01:51 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:01:51 --> Controller Class Initialized
INFO - 2018-03-25 08:01:51 --> Model Class Initialized
INFO - 2018-03-25 08:01:51 --> Model Class Initialized
INFO - 2018-03-25 08:01:51 --> Model Class Initialized
INFO - 2018-03-25 08:01:51 --> Model Class Initialized
INFO - 2018-03-25 08:01:51 --> Model Class Initialized
INFO - 2018-03-25 08:01:51 --> Model Class Initialized
INFO - 2018-03-25 08:01:51 --> Helper loaded: date_helper
INFO - 2018-03-25 08:01:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:01:51 --> Model Class Initialized
INFO - 2018-03-25 13:01:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:01:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:01:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:01:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:01:51 --> Final output sent to browser
DEBUG - 2018-03-25 13:01:51 --> Total execution time: 0.1205
INFO - 2018-03-25 08:02:09 --> Config Class Initialized
INFO - 2018-03-25 08:02:09 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:02:09 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:02:09 --> Utf8 Class Initialized
INFO - 2018-03-25 08:02:09 --> URI Class Initialized
INFO - 2018-03-25 08:02:09 --> Router Class Initialized
INFO - 2018-03-25 08:02:09 --> Output Class Initialized
INFO - 2018-03-25 08:02:09 --> Security Class Initialized
DEBUG - 2018-03-25 08:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:02:09 --> Input Class Initialized
INFO - 2018-03-25 08:02:09 --> Language Class Initialized
INFO - 2018-03-25 08:02:09 --> Loader Class Initialized
INFO - 2018-03-25 08:02:09 --> Helper loaded: url_helper
INFO - 2018-03-25 08:02:09 --> Helper loaded: form_helper
INFO - 2018-03-25 08:02:09 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:02:09 --> Controller Class Initialized
INFO - 2018-03-25 08:02:09 --> Model Class Initialized
INFO - 2018-03-25 08:02:09 --> Model Class Initialized
INFO - 2018-03-25 08:02:09 --> Model Class Initialized
INFO - 2018-03-25 08:02:09 --> Model Class Initialized
INFO - 2018-03-25 08:02:09 --> Model Class Initialized
INFO - 2018-03-25 08:02:09 --> Model Class Initialized
INFO - 2018-03-25 08:02:09 --> Helper loaded: date_helper
INFO - 2018-03-25 08:02:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:02:09 --> Model Class Initialized
INFO - 2018-03-25 13:02:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:02:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:02:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:02:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:02:09 --> Final output sent to browser
DEBUG - 2018-03-25 13:02:09 --> Total execution time: 0.1100
INFO - 2018-03-25 08:02:23 --> Config Class Initialized
INFO - 2018-03-25 08:02:23 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:02:23 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:02:23 --> Utf8 Class Initialized
INFO - 2018-03-25 08:02:23 --> URI Class Initialized
INFO - 2018-03-25 08:02:23 --> Router Class Initialized
INFO - 2018-03-25 08:02:23 --> Output Class Initialized
INFO - 2018-03-25 08:02:23 --> Security Class Initialized
DEBUG - 2018-03-25 08:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:02:23 --> Input Class Initialized
INFO - 2018-03-25 08:02:23 --> Language Class Initialized
INFO - 2018-03-25 08:02:23 --> Loader Class Initialized
INFO - 2018-03-25 08:02:23 --> Helper loaded: url_helper
INFO - 2018-03-25 08:02:23 --> Helper loaded: form_helper
INFO - 2018-03-25 08:02:23 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:02:23 --> Controller Class Initialized
INFO - 2018-03-25 08:02:23 --> Model Class Initialized
INFO - 2018-03-25 08:02:23 --> Model Class Initialized
INFO - 2018-03-25 08:02:23 --> Model Class Initialized
INFO - 2018-03-25 08:02:23 --> Model Class Initialized
INFO - 2018-03-25 08:02:23 --> Model Class Initialized
INFO - 2018-03-25 08:02:23 --> Model Class Initialized
INFO - 2018-03-25 08:02:23 --> Helper loaded: date_helper
INFO - 2018-03-25 08:02:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:02:23 --> Model Class Initialized
INFO - 2018-03-25 13:02:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:02:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:02:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:02:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:02:24 --> Final output sent to browser
DEBUG - 2018-03-25 13:02:24 --> Total execution time: 0.1288
INFO - 2018-03-25 08:02:37 --> Config Class Initialized
INFO - 2018-03-25 08:02:37 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:02:37 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:02:37 --> Utf8 Class Initialized
INFO - 2018-03-25 08:02:37 --> URI Class Initialized
INFO - 2018-03-25 08:02:37 --> Router Class Initialized
INFO - 2018-03-25 08:02:37 --> Output Class Initialized
INFO - 2018-03-25 08:02:37 --> Security Class Initialized
DEBUG - 2018-03-25 08:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:02:37 --> Input Class Initialized
INFO - 2018-03-25 08:02:37 --> Language Class Initialized
INFO - 2018-03-25 08:02:37 --> Loader Class Initialized
INFO - 2018-03-25 08:02:37 --> Helper loaded: url_helper
INFO - 2018-03-25 08:02:37 --> Helper loaded: form_helper
INFO - 2018-03-25 08:02:37 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:02:37 --> Controller Class Initialized
INFO - 2018-03-25 08:02:37 --> Model Class Initialized
INFO - 2018-03-25 08:02:37 --> Model Class Initialized
INFO - 2018-03-25 08:02:37 --> Model Class Initialized
INFO - 2018-03-25 08:02:37 --> Model Class Initialized
INFO - 2018-03-25 08:02:37 --> Model Class Initialized
INFO - 2018-03-25 08:02:37 --> Model Class Initialized
INFO - 2018-03-25 08:02:37 --> Helper loaded: date_helper
INFO - 2018-03-25 08:02:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:02:37 --> Model Class Initialized
INFO - 2018-03-25 13:02:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:02:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:02:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:02:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:02:37 --> Final output sent to browser
DEBUG - 2018-03-25 13:02:37 --> Total execution time: 0.1114
INFO - 2018-03-25 08:05:26 --> Config Class Initialized
INFO - 2018-03-25 08:05:26 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:05:26 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:05:26 --> Utf8 Class Initialized
INFO - 2018-03-25 08:05:26 --> URI Class Initialized
INFO - 2018-03-25 08:05:26 --> Router Class Initialized
INFO - 2018-03-25 08:05:26 --> Output Class Initialized
INFO - 2018-03-25 08:05:26 --> Security Class Initialized
DEBUG - 2018-03-25 08:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:05:26 --> Input Class Initialized
INFO - 2018-03-25 08:05:26 --> Language Class Initialized
INFO - 2018-03-25 08:05:26 --> Loader Class Initialized
INFO - 2018-03-25 08:05:26 --> Helper loaded: url_helper
INFO - 2018-03-25 08:05:26 --> Helper loaded: form_helper
INFO - 2018-03-25 08:05:26 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:05:26 --> Controller Class Initialized
INFO - 2018-03-25 08:05:26 --> Model Class Initialized
INFO - 2018-03-25 08:05:26 --> Model Class Initialized
INFO - 2018-03-25 08:05:26 --> Model Class Initialized
INFO - 2018-03-25 08:05:26 --> Model Class Initialized
INFO - 2018-03-25 08:05:26 --> Model Class Initialized
INFO - 2018-03-25 08:05:26 --> Model Class Initialized
INFO - 2018-03-25 08:05:26 --> Helper loaded: date_helper
INFO - 2018-03-25 08:05:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:05:26 --> Model Class Initialized
INFO - 2018-03-25 13:05:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:05:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:05:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:05:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:05:26 --> Final output sent to browser
DEBUG - 2018-03-25 13:05:26 --> Total execution time: 0.1180
INFO - 2018-03-25 08:06:26 --> Config Class Initialized
INFO - 2018-03-25 08:06:26 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:06:26 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:06:26 --> Utf8 Class Initialized
INFO - 2018-03-25 08:06:27 --> URI Class Initialized
INFO - 2018-03-25 08:06:27 --> Router Class Initialized
INFO - 2018-03-25 08:06:27 --> Output Class Initialized
INFO - 2018-03-25 08:06:27 --> Security Class Initialized
DEBUG - 2018-03-25 08:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:06:27 --> Input Class Initialized
INFO - 2018-03-25 08:06:27 --> Language Class Initialized
INFO - 2018-03-25 08:06:27 --> Loader Class Initialized
INFO - 2018-03-25 08:06:27 --> Helper loaded: url_helper
INFO - 2018-03-25 08:06:27 --> Helper loaded: form_helper
INFO - 2018-03-25 08:06:27 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:06:27 --> Controller Class Initialized
INFO - 2018-03-25 08:06:27 --> Model Class Initialized
INFO - 2018-03-25 08:06:27 --> Model Class Initialized
INFO - 2018-03-25 08:06:27 --> Model Class Initialized
INFO - 2018-03-25 08:06:27 --> Model Class Initialized
INFO - 2018-03-25 08:06:27 --> Model Class Initialized
INFO - 2018-03-25 08:06:27 --> Model Class Initialized
INFO - 2018-03-25 08:06:27 --> Helper loaded: date_helper
INFO - 2018-03-25 08:06:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:06:27 --> Model Class Initialized
INFO - 2018-03-25 13:06:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:06:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:06:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:06:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:06:27 --> Final output sent to browser
DEBUG - 2018-03-25 13:06:27 --> Total execution time: 0.1452
INFO - 2018-03-25 08:06:42 --> Config Class Initialized
INFO - 2018-03-25 08:06:42 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:06:42 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:06:42 --> Utf8 Class Initialized
INFO - 2018-03-25 08:06:42 --> URI Class Initialized
INFO - 2018-03-25 08:06:42 --> Router Class Initialized
INFO - 2018-03-25 08:06:42 --> Output Class Initialized
INFO - 2018-03-25 08:06:42 --> Security Class Initialized
DEBUG - 2018-03-25 08:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:06:42 --> Input Class Initialized
INFO - 2018-03-25 08:06:42 --> Language Class Initialized
INFO - 2018-03-25 08:06:42 --> Loader Class Initialized
INFO - 2018-03-25 08:06:42 --> Helper loaded: url_helper
INFO - 2018-03-25 08:06:42 --> Helper loaded: form_helper
INFO - 2018-03-25 08:06:42 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:06:42 --> Controller Class Initialized
INFO - 2018-03-25 08:06:42 --> Model Class Initialized
INFO - 2018-03-25 08:06:42 --> Model Class Initialized
INFO - 2018-03-25 08:06:42 --> Model Class Initialized
INFO - 2018-03-25 08:06:42 --> Model Class Initialized
INFO - 2018-03-25 08:06:42 --> Model Class Initialized
INFO - 2018-03-25 08:06:42 --> Model Class Initialized
INFO - 2018-03-25 08:06:42 --> Helper loaded: date_helper
INFO - 2018-03-25 08:06:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:06:42 --> Model Class Initialized
INFO - 2018-03-25 13:06:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:06:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:06:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:06:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:06:43 --> Final output sent to browser
DEBUG - 2018-03-25 13:06:43 --> Total execution time: 0.1510
INFO - 2018-03-25 08:07:57 --> Config Class Initialized
INFO - 2018-03-25 08:07:57 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:07:57 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:07:57 --> Utf8 Class Initialized
INFO - 2018-03-25 08:07:57 --> URI Class Initialized
INFO - 2018-03-25 08:07:57 --> Router Class Initialized
INFO - 2018-03-25 08:07:57 --> Output Class Initialized
INFO - 2018-03-25 08:07:57 --> Security Class Initialized
DEBUG - 2018-03-25 08:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:07:57 --> Input Class Initialized
INFO - 2018-03-25 08:07:57 --> Language Class Initialized
INFO - 2018-03-25 08:07:57 --> Loader Class Initialized
INFO - 2018-03-25 08:07:57 --> Helper loaded: url_helper
INFO - 2018-03-25 08:07:57 --> Helper loaded: form_helper
INFO - 2018-03-25 08:07:57 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:07:57 --> Controller Class Initialized
INFO - 2018-03-25 08:07:57 --> Model Class Initialized
INFO - 2018-03-25 08:07:57 --> Model Class Initialized
INFO - 2018-03-25 08:07:57 --> Model Class Initialized
INFO - 2018-03-25 08:07:57 --> Model Class Initialized
INFO - 2018-03-25 08:07:57 --> Model Class Initialized
INFO - 2018-03-25 08:07:57 --> Model Class Initialized
INFO - 2018-03-25 08:07:57 --> Helper loaded: date_helper
INFO - 2018-03-25 08:07:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:07:57 --> Model Class Initialized
INFO - 2018-03-25 13:07:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:07:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:07:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:07:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:07:57 --> Final output sent to browser
DEBUG - 2018-03-25 13:07:57 --> Total execution time: 0.1108
INFO - 2018-03-25 08:08:00 --> Config Class Initialized
INFO - 2018-03-25 08:08:00 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:08:00 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:08:00 --> Utf8 Class Initialized
INFO - 2018-03-25 08:08:00 --> URI Class Initialized
INFO - 2018-03-25 08:08:00 --> Router Class Initialized
INFO - 2018-03-25 08:08:00 --> Output Class Initialized
INFO - 2018-03-25 08:08:00 --> Security Class Initialized
DEBUG - 2018-03-25 08:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:08:00 --> Input Class Initialized
INFO - 2018-03-25 08:08:00 --> Language Class Initialized
INFO - 2018-03-25 08:08:00 --> Loader Class Initialized
INFO - 2018-03-25 08:08:00 --> Helper loaded: url_helper
INFO - 2018-03-25 08:08:00 --> Helper loaded: form_helper
INFO - 2018-03-25 08:08:00 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:08:00 --> Controller Class Initialized
INFO - 2018-03-25 08:08:00 --> Model Class Initialized
INFO - 2018-03-25 08:08:00 --> Model Class Initialized
INFO - 2018-03-25 08:08:00 --> Model Class Initialized
INFO - 2018-03-25 08:08:00 --> Model Class Initialized
INFO - 2018-03-25 08:08:00 --> Model Class Initialized
INFO - 2018-03-25 08:08:00 --> Model Class Initialized
INFO - 2018-03-25 08:08:00 --> Helper loaded: date_helper
INFO - 2018-03-25 08:08:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:08:00 --> Model Class Initialized
INFO - 2018-03-25 13:08:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:08:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:08:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:08:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:08:00 --> Final output sent to browser
DEBUG - 2018-03-25 13:08:00 --> Total execution time: 0.1042
INFO - 2018-03-25 08:08:03 --> Config Class Initialized
INFO - 2018-03-25 08:08:03 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:08:03 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:08:03 --> Utf8 Class Initialized
INFO - 2018-03-25 08:08:03 --> URI Class Initialized
INFO - 2018-03-25 08:08:03 --> Router Class Initialized
INFO - 2018-03-25 08:08:03 --> Output Class Initialized
INFO - 2018-03-25 08:08:03 --> Security Class Initialized
DEBUG - 2018-03-25 08:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:08:03 --> Input Class Initialized
INFO - 2018-03-25 08:08:03 --> Language Class Initialized
INFO - 2018-03-25 08:08:03 --> Loader Class Initialized
INFO - 2018-03-25 08:08:03 --> Helper loaded: url_helper
INFO - 2018-03-25 08:08:03 --> Helper loaded: form_helper
INFO - 2018-03-25 08:08:03 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:08:03 --> Controller Class Initialized
INFO - 2018-03-25 08:08:03 --> Model Class Initialized
INFO - 2018-03-25 08:08:03 --> Model Class Initialized
INFO - 2018-03-25 08:08:03 --> Model Class Initialized
INFO - 2018-03-25 08:08:03 --> Model Class Initialized
INFO - 2018-03-25 08:08:03 --> Model Class Initialized
INFO - 2018-03-25 08:08:03 --> Model Class Initialized
INFO - 2018-03-25 08:08:03 --> Helper loaded: date_helper
INFO - 2018-03-25 08:08:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:08:03 --> Model Class Initialized
INFO - 2018-03-25 13:08:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:08:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:08:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:08:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:08:03 --> Final output sent to browser
DEBUG - 2018-03-25 13:08:03 --> Total execution time: 0.1048
INFO - 2018-03-25 08:08:05 --> Config Class Initialized
INFO - 2018-03-25 08:08:05 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:08:05 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:08:05 --> Utf8 Class Initialized
INFO - 2018-03-25 08:08:05 --> URI Class Initialized
INFO - 2018-03-25 08:08:05 --> Router Class Initialized
INFO - 2018-03-25 08:08:05 --> Output Class Initialized
INFO - 2018-03-25 08:08:05 --> Security Class Initialized
DEBUG - 2018-03-25 08:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:08:05 --> Input Class Initialized
INFO - 2018-03-25 08:08:05 --> Language Class Initialized
INFO - 2018-03-25 08:08:05 --> Loader Class Initialized
INFO - 2018-03-25 08:08:05 --> Helper loaded: url_helper
INFO - 2018-03-25 08:08:05 --> Helper loaded: form_helper
INFO - 2018-03-25 08:08:05 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:08:05 --> Controller Class Initialized
INFO - 2018-03-25 08:08:05 --> Model Class Initialized
INFO - 2018-03-25 08:08:05 --> Model Class Initialized
INFO - 2018-03-25 08:08:05 --> Model Class Initialized
INFO - 2018-03-25 08:08:05 --> Model Class Initialized
INFO - 2018-03-25 08:08:05 --> Model Class Initialized
INFO - 2018-03-25 08:08:05 --> Model Class Initialized
INFO - 2018-03-25 08:08:05 --> Helper loaded: date_helper
INFO - 2018-03-25 08:08:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:08:05 --> Model Class Initialized
INFO - 2018-03-25 13:08:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:08:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:08:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:08:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:08:05 --> Final output sent to browser
DEBUG - 2018-03-25 13:08:05 --> Total execution time: 0.0965
INFO - 2018-03-25 08:11:13 --> Config Class Initialized
INFO - 2018-03-25 08:11:13 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:11:13 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:11:13 --> Utf8 Class Initialized
INFO - 2018-03-25 08:11:13 --> URI Class Initialized
INFO - 2018-03-25 08:11:13 --> Router Class Initialized
INFO - 2018-03-25 08:11:13 --> Output Class Initialized
INFO - 2018-03-25 08:11:13 --> Security Class Initialized
DEBUG - 2018-03-25 08:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:11:13 --> Input Class Initialized
INFO - 2018-03-25 08:11:13 --> Language Class Initialized
INFO - 2018-03-25 08:11:13 --> Loader Class Initialized
INFO - 2018-03-25 08:11:13 --> Helper loaded: url_helper
INFO - 2018-03-25 08:11:13 --> Helper loaded: form_helper
INFO - 2018-03-25 08:11:13 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:11:13 --> Controller Class Initialized
INFO - 2018-03-25 08:11:13 --> Model Class Initialized
INFO - 2018-03-25 08:11:13 --> Model Class Initialized
INFO - 2018-03-25 08:11:13 --> Model Class Initialized
INFO - 2018-03-25 08:11:13 --> Model Class Initialized
INFO - 2018-03-25 08:11:13 --> Model Class Initialized
INFO - 2018-03-25 08:11:13 --> Model Class Initialized
INFO - 2018-03-25 08:11:13 --> Helper loaded: date_helper
INFO - 2018-03-25 08:11:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:11:13 --> Model Class Initialized
INFO - 2018-03-25 13:11:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:11:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:11:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:11:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:11:13 --> Final output sent to browser
DEBUG - 2018-03-25 13:11:13 --> Total execution time: 0.1073
INFO - 2018-03-25 08:11:19 --> Config Class Initialized
INFO - 2018-03-25 08:11:19 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:11:19 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:11:19 --> Utf8 Class Initialized
INFO - 2018-03-25 08:11:19 --> URI Class Initialized
INFO - 2018-03-25 08:11:19 --> Router Class Initialized
INFO - 2018-03-25 08:11:19 --> Output Class Initialized
INFO - 2018-03-25 08:11:19 --> Security Class Initialized
DEBUG - 2018-03-25 08:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:11:19 --> Input Class Initialized
INFO - 2018-03-25 08:11:19 --> Language Class Initialized
INFO - 2018-03-25 08:11:19 --> Loader Class Initialized
INFO - 2018-03-25 08:11:19 --> Helper loaded: url_helper
INFO - 2018-03-25 08:11:19 --> Helper loaded: form_helper
INFO - 2018-03-25 08:11:19 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:11:19 --> Controller Class Initialized
INFO - 2018-03-25 08:11:19 --> Model Class Initialized
INFO - 2018-03-25 08:11:19 --> Model Class Initialized
INFO - 2018-03-25 08:11:19 --> Helper loaded: date_helper
INFO - 2018-03-25 08:11:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:11:19 --> Final output sent to browser
DEBUG - 2018-03-25 13:11:19 --> Total execution time: 0.0847
INFO - 2018-03-25 08:11:22 --> Config Class Initialized
INFO - 2018-03-25 08:11:22 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:11:22 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:11:22 --> Utf8 Class Initialized
INFO - 2018-03-25 08:11:22 --> URI Class Initialized
INFO - 2018-03-25 08:11:22 --> Router Class Initialized
INFO - 2018-03-25 08:11:22 --> Output Class Initialized
INFO - 2018-03-25 08:11:22 --> Security Class Initialized
DEBUG - 2018-03-25 08:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:11:22 --> Input Class Initialized
INFO - 2018-03-25 08:11:22 --> Language Class Initialized
INFO - 2018-03-25 08:11:22 --> Loader Class Initialized
INFO - 2018-03-25 08:11:22 --> Helper loaded: url_helper
INFO - 2018-03-25 08:11:22 --> Helper loaded: form_helper
INFO - 2018-03-25 08:11:23 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:11:23 --> Controller Class Initialized
INFO - 2018-03-25 08:11:23 --> Model Class Initialized
INFO - 2018-03-25 08:11:23 --> Model Class Initialized
INFO - 2018-03-25 08:11:23 --> Model Class Initialized
INFO - 2018-03-25 08:11:23 --> Model Class Initialized
INFO - 2018-03-25 08:11:23 --> Model Class Initialized
INFO - 2018-03-25 08:11:23 --> Model Class Initialized
INFO - 2018-03-25 08:11:23 --> Helper loaded: date_helper
INFO - 2018-03-25 08:11:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:11:23 --> Final output sent to browser
DEBUG - 2018-03-25 13:11:23 --> Total execution time: 0.0904
INFO - 2018-03-25 08:17:25 --> Config Class Initialized
INFO - 2018-03-25 08:17:25 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:17:25 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:17:25 --> Utf8 Class Initialized
INFO - 2018-03-25 08:17:25 --> URI Class Initialized
INFO - 2018-03-25 08:17:25 --> Router Class Initialized
INFO - 2018-03-25 08:17:25 --> Output Class Initialized
INFO - 2018-03-25 08:17:25 --> Security Class Initialized
DEBUG - 2018-03-25 08:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:17:25 --> Input Class Initialized
INFO - 2018-03-25 08:17:25 --> Language Class Initialized
INFO - 2018-03-25 08:17:25 --> Loader Class Initialized
INFO - 2018-03-25 08:17:25 --> Helper loaded: url_helper
INFO - 2018-03-25 08:17:25 --> Helper loaded: form_helper
INFO - 2018-03-25 08:17:25 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:17:25 --> Controller Class Initialized
INFO - 2018-03-25 08:17:25 --> Model Class Initialized
INFO - 2018-03-25 08:17:25 --> Model Class Initialized
INFO - 2018-03-25 08:17:25 --> Model Class Initialized
INFO - 2018-03-25 08:17:25 --> Model Class Initialized
INFO - 2018-03-25 08:17:25 --> Model Class Initialized
INFO - 2018-03-25 08:17:25 --> Model Class Initialized
INFO - 2018-03-25 08:17:25 --> Helper loaded: date_helper
INFO - 2018-03-25 08:17:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:17:25 --> Model Class Initialized
INFO - 2018-03-25 13:17:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:17:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:17:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:17:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:17:25 --> Final output sent to browser
DEBUG - 2018-03-25 13:17:25 --> Total execution time: 0.1057
INFO - 2018-03-25 08:17:30 --> Config Class Initialized
INFO - 2018-03-25 08:17:30 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:17:30 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:17:30 --> Utf8 Class Initialized
INFO - 2018-03-25 08:17:30 --> URI Class Initialized
INFO - 2018-03-25 08:17:30 --> Router Class Initialized
INFO - 2018-03-25 08:17:30 --> Output Class Initialized
INFO - 2018-03-25 08:17:30 --> Security Class Initialized
DEBUG - 2018-03-25 08:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:17:30 --> Input Class Initialized
INFO - 2018-03-25 08:17:30 --> Language Class Initialized
INFO - 2018-03-25 08:17:30 --> Loader Class Initialized
INFO - 2018-03-25 08:17:30 --> Helper loaded: url_helper
INFO - 2018-03-25 08:17:30 --> Helper loaded: form_helper
INFO - 2018-03-25 08:17:30 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:17:30 --> Controller Class Initialized
INFO - 2018-03-25 08:17:30 --> Model Class Initialized
INFO - 2018-03-25 08:17:30 --> Model Class Initialized
INFO - 2018-03-25 08:17:30 --> Helper loaded: date_helper
INFO - 2018-03-25 08:17:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:17:30 --> Final output sent to browser
DEBUG - 2018-03-25 13:17:30 --> Total execution time: 0.0918
INFO - 2018-03-25 08:17:33 --> Config Class Initialized
INFO - 2018-03-25 08:17:33 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:17:33 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:17:33 --> Utf8 Class Initialized
INFO - 2018-03-25 08:17:33 --> URI Class Initialized
INFO - 2018-03-25 08:17:33 --> Router Class Initialized
INFO - 2018-03-25 08:17:33 --> Output Class Initialized
INFO - 2018-03-25 08:17:33 --> Security Class Initialized
DEBUG - 2018-03-25 08:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:17:33 --> Input Class Initialized
INFO - 2018-03-25 08:17:33 --> Language Class Initialized
INFO - 2018-03-25 08:17:33 --> Loader Class Initialized
INFO - 2018-03-25 08:17:33 --> Helper loaded: url_helper
INFO - 2018-03-25 08:17:33 --> Helper loaded: form_helper
INFO - 2018-03-25 08:17:33 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:17:33 --> Controller Class Initialized
INFO - 2018-03-25 08:17:33 --> Model Class Initialized
INFO - 2018-03-25 08:17:33 --> Model Class Initialized
INFO - 2018-03-25 08:17:33 --> Model Class Initialized
INFO - 2018-03-25 08:17:33 --> Model Class Initialized
INFO - 2018-03-25 08:17:33 --> Model Class Initialized
INFO - 2018-03-25 08:17:33 --> Model Class Initialized
INFO - 2018-03-25 08:17:33 --> Helper loaded: date_helper
INFO - 2018-03-25 08:17:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:17:33 --> Final output sent to browser
DEBUG - 2018-03-25 13:17:33 --> Total execution time: 0.0861
INFO - 2018-03-25 08:18:41 --> Config Class Initialized
INFO - 2018-03-25 08:18:41 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:18:41 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:18:41 --> Utf8 Class Initialized
INFO - 2018-03-25 08:18:41 --> URI Class Initialized
INFO - 2018-03-25 08:18:41 --> Router Class Initialized
INFO - 2018-03-25 08:18:41 --> Output Class Initialized
INFO - 2018-03-25 08:18:41 --> Security Class Initialized
DEBUG - 2018-03-25 08:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:18:41 --> Input Class Initialized
INFO - 2018-03-25 08:18:41 --> Language Class Initialized
INFO - 2018-03-25 08:18:41 --> Loader Class Initialized
INFO - 2018-03-25 08:18:41 --> Helper loaded: url_helper
INFO - 2018-03-25 08:18:41 --> Helper loaded: form_helper
INFO - 2018-03-25 08:18:41 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:18:41 --> Controller Class Initialized
INFO - 2018-03-25 08:18:41 --> Model Class Initialized
INFO - 2018-03-25 08:18:41 --> Model Class Initialized
INFO - 2018-03-25 08:18:41 --> Model Class Initialized
INFO - 2018-03-25 08:18:41 --> Model Class Initialized
INFO - 2018-03-25 08:18:41 --> Model Class Initialized
INFO - 2018-03-25 08:18:41 --> Model Class Initialized
INFO - 2018-03-25 08:18:41 --> Helper loaded: date_helper
INFO - 2018-03-25 08:18:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:18:41 --> Model Class Initialized
INFO - 2018-03-25 13:18:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:18:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:18:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:18:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:18:41 --> Final output sent to browser
DEBUG - 2018-03-25 13:18:41 --> Total execution time: 0.1041
INFO - 2018-03-25 08:18:50 --> Config Class Initialized
INFO - 2018-03-25 08:18:50 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:18:50 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:18:50 --> Utf8 Class Initialized
INFO - 2018-03-25 08:18:50 --> URI Class Initialized
INFO - 2018-03-25 08:18:50 --> Router Class Initialized
INFO - 2018-03-25 08:18:50 --> Output Class Initialized
INFO - 2018-03-25 08:18:50 --> Security Class Initialized
DEBUG - 2018-03-25 08:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:18:50 --> Input Class Initialized
INFO - 2018-03-25 08:18:50 --> Language Class Initialized
INFO - 2018-03-25 08:18:50 --> Loader Class Initialized
INFO - 2018-03-25 08:18:50 --> Helper loaded: url_helper
INFO - 2018-03-25 08:18:50 --> Helper loaded: form_helper
INFO - 2018-03-25 08:18:50 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:18:50 --> Controller Class Initialized
INFO - 2018-03-25 08:18:50 --> Model Class Initialized
INFO - 2018-03-25 08:18:50 --> Model Class Initialized
INFO - 2018-03-25 08:18:50 --> Helper loaded: date_helper
INFO - 2018-03-25 08:18:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:18:50 --> Final output sent to browser
DEBUG - 2018-03-25 13:18:50 --> Total execution time: 0.0958
INFO - 2018-03-25 08:18:51 --> Config Class Initialized
INFO - 2018-03-25 08:18:51 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:18:51 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:18:51 --> Utf8 Class Initialized
INFO - 2018-03-25 08:18:51 --> URI Class Initialized
INFO - 2018-03-25 08:18:51 --> Router Class Initialized
INFO - 2018-03-25 08:18:51 --> Output Class Initialized
INFO - 2018-03-25 08:18:51 --> Security Class Initialized
DEBUG - 2018-03-25 08:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:18:51 --> Input Class Initialized
INFO - 2018-03-25 08:18:51 --> Language Class Initialized
INFO - 2018-03-25 08:18:51 --> Loader Class Initialized
INFO - 2018-03-25 08:18:51 --> Helper loaded: url_helper
INFO - 2018-03-25 08:18:51 --> Helper loaded: form_helper
INFO - 2018-03-25 08:18:51 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:18:51 --> Controller Class Initialized
INFO - 2018-03-25 08:18:51 --> Model Class Initialized
INFO - 2018-03-25 08:18:51 --> Model Class Initialized
INFO - 2018-03-25 08:18:51 --> Helper loaded: date_helper
INFO - 2018-03-25 08:18:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:18:51 --> Final output sent to browser
DEBUG - 2018-03-25 13:18:51 --> Total execution time: 0.0868
INFO - 2018-03-25 08:18:51 --> Config Class Initialized
INFO - 2018-03-25 08:18:51 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:18:51 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:18:51 --> Utf8 Class Initialized
INFO - 2018-03-25 08:18:51 --> URI Class Initialized
INFO - 2018-03-25 08:18:51 --> Router Class Initialized
INFO - 2018-03-25 08:18:51 --> Output Class Initialized
INFO - 2018-03-25 08:18:51 --> Security Class Initialized
DEBUG - 2018-03-25 08:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:18:51 --> Input Class Initialized
INFO - 2018-03-25 08:18:51 --> Language Class Initialized
INFO - 2018-03-25 08:18:51 --> Loader Class Initialized
INFO - 2018-03-25 08:18:51 --> Helper loaded: url_helper
INFO - 2018-03-25 08:18:51 --> Helper loaded: form_helper
INFO - 2018-03-25 08:18:51 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:18:51 --> Controller Class Initialized
INFO - 2018-03-25 08:18:51 --> Model Class Initialized
INFO - 2018-03-25 08:18:51 --> Model Class Initialized
INFO - 2018-03-25 08:18:51 --> Helper loaded: date_helper
INFO - 2018-03-25 08:18:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:18:51 --> Final output sent to browser
DEBUG - 2018-03-25 13:18:51 --> Total execution time: 0.0937
INFO - 2018-03-25 08:18:54 --> Config Class Initialized
INFO - 2018-03-25 08:18:54 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:18:54 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:18:54 --> Utf8 Class Initialized
INFO - 2018-03-25 08:18:54 --> URI Class Initialized
INFO - 2018-03-25 08:18:54 --> Router Class Initialized
INFO - 2018-03-25 08:18:54 --> Output Class Initialized
INFO - 2018-03-25 08:18:54 --> Security Class Initialized
DEBUG - 2018-03-25 08:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:18:54 --> Input Class Initialized
INFO - 2018-03-25 08:18:54 --> Language Class Initialized
INFO - 2018-03-25 08:18:54 --> Loader Class Initialized
INFO - 2018-03-25 08:18:54 --> Helper loaded: url_helper
INFO - 2018-03-25 08:18:54 --> Helper loaded: form_helper
INFO - 2018-03-25 08:18:54 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:18:54 --> Controller Class Initialized
INFO - 2018-03-25 08:18:54 --> Model Class Initialized
INFO - 2018-03-25 08:18:54 --> Model Class Initialized
INFO - 2018-03-25 08:18:54 --> Model Class Initialized
INFO - 2018-03-25 08:18:54 --> Model Class Initialized
INFO - 2018-03-25 08:18:54 --> Model Class Initialized
INFO - 2018-03-25 08:18:54 --> Model Class Initialized
INFO - 2018-03-25 08:18:54 --> Helper loaded: date_helper
INFO - 2018-03-25 08:18:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:18:54 --> Final output sent to browser
DEBUG - 2018-03-25 13:18:54 --> Total execution time: 0.1156
INFO - 2018-03-25 08:19:18 --> Config Class Initialized
INFO - 2018-03-25 08:19:18 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:19:18 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:19:18 --> Utf8 Class Initialized
INFO - 2018-03-25 08:19:18 --> URI Class Initialized
INFO - 2018-03-25 08:19:18 --> Router Class Initialized
INFO - 2018-03-25 08:19:18 --> Output Class Initialized
INFO - 2018-03-25 08:19:18 --> Security Class Initialized
DEBUG - 2018-03-25 08:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:19:18 --> Input Class Initialized
INFO - 2018-03-25 08:19:18 --> Language Class Initialized
INFO - 2018-03-25 08:19:18 --> Loader Class Initialized
INFO - 2018-03-25 08:19:18 --> Helper loaded: url_helper
INFO - 2018-03-25 08:19:18 --> Helper loaded: form_helper
INFO - 2018-03-25 08:19:18 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:19:18 --> Controller Class Initialized
INFO - 2018-03-25 08:19:18 --> Model Class Initialized
INFO - 2018-03-25 08:19:18 --> Model Class Initialized
INFO - 2018-03-25 08:19:18 --> Model Class Initialized
INFO - 2018-03-25 08:19:18 --> Model Class Initialized
INFO - 2018-03-25 08:19:18 --> Model Class Initialized
INFO - 2018-03-25 08:19:18 --> Model Class Initialized
INFO - 2018-03-25 08:19:18 --> Helper loaded: date_helper
INFO - 2018-03-25 08:19:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:19:18 --> Model Class Initialized
INFO - 2018-03-25 13:19:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:19:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:19:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:19:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:19:18 --> Final output sent to browser
DEBUG - 2018-03-25 13:19:18 --> Total execution time: 0.0960
INFO - 2018-03-25 08:19:24 --> Config Class Initialized
INFO - 2018-03-25 08:19:24 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:19:24 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:19:24 --> Utf8 Class Initialized
INFO - 2018-03-25 08:19:24 --> URI Class Initialized
INFO - 2018-03-25 08:19:24 --> Router Class Initialized
INFO - 2018-03-25 08:19:24 --> Output Class Initialized
INFO - 2018-03-25 08:19:24 --> Security Class Initialized
DEBUG - 2018-03-25 08:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:19:24 --> Input Class Initialized
INFO - 2018-03-25 08:19:24 --> Language Class Initialized
INFO - 2018-03-25 08:19:24 --> Loader Class Initialized
INFO - 2018-03-25 08:19:24 --> Helper loaded: url_helper
INFO - 2018-03-25 08:19:24 --> Helper loaded: form_helper
INFO - 2018-03-25 08:19:24 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:19:24 --> Controller Class Initialized
INFO - 2018-03-25 08:19:24 --> Model Class Initialized
INFO - 2018-03-25 08:19:24 --> Model Class Initialized
INFO - 2018-03-25 08:19:24 --> Helper loaded: date_helper
INFO - 2018-03-25 08:19:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:19:24 --> Final output sent to browser
DEBUG - 2018-03-25 13:19:24 --> Total execution time: 0.0905
INFO - 2018-03-25 08:19:29 --> Config Class Initialized
INFO - 2018-03-25 08:19:29 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:19:29 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:19:29 --> Utf8 Class Initialized
INFO - 2018-03-25 08:19:29 --> URI Class Initialized
INFO - 2018-03-25 08:19:29 --> Router Class Initialized
INFO - 2018-03-25 08:19:29 --> Output Class Initialized
INFO - 2018-03-25 08:19:29 --> Security Class Initialized
DEBUG - 2018-03-25 08:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:19:29 --> Input Class Initialized
INFO - 2018-03-25 08:19:29 --> Language Class Initialized
INFO - 2018-03-25 08:19:29 --> Loader Class Initialized
INFO - 2018-03-25 08:19:29 --> Helper loaded: url_helper
INFO - 2018-03-25 08:19:29 --> Helper loaded: form_helper
INFO - 2018-03-25 08:19:29 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:19:29 --> Controller Class Initialized
INFO - 2018-03-25 08:19:29 --> Model Class Initialized
INFO - 2018-03-25 08:19:29 --> Model Class Initialized
INFO - 2018-03-25 08:19:29 --> Model Class Initialized
INFO - 2018-03-25 08:19:29 --> Model Class Initialized
INFO - 2018-03-25 08:19:29 --> Model Class Initialized
INFO - 2018-03-25 08:19:29 --> Model Class Initialized
INFO - 2018-03-25 08:19:29 --> Helper loaded: date_helper
INFO - 2018-03-25 08:19:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:19:29 --> Final output sent to browser
DEBUG - 2018-03-25 13:19:29 --> Total execution time: 0.1182
INFO - 2018-03-25 08:20:21 --> Config Class Initialized
INFO - 2018-03-25 08:20:21 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:20:21 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:20:21 --> Utf8 Class Initialized
INFO - 2018-03-25 08:20:21 --> URI Class Initialized
INFO - 2018-03-25 08:20:21 --> Router Class Initialized
INFO - 2018-03-25 08:20:21 --> Output Class Initialized
INFO - 2018-03-25 08:20:21 --> Security Class Initialized
DEBUG - 2018-03-25 08:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:20:21 --> Input Class Initialized
INFO - 2018-03-25 08:20:21 --> Language Class Initialized
INFO - 2018-03-25 08:20:21 --> Loader Class Initialized
INFO - 2018-03-25 08:20:21 --> Helper loaded: url_helper
INFO - 2018-03-25 08:20:21 --> Helper loaded: form_helper
INFO - 2018-03-25 08:20:21 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:20:21 --> Controller Class Initialized
INFO - 2018-03-25 08:20:21 --> Model Class Initialized
INFO - 2018-03-25 08:20:21 --> Model Class Initialized
INFO - 2018-03-25 08:20:21 --> Model Class Initialized
INFO - 2018-03-25 08:20:21 --> Model Class Initialized
INFO - 2018-03-25 08:20:21 --> Model Class Initialized
INFO - 2018-03-25 08:20:21 --> Model Class Initialized
INFO - 2018-03-25 08:20:21 --> Helper loaded: date_helper
INFO - 2018-03-25 08:20:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:20:21 --> Model Class Initialized
INFO - 2018-03-25 13:20:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:20:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:20:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:20:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:20:21 --> Final output sent to browser
DEBUG - 2018-03-25 13:20:21 --> Total execution time: 0.1092
INFO - 2018-03-25 08:20:25 --> Config Class Initialized
INFO - 2018-03-25 08:20:25 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:20:25 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:20:25 --> Utf8 Class Initialized
INFO - 2018-03-25 08:20:25 --> URI Class Initialized
INFO - 2018-03-25 08:20:25 --> Router Class Initialized
INFO - 2018-03-25 08:20:25 --> Output Class Initialized
INFO - 2018-03-25 08:20:25 --> Security Class Initialized
DEBUG - 2018-03-25 08:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:20:25 --> Input Class Initialized
INFO - 2018-03-25 08:20:25 --> Language Class Initialized
INFO - 2018-03-25 08:20:25 --> Loader Class Initialized
INFO - 2018-03-25 08:20:25 --> Helper loaded: url_helper
INFO - 2018-03-25 08:20:25 --> Helper loaded: form_helper
INFO - 2018-03-25 08:20:25 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:20:25 --> Controller Class Initialized
INFO - 2018-03-25 08:20:25 --> Model Class Initialized
INFO - 2018-03-25 08:20:25 --> Model Class Initialized
INFO - 2018-03-25 08:20:25 --> Model Class Initialized
INFO - 2018-03-25 08:20:25 --> Model Class Initialized
INFO - 2018-03-25 08:20:25 --> Model Class Initialized
INFO - 2018-03-25 08:20:25 --> Model Class Initialized
INFO - 2018-03-25 08:20:25 --> Helper loaded: date_helper
INFO - 2018-03-25 08:20:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:20:25 --> Model Class Initialized
INFO - 2018-03-25 13:20:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:20:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:20:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:20:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:20:25 --> Final output sent to browser
DEBUG - 2018-03-25 13:20:25 --> Total execution time: 0.0941
INFO - 2018-03-25 08:20:27 --> Config Class Initialized
INFO - 2018-03-25 08:20:27 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:20:27 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:20:27 --> Utf8 Class Initialized
INFO - 2018-03-25 08:20:27 --> URI Class Initialized
INFO - 2018-03-25 08:20:27 --> Router Class Initialized
INFO - 2018-03-25 08:20:27 --> Output Class Initialized
INFO - 2018-03-25 08:20:27 --> Security Class Initialized
DEBUG - 2018-03-25 08:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:20:27 --> Input Class Initialized
INFO - 2018-03-25 08:20:27 --> Language Class Initialized
INFO - 2018-03-25 08:20:27 --> Loader Class Initialized
INFO - 2018-03-25 08:20:27 --> Helper loaded: url_helper
INFO - 2018-03-25 08:20:27 --> Helper loaded: form_helper
INFO - 2018-03-25 08:20:27 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:20:27 --> Controller Class Initialized
INFO - 2018-03-25 08:20:27 --> Model Class Initialized
INFO - 2018-03-25 08:20:27 --> Model Class Initialized
INFO - 2018-03-25 08:20:27 --> Model Class Initialized
INFO - 2018-03-25 08:20:27 --> Model Class Initialized
INFO - 2018-03-25 08:20:27 --> Model Class Initialized
INFO - 2018-03-25 08:20:27 --> Model Class Initialized
INFO - 2018-03-25 08:20:27 --> Helper loaded: date_helper
INFO - 2018-03-25 08:20:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:20:27 --> Model Class Initialized
INFO - 2018-03-25 13:20:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:20:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:20:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:20:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:20:27 --> Final output sent to browser
DEBUG - 2018-03-25 13:20:27 --> Total execution time: 0.1107
INFO - 2018-03-25 08:28:50 --> Config Class Initialized
INFO - 2018-03-25 08:28:50 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:28:50 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:28:50 --> Utf8 Class Initialized
INFO - 2018-03-25 08:28:50 --> URI Class Initialized
INFO - 2018-03-25 08:28:50 --> Router Class Initialized
INFO - 2018-03-25 08:28:50 --> Output Class Initialized
INFO - 2018-03-25 08:28:50 --> Security Class Initialized
DEBUG - 2018-03-25 08:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:28:50 --> Input Class Initialized
INFO - 2018-03-25 08:28:50 --> Language Class Initialized
INFO - 2018-03-25 08:28:50 --> Loader Class Initialized
INFO - 2018-03-25 08:28:50 --> Helper loaded: url_helper
INFO - 2018-03-25 08:28:50 --> Helper loaded: form_helper
INFO - 2018-03-25 08:28:50 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:28:50 --> Controller Class Initialized
INFO - 2018-03-25 08:28:50 --> Model Class Initialized
INFO - 2018-03-25 08:28:50 --> Model Class Initialized
INFO - 2018-03-25 08:28:50 --> Model Class Initialized
INFO - 2018-03-25 08:28:50 --> Model Class Initialized
INFO - 2018-03-25 08:28:50 --> Model Class Initialized
INFO - 2018-03-25 08:28:50 --> Model Class Initialized
INFO - 2018-03-25 08:28:50 --> Helper loaded: date_helper
INFO - 2018-03-25 08:28:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:28:50 --> Model Class Initialized
INFO - 2018-03-25 13:28:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:28:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:28:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:28:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:28:50 --> Final output sent to browser
DEBUG - 2018-03-25 13:28:50 --> Total execution time: 0.1177
INFO - 2018-03-25 08:28:54 --> Config Class Initialized
INFO - 2018-03-25 08:28:54 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:28:54 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:28:54 --> Utf8 Class Initialized
INFO - 2018-03-25 08:28:54 --> URI Class Initialized
INFO - 2018-03-25 08:28:54 --> Router Class Initialized
INFO - 2018-03-25 08:28:54 --> Output Class Initialized
INFO - 2018-03-25 08:28:54 --> Security Class Initialized
DEBUG - 2018-03-25 08:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:28:54 --> Input Class Initialized
INFO - 2018-03-25 08:28:54 --> Language Class Initialized
INFO - 2018-03-25 08:28:54 --> Loader Class Initialized
INFO - 2018-03-25 08:28:54 --> Helper loaded: url_helper
INFO - 2018-03-25 08:28:54 --> Helper loaded: form_helper
INFO - 2018-03-25 08:28:54 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:28:54 --> Controller Class Initialized
INFO - 2018-03-25 08:28:54 --> Model Class Initialized
INFO - 2018-03-25 08:28:54 --> Model Class Initialized
INFO - 2018-03-25 08:28:54 --> Helper loaded: date_helper
INFO - 2018-03-25 08:28:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:28:54 --> Final output sent to browser
DEBUG - 2018-03-25 13:28:54 --> Total execution time: 0.0947
INFO - 2018-03-25 08:28:59 --> Config Class Initialized
INFO - 2018-03-25 08:28:59 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:28:59 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:28:59 --> Utf8 Class Initialized
INFO - 2018-03-25 08:28:59 --> URI Class Initialized
INFO - 2018-03-25 08:28:59 --> Router Class Initialized
INFO - 2018-03-25 08:28:59 --> Output Class Initialized
INFO - 2018-03-25 08:28:59 --> Security Class Initialized
DEBUG - 2018-03-25 08:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:28:59 --> Input Class Initialized
INFO - 2018-03-25 08:28:59 --> Language Class Initialized
INFO - 2018-03-25 08:28:59 --> Loader Class Initialized
INFO - 2018-03-25 08:28:59 --> Helper loaded: url_helper
INFO - 2018-03-25 08:28:59 --> Helper loaded: form_helper
INFO - 2018-03-25 08:28:59 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:28:59 --> Controller Class Initialized
INFO - 2018-03-25 08:28:59 --> Model Class Initialized
INFO - 2018-03-25 08:28:59 --> Model Class Initialized
INFO - 2018-03-25 08:28:59 --> Model Class Initialized
INFO - 2018-03-25 08:28:59 --> Model Class Initialized
INFO - 2018-03-25 08:28:59 --> Model Class Initialized
INFO - 2018-03-25 08:28:59 --> Model Class Initialized
INFO - 2018-03-25 08:28:59 --> Helper loaded: date_helper
INFO - 2018-03-25 08:28:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:28:59 --> Final output sent to browser
DEBUG - 2018-03-25 13:28:59 --> Total execution time: 0.1022
INFO - 2018-03-25 08:32:34 --> Config Class Initialized
INFO - 2018-03-25 08:32:34 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:32:34 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:32:34 --> Utf8 Class Initialized
INFO - 2018-03-25 08:32:34 --> URI Class Initialized
INFO - 2018-03-25 08:32:34 --> Router Class Initialized
INFO - 2018-03-25 08:32:34 --> Output Class Initialized
INFO - 2018-03-25 08:32:34 --> Security Class Initialized
DEBUG - 2018-03-25 08:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:32:34 --> Input Class Initialized
INFO - 2018-03-25 08:32:34 --> Language Class Initialized
INFO - 2018-03-25 08:32:34 --> Loader Class Initialized
INFO - 2018-03-25 08:32:34 --> Helper loaded: url_helper
INFO - 2018-03-25 08:32:34 --> Helper loaded: form_helper
INFO - 2018-03-25 08:32:34 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:32:34 --> Controller Class Initialized
INFO - 2018-03-25 08:32:34 --> Model Class Initialized
INFO - 2018-03-25 08:32:34 --> Model Class Initialized
INFO - 2018-03-25 08:32:34 --> Model Class Initialized
INFO - 2018-03-25 08:32:34 --> Model Class Initialized
INFO - 2018-03-25 08:32:34 --> Model Class Initialized
INFO - 2018-03-25 08:32:34 --> Model Class Initialized
INFO - 2018-03-25 08:32:34 --> Helper loaded: date_helper
INFO - 2018-03-25 08:32:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:32:34 --> Model Class Initialized
INFO - 2018-03-25 13:32:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:32:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:32:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:32:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:32:34 --> Final output sent to browser
DEBUG - 2018-03-25 13:32:34 --> Total execution time: 0.1312
INFO - 2018-03-25 08:32:38 --> Config Class Initialized
INFO - 2018-03-25 08:32:38 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:32:38 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:32:38 --> Utf8 Class Initialized
INFO - 2018-03-25 08:32:38 --> URI Class Initialized
INFO - 2018-03-25 08:32:38 --> Router Class Initialized
INFO - 2018-03-25 08:32:38 --> Output Class Initialized
INFO - 2018-03-25 08:32:38 --> Security Class Initialized
DEBUG - 2018-03-25 08:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:32:38 --> Input Class Initialized
INFO - 2018-03-25 08:32:38 --> Language Class Initialized
INFO - 2018-03-25 08:32:38 --> Loader Class Initialized
INFO - 2018-03-25 08:32:38 --> Helper loaded: url_helper
INFO - 2018-03-25 08:32:38 --> Helper loaded: form_helper
INFO - 2018-03-25 08:32:38 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:32:38 --> Controller Class Initialized
INFO - 2018-03-25 08:32:38 --> Model Class Initialized
INFO - 2018-03-25 08:32:38 --> Model Class Initialized
INFO - 2018-03-25 08:32:38 --> Helper loaded: date_helper
INFO - 2018-03-25 08:32:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:32:38 --> Final output sent to browser
DEBUG - 2018-03-25 13:32:38 --> Total execution time: 0.1011
INFO - 2018-03-25 08:32:44 --> Config Class Initialized
INFO - 2018-03-25 08:32:44 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:32:44 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:32:44 --> Utf8 Class Initialized
INFO - 2018-03-25 08:32:44 --> URI Class Initialized
INFO - 2018-03-25 08:32:44 --> Router Class Initialized
INFO - 2018-03-25 08:32:44 --> Output Class Initialized
INFO - 2018-03-25 08:32:44 --> Security Class Initialized
DEBUG - 2018-03-25 08:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:32:44 --> Input Class Initialized
INFO - 2018-03-25 08:32:44 --> Language Class Initialized
INFO - 2018-03-25 08:32:44 --> Loader Class Initialized
INFO - 2018-03-25 08:32:44 --> Helper loaded: url_helper
INFO - 2018-03-25 08:32:44 --> Helper loaded: form_helper
INFO - 2018-03-25 08:32:44 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:32:44 --> Controller Class Initialized
INFO - 2018-03-25 08:32:44 --> Model Class Initialized
INFO - 2018-03-25 08:32:44 --> Model Class Initialized
INFO - 2018-03-25 08:32:44 --> Model Class Initialized
INFO - 2018-03-25 08:32:44 --> Model Class Initialized
INFO - 2018-03-25 08:32:44 --> Model Class Initialized
INFO - 2018-03-25 08:32:44 --> Model Class Initialized
INFO - 2018-03-25 08:32:44 --> Helper loaded: date_helper
INFO - 2018-03-25 08:32:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:32:44 --> Final output sent to browser
DEBUG - 2018-03-25 13:32:44 --> Total execution time: 0.1241
INFO - 2018-03-25 08:33:19 --> Config Class Initialized
INFO - 2018-03-25 08:33:19 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:33:19 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:33:19 --> Utf8 Class Initialized
INFO - 2018-03-25 08:33:19 --> URI Class Initialized
INFO - 2018-03-25 08:33:19 --> Router Class Initialized
INFO - 2018-03-25 08:33:19 --> Output Class Initialized
INFO - 2018-03-25 08:33:19 --> Security Class Initialized
DEBUG - 2018-03-25 08:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:33:19 --> Input Class Initialized
INFO - 2018-03-25 08:33:19 --> Language Class Initialized
INFO - 2018-03-25 08:33:19 --> Loader Class Initialized
INFO - 2018-03-25 08:33:19 --> Helper loaded: url_helper
INFO - 2018-03-25 08:33:19 --> Helper loaded: form_helper
INFO - 2018-03-25 08:33:19 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:33:19 --> Controller Class Initialized
INFO - 2018-03-25 08:33:19 --> Model Class Initialized
INFO - 2018-03-25 08:33:19 --> Model Class Initialized
INFO - 2018-03-25 08:33:19 --> Model Class Initialized
INFO - 2018-03-25 08:33:19 --> Model Class Initialized
INFO - 2018-03-25 08:33:19 --> Model Class Initialized
INFO - 2018-03-25 08:33:19 --> Model Class Initialized
INFO - 2018-03-25 08:33:19 --> Helper loaded: date_helper
INFO - 2018-03-25 08:33:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:33:19 --> Model Class Initialized
INFO - 2018-03-25 13:33:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:33:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:33:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:33:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:33:19 --> Final output sent to browser
DEBUG - 2018-03-25 13:33:19 --> Total execution time: 0.1027
INFO - 2018-03-25 08:33:31 --> Config Class Initialized
INFO - 2018-03-25 08:33:31 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:33:31 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:33:31 --> Utf8 Class Initialized
INFO - 2018-03-25 08:33:31 --> URI Class Initialized
INFO - 2018-03-25 08:33:31 --> Router Class Initialized
INFO - 2018-03-25 08:33:31 --> Output Class Initialized
INFO - 2018-03-25 08:33:31 --> Security Class Initialized
DEBUG - 2018-03-25 08:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:33:31 --> Input Class Initialized
INFO - 2018-03-25 08:33:31 --> Language Class Initialized
INFO - 2018-03-25 08:33:31 --> Loader Class Initialized
INFO - 2018-03-25 08:33:31 --> Helper loaded: url_helper
INFO - 2018-03-25 08:33:31 --> Helper loaded: form_helper
INFO - 2018-03-25 08:33:31 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:33:31 --> Controller Class Initialized
INFO - 2018-03-25 08:33:31 --> Model Class Initialized
INFO - 2018-03-25 08:33:31 --> Model Class Initialized
INFO - 2018-03-25 08:33:31 --> Helper loaded: date_helper
INFO - 2018-03-25 08:33:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:33:31 --> Final output sent to browser
DEBUG - 2018-03-25 13:33:31 --> Total execution time: 0.0978
INFO - 2018-03-25 08:33:36 --> Config Class Initialized
INFO - 2018-03-25 08:33:36 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:33:36 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:33:36 --> Utf8 Class Initialized
INFO - 2018-03-25 08:33:36 --> URI Class Initialized
INFO - 2018-03-25 08:33:36 --> Router Class Initialized
INFO - 2018-03-25 08:33:36 --> Output Class Initialized
INFO - 2018-03-25 08:33:36 --> Security Class Initialized
DEBUG - 2018-03-25 08:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:33:36 --> Input Class Initialized
INFO - 2018-03-25 08:33:36 --> Language Class Initialized
INFO - 2018-03-25 08:33:36 --> Loader Class Initialized
INFO - 2018-03-25 08:33:36 --> Helper loaded: url_helper
INFO - 2018-03-25 08:33:36 --> Helper loaded: form_helper
INFO - 2018-03-25 08:33:36 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:33:36 --> Controller Class Initialized
INFO - 2018-03-25 08:33:36 --> Model Class Initialized
INFO - 2018-03-25 08:33:36 --> Model Class Initialized
INFO - 2018-03-25 08:33:36 --> Model Class Initialized
INFO - 2018-03-25 08:33:36 --> Model Class Initialized
INFO - 2018-03-25 08:33:36 --> Model Class Initialized
INFO - 2018-03-25 08:33:36 --> Model Class Initialized
INFO - 2018-03-25 08:33:36 --> Helper loaded: date_helper
INFO - 2018-03-25 08:33:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:33:36 --> Final output sent to browser
DEBUG - 2018-03-25 13:33:36 --> Total execution time: 0.1453
INFO - 2018-03-25 08:34:11 --> Config Class Initialized
INFO - 2018-03-25 08:34:11 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:34:11 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:34:11 --> Utf8 Class Initialized
INFO - 2018-03-25 08:34:11 --> URI Class Initialized
INFO - 2018-03-25 08:34:11 --> Router Class Initialized
INFO - 2018-03-25 08:34:11 --> Output Class Initialized
INFO - 2018-03-25 08:34:11 --> Security Class Initialized
DEBUG - 2018-03-25 08:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:34:11 --> Input Class Initialized
INFO - 2018-03-25 08:34:11 --> Language Class Initialized
INFO - 2018-03-25 08:34:11 --> Loader Class Initialized
INFO - 2018-03-25 08:34:11 --> Helper loaded: url_helper
INFO - 2018-03-25 08:34:11 --> Helper loaded: form_helper
INFO - 2018-03-25 08:34:11 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:34:11 --> Controller Class Initialized
INFO - 2018-03-25 08:34:11 --> Model Class Initialized
INFO - 2018-03-25 08:34:11 --> Model Class Initialized
INFO - 2018-03-25 08:34:11 --> Model Class Initialized
INFO - 2018-03-25 08:34:11 --> Model Class Initialized
INFO - 2018-03-25 08:34:11 --> Model Class Initialized
INFO - 2018-03-25 08:34:11 --> Model Class Initialized
INFO - 2018-03-25 08:34:11 --> Helper loaded: date_helper
INFO - 2018-03-25 08:34:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:34:11 --> Model Class Initialized
INFO - 2018-03-25 13:34:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:34:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:34:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:34:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:34:11 --> Final output sent to browser
DEBUG - 2018-03-25 13:34:11 --> Total execution time: 0.1052
INFO - 2018-03-25 08:35:43 --> Config Class Initialized
INFO - 2018-03-25 08:35:43 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:35:43 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:35:43 --> Utf8 Class Initialized
INFO - 2018-03-25 08:35:43 --> URI Class Initialized
INFO - 2018-03-25 08:35:43 --> Router Class Initialized
INFO - 2018-03-25 08:35:43 --> Output Class Initialized
INFO - 2018-03-25 08:35:43 --> Security Class Initialized
DEBUG - 2018-03-25 08:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:35:43 --> Input Class Initialized
INFO - 2018-03-25 08:35:43 --> Language Class Initialized
INFO - 2018-03-25 08:35:43 --> Loader Class Initialized
INFO - 2018-03-25 08:35:43 --> Helper loaded: url_helper
INFO - 2018-03-25 08:35:43 --> Helper loaded: form_helper
INFO - 2018-03-25 08:35:43 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:35:44 --> Controller Class Initialized
INFO - 2018-03-25 08:35:44 --> Model Class Initialized
INFO - 2018-03-25 08:35:44 --> Model Class Initialized
INFO - 2018-03-25 08:35:44 --> Model Class Initialized
INFO - 2018-03-25 08:35:44 --> Model Class Initialized
INFO - 2018-03-25 08:35:44 --> Model Class Initialized
INFO - 2018-03-25 08:35:44 --> Model Class Initialized
INFO - 2018-03-25 08:35:44 --> Helper loaded: date_helper
INFO - 2018-03-25 08:35:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:35:44 --> Model Class Initialized
INFO - 2018-03-25 13:35:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:35:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:35:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:35:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:35:44 --> Final output sent to browser
DEBUG - 2018-03-25 13:35:44 --> Total execution time: 0.1182
INFO - 2018-03-25 08:35:57 --> Config Class Initialized
INFO - 2018-03-25 08:35:57 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:35:57 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:35:57 --> Utf8 Class Initialized
INFO - 2018-03-25 08:35:57 --> URI Class Initialized
INFO - 2018-03-25 08:35:57 --> Router Class Initialized
INFO - 2018-03-25 08:35:58 --> Output Class Initialized
INFO - 2018-03-25 08:35:58 --> Security Class Initialized
DEBUG - 2018-03-25 08:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:35:58 --> Input Class Initialized
INFO - 2018-03-25 08:35:58 --> Language Class Initialized
INFO - 2018-03-25 08:35:58 --> Loader Class Initialized
INFO - 2018-03-25 08:35:58 --> Helper loaded: url_helper
INFO - 2018-03-25 08:35:58 --> Helper loaded: form_helper
INFO - 2018-03-25 08:35:58 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:35:58 --> Controller Class Initialized
INFO - 2018-03-25 08:35:58 --> Model Class Initialized
INFO - 2018-03-25 08:35:58 --> Model Class Initialized
INFO - 2018-03-25 08:35:58 --> Model Class Initialized
INFO - 2018-03-25 08:35:58 --> Model Class Initialized
INFO - 2018-03-25 08:35:58 --> Model Class Initialized
INFO - 2018-03-25 08:35:58 --> Model Class Initialized
INFO - 2018-03-25 08:35:58 --> Helper loaded: date_helper
INFO - 2018-03-25 08:35:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:35:58 --> Model Class Initialized
INFO - 2018-03-25 13:35:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:35:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:35:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:35:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:35:58 --> Final output sent to browser
DEBUG - 2018-03-25 13:35:58 --> Total execution time: 0.1001
INFO - 2018-03-25 08:36:02 --> Config Class Initialized
INFO - 2018-03-25 08:36:02 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:36:02 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:36:02 --> Utf8 Class Initialized
INFO - 2018-03-25 08:36:02 --> URI Class Initialized
INFO - 2018-03-25 08:36:02 --> Router Class Initialized
INFO - 2018-03-25 08:36:02 --> Output Class Initialized
INFO - 2018-03-25 08:36:02 --> Security Class Initialized
DEBUG - 2018-03-25 08:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:36:02 --> Input Class Initialized
INFO - 2018-03-25 08:36:02 --> Language Class Initialized
INFO - 2018-03-25 08:36:02 --> Loader Class Initialized
INFO - 2018-03-25 08:36:02 --> Helper loaded: url_helper
INFO - 2018-03-25 08:36:02 --> Helper loaded: form_helper
INFO - 2018-03-25 08:36:02 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:36:02 --> Controller Class Initialized
INFO - 2018-03-25 08:36:02 --> Model Class Initialized
INFO - 2018-03-25 08:36:02 --> Model Class Initialized
INFO - 2018-03-25 08:36:02 --> Helper loaded: date_helper
INFO - 2018-03-25 08:36:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:36:02 --> Final output sent to browser
DEBUG - 2018-03-25 13:36:02 --> Total execution time: 0.0872
INFO - 2018-03-25 08:36:07 --> Config Class Initialized
INFO - 2018-03-25 08:36:07 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:36:07 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:36:07 --> Utf8 Class Initialized
INFO - 2018-03-25 08:36:07 --> URI Class Initialized
INFO - 2018-03-25 08:36:07 --> Router Class Initialized
INFO - 2018-03-25 08:36:07 --> Output Class Initialized
INFO - 2018-03-25 08:36:07 --> Security Class Initialized
DEBUG - 2018-03-25 08:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:36:07 --> Input Class Initialized
INFO - 2018-03-25 08:36:07 --> Language Class Initialized
INFO - 2018-03-25 08:36:07 --> Loader Class Initialized
INFO - 2018-03-25 08:36:07 --> Helper loaded: url_helper
INFO - 2018-03-25 08:36:07 --> Helper loaded: form_helper
INFO - 2018-03-25 08:36:07 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:36:07 --> Controller Class Initialized
INFO - 2018-03-25 08:36:07 --> Model Class Initialized
INFO - 2018-03-25 08:36:07 --> Model Class Initialized
INFO - 2018-03-25 08:36:07 --> Model Class Initialized
INFO - 2018-03-25 08:36:07 --> Model Class Initialized
INFO - 2018-03-25 08:36:07 --> Model Class Initialized
INFO - 2018-03-25 08:36:07 --> Model Class Initialized
INFO - 2018-03-25 08:36:07 --> Helper loaded: date_helper
INFO - 2018-03-25 08:36:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:36:08 --> Final output sent to browser
DEBUG - 2018-03-25 13:36:08 --> Total execution time: 0.3444
INFO - 2018-03-25 08:36:17 --> Config Class Initialized
INFO - 2018-03-25 08:36:17 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:36:17 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:36:17 --> Utf8 Class Initialized
INFO - 2018-03-25 08:36:17 --> URI Class Initialized
INFO - 2018-03-25 08:36:17 --> Router Class Initialized
INFO - 2018-03-25 08:36:17 --> Output Class Initialized
INFO - 2018-03-25 08:36:17 --> Security Class Initialized
DEBUG - 2018-03-25 08:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:36:17 --> Input Class Initialized
INFO - 2018-03-25 08:36:17 --> Language Class Initialized
INFO - 2018-03-25 08:36:17 --> Loader Class Initialized
INFO - 2018-03-25 08:36:17 --> Helper loaded: url_helper
INFO - 2018-03-25 08:36:17 --> Helper loaded: form_helper
INFO - 2018-03-25 08:36:17 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:36:17 --> Controller Class Initialized
INFO - 2018-03-25 08:36:17 --> Model Class Initialized
INFO - 2018-03-25 08:36:17 --> Model Class Initialized
INFO - 2018-03-25 08:36:17 --> Model Class Initialized
INFO - 2018-03-25 08:36:17 --> Model Class Initialized
INFO - 2018-03-25 08:36:17 --> Model Class Initialized
INFO - 2018-03-25 08:36:17 --> Model Class Initialized
INFO - 2018-03-25 08:36:17 --> Helper loaded: date_helper
INFO - 2018-03-25 08:36:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:36:17 --> Model Class Initialized
INFO - 2018-03-25 13:36:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:36:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:36:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 13:36:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:36:17 --> Final output sent to browser
DEBUG - 2018-03-25 13:36:17 --> Total execution time: 0.1011
INFO - 2018-03-25 08:36:37 --> Config Class Initialized
INFO - 2018-03-25 08:36:37 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:36:37 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:36:37 --> Utf8 Class Initialized
INFO - 2018-03-25 08:36:37 --> URI Class Initialized
INFO - 2018-03-25 08:36:37 --> Router Class Initialized
INFO - 2018-03-25 08:36:37 --> Output Class Initialized
INFO - 2018-03-25 08:36:37 --> Security Class Initialized
DEBUG - 2018-03-25 08:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:36:37 --> Input Class Initialized
INFO - 2018-03-25 08:36:37 --> Language Class Initialized
INFO - 2018-03-25 08:36:37 --> Loader Class Initialized
INFO - 2018-03-25 08:36:37 --> Helper loaded: url_helper
INFO - 2018-03-25 08:36:37 --> Helper loaded: form_helper
INFO - 2018-03-25 08:36:37 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:36:37 --> Controller Class Initialized
INFO - 2018-03-25 08:36:37 --> Model Class Initialized
INFO - 2018-03-25 08:36:37 --> Model Class Initialized
INFO - 2018-03-25 08:36:37 --> Model Class Initialized
INFO - 2018-03-25 08:36:37 --> Model Class Initialized
INFO - 2018-03-25 08:36:37 --> Model Class Initialized
INFO - 2018-03-25 08:36:37 --> Model Class Initialized
INFO - 2018-03-25 08:36:37 --> Helper loaded: date_helper
INFO - 2018-03-25 08:36:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:36:37 --> Model Class Initialized
INFO - 2018-03-25 13:36:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:36:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:36:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-25 13:36:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:36:37 --> Final output sent to browser
DEBUG - 2018-03-25 13:36:37 --> Total execution time: 0.1010
INFO - 2018-03-25 08:40:29 --> Config Class Initialized
INFO - 2018-03-25 08:40:29 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:40:29 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:40:29 --> Utf8 Class Initialized
INFO - 2018-03-25 08:40:29 --> URI Class Initialized
INFO - 2018-03-25 08:40:29 --> Router Class Initialized
INFO - 2018-03-25 08:40:29 --> Output Class Initialized
INFO - 2018-03-25 08:40:29 --> Security Class Initialized
DEBUG - 2018-03-25 08:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:40:29 --> Input Class Initialized
INFO - 2018-03-25 08:40:29 --> Language Class Initialized
INFO - 2018-03-25 08:40:29 --> Loader Class Initialized
INFO - 2018-03-25 08:40:29 --> Helper loaded: url_helper
INFO - 2018-03-25 08:40:29 --> Helper loaded: form_helper
INFO - 2018-03-25 08:40:29 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:40:29 --> Controller Class Initialized
INFO - 2018-03-25 08:40:29 --> Model Class Initialized
INFO - 2018-03-25 08:40:29 --> Model Class Initialized
INFO - 2018-03-25 08:40:29 --> Model Class Initialized
INFO - 2018-03-25 08:40:29 --> Model Class Initialized
INFO - 2018-03-25 08:40:29 --> Model Class Initialized
INFO - 2018-03-25 08:40:29 --> Model Class Initialized
INFO - 2018-03-25 08:40:29 --> Helper loaded: date_helper
INFO - 2018-03-25 08:40:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:40:29 --> Model Class Initialized
INFO - 2018-03-25 13:40:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:40:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:40:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/edit.php
INFO - 2018-03-25 13:40:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:40:29 --> Final output sent to browser
DEBUG - 2018-03-25 13:40:29 --> Total execution time: 0.1385
INFO - 2018-03-25 08:40:33 --> Config Class Initialized
INFO - 2018-03-25 08:40:33 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:40:33 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:40:33 --> Utf8 Class Initialized
INFO - 2018-03-25 08:40:33 --> URI Class Initialized
INFO - 2018-03-25 08:40:33 --> Router Class Initialized
INFO - 2018-03-25 08:40:33 --> Output Class Initialized
INFO - 2018-03-25 08:40:33 --> Security Class Initialized
DEBUG - 2018-03-25 08:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:40:33 --> Input Class Initialized
INFO - 2018-03-25 08:40:33 --> Language Class Initialized
INFO - 2018-03-25 08:40:33 --> Loader Class Initialized
INFO - 2018-03-25 08:40:33 --> Helper loaded: url_helper
INFO - 2018-03-25 08:40:33 --> Helper loaded: form_helper
INFO - 2018-03-25 08:40:33 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:40:33 --> Controller Class Initialized
INFO - 2018-03-25 08:40:33 --> Model Class Initialized
INFO - 2018-03-25 08:40:33 --> Model Class Initialized
INFO - 2018-03-25 08:40:33 --> Model Class Initialized
INFO - 2018-03-25 08:40:33 --> Model Class Initialized
INFO - 2018-03-25 08:40:33 --> Model Class Initialized
INFO - 2018-03-25 08:40:33 --> Model Class Initialized
INFO - 2018-03-25 08:40:33 --> Helper loaded: date_helper
INFO - 2018-03-25 08:40:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:40:33 --> Model Class Initialized
INFO - 2018-03-25 13:40:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:40:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:40:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-25 13:40:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:40:33 --> Final output sent to browser
DEBUG - 2018-03-25 13:40:33 --> Total execution time: 0.0867
INFO - 2018-03-25 08:40:37 --> Config Class Initialized
INFO - 2018-03-25 08:40:37 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:40:37 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:40:37 --> Utf8 Class Initialized
INFO - 2018-03-25 08:40:37 --> URI Class Initialized
INFO - 2018-03-25 08:40:37 --> Router Class Initialized
INFO - 2018-03-25 08:40:37 --> Output Class Initialized
INFO - 2018-03-25 08:40:37 --> Security Class Initialized
DEBUG - 2018-03-25 08:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:40:37 --> Input Class Initialized
INFO - 2018-03-25 08:40:37 --> Language Class Initialized
INFO - 2018-03-25 08:40:37 --> Loader Class Initialized
INFO - 2018-03-25 08:40:37 --> Helper loaded: url_helper
INFO - 2018-03-25 08:40:37 --> Helper loaded: form_helper
INFO - 2018-03-25 08:40:37 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:40:37 --> Controller Class Initialized
INFO - 2018-03-25 08:40:37 --> Model Class Initialized
INFO - 2018-03-25 08:40:37 --> Model Class Initialized
INFO - 2018-03-25 08:40:37 --> Model Class Initialized
INFO - 2018-03-25 08:40:37 --> Model Class Initialized
INFO - 2018-03-25 08:40:37 --> Model Class Initialized
INFO - 2018-03-25 08:40:37 --> Model Class Initialized
INFO - 2018-03-25 08:40:37 --> Model Class Initialized
INFO - 2018-03-25 08:40:37 --> Model Class Initialized
INFO - 2018-03-25 08:40:37 --> Model Class Initialized
INFO - 2018-03-25 08:40:37 --> Model Class Initialized
INFO - 2018-03-25 08:40:37 --> Model Class Initialized
INFO - 2018-03-25 08:40:37 --> Model Class Initialized
INFO - 2018-03-25 08:40:37 --> Model Class Initialized
INFO - 2018-03-25 08:40:37 --> Helper loaded: date_helper
INFO - 2018-03-25 08:40:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:40:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:40:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:40:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-25 13:40:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:40:38 --> Final output sent to browser
DEBUG - 2018-03-25 13:40:38 --> Total execution time: 0.3766
INFO - 2018-03-25 08:40:48 --> Config Class Initialized
INFO - 2018-03-25 08:40:48 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:40:48 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:40:48 --> Utf8 Class Initialized
INFO - 2018-03-25 08:40:48 --> URI Class Initialized
INFO - 2018-03-25 08:40:48 --> Router Class Initialized
INFO - 2018-03-25 08:40:48 --> Output Class Initialized
INFO - 2018-03-25 08:40:48 --> Security Class Initialized
DEBUG - 2018-03-25 08:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:40:48 --> Input Class Initialized
INFO - 2018-03-25 08:40:48 --> Language Class Initialized
INFO - 2018-03-25 08:40:48 --> Loader Class Initialized
INFO - 2018-03-25 08:40:48 --> Helper loaded: url_helper
INFO - 2018-03-25 08:40:48 --> Helper loaded: form_helper
INFO - 2018-03-25 08:40:48 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:40:48 --> Controller Class Initialized
INFO - 2018-03-25 08:40:48 --> Model Class Initialized
INFO - 2018-03-25 08:40:48 --> Model Class Initialized
INFO - 2018-03-25 08:40:48 --> Model Class Initialized
INFO - 2018-03-25 08:40:48 --> Model Class Initialized
INFO - 2018-03-25 08:40:48 --> Model Class Initialized
INFO - 2018-03-25 08:40:48 --> Model Class Initialized
INFO - 2018-03-25 08:40:48 --> Model Class Initialized
INFO - 2018-03-25 08:40:48 --> Model Class Initialized
INFO - 2018-03-25 08:40:48 --> Model Class Initialized
INFO - 2018-03-25 08:40:48 --> Model Class Initialized
INFO - 2018-03-25 08:40:48 --> Model Class Initialized
INFO - 2018-03-25 08:40:48 --> Model Class Initialized
INFO - 2018-03-25 08:40:48 --> Model Class Initialized
INFO - 2018-03-25 08:40:48 --> Helper loaded: date_helper
INFO - 2018-03-25 08:40:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:40:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/list.php
INFO - 2018-03-25 13:40:48 --> Final output sent to browser
DEBUG - 2018-03-25 13:40:48 --> Total execution time: 0.0903
INFO - 2018-03-25 08:40:53 --> Config Class Initialized
INFO - 2018-03-25 08:40:53 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:40:53 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:40:53 --> Utf8 Class Initialized
INFO - 2018-03-25 08:40:53 --> URI Class Initialized
INFO - 2018-03-25 08:40:53 --> Router Class Initialized
INFO - 2018-03-25 08:40:53 --> Output Class Initialized
INFO - 2018-03-25 08:40:53 --> Security Class Initialized
DEBUG - 2018-03-25 08:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:40:53 --> Input Class Initialized
INFO - 2018-03-25 08:40:53 --> Language Class Initialized
INFO - 2018-03-25 08:40:53 --> Loader Class Initialized
INFO - 2018-03-25 08:40:53 --> Helper loaded: url_helper
INFO - 2018-03-25 08:40:53 --> Helper loaded: form_helper
INFO - 2018-03-25 08:40:53 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:40:53 --> Controller Class Initialized
INFO - 2018-03-25 08:40:53 --> Model Class Initialized
INFO - 2018-03-25 08:40:53 --> Model Class Initialized
INFO - 2018-03-25 08:40:53 --> Model Class Initialized
INFO - 2018-03-25 08:40:53 --> Model Class Initialized
INFO - 2018-03-25 08:40:53 --> Model Class Initialized
INFO - 2018-03-25 08:40:53 --> Model Class Initialized
INFO - 2018-03-25 08:40:53 --> Model Class Initialized
INFO - 2018-03-25 08:40:53 --> Model Class Initialized
INFO - 2018-03-25 08:40:53 --> Model Class Initialized
INFO - 2018-03-25 08:40:53 --> Model Class Initialized
INFO - 2018-03-25 08:40:53 --> Model Class Initialized
INFO - 2018-03-25 08:40:53 --> Model Class Initialized
INFO - 2018-03-25 08:40:53 --> Model Class Initialized
INFO - 2018-03-25 08:40:53 --> Helper loaded: date_helper
INFO - 2018-03-25 08:40:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:40:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/list.php
INFO - 2018-03-25 13:40:53 --> Final output sent to browser
DEBUG - 2018-03-25 13:40:53 --> Total execution time: 0.1219
INFO - 2018-03-25 08:40:56 --> Config Class Initialized
INFO - 2018-03-25 08:40:56 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:40:56 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:40:56 --> Utf8 Class Initialized
INFO - 2018-03-25 08:40:56 --> URI Class Initialized
INFO - 2018-03-25 08:40:56 --> Router Class Initialized
INFO - 2018-03-25 08:40:57 --> Output Class Initialized
INFO - 2018-03-25 08:40:57 --> Security Class Initialized
DEBUG - 2018-03-25 08:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:40:57 --> Input Class Initialized
INFO - 2018-03-25 08:40:57 --> Language Class Initialized
INFO - 2018-03-25 08:40:57 --> Loader Class Initialized
INFO - 2018-03-25 08:40:57 --> Helper loaded: url_helper
INFO - 2018-03-25 08:40:57 --> Helper loaded: form_helper
INFO - 2018-03-25 08:40:57 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:40:57 --> Controller Class Initialized
INFO - 2018-03-25 08:40:57 --> Model Class Initialized
INFO - 2018-03-25 08:40:57 --> Model Class Initialized
INFO - 2018-03-25 08:40:57 --> Model Class Initialized
INFO - 2018-03-25 08:40:57 --> Model Class Initialized
INFO - 2018-03-25 08:40:57 --> Model Class Initialized
INFO - 2018-03-25 08:40:57 --> Model Class Initialized
INFO - 2018-03-25 08:40:57 --> Model Class Initialized
INFO - 2018-03-25 08:40:57 --> Model Class Initialized
INFO - 2018-03-25 08:40:57 --> Model Class Initialized
INFO - 2018-03-25 08:40:57 --> Model Class Initialized
INFO - 2018-03-25 08:40:57 --> Model Class Initialized
INFO - 2018-03-25 08:40:57 --> Model Class Initialized
INFO - 2018-03-25 08:40:57 --> Model Class Initialized
INFO - 2018-03-25 08:40:57 --> Helper loaded: date_helper
INFO - 2018-03-25 08:40:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:40:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/list.php
INFO - 2018-03-25 13:40:57 --> Final output sent to browser
DEBUG - 2018-03-25 13:40:57 --> Total execution time: 0.1043
INFO - 2018-03-25 08:41:22 --> Config Class Initialized
INFO - 2018-03-25 08:41:22 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:41:22 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:41:22 --> Utf8 Class Initialized
INFO - 2018-03-25 08:41:22 --> URI Class Initialized
INFO - 2018-03-25 08:41:22 --> Router Class Initialized
INFO - 2018-03-25 08:41:22 --> Output Class Initialized
INFO - 2018-03-25 08:41:22 --> Security Class Initialized
DEBUG - 2018-03-25 08:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:41:22 --> Input Class Initialized
INFO - 2018-03-25 08:41:22 --> Language Class Initialized
INFO - 2018-03-25 08:41:22 --> Loader Class Initialized
INFO - 2018-03-25 08:41:22 --> Helper loaded: url_helper
INFO - 2018-03-25 08:41:22 --> Helper loaded: form_helper
INFO - 2018-03-25 08:41:22 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:41:22 --> Controller Class Initialized
INFO - 2018-03-25 08:41:22 --> Model Class Initialized
INFO - 2018-03-25 08:41:22 --> Model Class Initialized
INFO - 2018-03-25 08:41:22 --> Model Class Initialized
INFO - 2018-03-25 08:41:22 --> Model Class Initialized
INFO - 2018-03-25 08:41:22 --> Model Class Initialized
INFO - 2018-03-25 08:41:22 --> Model Class Initialized
INFO - 2018-03-25 08:41:22 --> Model Class Initialized
INFO - 2018-03-25 08:41:22 --> Model Class Initialized
INFO - 2018-03-25 08:41:22 --> Model Class Initialized
INFO - 2018-03-25 08:41:22 --> Model Class Initialized
INFO - 2018-03-25 08:41:22 --> Model Class Initialized
INFO - 2018-03-25 08:41:22 --> Model Class Initialized
INFO - 2018-03-25 08:41:22 --> Model Class Initialized
INFO - 2018-03-25 08:41:22 --> Helper loaded: date_helper
INFO - 2018-03-25 08:41:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:41:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/list.php
INFO - 2018-03-25 13:41:22 --> Final output sent to browser
DEBUG - 2018-03-25 13:41:22 --> Total execution time: 0.0995
INFO - 2018-03-25 08:41:25 --> Config Class Initialized
INFO - 2018-03-25 08:41:25 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:41:25 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:41:25 --> Utf8 Class Initialized
INFO - 2018-03-25 08:41:25 --> URI Class Initialized
INFO - 2018-03-25 08:41:25 --> Router Class Initialized
INFO - 2018-03-25 08:41:25 --> Output Class Initialized
INFO - 2018-03-25 08:41:25 --> Security Class Initialized
DEBUG - 2018-03-25 08:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:41:25 --> Input Class Initialized
INFO - 2018-03-25 08:41:25 --> Language Class Initialized
INFO - 2018-03-25 08:41:25 --> Loader Class Initialized
INFO - 2018-03-25 08:41:25 --> Helper loaded: url_helper
INFO - 2018-03-25 08:41:25 --> Helper loaded: form_helper
INFO - 2018-03-25 08:41:25 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:41:25 --> Controller Class Initialized
INFO - 2018-03-25 08:41:25 --> Model Class Initialized
INFO - 2018-03-25 08:41:25 --> Model Class Initialized
INFO - 2018-03-25 08:41:25 --> Model Class Initialized
INFO - 2018-03-25 08:41:25 --> Model Class Initialized
INFO - 2018-03-25 08:41:25 --> Model Class Initialized
INFO - 2018-03-25 08:41:25 --> Model Class Initialized
INFO - 2018-03-25 08:41:25 --> Model Class Initialized
INFO - 2018-03-25 08:41:25 --> Model Class Initialized
INFO - 2018-03-25 08:41:25 --> Model Class Initialized
INFO - 2018-03-25 08:41:25 --> Model Class Initialized
INFO - 2018-03-25 08:41:25 --> Model Class Initialized
INFO - 2018-03-25 08:41:25 --> Model Class Initialized
INFO - 2018-03-25 08:41:25 --> Model Class Initialized
INFO - 2018-03-25 08:41:25 --> Helper loaded: date_helper
INFO - 2018-03-25 08:41:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:41:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:41:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:41:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-25 13:41:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:41:25 --> Final output sent to browser
DEBUG - 2018-03-25 13:41:25 --> Total execution time: 0.1872
INFO - 2018-03-25 08:41:35 --> Config Class Initialized
INFO - 2018-03-25 08:41:35 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:41:35 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:41:35 --> Utf8 Class Initialized
INFO - 2018-03-25 08:41:35 --> URI Class Initialized
INFO - 2018-03-25 08:41:35 --> Router Class Initialized
INFO - 2018-03-25 08:41:35 --> Output Class Initialized
INFO - 2018-03-25 08:41:35 --> Security Class Initialized
DEBUG - 2018-03-25 08:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:41:35 --> Input Class Initialized
INFO - 2018-03-25 08:41:35 --> Language Class Initialized
INFO - 2018-03-25 08:41:35 --> Loader Class Initialized
INFO - 2018-03-25 08:41:35 --> Helper loaded: url_helper
INFO - 2018-03-25 08:41:35 --> Helper loaded: form_helper
INFO - 2018-03-25 08:41:35 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:41:35 --> Controller Class Initialized
INFO - 2018-03-25 08:41:35 --> Model Class Initialized
INFO - 2018-03-25 08:41:35 --> Model Class Initialized
INFO - 2018-03-25 08:41:35 --> Helper loaded: date_helper
INFO - 2018-03-25 08:41:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:41:35 --> Final output sent to browser
DEBUG - 2018-03-25 13:41:35 --> Total execution time: 0.1082
INFO - 2018-03-25 08:41:39 --> Config Class Initialized
INFO - 2018-03-25 08:41:39 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:41:39 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:41:39 --> Utf8 Class Initialized
INFO - 2018-03-25 08:41:39 --> URI Class Initialized
INFO - 2018-03-25 08:41:39 --> Router Class Initialized
INFO - 2018-03-25 08:41:39 --> Output Class Initialized
INFO - 2018-03-25 08:41:39 --> Security Class Initialized
DEBUG - 2018-03-25 08:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:41:39 --> Input Class Initialized
INFO - 2018-03-25 08:41:39 --> Language Class Initialized
INFO - 2018-03-25 08:41:39 --> Loader Class Initialized
INFO - 2018-03-25 08:41:39 --> Helper loaded: url_helper
INFO - 2018-03-25 08:41:39 --> Helper loaded: form_helper
INFO - 2018-03-25 08:41:39 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:41:39 --> Controller Class Initialized
INFO - 2018-03-25 08:41:39 --> Model Class Initialized
INFO - 2018-03-25 08:41:39 --> Model Class Initialized
INFO - 2018-03-25 08:41:39 --> Model Class Initialized
INFO - 2018-03-25 08:41:39 --> Model Class Initialized
INFO - 2018-03-25 08:41:39 --> Model Class Initialized
INFO - 2018-03-25 08:41:39 --> Model Class Initialized
INFO - 2018-03-25 08:41:39 --> Model Class Initialized
INFO - 2018-03-25 08:41:39 --> Model Class Initialized
INFO - 2018-03-25 08:41:39 --> Model Class Initialized
INFO - 2018-03-25 08:41:39 --> Model Class Initialized
INFO - 2018-03-25 08:41:39 --> Model Class Initialized
INFO - 2018-03-25 08:41:39 --> Model Class Initialized
INFO - 2018-03-25 08:41:39 --> Model Class Initialized
INFO - 2018-03-25 08:41:39 --> Helper loaded: date_helper
INFO - 2018-03-25 08:41:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 08:41:40 --> Config Class Initialized
INFO - 2018-03-25 08:41:40 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:41:40 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:41:40 --> Utf8 Class Initialized
INFO - 2018-03-25 08:41:40 --> URI Class Initialized
INFO - 2018-03-25 08:41:40 --> Router Class Initialized
INFO - 2018-03-25 08:41:40 --> Output Class Initialized
INFO - 2018-03-25 08:41:40 --> Security Class Initialized
DEBUG - 2018-03-25 08:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:41:40 --> Input Class Initialized
INFO - 2018-03-25 08:41:40 --> Language Class Initialized
INFO - 2018-03-25 08:41:40 --> Loader Class Initialized
INFO - 2018-03-25 08:41:40 --> Helper loaded: url_helper
INFO - 2018-03-25 08:41:40 --> Helper loaded: form_helper
INFO - 2018-03-25 08:41:40 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:41:40 --> Controller Class Initialized
INFO - 2018-03-25 08:41:40 --> Model Class Initialized
INFO - 2018-03-25 08:41:40 --> Model Class Initialized
INFO - 2018-03-25 08:41:40 --> Model Class Initialized
INFO - 2018-03-25 08:41:40 --> Model Class Initialized
INFO - 2018-03-25 08:41:40 --> Model Class Initialized
INFO - 2018-03-25 08:41:40 --> Model Class Initialized
INFO - 2018-03-25 08:41:40 --> Model Class Initialized
INFO - 2018-03-25 08:41:40 --> Model Class Initialized
INFO - 2018-03-25 08:41:40 --> Model Class Initialized
INFO - 2018-03-25 08:41:40 --> Model Class Initialized
INFO - 2018-03-25 08:41:40 --> Model Class Initialized
INFO - 2018-03-25 08:41:40 --> Model Class Initialized
INFO - 2018-03-25 08:41:40 --> Model Class Initialized
INFO - 2018-03-25 08:41:40 --> Helper loaded: date_helper
INFO - 2018-03-25 08:41:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:41:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:41:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:41:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-25 13:41:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:41:40 --> Final output sent to browser
DEBUG - 2018-03-25 13:41:40 --> Total execution time: 0.1559
INFO - 2018-03-25 08:42:12 --> Config Class Initialized
INFO - 2018-03-25 08:42:12 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:42:12 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:42:12 --> Utf8 Class Initialized
INFO - 2018-03-25 08:42:12 --> URI Class Initialized
INFO - 2018-03-25 08:42:12 --> Router Class Initialized
INFO - 2018-03-25 08:42:12 --> Output Class Initialized
INFO - 2018-03-25 08:42:12 --> Security Class Initialized
DEBUG - 2018-03-25 08:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:42:12 --> Input Class Initialized
INFO - 2018-03-25 08:42:12 --> Language Class Initialized
INFO - 2018-03-25 08:42:12 --> Loader Class Initialized
INFO - 2018-03-25 08:42:12 --> Helper loaded: url_helper
INFO - 2018-03-25 08:42:12 --> Helper loaded: form_helper
INFO - 2018-03-25 08:42:12 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:42:12 --> Controller Class Initialized
INFO - 2018-03-25 08:42:12 --> Model Class Initialized
INFO - 2018-03-25 08:42:12 --> Model Class Initialized
INFO - 2018-03-25 08:42:12 --> Helper loaded: date_helper
INFO - 2018-03-25 08:42:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:42:12 --> Final output sent to browser
DEBUG - 2018-03-25 13:42:12 --> Total execution time: 0.0909
INFO - 2018-03-25 08:43:22 --> Config Class Initialized
INFO - 2018-03-25 08:43:22 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:43:22 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:43:22 --> Utf8 Class Initialized
INFO - 2018-03-25 08:43:22 --> URI Class Initialized
INFO - 2018-03-25 08:43:22 --> Router Class Initialized
INFO - 2018-03-25 08:43:22 --> Output Class Initialized
INFO - 2018-03-25 08:43:22 --> Security Class Initialized
DEBUG - 2018-03-25 08:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:43:22 --> Input Class Initialized
INFO - 2018-03-25 08:43:22 --> Language Class Initialized
INFO - 2018-03-25 08:43:22 --> Loader Class Initialized
INFO - 2018-03-25 08:43:22 --> Helper loaded: url_helper
INFO - 2018-03-25 08:43:22 --> Helper loaded: form_helper
INFO - 2018-03-25 08:43:22 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:43:22 --> Controller Class Initialized
INFO - 2018-03-25 08:43:22 --> Model Class Initialized
INFO - 2018-03-25 08:43:22 --> Model Class Initialized
INFO - 2018-03-25 08:43:22 --> Model Class Initialized
INFO - 2018-03-25 08:43:22 --> Model Class Initialized
INFO - 2018-03-25 08:43:22 --> Model Class Initialized
INFO - 2018-03-25 08:43:22 --> Model Class Initialized
INFO - 2018-03-25 08:43:22 --> Model Class Initialized
INFO - 2018-03-25 08:43:22 --> Model Class Initialized
INFO - 2018-03-25 08:43:22 --> Model Class Initialized
INFO - 2018-03-25 08:43:22 --> Model Class Initialized
INFO - 2018-03-25 08:43:22 --> Model Class Initialized
INFO - 2018-03-25 08:43:22 --> Model Class Initialized
INFO - 2018-03-25 08:43:22 --> Model Class Initialized
INFO - 2018-03-25 08:43:22 --> Helper loaded: date_helper
INFO - 2018-03-25 08:43:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:43:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:43:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:43:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-25 13:43:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:43:22 --> Final output sent to browser
DEBUG - 2018-03-25 13:43:22 --> Total execution time: 0.1144
INFO - 2018-03-25 08:43:38 --> Config Class Initialized
INFO - 2018-03-25 08:43:38 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:43:38 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:43:38 --> Utf8 Class Initialized
INFO - 2018-03-25 08:43:38 --> URI Class Initialized
INFO - 2018-03-25 08:43:38 --> Router Class Initialized
INFO - 2018-03-25 08:43:38 --> Output Class Initialized
INFO - 2018-03-25 08:43:38 --> Security Class Initialized
DEBUG - 2018-03-25 08:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:43:38 --> Input Class Initialized
INFO - 2018-03-25 08:43:38 --> Language Class Initialized
INFO - 2018-03-25 08:43:38 --> Loader Class Initialized
INFO - 2018-03-25 08:43:38 --> Helper loaded: url_helper
INFO - 2018-03-25 08:43:38 --> Helper loaded: form_helper
INFO - 2018-03-25 08:43:38 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:43:38 --> Controller Class Initialized
INFO - 2018-03-25 08:43:38 --> Model Class Initialized
INFO - 2018-03-25 08:43:38 --> Model Class Initialized
INFO - 2018-03-25 08:43:38 --> Model Class Initialized
INFO - 2018-03-25 08:43:38 --> Model Class Initialized
INFO - 2018-03-25 08:43:38 --> Model Class Initialized
INFO - 2018-03-25 08:43:38 --> Model Class Initialized
INFO - 2018-03-25 08:43:38 --> Model Class Initialized
INFO - 2018-03-25 08:43:38 --> Model Class Initialized
INFO - 2018-03-25 08:43:38 --> Model Class Initialized
INFO - 2018-03-25 08:43:38 --> Model Class Initialized
INFO - 2018-03-25 08:43:38 --> Helper loaded: date_helper
INFO - 2018-03-25 08:43:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:43:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:43:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:43:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/detail.php
INFO - 2018-03-25 13:43:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:43:38 --> Final output sent to browser
DEBUG - 2018-03-25 13:43:38 --> Total execution time: 0.2665
INFO - 2018-03-25 08:44:24 --> Config Class Initialized
INFO - 2018-03-25 08:44:24 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:44:24 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:44:24 --> Utf8 Class Initialized
INFO - 2018-03-25 08:44:24 --> URI Class Initialized
INFO - 2018-03-25 08:44:24 --> Router Class Initialized
INFO - 2018-03-25 08:44:24 --> Output Class Initialized
INFO - 2018-03-25 08:44:24 --> Security Class Initialized
DEBUG - 2018-03-25 08:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:44:24 --> Input Class Initialized
INFO - 2018-03-25 08:44:24 --> Language Class Initialized
INFO - 2018-03-25 08:44:24 --> Loader Class Initialized
INFO - 2018-03-25 08:44:24 --> Helper loaded: url_helper
INFO - 2018-03-25 08:44:24 --> Helper loaded: form_helper
INFO - 2018-03-25 08:44:24 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:44:24 --> Controller Class Initialized
INFO - 2018-03-25 08:44:24 --> Model Class Initialized
INFO - 2018-03-25 08:44:24 --> Model Class Initialized
INFO - 2018-03-25 08:44:24 --> Model Class Initialized
INFO - 2018-03-25 08:44:24 --> Model Class Initialized
INFO - 2018-03-25 08:44:24 --> Model Class Initialized
INFO - 2018-03-25 08:44:24 --> Model Class Initialized
INFO - 2018-03-25 08:44:24 --> Model Class Initialized
INFO - 2018-03-25 08:44:24 --> Model Class Initialized
INFO - 2018-03-25 08:44:24 --> Model Class Initialized
INFO - 2018-03-25 08:44:24 --> Model Class Initialized
INFO - 2018-03-25 08:44:24 --> Model Class Initialized
INFO - 2018-03-25 08:44:24 --> Model Class Initialized
INFO - 2018-03-25 08:44:24 --> Model Class Initialized
INFO - 2018-03-25 08:44:24 --> Helper loaded: date_helper
INFO - 2018-03-25 08:44:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:44:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:44:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:44:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-25 13:44:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:44:24 --> Final output sent to browser
DEBUG - 2018-03-25 13:44:24 --> Total execution time: 0.1196
INFO - 2018-03-25 08:45:33 --> Config Class Initialized
INFO - 2018-03-25 08:45:33 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:45:33 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:45:33 --> Utf8 Class Initialized
INFO - 2018-03-25 08:45:33 --> URI Class Initialized
INFO - 2018-03-25 08:45:33 --> Router Class Initialized
INFO - 2018-03-25 08:45:33 --> Output Class Initialized
INFO - 2018-03-25 08:45:33 --> Security Class Initialized
DEBUG - 2018-03-25 08:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:45:33 --> Input Class Initialized
INFO - 2018-03-25 08:45:33 --> Language Class Initialized
INFO - 2018-03-25 08:45:33 --> Loader Class Initialized
INFO - 2018-03-25 08:45:33 --> Helper loaded: url_helper
INFO - 2018-03-25 08:45:33 --> Helper loaded: form_helper
INFO - 2018-03-25 08:45:33 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:45:33 --> Controller Class Initialized
INFO - 2018-03-25 08:45:33 --> Model Class Initialized
INFO - 2018-03-25 08:45:33 --> Model Class Initialized
INFO - 2018-03-25 08:45:33 --> Model Class Initialized
INFO - 2018-03-25 08:45:33 --> Model Class Initialized
INFO - 2018-03-25 08:45:33 --> Model Class Initialized
INFO - 2018-03-25 08:45:33 --> Helper loaded: date_helper
INFO - 2018-03-25 13:45:33 --> Model Class Initialized
INFO - 2018-03-25 13:45:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:45:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:45:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-25 13:45:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:45:33 --> Final output sent to browser
DEBUG - 2018-03-25 13:45:33 --> Total execution time: 0.1185
INFO - 2018-03-25 08:45:43 --> Config Class Initialized
INFO - 2018-03-25 08:45:43 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:45:43 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:45:43 --> Utf8 Class Initialized
INFO - 2018-03-25 08:45:43 --> URI Class Initialized
INFO - 2018-03-25 08:45:43 --> Router Class Initialized
INFO - 2018-03-25 08:45:43 --> Output Class Initialized
INFO - 2018-03-25 08:45:43 --> Security Class Initialized
DEBUG - 2018-03-25 08:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:45:43 --> Input Class Initialized
INFO - 2018-03-25 08:45:43 --> Language Class Initialized
INFO - 2018-03-25 08:45:43 --> Loader Class Initialized
INFO - 2018-03-25 08:45:43 --> Helper loaded: url_helper
INFO - 2018-03-25 08:45:43 --> Helper loaded: form_helper
INFO - 2018-03-25 08:45:43 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:45:43 --> Controller Class Initialized
INFO - 2018-03-25 08:45:43 --> Model Class Initialized
INFO - 2018-03-25 08:45:43 --> Model Class Initialized
INFO - 2018-03-25 08:45:43 --> Model Class Initialized
INFO - 2018-03-25 08:45:43 --> Model Class Initialized
INFO - 2018-03-25 08:45:43 --> Model Class Initialized
INFO - 2018-03-25 08:45:43 --> Helper loaded: date_helper
INFO - 2018-03-25 13:45:43 --> Model Class Initialized
INFO - 2018-03-25 13:45:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:45:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:45:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/create.php
INFO - 2018-03-25 13:45:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:45:43 --> Final output sent to browser
DEBUG - 2018-03-25 13:45:43 --> Total execution time: 0.0939
INFO - 2018-03-25 08:45:58 --> Config Class Initialized
INFO - 2018-03-25 08:45:58 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:45:58 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:45:58 --> Utf8 Class Initialized
INFO - 2018-03-25 08:45:58 --> URI Class Initialized
INFO - 2018-03-25 08:45:58 --> Router Class Initialized
INFO - 2018-03-25 08:45:58 --> Output Class Initialized
INFO - 2018-03-25 08:45:58 --> Security Class Initialized
DEBUG - 2018-03-25 08:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:45:58 --> Input Class Initialized
INFO - 2018-03-25 08:45:58 --> Language Class Initialized
INFO - 2018-03-25 08:45:58 --> Loader Class Initialized
INFO - 2018-03-25 08:45:58 --> Helper loaded: url_helper
INFO - 2018-03-25 08:45:58 --> Helper loaded: form_helper
INFO - 2018-03-25 08:45:58 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:45:58 --> Controller Class Initialized
INFO - 2018-03-25 08:45:58 --> Model Class Initialized
INFO - 2018-03-25 08:45:58 --> Model Class Initialized
INFO - 2018-03-25 08:45:58 --> Model Class Initialized
INFO - 2018-03-25 08:45:58 --> Model Class Initialized
INFO - 2018-03-25 08:45:58 --> Model Class Initialized
INFO - 2018-03-25 08:45:58 --> Helper loaded: date_helper
INFO - 2018-03-25 08:45:58 --> Config Class Initialized
INFO - 2018-03-25 08:45:58 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:45:58 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:45:58 --> Utf8 Class Initialized
INFO - 2018-03-25 08:45:58 --> URI Class Initialized
INFO - 2018-03-25 08:45:58 --> Router Class Initialized
INFO - 2018-03-25 08:45:58 --> Output Class Initialized
INFO - 2018-03-25 08:45:58 --> Security Class Initialized
DEBUG - 2018-03-25 08:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:45:58 --> Input Class Initialized
INFO - 2018-03-25 08:45:58 --> Language Class Initialized
INFO - 2018-03-25 08:45:58 --> Loader Class Initialized
INFO - 2018-03-25 08:45:58 --> Helper loaded: url_helper
INFO - 2018-03-25 08:45:58 --> Helper loaded: form_helper
INFO - 2018-03-25 08:45:58 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:45:58 --> Controller Class Initialized
INFO - 2018-03-25 08:45:58 --> Model Class Initialized
INFO - 2018-03-25 08:45:58 --> Model Class Initialized
INFO - 2018-03-25 08:45:58 --> Model Class Initialized
INFO - 2018-03-25 08:45:58 --> Model Class Initialized
INFO - 2018-03-25 08:45:58 --> Model Class Initialized
INFO - 2018-03-25 08:45:58 --> Helper loaded: date_helper
INFO - 2018-03-25 13:45:58 --> Model Class Initialized
INFO - 2018-03-25 13:45:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:45:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:45:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-25 13:45:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:45:58 --> Final output sent to browser
DEBUG - 2018-03-25 13:45:58 --> Total execution time: 0.1006
INFO - 2018-03-25 08:46:06 --> Config Class Initialized
INFO - 2018-03-25 08:46:06 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:46:06 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:46:06 --> Utf8 Class Initialized
INFO - 2018-03-25 08:46:06 --> URI Class Initialized
INFO - 2018-03-25 08:46:06 --> Router Class Initialized
INFO - 2018-03-25 08:46:06 --> Output Class Initialized
INFO - 2018-03-25 08:46:06 --> Security Class Initialized
DEBUG - 2018-03-25 08:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:46:06 --> Input Class Initialized
INFO - 2018-03-25 08:46:06 --> Language Class Initialized
INFO - 2018-03-25 08:46:06 --> Loader Class Initialized
INFO - 2018-03-25 08:46:06 --> Helper loaded: url_helper
INFO - 2018-03-25 08:46:06 --> Helper loaded: form_helper
INFO - 2018-03-25 08:46:06 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:46:06 --> Controller Class Initialized
INFO - 2018-03-25 08:46:06 --> Model Class Initialized
INFO - 2018-03-25 08:46:06 --> Model Class Initialized
INFO - 2018-03-25 08:46:06 --> Model Class Initialized
INFO - 2018-03-25 08:46:06 --> Model Class Initialized
INFO - 2018-03-25 08:46:06 --> Model Class Initialized
INFO - 2018-03-25 08:46:06 --> Helper loaded: date_helper
INFO - 2018-03-25 13:46:06 --> Model Class Initialized
INFO - 2018-03-25 13:46:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:46:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:46:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/create.php
INFO - 2018-03-25 13:46:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:46:06 --> Final output sent to browser
DEBUG - 2018-03-25 13:46:06 --> Total execution time: 0.1004
INFO - 2018-03-25 08:46:23 --> Config Class Initialized
INFO - 2018-03-25 08:46:23 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:46:23 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:46:23 --> Utf8 Class Initialized
INFO - 2018-03-25 08:46:23 --> URI Class Initialized
INFO - 2018-03-25 08:46:23 --> Router Class Initialized
INFO - 2018-03-25 08:46:23 --> Output Class Initialized
INFO - 2018-03-25 08:46:23 --> Security Class Initialized
DEBUG - 2018-03-25 08:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:46:23 --> Input Class Initialized
INFO - 2018-03-25 08:46:23 --> Language Class Initialized
INFO - 2018-03-25 08:46:23 --> Loader Class Initialized
INFO - 2018-03-25 08:46:23 --> Helper loaded: url_helper
INFO - 2018-03-25 08:46:23 --> Helper loaded: form_helper
INFO - 2018-03-25 08:46:23 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:46:23 --> Controller Class Initialized
INFO - 2018-03-25 08:46:23 --> Model Class Initialized
INFO - 2018-03-25 08:46:23 --> Model Class Initialized
INFO - 2018-03-25 08:46:23 --> Model Class Initialized
INFO - 2018-03-25 08:46:23 --> Model Class Initialized
INFO - 2018-03-25 08:46:23 --> Model Class Initialized
INFO - 2018-03-25 08:46:23 --> Helper loaded: date_helper
INFO - 2018-03-25 13:46:23 --> Model Class Initialized
INFO - 2018-03-25 13:46:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:46:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:46:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-25 13:46:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:46:23 --> Final output sent to browser
DEBUG - 2018-03-25 13:46:23 --> Total execution time: 0.1237
INFO - 2018-03-25 08:46:29 --> Config Class Initialized
INFO - 2018-03-25 08:46:29 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:46:29 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:46:29 --> Utf8 Class Initialized
INFO - 2018-03-25 08:46:29 --> URI Class Initialized
INFO - 2018-03-25 08:46:29 --> Router Class Initialized
INFO - 2018-03-25 08:46:29 --> Output Class Initialized
INFO - 2018-03-25 08:46:29 --> Security Class Initialized
DEBUG - 2018-03-25 08:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:46:29 --> Input Class Initialized
INFO - 2018-03-25 08:46:29 --> Language Class Initialized
INFO - 2018-03-25 08:46:29 --> Loader Class Initialized
INFO - 2018-03-25 08:46:29 --> Helper loaded: url_helper
INFO - 2018-03-25 08:46:29 --> Helper loaded: form_helper
INFO - 2018-03-25 08:46:29 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:46:29 --> Controller Class Initialized
INFO - 2018-03-25 08:46:29 --> Model Class Initialized
INFO - 2018-03-25 08:46:29 --> Model Class Initialized
INFO - 2018-03-25 08:46:29 --> Model Class Initialized
INFO - 2018-03-25 08:46:29 --> Model Class Initialized
INFO - 2018-03-25 08:46:29 --> Model Class Initialized
INFO - 2018-03-25 08:46:29 --> Helper loaded: date_helper
INFO - 2018-03-25 13:46:29 --> Model Class Initialized
INFO - 2018-03-25 13:46:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:46:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:46:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/create.php
INFO - 2018-03-25 13:46:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:46:29 --> Final output sent to browser
DEBUG - 2018-03-25 13:46:29 --> Total execution time: 0.1176
INFO - 2018-03-25 08:47:08 --> Config Class Initialized
INFO - 2018-03-25 08:47:08 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:47:08 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:47:08 --> Utf8 Class Initialized
INFO - 2018-03-25 08:47:08 --> URI Class Initialized
INFO - 2018-03-25 08:47:08 --> Router Class Initialized
INFO - 2018-03-25 08:47:08 --> Output Class Initialized
INFO - 2018-03-25 08:47:08 --> Security Class Initialized
DEBUG - 2018-03-25 08:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:47:08 --> Input Class Initialized
INFO - 2018-03-25 08:47:08 --> Language Class Initialized
INFO - 2018-03-25 08:47:08 --> Loader Class Initialized
INFO - 2018-03-25 08:47:08 --> Helper loaded: url_helper
INFO - 2018-03-25 08:47:08 --> Helper loaded: form_helper
INFO - 2018-03-25 08:47:08 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:47:09 --> Controller Class Initialized
INFO - 2018-03-25 08:47:09 --> Model Class Initialized
INFO - 2018-03-25 08:47:09 --> Model Class Initialized
INFO - 2018-03-25 08:47:09 --> Model Class Initialized
INFO - 2018-03-25 08:47:09 --> Model Class Initialized
INFO - 2018-03-25 08:47:09 --> Model Class Initialized
INFO - 2018-03-25 08:47:09 --> Helper loaded: date_helper
INFO - 2018-03-25 08:47:09 --> Config Class Initialized
INFO - 2018-03-25 08:47:09 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:47:09 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:47:09 --> Utf8 Class Initialized
INFO - 2018-03-25 08:47:09 --> URI Class Initialized
INFO - 2018-03-25 08:47:09 --> Router Class Initialized
INFO - 2018-03-25 08:47:09 --> Output Class Initialized
INFO - 2018-03-25 08:47:09 --> Security Class Initialized
DEBUG - 2018-03-25 08:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:47:09 --> Input Class Initialized
INFO - 2018-03-25 08:47:09 --> Language Class Initialized
INFO - 2018-03-25 08:47:09 --> Loader Class Initialized
INFO - 2018-03-25 08:47:09 --> Helper loaded: url_helper
INFO - 2018-03-25 08:47:09 --> Helper loaded: form_helper
INFO - 2018-03-25 08:47:09 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:47:09 --> Controller Class Initialized
INFO - 2018-03-25 08:47:09 --> Model Class Initialized
INFO - 2018-03-25 08:47:09 --> Model Class Initialized
INFO - 2018-03-25 08:47:09 --> Model Class Initialized
INFO - 2018-03-25 08:47:09 --> Model Class Initialized
INFO - 2018-03-25 08:47:09 --> Model Class Initialized
INFO - 2018-03-25 08:47:09 --> Helper loaded: date_helper
INFO - 2018-03-25 13:47:09 --> Model Class Initialized
INFO - 2018-03-25 13:47:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:47:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:47:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-25 13:47:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:47:09 --> Final output sent to browser
DEBUG - 2018-03-25 13:47:09 --> Total execution time: 0.1259
INFO - 2018-03-25 08:47:19 --> Config Class Initialized
INFO - 2018-03-25 08:47:19 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:47:19 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:47:19 --> Utf8 Class Initialized
INFO - 2018-03-25 08:47:19 --> URI Class Initialized
INFO - 2018-03-25 08:47:19 --> Router Class Initialized
INFO - 2018-03-25 08:47:19 --> Output Class Initialized
INFO - 2018-03-25 08:47:19 --> Security Class Initialized
DEBUG - 2018-03-25 08:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:47:19 --> Input Class Initialized
INFO - 2018-03-25 08:47:19 --> Language Class Initialized
INFO - 2018-03-25 08:47:19 --> Loader Class Initialized
INFO - 2018-03-25 08:47:19 --> Helper loaded: url_helper
INFO - 2018-03-25 08:47:19 --> Helper loaded: form_helper
INFO - 2018-03-25 08:47:19 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:47:19 --> Controller Class Initialized
INFO - 2018-03-25 08:47:19 --> Model Class Initialized
INFO - 2018-03-25 08:47:19 --> Model Class Initialized
INFO - 2018-03-25 08:47:19 --> Model Class Initialized
INFO - 2018-03-25 08:47:19 --> Model Class Initialized
INFO - 2018-03-25 08:47:19 --> Model Class Initialized
INFO - 2018-03-25 08:47:19 --> Helper loaded: date_helper
INFO - 2018-03-25 13:47:19 --> Model Class Initialized
INFO - 2018-03-25 13:47:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:47:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:47:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/update.php
INFO - 2018-03-25 13:47:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:47:19 --> Final output sent to browser
DEBUG - 2018-03-25 13:47:19 --> Total execution time: 0.0901
INFO - 2018-03-25 08:47:21 --> Config Class Initialized
INFO - 2018-03-25 08:47:21 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:47:21 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:47:21 --> Utf8 Class Initialized
INFO - 2018-03-25 08:47:21 --> URI Class Initialized
INFO - 2018-03-25 08:47:21 --> Router Class Initialized
INFO - 2018-03-25 08:47:21 --> Output Class Initialized
INFO - 2018-03-25 08:47:21 --> Security Class Initialized
DEBUG - 2018-03-25 08:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:47:21 --> Input Class Initialized
INFO - 2018-03-25 08:47:21 --> Language Class Initialized
INFO - 2018-03-25 08:47:21 --> Loader Class Initialized
INFO - 2018-03-25 08:47:21 --> Helper loaded: url_helper
INFO - 2018-03-25 08:47:21 --> Helper loaded: form_helper
INFO - 2018-03-25 08:47:21 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:47:21 --> Controller Class Initialized
INFO - 2018-03-25 08:47:21 --> Model Class Initialized
INFO - 2018-03-25 08:47:21 --> Model Class Initialized
INFO - 2018-03-25 08:47:21 --> Model Class Initialized
INFO - 2018-03-25 08:47:21 --> Model Class Initialized
INFO - 2018-03-25 08:47:21 --> Model Class Initialized
INFO - 2018-03-25 08:47:21 --> Helper loaded: date_helper
INFO - 2018-03-25 13:47:21 --> Model Class Initialized
INFO - 2018-03-25 13:47:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:47:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:47:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-25 13:47:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:47:21 --> Final output sent to browser
DEBUG - 2018-03-25 13:47:21 --> Total execution time: 0.1173
INFO - 2018-03-25 08:47:27 --> Config Class Initialized
INFO - 2018-03-25 08:47:27 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:47:27 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:47:27 --> Utf8 Class Initialized
INFO - 2018-03-25 08:47:27 --> URI Class Initialized
INFO - 2018-03-25 08:47:27 --> Router Class Initialized
INFO - 2018-03-25 08:47:27 --> Output Class Initialized
INFO - 2018-03-25 08:47:27 --> Security Class Initialized
DEBUG - 2018-03-25 08:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:47:27 --> Input Class Initialized
INFO - 2018-03-25 08:47:27 --> Language Class Initialized
INFO - 2018-03-25 08:47:27 --> Loader Class Initialized
INFO - 2018-03-25 08:47:27 --> Helper loaded: url_helper
INFO - 2018-03-25 08:47:27 --> Helper loaded: form_helper
INFO - 2018-03-25 08:47:27 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:47:27 --> Controller Class Initialized
INFO - 2018-03-25 08:47:27 --> Model Class Initialized
INFO - 2018-03-25 08:47:28 --> Model Class Initialized
INFO - 2018-03-25 08:47:28 --> Model Class Initialized
INFO - 2018-03-25 08:47:28 --> Model Class Initialized
INFO - 2018-03-25 08:47:28 --> Model Class Initialized
INFO - 2018-03-25 08:47:28 --> Helper loaded: date_helper
INFO - 2018-03-25 13:47:28 --> Model Class Initialized
INFO - 2018-03-25 13:47:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:47:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:47:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/create.php
INFO - 2018-03-25 13:47:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:47:28 --> Final output sent to browser
DEBUG - 2018-03-25 13:47:28 --> Total execution time: 0.1068
INFO - 2018-03-25 08:47:41 --> Config Class Initialized
INFO - 2018-03-25 08:47:41 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:47:41 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:47:41 --> Utf8 Class Initialized
INFO - 2018-03-25 08:47:41 --> URI Class Initialized
INFO - 2018-03-25 08:47:41 --> Router Class Initialized
INFO - 2018-03-25 08:47:41 --> Output Class Initialized
INFO - 2018-03-25 08:47:41 --> Security Class Initialized
DEBUG - 2018-03-25 08:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:47:41 --> Input Class Initialized
INFO - 2018-03-25 08:47:41 --> Language Class Initialized
INFO - 2018-03-25 08:47:41 --> Loader Class Initialized
INFO - 2018-03-25 08:47:41 --> Helper loaded: url_helper
INFO - 2018-03-25 08:47:41 --> Helper loaded: form_helper
INFO - 2018-03-25 08:47:41 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:47:41 --> Controller Class Initialized
INFO - 2018-03-25 08:47:41 --> Model Class Initialized
INFO - 2018-03-25 08:47:41 --> Model Class Initialized
INFO - 2018-03-25 08:47:41 --> Model Class Initialized
INFO - 2018-03-25 08:47:41 --> Model Class Initialized
INFO - 2018-03-25 08:47:41 --> Model Class Initialized
INFO - 2018-03-25 08:47:41 --> Helper loaded: date_helper
INFO - 2018-03-25 13:47:41 --> Model Class Initialized
INFO - 2018-03-25 13:47:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:47:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:47:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-25 13:47:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:47:41 --> Final output sent to browser
DEBUG - 2018-03-25 13:47:41 --> Total execution time: 0.0923
INFO - 2018-03-25 08:47:45 --> Config Class Initialized
INFO - 2018-03-25 08:47:45 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:47:45 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:47:45 --> Utf8 Class Initialized
INFO - 2018-03-25 08:47:45 --> URI Class Initialized
INFO - 2018-03-25 08:47:45 --> Router Class Initialized
INFO - 2018-03-25 08:47:45 --> Output Class Initialized
INFO - 2018-03-25 08:47:45 --> Security Class Initialized
DEBUG - 2018-03-25 08:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:47:45 --> Input Class Initialized
INFO - 2018-03-25 08:47:45 --> Language Class Initialized
INFO - 2018-03-25 08:47:45 --> Loader Class Initialized
INFO - 2018-03-25 08:47:45 --> Helper loaded: url_helper
INFO - 2018-03-25 08:47:45 --> Helper loaded: form_helper
INFO - 2018-03-25 08:47:45 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:47:45 --> Controller Class Initialized
INFO - 2018-03-25 08:47:45 --> Model Class Initialized
INFO - 2018-03-25 08:47:45 --> Model Class Initialized
INFO - 2018-03-25 08:47:45 --> Model Class Initialized
INFO - 2018-03-25 08:47:45 --> Model Class Initialized
INFO - 2018-03-25 08:47:45 --> Model Class Initialized
INFO - 2018-03-25 08:47:45 --> Helper loaded: date_helper
INFO - 2018-03-25 13:47:45 --> Model Class Initialized
INFO - 2018-03-25 13:47:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:47:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:47:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/create.php
INFO - 2018-03-25 13:47:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:47:45 --> Final output sent to browser
DEBUG - 2018-03-25 13:47:45 --> Total execution time: 0.1352
INFO - 2018-03-25 08:48:39 --> Config Class Initialized
INFO - 2018-03-25 08:48:39 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:48:39 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:48:39 --> Utf8 Class Initialized
INFO - 2018-03-25 08:48:39 --> URI Class Initialized
INFO - 2018-03-25 08:48:39 --> Router Class Initialized
INFO - 2018-03-25 08:48:39 --> Output Class Initialized
INFO - 2018-03-25 08:48:39 --> Security Class Initialized
DEBUG - 2018-03-25 08:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:48:39 --> Input Class Initialized
INFO - 2018-03-25 08:48:39 --> Language Class Initialized
INFO - 2018-03-25 08:48:39 --> Loader Class Initialized
INFO - 2018-03-25 08:48:39 --> Helper loaded: url_helper
INFO - 2018-03-25 08:48:39 --> Helper loaded: form_helper
INFO - 2018-03-25 08:48:39 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:48:39 --> Controller Class Initialized
INFO - 2018-03-25 08:48:39 --> Model Class Initialized
INFO - 2018-03-25 08:48:39 --> Model Class Initialized
INFO - 2018-03-25 08:48:39 --> Model Class Initialized
INFO - 2018-03-25 08:48:39 --> Model Class Initialized
INFO - 2018-03-25 08:48:39 --> Model Class Initialized
INFO - 2018-03-25 08:48:39 --> Helper loaded: date_helper
INFO - 2018-03-25 08:48:39 --> Config Class Initialized
INFO - 2018-03-25 08:48:39 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:48:39 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:48:39 --> Utf8 Class Initialized
INFO - 2018-03-25 08:48:39 --> URI Class Initialized
INFO - 2018-03-25 08:48:39 --> Router Class Initialized
INFO - 2018-03-25 08:48:39 --> Output Class Initialized
INFO - 2018-03-25 08:48:39 --> Security Class Initialized
DEBUG - 2018-03-25 08:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:48:39 --> Input Class Initialized
INFO - 2018-03-25 08:48:39 --> Language Class Initialized
INFO - 2018-03-25 08:48:39 --> Loader Class Initialized
INFO - 2018-03-25 08:48:39 --> Helper loaded: url_helper
INFO - 2018-03-25 08:48:39 --> Helper loaded: form_helper
INFO - 2018-03-25 08:48:39 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:48:39 --> Controller Class Initialized
INFO - 2018-03-25 08:48:39 --> Model Class Initialized
INFO - 2018-03-25 08:48:39 --> Model Class Initialized
INFO - 2018-03-25 08:48:39 --> Model Class Initialized
INFO - 2018-03-25 08:48:39 --> Model Class Initialized
INFO - 2018-03-25 08:48:39 --> Model Class Initialized
INFO - 2018-03-25 08:48:39 --> Helper loaded: date_helper
INFO - 2018-03-25 13:48:39 --> Model Class Initialized
INFO - 2018-03-25 13:48:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:48:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:48:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-25 13:48:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:48:39 --> Final output sent to browser
DEBUG - 2018-03-25 13:48:39 --> Total execution time: 0.1180
INFO - 2018-03-25 08:48:44 --> Config Class Initialized
INFO - 2018-03-25 08:48:44 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:48:44 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:48:44 --> Utf8 Class Initialized
INFO - 2018-03-25 08:48:44 --> URI Class Initialized
INFO - 2018-03-25 08:48:44 --> Router Class Initialized
INFO - 2018-03-25 08:48:44 --> Output Class Initialized
INFO - 2018-03-25 08:48:44 --> Security Class Initialized
DEBUG - 2018-03-25 08:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:48:44 --> Input Class Initialized
INFO - 2018-03-25 08:48:44 --> Language Class Initialized
INFO - 2018-03-25 08:48:44 --> Loader Class Initialized
INFO - 2018-03-25 08:48:44 --> Helper loaded: url_helper
INFO - 2018-03-25 08:48:44 --> Helper loaded: form_helper
INFO - 2018-03-25 08:48:44 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:48:44 --> Controller Class Initialized
INFO - 2018-03-25 08:48:44 --> Model Class Initialized
INFO - 2018-03-25 08:48:44 --> Model Class Initialized
INFO - 2018-03-25 08:48:44 --> Model Class Initialized
INFO - 2018-03-25 08:48:44 --> Model Class Initialized
INFO - 2018-03-25 08:48:44 --> Model Class Initialized
INFO - 2018-03-25 08:48:44 --> Helper loaded: date_helper
INFO - 2018-03-25 13:48:44 --> Model Class Initialized
INFO - 2018-03-25 13:48:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:48:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:48:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-25 13:48:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:48:44 --> Final output sent to browser
DEBUG - 2018-03-25 13:48:44 --> Total execution time: 0.1649
INFO - 2018-03-25 08:48:47 --> Config Class Initialized
INFO - 2018-03-25 08:48:47 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:48:47 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:48:47 --> Utf8 Class Initialized
INFO - 2018-03-25 08:48:47 --> URI Class Initialized
INFO - 2018-03-25 08:48:47 --> Router Class Initialized
INFO - 2018-03-25 08:48:47 --> Output Class Initialized
INFO - 2018-03-25 08:48:47 --> Security Class Initialized
DEBUG - 2018-03-25 08:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:48:47 --> Input Class Initialized
INFO - 2018-03-25 08:48:47 --> Language Class Initialized
INFO - 2018-03-25 08:48:47 --> Loader Class Initialized
INFO - 2018-03-25 08:48:47 --> Helper loaded: url_helper
INFO - 2018-03-25 08:48:47 --> Helper loaded: form_helper
INFO - 2018-03-25 08:48:47 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:48:47 --> Controller Class Initialized
INFO - 2018-03-25 08:48:47 --> Model Class Initialized
INFO - 2018-03-25 08:48:47 --> Model Class Initialized
INFO - 2018-03-25 08:48:47 --> Model Class Initialized
INFO - 2018-03-25 08:48:47 --> Model Class Initialized
INFO - 2018-03-25 08:48:47 --> Model Class Initialized
INFO - 2018-03-25 08:48:47 --> Helper loaded: date_helper
INFO - 2018-03-25 13:48:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/list.php
INFO - 2018-03-25 13:48:47 --> Final output sent to browser
DEBUG - 2018-03-25 13:48:47 --> Total execution time: 0.1472
INFO - 2018-03-25 08:48:49 --> Config Class Initialized
INFO - 2018-03-25 08:48:49 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:48:49 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:48:49 --> Utf8 Class Initialized
INFO - 2018-03-25 08:48:49 --> URI Class Initialized
INFO - 2018-03-25 08:48:49 --> Router Class Initialized
INFO - 2018-03-25 08:48:49 --> Output Class Initialized
INFO - 2018-03-25 08:48:49 --> Security Class Initialized
DEBUG - 2018-03-25 08:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:48:49 --> Input Class Initialized
INFO - 2018-03-25 08:48:49 --> Language Class Initialized
INFO - 2018-03-25 08:48:49 --> Loader Class Initialized
INFO - 2018-03-25 08:48:49 --> Helper loaded: url_helper
INFO - 2018-03-25 08:48:49 --> Helper loaded: form_helper
INFO - 2018-03-25 08:48:49 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:48:49 --> Controller Class Initialized
INFO - 2018-03-25 08:48:49 --> Model Class Initialized
INFO - 2018-03-25 08:48:49 --> Model Class Initialized
INFO - 2018-03-25 08:48:49 --> Model Class Initialized
INFO - 2018-03-25 08:48:49 --> Model Class Initialized
INFO - 2018-03-25 08:48:49 --> Model Class Initialized
INFO - 2018-03-25 08:48:49 --> Helper loaded: date_helper
INFO - 2018-03-25 13:48:49 --> Model Class Initialized
INFO - 2018-03-25 13:48:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:48:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:48:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/create.php
INFO - 2018-03-25 13:48:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:48:50 --> Final output sent to browser
DEBUG - 2018-03-25 13:48:50 --> Total execution time: 0.1974
INFO - 2018-03-25 08:49:04 --> Config Class Initialized
INFO - 2018-03-25 08:49:04 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:49:04 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:49:04 --> Utf8 Class Initialized
INFO - 2018-03-25 08:49:04 --> URI Class Initialized
INFO - 2018-03-25 08:49:04 --> Router Class Initialized
INFO - 2018-03-25 08:49:04 --> Output Class Initialized
INFO - 2018-03-25 08:49:04 --> Security Class Initialized
DEBUG - 2018-03-25 08:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:49:04 --> Input Class Initialized
INFO - 2018-03-25 08:49:04 --> Language Class Initialized
INFO - 2018-03-25 08:49:04 --> Loader Class Initialized
INFO - 2018-03-25 08:49:04 --> Helper loaded: url_helper
INFO - 2018-03-25 08:49:04 --> Helper loaded: form_helper
INFO - 2018-03-25 08:49:04 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:49:04 --> Controller Class Initialized
INFO - 2018-03-25 08:49:04 --> Model Class Initialized
INFO - 2018-03-25 08:49:04 --> Model Class Initialized
INFO - 2018-03-25 08:49:04 --> Model Class Initialized
INFO - 2018-03-25 08:49:04 --> Model Class Initialized
INFO - 2018-03-25 08:49:04 --> Model Class Initialized
INFO - 2018-03-25 08:49:04 --> Helper loaded: date_helper
INFO - 2018-03-25 08:49:04 --> Config Class Initialized
INFO - 2018-03-25 08:49:04 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:49:04 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:49:04 --> Utf8 Class Initialized
INFO - 2018-03-25 08:49:04 --> URI Class Initialized
INFO - 2018-03-25 08:49:04 --> Router Class Initialized
INFO - 2018-03-25 08:49:04 --> Output Class Initialized
INFO - 2018-03-25 08:49:04 --> Security Class Initialized
DEBUG - 2018-03-25 08:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:49:04 --> Input Class Initialized
INFO - 2018-03-25 08:49:04 --> Language Class Initialized
INFO - 2018-03-25 08:49:04 --> Loader Class Initialized
INFO - 2018-03-25 08:49:04 --> Helper loaded: url_helper
INFO - 2018-03-25 08:49:04 --> Helper loaded: form_helper
INFO - 2018-03-25 08:49:04 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:49:04 --> Controller Class Initialized
INFO - 2018-03-25 08:49:04 --> Model Class Initialized
INFO - 2018-03-25 08:49:04 --> Model Class Initialized
INFO - 2018-03-25 08:49:04 --> Model Class Initialized
INFO - 2018-03-25 08:49:04 --> Model Class Initialized
INFO - 2018-03-25 08:49:04 --> Model Class Initialized
INFO - 2018-03-25 08:49:04 --> Helper loaded: date_helper
INFO - 2018-03-25 13:49:04 --> Model Class Initialized
INFO - 2018-03-25 13:49:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:49:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:49:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-25 13:49:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:49:04 --> Final output sent to browser
DEBUG - 2018-03-25 13:49:04 --> Total execution time: 0.0975
INFO - 2018-03-25 08:49:06 --> Config Class Initialized
INFO - 2018-03-25 08:49:06 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:49:06 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:49:06 --> Utf8 Class Initialized
INFO - 2018-03-25 08:49:06 --> URI Class Initialized
INFO - 2018-03-25 08:49:06 --> Router Class Initialized
INFO - 2018-03-25 08:49:06 --> Output Class Initialized
INFO - 2018-03-25 08:49:06 --> Security Class Initialized
DEBUG - 2018-03-25 08:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:49:06 --> Input Class Initialized
INFO - 2018-03-25 08:49:06 --> Language Class Initialized
INFO - 2018-03-25 08:49:06 --> Loader Class Initialized
INFO - 2018-03-25 08:49:06 --> Helper loaded: url_helper
INFO - 2018-03-25 08:49:06 --> Helper loaded: form_helper
INFO - 2018-03-25 08:49:06 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:49:06 --> Controller Class Initialized
INFO - 2018-03-25 08:49:06 --> Model Class Initialized
INFO - 2018-03-25 08:49:06 --> Model Class Initialized
INFO - 2018-03-25 08:49:06 --> Model Class Initialized
INFO - 2018-03-25 08:49:06 --> Model Class Initialized
INFO - 2018-03-25 08:49:06 --> Model Class Initialized
INFO - 2018-03-25 08:49:06 --> Helper loaded: date_helper
INFO - 2018-03-25 13:49:06 --> Model Class Initialized
INFO - 2018-03-25 13:49:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:49:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:49:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/create.php
INFO - 2018-03-25 13:49:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:49:06 --> Final output sent to browser
DEBUG - 2018-03-25 13:49:06 --> Total execution time: 0.1086
INFO - 2018-03-25 08:49:19 --> Config Class Initialized
INFO - 2018-03-25 08:49:19 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:49:19 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:49:19 --> Utf8 Class Initialized
INFO - 2018-03-25 08:49:19 --> URI Class Initialized
INFO - 2018-03-25 08:49:19 --> Router Class Initialized
INFO - 2018-03-25 08:49:19 --> Output Class Initialized
INFO - 2018-03-25 08:49:19 --> Security Class Initialized
DEBUG - 2018-03-25 08:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:49:19 --> Input Class Initialized
INFO - 2018-03-25 08:49:19 --> Language Class Initialized
INFO - 2018-03-25 08:49:19 --> Loader Class Initialized
INFO - 2018-03-25 08:49:19 --> Helper loaded: url_helper
INFO - 2018-03-25 08:49:19 --> Helper loaded: form_helper
INFO - 2018-03-25 08:49:19 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:49:19 --> Controller Class Initialized
INFO - 2018-03-25 08:49:19 --> Model Class Initialized
INFO - 2018-03-25 08:49:19 --> Model Class Initialized
INFO - 2018-03-25 08:49:19 --> Model Class Initialized
INFO - 2018-03-25 08:49:19 --> Model Class Initialized
INFO - 2018-03-25 08:49:19 --> Model Class Initialized
INFO - 2018-03-25 08:49:19 --> Helper loaded: date_helper
INFO - 2018-03-25 08:49:20 --> Config Class Initialized
INFO - 2018-03-25 08:49:20 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:49:20 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:49:20 --> Utf8 Class Initialized
INFO - 2018-03-25 08:49:20 --> URI Class Initialized
INFO - 2018-03-25 08:49:20 --> Router Class Initialized
INFO - 2018-03-25 08:49:20 --> Output Class Initialized
INFO - 2018-03-25 08:49:20 --> Security Class Initialized
DEBUG - 2018-03-25 08:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:49:20 --> Input Class Initialized
INFO - 2018-03-25 08:49:20 --> Language Class Initialized
INFO - 2018-03-25 08:49:20 --> Loader Class Initialized
INFO - 2018-03-25 08:49:20 --> Helper loaded: url_helper
INFO - 2018-03-25 08:49:20 --> Helper loaded: form_helper
INFO - 2018-03-25 08:49:20 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:49:20 --> Controller Class Initialized
INFO - 2018-03-25 08:49:20 --> Model Class Initialized
INFO - 2018-03-25 08:49:20 --> Model Class Initialized
INFO - 2018-03-25 08:49:20 --> Model Class Initialized
INFO - 2018-03-25 08:49:20 --> Model Class Initialized
INFO - 2018-03-25 08:49:20 --> Model Class Initialized
INFO - 2018-03-25 08:49:20 --> Helper loaded: date_helper
INFO - 2018-03-25 13:49:20 --> Model Class Initialized
INFO - 2018-03-25 13:49:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:49:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:49:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-25 13:49:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:49:20 --> Final output sent to browser
DEBUG - 2018-03-25 13:49:20 --> Total execution time: 0.1281
INFO - 2018-03-25 08:49:25 --> Config Class Initialized
INFO - 2018-03-25 08:49:25 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:49:25 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:49:25 --> Utf8 Class Initialized
INFO - 2018-03-25 08:49:25 --> URI Class Initialized
INFO - 2018-03-25 08:49:25 --> Router Class Initialized
INFO - 2018-03-25 08:49:25 --> Output Class Initialized
INFO - 2018-03-25 08:49:25 --> Security Class Initialized
DEBUG - 2018-03-25 08:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:49:25 --> Input Class Initialized
INFO - 2018-03-25 08:49:25 --> Language Class Initialized
INFO - 2018-03-25 08:49:25 --> Loader Class Initialized
INFO - 2018-03-25 08:49:25 --> Helper loaded: url_helper
INFO - 2018-03-25 08:49:25 --> Helper loaded: form_helper
INFO - 2018-03-25 08:49:25 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:49:25 --> Controller Class Initialized
INFO - 2018-03-25 08:49:25 --> Model Class Initialized
INFO - 2018-03-25 08:49:25 --> Model Class Initialized
INFO - 2018-03-25 08:49:25 --> Model Class Initialized
INFO - 2018-03-25 08:49:25 --> Model Class Initialized
INFO - 2018-03-25 08:49:25 --> Model Class Initialized
INFO - 2018-03-25 08:49:25 --> Helper loaded: date_helper
INFO - 2018-03-25 13:49:25 --> Model Class Initialized
INFO - 2018-03-25 13:49:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:49:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:49:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/create.php
INFO - 2018-03-25 13:49:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:49:25 --> Final output sent to browser
DEBUG - 2018-03-25 13:49:25 --> Total execution time: 0.0942
INFO - 2018-03-25 08:49:34 --> Config Class Initialized
INFO - 2018-03-25 08:49:34 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:49:34 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:49:34 --> Utf8 Class Initialized
INFO - 2018-03-25 08:49:34 --> URI Class Initialized
INFO - 2018-03-25 08:49:34 --> Router Class Initialized
INFO - 2018-03-25 08:49:34 --> Output Class Initialized
INFO - 2018-03-25 08:49:34 --> Security Class Initialized
DEBUG - 2018-03-25 08:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:49:34 --> Input Class Initialized
INFO - 2018-03-25 08:49:34 --> Language Class Initialized
INFO - 2018-03-25 08:49:34 --> Loader Class Initialized
INFO - 2018-03-25 08:49:34 --> Helper loaded: url_helper
INFO - 2018-03-25 08:49:34 --> Helper loaded: form_helper
INFO - 2018-03-25 08:49:34 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:49:34 --> Controller Class Initialized
INFO - 2018-03-25 08:49:34 --> Model Class Initialized
INFO - 2018-03-25 08:49:34 --> Model Class Initialized
INFO - 2018-03-25 08:49:34 --> Model Class Initialized
INFO - 2018-03-25 08:49:34 --> Model Class Initialized
INFO - 2018-03-25 08:49:34 --> Model Class Initialized
INFO - 2018-03-25 08:49:34 --> Helper loaded: date_helper
INFO - 2018-03-25 08:49:35 --> Config Class Initialized
INFO - 2018-03-25 08:49:35 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:49:35 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:49:35 --> Utf8 Class Initialized
INFO - 2018-03-25 08:49:35 --> URI Class Initialized
INFO - 2018-03-25 08:49:35 --> Router Class Initialized
INFO - 2018-03-25 08:49:35 --> Output Class Initialized
INFO - 2018-03-25 08:49:35 --> Security Class Initialized
DEBUG - 2018-03-25 08:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:49:35 --> Input Class Initialized
INFO - 2018-03-25 08:49:35 --> Language Class Initialized
INFO - 2018-03-25 08:49:35 --> Loader Class Initialized
INFO - 2018-03-25 08:49:35 --> Helper loaded: url_helper
INFO - 2018-03-25 08:49:35 --> Helper loaded: form_helper
INFO - 2018-03-25 08:49:35 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:49:35 --> Controller Class Initialized
INFO - 2018-03-25 08:49:35 --> Model Class Initialized
INFO - 2018-03-25 08:49:35 --> Model Class Initialized
INFO - 2018-03-25 08:49:35 --> Model Class Initialized
INFO - 2018-03-25 08:49:35 --> Model Class Initialized
INFO - 2018-03-25 08:49:35 --> Model Class Initialized
INFO - 2018-03-25 08:49:35 --> Helper loaded: date_helper
INFO - 2018-03-25 13:49:35 --> Model Class Initialized
INFO - 2018-03-25 13:49:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:49:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:49:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-25 13:49:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:49:35 --> Final output sent to browser
DEBUG - 2018-03-25 13:49:35 --> Total execution time: 0.1135
INFO - 2018-03-25 08:49:39 --> Config Class Initialized
INFO - 2018-03-25 08:49:39 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:49:39 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:49:39 --> Utf8 Class Initialized
INFO - 2018-03-25 08:49:39 --> URI Class Initialized
INFO - 2018-03-25 08:49:39 --> Router Class Initialized
INFO - 2018-03-25 08:49:39 --> Output Class Initialized
INFO - 2018-03-25 08:49:39 --> Security Class Initialized
DEBUG - 2018-03-25 08:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:49:39 --> Input Class Initialized
INFO - 2018-03-25 08:49:39 --> Language Class Initialized
ERROR - 2018-03-25 08:49:39 --> 404 Page Not Found: Kasir/kasir
INFO - 2018-03-25 08:50:09 --> Config Class Initialized
INFO - 2018-03-25 08:50:09 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:50:09 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:50:09 --> Utf8 Class Initialized
INFO - 2018-03-25 08:50:09 --> URI Class Initialized
INFO - 2018-03-25 08:50:09 --> Router Class Initialized
INFO - 2018-03-25 08:50:09 --> Output Class Initialized
INFO - 2018-03-25 08:50:09 --> Security Class Initialized
DEBUG - 2018-03-25 08:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:50:09 --> Input Class Initialized
INFO - 2018-03-25 08:50:09 --> Language Class Initialized
INFO - 2018-03-25 08:50:09 --> Loader Class Initialized
INFO - 2018-03-25 08:50:09 --> Helper loaded: url_helper
INFO - 2018-03-25 08:50:09 --> Helper loaded: form_helper
INFO - 2018-03-25 08:50:09 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:50:09 --> Controller Class Initialized
INFO - 2018-03-25 08:50:09 --> Model Class Initialized
INFO - 2018-03-25 08:50:09 --> Model Class Initialized
INFO - 2018-03-25 08:50:09 --> Model Class Initialized
INFO - 2018-03-25 08:50:09 --> Model Class Initialized
INFO - 2018-03-25 08:50:09 --> Model Class Initialized
INFO - 2018-03-25 08:50:09 --> Helper loaded: date_helper
INFO - 2018-03-25 13:50:09 --> Model Class Initialized
INFO - 2018-03-25 13:50:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:50:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:50:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-25 13:50:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:50:09 --> Final output sent to browser
DEBUG - 2018-03-25 13:50:09 --> Total execution time: 0.0974
INFO - 2018-03-25 08:58:27 --> Config Class Initialized
INFO - 2018-03-25 08:58:27 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:58:27 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:58:27 --> Utf8 Class Initialized
INFO - 2018-03-25 08:58:27 --> URI Class Initialized
INFO - 2018-03-25 08:58:27 --> Router Class Initialized
INFO - 2018-03-25 08:58:27 --> Output Class Initialized
INFO - 2018-03-25 08:58:27 --> Security Class Initialized
DEBUG - 2018-03-25 08:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:58:27 --> Input Class Initialized
INFO - 2018-03-25 08:58:27 --> Language Class Initialized
INFO - 2018-03-25 08:58:27 --> Loader Class Initialized
INFO - 2018-03-25 08:58:27 --> Helper loaded: url_helper
INFO - 2018-03-25 08:58:27 --> Helper loaded: form_helper
INFO - 2018-03-25 08:58:27 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:58:27 --> Controller Class Initialized
INFO - 2018-03-25 08:58:27 --> Model Class Initialized
INFO - 2018-03-25 08:58:27 --> Model Class Initialized
INFO - 2018-03-25 08:58:27 --> Model Class Initialized
INFO - 2018-03-25 08:58:27 --> Model Class Initialized
INFO - 2018-03-25 08:58:27 --> Model Class Initialized
INFO - 2018-03-25 08:58:27 --> Helper loaded: date_helper
INFO - 2018-03-25 13:58:27 --> Model Class Initialized
INFO - 2018-03-25 13:58:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 13:58:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 13:58:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/group_akses/table.php
INFO - 2018-03-25 13:58:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 13:58:27 --> Final output sent to browser
DEBUG - 2018-03-25 13:58:27 --> Total execution time: 0.1046
INFO - 2018-03-25 08:58:31 --> Config Class Initialized
INFO - 2018-03-25 08:58:31 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:58:31 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:58:31 --> Utf8 Class Initialized
INFO - 2018-03-25 08:58:31 --> URI Class Initialized
INFO - 2018-03-25 08:58:31 --> Router Class Initialized
INFO - 2018-03-25 08:58:31 --> Output Class Initialized
INFO - 2018-03-25 08:58:31 --> Security Class Initialized
DEBUG - 2018-03-25 08:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:58:31 --> Input Class Initialized
INFO - 2018-03-25 08:58:31 --> Language Class Initialized
INFO - 2018-03-25 08:58:31 --> Loader Class Initialized
INFO - 2018-03-25 08:58:31 --> Helper loaded: url_helper
INFO - 2018-03-25 08:58:31 --> Helper loaded: form_helper
INFO - 2018-03-25 08:58:31 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:58:31 --> Controller Class Initialized
INFO - 2018-03-25 08:58:31 --> Model Class Initialized
INFO - 2018-03-25 08:58:31 --> Model Class Initialized
INFO - 2018-03-25 08:58:31 --> Model Class Initialized
INFO - 2018-03-25 08:58:31 --> Model Class Initialized
INFO - 2018-03-25 08:58:31 --> Model Class Initialized
INFO - 2018-03-25 08:58:31 --> Helper loaded: date_helper
INFO - 2018-03-25 13:58:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/group_akses/list.php
INFO - 2018-03-25 13:58:31 --> Final output sent to browser
DEBUG - 2018-03-25 13:58:31 --> Total execution time: 0.1814
INFO - 2018-03-25 08:58:36 --> Config Class Initialized
INFO - 2018-03-25 08:58:36 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:58:36 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:58:36 --> Utf8 Class Initialized
INFO - 2018-03-25 08:58:36 --> URI Class Initialized
INFO - 2018-03-25 08:58:36 --> Router Class Initialized
INFO - 2018-03-25 08:58:36 --> Output Class Initialized
INFO - 2018-03-25 08:58:36 --> Security Class Initialized
DEBUG - 2018-03-25 08:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:58:36 --> Input Class Initialized
INFO - 2018-03-25 08:58:36 --> Language Class Initialized
INFO - 2018-03-25 08:58:36 --> Loader Class Initialized
INFO - 2018-03-25 08:58:36 --> Helper loaded: url_helper
INFO - 2018-03-25 08:58:36 --> Helper loaded: form_helper
INFO - 2018-03-25 08:58:36 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:58:36 --> Controller Class Initialized
INFO - 2018-03-25 08:58:36 --> Model Class Initialized
INFO - 2018-03-25 08:58:36 --> Model Class Initialized
INFO - 2018-03-25 08:58:36 --> Model Class Initialized
INFO - 2018-03-25 08:58:36 --> Model Class Initialized
INFO - 2018-03-25 08:58:36 --> Model Class Initialized
INFO - 2018-03-25 08:58:36 --> Helper loaded: date_helper
INFO - 2018-03-25 13:58:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/group_akses/list.php
INFO - 2018-03-25 13:58:36 --> Final output sent to browser
DEBUG - 2018-03-25 13:58:36 --> Total execution time: 0.0893
INFO - 2018-03-25 08:58:38 --> Config Class Initialized
INFO - 2018-03-25 08:58:38 --> Hooks Class Initialized
DEBUG - 2018-03-25 08:58:38 --> UTF-8 Support Enabled
INFO - 2018-03-25 08:58:38 --> Utf8 Class Initialized
INFO - 2018-03-25 08:58:38 --> URI Class Initialized
INFO - 2018-03-25 08:58:38 --> Router Class Initialized
INFO - 2018-03-25 08:58:38 --> Output Class Initialized
INFO - 2018-03-25 08:58:38 --> Security Class Initialized
DEBUG - 2018-03-25 08:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 08:58:38 --> Input Class Initialized
INFO - 2018-03-25 08:58:38 --> Language Class Initialized
INFO - 2018-03-25 08:58:38 --> Loader Class Initialized
INFO - 2018-03-25 08:58:38 --> Helper loaded: url_helper
INFO - 2018-03-25 08:58:38 --> Helper loaded: form_helper
INFO - 2018-03-25 08:58:38 --> Database Driver Class Initialized
DEBUG - 2018-03-25 08:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 08:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 08:58:38 --> Controller Class Initialized
INFO - 2018-03-25 08:58:38 --> Model Class Initialized
INFO - 2018-03-25 08:58:38 --> Model Class Initialized
INFO - 2018-03-25 08:58:38 --> Model Class Initialized
INFO - 2018-03-25 08:58:38 --> Model Class Initialized
INFO - 2018-03-25 08:58:38 --> Model Class Initialized
INFO - 2018-03-25 08:58:38 --> Helper loaded: date_helper
INFO - 2018-03-25 13:58:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/group_akses/list.php
INFO - 2018-03-25 13:58:38 --> Final output sent to browser
DEBUG - 2018-03-25 13:58:38 --> Total execution time: 0.0700
INFO - 2018-03-25 09:11:59 --> Config Class Initialized
INFO - 2018-03-25 09:11:59 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:11:59 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:11:59 --> Utf8 Class Initialized
INFO - 2018-03-25 09:11:59 --> URI Class Initialized
INFO - 2018-03-25 09:11:59 --> Router Class Initialized
INFO - 2018-03-25 09:11:59 --> Output Class Initialized
INFO - 2018-03-25 09:11:59 --> Security Class Initialized
DEBUG - 2018-03-25 09:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:11:59 --> Input Class Initialized
INFO - 2018-03-25 09:11:59 --> Language Class Initialized
INFO - 2018-03-25 09:11:59 --> Loader Class Initialized
INFO - 2018-03-25 09:11:59 --> Helper loaded: url_helper
INFO - 2018-03-25 09:11:59 --> Helper loaded: form_helper
INFO - 2018-03-25 09:11:59 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:11:59 --> Controller Class Initialized
INFO - 2018-03-25 09:11:59 --> Model Class Initialized
INFO - 2018-03-25 09:11:59 --> Model Class Initialized
INFO - 2018-03-25 09:11:59 --> Model Class Initialized
INFO - 2018-03-25 09:11:59 --> Model Class Initialized
INFO - 2018-03-25 09:11:59 --> Model Class Initialized
INFO - 2018-03-25 09:11:59 --> Model Class Initialized
INFO - 2018-03-25 09:11:59 --> Model Class Initialized
INFO - 2018-03-25 09:11:59 --> Model Class Initialized
INFO - 2018-03-25 09:11:59 --> Model Class Initialized
INFO - 2018-03-25 09:11:59 --> Model Class Initialized
INFO - 2018-03-25 09:11:59 --> Model Class Initialized
INFO - 2018-03-25 09:11:59 --> Model Class Initialized
INFO - 2018-03-25 09:11:59 --> Model Class Initialized
INFO - 2018-03-25 09:11:59 --> Helper loaded: date_helper
INFO - 2018-03-25 09:11:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:11:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 14:11:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 14:11:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-25 14:11:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 14:11:59 --> Final output sent to browser
DEBUG - 2018-03-25 14:11:59 --> Total execution time: 0.1116
INFO - 2018-03-25 09:12:04 --> Config Class Initialized
INFO - 2018-03-25 09:12:04 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:12:04 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:12:04 --> Utf8 Class Initialized
INFO - 2018-03-25 09:12:04 --> URI Class Initialized
INFO - 2018-03-25 09:12:04 --> Router Class Initialized
INFO - 2018-03-25 09:12:04 --> Output Class Initialized
INFO - 2018-03-25 09:12:04 --> Security Class Initialized
DEBUG - 2018-03-25 09:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:12:04 --> Input Class Initialized
INFO - 2018-03-25 09:12:04 --> Language Class Initialized
INFO - 2018-03-25 09:12:04 --> Loader Class Initialized
INFO - 2018-03-25 09:12:04 --> Helper loaded: url_helper
INFO - 2018-03-25 09:12:04 --> Helper loaded: form_helper
INFO - 2018-03-25 09:12:04 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:12:04 --> Controller Class Initialized
INFO - 2018-03-25 09:12:04 --> Model Class Initialized
INFO - 2018-03-25 09:12:04 --> Model Class Initialized
INFO - 2018-03-25 09:12:04 --> Model Class Initialized
INFO - 2018-03-25 09:12:04 --> Model Class Initialized
INFO - 2018-03-25 09:12:04 --> Model Class Initialized
INFO - 2018-03-25 09:12:04 --> Model Class Initialized
INFO - 2018-03-25 09:12:04 --> Model Class Initialized
INFO - 2018-03-25 09:12:04 --> Model Class Initialized
INFO - 2018-03-25 09:12:04 --> Model Class Initialized
INFO - 2018-03-25 09:12:04 --> Model Class Initialized
INFO - 2018-03-25 09:12:04 --> Model Class Initialized
INFO - 2018-03-25 09:12:04 --> Model Class Initialized
INFO - 2018-03-25 09:12:04 --> Model Class Initialized
INFO - 2018-03-25 09:12:04 --> Helper loaded: date_helper
INFO - 2018-03-25 09:12:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:12:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/list.php
INFO - 2018-03-25 14:12:04 --> Final output sent to browser
DEBUG - 2018-03-25 14:12:04 --> Total execution time: 0.1215
INFO - 2018-03-25 09:35:55 --> Config Class Initialized
INFO - 2018-03-25 09:35:55 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:35:55 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:35:55 --> Utf8 Class Initialized
INFO - 2018-03-25 09:35:55 --> URI Class Initialized
INFO - 2018-03-25 09:35:55 --> Router Class Initialized
INFO - 2018-03-25 09:35:55 --> Output Class Initialized
INFO - 2018-03-25 09:35:55 --> Security Class Initialized
DEBUG - 2018-03-25 09:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:35:55 --> Input Class Initialized
INFO - 2018-03-25 09:35:55 --> Language Class Initialized
INFO - 2018-03-25 09:35:55 --> Loader Class Initialized
INFO - 2018-03-25 09:35:55 --> Helper loaded: url_helper
INFO - 2018-03-25 09:35:55 --> Helper loaded: form_helper
INFO - 2018-03-25 09:35:55 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:35:55 --> Controller Class Initialized
INFO - 2018-03-25 09:35:55 --> Model Class Initialized
INFO - 2018-03-25 09:35:55 --> Model Class Initialized
INFO - 2018-03-25 09:35:55 --> Model Class Initialized
INFO - 2018-03-25 09:35:55 --> Model Class Initialized
INFO - 2018-03-25 09:35:55 --> Model Class Initialized
INFO - 2018-03-25 09:35:55 --> Model Class Initialized
INFO - 2018-03-25 09:35:55 --> Model Class Initialized
INFO - 2018-03-25 09:35:55 --> Helper loaded: date_helper
INFO - 2018-03-25 09:35:55 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:35:55 --> Model Class Initialized
INFO - 2018-03-25 14:35:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 14:35:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 14:35:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-25 14:35:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 14:35:55 --> Final output sent to browser
DEBUG - 2018-03-25 14:35:55 --> Total execution time: 0.1204
INFO - 2018-03-25 09:35:57 --> Config Class Initialized
INFO - 2018-03-25 09:35:57 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:35:57 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:35:57 --> Utf8 Class Initialized
INFO - 2018-03-25 09:35:57 --> URI Class Initialized
INFO - 2018-03-25 09:35:57 --> Router Class Initialized
INFO - 2018-03-25 09:35:57 --> Output Class Initialized
INFO - 2018-03-25 09:35:57 --> Security Class Initialized
DEBUG - 2018-03-25 09:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:35:57 --> Input Class Initialized
INFO - 2018-03-25 09:35:57 --> Language Class Initialized
INFO - 2018-03-25 09:35:57 --> Loader Class Initialized
INFO - 2018-03-25 09:35:57 --> Helper loaded: url_helper
INFO - 2018-03-25 09:35:57 --> Helper loaded: form_helper
INFO - 2018-03-25 09:35:57 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:35:57 --> Controller Class Initialized
INFO - 2018-03-25 09:35:57 --> Model Class Initialized
INFO - 2018-03-25 09:35:57 --> Model Class Initialized
INFO - 2018-03-25 09:35:57 --> Model Class Initialized
INFO - 2018-03-25 09:35:57 --> Model Class Initialized
INFO - 2018-03-25 09:35:57 --> Model Class Initialized
INFO - 2018-03-25 09:35:57 --> Model Class Initialized
INFO - 2018-03-25 09:35:57 --> Model Class Initialized
INFO - 2018-03-25 09:35:57 --> Helper loaded: date_helper
INFO - 2018-03-25 09:35:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:35:57 --> Model Class Initialized
INFO - 2018-03-25 14:35:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 14:35:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 14:35:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/create.php
INFO - 2018-03-25 14:35:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 14:35:57 --> Final output sent to browser
DEBUG - 2018-03-25 14:35:57 --> Total execution time: 0.1912
INFO - 2018-03-25 09:36:07 --> Config Class Initialized
INFO - 2018-03-25 09:36:07 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:36:07 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:36:07 --> Utf8 Class Initialized
INFO - 2018-03-25 09:36:07 --> URI Class Initialized
INFO - 2018-03-25 09:36:07 --> Router Class Initialized
INFO - 2018-03-25 09:36:07 --> Output Class Initialized
INFO - 2018-03-25 09:36:07 --> Security Class Initialized
DEBUG - 2018-03-25 09:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:36:07 --> Input Class Initialized
INFO - 2018-03-25 09:36:07 --> Language Class Initialized
INFO - 2018-03-25 09:36:07 --> Loader Class Initialized
INFO - 2018-03-25 09:36:07 --> Helper loaded: url_helper
INFO - 2018-03-25 09:36:07 --> Helper loaded: form_helper
INFO - 2018-03-25 09:36:07 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:36:07 --> Controller Class Initialized
INFO - 2018-03-25 09:36:07 --> Model Class Initialized
INFO - 2018-03-25 09:36:07 --> Model Class Initialized
INFO - 2018-03-25 09:36:07 --> Helper loaded: date_helper
INFO - 2018-03-25 09:36:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:36:07 --> Final output sent to browser
DEBUG - 2018-03-25 14:36:07 --> Total execution time: 0.0740
INFO - 2018-03-25 09:36:12 --> Config Class Initialized
INFO - 2018-03-25 09:36:12 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:36:12 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:36:12 --> Utf8 Class Initialized
INFO - 2018-03-25 09:36:12 --> URI Class Initialized
INFO - 2018-03-25 09:36:12 --> Router Class Initialized
INFO - 2018-03-25 09:36:12 --> Output Class Initialized
INFO - 2018-03-25 09:36:12 --> Security Class Initialized
DEBUG - 2018-03-25 09:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:36:12 --> Input Class Initialized
INFO - 2018-03-25 09:36:12 --> Language Class Initialized
INFO - 2018-03-25 09:36:12 --> Loader Class Initialized
INFO - 2018-03-25 09:36:12 --> Helper loaded: url_helper
INFO - 2018-03-25 09:36:12 --> Helper loaded: form_helper
INFO - 2018-03-25 09:36:12 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:36:12 --> Controller Class Initialized
INFO - 2018-03-25 09:36:12 --> Model Class Initialized
INFO - 2018-03-25 09:36:12 --> Model Class Initialized
INFO - 2018-03-25 09:36:12 --> Model Class Initialized
INFO - 2018-03-25 09:36:12 --> Model Class Initialized
INFO - 2018-03-25 09:36:12 --> Model Class Initialized
INFO - 2018-03-25 09:36:12 --> Model Class Initialized
INFO - 2018-03-25 09:36:12 --> Model Class Initialized
INFO - 2018-03-25 09:36:12 --> Helper loaded: date_helper
INFO - 2018-03-25 09:36:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 09:36:12 --> Config Class Initialized
INFO - 2018-03-25 09:36:12 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:36:12 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:36:12 --> Utf8 Class Initialized
INFO - 2018-03-25 09:36:12 --> URI Class Initialized
INFO - 2018-03-25 09:36:12 --> Router Class Initialized
INFO - 2018-03-25 09:36:12 --> Output Class Initialized
INFO - 2018-03-25 09:36:12 --> Security Class Initialized
DEBUG - 2018-03-25 09:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:36:12 --> Input Class Initialized
INFO - 2018-03-25 09:36:12 --> Language Class Initialized
INFO - 2018-03-25 09:36:12 --> Loader Class Initialized
INFO - 2018-03-25 09:36:12 --> Helper loaded: url_helper
INFO - 2018-03-25 09:36:12 --> Helper loaded: form_helper
INFO - 2018-03-25 09:36:12 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:36:12 --> Controller Class Initialized
INFO - 2018-03-25 09:36:12 --> Model Class Initialized
INFO - 2018-03-25 09:36:12 --> Model Class Initialized
INFO - 2018-03-25 09:36:12 --> Model Class Initialized
INFO - 2018-03-25 09:36:12 --> Model Class Initialized
INFO - 2018-03-25 09:36:12 --> Model Class Initialized
INFO - 2018-03-25 09:36:12 --> Model Class Initialized
INFO - 2018-03-25 09:36:12 --> Model Class Initialized
INFO - 2018-03-25 09:36:12 --> Helper loaded: date_helper
INFO - 2018-03-25 09:36:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:36:12 --> Model Class Initialized
INFO - 2018-03-25 14:36:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 14:36:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 14:36:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 14:36:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 14:36:12 --> Final output sent to browser
DEBUG - 2018-03-25 14:36:12 --> Total execution time: 0.1171
INFO - 2018-03-25 09:36:23 --> Config Class Initialized
INFO - 2018-03-25 09:36:23 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:36:23 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:36:23 --> Utf8 Class Initialized
INFO - 2018-03-25 09:36:23 --> URI Class Initialized
INFO - 2018-03-25 09:36:23 --> Router Class Initialized
INFO - 2018-03-25 09:36:23 --> Output Class Initialized
INFO - 2018-03-25 09:36:23 --> Security Class Initialized
DEBUG - 2018-03-25 09:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:36:23 --> Input Class Initialized
INFO - 2018-03-25 09:36:23 --> Language Class Initialized
INFO - 2018-03-25 09:36:23 --> Loader Class Initialized
INFO - 2018-03-25 09:36:23 --> Helper loaded: url_helper
INFO - 2018-03-25 09:36:23 --> Helper loaded: form_helper
INFO - 2018-03-25 09:36:23 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:36:23 --> Controller Class Initialized
INFO - 2018-03-25 09:36:23 --> Model Class Initialized
INFO - 2018-03-25 09:36:23 --> Model Class Initialized
INFO - 2018-03-25 09:36:23 --> Model Class Initialized
INFO - 2018-03-25 09:36:23 --> Model Class Initialized
INFO - 2018-03-25 09:36:23 --> Model Class Initialized
INFO - 2018-03-25 09:36:23 --> Model Class Initialized
INFO - 2018-03-25 09:36:23 --> Model Class Initialized
INFO - 2018-03-25 09:36:23 --> Helper loaded: date_helper
INFO - 2018-03-25 09:36:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:36:23 --> Model Class Initialized
INFO - 2018-03-25 14:36:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 14:36:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 14:36:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-25 14:36:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 14:36:23 --> Final output sent to browser
DEBUG - 2018-03-25 14:36:23 --> Total execution time: 0.1579
INFO - 2018-03-25 09:36:28 --> Config Class Initialized
INFO - 2018-03-25 09:36:28 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:36:28 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:36:28 --> Utf8 Class Initialized
INFO - 2018-03-25 09:36:28 --> URI Class Initialized
INFO - 2018-03-25 09:36:28 --> Router Class Initialized
INFO - 2018-03-25 09:36:28 --> Output Class Initialized
INFO - 2018-03-25 09:36:28 --> Security Class Initialized
DEBUG - 2018-03-25 09:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:36:28 --> Input Class Initialized
INFO - 2018-03-25 09:36:28 --> Language Class Initialized
INFO - 2018-03-25 09:36:28 --> Loader Class Initialized
INFO - 2018-03-25 09:36:28 --> Helper loaded: url_helper
INFO - 2018-03-25 09:36:28 --> Helper loaded: form_helper
INFO - 2018-03-25 09:36:28 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:36:28 --> Controller Class Initialized
INFO - 2018-03-25 09:36:28 --> Model Class Initialized
INFO - 2018-03-25 09:36:28 --> Model Class Initialized
INFO - 2018-03-25 09:36:28 --> Model Class Initialized
INFO - 2018-03-25 09:36:28 --> Model Class Initialized
INFO - 2018-03-25 09:36:28 --> Model Class Initialized
INFO - 2018-03-25 09:36:28 --> Model Class Initialized
INFO - 2018-03-25 09:36:28 --> Model Class Initialized
INFO - 2018-03-25 09:36:28 --> Helper loaded: date_helper
INFO - 2018-03-25 09:36:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:36:28 --> Model Class Initialized
INFO - 2018-03-25 14:36:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 14:36:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 14:36:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/edit.php
INFO - 2018-03-25 14:36:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 14:36:28 --> Final output sent to browser
DEBUG - 2018-03-25 14:36:28 --> Total execution time: 0.1457
INFO - 2018-03-25 09:36:34 --> Config Class Initialized
INFO - 2018-03-25 09:36:34 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:36:34 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:36:34 --> Utf8 Class Initialized
INFO - 2018-03-25 09:36:34 --> URI Class Initialized
INFO - 2018-03-25 09:36:34 --> Router Class Initialized
INFO - 2018-03-25 09:36:34 --> Output Class Initialized
INFO - 2018-03-25 09:36:34 --> Security Class Initialized
DEBUG - 2018-03-25 09:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:36:34 --> Input Class Initialized
INFO - 2018-03-25 09:36:34 --> Language Class Initialized
INFO - 2018-03-25 09:36:34 --> Loader Class Initialized
INFO - 2018-03-25 09:36:34 --> Helper loaded: url_helper
INFO - 2018-03-25 09:36:34 --> Helper loaded: form_helper
INFO - 2018-03-25 09:36:34 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:36:34 --> Controller Class Initialized
INFO - 2018-03-25 09:36:34 --> Model Class Initialized
INFO - 2018-03-25 09:36:34 --> Model Class Initialized
INFO - 2018-03-25 09:36:34 --> Model Class Initialized
INFO - 2018-03-25 09:36:34 --> Model Class Initialized
INFO - 2018-03-25 09:36:34 --> Model Class Initialized
INFO - 2018-03-25 09:36:34 --> Model Class Initialized
INFO - 2018-03-25 09:36:34 --> Model Class Initialized
INFO - 2018-03-25 09:36:34 --> Helper loaded: date_helper
INFO - 2018-03-25 09:36:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 09:36:34 --> Config Class Initialized
INFO - 2018-03-25 09:36:34 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:36:34 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:36:34 --> Utf8 Class Initialized
INFO - 2018-03-25 09:36:34 --> URI Class Initialized
INFO - 2018-03-25 09:36:34 --> Router Class Initialized
INFO - 2018-03-25 09:36:34 --> Output Class Initialized
INFO - 2018-03-25 09:36:34 --> Security Class Initialized
DEBUG - 2018-03-25 09:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:36:34 --> Input Class Initialized
INFO - 2018-03-25 09:36:34 --> Language Class Initialized
INFO - 2018-03-25 09:36:34 --> Loader Class Initialized
INFO - 2018-03-25 09:36:34 --> Helper loaded: url_helper
INFO - 2018-03-25 09:36:34 --> Helper loaded: form_helper
INFO - 2018-03-25 09:36:34 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:36:34 --> Controller Class Initialized
INFO - 2018-03-25 09:36:34 --> Model Class Initialized
INFO - 2018-03-25 09:36:34 --> Model Class Initialized
INFO - 2018-03-25 09:36:34 --> Model Class Initialized
INFO - 2018-03-25 09:36:34 --> Model Class Initialized
INFO - 2018-03-25 09:36:34 --> Model Class Initialized
INFO - 2018-03-25 09:36:34 --> Model Class Initialized
INFO - 2018-03-25 09:36:34 --> Model Class Initialized
INFO - 2018-03-25 09:36:34 --> Helper loaded: date_helper
INFO - 2018-03-25 09:36:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:36:34 --> Model Class Initialized
INFO - 2018-03-25 14:36:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 14:36:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 14:36:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 14:36:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 14:36:34 --> Final output sent to browser
DEBUG - 2018-03-25 14:36:34 --> Total execution time: 0.1140
INFO - 2018-03-25 09:36:36 --> Config Class Initialized
INFO - 2018-03-25 09:36:36 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:36:36 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:36:36 --> Utf8 Class Initialized
INFO - 2018-03-25 09:36:36 --> URI Class Initialized
INFO - 2018-03-25 09:36:36 --> Router Class Initialized
INFO - 2018-03-25 09:36:36 --> Output Class Initialized
INFO - 2018-03-25 09:36:36 --> Security Class Initialized
DEBUG - 2018-03-25 09:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:36:36 --> Input Class Initialized
INFO - 2018-03-25 09:36:36 --> Language Class Initialized
INFO - 2018-03-25 09:36:36 --> Loader Class Initialized
INFO - 2018-03-25 09:36:36 --> Helper loaded: url_helper
INFO - 2018-03-25 09:36:36 --> Helper loaded: form_helper
INFO - 2018-03-25 09:36:36 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:36:36 --> Controller Class Initialized
INFO - 2018-03-25 09:36:36 --> Model Class Initialized
INFO - 2018-03-25 09:36:36 --> Model Class Initialized
INFO - 2018-03-25 09:36:36 --> Model Class Initialized
INFO - 2018-03-25 09:36:36 --> Model Class Initialized
INFO - 2018-03-25 09:36:36 --> Model Class Initialized
INFO - 2018-03-25 09:36:36 --> Model Class Initialized
INFO - 2018-03-25 09:36:36 --> Model Class Initialized
INFO - 2018-03-25 09:36:36 --> Helper loaded: date_helper
INFO - 2018-03-25 09:36:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:36:36 --> Model Class Initialized
INFO - 2018-03-25 14:36:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 14:36:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 14:36:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-25 14:36:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 14:36:36 --> Final output sent to browser
DEBUG - 2018-03-25 14:36:36 --> Total execution time: 0.1246
INFO - 2018-03-25 09:36:41 --> Config Class Initialized
INFO - 2018-03-25 09:36:41 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:36:41 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:36:41 --> Utf8 Class Initialized
INFO - 2018-03-25 09:36:41 --> URI Class Initialized
INFO - 2018-03-25 09:36:41 --> Router Class Initialized
INFO - 2018-03-25 09:36:41 --> Output Class Initialized
INFO - 2018-03-25 09:36:41 --> Security Class Initialized
DEBUG - 2018-03-25 09:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:36:41 --> Input Class Initialized
INFO - 2018-03-25 09:36:41 --> Language Class Initialized
INFO - 2018-03-25 09:36:41 --> Loader Class Initialized
INFO - 2018-03-25 09:36:41 --> Helper loaded: url_helper
INFO - 2018-03-25 09:36:41 --> Helper loaded: form_helper
INFO - 2018-03-25 09:36:41 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:36:41 --> Controller Class Initialized
INFO - 2018-03-25 09:36:41 --> Model Class Initialized
INFO - 2018-03-25 09:36:41 --> Model Class Initialized
INFO - 2018-03-25 09:36:41 --> Model Class Initialized
INFO - 2018-03-25 09:36:41 --> Model Class Initialized
INFO - 2018-03-25 09:36:41 --> Model Class Initialized
INFO - 2018-03-25 09:36:41 --> Model Class Initialized
INFO - 2018-03-25 09:36:41 --> Model Class Initialized
INFO - 2018-03-25 09:36:41 --> Helper loaded: date_helper
INFO - 2018-03-25 09:36:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 09:36:42 --> Config Class Initialized
INFO - 2018-03-25 09:36:42 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:36:42 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:36:42 --> Utf8 Class Initialized
INFO - 2018-03-25 09:36:42 --> URI Class Initialized
INFO - 2018-03-25 09:36:42 --> Router Class Initialized
INFO - 2018-03-25 09:36:42 --> Output Class Initialized
INFO - 2018-03-25 09:36:42 --> Security Class Initialized
DEBUG - 2018-03-25 09:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:36:42 --> Input Class Initialized
INFO - 2018-03-25 09:36:42 --> Language Class Initialized
INFO - 2018-03-25 09:36:42 --> Loader Class Initialized
INFO - 2018-03-25 09:36:42 --> Helper loaded: url_helper
INFO - 2018-03-25 09:36:42 --> Helper loaded: form_helper
INFO - 2018-03-25 09:36:42 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:36:42 --> Controller Class Initialized
INFO - 2018-03-25 09:36:42 --> Model Class Initialized
INFO - 2018-03-25 09:36:42 --> Model Class Initialized
INFO - 2018-03-25 09:36:42 --> Model Class Initialized
INFO - 2018-03-25 09:36:42 --> Model Class Initialized
INFO - 2018-03-25 09:36:42 --> Model Class Initialized
INFO - 2018-03-25 09:36:42 --> Model Class Initialized
INFO - 2018-03-25 09:36:42 --> Model Class Initialized
INFO - 2018-03-25 09:36:42 --> Helper loaded: date_helper
INFO - 2018-03-25 09:36:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:36:42 --> Model Class Initialized
INFO - 2018-03-25 14:36:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 14:36:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 14:36:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-25 14:36:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 14:36:42 --> Final output sent to browser
DEBUG - 2018-03-25 14:36:42 --> Total execution time: 0.1314
INFO - 2018-03-25 09:36:51 --> Config Class Initialized
INFO - 2018-03-25 09:36:51 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:36:51 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:36:51 --> Utf8 Class Initialized
INFO - 2018-03-25 09:36:51 --> URI Class Initialized
INFO - 2018-03-25 09:36:51 --> Router Class Initialized
INFO - 2018-03-25 09:36:51 --> Output Class Initialized
INFO - 2018-03-25 09:36:51 --> Security Class Initialized
DEBUG - 2018-03-25 09:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:36:51 --> Input Class Initialized
INFO - 2018-03-25 09:36:51 --> Language Class Initialized
INFO - 2018-03-25 09:36:51 --> Loader Class Initialized
INFO - 2018-03-25 09:36:51 --> Helper loaded: url_helper
INFO - 2018-03-25 09:36:51 --> Helper loaded: form_helper
INFO - 2018-03-25 09:36:51 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:36:51 --> Controller Class Initialized
INFO - 2018-03-25 09:36:51 --> Model Class Initialized
INFO - 2018-03-25 09:36:51 --> Model Class Initialized
INFO - 2018-03-25 09:36:51 --> Model Class Initialized
INFO - 2018-03-25 09:36:51 --> Model Class Initialized
INFO - 2018-03-25 09:36:51 --> Model Class Initialized
INFO - 2018-03-25 09:36:51 --> Model Class Initialized
INFO - 2018-03-25 09:36:51 --> Model Class Initialized
INFO - 2018-03-25 09:36:51 --> Helper loaded: date_helper
INFO - 2018-03-25 09:36:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:36:51 --> Model Class Initialized
INFO - 2018-03-25 14:36:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 14:36:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 14:36:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/create.php
INFO - 2018-03-25 14:36:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 14:36:51 --> Final output sent to browser
DEBUG - 2018-03-25 14:36:51 --> Total execution time: 0.1767
INFO - 2018-03-25 09:37:02 --> Config Class Initialized
INFO - 2018-03-25 09:37:02 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:37:02 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:37:02 --> Utf8 Class Initialized
INFO - 2018-03-25 09:37:02 --> URI Class Initialized
INFO - 2018-03-25 09:37:02 --> Router Class Initialized
INFO - 2018-03-25 09:37:02 --> Output Class Initialized
INFO - 2018-03-25 09:37:02 --> Security Class Initialized
DEBUG - 2018-03-25 09:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:37:02 --> Input Class Initialized
INFO - 2018-03-25 09:37:02 --> Language Class Initialized
INFO - 2018-03-25 09:37:02 --> Loader Class Initialized
INFO - 2018-03-25 09:37:02 --> Helper loaded: url_helper
INFO - 2018-03-25 09:37:02 --> Helper loaded: form_helper
INFO - 2018-03-25 09:37:02 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:37:02 --> Controller Class Initialized
INFO - 2018-03-25 09:37:02 --> Model Class Initialized
INFO - 2018-03-25 09:37:02 --> Model Class Initialized
INFO - 2018-03-25 09:37:02 --> Helper loaded: date_helper
INFO - 2018-03-25 09:37:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:37:02 --> Final output sent to browser
DEBUG - 2018-03-25 14:37:02 --> Total execution time: 0.1722
INFO - 2018-03-25 09:37:12 --> Config Class Initialized
INFO - 2018-03-25 09:37:12 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:37:12 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:37:12 --> Utf8 Class Initialized
INFO - 2018-03-25 09:37:12 --> URI Class Initialized
INFO - 2018-03-25 09:37:12 --> Router Class Initialized
INFO - 2018-03-25 09:37:12 --> Output Class Initialized
INFO - 2018-03-25 09:37:12 --> Security Class Initialized
DEBUG - 2018-03-25 09:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:37:12 --> Input Class Initialized
INFO - 2018-03-25 09:37:12 --> Language Class Initialized
INFO - 2018-03-25 09:37:12 --> Loader Class Initialized
INFO - 2018-03-25 09:37:12 --> Helper loaded: url_helper
INFO - 2018-03-25 09:37:12 --> Helper loaded: form_helper
INFO - 2018-03-25 09:37:12 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:37:13 --> Controller Class Initialized
INFO - 2018-03-25 09:37:13 --> Model Class Initialized
INFO - 2018-03-25 09:37:13 --> Model Class Initialized
INFO - 2018-03-25 09:37:13 --> Helper loaded: date_helper
INFO - 2018-03-25 09:37:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:37:13 --> Final output sent to browser
DEBUG - 2018-03-25 14:37:13 --> Total execution time: 0.1528
INFO - 2018-03-25 09:37:13 --> Config Class Initialized
INFO - 2018-03-25 09:37:13 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:37:13 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:37:13 --> Utf8 Class Initialized
INFO - 2018-03-25 09:37:13 --> URI Class Initialized
INFO - 2018-03-25 09:37:13 --> Router Class Initialized
INFO - 2018-03-25 09:37:13 --> Output Class Initialized
INFO - 2018-03-25 09:37:13 --> Security Class Initialized
DEBUG - 2018-03-25 09:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:37:13 --> Input Class Initialized
INFO - 2018-03-25 09:37:13 --> Language Class Initialized
INFO - 2018-03-25 09:37:13 --> Loader Class Initialized
INFO - 2018-03-25 09:37:13 --> Helper loaded: url_helper
INFO - 2018-03-25 09:37:13 --> Helper loaded: form_helper
INFO - 2018-03-25 09:37:13 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:37:13 --> Controller Class Initialized
INFO - 2018-03-25 09:37:13 --> Model Class Initialized
INFO - 2018-03-25 09:37:13 --> Model Class Initialized
INFO - 2018-03-25 09:37:13 --> Helper loaded: date_helper
INFO - 2018-03-25 09:37:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:37:13 --> Final output sent to browser
DEBUG - 2018-03-25 14:37:13 --> Total execution time: 0.0890
INFO - 2018-03-25 09:37:19 --> Config Class Initialized
INFO - 2018-03-25 09:37:19 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:37:19 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:37:19 --> Utf8 Class Initialized
INFO - 2018-03-25 09:37:19 --> URI Class Initialized
INFO - 2018-03-25 09:37:19 --> Router Class Initialized
INFO - 2018-03-25 09:37:19 --> Output Class Initialized
INFO - 2018-03-25 09:37:19 --> Security Class Initialized
DEBUG - 2018-03-25 09:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:37:19 --> Input Class Initialized
INFO - 2018-03-25 09:37:19 --> Language Class Initialized
INFO - 2018-03-25 09:37:19 --> Loader Class Initialized
INFO - 2018-03-25 09:37:19 --> Helper loaded: url_helper
INFO - 2018-03-25 09:37:19 --> Helper loaded: form_helper
INFO - 2018-03-25 09:37:19 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:37:19 --> Controller Class Initialized
INFO - 2018-03-25 09:37:19 --> Model Class Initialized
INFO - 2018-03-25 09:37:19 --> Model Class Initialized
INFO - 2018-03-25 09:37:19 --> Model Class Initialized
INFO - 2018-03-25 09:37:19 --> Model Class Initialized
INFO - 2018-03-25 09:37:19 --> Model Class Initialized
INFO - 2018-03-25 09:37:19 --> Model Class Initialized
INFO - 2018-03-25 09:37:19 --> Model Class Initialized
INFO - 2018-03-25 09:37:19 --> Helper loaded: date_helper
INFO - 2018-03-25 09:37:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 09:37:19 --> Config Class Initialized
INFO - 2018-03-25 09:37:19 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:37:19 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:37:19 --> Utf8 Class Initialized
INFO - 2018-03-25 09:37:19 --> URI Class Initialized
INFO - 2018-03-25 09:37:19 --> Router Class Initialized
INFO - 2018-03-25 09:37:19 --> Output Class Initialized
INFO - 2018-03-25 09:37:19 --> Security Class Initialized
DEBUG - 2018-03-25 09:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:37:19 --> Input Class Initialized
INFO - 2018-03-25 09:37:19 --> Language Class Initialized
INFO - 2018-03-25 09:37:19 --> Loader Class Initialized
INFO - 2018-03-25 09:37:19 --> Helper loaded: url_helper
INFO - 2018-03-25 09:37:19 --> Helper loaded: form_helper
INFO - 2018-03-25 09:37:19 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:37:19 --> Controller Class Initialized
INFO - 2018-03-25 09:37:19 --> Model Class Initialized
INFO - 2018-03-25 09:37:19 --> Model Class Initialized
INFO - 2018-03-25 09:37:19 --> Model Class Initialized
INFO - 2018-03-25 09:37:19 --> Model Class Initialized
INFO - 2018-03-25 09:37:19 --> Model Class Initialized
INFO - 2018-03-25 09:37:19 --> Model Class Initialized
INFO - 2018-03-25 09:37:19 --> Model Class Initialized
INFO - 2018-03-25 09:37:19 --> Helper loaded: date_helper
INFO - 2018-03-25 09:37:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:37:19 --> Model Class Initialized
INFO - 2018-03-25 14:37:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 14:37:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 14:37:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-25 14:37:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 14:37:19 --> Final output sent to browser
DEBUG - 2018-03-25 14:37:19 --> Total execution time: 0.1269
INFO - 2018-03-25 09:37:22 --> Config Class Initialized
INFO - 2018-03-25 09:37:22 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:37:22 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:37:22 --> Utf8 Class Initialized
INFO - 2018-03-25 09:37:22 --> URI Class Initialized
INFO - 2018-03-25 09:37:22 --> Router Class Initialized
INFO - 2018-03-25 09:37:22 --> Output Class Initialized
INFO - 2018-03-25 09:37:22 --> Security Class Initialized
DEBUG - 2018-03-25 09:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:37:22 --> Input Class Initialized
INFO - 2018-03-25 09:37:22 --> Language Class Initialized
INFO - 2018-03-25 09:37:22 --> Loader Class Initialized
INFO - 2018-03-25 09:37:22 --> Helper loaded: url_helper
INFO - 2018-03-25 09:37:22 --> Helper loaded: form_helper
INFO - 2018-03-25 09:37:22 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:37:22 --> Controller Class Initialized
INFO - 2018-03-25 09:37:22 --> Model Class Initialized
INFO - 2018-03-25 09:37:22 --> Model Class Initialized
INFO - 2018-03-25 09:37:22 --> Model Class Initialized
INFO - 2018-03-25 09:37:22 --> Model Class Initialized
INFO - 2018-03-25 09:37:22 --> Model Class Initialized
INFO - 2018-03-25 09:37:22 --> Model Class Initialized
INFO - 2018-03-25 09:37:22 --> Model Class Initialized
INFO - 2018-03-25 09:37:23 --> Helper loaded: date_helper
INFO - 2018-03-25 09:37:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:37:23 --> Model Class Initialized
INFO - 2018-03-25 14:37:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 14:37:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 14:37:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-25 14:37:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 14:37:23 --> Final output sent to browser
DEBUG - 2018-03-25 14:37:23 --> Total execution time: 0.1656
INFO - 2018-03-25 09:38:48 --> Config Class Initialized
INFO - 2018-03-25 09:38:48 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:38:48 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:38:48 --> Utf8 Class Initialized
INFO - 2018-03-25 09:38:48 --> URI Class Initialized
INFO - 2018-03-25 09:38:48 --> Router Class Initialized
INFO - 2018-03-25 09:38:48 --> Output Class Initialized
INFO - 2018-03-25 09:38:48 --> Security Class Initialized
DEBUG - 2018-03-25 09:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:38:48 --> Input Class Initialized
INFO - 2018-03-25 09:38:48 --> Language Class Initialized
INFO - 2018-03-25 09:38:48 --> Loader Class Initialized
INFO - 2018-03-25 09:38:48 --> Helper loaded: url_helper
INFO - 2018-03-25 09:38:48 --> Helper loaded: form_helper
INFO - 2018-03-25 09:38:48 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:38:49 --> Controller Class Initialized
INFO - 2018-03-25 09:38:49 --> Model Class Initialized
INFO - 2018-03-25 09:38:49 --> Model Class Initialized
INFO - 2018-03-25 09:38:49 --> Model Class Initialized
INFO - 2018-03-25 09:38:49 --> Model Class Initialized
INFO - 2018-03-25 09:38:49 --> Model Class Initialized
INFO - 2018-03-25 09:38:49 --> Model Class Initialized
INFO - 2018-03-25 09:38:49 --> Model Class Initialized
INFO - 2018-03-25 09:38:49 --> Model Class Initialized
INFO - 2018-03-25 09:38:49 --> Model Class Initialized
INFO - 2018-03-25 09:38:49 --> Model Class Initialized
INFO - 2018-03-25 09:38:49 --> Model Class Initialized
INFO - 2018-03-25 09:38:49 --> Model Class Initialized
INFO - 2018-03-25 09:38:49 --> Model Class Initialized
INFO - 2018-03-25 09:38:49 --> Helper loaded: date_helper
INFO - 2018-03-25 09:38:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:38:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 14:38:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 14:38:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-25 14:38:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 14:38:49 --> Final output sent to browser
DEBUG - 2018-03-25 14:38:49 --> Total execution time: 0.1797
INFO - 2018-03-25 09:38:54 --> Config Class Initialized
INFO - 2018-03-25 09:38:54 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:38:54 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:38:54 --> Utf8 Class Initialized
INFO - 2018-03-25 09:38:54 --> URI Class Initialized
INFO - 2018-03-25 09:38:54 --> Router Class Initialized
INFO - 2018-03-25 09:38:54 --> Output Class Initialized
INFO - 2018-03-25 09:38:54 --> Security Class Initialized
DEBUG - 2018-03-25 09:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:38:54 --> Input Class Initialized
INFO - 2018-03-25 09:38:54 --> Language Class Initialized
INFO - 2018-03-25 09:38:54 --> Loader Class Initialized
INFO - 2018-03-25 09:38:54 --> Helper loaded: url_helper
INFO - 2018-03-25 09:38:54 --> Helper loaded: form_helper
INFO - 2018-03-25 09:38:54 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:38:54 --> Controller Class Initialized
INFO - 2018-03-25 09:38:54 --> Model Class Initialized
INFO - 2018-03-25 09:38:54 --> Model Class Initialized
INFO - 2018-03-25 09:38:54 --> Model Class Initialized
INFO - 2018-03-25 09:38:54 --> Model Class Initialized
INFO - 2018-03-25 09:38:54 --> Model Class Initialized
INFO - 2018-03-25 09:38:54 --> Model Class Initialized
INFO - 2018-03-25 09:38:54 --> Model Class Initialized
INFO - 2018-03-25 09:38:54 --> Model Class Initialized
INFO - 2018-03-25 09:38:54 --> Model Class Initialized
INFO - 2018-03-25 09:38:54 --> Model Class Initialized
INFO - 2018-03-25 09:38:54 --> Model Class Initialized
INFO - 2018-03-25 09:38:54 --> Model Class Initialized
INFO - 2018-03-25 09:38:54 --> Model Class Initialized
INFO - 2018-03-25 09:38:54 --> Helper loaded: date_helper
INFO - 2018-03-25 09:38:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:38:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/list.php
INFO - 2018-03-25 14:38:54 --> Final output sent to browser
DEBUG - 2018-03-25 14:38:54 --> Total execution time: 0.1817
INFO - 2018-03-25 09:38:56 --> Config Class Initialized
INFO - 2018-03-25 09:38:56 --> Hooks Class Initialized
DEBUG - 2018-03-25 09:38:56 --> UTF-8 Support Enabled
INFO - 2018-03-25 09:38:56 --> Utf8 Class Initialized
INFO - 2018-03-25 09:38:56 --> URI Class Initialized
INFO - 2018-03-25 09:38:56 --> Router Class Initialized
INFO - 2018-03-25 09:38:56 --> Output Class Initialized
INFO - 2018-03-25 09:38:56 --> Security Class Initialized
DEBUG - 2018-03-25 09:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 09:38:56 --> Input Class Initialized
INFO - 2018-03-25 09:38:56 --> Language Class Initialized
INFO - 2018-03-25 09:38:56 --> Loader Class Initialized
INFO - 2018-03-25 09:38:56 --> Helper loaded: url_helper
INFO - 2018-03-25 09:38:56 --> Helper loaded: form_helper
INFO - 2018-03-25 09:38:56 --> Database Driver Class Initialized
DEBUG - 2018-03-25 09:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 09:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 09:38:56 --> Controller Class Initialized
INFO - 2018-03-25 09:38:56 --> Model Class Initialized
INFO - 2018-03-25 09:38:56 --> Model Class Initialized
INFO - 2018-03-25 09:38:56 --> Model Class Initialized
INFO - 2018-03-25 09:38:56 --> Model Class Initialized
INFO - 2018-03-25 09:38:56 --> Model Class Initialized
INFO - 2018-03-25 09:38:56 --> Model Class Initialized
INFO - 2018-03-25 09:38:56 --> Model Class Initialized
INFO - 2018-03-25 09:38:56 --> Model Class Initialized
INFO - 2018-03-25 09:38:56 --> Model Class Initialized
INFO - 2018-03-25 09:38:56 --> Model Class Initialized
INFO - 2018-03-25 09:38:56 --> Model Class Initialized
INFO - 2018-03-25 09:38:56 --> Model Class Initialized
INFO - 2018-03-25 09:38:56 --> Model Class Initialized
INFO - 2018-03-25 09:38:56 --> Helper loaded: date_helper
INFO - 2018-03-25 09:38:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 14:38:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 14:38:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 14:38:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-25 14:38:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 14:38:56 --> Final output sent to browser
DEBUG - 2018-03-25 14:38:56 --> Total execution time: 0.1299
INFO - 2018-03-25 10:02:17 --> Config Class Initialized
INFO - 2018-03-25 10:02:17 --> Hooks Class Initialized
DEBUG - 2018-03-25 10:02:17 --> UTF-8 Support Enabled
INFO - 2018-03-25 10:02:17 --> Utf8 Class Initialized
INFO - 2018-03-25 10:02:17 --> URI Class Initialized
INFO - 2018-03-25 10:02:17 --> Router Class Initialized
INFO - 2018-03-25 10:02:17 --> Output Class Initialized
INFO - 2018-03-25 10:02:17 --> Security Class Initialized
DEBUG - 2018-03-25 10:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 10:02:17 --> Input Class Initialized
INFO - 2018-03-25 10:02:17 --> Language Class Initialized
INFO - 2018-03-25 10:02:17 --> Loader Class Initialized
INFO - 2018-03-25 10:02:17 --> Helper loaded: url_helper
INFO - 2018-03-25 10:02:17 --> Helper loaded: form_helper
INFO - 2018-03-25 10:02:17 --> Database Driver Class Initialized
DEBUG - 2018-03-25 10:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 10:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 10:02:17 --> Controller Class Initialized
INFO - 2018-03-25 10:02:17 --> Model Class Initialized
INFO - 2018-03-25 10:02:17 --> Model Class Initialized
INFO - 2018-03-25 10:02:17 --> Model Class Initialized
INFO - 2018-03-25 10:02:17 --> Model Class Initialized
INFO - 2018-03-25 10:02:17 --> Model Class Initialized
INFO - 2018-03-25 10:02:17 --> Model Class Initialized
INFO - 2018-03-25 10:02:17 --> Model Class Initialized
INFO - 2018-03-25 10:02:17 --> Model Class Initialized
INFO - 2018-03-25 10:02:17 --> Model Class Initialized
INFO - 2018-03-25 10:02:17 --> Model Class Initialized
INFO - 2018-03-25 10:02:17 --> Model Class Initialized
INFO - 2018-03-25 10:02:17 --> Model Class Initialized
INFO - 2018-03-25 10:02:17 --> Model Class Initialized
INFO - 2018-03-25 10:02:17 --> Model Class Initialized
INFO - 2018-03-25 10:02:17 --> Helper loaded: date_helper
INFO - 2018-03-25 10:02:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 15:02:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 15:02:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 15:02:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/create.php
INFO - 2018-03-25 15:02:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 15:02:17 --> Final output sent to browser
DEBUG - 2018-03-25 15:02:17 --> Total execution time: 0.1268
INFO - 2018-03-25 10:02:21 --> Config Class Initialized
INFO - 2018-03-25 10:02:21 --> Hooks Class Initialized
DEBUG - 2018-03-25 10:02:21 --> UTF-8 Support Enabled
INFO - 2018-03-25 10:02:21 --> Utf8 Class Initialized
INFO - 2018-03-25 10:02:21 --> URI Class Initialized
INFO - 2018-03-25 10:02:21 --> Router Class Initialized
INFO - 2018-03-25 10:02:21 --> Output Class Initialized
INFO - 2018-03-25 10:02:21 --> Security Class Initialized
DEBUG - 2018-03-25 10:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 10:02:21 --> Input Class Initialized
INFO - 2018-03-25 10:02:21 --> Language Class Initialized
INFO - 2018-03-25 10:02:21 --> Loader Class Initialized
INFO - 2018-03-25 10:02:21 --> Helper loaded: url_helper
INFO - 2018-03-25 10:02:21 --> Helper loaded: form_helper
INFO - 2018-03-25 10:02:21 --> Database Driver Class Initialized
DEBUG - 2018-03-25 10:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 10:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 10:02:21 --> Controller Class Initialized
INFO - 2018-03-25 10:02:21 --> Model Class Initialized
INFO - 2018-03-25 10:02:21 --> Model Class Initialized
INFO - 2018-03-25 10:02:21 --> Model Class Initialized
INFO - 2018-03-25 10:02:21 --> Model Class Initialized
INFO - 2018-03-25 10:02:21 --> Model Class Initialized
INFO - 2018-03-25 10:02:21 --> Model Class Initialized
INFO - 2018-03-25 10:02:21 --> Model Class Initialized
INFO - 2018-03-25 10:02:21 --> Model Class Initialized
INFO - 2018-03-25 10:02:21 --> Model Class Initialized
INFO - 2018-03-25 10:02:21 --> Model Class Initialized
INFO - 2018-03-25 10:02:21 --> Model Class Initialized
INFO - 2018-03-25 10:02:21 --> Model Class Initialized
INFO - 2018-03-25 10:02:21 --> Model Class Initialized
INFO - 2018-03-25 10:02:21 --> Model Class Initialized
INFO - 2018-03-25 10:02:21 --> Helper loaded: date_helper
INFO - 2018-03-25 10:02:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 15:02:21 --> Final output sent to browser
DEBUG - 2018-03-25 15:02:21 --> Total execution time: 0.1270
INFO - 2018-03-25 10:02:29 --> Config Class Initialized
INFO - 2018-03-25 10:02:29 --> Hooks Class Initialized
DEBUG - 2018-03-25 10:02:29 --> UTF-8 Support Enabled
INFO - 2018-03-25 10:02:29 --> Utf8 Class Initialized
INFO - 2018-03-25 10:02:29 --> URI Class Initialized
INFO - 2018-03-25 10:02:29 --> Router Class Initialized
INFO - 2018-03-25 10:02:29 --> Output Class Initialized
INFO - 2018-03-25 10:02:29 --> Security Class Initialized
DEBUG - 2018-03-25 10:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 10:02:29 --> Input Class Initialized
INFO - 2018-03-25 10:02:29 --> Language Class Initialized
INFO - 2018-03-25 10:02:29 --> Loader Class Initialized
INFO - 2018-03-25 10:02:29 --> Helper loaded: url_helper
INFO - 2018-03-25 10:02:29 --> Helper loaded: form_helper
INFO - 2018-03-25 10:02:29 --> Database Driver Class Initialized
DEBUG - 2018-03-25 10:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 10:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 10:02:29 --> Controller Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Helper loaded: date_helper
INFO - 2018-03-25 10:02:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 10:02:29 --> Config Class Initialized
INFO - 2018-03-25 10:02:29 --> Hooks Class Initialized
DEBUG - 2018-03-25 10:02:29 --> UTF-8 Support Enabled
INFO - 2018-03-25 10:02:29 --> Utf8 Class Initialized
INFO - 2018-03-25 10:02:29 --> URI Class Initialized
INFO - 2018-03-25 10:02:29 --> Router Class Initialized
INFO - 2018-03-25 10:02:29 --> Output Class Initialized
INFO - 2018-03-25 10:02:29 --> Security Class Initialized
DEBUG - 2018-03-25 10:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 10:02:29 --> Input Class Initialized
INFO - 2018-03-25 10:02:29 --> Language Class Initialized
INFO - 2018-03-25 10:02:29 --> Loader Class Initialized
INFO - 2018-03-25 10:02:29 --> Helper loaded: url_helper
INFO - 2018-03-25 10:02:29 --> Helper loaded: form_helper
INFO - 2018-03-25 10:02:29 --> Database Driver Class Initialized
DEBUG - 2018-03-25 10:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 10:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 10:02:29 --> Controller Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Model Class Initialized
INFO - 2018-03-25 10:02:29 --> Helper loaded: date_helper
INFO - 2018-03-25 10:02:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 15:02:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 15:02:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 15:02:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-25 15:02:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 15:02:29 --> Final output sent to browser
DEBUG - 2018-03-25 15:02:29 --> Total execution time: 0.1429
INFO - 2018-03-25 11:43:42 --> Config Class Initialized
INFO - 2018-03-25 11:43:42 --> Hooks Class Initialized
DEBUG - 2018-03-25 11:43:42 --> UTF-8 Support Enabled
INFO - 2018-03-25 11:43:42 --> Utf8 Class Initialized
INFO - 2018-03-25 11:43:42 --> URI Class Initialized
INFO - 2018-03-25 11:43:42 --> Router Class Initialized
INFO - 2018-03-25 11:43:42 --> Output Class Initialized
INFO - 2018-03-25 11:43:42 --> Security Class Initialized
DEBUG - 2018-03-25 11:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 11:43:42 --> Input Class Initialized
INFO - 2018-03-25 11:43:42 --> Language Class Initialized
INFO - 2018-03-25 11:43:42 --> Loader Class Initialized
INFO - 2018-03-25 11:43:42 --> Helper loaded: url_helper
INFO - 2018-03-25 11:43:42 --> Helper loaded: form_helper
INFO - 2018-03-25 11:43:42 --> Database Driver Class Initialized
DEBUG - 2018-03-25 11:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 11:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 11:43:42 --> Controller Class Initialized
INFO - 2018-03-25 11:43:42 --> Model Class Initialized
INFO - 2018-03-25 11:43:42 --> Model Class Initialized
INFO - 2018-03-25 11:43:42 --> Helper loaded: date_helper
INFO - 2018-03-25 16:43:42 --> Model Class Initialized
INFO - 2018-03-25 16:43:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 16:43:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 16:43:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/table.php
INFO - 2018-03-25 16:43:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 16:43:42 --> Final output sent to browser
DEBUG - 2018-03-25 16:43:42 --> Total execution time: 0.1750
INFO - 2018-03-25 11:43:45 --> Config Class Initialized
INFO - 2018-03-25 11:43:45 --> Hooks Class Initialized
DEBUG - 2018-03-25 11:43:45 --> UTF-8 Support Enabled
INFO - 2018-03-25 11:43:45 --> Utf8 Class Initialized
INFO - 2018-03-25 11:43:45 --> URI Class Initialized
INFO - 2018-03-25 11:43:45 --> Router Class Initialized
INFO - 2018-03-25 11:43:45 --> Output Class Initialized
INFO - 2018-03-25 11:43:45 --> Security Class Initialized
DEBUG - 2018-03-25 11:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 11:43:45 --> Input Class Initialized
INFO - 2018-03-25 11:43:45 --> Language Class Initialized
INFO - 2018-03-25 11:43:45 --> Loader Class Initialized
INFO - 2018-03-25 11:43:45 --> Helper loaded: url_helper
INFO - 2018-03-25 11:43:45 --> Helper loaded: form_helper
INFO - 2018-03-25 11:43:45 --> Database Driver Class Initialized
DEBUG - 2018-03-25 11:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 11:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 11:43:45 --> Controller Class Initialized
INFO - 2018-03-25 11:43:45 --> Model Class Initialized
INFO - 2018-03-25 11:43:45 --> Model Class Initialized
INFO - 2018-03-25 11:43:45 --> Helper loaded: date_helper
ERROR - 2018-03-25 16:43:45 --> Query error: Unknown column 'flag_aktifs' in 'where clause' - Invalid query: SELECT *
FROM `mst_pegawai`
WHERE `id_mst_pegawai` = '1'
AND `flag_aktifs` = 1
ERROR - 2018-03-25 16:43:45 --> Severity: error --> Exception: Call to a member function result() on boolean E:\xampp\htdocs\skin_care\application\models\Pegawai_model.php 11
INFO - 2018-03-25 12:30:09 --> Config Class Initialized
INFO - 2018-03-25 12:30:09 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:30:09 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:30:09 --> Utf8 Class Initialized
INFO - 2018-03-25 12:30:09 --> URI Class Initialized
INFO - 2018-03-25 12:30:09 --> Router Class Initialized
INFO - 2018-03-25 12:30:09 --> Output Class Initialized
INFO - 2018-03-25 12:30:09 --> Security Class Initialized
DEBUG - 2018-03-25 12:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:30:09 --> Input Class Initialized
INFO - 2018-03-25 12:30:09 --> Language Class Initialized
INFO - 2018-03-25 12:30:09 --> Loader Class Initialized
INFO - 2018-03-25 12:30:09 --> Helper loaded: url_helper
INFO - 2018-03-25 12:30:09 --> Helper loaded: form_helper
INFO - 2018-03-25 12:30:09 --> Database Driver Class Initialized
DEBUG - 2018-03-25 12:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 12:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 12:30:09 --> Controller Class Initialized
INFO - 2018-03-25 12:30:09 --> Model Class Initialized
INFO - 2018-03-25 12:30:09 --> Model Class Initialized
INFO - 2018-03-25 12:30:09 --> Helper loaded: date_helper
INFO - 2018-03-25 17:30:09 --> Model Class Initialized
INFO - 2018-03-25 17:30:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 17:30:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 17:30:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/update.php
INFO - 2018-03-25 17:30:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 17:30:09 --> Final output sent to browser
DEBUG - 2018-03-25 17:30:09 --> Total execution time: 0.1146
INFO - 2018-03-25 12:30:15 --> Config Class Initialized
INFO - 2018-03-25 12:30:15 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:30:15 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:30:15 --> Utf8 Class Initialized
INFO - 2018-03-25 12:30:15 --> URI Class Initialized
INFO - 2018-03-25 12:30:15 --> Router Class Initialized
INFO - 2018-03-25 12:30:15 --> Output Class Initialized
INFO - 2018-03-25 12:30:15 --> Security Class Initialized
DEBUG - 2018-03-25 12:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:30:15 --> Input Class Initialized
INFO - 2018-03-25 12:30:15 --> Language Class Initialized
INFO - 2018-03-25 12:30:15 --> Loader Class Initialized
INFO - 2018-03-25 12:30:15 --> Helper loaded: url_helper
INFO - 2018-03-25 12:30:15 --> Helper loaded: form_helper
INFO - 2018-03-25 12:30:15 --> Database Driver Class Initialized
DEBUG - 2018-03-25 12:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 12:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 12:30:15 --> Controller Class Initialized
INFO - 2018-03-25 12:30:15 --> Model Class Initialized
INFO - 2018-03-25 12:30:15 --> Model Class Initialized
INFO - 2018-03-25 12:30:15 --> Model Class Initialized
INFO - 2018-03-25 12:30:15 --> Model Class Initialized
INFO - 2018-03-25 12:30:15 --> Model Class Initialized
INFO - 2018-03-25 12:30:15 --> Model Class Initialized
INFO - 2018-03-25 12:30:15 --> Model Class Initialized
INFO - 2018-03-25 12:30:15 --> Model Class Initialized
INFO - 2018-03-25 12:30:15 --> Model Class Initialized
INFO - 2018-03-25 12:30:15 --> Model Class Initialized
INFO - 2018-03-25 12:30:15 --> Model Class Initialized
INFO - 2018-03-25 12:30:15 --> Helper loaded: date_helper
INFO - 2018-03-25 12:30:15 --> Helper loaded: tanggal_helper
ERROR - 2018-03-25 17:30:15 --> Query error: Incorrect number of arguments for PROCEDURE klinik.listTagihanPasien; expected 0, got 1 - Invalid query: call listTagihanPasien('2018-03-25')
ERROR - 2018-03-25 17:30:15 --> Severity: error --> Exception: Call to a member function num_rows() on boolean E:\xampp\htdocs\skin_care\application\models\Billing_model.php 27
INFO - 2018-03-25 12:30:53 --> Config Class Initialized
INFO - 2018-03-25 12:30:53 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:30:53 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:30:53 --> Utf8 Class Initialized
INFO - 2018-03-25 12:30:53 --> URI Class Initialized
INFO - 2018-03-25 12:30:53 --> Router Class Initialized
INFO - 2018-03-25 12:30:53 --> Output Class Initialized
INFO - 2018-03-25 12:30:53 --> Security Class Initialized
DEBUG - 2018-03-25 12:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:30:53 --> Input Class Initialized
INFO - 2018-03-25 12:30:53 --> Language Class Initialized
INFO - 2018-03-25 12:30:53 --> Loader Class Initialized
INFO - 2018-03-25 12:30:53 --> Helper loaded: url_helper
INFO - 2018-03-25 12:30:53 --> Helper loaded: form_helper
INFO - 2018-03-25 12:30:53 --> Database Driver Class Initialized
DEBUG - 2018-03-25 12:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 12:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 12:30:53 --> Controller Class Initialized
INFO - 2018-03-25 12:30:53 --> Model Class Initialized
INFO - 2018-03-25 12:30:53 --> Model Class Initialized
INFO - 2018-03-25 12:30:53 --> Model Class Initialized
INFO - 2018-03-25 12:30:53 --> Model Class Initialized
INFO - 2018-03-25 12:30:53 --> Model Class Initialized
INFO - 2018-03-25 12:30:53 --> Model Class Initialized
INFO - 2018-03-25 12:30:53 --> Model Class Initialized
INFO - 2018-03-25 12:30:53 --> Model Class Initialized
INFO - 2018-03-25 12:30:53 --> Model Class Initialized
INFO - 2018-03-25 12:30:53 --> Model Class Initialized
INFO - 2018-03-25 12:30:53 --> Model Class Initialized
INFO - 2018-03-25 12:30:53 --> Helper loaded: date_helper
INFO - 2018-03-25 12:30:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 17:30:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 17:30:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 17:30:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-25 17:30:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 17:30:53 --> Final output sent to browser
DEBUG - 2018-03-25 17:30:53 --> Total execution time: 0.1121
INFO - 2018-03-25 12:43:19 --> Config Class Initialized
INFO - 2018-03-25 12:43:19 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:43:19 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:43:19 --> Utf8 Class Initialized
INFO - 2018-03-25 12:43:19 --> URI Class Initialized
INFO - 2018-03-25 12:43:19 --> Router Class Initialized
INFO - 2018-03-25 12:43:19 --> Output Class Initialized
INFO - 2018-03-25 12:43:19 --> Security Class Initialized
DEBUG - 2018-03-25 12:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:43:19 --> Input Class Initialized
INFO - 2018-03-25 12:43:19 --> Language Class Initialized
INFO - 2018-03-25 12:43:19 --> Loader Class Initialized
INFO - 2018-03-25 12:43:19 --> Helper loaded: url_helper
INFO - 2018-03-25 12:43:19 --> Helper loaded: form_helper
INFO - 2018-03-25 12:43:19 --> Database Driver Class Initialized
DEBUG - 2018-03-25 12:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 12:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 12:43:19 --> Controller Class Initialized
INFO - 2018-03-25 12:43:19 --> Model Class Initialized
INFO - 2018-03-25 12:43:19 --> Model Class Initialized
INFO - 2018-03-25 12:43:19 --> Model Class Initialized
INFO - 2018-03-25 12:43:19 --> Model Class Initialized
INFO - 2018-03-25 12:43:19 --> Model Class Initialized
INFO - 2018-03-25 12:43:19 --> Model Class Initialized
INFO - 2018-03-25 12:43:19 --> Model Class Initialized
INFO - 2018-03-25 12:43:19 --> Model Class Initialized
INFO - 2018-03-25 12:43:19 --> Model Class Initialized
INFO - 2018-03-25 12:43:19 --> Model Class Initialized
INFO - 2018-03-25 12:43:19 --> Model Class Initialized
INFO - 2018-03-25 12:43:19 --> Helper loaded: date_helper
INFO - 2018-03-25 12:43:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 17:43:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 17:43:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 17:43:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-25 17:43:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 17:43:19 --> Final output sent to browser
DEBUG - 2018-03-25 17:43:19 --> Total execution time: 0.0998
INFO - 2018-03-25 12:43:45 --> Config Class Initialized
INFO - 2018-03-25 12:43:45 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:43:45 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:43:45 --> Utf8 Class Initialized
INFO - 2018-03-25 12:43:45 --> URI Class Initialized
INFO - 2018-03-25 12:43:45 --> Router Class Initialized
INFO - 2018-03-25 12:43:45 --> Output Class Initialized
INFO - 2018-03-25 12:43:45 --> Security Class Initialized
DEBUG - 2018-03-25 12:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:43:45 --> Input Class Initialized
INFO - 2018-03-25 12:43:45 --> Language Class Initialized
INFO - 2018-03-25 12:43:45 --> Loader Class Initialized
INFO - 2018-03-25 12:43:45 --> Helper loaded: url_helper
INFO - 2018-03-25 12:43:45 --> Helper loaded: form_helper
INFO - 2018-03-25 12:43:45 --> Database Driver Class Initialized
DEBUG - 2018-03-25 12:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 12:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 12:43:45 --> Controller Class Initialized
INFO - 2018-03-25 12:43:45 --> Model Class Initialized
INFO - 2018-03-25 12:43:45 --> Model Class Initialized
INFO - 2018-03-25 12:43:45 --> Model Class Initialized
INFO - 2018-03-25 12:43:45 --> Model Class Initialized
INFO - 2018-03-25 12:43:45 --> Model Class Initialized
INFO - 2018-03-25 12:43:45 --> Model Class Initialized
INFO - 2018-03-25 12:43:45 --> Model Class Initialized
INFO - 2018-03-25 12:43:45 --> Model Class Initialized
INFO - 2018-03-25 12:43:45 --> Model Class Initialized
INFO - 2018-03-25 12:43:45 --> Model Class Initialized
INFO - 2018-03-25 12:43:45 --> Model Class Initialized
INFO - 2018-03-25 12:43:45 --> Helper loaded: date_helper
INFO - 2018-03-25 12:43:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 17:43:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 17:43:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 17:43:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-25 17:43:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 17:43:45 --> Final output sent to browser
DEBUG - 2018-03-25 17:43:45 --> Total execution time: 0.1157
INFO - 2018-03-25 12:47:59 --> Config Class Initialized
INFO - 2018-03-25 12:47:59 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:47:59 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:47:59 --> Utf8 Class Initialized
INFO - 2018-03-25 12:47:59 --> URI Class Initialized
INFO - 2018-03-25 12:47:59 --> Router Class Initialized
INFO - 2018-03-25 12:47:59 --> Output Class Initialized
INFO - 2018-03-25 12:47:59 --> Security Class Initialized
DEBUG - 2018-03-25 12:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:47:59 --> Input Class Initialized
INFO - 2018-03-25 12:47:59 --> Language Class Initialized
INFO - 2018-03-25 12:47:59 --> Loader Class Initialized
INFO - 2018-03-25 12:47:59 --> Helper loaded: url_helper
INFO - 2018-03-25 12:47:59 --> Helper loaded: form_helper
INFO - 2018-03-25 12:47:59 --> Database Driver Class Initialized
DEBUG - 2018-03-25 12:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 12:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 12:47:59 --> Controller Class Initialized
INFO - 2018-03-25 12:47:59 --> Model Class Initialized
INFO - 2018-03-25 12:47:59 --> Model Class Initialized
INFO - 2018-03-25 12:47:59 --> Model Class Initialized
INFO - 2018-03-25 12:47:59 --> Model Class Initialized
INFO - 2018-03-25 12:47:59 --> Model Class Initialized
INFO - 2018-03-25 12:47:59 --> Model Class Initialized
INFO - 2018-03-25 12:47:59 --> Model Class Initialized
INFO - 2018-03-25 12:47:59 --> Model Class Initialized
INFO - 2018-03-25 12:47:59 --> Model Class Initialized
INFO - 2018-03-25 12:47:59 --> Model Class Initialized
INFO - 2018-03-25 12:47:59 --> Model Class Initialized
INFO - 2018-03-25 12:47:59 --> Helper loaded: date_helper
INFO - 2018-03-25 12:47:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 17:47:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 17:47:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 17:47:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-25 17:47:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 17:47:59 --> Final output sent to browser
DEBUG - 2018-03-25 17:47:59 --> Total execution time: 0.1129
INFO - 2018-03-25 12:48:01 --> Config Class Initialized
INFO - 2018-03-25 12:48:01 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:48:01 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:48:01 --> Utf8 Class Initialized
INFO - 2018-03-25 12:48:01 --> URI Class Initialized
INFO - 2018-03-25 12:48:01 --> Router Class Initialized
INFO - 2018-03-25 12:48:01 --> Output Class Initialized
INFO - 2018-03-25 12:48:01 --> Security Class Initialized
DEBUG - 2018-03-25 12:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:48:01 --> Input Class Initialized
INFO - 2018-03-25 12:48:01 --> Language Class Initialized
ERROR - 2018-03-25 12:48:01 --> 404 Page Not Found: Kasir/Kasir/detailTagihan
INFO - 2018-03-25 12:48:04 --> Config Class Initialized
INFO - 2018-03-25 12:48:04 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:48:04 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:48:04 --> Utf8 Class Initialized
INFO - 2018-03-25 12:48:04 --> URI Class Initialized
INFO - 2018-03-25 12:48:04 --> Router Class Initialized
INFO - 2018-03-25 12:48:04 --> Output Class Initialized
INFO - 2018-03-25 12:48:04 --> Security Class Initialized
DEBUG - 2018-03-25 12:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:48:04 --> Input Class Initialized
INFO - 2018-03-25 12:48:04 --> Language Class Initialized
INFO - 2018-03-25 12:48:04 --> Loader Class Initialized
INFO - 2018-03-25 12:48:04 --> Helper loaded: url_helper
INFO - 2018-03-25 12:48:04 --> Helper loaded: form_helper
INFO - 2018-03-25 12:48:04 --> Database Driver Class Initialized
DEBUG - 2018-03-25 12:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 12:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 12:48:04 --> Controller Class Initialized
INFO - 2018-03-25 12:48:04 --> Model Class Initialized
INFO - 2018-03-25 12:48:04 --> Model Class Initialized
INFO - 2018-03-25 12:48:04 --> Model Class Initialized
INFO - 2018-03-25 12:48:04 --> Model Class Initialized
INFO - 2018-03-25 12:48:04 --> Model Class Initialized
INFO - 2018-03-25 12:48:04 --> Model Class Initialized
INFO - 2018-03-25 12:48:04 --> Model Class Initialized
INFO - 2018-03-25 12:48:04 --> Model Class Initialized
INFO - 2018-03-25 12:48:04 --> Model Class Initialized
INFO - 2018-03-25 12:48:04 --> Model Class Initialized
INFO - 2018-03-25 12:48:04 --> Model Class Initialized
INFO - 2018-03-25 12:48:04 --> Helper loaded: date_helper
INFO - 2018-03-25 12:48:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 17:48:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 17:48:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 17:48:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-25 17:48:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 17:48:04 --> Final output sent to browser
DEBUG - 2018-03-25 17:48:04 --> Total execution time: 0.1247
INFO - 2018-03-25 12:49:43 --> Config Class Initialized
INFO - 2018-03-25 12:49:43 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:49:43 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:49:43 --> Utf8 Class Initialized
INFO - 2018-03-25 12:49:43 --> URI Class Initialized
INFO - 2018-03-25 12:49:43 --> Router Class Initialized
INFO - 2018-03-25 12:49:43 --> Output Class Initialized
INFO - 2018-03-25 12:49:43 --> Security Class Initialized
DEBUG - 2018-03-25 12:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:49:43 --> Input Class Initialized
INFO - 2018-03-25 12:49:43 --> Language Class Initialized
INFO - 2018-03-25 12:49:43 --> Loader Class Initialized
INFO - 2018-03-25 12:49:43 --> Helper loaded: url_helper
INFO - 2018-03-25 12:49:43 --> Helper loaded: form_helper
INFO - 2018-03-25 12:49:43 --> Database Driver Class Initialized
DEBUG - 2018-03-25 12:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 12:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 12:49:43 --> Controller Class Initialized
INFO - 2018-03-25 12:49:43 --> Model Class Initialized
INFO - 2018-03-25 12:49:43 --> Model Class Initialized
INFO - 2018-03-25 12:49:43 --> Model Class Initialized
INFO - 2018-03-25 12:49:43 --> Model Class Initialized
INFO - 2018-03-25 12:49:43 --> Model Class Initialized
INFO - 2018-03-25 12:49:43 --> Model Class Initialized
INFO - 2018-03-25 12:49:43 --> Model Class Initialized
INFO - 2018-03-25 12:49:43 --> Model Class Initialized
INFO - 2018-03-25 12:49:43 --> Model Class Initialized
INFO - 2018-03-25 12:49:43 --> Model Class Initialized
INFO - 2018-03-25 12:49:43 --> Model Class Initialized
INFO - 2018-03-25 12:49:43 --> Helper loaded: date_helper
INFO - 2018-03-25 12:49:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 17:49:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 17:49:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 17:49:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-25 17:49:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 17:49:43 --> Final output sent to browser
DEBUG - 2018-03-25 17:49:43 --> Total execution time: 0.1029
INFO - 2018-03-25 12:49:49 --> Config Class Initialized
INFO - 2018-03-25 12:49:49 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:49:49 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:49:49 --> Utf8 Class Initialized
INFO - 2018-03-25 12:49:49 --> URI Class Initialized
INFO - 2018-03-25 12:49:49 --> Router Class Initialized
INFO - 2018-03-25 12:49:49 --> Output Class Initialized
INFO - 2018-03-25 12:49:49 --> Security Class Initialized
DEBUG - 2018-03-25 12:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:49:49 --> Input Class Initialized
INFO - 2018-03-25 12:49:49 --> Language Class Initialized
INFO - 2018-03-25 12:49:49 --> Loader Class Initialized
INFO - 2018-03-25 12:49:49 --> Helper loaded: url_helper
INFO - 2018-03-25 12:49:49 --> Helper loaded: form_helper
INFO - 2018-03-25 12:49:49 --> Database Driver Class Initialized
DEBUG - 2018-03-25 12:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 12:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 12:49:49 --> Controller Class Initialized
INFO - 2018-03-25 12:49:49 --> Model Class Initialized
INFO - 2018-03-25 12:49:49 --> Model Class Initialized
INFO - 2018-03-25 12:49:49 --> Model Class Initialized
INFO - 2018-03-25 12:49:49 --> Model Class Initialized
INFO - 2018-03-25 12:49:49 --> Model Class Initialized
INFO - 2018-03-25 12:49:49 --> Model Class Initialized
INFO - 2018-03-25 12:49:49 --> Model Class Initialized
INFO - 2018-03-25 12:49:49 --> Model Class Initialized
INFO - 2018-03-25 12:49:49 --> Model Class Initialized
INFO - 2018-03-25 12:49:49 --> Model Class Initialized
INFO - 2018-03-25 12:49:49 --> Model Class Initialized
INFO - 2018-03-25 12:49:49 --> Helper loaded: date_helper
INFO - 2018-03-25 12:49:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 17:49:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-25 17:49:49 --> Final output sent to browser
DEBUG - 2018-03-25 17:49:49 --> Total execution time: 0.0840
INFO - 2018-03-25 12:49:53 --> Config Class Initialized
INFO - 2018-03-25 12:49:53 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:49:53 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:49:53 --> Utf8 Class Initialized
INFO - 2018-03-25 12:49:53 --> URI Class Initialized
INFO - 2018-03-25 12:49:53 --> Router Class Initialized
INFO - 2018-03-25 12:49:53 --> Output Class Initialized
INFO - 2018-03-25 12:49:53 --> Security Class Initialized
DEBUG - 2018-03-25 12:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:49:53 --> Input Class Initialized
INFO - 2018-03-25 12:49:53 --> Language Class Initialized
INFO - 2018-03-25 12:49:53 --> Loader Class Initialized
INFO - 2018-03-25 12:49:53 --> Helper loaded: url_helper
INFO - 2018-03-25 12:49:53 --> Helper loaded: form_helper
INFO - 2018-03-25 12:49:53 --> Database Driver Class Initialized
DEBUG - 2018-03-25 12:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 12:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 12:49:53 --> Controller Class Initialized
INFO - 2018-03-25 12:49:53 --> Model Class Initialized
INFO - 2018-03-25 12:49:53 --> Model Class Initialized
INFO - 2018-03-25 12:49:53 --> Model Class Initialized
INFO - 2018-03-25 12:49:53 --> Model Class Initialized
INFO - 2018-03-25 12:49:53 --> Model Class Initialized
INFO - 2018-03-25 12:49:53 --> Model Class Initialized
INFO - 2018-03-25 12:49:53 --> Model Class Initialized
INFO - 2018-03-25 12:49:53 --> Model Class Initialized
INFO - 2018-03-25 12:49:53 --> Model Class Initialized
INFO - 2018-03-25 12:49:53 --> Model Class Initialized
INFO - 2018-03-25 12:49:53 --> Model Class Initialized
INFO - 2018-03-25 12:49:53 --> Helper loaded: date_helper
INFO - 2018-03-25 12:49:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 17:49:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-25 17:49:53 --> Final output sent to browser
DEBUG - 2018-03-25 17:49:53 --> Total execution time: 0.0858
INFO - 2018-03-25 12:50:06 --> Config Class Initialized
INFO - 2018-03-25 12:50:06 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:50:06 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:50:06 --> Utf8 Class Initialized
INFO - 2018-03-25 12:50:06 --> URI Class Initialized
INFO - 2018-03-25 12:50:06 --> Router Class Initialized
INFO - 2018-03-25 12:50:06 --> Output Class Initialized
INFO - 2018-03-25 12:50:06 --> Security Class Initialized
DEBUG - 2018-03-25 12:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:50:06 --> Input Class Initialized
INFO - 2018-03-25 12:50:06 --> Language Class Initialized
INFO - 2018-03-25 12:50:06 --> Loader Class Initialized
INFO - 2018-03-25 12:50:06 --> Helper loaded: url_helper
INFO - 2018-03-25 12:50:06 --> Helper loaded: form_helper
INFO - 2018-03-25 12:50:06 --> Database Driver Class Initialized
DEBUG - 2018-03-25 12:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 12:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 12:50:06 --> Controller Class Initialized
INFO - 2018-03-25 12:50:06 --> Model Class Initialized
INFO - 2018-03-25 12:50:06 --> Model Class Initialized
INFO - 2018-03-25 12:50:06 --> Model Class Initialized
INFO - 2018-03-25 12:50:06 --> Model Class Initialized
INFO - 2018-03-25 12:50:06 --> Model Class Initialized
INFO - 2018-03-25 12:50:06 --> Model Class Initialized
INFO - 2018-03-25 12:50:06 --> Model Class Initialized
INFO - 2018-03-25 12:50:06 --> Model Class Initialized
INFO - 2018-03-25 12:50:06 --> Model Class Initialized
INFO - 2018-03-25 12:50:06 --> Model Class Initialized
INFO - 2018-03-25 12:50:06 --> Model Class Initialized
INFO - 2018-03-25 12:50:06 --> Helper loaded: date_helper
INFO - 2018-03-25 12:50:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 17:50:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-25 17:50:06 --> Final output sent to browser
DEBUG - 2018-03-25 17:50:06 --> Total execution time: 0.0991
INFO - 2018-03-25 12:50:07 --> Config Class Initialized
INFO - 2018-03-25 12:50:07 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:50:07 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:50:07 --> Utf8 Class Initialized
INFO - 2018-03-25 12:50:07 --> URI Class Initialized
INFO - 2018-03-25 12:50:07 --> Router Class Initialized
INFO - 2018-03-25 12:50:07 --> Output Class Initialized
INFO - 2018-03-25 12:50:07 --> Security Class Initialized
DEBUG - 2018-03-25 12:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:50:07 --> Input Class Initialized
INFO - 2018-03-25 12:50:07 --> Language Class Initialized
INFO - 2018-03-25 12:50:07 --> Loader Class Initialized
INFO - 2018-03-25 12:50:07 --> Helper loaded: url_helper
INFO - 2018-03-25 12:50:07 --> Helper loaded: form_helper
INFO - 2018-03-25 12:50:07 --> Database Driver Class Initialized
DEBUG - 2018-03-25 12:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 12:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 12:50:07 --> Controller Class Initialized
INFO - 2018-03-25 12:50:07 --> Model Class Initialized
INFO - 2018-03-25 12:50:07 --> Model Class Initialized
INFO - 2018-03-25 12:50:07 --> Model Class Initialized
INFO - 2018-03-25 12:50:07 --> Model Class Initialized
INFO - 2018-03-25 12:50:07 --> Model Class Initialized
INFO - 2018-03-25 12:50:07 --> Model Class Initialized
INFO - 2018-03-25 12:50:07 --> Model Class Initialized
INFO - 2018-03-25 12:50:07 --> Model Class Initialized
INFO - 2018-03-25 12:50:07 --> Model Class Initialized
INFO - 2018-03-25 12:50:07 --> Model Class Initialized
INFO - 2018-03-25 12:50:07 --> Model Class Initialized
INFO - 2018-03-25 12:50:07 --> Helper loaded: date_helper
INFO - 2018-03-25 12:50:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 17:50:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-25 17:50:07 --> Final output sent to browser
DEBUG - 2018-03-25 17:50:07 --> Total execution time: 0.1125
INFO - 2018-03-25 12:50:11 --> Config Class Initialized
INFO - 2018-03-25 12:50:11 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:50:11 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:50:11 --> Utf8 Class Initialized
INFO - 2018-03-25 12:50:11 --> URI Class Initialized
INFO - 2018-03-25 12:50:11 --> Router Class Initialized
INFO - 2018-03-25 12:50:11 --> Output Class Initialized
INFO - 2018-03-25 12:50:11 --> Security Class Initialized
DEBUG - 2018-03-25 12:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:50:11 --> Input Class Initialized
INFO - 2018-03-25 12:50:11 --> Language Class Initialized
INFO - 2018-03-25 12:50:11 --> Loader Class Initialized
INFO - 2018-03-25 12:50:11 --> Helper loaded: url_helper
INFO - 2018-03-25 12:50:11 --> Helper loaded: form_helper
INFO - 2018-03-25 12:50:11 --> Database Driver Class Initialized
DEBUG - 2018-03-25 12:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 12:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 12:50:11 --> Controller Class Initialized
INFO - 2018-03-25 12:50:11 --> Model Class Initialized
INFO - 2018-03-25 12:50:11 --> Model Class Initialized
INFO - 2018-03-25 12:50:11 --> Model Class Initialized
INFO - 2018-03-25 12:50:11 --> Model Class Initialized
INFO - 2018-03-25 12:50:11 --> Model Class Initialized
INFO - 2018-03-25 12:50:11 --> Model Class Initialized
INFO - 2018-03-25 12:50:11 --> Model Class Initialized
INFO - 2018-03-25 12:50:11 --> Model Class Initialized
INFO - 2018-03-25 12:50:11 --> Model Class Initialized
INFO - 2018-03-25 12:50:11 --> Model Class Initialized
INFO - 2018-03-25 12:50:11 --> Model Class Initialized
INFO - 2018-03-25 12:50:11 --> Helper loaded: date_helper
INFO - 2018-03-25 12:50:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 17:50:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-25 17:50:11 --> Final output sent to browser
DEBUG - 2018-03-25 17:50:11 --> Total execution time: 0.1018
INFO - 2018-03-25 12:51:37 --> Config Class Initialized
INFO - 2018-03-25 12:51:37 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:51:37 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:51:37 --> Utf8 Class Initialized
INFO - 2018-03-25 12:51:37 --> URI Class Initialized
INFO - 2018-03-25 12:51:38 --> Router Class Initialized
INFO - 2018-03-25 12:51:38 --> Output Class Initialized
INFO - 2018-03-25 12:51:38 --> Security Class Initialized
DEBUG - 2018-03-25 12:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:51:38 --> Input Class Initialized
INFO - 2018-03-25 12:51:38 --> Language Class Initialized
INFO - 2018-03-25 12:51:38 --> Loader Class Initialized
INFO - 2018-03-25 12:51:38 --> Helper loaded: url_helper
INFO - 2018-03-25 12:51:38 --> Helper loaded: form_helper
INFO - 2018-03-25 12:51:38 --> Database Driver Class Initialized
DEBUG - 2018-03-25 12:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 12:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 12:51:38 --> Controller Class Initialized
INFO - 2018-03-25 12:51:38 --> Model Class Initialized
INFO - 2018-03-25 12:51:38 --> Model Class Initialized
INFO - 2018-03-25 12:51:38 --> Model Class Initialized
INFO - 2018-03-25 12:51:38 --> Model Class Initialized
INFO - 2018-03-25 12:51:38 --> Model Class Initialized
INFO - 2018-03-25 12:51:38 --> Model Class Initialized
INFO - 2018-03-25 12:51:38 --> Model Class Initialized
INFO - 2018-03-25 12:51:38 --> Model Class Initialized
INFO - 2018-03-25 12:51:38 --> Model Class Initialized
INFO - 2018-03-25 12:51:38 --> Model Class Initialized
INFO - 2018-03-25 12:51:38 --> Model Class Initialized
INFO - 2018-03-25 12:51:38 --> Helper loaded: date_helper
INFO - 2018-03-25 12:51:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 17:51:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-25 17:51:38 --> Final output sent to browser
DEBUG - 2018-03-25 17:51:38 --> Total execution time: 0.0987
INFO - 2018-03-25 12:51:49 --> Config Class Initialized
INFO - 2018-03-25 12:51:49 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:51:49 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:51:49 --> Utf8 Class Initialized
INFO - 2018-03-25 12:51:49 --> URI Class Initialized
INFO - 2018-03-25 12:51:49 --> Router Class Initialized
INFO - 2018-03-25 12:51:49 --> Output Class Initialized
INFO - 2018-03-25 12:51:49 --> Security Class Initialized
DEBUG - 2018-03-25 12:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:51:49 --> Input Class Initialized
INFO - 2018-03-25 12:51:49 --> Language Class Initialized
ERROR - 2018-03-25 12:51:49 --> 404 Page Not Found: Kasir/Kasir/detailTagihan
INFO - 2018-03-25 12:51:51 --> Config Class Initialized
INFO - 2018-03-25 12:51:51 --> Hooks Class Initialized
DEBUG - 2018-03-25 12:51:51 --> UTF-8 Support Enabled
INFO - 2018-03-25 12:51:51 --> Utf8 Class Initialized
INFO - 2018-03-25 12:51:51 --> URI Class Initialized
INFO - 2018-03-25 12:51:51 --> Router Class Initialized
INFO - 2018-03-25 12:51:51 --> Output Class Initialized
INFO - 2018-03-25 12:51:51 --> Security Class Initialized
DEBUG - 2018-03-25 12:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 12:51:51 --> Input Class Initialized
INFO - 2018-03-25 12:51:51 --> Language Class Initialized
INFO - 2018-03-25 12:51:51 --> Loader Class Initialized
INFO - 2018-03-25 12:51:51 --> Helper loaded: url_helper
INFO - 2018-03-25 12:51:51 --> Helper loaded: form_helper
INFO - 2018-03-25 12:51:51 --> Database Driver Class Initialized
DEBUG - 2018-03-25 12:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 12:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 12:51:51 --> Controller Class Initialized
INFO - 2018-03-25 12:51:51 --> Model Class Initialized
INFO - 2018-03-25 12:51:51 --> Model Class Initialized
INFO - 2018-03-25 12:51:51 --> Model Class Initialized
INFO - 2018-03-25 12:51:51 --> Model Class Initialized
INFO - 2018-03-25 12:51:51 --> Model Class Initialized
INFO - 2018-03-25 12:51:51 --> Model Class Initialized
INFO - 2018-03-25 12:51:51 --> Model Class Initialized
INFO - 2018-03-25 12:51:51 --> Model Class Initialized
INFO - 2018-03-25 12:51:51 --> Model Class Initialized
INFO - 2018-03-25 12:51:51 --> Model Class Initialized
INFO - 2018-03-25 12:51:51 --> Model Class Initialized
INFO - 2018-03-25 12:51:51 --> Helper loaded: date_helper
INFO - 2018-03-25 12:51:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 17:51:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 17:51:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 17:51:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-25 17:51:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 17:51:51 --> Final output sent to browser
DEBUG - 2018-03-25 17:51:51 --> Total execution time: 0.1140
INFO - 2018-03-25 13:19:07 --> Config Class Initialized
INFO - 2018-03-25 13:19:07 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:19:07 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:19:07 --> Utf8 Class Initialized
INFO - 2018-03-25 13:19:07 --> URI Class Initialized
INFO - 2018-03-25 13:19:07 --> Router Class Initialized
INFO - 2018-03-25 13:19:07 --> Output Class Initialized
INFO - 2018-03-25 13:19:07 --> Security Class Initialized
DEBUG - 2018-03-25 13:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:19:07 --> Input Class Initialized
INFO - 2018-03-25 13:19:07 --> Language Class Initialized
INFO - 2018-03-25 13:19:07 --> Loader Class Initialized
INFO - 2018-03-25 13:19:07 --> Helper loaded: url_helper
INFO - 2018-03-25 13:19:07 --> Helper loaded: form_helper
INFO - 2018-03-25 13:19:07 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:19:07 --> Controller Class Initialized
INFO - 2018-03-25 13:19:07 --> Model Class Initialized
INFO - 2018-03-25 13:19:07 --> Model Class Initialized
INFO - 2018-03-25 13:19:07 --> Model Class Initialized
INFO - 2018-03-25 13:19:08 --> Model Class Initialized
INFO - 2018-03-25 13:19:08 --> Model Class Initialized
INFO - 2018-03-25 13:19:08 --> Model Class Initialized
INFO - 2018-03-25 13:19:08 --> Model Class Initialized
INFO - 2018-03-25 13:19:08 --> Model Class Initialized
INFO - 2018-03-25 13:19:08 --> Model Class Initialized
INFO - 2018-03-25 13:19:08 --> Model Class Initialized
INFO - 2018-03-25 13:19:08 --> Model Class Initialized
INFO - 2018-03-25 13:19:08 --> Helper loaded: date_helper
INFO - 2018-03-25 13:19:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 18:19:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 18:19:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 18:19:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-25 18:19:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 18:19:08 --> Final output sent to browser
DEBUG - 2018-03-25 18:19:08 --> Total execution time: 0.1083
INFO - 2018-03-25 13:19:10 --> Config Class Initialized
INFO - 2018-03-25 13:19:10 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:19:10 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:19:10 --> Utf8 Class Initialized
INFO - 2018-03-25 13:19:10 --> URI Class Initialized
INFO - 2018-03-25 13:19:10 --> Router Class Initialized
INFO - 2018-03-25 13:19:10 --> Output Class Initialized
INFO - 2018-03-25 13:19:10 --> Security Class Initialized
DEBUG - 2018-03-25 13:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:19:10 --> Input Class Initialized
INFO - 2018-03-25 13:19:10 --> Language Class Initialized
INFO - 2018-03-25 13:19:10 --> Loader Class Initialized
INFO - 2018-03-25 13:19:10 --> Helper loaded: url_helper
INFO - 2018-03-25 13:19:10 --> Helper loaded: form_helper
INFO - 2018-03-25 13:19:10 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:19:10 --> Controller Class Initialized
INFO - 2018-03-25 13:19:10 --> Model Class Initialized
INFO - 2018-03-25 13:19:10 --> Model Class Initialized
INFO - 2018-03-25 13:19:10 --> Model Class Initialized
INFO - 2018-03-25 13:19:10 --> Model Class Initialized
INFO - 2018-03-25 13:19:10 --> Model Class Initialized
INFO - 2018-03-25 13:19:10 --> Model Class Initialized
INFO - 2018-03-25 13:19:10 --> Model Class Initialized
INFO - 2018-03-25 13:19:10 --> Model Class Initialized
INFO - 2018-03-25 13:19:10 --> Model Class Initialized
INFO - 2018-03-25 13:19:10 --> Model Class Initialized
INFO - 2018-03-25 13:19:10 --> Model Class Initialized
INFO - 2018-03-25 13:19:10 --> Helper loaded: date_helper
INFO - 2018-03-25 13:19:10 --> Helper loaded: tanggal_helper
ERROR - 2018-03-25 18:19:10 --> Query error: Unknown column 'billing.id_mst_pasien' in 'on clause' - Invalid query: SELECT *
FROM `billing`
INNER JOIN `pendaftaran` ON `pendaftaran`.`id_trx_pendaftaran` = `billing`.`id_trx_pendaftaran`
INNER JOIN `mst_pasien` ON `mst_pasien`.`id_mst_pasien` = `billing`.`id_mst_pasien`
WHERE `id_billing` = '3'
ERROR - 2018-03-25 18:19:10 --> Severity: error --> Exception: Call to a member function row() on boolean E:\xampp\htdocs\skin_care\application\models\Billing_model.php 35
INFO - 2018-03-25 13:19:35 --> Config Class Initialized
INFO - 2018-03-25 13:19:35 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:19:35 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:19:35 --> Utf8 Class Initialized
INFO - 2018-03-25 13:19:35 --> URI Class Initialized
INFO - 2018-03-25 13:19:35 --> Router Class Initialized
INFO - 2018-03-25 13:19:35 --> Output Class Initialized
INFO - 2018-03-25 13:19:35 --> Security Class Initialized
DEBUG - 2018-03-25 13:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:19:35 --> Input Class Initialized
INFO - 2018-03-25 13:19:35 --> Language Class Initialized
INFO - 2018-03-25 13:19:35 --> Loader Class Initialized
INFO - 2018-03-25 13:19:35 --> Helper loaded: url_helper
INFO - 2018-03-25 13:19:35 --> Helper loaded: form_helper
INFO - 2018-03-25 13:19:35 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:19:35 --> Controller Class Initialized
INFO - 2018-03-25 13:19:35 --> Model Class Initialized
INFO - 2018-03-25 13:19:35 --> Model Class Initialized
INFO - 2018-03-25 13:19:35 --> Model Class Initialized
INFO - 2018-03-25 13:19:35 --> Model Class Initialized
INFO - 2018-03-25 13:19:35 --> Model Class Initialized
INFO - 2018-03-25 13:19:35 --> Model Class Initialized
INFO - 2018-03-25 13:19:35 --> Model Class Initialized
INFO - 2018-03-25 13:19:35 --> Model Class Initialized
INFO - 2018-03-25 13:19:35 --> Model Class Initialized
INFO - 2018-03-25 13:19:35 --> Model Class Initialized
INFO - 2018-03-25 13:19:35 --> Model Class Initialized
INFO - 2018-03-25 13:19:35 --> Helper loaded: date_helper
INFO - 2018-03-25 13:19:35 --> Helper loaded: tanggal_helper
ERROR - 2018-03-25 18:19:35 --> Severity: error --> Exception: Cannot use object of type stdClass as array E:\xampp\htdocs\skin_care\application\controllers\Kasir\Kasir.php 40
INFO - 2018-03-25 13:20:17 --> Config Class Initialized
INFO - 2018-03-25 13:20:17 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:20:17 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:20:17 --> Utf8 Class Initialized
INFO - 2018-03-25 13:20:17 --> URI Class Initialized
INFO - 2018-03-25 13:20:17 --> Router Class Initialized
INFO - 2018-03-25 13:20:17 --> Output Class Initialized
INFO - 2018-03-25 13:20:17 --> Security Class Initialized
DEBUG - 2018-03-25 13:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:20:17 --> Input Class Initialized
INFO - 2018-03-25 13:20:17 --> Language Class Initialized
INFO - 2018-03-25 13:20:17 --> Loader Class Initialized
INFO - 2018-03-25 13:20:17 --> Helper loaded: url_helper
INFO - 2018-03-25 13:20:17 --> Helper loaded: form_helper
INFO - 2018-03-25 13:20:17 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:20:17 --> Controller Class Initialized
INFO - 2018-03-25 13:20:17 --> Model Class Initialized
INFO - 2018-03-25 13:20:17 --> Model Class Initialized
INFO - 2018-03-25 13:20:17 --> Model Class Initialized
INFO - 2018-03-25 13:20:17 --> Model Class Initialized
INFO - 2018-03-25 13:20:17 --> Model Class Initialized
INFO - 2018-03-25 13:20:17 --> Model Class Initialized
INFO - 2018-03-25 13:20:17 --> Model Class Initialized
INFO - 2018-03-25 13:20:17 --> Model Class Initialized
INFO - 2018-03-25 13:20:17 --> Model Class Initialized
INFO - 2018-03-25 13:20:17 --> Model Class Initialized
INFO - 2018-03-25 13:20:17 --> Model Class Initialized
INFO - 2018-03-25 13:20:17 --> Helper loaded: date_helper
INFO - 2018-03-25 13:20:17 --> Helper loaded: tanggal_helper
ERROR - 2018-03-25 18:20:17 --> Severity: error --> Exception: Cannot use object of type stdClass as array E:\xampp\htdocs\skin_care\application\controllers\Kasir\Kasir.php 41
INFO - 2018-03-25 13:20:28 --> Config Class Initialized
INFO - 2018-03-25 13:20:28 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:20:28 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:20:28 --> Utf8 Class Initialized
INFO - 2018-03-25 13:20:28 --> URI Class Initialized
INFO - 2018-03-25 13:20:28 --> Router Class Initialized
INFO - 2018-03-25 13:20:28 --> Output Class Initialized
INFO - 2018-03-25 13:20:28 --> Security Class Initialized
DEBUG - 2018-03-25 13:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:20:28 --> Input Class Initialized
INFO - 2018-03-25 13:20:28 --> Language Class Initialized
INFO - 2018-03-25 13:20:28 --> Loader Class Initialized
INFO - 2018-03-25 13:20:28 --> Helper loaded: url_helper
INFO - 2018-03-25 13:20:28 --> Helper loaded: form_helper
INFO - 2018-03-25 13:20:28 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:20:28 --> Controller Class Initialized
INFO - 2018-03-25 13:20:28 --> Model Class Initialized
INFO - 2018-03-25 13:20:28 --> Model Class Initialized
INFO - 2018-03-25 13:20:28 --> Model Class Initialized
INFO - 2018-03-25 13:20:28 --> Model Class Initialized
INFO - 2018-03-25 13:20:28 --> Model Class Initialized
INFO - 2018-03-25 13:20:28 --> Model Class Initialized
INFO - 2018-03-25 13:20:28 --> Model Class Initialized
INFO - 2018-03-25 13:20:28 --> Model Class Initialized
INFO - 2018-03-25 13:20:28 --> Model Class Initialized
INFO - 2018-03-25 13:20:28 --> Model Class Initialized
INFO - 2018-03-25 13:20:28 --> Model Class Initialized
INFO - 2018-03-25 13:20:28 --> Helper loaded: date_helper
INFO - 2018-03-25 13:20:28 --> Helper loaded: tanggal_helper
ERROR - 2018-03-25 18:20:28 --> Severity: error --> Exception: Cannot use object of type stdClass as array E:\xampp\htdocs\skin_care\application\controllers\Kasir\Kasir.php 41
INFO - 2018-03-25 13:20:49 --> Config Class Initialized
INFO - 2018-03-25 13:20:49 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:20:50 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:20:50 --> Utf8 Class Initialized
INFO - 2018-03-25 13:20:50 --> URI Class Initialized
INFO - 2018-03-25 13:20:50 --> Router Class Initialized
INFO - 2018-03-25 13:20:50 --> Output Class Initialized
INFO - 2018-03-25 13:20:50 --> Security Class Initialized
DEBUG - 2018-03-25 13:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:20:50 --> Input Class Initialized
INFO - 2018-03-25 13:20:50 --> Language Class Initialized
INFO - 2018-03-25 13:20:50 --> Loader Class Initialized
INFO - 2018-03-25 13:20:50 --> Helper loaded: url_helper
INFO - 2018-03-25 13:20:50 --> Helper loaded: form_helper
INFO - 2018-03-25 13:20:50 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:20:50 --> Controller Class Initialized
INFO - 2018-03-25 13:20:50 --> Model Class Initialized
INFO - 2018-03-25 13:20:50 --> Model Class Initialized
INFO - 2018-03-25 13:20:50 --> Model Class Initialized
INFO - 2018-03-25 13:20:50 --> Model Class Initialized
INFO - 2018-03-25 13:20:50 --> Model Class Initialized
INFO - 2018-03-25 13:20:50 --> Model Class Initialized
INFO - 2018-03-25 13:20:50 --> Model Class Initialized
INFO - 2018-03-25 13:20:50 --> Model Class Initialized
INFO - 2018-03-25 13:20:50 --> Model Class Initialized
INFO - 2018-03-25 13:20:50 --> Model Class Initialized
INFO - 2018-03-25 13:20:50 --> Model Class Initialized
INFO - 2018-03-25 13:20:50 --> Helper loaded: date_helper
INFO - 2018-03-25 13:20:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 18:20:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 18:20:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 18:20:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-25 18:20:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 18:20:50 --> Final output sent to browser
DEBUG - 2018-03-25 18:20:50 --> Total execution time: 0.1141
INFO - 2018-03-25 13:21:21 --> Config Class Initialized
INFO - 2018-03-25 13:21:21 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:21:21 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:21:21 --> Utf8 Class Initialized
INFO - 2018-03-25 13:21:21 --> URI Class Initialized
INFO - 2018-03-25 13:21:21 --> Router Class Initialized
INFO - 2018-03-25 13:21:21 --> Output Class Initialized
INFO - 2018-03-25 13:21:21 --> Security Class Initialized
DEBUG - 2018-03-25 13:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:21:21 --> Input Class Initialized
INFO - 2018-03-25 13:21:21 --> Language Class Initialized
INFO - 2018-03-25 13:21:21 --> Loader Class Initialized
INFO - 2018-03-25 13:21:21 --> Helper loaded: url_helper
INFO - 2018-03-25 13:21:21 --> Helper loaded: form_helper
INFO - 2018-03-25 13:21:21 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:21:21 --> Controller Class Initialized
INFO - 2018-03-25 13:21:21 --> Model Class Initialized
INFO - 2018-03-25 13:21:21 --> Model Class Initialized
INFO - 2018-03-25 13:21:21 --> Model Class Initialized
INFO - 2018-03-25 13:21:21 --> Model Class Initialized
INFO - 2018-03-25 13:21:21 --> Model Class Initialized
INFO - 2018-03-25 13:21:21 --> Model Class Initialized
INFO - 2018-03-25 13:21:21 --> Model Class Initialized
INFO - 2018-03-25 13:21:21 --> Model Class Initialized
INFO - 2018-03-25 13:21:21 --> Model Class Initialized
INFO - 2018-03-25 13:21:21 --> Model Class Initialized
INFO - 2018-03-25 13:21:21 --> Model Class Initialized
INFO - 2018-03-25 13:21:21 --> Helper loaded: date_helper
INFO - 2018-03-25 13:21:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 18:21:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 18:21:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 18:21:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-25 18:21:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 18:21:21 --> Final output sent to browser
DEBUG - 2018-03-25 18:21:21 --> Total execution time: 0.1604
INFO - 2018-03-25 13:21:24 --> Config Class Initialized
INFO - 2018-03-25 13:21:24 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:21:24 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:21:24 --> Utf8 Class Initialized
INFO - 2018-03-25 13:21:24 --> URI Class Initialized
INFO - 2018-03-25 13:21:24 --> Router Class Initialized
INFO - 2018-03-25 13:21:24 --> Output Class Initialized
INFO - 2018-03-25 13:21:24 --> Security Class Initialized
DEBUG - 2018-03-25 13:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:21:24 --> Input Class Initialized
INFO - 2018-03-25 13:21:24 --> Language Class Initialized
INFO - 2018-03-25 13:21:24 --> Loader Class Initialized
INFO - 2018-03-25 13:21:24 --> Helper loaded: url_helper
INFO - 2018-03-25 13:21:24 --> Helper loaded: form_helper
INFO - 2018-03-25 13:21:24 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:21:24 --> Controller Class Initialized
INFO - 2018-03-25 13:21:24 --> Model Class Initialized
INFO - 2018-03-25 13:21:24 --> Model Class Initialized
INFO - 2018-03-25 13:21:24 --> Model Class Initialized
INFO - 2018-03-25 13:21:24 --> Model Class Initialized
INFO - 2018-03-25 13:21:24 --> Model Class Initialized
INFO - 2018-03-25 13:21:24 --> Model Class Initialized
INFO - 2018-03-25 13:21:24 --> Model Class Initialized
INFO - 2018-03-25 13:21:24 --> Model Class Initialized
INFO - 2018-03-25 13:21:24 --> Model Class Initialized
INFO - 2018-03-25 13:21:24 --> Model Class Initialized
INFO - 2018-03-25 13:21:24 --> Model Class Initialized
INFO - 2018-03-25 13:21:24 --> Model Class Initialized
INFO - 2018-03-25 13:21:24 --> Model Class Initialized
INFO - 2018-03-25 13:21:24 --> Model Class Initialized
INFO - 2018-03-25 13:21:24 --> Helper loaded: date_helper
INFO - 2018-03-25 13:21:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 18:21:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 18:21:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 18:21:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-25 18:21:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 18:21:24 --> Final output sent to browser
DEBUG - 2018-03-25 18:21:24 --> Total execution time: 0.1972
INFO - 2018-03-25 13:21:27 --> Config Class Initialized
INFO - 2018-03-25 13:21:27 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:21:27 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:21:27 --> Utf8 Class Initialized
INFO - 2018-03-25 13:21:27 --> URI Class Initialized
INFO - 2018-03-25 13:21:27 --> Router Class Initialized
INFO - 2018-03-25 13:21:27 --> Output Class Initialized
INFO - 2018-03-25 13:21:27 --> Security Class Initialized
DEBUG - 2018-03-25 13:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:21:27 --> Input Class Initialized
INFO - 2018-03-25 13:21:27 --> Language Class Initialized
INFO - 2018-03-25 13:21:27 --> Loader Class Initialized
INFO - 2018-03-25 13:21:27 --> Helper loaded: url_helper
INFO - 2018-03-25 13:21:27 --> Helper loaded: form_helper
INFO - 2018-03-25 13:21:27 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:21:27 --> Controller Class Initialized
INFO - 2018-03-25 13:21:27 --> Model Class Initialized
INFO - 2018-03-25 13:21:27 --> Model Class Initialized
INFO - 2018-03-25 13:21:27 --> Model Class Initialized
INFO - 2018-03-25 13:21:27 --> Model Class Initialized
INFO - 2018-03-25 13:21:27 --> Model Class Initialized
INFO - 2018-03-25 13:21:27 --> Model Class Initialized
INFO - 2018-03-25 13:21:27 --> Model Class Initialized
INFO - 2018-03-25 13:21:27 --> Model Class Initialized
INFO - 2018-03-25 13:21:27 --> Model Class Initialized
INFO - 2018-03-25 13:21:27 --> Model Class Initialized
INFO - 2018-03-25 13:21:27 --> Model Class Initialized
INFO - 2018-03-25 13:21:27 --> Model Class Initialized
INFO - 2018-03-25 13:21:27 --> Model Class Initialized
INFO - 2018-03-25 13:21:27 --> Model Class Initialized
INFO - 2018-03-25 13:21:27 --> Helper loaded: date_helper
INFO - 2018-03-25 13:21:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 18:21:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 18:21:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 18:21:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-25 18:21:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 18:21:27 --> Final output sent to browser
DEBUG - 2018-03-25 18:21:27 --> Total execution time: 0.1473
INFO - 2018-03-25 13:21:33 --> Config Class Initialized
INFO - 2018-03-25 13:21:33 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:21:33 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:21:33 --> Utf8 Class Initialized
INFO - 2018-03-25 13:21:33 --> URI Class Initialized
INFO - 2018-03-25 13:21:33 --> Router Class Initialized
INFO - 2018-03-25 13:21:33 --> Output Class Initialized
INFO - 2018-03-25 13:21:33 --> Security Class Initialized
DEBUG - 2018-03-25 13:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:21:33 --> Input Class Initialized
INFO - 2018-03-25 13:21:33 --> Language Class Initialized
INFO - 2018-03-25 13:21:33 --> Loader Class Initialized
INFO - 2018-03-25 13:21:33 --> Helper loaded: url_helper
INFO - 2018-03-25 13:21:33 --> Helper loaded: form_helper
INFO - 2018-03-25 13:21:33 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:21:33 --> Controller Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Helper loaded: date_helper
INFO - 2018-03-25 13:21:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 18:21:33 --> Final output sent to browser
DEBUG - 2018-03-25 18:21:33 --> Total execution time: 0.1281
INFO - 2018-03-25 13:21:33 --> Config Class Initialized
INFO - 2018-03-25 13:21:33 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:21:33 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:21:33 --> Utf8 Class Initialized
INFO - 2018-03-25 13:21:33 --> URI Class Initialized
INFO - 2018-03-25 13:21:33 --> Router Class Initialized
INFO - 2018-03-25 13:21:33 --> Output Class Initialized
INFO - 2018-03-25 13:21:33 --> Security Class Initialized
DEBUG - 2018-03-25 13:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:21:33 --> Input Class Initialized
INFO - 2018-03-25 13:21:33 --> Language Class Initialized
INFO - 2018-03-25 13:21:33 --> Loader Class Initialized
INFO - 2018-03-25 13:21:33 --> Helper loaded: url_helper
INFO - 2018-03-25 13:21:33 --> Helper loaded: form_helper
INFO - 2018-03-25 13:21:33 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:21:33 --> Controller Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Model Class Initialized
INFO - 2018-03-25 13:21:33 --> Helper loaded: date_helper
INFO - 2018-03-25 13:21:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 18:21:33 --> Final output sent to browser
DEBUG - 2018-03-25 18:21:33 --> Total execution time: 0.0908
INFO - 2018-03-25 13:21:34 --> Config Class Initialized
INFO - 2018-03-25 13:21:34 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:21:34 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:21:34 --> Utf8 Class Initialized
INFO - 2018-03-25 13:21:34 --> URI Class Initialized
INFO - 2018-03-25 13:21:34 --> Router Class Initialized
INFO - 2018-03-25 13:21:34 --> Output Class Initialized
INFO - 2018-03-25 13:21:34 --> Security Class Initialized
DEBUG - 2018-03-25 13:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:21:34 --> Input Class Initialized
INFO - 2018-03-25 13:21:34 --> Language Class Initialized
INFO - 2018-03-25 13:21:34 --> Loader Class Initialized
INFO - 2018-03-25 13:21:34 --> Helper loaded: url_helper
INFO - 2018-03-25 13:21:34 --> Helper loaded: form_helper
INFO - 2018-03-25 13:21:34 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:21:34 --> Controller Class Initialized
INFO - 2018-03-25 13:21:34 --> Model Class Initialized
INFO - 2018-03-25 13:21:34 --> Model Class Initialized
INFO - 2018-03-25 13:21:34 --> Model Class Initialized
INFO - 2018-03-25 13:21:34 --> Model Class Initialized
INFO - 2018-03-25 13:21:34 --> Model Class Initialized
INFO - 2018-03-25 13:21:34 --> Model Class Initialized
INFO - 2018-03-25 13:21:34 --> Model Class Initialized
INFO - 2018-03-25 13:21:34 --> Model Class Initialized
INFO - 2018-03-25 13:21:34 --> Model Class Initialized
INFO - 2018-03-25 13:21:34 --> Model Class Initialized
INFO - 2018-03-25 13:21:34 --> Model Class Initialized
INFO - 2018-03-25 13:21:34 --> Model Class Initialized
INFO - 2018-03-25 13:21:34 --> Model Class Initialized
INFO - 2018-03-25 13:21:34 --> Model Class Initialized
INFO - 2018-03-25 13:21:34 --> Helper loaded: date_helper
INFO - 2018-03-25 13:21:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 18:21:34 --> Final output sent to browser
DEBUG - 2018-03-25 18:21:34 --> Total execution time: 0.1401
INFO - 2018-03-25 13:21:37 --> Config Class Initialized
INFO - 2018-03-25 13:21:37 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:21:37 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:21:37 --> Utf8 Class Initialized
INFO - 2018-03-25 13:21:37 --> URI Class Initialized
INFO - 2018-03-25 13:21:37 --> Router Class Initialized
INFO - 2018-03-25 13:21:37 --> Output Class Initialized
INFO - 2018-03-25 13:21:37 --> Security Class Initialized
DEBUG - 2018-03-25 13:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:21:37 --> Input Class Initialized
INFO - 2018-03-25 13:21:37 --> Language Class Initialized
INFO - 2018-03-25 13:21:37 --> Loader Class Initialized
INFO - 2018-03-25 13:21:37 --> Helper loaded: url_helper
INFO - 2018-03-25 13:21:37 --> Helper loaded: form_helper
INFO - 2018-03-25 13:21:37 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:21:37 --> Controller Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Helper loaded: date_helper
INFO - 2018-03-25 13:21:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:21:37 --> Config Class Initialized
INFO - 2018-03-25 13:21:37 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:21:37 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:21:37 --> Utf8 Class Initialized
INFO - 2018-03-25 13:21:37 --> URI Class Initialized
INFO - 2018-03-25 13:21:37 --> Router Class Initialized
INFO - 2018-03-25 13:21:37 --> Output Class Initialized
INFO - 2018-03-25 13:21:37 --> Security Class Initialized
DEBUG - 2018-03-25 13:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:21:37 --> Input Class Initialized
INFO - 2018-03-25 13:21:37 --> Language Class Initialized
INFO - 2018-03-25 13:21:37 --> Loader Class Initialized
INFO - 2018-03-25 13:21:37 --> Helper loaded: url_helper
INFO - 2018-03-25 13:21:37 --> Helper loaded: form_helper
INFO - 2018-03-25 13:21:37 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:21:37 --> Controller Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Model Class Initialized
INFO - 2018-03-25 13:21:37 --> Helper loaded: date_helper
INFO - 2018-03-25 13:21:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 18:21:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 18:21:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 18:21:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-25 18:21:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 18:21:37 --> Final output sent to browser
DEBUG - 2018-03-25 18:21:37 --> Total execution time: 0.2270
INFO - 2018-03-25 13:21:43 --> Config Class Initialized
INFO - 2018-03-25 13:21:43 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:21:43 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:21:43 --> Utf8 Class Initialized
INFO - 2018-03-25 13:21:43 --> URI Class Initialized
INFO - 2018-03-25 13:21:43 --> Router Class Initialized
INFO - 2018-03-25 13:21:43 --> Output Class Initialized
INFO - 2018-03-25 13:21:43 --> Security Class Initialized
DEBUG - 2018-03-25 13:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:21:43 --> Input Class Initialized
INFO - 2018-03-25 13:21:43 --> Language Class Initialized
INFO - 2018-03-25 13:21:43 --> Loader Class Initialized
INFO - 2018-03-25 13:21:43 --> Helper loaded: url_helper
INFO - 2018-03-25 13:21:43 --> Helper loaded: form_helper
INFO - 2018-03-25 13:21:43 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:21:43 --> Controller Class Initialized
INFO - 2018-03-25 13:21:43 --> Model Class Initialized
INFO - 2018-03-25 13:21:43 --> Model Class Initialized
INFO - 2018-03-25 13:21:43 --> Helper loaded: date_helper
INFO - 2018-03-25 13:21:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 18:21:43 --> Final output sent to browser
DEBUG - 2018-03-25 18:21:43 --> Total execution time: 0.0988
INFO - 2018-03-25 13:21:48 --> Config Class Initialized
INFO - 2018-03-25 13:21:48 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:21:48 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:21:48 --> Utf8 Class Initialized
INFO - 2018-03-25 13:21:48 --> URI Class Initialized
INFO - 2018-03-25 13:21:48 --> Router Class Initialized
INFO - 2018-03-25 13:21:48 --> Output Class Initialized
INFO - 2018-03-25 13:21:48 --> Security Class Initialized
DEBUG - 2018-03-25 13:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:21:48 --> Input Class Initialized
INFO - 2018-03-25 13:21:48 --> Language Class Initialized
INFO - 2018-03-25 13:21:48 --> Loader Class Initialized
INFO - 2018-03-25 13:21:48 --> Helper loaded: url_helper
INFO - 2018-03-25 13:21:48 --> Helper loaded: form_helper
INFO - 2018-03-25 13:21:48 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:21:48 --> Controller Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Helper loaded: date_helper
INFO - 2018-03-25 13:21:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:21:48 --> Config Class Initialized
INFO - 2018-03-25 13:21:48 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:21:48 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:21:48 --> Utf8 Class Initialized
INFO - 2018-03-25 13:21:48 --> URI Class Initialized
INFO - 2018-03-25 13:21:48 --> Router Class Initialized
INFO - 2018-03-25 13:21:48 --> Output Class Initialized
INFO - 2018-03-25 13:21:48 --> Security Class Initialized
DEBUG - 2018-03-25 13:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:21:48 --> Input Class Initialized
INFO - 2018-03-25 13:21:48 --> Language Class Initialized
INFO - 2018-03-25 13:21:48 --> Loader Class Initialized
INFO - 2018-03-25 13:21:48 --> Helper loaded: url_helper
INFO - 2018-03-25 13:21:48 --> Helper loaded: form_helper
INFO - 2018-03-25 13:21:48 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:21:48 --> Controller Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Model Class Initialized
INFO - 2018-03-25 13:21:48 --> Helper loaded: date_helper
INFO - 2018-03-25 13:21:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 18:21:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 18:21:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 18:21:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-25 18:21:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 18:21:48 --> Final output sent to browser
DEBUG - 2018-03-25 18:21:48 --> Total execution time: 0.1343
INFO - 2018-03-25 13:22:04 --> Config Class Initialized
INFO - 2018-03-25 13:22:04 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:22:04 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:22:04 --> Utf8 Class Initialized
INFO - 2018-03-25 13:22:04 --> URI Class Initialized
INFO - 2018-03-25 13:22:04 --> Router Class Initialized
INFO - 2018-03-25 13:22:04 --> Output Class Initialized
INFO - 2018-03-25 13:22:04 --> Security Class Initialized
DEBUG - 2018-03-25 13:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:22:04 --> Input Class Initialized
INFO - 2018-03-25 13:22:04 --> Language Class Initialized
INFO - 2018-03-25 13:22:04 --> Loader Class Initialized
INFO - 2018-03-25 13:22:04 --> Helper loaded: url_helper
INFO - 2018-03-25 13:22:04 --> Helper loaded: form_helper
INFO - 2018-03-25 13:22:04 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:22:04 --> Controller Class Initialized
INFO - 2018-03-25 13:22:04 --> Model Class Initialized
INFO - 2018-03-25 13:22:04 --> Model Class Initialized
INFO - 2018-03-25 13:22:04 --> Model Class Initialized
INFO - 2018-03-25 13:22:04 --> Model Class Initialized
INFO - 2018-03-25 13:22:04 --> Model Class Initialized
INFO - 2018-03-25 13:22:04 --> Model Class Initialized
INFO - 2018-03-25 13:22:04 --> Model Class Initialized
INFO - 2018-03-25 13:22:04 --> Model Class Initialized
INFO - 2018-03-25 13:22:04 --> Model Class Initialized
INFO - 2018-03-25 13:22:04 --> Model Class Initialized
INFO - 2018-03-25 13:22:04 --> Model Class Initialized
INFO - 2018-03-25 13:22:04 --> Helper loaded: date_helper
INFO - 2018-03-25 13:22:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 18:22:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 18:22:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 18:22:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-25 18:22:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 18:22:04 --> Final output sent to browser
DEBUG - 2018-03-25 18:22:04 --> Total execution time: 0.1319
INFO - 2018-03-25 13:22:33 --> Config Class Initialized
INFO - 2018-03-25 13:22:33 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:22:33 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:22:33 --> Utf8 Class Initialized
INFO - 2018-03-25 13:22:33 --> URI Class Initialized
INFO - 2018-03-25 13:22:33 --> Router Class Initialized
INFO - 2018-03-25 13:22:33 --> Output Class Initialized
INFO - 2018-03-25 13:22:33 --> Security Class Initialized
DEBUG - 2018-03-25 13:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:22:33 --> Input Class Initialized
INFO - 2018-03-25 13:22:33 --> Language Class Initialized
INFO - 2018-03-25 13:22:33 --> Loader Class Initialized
INFO - 2018-03-25 13:22:33 --> Helper loaded: url_helper
INFO - 2018-03-25 13:22:33 --> Helper loaded: form_helper
INFO - 2018-03-25 13:22:33 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:22:33 --> Controller Class Initialized
INFO - 2018-03-25 13:22:33 --> Model Class Initialized
INFO - 2018-03-25 13:22:33 --> Model Class Initialized
INFO - 2018-03-25 13:22:33 --> Model Class Initialized
INFO - 2018-03-25 13:22:33 --> Model Class Initialized
INFO - 2018-03-25 13:22:33 --> Model Class Initialized
INFO - 2018-03-25 13:22:33 --> Model Class Initialized
INFO - 2018-03-25 13:22:33 --> Model Class Initialized
INFO - 2018-03-25 13:22:33 --> Model Class Initialized
INFO - 2018-03-25 13:22:33 --> Model Class Initialized
INFO - 2018-03-25 13:22:33 --> Model Class Initialized
INFO - 2018-03-25 13:22:33 --> Model Class Initialized
INFO - 2018-03-25 13:22:33 --> Model Class Initialized
INFO - 2018-03-25 13:22:33 --> Model Class Initialized
INFO - 2018-03-25 13:22:33 --> Model Class Initialized
INFO - 2018-03-25 13:22:33 --> Helper loaded: date_helper
INFO - 2018-03-25 13:22:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 18:22:33 --> Final output sent to browser
DEBUG - 2018-03-25 18:22:33 --> Total execution time: 0.1426
INFO - 2018-03-25 13:22:36 --> Config Class Initialized
INFO - 2018-03-25 13:22:36 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:22:36 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:22:36 --> Utf8 Class Initialized
INFO - 2018-03-25 13:22:36 --> URI Class Initialized
INFO - 2018-03-25 13:22:36 --> Router Class Initialized
INFO - 2018-03-25 13:22:36 --> Output Class Initialized
INFO - 2018-03-25 13:22:36 --> Security Class Initialized
DEBUG - 2018-03-25 13:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:22:36 --> Input Class Initialized
INFO - 2018-03-25 13:22:36 --> Language Class Initialized
INFO - 2018-03-25 13:22:36 --> Loader Class Initialized
INFO - 2018-03-25 13:22:36 --> Helper loaded: url_helper
INFO - 2018-03-25 13:22:36 --> Helper loaded: form_helper
INFO - 2018-03-25 13:22:36 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:22:36 --> Controller Class Initialized
INFO - 2018-03-25 13:22:36 --> Model Class Initialized
INFO - 2018-03-25 13:22:36 --> Model Class Initialized
INFO - 2018-03-25 13:22:36 --> Model Class Initialized
INFO - 2018-03-25 13:22:36 --> Model Class Initialized
INFO - 2018-03-25 13:22:36 --> Model Class Initialized
INFO - 2018-03-25 13:22:36 --> Model Class Initialized
INFO - 2018-03-25 13:22:36 --> Model Class Initialized
INFO - 2018-03-25 13:22:36 --> Model Class Initialized
INFO - 2018-03-25 13:22:36 --> Model Class Initialized
INFO - 2018-03-25 13:22:36 --> Model Class Initialized
INFO - 2018-03-25 13:22:36 --> Model Class Initialized
INFO - 2018-03-25 13:22:36 --> Model Class Initialized
INFO - 2018-03-25 13:22:36 --> Model Class Initialized
INFO - 2018-03-25 13:22:36 --> Model Class Initialized
INFO - 2018-03-25 13:22:36 --> Helper loaded: date_helper
INFO - 2018-03-25 13:22:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 18:22:36 --> Final output sent to browser
DEBUG - 2018-03-25 18:22:36 --> Total execution time: 0.1026
INFO - 2018-03-25 13:22:39 --> Config Class Initialized
INFO - 2018-03-25 13:22:39 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:22:39 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:22:39 --> Utf8 Class Initialized
INFO - 2018-03-25 13:22:39 --> URI Class Initialized
INFO - 2018-03-25 13:22:40 --> Router Class Initialized
INFO - 2018-03-25 13:22:40 --> Output Class Initialized
INFO - 2018-03-25 13:22:40 --> Security Class Initialized
DEBUG - 2018-03-25 13:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:22:40 --> Input Class Initialized
INFO - 2018-03-25 13:22:40 --> Language Class Initialized
INFO - 2018-03-25 13:22:40 --> Loader Class Initialized
INFO - 2018-03-25 13:22:40 --> Helper loaded: url_helper
INFO - 2018-03-25 13:22:40 --> Helper loaded: form_helper
INFO - 2018-03-25 13:22:40 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:22:40 --> Controller Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Helper loaded: date_helper
INFO - 2018-03-25 13:22:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 13:22:40 --> Config Class Initialized
INFO - 2018-03-25 13:22:40 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:22:40 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:22:40 --> Utf8 Class Initialized
INFO - 2018-03-25 13:22:40 --> URI Class Initialized
INFO - 2018-03-25 13:22:40 --> Router Class Initialized
INFO - 2018-03-25 13:22:40 --> Output Class Initialized
INFO - 2018-03-25 13:22:40 --> Security Class Initialized
DEBUG - 2018-03-25 13:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:22:40 --> Input Class Initialized
INFO - 2018-03-25 13:22:40 --> Language Class Initialized
INFO - 2018-03-25 13:22:40 --> Loader Class Initialized
INFO - 2018-03-25 13:22:40 --> Helper loaded: url_helper
INFO - 2018-03-25 13:22:40 --> Helper loaded: form_helper
INFO - 2018-03-25 13:22:40 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:22:40 --> Controller Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Model Class Initialized
INFO - 2018-03-25 13:22:40 --> Helper loaded: date_helper
INFO - 2018-03-25 13:22:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 18:22:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 18:22:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 18:22:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-25 18:22:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 18:22:40 --> Final output sent to browser
DEBUG - 2018-03-25 18:22:40 --> Total execution time: 0.1489
INFO - 2018-03-25 13:22:44 --> Config Class Initialized
INFO - 2018-03-25 13:22:44 --> Hooks Class Initialized
DEBUG - 2018-03-25 13:22:44 --> UTF-8 Support Enabled
INFO - 2018-03-25 13:22:44 --> Utf8 Class Initialized
INFO - 2018-03-25 13:22:44 --> URI Class Initialized
INFO - 2018-03-25 13:22:44 --> Router Class Initialized
INFO - 2018-03-25 13:22:44 --> Output Class Initialized
INFO - 2018-03-25 13:22:44 --> Security Class Initialized
DEBUG - 2018-03-25 13:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 13:22:44 --> Input Class Initialized
INFO - 2018-03-25 13:22:44 --> Language Class Initialized
INFO - 2018-03-25 13:22:44 --> Loader Class Initialized
INFO - 2018-03-25 13:22:44 --> Helper loaded: url_helper
INFO - 2018-03-25 13:22:44 --> Helper loaded: form_helper
INFO - 2018-03-25 13:22:44 --> Database Driver Class Initialized
DEBUG - 2018-03-25 13:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 13:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 13:22:44 --> Controller Class Initialized
INFO - 2018-03-25 13:22:44 --> Model Class Initialized
INFO - 2018-03-25 13:22:44 --> Model Class Initialized
INFO - 2018-03-25 13:22:44 --> Model Class Initialized
INFO - 2018-03-25 13:22:44 --> Model Class Initialized
INFO - 2018-03-25 13:22:44 --> Model Class Initialized
INFO - 2018-03-25 13:22:44 --> Model Class Initialized
INFO - 2018-03-25 13:22:44 --> Model Class Initialized
INFO - 2018-03-25 13:22:44 --> Model Class Initialized
INFO - 2018-03-25 13:22:44 --> Model Class Initialized
INFO - 2018-03-25 13:22:44 --> Model Class Initialized
INFO - 2018-03-25 13:22:44 --> Model Class Initialized
INFO - 2018-03-25 13:22:44 --> Helper loaded: date_helper
INFO - 2018-03-25 13:22:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 18:22:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 18:22:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 18:22:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-25 18:22:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 18:22:44 --> Final output sent to browser
DEBUG - 2018-03-25 18:22:44 --> Total execution time: 0.1246
INFO - 2018-03-25 18:29:52 --> Config Class Initialized
INFO - 2018-03-25 18:29:52 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:29:52 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:29:52 --> Utf8 Class Initialized
INFO - 2018-03-25 18:29:52 --> URI Class Initialized
INFO - 2018-03-25 18:29:52 --> Router Class Initialized
INFO - 2018-03-25 18:29:52 --> Output Class Initialized
INFO - 2018-03-25 18:29:52 --> Security Class Initialized
DEBUG - 2018-03-25 18:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:29:52 --> Input Class Initialized
INFO - 2018-03-25 18:29:52 --> Language Class Initialized
INFO - 2018-03-25 18:29:52 --> Loader Class Initialized
INFO - 2018-03-25 18:29:52 --> Helper loaded: url_helper
INFO - 2018-03-25 18:29:52 --> Helper loaded: form_helper
INFO - 2018-03-25 18:29:52 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:29:52 --> Controller Class Initialized
INFO - 2018-03-25 18:29:52 --> Config Class Initialized
INFO - 2018-03-25 18:29:52 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:29:52 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:29:52 --> Utf8 Class Initialized
INFO - 2018-03-25 18:29:52 --> URI Class Initialized
INFO - 2018-03-25 18:29:52 --> Router Class Initialized
INFO - 2018-03-25 18:29:52 --> Output Class Initialized
INFO - 2018-03-25 18:29:52 --> Security Class Initialized
DEBUG - 2018-03-25 18:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:29:52 --> Input Class Initialized
INFO - 2018-03-25 18:29:52 --> Language Class Initialized
INFO - 2018-03-25 18:29:52 --> Loader Class Initialized
INFO - 2018-03-25 18:29:52 --> Helper loaded: url_helper
INFO - 2018-03-25 18:29:52 --> Helper loaded: form_helper
INFO - 2018-03-25 18:29:52 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:29:52 --> Controller Class Initialized
INFO - 2018-03-25 18:29:52 --> Model Class Initialized
INFO - 2018-03-25 18:29:52 --> Model Class Initialized
INFO - 2018-03-25 18:29:52 --> Model Class Initialized
INFO - 2018-03-25 18:29:52 --> Helper loaded: date_helper
INFO - 2018-03-25 23:29:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-25 23:29:52 --> Final output sent to browser
DEBUG - 2018-03-25 23:29:52 --> Total execution time: 0.1628
INFO - 2018-03-25 18:29:58 --> Config Class Initialized
INFO - 2018-03-25 18:29:58 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:29:58 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:29:58 --> Utf8 Class Initialized
INFO - 2018-03-25 18:29:58 --> URI Class Initialized
INFO - 2018-03-25 18:29:58 --> Router Class Initialized
INFO - 2018-03-25 18:29:58 --> Output Class Initialized
INFO - 2018-03-25 18:29:58 --> Security Class Initialized
DEBUG - 2018-03-25 18:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:29:58 --> Input Class Initialized
INFO - 2018-03-25 18:29:58 --> Language Class Initialized
INFO - 2018-03-25 18:29:58 --> Loader Class Initialized
INFO - 2018-03-25 18:29:58 --> Helper loaded: url_helper
INFO - 2018-03-25 18:29:58 --> Helper loaded: form_helper
INFO - 2018-03-25 18:29:58 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:29:58 --> Controller Class Initialized
INFO - 2018-03-25 18:29:58 --> Model Class Initialized
INFO - 2018-03-25 18:29:58 --> Model Class Initialized
INFO - 2018-03-25 18:29:58 --> Model Class Initialized
INFO - 2018-03-25 18:29:58 --> Helper loaded: date_helper
INFO - 2018-03-25 18:29:59 --> Config Class Initialized
INFO - 2018-03-25 18:29:59 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:29:59 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:29:59 --> Utf8 Class Initialized
INFO - 2018-03-25 18:29:59 --> URI Class Initialized
INFO - 2018-03-25 18:29:59 --> Router Class Initialized
INFO - 2018-03-25 18:29:59 --> Output Class Initialized
INFO - 2018-03-25 18:29:59 --> Security Class Initialized
DEBUG - 2018-03-25 18:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:29:59 --> Input Class Initialized
INFO - 2018-03-25 18:29:59 --> Language Class Initialized
INFO - 2018-03-25 18:29:59 --> Loader Class Initialized
INFO - 2018-03-25 18:29:59 --> Helper loaded: url_helper
INFO - 2018-03-25 18:29:59 --> Helper loaded: form_helper
INFO - 2018-03-25 18:29:59 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:29:59 --> Controller Class Initialized
INFO - 2018-03-25 18:29:59 --> Model Class Initialized
INFO - 2018-03-25 18:29:59 --> Model Class Initialized
INFO - 2018-03-25 18:29:59 --> Model Class Initialized
INFO - 2018-03-25 18:29:59 --> Model Class Initialized
INFO - 2018-03-25 18:29:59 --> Model Class Initialized
INFO - 2018-03-25 18:29:59 --> Helper loaded: date_helper
INFO - 2018-03-25 23:30:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 23:30:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 23:30:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-25 23:30:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 23:30:00 --> Final output sent to browser
DEBUG - 2018-03-25 23:30:00 --> Total execution time: 0.9890
INFO - 2018-03-25 18:30:04 --> Config Class Initialized
INFO - 2018-03-25 18:30:04 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:30:04 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:30:04 --> Utf8 Class Initialized
INFO - 2018-03-25 18:30:04 --> URI Class Initialized
INFO - 2018-03-25 18:30:04 --> Router Class Initialized
INFO - 2018-03-25 18:30:04 --> Output Class Initialized
INFO - 2018-03-25 18:30:04 --> Security Class Initialized
DEBUG - 2018-03-25 18:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:30:04 --> Input Class Initialized
INFO - 2018-03-25 18:30:04 --> Language Class Initialized
INFO - 2018-03-25 18:30:04 --> Loader Class Initialized
INFO - 2018-03-25 18:30:04 --> Helper loaded: url_helper
INFO - 2018-03-25 18:30:04 --> Helper loaded: form_helper
INFO - 2018-03-25 18:30:04 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:30:04 --> Controller Class Initialized
INFO - 2018-03-25 18:30:04 --> Model Class Initialized
INFO - 2018-03-25 18:30:04 --> Model Class Initialized
INFO - 2018-03-25 18:30:04 --> Model Class Initialized
INFO - 2018-03-25 18:30:04 --> Model Class Initialized
INFO - 2018-03-25 18:30:04 --> Model Class Initialized
INFO - 2018-03-25 18:30:04 --> Model Class Initialized
INFO - 2018-03-25 18:30:04 --> Model Class Initialized
INFO - 2018-03-25 18:30:04 --> Model Class Initialized
INFO - 2018-03-25 18:30:04 --> Model Class Initialized
INFO - 2018-03-25 18:30:04 --> Model Class Initialized
INFO - 2018-03-25 18:30:04 --> Model Class Initialized
INFO - 2018-03-25 18:30:04 --> Helper loaded: date_helper
INFO - 2018-03-25 18:30:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 23:30:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 23:30:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 23:30:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-25 23:30:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 23:30:05 --> Final output sent to browser
DEBUG - 2018-03-25 23:30:05 --> Total execution time: 0.7501
INFO - 2018-03-25 18:30:07 --> Config Class Initialized
INFO - 2018-03-25 18:30:07 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:30:07 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:30:07 --> Utf8 Class Initialized
INFO - 2018-03-25 18:30:07 --> URI Class Initialized
INFO - 2018-03-25 18:30:07 --> Router Class Initialized
INFO - 2018-03-25 18:30:07 --> Output Class Initialized
INFO - 2018-03-25 18:30:07 --> Security Class Initialized
DEBUG - 2018-03-25 18:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:30:07 --> Input Class Initialized
INFO - 2018-03-25 18:30:07 --> Language Class Initialized
INFO - 2018-03-25 18:30:07 --> Loader Class Initialized
INFO - 2018-03-25 18:30:07 --> Helper loaded: url_helper
INFO - 2018-03-25 18:30:07 --> Helper loaded: form_helper
INFO - 2018-03-25 18:30:07 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:30:07 --> Controller Class Initialized
INFO - 2018-03-25 18:30:07 --> Model Class Initialized
INFO - 2018-03-25 18:30:07 --> Model Class Initialized
INFO - 2018-03-25 18:30:07 --> Model Class Initialized
INFO - 2018-03-25 18:30:07 --> Model Class Initialized
INFO - 2018-03-25 18:30:07 --> Model Class Initialized
INFO - 2018-03-25 18:30:07 --> Model Class Initialized
INFO - 2018-03-25 18:30:07 --> Model Class Initialized
INFO - 2018-03-25 18:30:07 --> Model Class Initialized
INFO - 2018-03-25 18:30:07 --> Model Class Initialized
INFO - 2018-03-25 18:30:07 --> Model Class Initialized
INFO - 2018-03-25 18:30:07 --> Model Class Initialized
INFO - 2018-03-25 18:30:07 --> Helper loaded: date_helper
INFO - 2018-03-25 18:30:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 23:30:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 23:30:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 23:30:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-25 23:30:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 23:30:07 --> Final output sent to browser
DEBUG - 2018-03-25 23:30:07 --> Total execution time: 0.2889
INFO - 2018-03-25 18:32:42 --> Config Class Initialized
INFO - 2018-03-25 18:32:42 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:32:42 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:32:42 --> Utf8 Class Initialized
INFO - 2018-03-25 18:32:42 --> URI Class Initialized
INFO - 2018-03-25 18:32:42 --> Router Class Initialized
INFO - 2018-03-25 18:32:42 --> Output Class Initialized
INFO - 2018-03-25 18:32:42 --> Security Class Initialized
DEBUG - 2018-03-25 18:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:32:42 --> Input Class Initialized
INFO - 2018-03-25 18:32:42 --> Language Class Initialized
INFO - 2018-03-25 18:32:42 --> Loader Class Initialized
INFO - 2018-03-25 18:32:42 --> Helper loaded: url_helper
INFO - 2018-03-25 18:32:42 --> Helper loaded: form_helper
INFO - 2018-03-25 18:32:42 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:32:42 --> Controller Class Initialized
INFO - 2018-03-25 18:32:42 --> Model Class Initialized
INFO - 2018-03-25 18:32:42 --> Model Class Initialized
INFO - 2018-03-25 18:32:42 --> Model Class Initialized
INFO - 2018-03-25 18:32:42 --> Model Class Initialized
INFO - 2018-03-25 18:32:42 --> Model Class Initialized
INFO - 2018-03-25 18:32:42 --> Model Class Initialized
INFO - 2018-03-25 18:32:42 --> Model Class Initialized
INFO - 2018-03-25 18:32:42 --> Model Class Initialized
INFO - 2018-03-25 18:32:42 --> Model Class Initialized
INFO - 2018-03-25 18:32:42 --> Model Class Initialized
INFO - 2018-03-25 18:32:42 --> Model Class Initialized
INFO - 2018-03-25 18:32:42 --> Helper loaded: date_helper
INFO - 2018-03-25 18:32:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 23:32:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 23:32:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 23:32:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-25 23:32:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 23:32:43 --> Final output sent to browser
DEBUG - 2018-03-25 23:32:43 --> Total execution time: 0.2111
INFO - 2018-03-25 18:35:26 --> Config Class Initialized
INFO - 2018-03-25 18:35:26 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:35:26 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:35:26 --> Utf8 Class Initialized
INFO - 2018-03-25 18:35:26 --> URI Class Initialized
INFO - 2018-03-25 18:35:26 --> Router Class Initialized
INFO - 2018-03-25 18:35:26 --> Output Class Initialized
INFO - 2018-03-25 18:35:26 --> Security Class Initialized
DEBUG - 2018-03-25 18:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:35:26 --> Input Class Initialized
INFO - 2018-03-25 18:35:26 --> Language Class Initialized
INFO - 2018-03-25 18:35:26 --> Loader Class Initialized
INFO - 2018-03-25 18:35:26 --> Helper loaded: url_helper
INFO - 2018-03-25 18:35:26 --> Helper loaded: form_helper
INFO - 2018-03-25 18:35:26 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:35:26 --> Controller Class Initialized
INFO - 2018-03-25 18:35:26 --> Model Class Initialized
INFO - 2018-03-25 18:35:26 --> Model Class Initialized
INFO - 2018-03-25 18:35:26 --> Model Class Initialized
INFO - 2018-03-25 18:35:26 --> Model Class Initialized
INFO - 2018-03-25 18:35:26 --> Model Class Initialized
INFO - 2018-03-25 18:35:26 --> Model Class Initialized
INFO - 2018-03-25 18:35:26 --> Model Class Initialized
INFO - 2018-03-25 18:35:26 --> Model Class Initialized
INFO - 2018-03-25 18:35:26 --> Model Class Initialized
INFO - 2018-03-25 18:35:26 --> Model Class Initialized
INFO - 2018-03-25 18:35:26 --> Model Class Initialized
INFO - 2018-03-25 18:35:26 --> Model Class Initialized
INFO - 2018-03-25 18:35:26 --> Model Class Initialized
INFO - 2018-03-25 18:35:26 --> Model Class Initialized
INFO - 2018-03-25 18:35:26 --> Helper loaded: date_helper
INFO - 2018-03-25 18:35:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 23:35:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 23:35:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 23:35:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-25 23:35:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 23:35:27 --> Final output sent to browser
DEBUG - 2018-03-25 23:35:27 --> Total execution time: 0.3043
INFO - 2018-03-25 18:35:29 --> Config Class Initialized
INFO - 2018-03-25 18:35:29 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:35:29 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:35:29 --> Utf8 Class Initialized
INFO - 2018-03-25 18:35:29 --> URI Class Initialized
INFO - 2018-03-25 18:35:29 --> Router Class Initialized
INFO - 2018-03-25 18:35:29 --> Output Class Initialized
INFO - 2018-03-25 18:35:29 --> Security Class Initialized
DEBUG - 2018-03-25 18:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:35:29 --> Input Class Initialized
INFO - 2018-03-25 18:35:29 --> Language Class Initialized
INFO - 2018-03-25 18:35:29 --> Loader Class Initialized
INFO - 2018-03-25 18:35:29 --> Helper loaded: url_helper
INFO - 2018-03-25 18:35:29 --> Helper loaded: form_helper
INFO - 2018-03-25 18:35:29 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:35:29 --> Controller Class Initialized
INFO - 2018-03-25 18:35:29 --> Model Class Initialized
INFO - 2018-03-25 18:35:29 --> Model Class Initialized
INFO - 2018-03-25 18:35:29 --> Model Class Initialized
INFO - 2018-03-25 18:35:29 --> Model Class Initialized
INFO - 2018-03-25 18:35:29 --> Model Class Initialized
INFO - 2018-03-25 18:35:29 --> Model Class Initialized
INFO - 2018-03-25 18:35:29 --> Model Class Initialized
INFO - 2018-03-25 18:35:29 --> Model Class Initialized
INFO - 2018-03-25 18:35:29 --> Model Class Initialized
INFO - 2018-03-25 18:35:29 --> Model Class Initialized
INFO - 2018-03-25 18:35:29 --> Model Class Initialized
INFO - 2018-03-25 18:35:29 --> Model Class Initialized
INFO - 2018-03-25 18:35:29 --> Model Class Initialized
INFO - 2018-03-25 18:35:29 --> Model Class Initialized
INFO - 2018-03-25 18:35:29 --> Helper loaded: date_helper
INFO - 2018-03-25 18:35:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 23:35:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 23:35:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 23:35:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-25 23:35:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 23:35:29 --> Final output sent to browser
DEBUG - 2018-03-25 23:35:29 --> Total execution time: 0.2629
INFO - 2018-03-25 18:35:33 --> Config Class Initialized
INFO - 2018-03-25 18:35:33 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:35:33 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:35:33 --> Utf8 Class Initialized
INFO - 2018-03-25 18:35:33 --> URI Class Initialized
INFO - 2018-03-25 18:35:33 --> Router Class Initialized
INFO - 2018-03-25 18:35:33 --> Output Class Initialized
INFO - 2018-03-25 18:35:33 --> Security Class Initialized
DEBUG - 2018-03-25 18:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:35:33 --> Input Class Initialized
INFO - 2018-03-25 18:35:33 --> Language Class Initialized
INFO - 2018-03-25 18:35:33 --> Loader Class Initialized
INFO - 2018-03-25 18:35:33 --> Helper loaded: url_helper
INFO - 2018-03-25 18:35:33 --> Helper loaded: form_helper
INFO - 2018-03-25 18:35:33 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:35:33 --> Controller Class Initialized
INFO - 2018-03-25 18:35:33 --> Model Class Initialized
INFO - 2018-03-25 18:35:33 --> Model Class Initialized
INFO - 2018-03-25 18:35:33 --> Model Class Initialized
INFO - 2018-03-25 18:35:33 --> Model Class Initialized
INFO - 2018-03-25 18:35:33 --> Model Class Initialized
INFO - 2018-03-25 18:35:33 --> Model Class Initialized
INFO - 2018-03-25 18:35:33 --> Model Class Initialized
INFO - 2018-03-25 18:35:33 --> Model Class Initialized
INFO - 2018-03-25 18:35:33 --> Model Class Initialized
INFO - 2018-03-25 18:35:33 --> Model Class Initialized
INFO - 2018-03-25 18:35:33 --> Model Class Initialized
INFO - 2018-03-25 18:35:33 --> Helper loaded: date_helper
INFO - 2018-03-25 18:35:33 --> Helper loaded: tanggal_helper
ERROR - 2018-03-25 23:35:33 --> Severity: error --> Exception: Call to a member function read() on null E:\xampp\htdocs\skin_care\application\controllers\Kasir\Kasir.php 44
INFO - 2018-03-25 18:35:53 --> Config Class Initialized
INFO - 2018-03-25 18:35:53 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:35:53 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:35:53 --> Utf8 Class Initialized
INFO - 2018-03-25 18:35:53 --> URI Class Initialized
INFO - 2018-03-25 18:35:53 --> Router Class Initialized
INFO - 2018-03-25 18:35:53 --> Output Class Initialized
INFO - 2018-03-25 18:35:53 --> Security Class Initialized
DEBUG - 2018-03-25 18:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:35:53 --> Input Class Initialized
INFO - 2018-03-25 18:35:53 --> Language Class Initialized
INFO - 2018-03-25 18:35:53 --> Loader Class Initialized
INFO - 2018-03-25 18:35:53 --> Helper loaded: url_helper
INFO - 2018-03-25 18:35:53 --> Helper loaded: form_helper
INFO - 2018-03-25 18:35:53 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:35:53 --> Controller Class Initialized
INFO - 2018-03-25 18:35:53 --> Model Class Initialized
INFO - 2018-03-25 18:35:53 --> Model Class Initialized
INFO - 2018-03-25 18:35:53 --> Model Class Initialized
INFO - 2018-03-25 18:35:53 --> Model Class Initialized
INFO - 2018-03-25 18:35:53 --> Model Class Initialized
INFO - 2018-03-25 18:35:53 --> Model Class Initialized
INFO - 2018-03-25 18:35:53 --> Model Class Initialized
INFO - 2018-03-25 18:35:53 --> Model Class Initialized
INFO - 2018-03-25 18:35:53 --> Model Class Initialized
INFO - 2018-03-25 18:35:53 --> Model Class Initialized
INFO - 2018-03-25 18:35:53 --> Model Class Initialized
INFO - 2018-03-25 18:35:53 --> Model Class Initialized
INFO - 2018-03-25 18:35:53 --> Helper loaded: date_helper
INFO - 2018-03-25 18:35:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 23:35:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 23:35:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 23:35:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-25 23:35:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 23:35:53 --> Final output sent to browser
DEBUG - 2018-03-25 23:35:53 --> Total execution time: 0.1283
INFO - 2018-03-25 18:36:29 --> Config Class Initialized
INFO - 2018-03-25 18:36:29 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:36:29 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:36:29 --> Utf8 Class Initialized
INFO - 2018-03-25 18:36:29 --> URI Class Initialized
INFO - 2018-03-25 18:36:29 --> Router Class Initialized
INFO - 2018-03-25 18:36:29 --> Output Class Initialized
INFO - 2018-03-25 18:36:29 --> Security Class Initialized
DEBUG - 2018-03-25 18:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:36:29 --> Input Class Initialized
INFO - 2018-03-25 18:36:29 --> Language Class Initialized
INFO - 2018-03-25 18:36:29 --> Loader Class Initialized
INFO - 2018-03-25 18:36:29 --> Helper loaded: url_helper
INFO - 2018-03-25 18:36:29 --> Helper loaded: form_helper
INFO - 2018-03-25 18:36:29 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:36:29 --> Controller Class Initialized
INFO - 2018-03-25 18:36:29 --> Model Class Initialized
INFO - 2018-03-25 18:36:29 --> Model Class Initialized
INFO - 2018-03-25 18:36:29 --> Model Class Initialized
INFO - 2018-03-25 18:36:29 --> Model Class Initialized
INFO - 2018-03-25 18:36:29 --> Model Class Initialized
INFO - 2018-03-25 18:36:29 --> Model Class Initialized
INFO - 2018-03-25 18:36:29 --> Model Class Initialized
INFO - 2018-03-25 18:36:29 --> Model Class Initialized
INFO - 2018-03-25 18:36:29 --> Model Class Initialized
INFO - 2018-03-25 18:36:29 --> Model Class Initialized
INFO - 2018-03-25 18:36:29 --> Model Class Initialized
INFO - 2018-03-25 18:36:29 --> Model Class Initialized
INFO - 2018-03-25 18:36:29 --> Helper loaded: date_helper
INFO - 2018-03-25 18:36:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 23:36:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 23:36:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 23:36:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-25 23:36:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 23:36:29 --> Final output sent to browser
DEBUG - 2018-03-25 23:36:29 --> Total execution time: 0.1690
INFO - 2018-03-25 18:41:15 --> Config Class Initialized
INFO - 2018-03-25 18:41:15 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:41:15 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:41:15 --> Utf8 Class Initialized
INFO - 2018-03-25 18:41:15 --> URI Class Initialized
INFO - 2018-03-25 18:41:15 --> Router Class Initialized
INFO - 2018-03-25 18:41:15 --> Output Class Initialized
INFO - 2018-03-25 18:41:15 --> Security Class Initialized
DEBUG - 2018-03-25 18:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:41:15 --> Input Class Initialized
INFO - 2018-03-25 18:41:15 --> Language Class Initialized
INFO - 2018-03-25 18:41:15 --> Loader Class Initialized
INFO - 2018-03-25 18:41:15 --> Helper loaded: url_helper
INFO - 2018-03-25 18:41:15 --> Helper loaded: form_helper
INFO - 2018-03-25 18:41:15 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:41:16 --> Controller Class Initialized
INFO - 2018-03-25 18:41:16 --> Model Class Initialized
INFO - 2018-03-25 18:41:16 --> Model Class Initialized
INFO - 2018-03-25 18:41:16 --> Model Class Initialized
INFO - 2018-03-25 18:41:16 --> Model Class Initialized
INFO - 2018-03-25 18:41:16 --> Model Class Initialized
INFO - 2018-03-25 18:41:16 --> Model Class Initialized
INFO - 2018-03-25 18:41:16 --> Model Class Initialized
INFO - 2018-03-25 18:41:16 --> Model Class Initialized
INFO - 2018-03-25 18:41:16 --> Model Class Initialized
INFO - 2018-03-25 18:41:16 --> Model Class Initialized
INFO - 2018-03-25 18:41:16 --> Model Class Initialized
INFO - 2018-03-25 18:41:16 --> Model Class Initialized
INFO - 2018-03-25 18:41:16 --> Helper loaded: date_helper
INFO - 2018-03-25 18:41:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 23:41:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 23:41:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 23:41:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-25 23:41:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 23:41:16 --> Final output sent to browser
DEBUG - 2018-03-25 23:41:16 --> Total execution time: 0.1264
INFO - 2018-03-25 18:41:24 --> Config Class Initialized
INFO - 2018-03-25 18:41:24 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:41:24 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:41:24 --> Utf8 Class Initialized
INFO - 2018-03-25 18:41:24 --> URI Class Initialized
INFO - 2018-03-25 18:41:24 --> Router Class Initialized
INFO - 2018-03-25 18:41:24 --> Output Class Initialized
INFO - 2018-03-25 18:41:24 --> Security Class Initialized
DEBUG - 2018-03-25 18:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:41:24 --> Input Class Initialized
INFO - 2018-03-25 18:41:24 --> Language Class Initialized
INFO - 2018-03-25 18:41:25 --> Loader Class Initialized
INFO - 2018-03-25 18:41:25 --> Helper loaded: url_helper
INFO - 2018-03-25 18:41:25 --> Helper loaded: form_helper
INFO - 2018-03-25 18:41:25 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:41:25 --> Controller Class Initialized
INFO - 2018-03-25 18:41:25 --> Model Class Initialized
INFO - 2018-03-25 18:41:25 --> Model Class Initialized
INFO - 2018-03-25 18:41:25 --> Model Class Initialized
INFO - 2018-03-25 18:41:25 --> Model Class Initialized
INFO - 2018-03-25 18:41:25 --> Model Class Initialized
INFO - 2018-03-25 18:41:25 --> Model Class Initialized
INFO - 2018-03-25 18:41:25 --> Model Class Initialized
INFO - 2018-03-25 18:41:25 --> Model Class Initialized
INFO - 2018-03-25 18:41:25 --> Model Class Initialized
INFO - 2018-03-25 18:41:25 --> Model Class Initialized
INFO - 2018-03-25 18:41:25 --> Helper loaded: date_helper
INFO - 2018-03-25 18:41:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 23:41:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 23:41:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 23:41:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/detail.php
INFO - 2018-03-25 23:41:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 23:41:25 --> Final output sent to browser
DEBUG - 2018-03-25 23:41:25 --> Total execution time: 0.3663
INFO - 2018-03-25 18:41:27 --> Config Class Initialized
INFO - 2018-03-25 18:41:27 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:41:27 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:41:27 --> Utf8 Class Initialized
INFO - 2018-03-25 18:41:27 --> URI Class Initialized
INFO - 2018-03-25 18:41:27 --> Router Class Initialized
INFO - 2018-03-25 18:41:27 --> Output Class Initialized
INFO - 2018-03-25 18:41:27 --> Security Class Initialized
DEBUG - 2018-03-25 18:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:41:27 --> Input Class Initialized
INFO - 2018-03-25 18:41:27 --> Language Class Initialized
INFO - 2018-03-25 18:41:27 --> Loader Class Initialized
INFO - 2018-03-25 18:41:27 --> Helper loaded: url_helper
INFO - 2018-03-25 18:41:27 --> Helper loaded: form_helper
INFO - 2018-03-25 18:41:27 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:41:27 --> Controller Class Initialized
INFO - 2018-03-25 18:41:27 --> Model Class Initialized
INFO - 2018-03-25 18:41:27 --> Model Class Initialized
INFO - 2018-03-25 18:41:27 --> Model Class Initialized
INFO - 2018-03-25 18:41:27 --> Model Class Initialized
INFO - 2018-03-25 18:41:27 --> Model Class Initialized
INFO - 2018-03-25 18:41:27 --> Model Class Initialized
INFO - 2018-03-25 18:41:27 --> Model Class Initialized
INFO - 2018-03-25 18:41:27 --> Model Class Initialized
INFO - 2018-03-25 18:41:27 --> Model Class Initialized
INFO - 2018-03-25 18:41:27 --> Model Class Initialized
INFO - 2018-03-25 18:41:27 --> Model Class Initialized
INFO - 2018-03-25 18:41:27 --> Model Class Initialized
INFO - 2018-03-25 18:41:27 --> Helper loaded: date_helper
INFO - 2018-03-25 18:41:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 23:41:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 23:41:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 23:41:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-25 23:41:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 23:41:27 --> Final output sent to browser
DEBUG - 2018-03-25 23:41:27 --> Total execution time: 0.1875
INFO - 2018-03-25 18:43:26 --> Config Class Initialized
INFO - 2018-03-25 18:43:26 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:43:26 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:43:26 --> Utf8 Class Initialized
INFO - 2018-03-25 18:43:26 --> URI Class Initialized
INFO - 2018-03-25 18:43:26 --> Router Class Initialized
INFO - 2018-03-25 18:43:26 --> Output Class Initialized
INFO - 2018-03-25 18:43:26 --> Security Class Initialized
DEBUG - 2018-03-25 18:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:43:26 --> Input Class Initialized
INFO - 2018-03-25 18:43:26 --> Language Class Initialized
INFO - 2018-03-25 18:43:26 --> Loader Class Initialized
INFO - 2018-03-25 18:43:26 --> Helper loaded: url_helper
INFO - 2018-03-25 18:43:26 --> Helper loaded: form_helper
INFO - 2018-03-25 18:43:26 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:43:26 --> Controller Class Initialized
INFO - 2018-03-25 18:43:26 --> Model Class Initialized
INFO - 2018-03-25 18:43:26 --> Model Class Initialized
INFO - 2018-03-25 18:43:26 --> Model Class Initialized
INFO - 2018-03-25 18:43:26 --> Model Class Initialized
INFO - 2018-03-25 18:43:26 --> Model Class Initialized
INFO - 2018-03-25 18:43:26 --> Model Class Initialized
INFO - 2018-03-25 18:43:26 --> Model Class Initialized
INFO - 2018-03-25 18:43:26 --> Model Class Initialized
INFO - 2018-03-25 18:43:26 --> Model Class Initialized
INFO - 2018-03-25 18:43:26 --> Model Class Initialized
INFO - 2018-03-25 18:43:26 --> Model Class Initialized
INFO - 2018-03-25 18:43:26 --> Model Class Initialized
INFO - 2018-03-25 18:43:26 --> Helper loaded: date_helper
INFO - 2018-03-25 18:43:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 23:43:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 23:43:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 23:43:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-25 23:43:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 23:43:26 --> Final output sent to browser
DEBUG - 2018-03-25 23:43:26 --> Total execution time: 0.1425
INFO - 2018-03-25 18:45:27 --> Config Class Initialized
INFO - 2018-03-25 18:45:27 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:45:27 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:45:27 --> Utf8 Class Initialized
INFO - 2018-03-25 18:45:27 --> URI Class Initialized
INFO - 2018-03-25 18:45:27 --> Router Class Initialized
INFO - 2018-03-25 18:45:27 --> Output Class Initialized
INFO - 2018-03-25 18:45:27 --> Security Class Initialized
DEBUG - 2018-03-25 18:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:45:27 --> Input Class Initialized
INFO - 2018-03-25 18:45:27 --> Language Class Initialized
INFO - 2018-03-25 18:45:27 --> Loader Class Initialized
INFO - 2018-03-25 18:45:27 --> Helper loaded: url_helper
INFO - 2018-03-25 18:45:27 --> Helper loaded: form_helper
INFO - 2018-03-25 18:45:27 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:45:27 --> Controller Class Initialized
INFO - 2018-03-25 18:45:27 --> Model Class Initialized
INFO - 2018-03-25 18:45:27 --> Model Class Initialized
INFO - 2018-03-25 18:45:27 --> Model Class Initialized
INFO - 2018-03-25 18:45:27 --> Model Class Initialized
INFO - 2018-03-25 18:45:27 --> Model Class Initialized
INFO - 2018-03-25 18:45:27 --> Model Class Initialized
INFO - 2018-03-25 18:45:27 --> Model Class Initialized
INFO - 2018-03-25 18:45:27 --> Model Class Initialized
INFO - 2018-03-25 18:45:27 --> Model Class Initialized
INFO - 2018-03-25 18:45:27 --> Model Class Initialized
INFO - 2018-03-25 18:45:27 --> Model Class Initialized
INFO - 2018-03-25 18:45:27 --> Model Class Initialized
INFO - 2018-03-25 18:45:27 --> Helper loaded: date_helper
INFO - 2018-03-25 18:45:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 23:45:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 23:45:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 23:45:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-25 23:45:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 23:45:27 --> Final output sent to browser
DEBUG - 2018-03-25 23:45:27 --> Total execution time: 0.1123
INFO - 2018-03-25 18:46:13 --> Config Class Initialized
INFO - 2018-03-25 18:46:13 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:46:13 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:46:13 --> Utf8 Class Initialized
INFO - 2018-03-25 18:46:13 --> URI Class Initialized
INFO - 2018-03-25 18:46:13 --> Router Class Initialized
INFO - 2018-03-25 18:46:13 --> Output Class Initialized
INFO - 2018-03-25 18:46:13 --> Security Class Initialized
DEBUG - 2018-03-25 18:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:46:13 --> Input Class Initialized
INFO - 2018-03-25 18:46:13 --> Language Class Initialized
INFO - 2018-03-25 18:46:13 --> Loader Class Initialized
INFO - 2018-03-25 18:46:13 --> Helper loaded: url_helper
INFO - 2018-03-25 18:46:13 --> Helper loaded: form_helper
INFO - 2018-03-25 18:46:13 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:46:13 --> Controller Class Initialized
INFO - 2018-03-25 18:46:13 --> Model Class Initialized
INFO - 2018-03-25 18:46:13 --> Model Class Initialized
INFO - 2018-03-25 18:46:13 --> Model Class Initialized
INFO - 2018-03-25 18:46:13 --> Model Class Initialized
INFO - 2018-03-25 18:46:13 --> Model Class Initialized
INFO - 2018-03-25 18:46:13 --> Model Class Initialized
INFO - 2018-03-25 18:46:13 --> Model Class Initialized
INFO - 2018-03-25 18:46:13 --> Model Class Initialized
INFO - 2018-03-25 18:46:13 --> Model Class Initialized
INFO - 2018-03-25 18:46:13 --> Model Class Initialized
INFO - 2018-03-25 18:46:13 --> Model Class Initialized
INFO - 2018-03-25 18:46:13 --> Model Class Initialized
INFO - 2018-03-25 18:46:13 --> Helper loaded: date_helper
INFO - 2018-03-25 18:46:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 23:46:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 23:46:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 23:46:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-25 23:46:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 23:46:13 --> Final output sent to browser
DEBUG - 2018-03-25 23:46:13 --> Total execution time: 0.1724
INFO - 2018-03-25 18:58:41 --> Config Class Initialized
INFO - 2018-03-25 18:58:41 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:58:41 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:58:41 --> Utf8 Class Initialized
INFO - 2018-03-25 18:58:41 --> URI Class Initialized
INFO - 2018-03-25 18:58:41 --> Router Class Initialized
INFO - 2018-03-25 18:58:41 --> Output Class Initialized
INFO - 2018-03-25 18:58:41 --> Security Class Initialized
DEBUG - 2018-03-25 18:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:58:41 --> Input Class Initialized
INFO - 2018-03-25 18:58:41 --> Language Class Initialized
INFO - 2018-03-25 18:58:41 --> Loader Class Initialized
INFO - 2018-03-25 18:58:41 --> Helper loaded: url_helper
INFO - 2018-03-25 18:58:41 --> Helper loaded: form_helper
INFO - 2018-03-25 18:58:41 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:58:41 --> Controller Class Initialized
INFO - 2018-03-25 18:58:41 --> Model Class Initialized
INFO - 2018-03-25 18:58:41 --> Model Class Initialized
INFO - 2018-03-25 18:58:41 --> Model Class Initialized
INFO - 2018-03-25 18:58:41 --> Model Class Initialized
INFO - 2018-03-25 18:58:41 --> Model Class Initialized
INFO - 2018-03-25 18:58:41 --> Model Class Initialized
INFO - 2018-03-25 18:58:41 --> Model Class Initialized
INFO - 2018-03-25 18:58:41 --> Model Class Initialized
INFO - 2018-03-25 18:58:41 --> Model Class Initialized
INFO - 2018-03-25 18:58:41 --> Model Class Initialized
INFO - 2018-03-25 18:58:41 --> Model Class Initialized
INFO - 2018-03-25 18:58:41 --> Model Class Initialized
INFO - 2018-03-25 18:58:41 --> Helper loaded: date_helper
INFO - 2018-03-25 18:58:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 23:58:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 23:58:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 23:58:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-25 23:58:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 23:58:41 --> Final output sent to browser
DEBUG - 2018-03-25 23:58:41 --> Total execution time: 0.1267
INFO - 2018-03-25 18:59:11 --> Config Class Initialized
INFO - 2018-03-25 18:59:11 --> Hooks Class Initialized
DEBUG - 2018-03-25 18:59:11 --> UTF-8 Support Enabled
INFO - 2018-03-25 18:59:11 --> Utf8 Class Initialized
INFO - 2018-03-25 18:59:11 --> URI Class Initialized
INFO - 2018-03-25 18:59:11 --> Router Class Initialized
INFO - 2018-03-25 18:59:11 --> Output Class Initialized
INFO - 2018-03-25 18:59:11 --> Security Class Initialized
DEBUG - 2018-03-25 18:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 18:59:11 --> Input Class Initialized
INFO - 2018-03-25 18:59:11 --> Language Class Initialized
INFO - 2018-03-25 18:59:11 --> Loader Class Initialized
INFO - 2018-03-25 18:59:11 --> Helper loaded: url_helper
INFO - 2018-03-25 18:59:11 --> Helper loaded: form_helper
INFO - 2018-03-25 18:59:11 --> Database Driver Class Initialized
DEBUG - 2018-03-25 18:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 18:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 18:59:11 --> Controller Class Initialized
INFO - 2018-03-25 18:59:11 --> Model Class Initialized
INFO - 2018-03-25 18:59:11 --> Model Class Initialized
INFO - 2018-03-25 18:59:11 --> Model Class Initialized
INFO - 2018-03-25 18:59:11 --> Model Class Initialized
INFO - 2018-03-25 18:59:11 --> Model Class Initialized
INFO - 2018-03-25 18:59:11 --> Model Class Initialized
INFO - 2018-03-25 18:59:11 --> Model Class Initialized
INFO - 2018-03-25 18:59:11 --> Model Class Initialized
INFO - 2018-03-25 18:59:11 --> Model Class Initialized
INFO - 2018-03-25 18:59:11 --> Model Class Initialized
INFO - 2018-03-25 18:59:11 --> Model Class Initialized
INFO - 2018-03-25 18:59:11 --> Model Class Initialized
INFO - 2018-03-25 18:59:11 --> Helper loaded: date_helper
INFO - 2018-03-25 18:59:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 23:59:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-25 23:59:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-25 23:59:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-25 23:59:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-25 23:59:11 --> Final output sent to browser
DEBUG - 2018-03-25 23:59:11 --> Total execution time: 0.1151
INFO - 2018-03-25 19:00:22 --> Config Class Initialized
INFO - 2018-03-25 19:00:22 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:00:22 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:00:22 --> Utf8 Class Initialized
INFO - 2018-03-25 19:00:22 --> URI Class Initialized
INFO - 2018-03-25 19:00:22 --> Router Class Initialized
INFO - 2018-03-25 19:00:22 --> Output Class Initialized
INFO - 2018-03-25 19:00:22 --> Security Class Initialized
DEBUG - 2018-03-25 19:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:00:22 --> Input Class Initialized
INFO - 2018-03-25 19:00:22 --> Language Class Initialized
INFO - 2018-03-25 19:00:22 --> Loader Class Initialized
INFO - 2018-03-25 19:00:22 --> Helper loaded: url_helper
INFO - 2018-03-25 19:00:22 --> Helper loaded: form_helper
INFO - 2018-03-25 19:00:22 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:00:22 --> Controller Class Initialized
INFO - 2018-03-25 19:00:22 --> Model Class Initialized
INFO - 2018-03-25 19:00:22 --> Model Class Initialized
INFO - 2018-03-25 19:00:22 --> Model Class Initialized
INFO - 2018-03-25 19:00:22 --> Model Class Initialized
INFO - 2018-03-25 19:00:22 --> Model Class Initialized
INFO - 2018-03-25 19:00:22 --> Model Class Initialized
INFO - 2018-03-25 19:00:22 --> Model Class Initialized
INFO - 2018-03-25 19:00:22 --> Model Class Initialized
INFO - 2018-03-25 19:00:22 --> Model Class Initialized
INFO - 2018-03-25 19:00:22 --> Model Class Initialized
INFO - 2018-03-25 19:00:22 --> Model Class Initialized
INFO - 2018-03-25 19:00:22 --> Model Class Initialized
INFO - 2018-03-25 19:00:22 --> Helper loaded: date_helper
INFO - 2018-03-25 19:00:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:00:48 --> Config Class Initialized
INFO - 2018-03-25 19:00:48 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:00:48 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:00:48 --> Utf8 Class Initialized
INFO - 2018-03-25 19:00:48 --> URI Class Initialized
INFO - 2018-03-25 19:00:48 --> Router Class Initialized
INFO - 2018-03-25 19:00:48 --> Output Class Initialized
INFO - 2018-03-25 19:00:48 --> Security Class Initialized
DEBUG - 2018-03-25 19:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:00:48 --> Input Class Initialized
INFO - 2018-03-25 19:00:48 --> Language Class Initialized
INFO - 2018-03-25 19:00:48 --> Loader Class Initialized
INFO - 2018-03-25 19:00:48 --> Helper loaded: url_helper
INFO - 2018-03-25 19:00:48 --> Helper loaded: form_helper
INFO - 2018-03-25 19:00:48 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:00:48 --> Controller Class Initialized
INFO - 2018-03-25 19:00:48 --> Model Class Initialized
INFO - 2018-03-25 19:00:48 --> Model Class Initialized
INFO - 2018-03-25 19:00:48 --> Model Class Initialized
INFO - 2018-03-25 19:00:48 --> Model Class Initialized
INFO - 2018-03-25 19:00:48 --> Model Class Initialized
INFO - 2018-03-25 19:00:48 --> Model Class Initialized
INFO - 2018-03-25 19:00:48 --> Model Class Initialized
INFO - 2018-03-25 19:00:48 --> Model Class Initialized
INFO - 2018-03-25 19:00:48 --> Model Class Initialized
INFO - 2018-03-25 19:00:48 --> Model Class Initialized
INFO - 2018-03-25 19:00:48 --> Model Class Initialized
INFO - 2018-03-25 19:00:48 --> Model Class Initialized
INFO - 2018-03-25 19:00:48 --> Model Class Initialized
INFO - 2018-03-25 19:00:48 --> Model Class Initialized
INFO - 2018-03-25 19:00:48 --> Helper loaded: date_helper
INFO - 2018-03-25 19:00:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:00:50 --> Config Class Initialized
INFO - 2018-03-25 19:00:50 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:00:50 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:00:50 --> Utf8 Class Initialized
INFO - 2018-03-25 19:00:50 --> URI Class Initialized
INFO - 2018-03-25 19:00:50 --> Router Class Initialized
INFO - 2018-03-25 19:00:50 --> Output Class Initialized
INFO - 2018-03-25 19:00:50 --> Security Class Initialized
DEBUG - 2018-03-25 19:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:00:50 --> Input Class Initialized
INFO - 2018-03-25 19:00:50 --> Language Class Initialized
INFO - 2018-03-25 19:00:50 --> Loader Class Initialized
INFO - 2018-03-25 19:00:50 --> Helper loaded: url_helper
INFO - 2018-03-25 19:00:50 --> Helper loaded: form_helper
INFO - 2018-03-25 19:00:50 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:00:50 --> Controller Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Helper loaded: date_helper
INFO - 2018-03-25 19:00:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:00:50 --> Config Class Initialized
INFO - 2018-03-25 19:00:50 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:00:50 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:00:50 --> Utf8 Class Initialized
INFO - 2018-03-25 19:00:50 --> URI Class Initialized
INFO - 2018-03-25 19:00:50 --> Router Class Initialized
INFO - 2018-03-25 19:00:50 --> Output Class Initialized
INFO - 2018-03-25 19:00:50 --> Security Class Initialized
DEBUG - 2018-03-25 19:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:00:50 --> Input Class Initialized
INFO - 2018-03-25 19:00:50 --> Language Class Initialized
INFO - 2018-03-25 19:00:50 --> Loader Class Initialized
INFO - 2018-03-25 19:00:50 --> Helper loaded: url_helper
INFO - 2018-03-25 19:00:50 --> Helper loaded: form_helper
INFO - 2018-03-25 19:00:50 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:00:50 --> Controller Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Model Class Initialized
INFO - 2018-03-25 19:00:50 --> Helper loaded: date_helper
INFO - 2018-03-25 19:00:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:00:56 --> Config Class Initialized
INFO - 2018-03-25 19:00:56 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:00:56 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:00:56 --> Utf8 Class Initialized
INFO - 2018-03-25 19:00:56 --> URI Class Initialized
INFO - 2018-03-25 19:00:56 --> Router Class Initialized
INFO - 2018-03-25 19:00:56 --> Output Class Initialized
INFO - 2018-03-25 19:00:56 --> Security Class Initialized
DEBUG - 2018-03-25 19:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:00:56 --> Input Class Initialized
INFO - 2018-03-25 19:00:56 --> Language Class Initialized
INFO - 2018-03-25 19:00:56 --> Loader Class Initialized
INFO - 2018-03-25 19:00:56 --> Helper loaded: url_helper
INFO - 2018-03-25 19:00:56 --> Helper loaded: form_helper
INFO - 2018-03-25 19:00:56 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:00:56 --> Controller Class Initialized
INFO - 2018-03-25 19:00:56 --> Model Class Initialized
INFO - 2018-03-25 19:00:56 --> Model Class Initialized
INFO - 2018-03-25 19:00:56 --> Model Class Initialized
INFO - 2018-03-25 19:00:56 --> Model Class Initialized
INFO - 2018-03-25 19:00:56 --> Model Class Initialized
INFO - 2018-03-25 19:00:56 --> Model Class Initialized
INFO - 2018-03-25 19:00:56 --> Model Class Initialized
INFO - 2018-03-25 19:00:56 --> Model Class Initialized
INFO - 2018-03-25 19:00:56 --> Model Class Initialized
INFO - 2018-03-25 19:00:56 --> Model Class Initialized
INFO - 2018-03-25 19:00:56 --> Model Class Initialized
INFO - 2018-03-25 19:00:56 --> Model Class Initialized
INFO - 2018-03-25 19:00:56 --> Helper loaded: date_helper
INFO - 2018-03-25 19:00:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:03:21 --> Config Class Initialized
INFO - 2018-03-25 19:03:21 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:03:21 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:03:21 --> Utf8 Class Initialized
INFO - 2018-03-25 19:03:21 --> URI Class Initialized
INFO - 2018-03-25 19:03:21 --> Router Class Initialized
INFO - 2018-03-25 19:03:21 --> Output Class Initialized
INFO - 2018-03-25 19:03:21 --> Security Class Initialized
DEBUG - 2018-03-25 19:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:03:21 --> Input Class Initialized
INFO - 2018-03-25 19:03:21 --> Language Class Initialized
INFO - 2018-03-25 19:03:21 --> Loader Class Initialized
INFO - 2018-03-25 19:03:21 --> Helper loaded: url_helper
INFO - 2018-03-25 19:03:21 --> Helper loaded: form_helper
INFO - 2018-03-25 19:03:21 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:03:21 --> Controller Class Initialized
INFO - 2018-03-25 19:03:21 --> Model Class Initialized
INFO - 2018-03-25 19:03:21 --> Model Class Initialized
INFO - 2018-03-25 19:03:21 --> Model Class Initialized
INFO - 2018-03-25 19:03:21 --> Model Class Initialized
INFO - 2018-03-25 19:03:21 --> Model Class Initialized
INFO - 2018-03-25 19:03:21 --> Model Class Initialized
INFO - 2018-03-25 19:03:21 --> Model Class Initialized
INFO - 2018-03-25 19:03:21 --> Model Class Initialized
INFO - 2018-03-25 19:03:21 --> Model Class Initialized
INFO - 2018-03-25 19:03:21 --> Model Class Initialized
INFO - 2018-03-25 19:03:21 --> Model Class Initialized
INFO - 2018-03-25 19:03:21 --> Model Class Initialized
INFO - 2018-03-25 19:03:21 --> Helper loaded: date_helper
INFO - 2018-03-25 19:03:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:06:49 --> Config Class Initialized
INFO - 2018-03-25 19:06:49 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:06:49 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:06:49 --> Utf8 Class Initialized
INFO - 2018-03-25 19:06:49 --> URI Class Initialized
INFO - 2018-03-25 19:06:49 --> Router Class Initialized
INFO - 2018-03-25 19:06:49 --> Output Class Initialized
INFO - 2018-03-25 19:06:49 --> Security Class Initialized
DEBUG - 2018-03-25 19:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:06:49 --> Input Class Initialized
INFO - 2018-03-25 19:06:49 --> Language Class Initialized
INFO - 2018-03-25 19:06:49 --> Loader Class Initialized
INFO - 2018-03-25 19:06:49 --> Helper loaded: url_helper
INFO - 2018-03-25 19:06:49 --> Helper loaded: form_helper
INFO - 2018-03-25 19:06:49 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:06:49 --> Controller Class Initialized
INFO - 2018-03-25 19:06:49 --> Model Class Initialized
INFO - 2018-03-25 19:06:49 --> Model Class Initialized
INFO - 2018-03-25 19:06:49 --> Model Class Initialized
INFO - 2018-03-25 19:06:49 --> Model Class Initialized
INFO - 2018-03-25 19:06:49 --> Model Class Initialized
INFO - 2018-03-25 19:06:49 --> Model Class Initialized
INFO - 2018-03-25 19:06:49 --> Model Class Initialized
INFO - 2018-03-25 19:06:49 --> Model Class Initialized
INFO - 2018-03-25 19:06:49 --> Model Class Initialized
INFO - 2018-03-25 19:06:49 --> Model Class Initialized
INFO - 2018-03-25 19:06:49 --> Model Class Initialized
INFO - 2018-03-25 19:06:49 --> Model Class Initialized
INFO - 2018-03-25 19:06:49 --> Helper loaded: date_helper
INFO - 2018-03-25 19:06:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:07:04 --> Config Class Initialized
INFO - 2018-03-25 19:07:04 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:07:04 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:07:04 --> Utf8 Class Initialized
INFO - 2018-03-25 19:07:04 --> URI Class Initialized
INFO - 2018-03-25 19:07:04 --> Router Class Initialized
INFO - 2018-03-25 19:07:04 --> Output Class Initialized
INFO - 2018-03-25 19:07:04 --> Security Class Initialized
DEBUG - 2018-03-25 19:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:07:04 --> Input Class Initialized
INFO - 2018-03-25 19:07:04 --> Language Class Initialized
INFO - 2018-03-25 19:07:04 --> Loader Class Initialized
INFO - 2018-03-25 19:07:04 --> Helper loaded: url_helper
INFO - 2018-03-25 19:07:04 --> Helper loaded: form_helper
INFO - 2018-03-25 19:07:04 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:07:04 --> Controller Class Initialized
INFO - 2018-03-25 19:07:04 --> Model Class Initialized
INFO - 2018-03-25 19:07:04 --> Model Class Initialized
INFO - 2018-03-25 19:07:04 --> Model Class Initialized
INFO - 2018-03-25 19:07:04 --> Model Class Initialized
INFO - 2018-03-25 19:07:04 --> Model Class Initialized
INFO - 2018-03-25 19:07:04 --> Model Class Initialized
INFO - 2018-03-25 19:07:04 --> Model Class Initialized
INFO - 2018-03-25 19:07:04 --> Model Class Initialized
INFO - 2018-03-25 19:07:04 --> Model Class Initialized
INFO - 2018-03-25 19:07:04 --> Model Class Initialized
INFO - 2018-03-25 19:07:04 --> Model Class Initialized
INFO - 2018-03-25 19:07:04 --> Model Class Initialized
INFO - 2018-03-25 19:07:04 --> Helper loaded: date_helper
INFO - 2018-03-25 19:07:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:07:13 --> Config Class Initialized
INFO - 2018-03-25 19:07:13 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:07:13 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:07:13 --> Utf8 Class Initialized
INFO - 2018-03-25 19:07:13 --> URI Class Initialized
INFO - 2018-03-25 19:07:13 --> Router Class Initialized
INFO - 2018-03-25 19:07:13 --> Output Class Initialized
INFO - 2018-03-25 19:07:13 --> Security Class Initialized
DEBUG - 2018-03-25 19:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:07:13 --> Input Class Initialized
INFO - 2018-03-25 19:07:13 --> Language Class Initialized
INFO - 2018-03-25 19:07:13 --> Loader Class Initialized
INFO - 2018-03-25 19:07:13 --> Helper loaded: url_helper
INFO - 2018-03-25 19:07:13 --> Helper loaded: form_helper
INFO - 2018-03-25 19:07:13 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:07:13 --> Controller Class Initialized
INFO - 2018-03-25 19:07:13 --> Model Class Initialized
INFO - 2018-03-25 19:07:13 --> Model Class Initialized
INFO - 2018-03-25 19:07:13 --> Model Class Initialized
INFO - 2018-03-25 19:07:13 --> Model Class Initialized
INFO - 2018-03-25 19:07:13 --> Model Class Initialized
INFO - 2018-03-25 19:07:13 --> Model Class Initialized
INFO - 2018-03-25 19:07:13 --> Model Class Initialized
INFO - 2018-03-25 19:07:13 --> Model Class Initialized
INFO - 2018-03-25 19:07:13 --> Model Class Initialized
INFO - 2018-03-25 19:07:13 --> Model Class Initialized
INFO - 2018-03-25 19:07:13 --> Model Class Initialized
INFO - 2018-03-25 19:07:13 --> Model Class Initialized
INFO - 2018-03-25 19:07:13 --> Helper loaded: date_helper
INFO - 2018-03-25 19:07:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:07:23 --> Config Class Initialized
INFO - 2018-03-25 19:07:23 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:07:23 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:07:23 --> Utf8 Class Initialized
INFO - 2018-03-25 19:07:23 --> URI Class Initialized
INFO - 2018-03-25 19:07:23 --> Router Class Initialized
INFO - 2018-03-25 19:07:23 --> Output Class Initialized
INFO - 2018-03-25 19:07:23 --> Security Class Initialized
DEBUG - 2018-03-25 19:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:07:23 --> Input Class Initialized
INFO - 2018-03-25 19:07:23 --> Language Class Initialized
INFO - 2018-03-25 19:07:23 --> Loader Class Initialized
INFO - 2018-03-25 19:07:23 --> Helper loaded: url_helper
INFO - 2018-03-25 19:07:23 --> Helper loaded: form_helper
INFO - 2018-03-25 19:07:23 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:07:23 --> Controller Class Initialized
INFO - 2018-03-25 19:07:23 --> Model Class Initialized
INFO - 2018-03-25 19:07:23 --> Model Class Initialized
INFO - 2018-03-25 19:07:23 --> Model Class Initialized
INFO - 2018-03-25 19:07:23 --> Model Class Initialized
INFO - 2018-03-25 19:07:23 --> Model Class Initialized
INFO - 2018-03-25 19:07:23 --> Model Class Initialized
INFO - 2018-03-25 19:07:23 --> Model Class Initialized
INFO - 2018-03-25 19:07:23 --> Model Class Initialized
INFO - 2018-03-25 19:07:23 --> Model Class Initialized
INFO - 2018-03-25 19:07:23 --> Model Class Initialized
INFO - 2018-03-25 19:07:23 --> Model Class Initialized
INFO - 2018-03-25 19:07:23 --> Model Class Initialized
INFO - 2018-03-25 19:07:23 --> Helper loaded: date_helper
INFO - 2018-03-25 19:07:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:08:08 --> Config Class Initialized
INFO - 2018-03-25 19:08:08 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:08:08 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:08:08 --> Utf8 Class Initialized
INFO - 2018-03-25 19:08:08 --> URI Class Initialized
INFO - 2018-03-25 19:08:08 --> Router Class Initialized
INFO - 2018-03-25 19:08:08 --> Output Class Initialized
INFO - 2018-03-25 19:08:08 --> Security Class Initialized
DEBUG - 2018-03-25 19:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:08:08 --> Input Class Initialized
INFO - 2018-03-25 19:08:08 --> Language Class Initialized
INFO - 2018-03-25 19:08:08 --> Loader Class Initialized
INFO - 2018-03-25 19:08:08 --> Helper loaded: url_helper
INFO - 2018-03-25 19:08:08 --> Helper loaded: form_helper
INFO - 2018-03-25 19:08:08 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:08:08 --> Controller Class Initialized
INFO - 2018-03-25 19:08:08 --> Model Class Initialized
INFO - 2018-03-25 19:08:08 --> Model Class Initialized
INFO - 2018-03-25 19:08:08 --> Model Class Initialized
INFO - 2018-03-25 19:08:08 --> Model Class Initialized
INFO - 2018-03-25 19:08:08 --> Model Class Initialized
INFO - 2018-03-25 19:08:08 --> Model Class Initialized
INFO - 2018-03-25 19:08:08 --> Model Class Initialized
INFO - 2018-03-25 19:08:08 --> Model Class Initialized
INFO - 2018-03-25 19:08:08 --> Model Class Initialized
INFO - 2018-03-25 19:08:08 --> Model Class Initialized
INFO - 2018-03-25 19:08:08 --> Model Class Initialized
INFO - 2018-03-25 19:08:08 --> Model Class Initialized
INFO - 2018-03-25 19:08:08 --> Helper loaded: date_helper
INFO - 2018-03-25 19:08:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:11:22 --> Config Class Initialized
INFO - 2018-03-25 19:11:22 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:11:22 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:11:22 --> Utf8 Class Initialized
INFO - 2018-03-25 19:11:22 --> URI Class Initialized
INFO - 2018-03-25 19:11:22 --> Router Class Initialized
INFO - 2018-03-25 19:11:22 --> Output Class Initialized
INFO - 2018-03-25 19:11:22 --> Security Class Initialized
DEBUG - 2018-03-25 19:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:11:22 --> Input Class Initialized
INFO - 2018-03-25 19:11:22 --> Language Class Initialized
INFO - 2018-03-25 19:11:22 --> Loader Class Initialized
INFO - 2018-03-25 19:11:22 --> Helper loaded: url_helper
INFO - 2018-03-25 19:11:22 --> Helper loaded: form_helper
INFO - 2018-03-25 19:11:22 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:11:22 --> Controller Class Initialized
INFO - 2018-03-25 19:11:22 --> Model Class Initialized
INFO - 2018-03-25 19:11:22 --> Model Class Initialized
INFO - 2018-03-25 19:11:22 --> Model Class Initialized
INFO - 2018-03-25 19:11:22 --> Model Class Initialized
INFO - 2018-03-25 19:11:22 --> Model Class Initialized
INFO - 2018-03-25 19:11:22 --> Model Class Initialized
INFO - 2018-03-25 19:11:22 --> Model Class Initialized
INFO - 2018-03-25 19:11:22 --> Model Class Initialized
INFO - 2018-03-25 19:11:22 --> Model Class Initialized
INFO - 2018-03-25 19:11:22 --> Model Class Initialized
INFO - 2018-03-25 19:11:22 --> Model Class Initialized
INFO - 2018-03-25 19:11:22 --> Model Class Initialized
INFO - 2018-03-25 19:11:22 --> Helper loaded: date_helper
INFO - 2018-03-25 19:11:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:11:37 --> Config Class Initialized
INFO - 2018-03-25 19:11:37 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:11:37 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:11:37 --> Utf8 Class Initialized
INFO - 2018-03-25 19:11:37 --> URI Class Initialized
INFO - 2018-03-25 19:11:37 --> Router Class Initialized
INFO - 2018-03-25 19:11:37 --> Output Class Initialized
INFO - 2018-03-25 19:11:37 --> Security Class Initialized
DEBUG - 2018-03-25 19:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:11:37 --> Input Class Initialized
INFO - 2018-03-25 19:11:37 --> Language Class Initialized
INFO - 2018-03-25 19:11:37 --> Loader Class Initialized
INFO - 2018-03-25 19:11:37 --> Helper loaded: url_helper
INFO - 2018-03-25 19:11:37 --> Helper loaded: form_helper
INFO - 2018-03-25 19:11:37 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:11:37 --> Controller Class Initialized
INFO - 2018-03-25 19:11:37 --> Model Class Initialized
INFO - 2018-03-25 19:11:37 --> Model Class Initialized
INFO - 2018-03-25 19:11:37 --> Model Class Initialized
INFO - 2018-03-25 19:11:37 --> Model Class Initialized
INFO - 2018-03-25 19:11:37 --> Model Class Initialized
INFO - 2018-03-25 19:11:37 --> Model Class Initialized
INFO - 2018-03-25 19:11:37 --> Model Class Initialized
INFO - 2018-03-25 19:11:37 --> Model Class Initialized
INFO - 2018-03-25 19:11:37 --> Model Class Initialized
INFO - 2018-03-25 19:11:37 --> Model Class Initialized
INFO - 2018-03-25 19:11:37 --> Model Class Initialized
INFO - 2018-03-25 19:11:37 --> Model Class Initialized
INFO - 2018-03-25 19:11:37 --> Helper loaded: date_helper
INFO - 2018-03-25 19:11:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:13:15 --> Config Class Initialized
INFO - 2018-03-25 19:13:15 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:13:15 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:13:15 --> Utf8 Class Initialized
INFO - 2018-03-25 19:13:15 --> URI Class Initialized
INFO - 2018-03-25 19:13:15 --> Router Class Initialized
INFO - 2018-03-25 19:13:15 --> Output Class Initialized
INFO - 2018-03-25 19:13:15 --> Security Class Initialized
DEBUG - 2018-03-25 19:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:13:15 --> Input Class Initialized
INFO - 2018-03-25 19:13:15 --> Language Class Initialized
INFO - 2018-03-25 19:13:15 --> Loader Class Initialized
INFO - 2018-03-25 19:13:15 --> Helper loaded: url_helper
INFO - 2018-03-25 19:13:15 --> Helper loaded: form_helper
INFO - 2018-03-25 19:13:15 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:13:15 --> Controller Class Initialized
INFO - 2018-03-25 19:13:15 --> Model Class Initialized
INFO - 2018-03-25 19:13:15 --> Model Class Initialized
INFO - 2018-03-25 19:13:15 --> Model Class Initialized
INFO - 2018-03-25 19:13:15 --> Model Class Initialized
INFO - 2018-03-25 19:13:15 --> Model Class Initialized
INFO - 2018-03-25 19:13:15 --> Model Class Initialized
INFO - 2018-03-25 19:13:15 --> Model Class Initialized
INFO - 2018-03-25 19:13:15 --> Model Class Initialized
INFO - 2018-03-25 19:13:15 --> Model Class Initialized
INFO - 2018-03-25 19:13:15 --> Model Class Initialized
INFO - 2018-03-25 19:13:15 --> Model Class Initialized
INFO - 2018-03-25 19:13:15 --> Model Class Initialized
INFO - 2018-03-25 19:13:15 --> Helper loaded: date_helper
INFO - 2018-03-25 19:13:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:13:21 --> Config Class Initialized
INFO - 2018-03-25 19:13:21 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:13:21 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:13:21 --> Utf8 Class Initialized
INFO - 2018-03-25 19:13:21 --> URI Class Initialized
INFO - 2018-03-25 19:13:21 --> Router Class Initialized
INFO - 2018-03-25 19:13:21 --> Output Class Initialized
INFO - 2018-03-25 19:13:21 --> Security Class Initialized
DEBUG - 2018-03-25 19:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:13:21 --> Input Class Initialized
INFO - 2018-03-25 19:13:21 --> Language Class Initialized
INFO - 2018-03-25 19:13:22 --> Loader Class Initialized
INFO - 2018-03-25 19:13:22 --> Helper loaded: url_helper
INFO - 2018-03-25 19:13:22 --> Helper loaded: form_helper
INFO - 2018-03-25 19:13:22 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:13:22 --> Controller Class Initialized
INFO - 2018-03-25 19:13:22 --> Model Class Initialized
INFO - 2018-03-25 19:13:22 --> Model Class Initialized
INFO - 2018-03-25 19:13:22 --> Model Class Initialized
INFO - 2018-03-25 19:13:22 --> Model Class Initialized
INFO - 2018-03-25 19:13:22 --> Model Class Initialized
INFO - 2018-03-25 19:13:22 --> Model Class Initialized
INFO - 2018-03-25 19:13:22 --> Model Class Initialized
INFO - 2018-03-25 19:13:22 --> Model Class Initialized
INFO - 2018-03-25 19:13:22 --> Model Class Initialized
INFO - 2018-03-25 19:13:22 --> Model Class Initialized
INFO - 2018-03-25 19:13:22 --> Model Class Initialized
INFO - 2018-03-25 19:13:22 --> Model Class Initialized
INFO - 2018-03-25 19:13:22 --> Helper loaded: date_helper
INFO - 2018-03-25 19:13:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:14:11 --> Config Class Initialized
INFO - 2018-03-25 19:14:11 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:14:11 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:14:11 --> Utf8 Class Initialized
INFO - 2018-03-25 19:14:11 --> URI Class Initialized
INFO - 2018-03-25 19:14:11 --> Router Class Initialized
INFO - 2018-03-25 19:14:11 --> Output Class Initialized
INFO - 2018-03-25 19:14:11 --> Security Class Initialized
DEBUG - 2018-03-25 19:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:14:11 --> Input Class Initialized
INFO - 2018-03-25 19:14:12 --> Language Class Initialized
INFO - 2018-03-25 19:14:12 --> Loader Class Initialized
INFO - 2018-03-25 19:14:12 --> Helper loaded: url_helper
INFO - 2018-03-25 19:14:12 --> Helper loaded: form_helper
INFO - 2018-03-25 19:14:12 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:14:12 --> Controller Class Initialized
INFO - 2018-03-25 19:14:12 --> Model Class Initialized
INFO - 2018-03-25 19:14:12 --> Model Class Initialized
INFO - 2018-03-25 19:14:12 --> Model Class Initialized
INFO - 2018-03-25 19:14:12 --> Model Class Initialized
INFO - 2018-03-25 19:14:12 --> Model Class Initialized
INFO - 2018-03-25 19:14:12 --> Model Class Initialized
INFO - 2018-03-25 19:14:12 --> Model Class Initialized
INFO - 2018-03-25 19:14:12 --> Model Class Initialized
INFO - 2018-03-25 19:14:12 --> Model Class Initialized
INFO - 2018-03-25 19:14:12 --> Model Class Initialized
INFO - 2018-03-25 19:14:12 --> Model Class Initialized
INFO - 2018-03-25 19:14:12 --> Model Class Initialized
INFO - 2018-03-25 19:14:12 --> Helper loaded: date_helper
INFO - 2018-03-25 19:14:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:14:24 --> Config Class Initialized
INFO - 2018-03-25 19:14:24 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:14:24 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:14:24 --> Utf8 Class Initialized
INFO - 2018-03-25 19:14:24 --> URI Class Initialized
INFO - 2018-03-25 19:14:24 --> Router Class Initialized
INFO - 2018-03-25 19:14:24 --> Output Class Initialized
INFO - 2018-03-25 19:14:24 --> Security Class Initialized
DEBUG - 2018-03-25 19:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:14:24 --> Input Class Initialized
INFO - 2018-03-25 19:14:24 --> Language Class Initialized
INFO - 2018-03-25 19:14:24 --> Loader Class Initialized
INFO - 2018-03-25 19:14:24 --> Helper loaded: url_helper
INFO - 2018-03-25 19:14:24 --> Helper loaded: form_helper
INFO - 2018-03-25 19:14:24 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:14:24 --> Controller Class Initialized
INFO - 2018-03-25 19:14:24 --> Model Class Initialized
INFO - 2018-03-25 19:14:24 --> Model Class Initialized
INFO - 2018-03-25 19:14:24 --> Model Class Initialized
INFO - 2018-03-25 19:14:24 --> Model Class Initialized
INFO - 2018-03-25 19:14:24 --> Model Class Initialized
INFO - 2018-03-25 19:14:24 --> Model Class Initialized
INFO - 2018-03-25 19:14:24 --> Model Class Initialized
INFO - 2018-03-25 19:14:24 --> Model Class Initialized
INFO - 2018-03-25 19:14:24 --> Model Class Initialized
INFO - 2018-03-25 19:14:24 --> Model Class Initialized
INFO - 2018-03-25 19:14:24 --> Model Class Initialized
INFO - 2018-03-25 19:14:24 --> Model Class Initialized
INFO - 2018-03-25 19:14:24 --> Helper loaded: date_helper
INFO - 2018-03-25 19:14:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:14:35 --> Config Class Initialized
INFO - 2018-03-25 19:14:35 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:14:35 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:14:35 --> Utf8 Class Initialized
INFO - 2018-03-25 19:14:35 --> URI Class Initialized
INFO - 2018-03-25 19:14:35 --> Router Class Initialized
INFO - 2018-03-25 19:14:35 --> Output Class Initialized
INFO - 2018-03-25 19:14:35 --> Security Class Initialized
DEBUG - 2018-03-25 19:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:14:35 --> Input Class Initialized
INFO - 2018-03-25 19:14:35 --> Language Class Initialized
INFO - 2018-03-25 19:14:35 --> Loader Class Initialized
INFO - 2018-03-25 19:14:35 --> Helper loaded: url_helper
INFO - 2018-03-25 19:14:35 --> Helper loaded: form_helper
INFO - 2018-03-25 19:14:35 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:14:35 --> Controller Class Initialized
INFO - 2018-03-25 19:14:35 --> Model Class Initialized
INFO - 2018-03-25 19:14:35 --> Model Class Initialized
INFO - 2018-03-25 19:14:35 --> Model Class Initialized
INFO - 2018-03-25 19:14:35 --> Model Class Initialized
INFO - 2018-03-25 19:14:35 --> Model Class Initialized
INFO - 2018-03-25 19:14:35 --> Model Class Initialized
INFO - 2018-03-25 19:14:35 --> Model Class Initialized
INFO - 2018-03-25 19:14:35 --> Model Class Initialized
INFO - 2018-03-25 19:14:35 --> Model Class Initialized
INFO - 2018-03-25 19:14:35 --> Model Class Initialized
INFO - 2018-03-25 19:14:35 --> Model Class Initialized
INFO - 2018-03-25 19:14:35 --> Model Class Initialized
INFO - 2018-03-25 19:14:35 --> Helper loaded: date_helper
INFO - 2018-03-25 19:14:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:14:59 --> Config Class Initialized
INFO - 2018-03-25 19:14:59 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:14:59 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:14:59 --> Utf8 Class Initialized
INFO - 2018-03-25 19:14:59 --> URI Class Initialized
INFO - 2018-03-25 19:14:59 --> Router Class Initialized
INFO - 2018-03-25 19:14:59 --> Output Class Initialized
INFO - 2018-03-25 19:14:59 --> Security Class Initialized
DEBUG - 2018-03-25 19:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:14:59 --> Input Class Initialized
INFO - 2018-03-25 19:14:59 --> Language Class Initialized
INFO - 2018-03-25 19:14:59 --> Loader Class Initialized
INFO - 2018-03-25 19:14:59 --> Helper loaded: url_helper
INFO - 2018-03-25 19:14:59 --> Helper loaded: form_helper
INFO - 2018-03-25 19:14:59 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:14:59 --> Controller Class Initialized
INFO - 2018-03-25 19:14:59 --> Model Class Initialized
INFO - 2018-03-25 19:14:59 --> Model Class Initialized
INFO - 2018-03-25 19:14:59 --> Model Class Initialized
INFO - 2018-03-25 19:14:59 --> Model Class Initialized
INFO - 2018-03-25 19:14:59 --> Model Class Initialized
INFO - 2018-03-25 19:14:59 --> Model Class Initialized
INFO - 2018-03-25 19:14:59 --> Model Class Initialized
INFO - 2018-03-25 19:14:59 --> Model Class Initialized
INFO - 2018-03-25 19:14:59 --> Model Class Initialized
INFO - 2018-03-25 19:14:59 --> Model Class Initialized
INFO - 2018-03-25 19:14:59 --> Model Class Initialized
INFO - 2018-03-25 19:14:59 --> Model Class Initialized
INFO - 2018-03-25 19:14:59 --> Helper loaded: date_helper
INFO - 2018-03-25 19:14:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:15:45 --> Config Class Initialized
INFO - 2018-03-25 19:15:45 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:15:45 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:15:45 --> Utf8 Class Initialized
INFO - 2018-03-25 19:15:45 --> URI Class Initialized
INFO - 2018-03-25 19:15:45 --> Router Class Initialized
INFO - 2018-03-25 19:15:45 --> Output Class Initialized
INFO - 2018-03-25 19:15:45 --> Security Class Initialized
DEBUG - 2018-03-25 19:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:15:45 --> Input Class Initialized
INFO - 2018-03-25 19:15:45 --> Language Class Initialized
INFO - 2018-03-25 19:15:45 --> Loader Class Initialized
INFO - 2018-03-25 19:15:45 --> Helper loaded: url_helper
INFO - 2018-03-25 19:15:45 --> Helper loaded: form_helper
INFO - 2018-03-25 19:15:45 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:15:45 --> Controller Class Initialized
INFO - 2018-03-25 19:15:45 --> Model Class Initialized
INFO - 2018-03-25 19:15:45 --> Model Class Initialized
INFO - 2018-03-25 19:15:45 --> Model Class Initialized
INFO - 2018-03-25 19:15:45 --> Model Class Initialized
INFO - 2018-03-25 19:15:45 --> Model Class Initialized
INFO - 2018-03-25 19:15:45 --> Model Class Initialized
INFO - 2018-03-25 19:15:45 --> Model Class Initialized
INFO - 2018-03-25 19:15:45 --> Model Class Initialized
INFO - 2018-03-25 19:15:45 --> Model Class Initialized
INFO - 2018-03-25 19:15:45 --> Model Class Initialized
INFO - 2018-03-25 19:15:45 --> Model Class Initialized
INFO - 2018-03-25 19:15:45 --> Model Class Initialized
INFO - 2018-03-25 19:15:45 --> Helper loaded: date_helper
INFO - 2018-03-25 19:15:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:17:04 --> Config Class Initialized
INFO - 2018-03-25 19:17:04 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:17:04 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:17:04 --> Utf8 Class Initialized
INFO - 2018-03-25 19:17:04 --> URI Class Initialized
INFO - 2018-03-25 19:17:04 --> Router Class Initialized
INFO - 2018-03-25 19:17:04 --> Output Class Initialized
INFO - 2018-03-25 19:17:04 --> Security Class Initialized
DEBUG - 2018-03-25 19:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:17:04 --> Input Class Initialized
INFO - 2018-03-25 19:17:04 --> Language Class Initialized
INFO - 2018-03-25 19:17:04 --> Loader Class Initialized
INFO - 2018-03-25 19:17:04 --> Helper loaded: url_helper
INFO - 2018-03-25 19:17:04 --> Helper loaded: form_helper
INFO - 2018-03-25 19:17:04 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:17:04 --> Controller Class Initialized
INFO - 2018-03-25 19:17:04 --> Model Class Initialized
INFO - 2018-03-25 19:17:04 --> Model Class Initialized
INFO - 2018-03-25 19:17:04 --> Model Class Initialized
INFO - 2018-03-25 19:17:04 --> Model Class Initialized
INFO - 2018-03-25 19:17:04 --> Model Class Initialized
INFO - 2018-03-25 19:17:04 --> Model Class Initialized
INFO - 2018-03-25 19:17:04 --> Model Class Initialized
INFO - 2018-03-25 19:17:04 --> Model Class Initialized
INFO - 2018-03-25 19:17:04 --> Model Class Initialized
INFO - 2018-03-25 19:17:04 --> Model Class Initialized
INFO - 2018-03-25 19:17:04 --> Model Class Initialized
INFO - 2018-03-25 19:17:04 --> Model Class Initialized
INFO - 2018-03-25 19:17:04 --> Helper loaded: date_helper
INFO - 2018-03-25 19:17:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:26:03 --> Config Class Initialized
INFO - 2018-03-25 19:26:03 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:26:03 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:26:03 --> Utf8 Class Initialized
INFO - 2018-03-25 19:26:03 --> URI Class Initialized
INFO - 2018-03-25 19:26:03 --> Router Class Initialized
INFO - 2018-03-25 19:26:03 --> Output Class Initialized
INFO - 2018-03-25 19:26:03 --> Security Class Initialized
DEBUG - 2018-03-25 19:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:26:03 --> Input Class Initialized
INFO - 2018-03-25 19:26:03 --> Language Class Initialized
INFO - 2018-03-25 19:26:03 --> Loader Class Initialized
INFO - 2018-03-25 19:26:03 --> Helper loaded: url_helper
INFO - 2018-03-25 19:26:03 --> Helper loaded: form_helper
INFO - 2018-03-25 19:26:03 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:26:03 --> Controller Class Initialized
INFO - 2018-03-25 19:26:03 --> Model Class Initialized
INFO - 2018-03-25 19:26:03 --> Model Class Initialized
INFO - 2018-03-25 19:26:03 --> Model Class Initialized
INFO - 2018-03-25 19:26:03 --> Model Class Initialized
INFO - 2018-03-25 19:26:03 --> Model Class Initialized
INFO - 2018-03-25 19:26:03 --> Model Class Initialized
INFO - 2018-03-25 19:26:03 --> Model Class Initialized
INFO - 2018-03-25 19:26:03 --> Model Class Initialized
INFO - 2018-03-25 19:26:03 --> Model Class Initialized
INFO - 2018-03-25 19:26:03 --> Model Class Initialized
INFO - 2018-03-25 19:26:03 --> Model Class Initialized
INFO - 2018-03-25 19:26:03 --> Model Class Initialized
INFO - 2018-03-25 19:26:03 --> Helper loaded: date_helper
INFO - 2018-03-25 19:26:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:26:16 --> Config Class Initialized
INFO - 2018-03-25 19:26:16 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:26:16 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:26:16 --> Utf8 Class Initialized
INFO - 2018-03-25 19:26:16 --> URI Class Initialized
INFO - 2018-03-25 19:26:16 --> Router Class Initialized
INFO - 2018-03-25 19:26:16 --> Output Class Initialized
INFO - 2018-03-25 19:26:16 --> Security Class Initialized
DEBUG - 2018-03-25 19:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:26:16 --> Input Class Initialized
INFO - 2018-03-25 19:26:16 --> Language Class Initialized
INFO - 2018-03-25 19:26:16 --> Loader Class Initialized
INFO - 2018-03-25 19:26:16 --> Helper loaded: url_helper
INFO - 2018-03-25 19:26:16 --> Helper loaded: form_helper
INFO - 2018-03-25 19:26:16 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:26:16 --> Controller Class Initialized
INFO - 2018-03-25 19:26:16 --> Model Class Initialized
INFO - 2018-03-25 19:26:16 --> Model Class Initialized
INFO - 2018-03-25 19:26:16 --> Model Class Initialized
INFO - 2018-03-25 19:26:16 --> Model Class Initialized
INFO - 2018-03-25 19:26:16 --> Model Class Initialized
INFO - 2018-03-25 19:26:16 --> Model Class Initialized
INFO - 2018-03-25 19:26:16 --> Model Class Initialized
INFO - 2018-03-25 19:26:16 --> Model Class Initialized
INFO - 2018-03-25 19:26:16 --> Model Class Initialized
INFO - 2018-03-25 19:26:16 --> Model Class Initialized
INFO - 2018-03-25 19:26:16 --> Model Class Initialized
INFO - 2018-03-25 19:26:16 --> Model Class Initialized
INFO - 2018-03-25 19:26:16 --> Helper loaded: date_helper
INFO - 2018-03-25 19:26:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:27:14 --> Config Class Initialized
INFO - 2018-03-25 19:27:14 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:27:14 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:27:14 --> Utf8 Class Initialized
INFO - 2018-03-25 19:27:14 --> URI Class Initialized
INFO - 2018-03-25 19:27:14 --> Router Class Initialized
INFO - 2018-03-25 19:27:14 --> Output Class Initialized
INFO - 2018-03-25 19:27:14 --> Security Class Initialized
DEBUG - 2018-03-25 19:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:27:14 --> Input Class Initialized
INFO - 2018-03-25 19:27:14 --> Language Class Initialized
INFO - 2018-03-25 19:27:14 --> Loader Class Initialized
INFO - 2018-03-25 19:27:14 --> Helper loaded: url_helper
INFO - 2018-03-25 19:27:14 --> Helper loaded: form_helper
INFO - 2018-03-25 19:27:14 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:27:14 --> Controller Class Initialized
INFO - 2018-03-25 19:27:14 --> Model Class Initialized
INFO - 2018-03-25 19:27:14 --> Model Class Initialized
INFO - 2018-03-25 19:27:14 --> Model Class Initialized
INFO - 2018-03-25 19:27:14 --> Model Class Initialized
INFO - 2018-03-25 19:27:14 --> Model Class Initialized
INFO - 2018-03-25 19:27:14 --> Model Class Initialized
INFO - 2018-03-25 19:27:14 --> Model Class Initialized
INFO - 2018-03-25 19:27:14 --> Model Class Initialized
INFO - 2018-03-25 19:27:14 --> Model Class Initialized
INFO - 2018-03-25 19:27:14 --> Model Class Initialized
INFO - 2018-03-25 19:27:14 --> Model Class Initialized
INFO - 2018-03-25 19:27:14 --> Model Class Initialized
INFO - 2018-03-25 19:27:14 --> Helper loaded: date_helper
INFO - 2018-03-25 19:27:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:27:18 --> Config Class Initialized
INFO - 2018-03-25 19:27:18 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:27:18 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:27:18 --> Utf8 Class Initialized
INFO - 2018-03-25 19:27:18 --> URI Class Initialized
INFO - 2018-03-25 19:27:18 --> Router Class Initialized
INFO - 2018-03-25 19:27:18 --> Output Class Initialized
INFO - 2018-03-25 19:27:18 --> Security Class Initialized
DEBUG - 2018-03-25 19:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:27:18 --> Input Class Initialized
INFO - 2018-03-25 19:27:18 --> Language Class Initialized
INFO - 2018-03-25 19:27:18 --> Loader Class Initialized
INFO - 2018-03-25 19:27:18 --> Helper loaded: url_helper
INFO - 2018-03-25 19:27:18 --> Helper loaded: form_helper
INFO - 2018-03-25 19:27:18 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:27:18 --> Controller Class Initialized
INFO - 2018-03-25 19:27:18 --> Model Class Initialized
INFO - 2018-03-25 19:27:18 --> Model Class Initialized
INFO - 2018-03-25 19:27:18 --> Model Class Initialized
INFO - 2018-03-25 19:27:18 --> Model Class Initialized
INFO - 2018-03-25 19:27:18 --> Model Class Initialized
INFO - 2018-03-25 19:27:18 --> Model Class Initialized
INFO - 2018-03-25 19:27:18 --> Model Class Initialized
INFO - 2018-03-25 19:27:18 --> Model Class Initialized
INFO - 2018-03-25 19:27:18 --> Model Class Initialized
INFO - 2018-03-25 19:27:18 --> Model Class Initialized
INFO - 2018-03-25 19:27:18 --> Model Class Initialized
INFO - 2018-03-25 19:27:18 --> Model Class Initialized
INFO - 2018-03-25 19:27:18 --> Helper loaded: date_helper
INFO - 2018-03-25 19:27:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:28:07 --> Config Class Initialized
INFO - 2018-03-25 19:28:07 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:28:07 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:28:07 --> Utf8 Class Initialized
INFO - 2018-03-25 19:28:07 --> URI Class Initialized
INFO - 2018-03-25 19:28:07 --> Router Class Initialized
INFO - 2018-03-25 19:28:07 --> Output Class Initialized
INFO - 2018-03-25 19:28:07 --> Security Class Initialized
DEBUG - 2018-03-25 19:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:28:07 --> Input Class Initialized
INFO - 2018-03-25 19:28:07 --> Language Class Initialized
INFO - 2018-03-25 19:28:07 --> Loader Class Initialized
INFO - 2018-03-25 19:28:07 --> Helper loaded: url_helper
INFO - 2018-03-25 19:28:07 --> Helper loaded: form_helper
INFO - 2018-03-25 19:28:07 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:28:07 --> Controller Class Initialized
INFO - 2018-03-25 19:28:07 --> Model Class Initialized
INFO - 2018-03-25 19:28:07 --> Model Class Initialized
INFO - 2018-03-25 19:28:07 --> Model Class Initialized
INFO - 2018-03-25 19:28:07 --> Model Class Initialized
INFO - 2018-03-25 19:28:07 --> Model Class Initialized
INFO - 2018-03-25 19:28:07 --> Model Class Initialized
INFO - 2018-03-25 19:28:07 --> Model Class Initialized
INFO - 2018-03-25 19:28:07 --> Model Class Initialized
INFO - 2018-03-25 19:28:07 --> Model Class Initialized
INFO - 2018-03-25 19:28:07 --> Model Class Initialized
INFO - 2018-03-25 19:28:07 --> Model Class Initialized
INFO - 2018-03-25 19:28:07 --> Model Class Initialized
INFO - 2018-03-25 19:28:07 --> Helper loaded: date_helper
INFO - 2018-03-25 19:28:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:28:08 --> Config Class Initialized
INFO - 2018-03-25 19:28:08 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:28:08 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:28:08 --> Utf8 Class Initialized
INFO - 2018-03-25 19:28:08 --> URI Class Initialized
INFO - 2018-03-25 19:28:08 --> Router Class Initialized
INFO - 2018-03-25 19:28:08 --> Output Class Initialized
INFO - 2018-03-25 19:28:08 --> Security Class Initialized
DEBUG - 2018-03-25 19:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:28:08 --> Input Class Initialized
INFO - 2018-03-25 19:28:08 --> Language Class Initialized
INFO - 2018-03-25 19:28:08 --> Loader Class Initialized
INFO - 2018-03-25 19:28:08 --> Helper loaded: url_helper
INFO - 2018-03-25 19:28:08 --> Helper loaded: form_helper
INFO - 2018-03-25 19:28:09 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:28:09 --> Controller Class Initialized
INFO - 2018-03-25 19:28:09 --> Model Class Initialized
INFO - 2018-03-25 19:28:09 --> Model Class Initialized
INFO - 2018-03-25 19:28:09 --> Model Class Initialized
INFO - 2018-03-25 19:28:09 --> Model Class Initialized
INFO - 2018-03-25 19:28:09 --> Model Class Initialized
INFO - 2018-03-25 19:28:09 --> Model Class Initialized
INFO - 2018-03-25 19:28:09 --> Model Class Initialized
INFO - 2018-03-25 19:28:09 --> Model Class Initialized
INFO - 2018-03-25 19:28:09 --> Model Class Initialized
INFO - 2018-03-25 19:28:09 --> Model Class Initialized
INFO - 2018-03-25 19:28:09 --> Model Class Initialized
INFO - 2018-03-25 19:28:09 --> Model Class Initialized
INFO - 2018-03-25 19:28:09 --> Helper loaded: date_helper
INFO - 2018-03-25 19:28:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:28:13 --> Config Class Initialized
INFO - 2018-03-25 19:28:13 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:28:13 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:28:13 --> Utf8 Class Initialized
INFO - 2018-03-25 19:28:13 --> URI Class Initialized
INFO - 2018-03-25 19:28:13 --> Router Class Initialized
INFO - 2018-03-25 19:28:13 --> Output Class Initialized
INFO - 2018-03-25 19:28:13 --> Security Class Initialized
DEBUG - 2018-03-25 19:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:28:13 --> Input Class Initialized
INFO - 2018-03-25 19:28:13 --> Language Class Initialized
INFO - 2018-03-25 19:28:13 --> Loader Class Initialized
INFO - 2018-03-25 19:28:13 --> Helper loaded: url_helper
INFO - 2018-03-25 19:28:13 --> Helper loaded: form_helper
INFO - 2018-03-25 19:28:13 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:28:13 --> Controller Class Initialized
INFO - 2018-03-25 19:28:13 --> Model Class Initialized
INFO - 2018-03-25 19:28:13 --> Model Class Initialized
INFO - 2018-03-25 19:28:13 --> Model Class Initialized
INFO - 2018-03-25 19:28:13 --> Model Class Initialized
INFO - 2018-03-25 19:28:13 --> Model Class Initialized
INFO - 2018-03-25 19:28:13 --> Model Class Initialized
INFO - 2018-03-25 19:28:13 --> Model Class Initialized
INFO - 2018-03-25 19:28:13 --> Model Class Initialized
INFO - 2018-03-25 19:28:13 --> Model Class Initialized
INFO - 2018-03-25 19:28:13 --> Model Class Initialized
INFO - 2018-03-25 19:28:13 --> Model Class Initialized
INFO - 2018-03-25 19:28:13 --> Model Class Initialized
INFO - 2018-03-25 19:28:13 --> Helper loaded: date_helper
INFO - 2018-03-25 19:28:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:28:14 --> Config Class Initialized
INFO - 2018-03-25 19:28:14 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:28:14 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:28:14 --> Utf8 Class Initialized
INFO - 2018-03-25 19:28:14 --> URI Class Initialized
INFO - 2018-03-25 19:28:14 --> Router Class Initialized
INFO - 2018-03-25 19:28:14 --> Output Class Initialized
INFO - 2018-03-25 19:28:14 --> Security Class Initialized
DEBUG - 2018-03-25 19:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:28:14 --> Input Class Initialized
INFO - 2018-03-25 19:28:14 --> Language Class Initialized
INFO - 2018-03-25 19:28:14 --> Loader Class Initialized
INFO - 2018-03-25 19:28:14 --> Helper loaded: url_helper
INFO - 2018-03-25 19:28:14 --> Helper loaded: form_helper
INFO - 2018-03-25 19:28:14 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:28:14 --> Controller Class Initialized
INFO - 2018-03-25 19:28:14 --> Model Class Initialized
INFO - 2018-03-25 19:28:14 --> Model Class Initialized
INFO - 2018-03-25 19:28:14 --> Model Class Initialized
INFO - 2018-03-25 19:28:14 --> Model Class Initialized
INFO - 2018-03-25 19:28:14 --> Model Class Initialized
INFO - 2018-03-25 19:28:14 --> Model Class Initialized
INFO - 2018-03-25 19:28:14 --> Model Class Initialized
INFO - 2018-03-25 19:28:14 --> Model Class Initialized
INFO - 2018-03-25 19:28:14 --> Model Class Initialized
INFO - 2018-03-25 19:28:14 --> Model Class Initialized
INFO - 2018-03-25 19:28:14 --> Model Class Initialized
INFO - 2018-03-25 19:28:14 --> Model Class Initialized
INFO - 2018-03-25 19:28:14 --> Helper loaded: date_helper
INFO - 2018-03-25 19:28:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:28:16 --> Config Class Initialized
INFO - 2018-03-25 19:28:16 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:28:16 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:28:16 --> Utf8 Class Initialized
INFO - 2018-03-25 19:28:16 --> URI Class Initialized
INFO - 2018-03-25 19:28:16 --> Router Class Initialized
INFO - 2018-03-25 19:28:16 --> Output Class Initialized
INFO - 2018-03-25 19:28:16 --> Security Class Initialized
DEBUG - 2018-03-25 19:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:28:16 --> Input Class Initialized
INFO - 2018-03-25 19:28:16 --> Language Class Initialized
INFO - 2018-03-25 19:28:16 --> Loader Class Initialized
INFO - 2018-03-25 19:28:16 --> Helper loaded: url_helper
INFO - 2018-03-25 19:28:16 --> Helper loaded: form_helper
INFO - 2018-03-25 19:28:16 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:28:16 --> Controller Class Initialized
INFO - 2018-03-25 19:28:16 --> Model Class Initialized
INFO - 2018-03-25 19:28:16 --> Model Class Initialized
INFO - 2018-03-25 19:28:16 --> Model Class Initialized
INFO - 2018-03-25 19:28:16 --> Model Class Initialized
INFO - 2018-03-25 19:28:16 --> Model Class Initialized
INFO - 2018-03-25 19:28:16 --> Model Class Initialized
INFO - 2018-03-25 19:28:16 --> Model Class Initialized
INFO - 2018-03-25 19:28:16 --> Model Class Initialized
INFO - 2018-03-25 19:28:16 --> Model Class Initialized
INFO - 2018-03-25 19:28:16 --> Model Class Initialized
INFO - 2018-03-25 19:28:16 --> Model Class Initialized
INFO - 2018-03-25 19:28:16 --> Model Class Initialized
INFO - 2018-03-25 19:28:16 --> Helper loaded: date_helper
INFO - 2018-03-25 19:28:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:28:18 --> Config Class Initialized
INFO - 2018-03-25 19:28:18 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:28:18 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:28:18 --> Utf8 Class Initialized
INFO - 2018-03-25 19:28:18 --> URI Class Initialized
INFO - 2018-03-25 19:28:18 --> Router Class Initialized
INFO - 2018-03-25 19:28:18 --> Output Class Initialized
INFO - 2018-03-25 19:28:18 --> Security Class Initialized
DEBUG - 2018-03-25 19:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:28:18 --> Input Class Initialized
INFO - 2018-03-25 19:28:18 --> Language Class Initialized
INFO - 2018-03-25 19:28:18 --> Loader Class Initialized
INFO - 2018-03-25 19:28:18 --> Helper loaded: url_helper
INFO - 2018-03-25 19:28:18 --> Helper loaded: form_helper
INFO - 2018-03-25 19:28:18 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:28:18 --> Controller Class Initialized
INFO - 2018-03-25 19:28:18 --> Model Class Initialized
INFO - 2018-03-25 19:28:18 --> Model Class Initialized
INFO - 2018-03-25 19:28:18 --> Model Class Initialized
INFO - 2018-03-25 19:28:18 --> Model Class Initialized
INFO - 2018-03-25 19:28:18 --> Model Class Initialized
INFO - 2018-03-25 19:28:18 --> Model Class Initialized
INFO - 2018-03-25 19:28:18 --> Model Class Initialized
INFO - 2018-03-25 19:28:18 --> Model Class Initialized
INFO - 2018-03-25 19:28:18 --> Model Class Initialized
INFO - 2018-03-25 19:28:18 --> Model Class Initialized
INFO - 2018-03-25 19:28:18 --> Model Class Initialized
INFO - 2018-03-25 19:28:18 --> Model Class Initialized
INFO - 2018-03-25 19:28:18 --> Helper loaded: date_helper
INFO - 2018-03-25 19:28:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:28:20 --> Config Class Initialized
INFO - 2018-03-25 19:28:20 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:28:20 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:28:20 --> Utf8 Class Initialized
INFO - 2018-03-25 19:28:20 --> URI Class Initialized
INFO - 2018-03-25 19:28:20 --> Router Class Initialized
INFO - 2018-03-25 19:28:20 --> Output Class Initialized
INFO - 2018-03-25 19:28:20 --> Security Class Initialized
DEBUG - 2018-03-25 19:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:28:20 --> Input Class Initialized
INFO - 2018-03-25 19:28:20 --> Language Class Initialized
INFO - 2018-03-25 19:28:20 --> Loader Class Initialized
INFO - 2018-03-25 19:28:20 --> Helper loaded: url_helper
INFO - 2018-03-25 19:28:20 --> Helper loaded: form_helper
INFO - 2018-03-25 19:28:20 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:28:20 --> Controller Class Initialized
INFO - 2018-03-25 19:28:20 --> Model Class Initialized
INFO - 2018-03-25 19:28:20 --> Model Class Initialized
INFO - 2018-03-25 19:28:20 --> Model Class Initialized
INFO - 2018-03-25 19:28:20 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Helper loaded: date_helper
INFO - 2018-03-25 19:28:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:28:21 --> Config Class Initialized
INFO - 2018-03-25 19:28:21 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:28:21 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:28:21 --> Utf8 Class Initialized
INFO - 2018-03-25 19:28:21 --> URI Class Initialized
INFO - 2018-03-25 19:28:21 --> Router Class Initialized
INFO - 2018-03-25 19:28:21 --> Output Class Initialized
INFO - 2018-03-25 19:28:21 --> Security Class Initialized
DEBUG - 2018-03-25 19:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:28:21 --> Input Class Initialized
INFO - 2018-03-25 19:28:21 --> Language Class Initialized
INFO - 2018-03-25 19:28:21 --> Loader Class Initialized
INFO - 2018-03-25 19:28:21 --> Helper loaded: url_helper
INFO - 2018-03-25 19:28:21 --> Helper loaded: form_helper
INFO - 2018-03-25 19:28:21 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:28:21 --> Controller Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Model Class Initialized
INFO - 2018-03-25 19:28:21 --> Helper loaded: date_helper
INFO - 2018-03-25 19:28:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:34:15 --> Config Class Initialized
INFO - 2018-03-25 19:34:15 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:34:15 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:34:15 --> Utf8 Class Initialized
INFO - 2018-03-25 19:34:15 --> URI Class Initialized
INFO - 2018-03-25 19:34:15 --> Router Class Initialized
INFO - 2018-03-25 19:34:15 --> Output Class Initialized
INFO - 2018-03-25 19:34:15 --> Security Class Initialized
DEBUG - 2018-03-25 19:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:34:15 --> Input Class Initialized
INFO - 2018-03-25 19:34:15 --> Language Class Initialized
INFO - 2018-03-25 19:34:15 --> Loader Class Initialized
INFO - 2018-03-25 19:34:15 --> Helper loaded: url_helper
INFO - 2018-03-25 19:34:15 --> Helper loaded: form_helper
INFO - 2018-03-25 19:34:15 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:34:15 --> Controller Class Initialized
INFO - 2018-03-25 19:34:15 --> Model Class Initialized
INFO - 2018-03-25 19:34:15 --> Model Class Initialized
INFO - 2018-03-25 19:34:15 --> Model Class Initialized
INFO - 2018-03-25 19:34:15 --> Model Class Initialized
INFO - 2018-03-25 19:34:15 --> Model Class Initialized
INFO - 2018-03-25 19:34:15 --> Model Class Initialized
INFO - 2018-03-25 19:34:15 --> Model Class Initialized
INFO - 2018-03-25 19:34:15 --> Model Class Initialized
INFO - 2018-03-25 19:34:15 --> Model Class Initialized
INFO - 2018-03-25 19:34:15 --> Model Class Initialized
INFO - 2018-03-25 19:34:15 --> Model Class Initialized
INFO - 2018-03-25 19:34:15 --> Model Class Initialized
INFO - 2018-03-25 19:34:15 --> Helper loaded: date_helper
INFO - 2018-03-25 19:34:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:35:09 --> Config Class Initialized
INFO - 2018-03-25 19:35:09 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:35:09 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:35:09 --> Utf8 Class Initialized
INFO - 2018-03-25 19:35:09 --> URI Class Initialized
INFO - 2018-03-25 19:35:09 --> Router Class Initialized
INFO - 2018-03-25 19:35:09 --> Output Class Initialized
INFO - 2018-03-25 19:35:09 --> Security Class Initialized
DEBUG - 2018-03-25 19:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:35:09 --> Input Class Initialized
INFO - 2018-03-25 19:35:09 --> Language Class Initialized
INFO - 2018-03-25 19:35:09 --> Loader Class Initialized
INFO - 2018-03-25 19:35:09 --> Helper loaded: url_helper
INFO - 2018-03-25 19:35:09 --> Helper loaded: form_helper
INFO - 2018-03-25 19:35:09 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:35:09 --> Controller Class Initialized
INFO - 2018-03-25 19:35:09 --> Model Class Initialized
INFO - 2018-03-25 19:35:09 --> Model Class Initialized
INFO - 2018-03-25 19:35:09 --> Model Class Initialized
INFO - 2018-03-25 19:35:09 --> Model Class Initialized
INFO - 2018-03-25 19:35:09 --> Model Class Initialized
INFO - 2018-03-25 19:35:09 --> Model Class Initialized
INFO - 2018-03-25 19:35:09 --> Model Class Initialized
INFO - 2018-03-25 19:35:09 --> Model Class Initialized
INFO - 2018-03-25 19:35:09 --> Model Class Initialized
INFO - 2018-03-25 19:35:09 --> Model Class Initialized
INFO - 2018-03-25 19:35:09 --> Model Class Initialized
INFO - 2018-03-25 19:35:09 --> Model Class Initialized
INFO - 2018-03-25 19:35:09 --> Helper loaded: date_helper
INFO - 2018-03-25 19:35:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:35:24 --> Config Class Initialized
INFO - 2018-03-25 19:35:24 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:35:24 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:35:24 --> Utf8 Class Initialized
INFO - 2018-03-25 19:35:24 --> URI Class Initialized
INFO - 2018-03-25 19:35:24 --> Router Class Initialized
INFO - 2018-03-25 19:35:24 --> Output Class Initialized
INFO - 2018-03-25 19:35:24 --> Security Class Initialized
DEBUG - 2018-03-25 19:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:35:24 --> Input Class Initialized
INFO - 2018-03-25 19:35:24 --> Language Class Initialized
INFO - 2018-03-25 19:35:24 --> Loader Class Initialized
INFO - 2018-03-25 19:35:24 --> Helper loaded: url_helper
INFO - 2018-03-25 19:35:24 --> Helper loaded: form_helper
INFO - 2018-03-25 19:35:24 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:35:24 --> Controller Class Initialized
INFO - 2018-03-25 19:35:24 --> Model Class Initialized
INFO - 2018-03-25 19:35:24 --> Model Class Initialized
INFO - 2018-03-25 19:35:24 --> Model Class Initialized
INFO - 2018-03-25 19:35:24 --> Model Class Initialized
INFO - 2018-03-25 19:35:24 --> Model Class Initialized
INFO - 2018-03-25 19:35:24 --> Model Class Initialized
INFO - 2018-03-25 19:35:24 --> Model Class Initialized
INFO - 2018-03-25 19:35:24 --> Model Class Initialized
INFO - 2018-03-25 19:35:24 --> Model Class Initialized
INFO - 2018-03-25 19:35:24 --> Model Class Initialized
INFO - 2018-03-25 19:35:24 --> Model Class Initialized
INFO - 2018-03-25 19:35:24 --> Model Class Initialized
INFO - 2018-03-25 19:35:24 --> Helper loaded: date_helper
INFO - 2018-03-25 19:35:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:42:12 --> Config Class Initialized
INFO - 2018-03-25 19:42:12 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:42:12 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:42:12 --> Utf8 Class Initialized
INFO - 2018-03-25 19:42:12 --> URI Class Initialized
INFO - 2018-03-25 19:42:12 --> Router Class Initialized
INFO - 2018-03-25 19:42:12 --> Output Class Initialized
INFO - 2018-03-25 19:42:12 --> Security Class Initialized
DEBUG - 2018-03-25 19:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:42:12 --> Input Class Initialized
INFO - 2018-03-25 19:42:12 --> Language Class Initialized
INFO - 2018-03-25 19:42:12 --> Loader Class Initialized
INFO - 2018-03-25 19:42:12 --> Helper loaded: url_helper
INFO - 2018-03-25 19:42:12 --> Helper loaded: form_helper
INFO - 2018-03-25 19:42:12 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:42:12 --> Controller Class Initialized
INFO - 2018-03-25 19:42:12 --> Model Class Initialized
INFO - 2018-03-25 19:42:12 --> Model Class Initialized
INFO - 2018-03-25 19:42:12 --> Model Class Initialized
INFO - 2018-03-25 19:42:12 --> Model Class Initialized
INFO - 2018-03-25 19:42:12 --> Model Class Initialized
INFO - 2018-03-25 19:42:12 --> Model Class Initialized
INFO - 2018-03-25 19:42:12 --> Model Class Initialized
INFO - 2018-03-25 19:42:12 --> Model Class Initialized
INFO - 2018-03-25 19:42:12 --> Model Class Initialized
INFO - 2018-03-25 19:42:12 --> Model Class Initialized
INFO - 2018-03-25 19:42:12 --> Model Class Initialized
INFO - 2018-03-25 19:42:12 --> Model Class Initialized
INFO - 2018-03-25 19:42:12 --> Helper loaded: date_helper
INFO - 2018-03-25 19:42:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:42:14 --> Config Class Initialized
INFO - 2018-03-25 19:42:14 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:42:14 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:42:14 --> Utf8 Class Initialized
INFO - 2018-03-25 19:42:14 --> URI Class Initialized
INFO - 2018-03-25 19:42:14 --> Router Class Initialized
INFO - 2018-03-25 19:42:14 --> Output Class Initialized
INFO - 2018-03-25 19:42:14 --> Security Class Initialized
DEBUG - 2018-03-25 19:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:42:14 --> Input Class Initialized
INFO - 2018-03-25 19:42:14 --> Language Class Initialized
INFO - 2018-03-25 19:42:14 --> Loader Class Initialized
INFO - 2018-03-25 19:42:14 --> Helper loaded: url_helper
INFO - 2018-03-25 19:42:14 --> Helper loaded: form_helper
INFO - 2018-03-25 19:42:14 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:42:14 --> Controller Class Initialized
INFO - 2018-03-25 19:42:14 --> Model Class Initialized
INFO - 2018-03-25 19:42:14 --> Model Class Initialized
INFO - 2018-03-25 19:42:14 --> Model Class Initialized
INFO - 2018-03-25 19:42:14 --> Model Class Initialized
INFO - 2018-03-25 19:42:14 --> Model Class Initialized
INFO - 2018-03-25 19:42:14 --> Model Class Initialized
INFO - 2018-03-25 19:42:14 --> Model Class Initialized
INFO - 2018-03-25 19:42:14 --> Model Class Initialized
INFO - 2018-03-25 19:42:14 --> Model Class Initialized
INFO - 2018-03-25 19:42:14 --> Model Class Initialized
INFO - 2018-03-25 19:42:14 --> Model Class Initialized
INFO - 2018-03-25 19:42:14 --> Model Class Initialized
INFO - 2018-03-25 19:42:14 --> Helper loaded: date_helper
INFO - 2018-03-25 19:42:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:42:18 --> Config Class Initialized
INFO - 2018-03-25 19:42:18 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:42:18 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:42:18 --> Utf8 Class Initialized
INFO - 2018-03-25 19:42:18 --> URI Class Initialized
INFO - 2018-03-25 19:42:18 --> Router Class Initialized
INFO - 2018-03-25 19:42:18 --> Output Class Initialized
INFO - 2018-03-25 19:42:18 --> Security Class Initialized
DEBUG - 2018-03-25 19:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:42:18 --> Input Class Initialized
INFO - 2018-03-25 19:42:18 --> Language Class Initialized
INFO - 2018-03-25 19:42:18 --> Loader Class Initialized
INFO - 2018-03-25 19:42:18 --> Helper loaded: url_helper
INFO - 2018-03-25 19:42:18 --> Helper loaded: form_helper
INFO - 2018-03-25 19:42:18 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:42:18 --> Controller Class Initialized
INFO - 2018-03-25 19:42:18 --> Model Class Initialized
INFO - 2018-03-25 19:42:18 --> Model Class Initialized
INFO - 2018-03-25 19:42:18 --> Model Class Initialized
INFO - 2018-03-25 19:42:18 --> Model Class Initialized
INFO - 2018-03-25 19:42:18 --> Model Class Initialized
INFO - 2018-03-25 19:42:18 --> Model Class Initialized
INFO - 2018-03-25 19:42:18 --> Model Class Initialized
INFO - 2018-03-25 19:42:18 --> Model Class Initialized
INFO - 2018-03-25 19:42:18 --> Model Class Initialized
INFO - 2018-03-25 19:42:18 --> Model Class Initialized
INFO - 2018-03-25 19:42:18 --> Model Class Initialized
INFO - 2018-03-25 19:42:18 --> Model Class Initialized
INFO - 2018-03-25 19:42:18 --> Helper loaded: date_helper
INFO - 2018-03-25 19:42:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:42:19 --> Config Class Initialized
INFO - 2018-03-25 19:42:19 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:42:19 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:42:19 --> Utf8 Class Initialized
INFO - 2018-03-25 19:42:19 --> URI Class Initialized
INFO - 2018-03-25 19:42:19 --> Router Class Initialized
INFO - 2018-03-25 19:42:19 --> Output Class Initialized
INFO - 2018-03-25 19:42:19 --> Security Class Initialized
DEBUG - 2018-03-25 19:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:42:19 --> Input Class Initialized
INFO - 2018-03-25 19:42:19 --> Language Class Initialized
INFO - 2018-03-25 19:42:19 --> Loader Class Initialized
INFO - 2018-03-25 19:42:19 --> Helper loaded: url_helper
INFO - 2018-03-25 19:42:19 --> Helper loaded: form_helper
INFO - 2018-03-25 19:42:19 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:42:19 --> Controller Class Initialized
INFO - 2018-03-25 19:42:19 --> Model Class Initialized
INFO - 2018-03-25 19:42:19 --> Model Class Initialized
INFO - 2018-03-25 19:42:19 --> Model Class Initialized
INFO - 2018-03-25 19:42:19 --> Model Class Initialized
INFO - 2018-03-25 19:42:19 --> Model Class Initialized
INFO - 2018-03-25 19:42:19 --> Model Class Initialized
INFO - 2018-03-25 19:42:19 --> Model Class Initialized
INFO - 2018-03-25 19:42:19 --> Model Class Initialized
INFO - 2018-03-25 19:42:19 --> Model Class Initialized
INFO - 2018-03-25 19:42:19 --> Model Class Initialized
INFO - 2018-03-25 19:42:19 --> Model Class Initialized
INFO - 2018-03-25 19:42:19 --> Model Class Initialized
INFO - 2018-03-25 19:42:19 --> Helper loaded: date_helper
INFO - 2018-03-25 19:42:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:42:45 --> Config Class Initialized
INFO - 2018-03-25 19:42:45 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:42:45 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:42:45 --> Utf8 Class Initialized
INFO - 2018-03-25 19:42:45 --> URI Class Initialized
INFO - 2018-03-25 19:42:45 --> Router Class Initialized
INFO - 2018-03-25 19:42:45 --> Output Class Initialized
INFO - 2018-03-25 19:42:45 --> Security Class Initialized
DEBUG - 2018-03-25 19:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:42:45 --> Input Class Initialized
INFO - 2018-03-25 19:42:45 --> Language Class Initialized
INFO - 2018-03-25 19:42:45 --> Loader Class Initialized
INFO - 2018-03-25 19:42:45 --> Helper loaded: url_helper
INFO - 2018-03-25 19:42:45 --> Helper loaded: form_helper
INFO - 2018-03-25 19:42:45 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:42:45 --> Controller Class Initialized
INFO - 2018-03-25 19:42:45 --> Model Class Initialized
INFO - 2018-03-25 19:42:45 --> Model Class Initialized
INFO - 2018-03-25 19:42:45 --> Model Class Initialized
INFO - 2018-03-25 19:42:45 --> Model Class Initialized
INFO - 2018-03-25 19:42:45 --> Model Class Initialized
INFO - 2018-03-25 19:42:45 --> Model Class Initialized
INFO - 2018-03-25 19:42:45 --> Model Class Initialized
INFO - 2018-03-25 19:42:45 --> Helper loaded: date_helper
INFO - 2018-03-25 19:42:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:42:47 --> Config Class Initialized
INFO - 2018-03-25 19:42:47 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:42:48 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:42:48 --> Utf8 Class Initialized
INFO - 2018-03-25 19:42:48 --> URI Class Initialized
INFO - 2018-03-25 19:42:48 --> Router Class Initialized
INFO - 2018-03-25 19:42:48 --> Output Class Initialized
INFO - 2018-03-25 19:42:48 --> Security Class Initialized
DEBUG - 2018-03-25 19:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:42:48 --> Input Class Initialized
INFO - 2018-03-25 19:42:48 --> Language Class Initialized
INFO - 2018-03-25 19:42:48 --> Loader Class Initialized
INFO - 2018-03-25 19:42:48 --> Helper loaded: url_helper
INFO - 2018-03-25 19:42:48 --> Helper loaded: form_helper
INFO - 2018-03-25 19:42:48 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:42:48 --> Controller Class Initialized
INFO - 2018-03-25 19:42:48 --> Model Class Initialized
INFO - 2018-03-25 19:42:48 --> Model Class Initialized
INFO - 2018-03-25 19:42:48 --> Model Class Initialized
INFO - 2018-03-25 19:42:48 --> Model Class Initialized
INFO - 2018-03-25 19:42:48 --> Model Class Initialized
INFO - 2018-03-25 19:42:48 --> Model Class Initialized
INFO - 2018-03-25 19:42:48 --> Model Class Initialized
INFO - 2018-03-25 19:42:48 --> Helper loaded: date_helper
INFO - 2018-03-25 19:42:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:42:50 --> Config Class Initialized
INFO - 2018-03-25 19:42:50 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:42:50 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:42:50 --> Utf8 Class Initialized
INFO - 2018-03-25 19:42:50 --> URI Class Initialized
INFO - 2018-03-25 19:42:50 --> Router Class Initialized
INFO - 2018-03-25 19:42:50 --> Output Class Initialized
INFO - 2018-03-25 19:42:50 --> Security Class Initialized
DEBUG - 2018-03-25 19:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:42:50 --> Input Class Initialized
INFO - 2018-03-25 19:42:50 --> Language Class Initialized
INFO - 2018-03-25 19:42:50 --> Loader Class Initialized
INFO - 2018-03-25 19:42:50 --> Helper loaded: url_helper
INFO - 2018-03-25 19:42:50 --> Helper loaded: form_helper
INFO - 2018-03-25 19:42:50 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:42:50 --> Controller Class Initialized
INFO - 2018-03-25 19:42:50 --> Model Class Initialized
INFO - 2018-03-25 19:42:50 --> Model Class Initialized
INFO - 2018-03-25 19:42:50 --> Model Class Initialized
INFO - 2018-03-25 19:42:50 --> Model Class Initialized
INFO - 2018-03-25 19:42:50 --> Model Class Initialized
INFO - 2018-03-25 19:42:50 --> Model Class Initialized
INFO - 2018-03-25 19:42:50 --> Model Class Initialized
INFO - 2018-03-25 19:42:50 --> Helper loaded: date_helper
INFO - 2018-03-25 19:42:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:42:55 --> Config Class Initialized
INFO - 2018-03-25 19:42:55 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:42:55 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:42:55 --> Utf8 Class Initialized
INFO - 2018-03-25 19:42:55 --> URI Class Initialized
INFO - 2018-03-25 19:42:55 --> Router Class Initialized
INFO - 2018-03-25 19:42:55 --> Output Class Initialized
INFO - 2018-03-25 19:42:55 --> Security Class Initialized
DEBUG - 2018-03-25 19:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:42:55 --> Input Class Initialized
INFO - 2018-03-25 19:42:55 --> Language Class Initialized
INFO - 2018-03-25 19:42:55 --> Loader Class Initialized
INFO - 2018-03-25 19:42:55 --> Helper loaded: url_helper
INFO - 2018-03-25 19:42:55 --> Helper loaded: form_helper
INFO - 2018-03-25 19:42:55 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:42:55 --> Controller Class Initialized
INFO - 2018-03-25 19:42:55 --> Model Class Initialized
INFO - 2018-03-25 19:42:55 --> Model Class Initialized
INFO - 2018-03-25 19:42:55 --> Helper loaded: date_helper
INFO - 2018-03-25 19:42:55 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:43:00 --> Config Class Initialized
INFO - 2018-03-25 19:43:00 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:43:00 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:43:00 --> Utf8 Class Initialized
INFO - 2018-03-25 19:43:00 --> URI Class Initialized
INFO - 2018-03-25 19:43:00 --> Router Class Initialized
INFO - 2018-03-25 19:43:00 --> Output Class Initialized
INFO - 2018-03-25 19:43:00 --> Security Class Initialized
DEBUG - 2018-03-25 19:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:43:00 --> Input Class Initialized
INFO - 2018-03-25 19:43:00 --> Language Class Initialized
INFO - 2018-03-25 19:43:00 --> Loader Class Initialized
INFO - 2018-03-25 19:43:00 --> Helper loaded: url_helper
INFO - 2018-03-25 19:43:00 --> Helper loaded: form_helper
INFO - 2018-03-25 19:43:00 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:43:00 --> Controller Class Initialized
INFO - 2018-03-25 19:43:00 --> Model Class Initialized
INFO - 2018-03-25 19:43:00 --> Model Class Initialized
INFO - 2018-03-25 19:43:00 --> Model Class Initialized
INFO - 2018-03-25 19:43:00 --> Model Class Initialized
INFO - 2018-03-25 19:43:00 --> Model Class Initialized
INFO - 2018-03-25 19:43:00 --> Model Class Initialized
INFO - 2018-03-25 19:43:00 --> Model Class Initialized
INFO - 2018-03-25 19:43:00 --> Helper loaded: date_helper
INFO - 2018-03-25 19:43:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:43:26 --> Config Class Initialized
INFO - 2018-03-25 19:43:26 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:43:26 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:43:26 --> Utf8 Class Initialized
INFO - 2018-03-25 19:43:26 --> URI Class Initialized
INFO - 2018-03-25 19:43:26 --> Router Class Initialized
INFO - 2018-03-25 19:43:26 --> Output Class Initialized
INFO - 2018-03-25 19:43:26 --> Security Class Initialized
DEBUG - 2018-03-25 19:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:43:26 --> Input Class Initialized
INFO - 2018-03-25 19:43:26 --> Language Class Initialized
INFO - 2018-03-25 19:43:26 --> Loader Class Initialized
INFO - 2018-03-25 19:43:26 --> Helper loaded: url_helper
INFO - 2018-03-25 19:43:26 --> Helper loaded: form_helper
INFO - 2018-03-25 19:43:26 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:43:26 --> Controller Class Initialized
INFO - 2018-03-25 19:43:26 --> Model Class Initialized
INFO - 2018-03-25 19:43:26 --> Model Class Initialized
INFO - 2018-03-25 19:43:26 --> Model Class Initialized
INFO - 2018-03-25 19:43:26 --> Model Class Initialized
INFO - 2018-03-25 19:43:26 --> Model Class Initialized
INFO - 2018-03-25 19:43:26 --> Model Class Initialized
INFO - 2018-03-25 19:43:26 --> Model Class Initialized
INFO - 2018-03-25 19:43:26 --> Helper loaded: date_helper
INFO - 2018-03-25 19:43:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:46:41 --> Config Class Initialized
INFO - 2018-03-25 19:46:41 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:46:41 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:46:41 --> Utf8 Class Initialized
INFO - 2018-03-25 19:46:41 --> URI Class Initialized
INFO - 2018-03-25 19:46:41 --> Router Class Initialized
INFO - 2018-03-25 19:46:41 --> Output Class Initialized
INFO - 2018-03-25 19:46:41 --> Security Class Initialized
DEBUG - 2018-03-25 19:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:46:41 --> Input Class Initialized
INFO - 2018-03-25 19:46:41 --> Language Class Initialized
INFO - 2018-03-25 19:46:41 --> Loader Class Initialized
INFO - 2018-03-25 19:46:41 --> Helper loaded: url_helper
INFO - 2018-03-25 19:46:41 --> Helper loaded: form_helper
INFO - 2018-03-25 19:46:41 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:46:41 --> Controller Class Initialized
INFO - 2018-03-25 19:46:41 --> Model Class Initialized
INFO - 2018-03-25 19:46:41 --> Model Class Initialized
INFO - 2018-03-25 19:46:41 --> Model Class Initialized
INFO - 2018-03-25 19:46:41 --> Model Class Initialized
INFO - 2018-03-25 19:46:41 --> Model Class Initialized
INFO - 2018-03-25 19:46:41 --> Model Class Initialized
INFO - 2018-03-25 19:46:41 --> Model Class Initialized
INFO - 2018-03-25 19:46:41 --> Model Class Initialized
INFO - 2018-03-25 19:46:41 --> Model Class Initialized
INFO - 2018-03-25 19:46:41 --> Model Class Initialized
INFO - 2018-03-25 19:46:41 --> Model Class Initialized
INFO - 2018-03-25 19:46:41 --> Model Class Initialized
INFO - 2018-03-25 19:46:41 --> Helper loaded: date_helper
INFO - 2018-03-25 19:46:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:47:14 --> Config Class Initialized
INFO - 2018-03-25 19:47:14 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:47:14 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:47:14 --> Utf8 Class Initialized
INFO - 2018-03-25 19:47:14 --> URI Class Initialized
INFO - 2018-03-25 19:47:14 --> Router Class Initialized
INFO - 2018-03-25 19:47:14 --> Output Class Initialized
INFO - 2018-03-25 19:47:14 --> Security Class Initialized
DEBUG - 2018-03-25 19:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:47:14 --> Input Class Initialized
INFO - 2018-03-25 19:47:14 --> Language Class Initialized
INFO - 2018-03-25 19:47:14 --> Loader Class Initialized
INFO - 2018-03-25 19:47:14 --> Helper loaded: url_helper
INFO - 2018-03-25 19:47:14 --> Helper loaded: form_helper
INFO - 2018-03-25 19:47:14 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:47:14 --> Controller Class Initialized
INFO - 2018-03-25 19:47:14 --> Model Class Initialized
INFO - 2018-03-25 19:47:14 --> Model Class Initialized
INFO - 2018-03-25 19:47:14 --> Model Class Initialized
INFO - 2018-03-25 19:47:14 --> Model Class Initialized
INFO - 2018-03-25 19:47:14 --> Model Class Initialized
INFO - 2018-03-25 19:47:14 --> Model Class Initialized
INFO - 2018-03-25 19:47:14 --> Model Class Initialized
INFO - 2018-03-25 19:47:14 --> Model Class Initialized
INFO - 2018-03-25 19:47:14 --> Model Class Initialized
INFO - 2018-03-25 19:47:14 --> Model Class Initialized
INFO - 2018-03-25 19:47:14 --> Model Class Initialized
INFO - 2018-03-25 19:47:14 --> Model Class Initialized
INFO - 2018-03-25 19:47:14 --> Helper loaded: date_helper
INFO - 2018-03-25 19:47:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:48:04 --> Config Class Initialized
INFO - 2018-03-25 19:48:04 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:48:04 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:48:04 --> Utf8 Class Initialized
INFO - 2018-03-25 19:48:04 --> URI Class Initialized
INFO - 2018-03-25 19:48:04 --> Router Class Initialized
INFO - 2018-03-25 19:48:04 --> Output Class Initialized
INFO - 2018-03-25 19:48:04 --> Security Class Initialized
DEBUG - 2018-03-25 19:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:48:04 --> Input Class Initialized
INFO - 2018-03-25 19:48:04 --> Language Class Initialized
INFO - 2018-03-25 19:48:04 --> Loader Class Initialized
INFO - 2018-03-25 19:48:04 --> Helper loaded: url_helper
INFO - 2018-03-25 19:48:04 --> Helper loaded: form_helper
INFO - 2018-03-25 19:48:04 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:48:04 --> Controller Class Initialized
INFO - 2018-03-25 19:48:04 --> Model Class Initialized
INFO - 2018-03-25 19:48:04 --> Model Class Initialized
INFO - 2018-03-25 19:48:04 --> Model Class Initialized
INFO - 2018-03-25 19:48:04 --> Model Class Initialized
INFO - 2018-03-25 19:48:04 --> Model Class Initialized
INFO - 2018-03-25 19:48:04 --> Model Class Initialized
INFO - 2018-03-25 19:48:04 --> Model Class Initialized
INFO - 2018-03-25 19:48:04 --> Model Class Initialized
INFO - 2018-03-25 19:48:04 --> Model Class Initialized
INFO - 2018-03-25 19:48:04 --> Model Class Initialized
INFO - 2018-03-25 19:48:04 --> Model Class Initialized
INFO - 2018-03-25 19:48:04 --> Model Class Initialized
INFO - 2018-03-25 19:48:04 --> Helper loaded: date_helper
INFO - 2018-03-25 19:48:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:48:46 --> Config Class Initialized
INFO - 2018-03-25 19:48:46 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:48:46 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:48:46 --> Utf8 Class Initialized
INFO - 2018-03-25 19:48:46 --> URI Class Initialized
INFO - 2018-03-25 19:48:46 --> Router Class Initialized
INFO - 2018-03-25 19:48:46 --> Output Class Initialized
INFO - 2018-03-25 19:48:46 --> Security Class Initialized
DEBUG - 2018-03-25 19:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:48:46 --> Input Class Initialized
INFO - 2018-03-25 19:48:46 --> Language Class Initialized
INFO - 2018-03-25 19:48:46 --> Loader Class Initialized
INFO - 2018-03-25 19:48:46 --> Helper loaded: url_helper
INFO - 2018-03-25 19:48:46 --> Helper loaded: form_helper
INFO - 2018-03-25 19:48:46 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:48:46 --> Controller Class Initialized
INFO - 2018-03-25 19:48:46 --> Model Class Initialized
INFO - 2018-03-25 19:48:46 --> Model Class Initialized
INFO - 2018-03-25 19:48:46 --> Model Class Initialized
INFO - 2018-03-25 19:48:46 --> Model Class Initialized
INFO - 2018-03-25 19:48:46 --> Model Class Initialized
INFO - 2018-03-25 19:48:46 --> Model Class Initialized
INFO - 2018-03-25 19:48:46 --> Model Class Initialized
INFO - 2018-03-25 19:48:46 --> Model Class Initialized
INFO - 2018-03-25 19:48:46 --> Model Class Initialized
INFO - 2018-03-25 19:48:46 --> Model Class Initialized
INFO - 2018-03-25 19:48:46 --> Model Class Initialized
INFO - 2018-03-25 19:48:46 --> Model Class Initialized
INFO - 2018-03-25 19:48:46 --> Helper loaded: date_helper
INFO - 2018-03-25 19:48:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:51:27 --> Config Class Initialized
INFO - 2018-03-25 19:51:27 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:51:27 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:51:27 --> Utf8 Class Initialized
INFO - 2018-03-25 19:51:27 --> URI Class Initialized
INFO - 2018-03-25 19:51:27 --> Router Class Initialized
INFO - 2018-03-25 19:51:27 --> Output Class Initialized
INFO - 2018-03-25 19:51:27 --> Security Class Initialized
DEBUG - 2018-03-25 19:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:51:27 --> Input Class Initialized
INFO - 2018-03-25 19:51:27 --> Language Class Initialized
INFO - 2018-03-25 19:51:27 --> Loader Class Initialized
INFO - 2018-03-25 19:51:27 --> Helper loaded: url_helper
INFO - 2018-03-25 19:51:27 --> Helper loaded: form_helper
INFO - 2018-03-25 19:51:27 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:51:27 --> Controller Class Initialized
INFO - 2018-03-25 19:51:27 --> Model Class Initialized
INFO - 2018-03-25 19:51:27 --> Model Class Initialized
INFO - 2018-03-25 19:51:27 --> Model Class Initialized
INFO - 2018-03-25 19:51:27 --> Model Class Initialized
INFO - 2018-03-25 19:51:27 --> Model Class Initialized
INFO - 2018-03-25 19:51:27 --> Model Class Initialized
INFO - 2018-03-25 19:51:27 --> Model Class Initialized
INFO - 2018-03-25 19:51:27 --> Model Class Initialized
INFO - 2018-03-25 19:51:27 --> Model Class Initialized
INFO - 2018-03-25 19:51:27 --> Model Class Initialized
INFO - 2018-03-25 19:51:27 --> Model Class Initialized
INFO - 2018-03-25 19:51:27 --> Model Class Initialized
INFO - 2018-03-25 19:51:27 --> Helper loaded: date_helper
INFO - 2018-03-25 19:51:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:51:41 --> Config Class Initialized
INFO - 2018-03-25 19:51:41 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:51:41 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:51:41 --> Utf8 Class Initialized
INFO - 2018-03-25 19:51:41 --> URI Class Initialized
INFO - 2018-03-25 19:51:41 --> Router Class Initialized
INFO - 2018-03-25 19:51:41 --> Output Class Initialized
INFO - 2018-03-25 19:51:41 --> Security Class Initialized
DEBUG - 2018-03-25 19:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:51:41 --> Input Class Initialized
INFO - 2018-03-25 19:51:41 --> Language Class Initialized
INFO - 2018-03-25 19:51:41 --> Loader Class Initialized
INFO - 2018-03-25 19:51:41 --> Helper loaded: url_helper
INFO - 2018-03-25 19:51:41 --> Helper loaded: form_helper
INFO - 2018-03-25 19:51:41 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:51:41 --> Controller Class Initialized
INFO - 2018-03-25 19:51:41 --> Model Class Initialized
INFO - 2018-03-25 19:51:41 --> Model Class Initialized
INFO - 2018-03-25 19:51:41 --> Model Class Initialized
INFO - 2018-03-25 19:51:41 --> Model Class Initialized
INFO - 2018-03-25 19:51:41 --> Model Class Initialized
INFO - 2018-03-25 19:51:41 --> Model Class Initialized
INFO - 2018-03-25 19:51:41 --> Model Class Initialized
INFO - 2018-03-25 19:51:41 --> Model Class Initialized
INFO - 2018-03-25 19:51:41 --> Model Class Initialized
INFO - 2018-03-25 19:51:41 --> Model Class Initialized
INFO - 2018-03-25 19:51:41 --> Model Class Initialized
INFO - 2018-03-25 19:51:41 --> Model Class Initialized
INFO - 2018-03-25 19:51:41 --> Helper loaded: date_helper
INFO - 2018-03-25 19:51:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:51:59 --> Config Class Initialized
INFO - 2018-03-25 19:51:59 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:51:59 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:51:59 --> Utf8 Class Initialized
INFO - 2018-03-25 19:51:59 --> URI Class Initialized
INFO - 2018-03-25 19:51:59 --> Router Class Initialized
INFO - 2018-03-25 19:51:59 --> Output Class Initialized
INFO - 2018-03-25 19:51:59 --> Security Class Initialized
DEBUG - 2018-03-25 19:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:51:59 --> Input Class Initialized
INFO - 2018-03-25 19:51:59 --> Language Class Initialized
INFO - 2018-03-25 19:51:59 --> Loader Class Initialized
INFO - 2018-03-25 19:51:59 --> Helper loaded: url_helper
INFO - 2018-03-25 19:51:59 --> Helper loaded: form_helper
INFO - 2018-03-25 19:51:59 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:51:59 --> Controller Class Initialized
INFO - 2018-03-25 19:51:59 --> Model Class Initialized
INFO - 2018-03-25 19:51:59 --> Model Class Initialized
INFO - 2018-03-25 19:51:59 --> Model Class Initialized
INFO - 2018-03-25 19:51:59 --> Model Class Initialized
INFO - 2018-03-25 19:51:59 --> Model Class Initialized
INFO - 2018-03-25 19:51:59 --> Model Class Initialized
INFO - 2018-03-25 19:51:59 --> Model Class Initialized
INFO - 2018-03-25 19:51:59 --> Model Class Initialized
INFO - 2018-03-25 19:51:59 --> Model Class Initialized
INFO - 2018-03-25 19:51:59 --> Model Class Initialized
INFO - 2018-03-25 19:51:59 --> Model Class Initialized
INFO - 2018-03-25 19:51:59 --> Model Class Initialized
INFO - 2018-03-25 19:51:59 --> Helper loaded: date_helper
INFO - 2018-03-25 19:51:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:52:09 --> Config Class Initialized
INFO - 2018-03-25 19:52:09 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:52:09 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:52:09 --> Utf8 Class Initialized
INFO - 2018-03-25 19:52:09 --> URI Class Initialized
INFO - 2018-03-25 19:52:09 --> Router Class Initialized
INFO - 2018-03-25 19:52:09 --> Output Class Initialized
INFO - 2018-03-25 19:52:09 --> Security Class Initialized
DEBUG - 2018-03-25 19:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:52:09 --> Input Class Initialized
INFO - 2018-03-25 19:52:09 --> Language Class Initialized
INFO - 2018-03-25 19:52:09 --> Loader Class Initialized
INFO - 2018-03-25 19:52:09 --> Helper loaded: url_helper
INFO - 2018-03-25 19:52:09 --> Helper loaded: form_helper
INFO - 2018-03-25 19:52:09 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:52:09 --> Controller Class Initialized
INFO - 2018-03-25 19:52:09 --> Model Class Initialized
INFO - 2018-03-25 19:52:09 --> Model Class Initialized
INFO - 2018-03-25 19:52:09 --> Model Class Initialized
INFO - 2018-03-25 19:52:09 --> Model Class Initialized
INFO - 2018-03-25 19:52:09 --> Model Class Initialized
INFO - 2018-03-25 19:52:09 --> Model Class Initialized
INFO - 2018-03-25 19:52:09 --> Model Class Initialized
INFO - 2018-03-25 19:52:09 --> Model Class Initialized
INFO - 2018-03-25 19:52:09 --> Model Class Initialized
INFO - 2018-03-25 19:52:09 --> Model Class Initialized
INFO - 2018-03-25 19:52:09 --> Model Class Initialized
INFO - 2018-03-25 19:52:09 --> Model Class Initialized
INFO - 2018-03-25 19:52:09 --> Helper loaded: date_helper
INFO - 2018-03-25 19:52:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:52:52 --> Config Class Initialized
INFO - 2018-03-25 19:52:52 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:52:52 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:52:52 --> Utf8 Class Initialized
INFO - 2018-03-25 19:52:52 --> URI Class Initialized
INFO - 2018-03-25 19:52:52 --> Router Class Initialized
INFO - 2018-03-25 19:52:52 --> Output Class Initialized
INFO - 2018-03-25 19:52:52 --> Security Class Initialized
DEBUG - 2018-03-25 19:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:52:52 --> Input Class Initialized
INFO - 2018-03-25 19:52:52 --> Language Class Initialized
INFO - 2018-03-25 19:52:52 --> Loader Class Initialized
INFO - 2018-03-25 19:52:52 --> Helper loaded: url_helper
INFO - 2018-03-25 19:52:52 --> Helper loaded: form_helper
INFO - 2018-03-25 19:52:52 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:52:52 --> Controller Class Initialized
INFO - 2018-03-25 19:52:52 --> Model Class Initialized
INFO - 2018-03-25 19:52:52 --> Model Class Initialized
INFO - 2018-03-25 19:52:52 --> Model Class Initialized
INFO - 2018-03-25 19:52:52 --> Model Class Initialized
INFO - 2018-03-25 19:52:52 --> Model Class Initialized
INFO - 2018-03-25 19:52:52 --> Model Class Initialized
INFO - 2018-03-25 19:52:52 --> Model Class Initialized
INFO - 2018-03-25 19:52:52 --> Model Class Initialized
INFO - 2018-03-25 19:52:52 --> Model Class Initialized
INFO - 2018-03-25 19:52:52 --> Model Class Initialized
INFO - 2018-03-25 19:52:52 --> Model Class Initialized
INFO - 2018-03-25 19:52:52 --> Model Class Initialized
INFO - 2018-03-25 19:52:52 --> Helper loaded: date_helper
INFO - 2018-03-25 19:52:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:54:03 --> Config Class Initialized
INFO - 2018-03-25 19:54:03 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:54:03 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:54:03 --> Utf8 Class Initialized
INFO - 2018-03-25 19:54:03 --> URI Class Initialized
INFO - 2018-03-25 19:54:03 --> Router Class Initialized
INFO - 2018-03-25 19:54:03 --> Output Class Initialized
INFO - 2018-03-25 19:54:03 --> Security Class Initialized
DEBUG - 2018-03-25 19:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:54:03 --> Input Class Initialized
INFO - 2018-03-25 19:54:03 --> Language Class Initialized
INFO - 2018-03-25 19:54:03 --> Loader Class Initialized
INFO - 2018-03-25 19:54:03 --> Helper loaded: url_helper
INFO - 2018-03-25 19:54:03 --> Helper loaded: form_helper
INFO - 2018-03-25 19:54:03 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:54:03 --> Controller Class Initialized
INFO - 2018-03-25 19:54:03 --> Model Class Initialized
INFO - 2018-03-25 19:54:03 --> Model Class Initialized
INFO - 2018-03-25 19:54:03 --> Model Class Initialized
INFO - 2018-03-25 19:54:03 --> Model Class Initialized
INFO - 2018-03-25 19:54:03 --> Model Class Initialized
INFO - 2018-03-25 19:54:03 --> Model Class Initialized
INFO - 2018-03-25 19:54:03 --> Model Class Initialized
INFO - 2018-03-25 19:54:03 --> Model Class Initialized
INFO - 2018-03-25 19:54:03 --> Model Class Initialized
INFO - 2018-03-25 19:54:03 --> Model Class Initialized
INFO - 2018-03-25 19:54:03 --> Model Class Initialized
INFO - 2018-03-25 19:54:03 --> Model Class Initialized
INFO - 2018-03-25 19:54:03 --> Helper loaded: date_helper
INFO - 2018-03-25 19:54:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:54:21 --> Config Class Initialized
INFO - 2018-03-25 19:54:21 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:54:21 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:54:21 --> Utf8 Class Initialized
INFO - 2018-03-25 19:54:21 --> URI Class Initialized
INFO - 2018-03-25 19:54:21 --> Router Class Initialized
INFO - 2018-03-25 19:54:21 --> Output Class Initialized
INFO - 2018-03-25 19:54:21 --> Security Class Initialized
DEBUG - 2018-03-25 19:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:54:21 --> Input Class Initialized
INFO - 2018-03-25 19:54:21 --> Language Class Initialized
INFO - 2018-03-25 19:54:21 --> Loader Class Initialized
INFO - 2018-03-25 19:54:21 --> Helper loaded: url_helper
INFO - 2018-03-25 19:54:21 --> Helper loaded: form_helper
INFO - 2018-03-25 19:54:21 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:54:21 --> Controller Class Initialized
INFO - 2018-03-25 19:54:21 --> Model Class Initialized
INFO - 2018-03-25 19:54:21 --> Model Class Initialized
INFO - 2018-03-25 19:54:21 --> Model Class Initialized
INFO - 2018-03-25 19:54:21 --> Model Class Initialized
INFO - 2018-03-25 19:54:21 --> Model Class Initialized
INFO - 2018-03-25 19:54:21 --> Model Class Initialized
INFO - 2018-03-25 19:54:21 --> Model Class Initialized
INFO - 2018-03-25 19:54:21 --> Model Class Initialized
INFO - 2018-03-25 19:54:21 --> Model Class Initialized
INFO - 2018-03-25 19:54:21 --> Model Class Initialized
INFO - 2018-03-25 19:54:21 --> Model Class Initialized
INFO - 2018-03-25 19:54:22 --> Model Class Initialized
INFO - 2018-03-25 19:54:22 --> Helper loaded: date_helper
INFO - 2018-03-25 19:54:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:54:46 --> Config Class Initialized
INFO - 2018-03-25 19:54:46 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:54:46 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:54:46 --> Utf8 Class Initialized
INFO - 2018-03-25 19:54:46 --> URI Class Initialized
INFO - 2018-03-25 19:54:46 --> Router Class Initialized
INFO - 2018-03-25 19:54:46 --> Output Class Initialized
INFO - 2018-03-25 19:54:46 --> Security Class Initialized
DEBUG - 2018-03-25 19:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:54:46 --> Input Class Initialized
INFO - 2018-03-25 19:54:46 --> Language Class Initialized
INFO - 2018-03-25 19:54:46 --> Loader Class Initialized
INFO - 2018-03-25 19:54:46 --> Helper loaded: url_helper
INFO - 2018-03-25 19:54:46 --> Helper loaded: form_helper
INFO - 2018-03-25 19:54:46 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:54:46 --> Controller Class Initialized
INFO - 2018-03-25 19:54:46 --> Model Class Initialized
INFO - 2018-03-25 19:54:46 --> Model Class Initialized
INFO - 2018-03-25 19:54:46 --> Model Class Initialized
INFO - 2018-03-25 19:54:46 --> Model Class Initialized
INFO - 2018-03-25 19:54:46 --> Model Class Initialized
INFO - 2018-03-25 19:54:46 --> Model Class Initialized
INFO - 2018-03-25 19:54:46 --> Model Class Initialized
INFO - 2018-03-25 19:54:46 --> Model Class Initialized
INFO - 2018-03-25 19:54:46 --> Model Class Initialized
INFO - 2018-03-25 19:54:46 --> Model Class Initialized
INFO - 2018-03-25 19:54:46 --> Model Class Initialized
INFO - 2018-03-25 19:54:46 --> Model Class Initialized
INFO - 2018-03-25 19:54:46 --> Helper loaded: date_helper
INFO - 2018-03-25 19:54:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:55:01 --> Config Class Initialized
INFO - 2018-03-25 19:55:01 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:55:01 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:55:01 --> Utf8 Class Initialized
INFO - 2018-03-25 19:55:01 --> URI Class Initialized
INFO - 2018-03-25 19:55:01 --> Router Class Initialized
INFO - 2018-03-25 19:55:01 --> Output Class Initialized
INFO - 2018-03-25 19:55:01 --> Security Class Initialized
DEBUG - 2018-03-25 19:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:55:01 --> Input Class Initialized
INFO - 2018-03-25 19:55:01 --> Language Class Initialized
INFO - 2018-03-25 19:55:01 --> Loader Class Initialized
INFO - 2018-03-25 19:55:01 --> Helper loaded: url_helper
INFO - 2018-03-25 19:55:01 --> Helper loaded: form_helper
INFO - 2018-03-25 19:55:01 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:55:01 --> Controller Class Initialized
INFO - 2018-03-25 19:55:01 --> Model Class Initialized
INFO - 2018-03-25 19:55:01 --> Model Class Initialized
INFO - 2018-03-25 19:55:01 --> Model Class Initialized
INFO - 2018-03-25 19:55:01 --> Model Class Initialized
INFO - 2018-03-25 19:55:01 --> Model Class Initialized
INFO - 2018-03-25 19:55:01 --> Model Class Initialized
INFO - 2018-03-25 19:55:01 --> Model Class Initialized
INFO - 2018-03-25 19:55:01 --> Model Class Initialized
INFO - 2018-03-25 19:55:01 --> Model Class Initialized
INFO - 2018-03-25 19:55:01 --> Model Class Initialized
INFO - 2018-03-25 19:55:01 --> Model Class Initialized
INFO - 2018-03-25 19:55:01 --> Model Class Initialized
INFO - 2018-03-25 19:55:01 --> Helper loaded: date_helper
INFO - 2018-03-25 19:55:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:55:32 --> Config Class Initialized
INFO - 2018-03-25 19:55:32 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:55:32 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:55:32 --> Utf8 Class Initialized
INFO - 2018-03-25 19:55:32 --> URI Class Initialized
INFO - 2018-03-25 19:55:32 --> Router Class Initialized
INFO - 2018-03-25 19:55:32 --> Output Class Initialized
INFO - 2018-03-25 19:55:32 --> Security Class Initialized
DEBUG - 2018-03-25 19:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:55:32 --> Input Class Initialized
INFO - 2018-03-25 19:55:32 --> Language Class Initialized
INFO - 2018-03-25 19:55:32 --> Loader Class Initialized
INFO - 2018-03-25 19:55:32 --> Helper loaded: url_helper
INFO - 2018-03-25 19:55:32 --> Helper loaded: form_helper
INFO - 2018-03-25 19:55:32 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:55:32 --> Controller Class Initialized
INFO - 2018-03-25 19:55:32 --> Model Class Initialized
INFO - 2018-03-25 19:55:32 --> Model Class Initialized
INFO - 2018-03-25 19:55:32 --> Model Class Initialized
INFO - 2018-03-25 19:55:32 --> Model Class Initialized
INFO - 2018-03-25 19:55:32 --> Model Class Initialized
INFO - 2018-03-25 19:55:32 --> Model Class Initialized
INFO - 2018-03-25 19:55:32 --> Model Class Initialized
INFO - 2018-03-25 19:55:32 --> Model Class Initialized
INFO - 2018-03-25 19:55:32 --> Model Class Initialized
INFO - 2018-03-25 19:55:32 --> Model Class Initialized
INFO - 2018-03-25 19:55:32 --> Model Class Initialized
INFO - 2018-03-25 19:55:32 --> Model Class Initialized
INFO - 2018-03-25 19:55:32 --> Helper loaded: date_helper
INFO - 2018-03-25 19:55:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:56:00 --> Config Class Initialized
INFO - 2018-03-25 19:56:00 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:56:00 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:56:00 --> Utf8 Class Initialized
INFO - 2018-03-25 19:56:00 --> URI Class Initialized
INFO - 2018-03-25 19:56:00 --> Router Class Initialized
INFO - 2018-03-25 19:56:00 --> Output Class Initialized
INFO - 2018-03-25 19:56:00 --> Security Class Initialized
DEBUG - 2018-03-25 19:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:56:00 --> Input Class Initialized
INFO - 2018-03-25 19:56:00 --> Language Class Initialized
INFO - 2018-03-25 19:56:00 --> Loader Class Initialized
INFO - 2018-03-25 19:56:00 --> Helper loaded: url_helper
INFO - 2018-03-25 19:56:00 --> Helper loaded: form_helper
INFO - 2018-03-25 19:56:00 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:56:00 --> Controller Class Initialized
INFO - 2018-03-25 19:56:00 --> Model Class Initialized
INFO - 2018-03-25 19:56:00 --> Model Class Initialized
INFO - 2018-03-25 19:56:00 --> Model Class Initialized
INFO - 2018-03-25 19:56:00 --> Model Class Initialized
INFO - 2018-03-25 19:56:00 --> Model Class Initialized
INFO - 2018-03-25 19:56:00 --> Model Class Initialized
INFO - 2018-03-25 19:56:00 --> Model Class Initialized
INFO - 2018-03-25 19:56:00 --> Model Class Initialized
INFO - 2018-03-25 19:56:00 --> Model Class Initialized
INFO - 2018-03-25 19:56:00 --> Model Class Initialized
INFO - 2018-03-25 19:56:00 --> Model Class Initialized
INFO - 2018-03-25 19:56:00 --> Model Class Initialized
INFO - 2018-03-25 19:56:00 --> Helper loaded: date_helper
INFO - 2018-03-25 19:56:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:59:34 --> Config Class Initialized
INFO - 2018-03-25 19:59:34 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:59:34 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:59:34 --> Utf8 Class Initialized
INFO - 2018-03-25 19:59:34 --> URI Class Initialized
INFO - 2018-03-25 19:59:34 --> Router Class Initialized
INFO - 2018-03-25 19:59:34 --> Output Class Initialized
INFO - 2018-03-25 19:59:34 --> Security Class Initialized
DEBUG - 2018-03-25 19:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:59:34 --> Input Class Initialized
INFO - 2018-03-25 19:59:34 --> Language Class Initialized
INFO - 2018-03-25 19:59:34 --> Loader Class Initialized
INFO - 2018-03-25 19:59:34 --> Helper loaded: url_helper
INFO - 2018-03-25 19:59:34 --> Helper loaded: form_helper
INFO - 2018-03-25 19:59:34 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:59:34 --> Controller Class Initialized
INFO - 2018-03-25 19:59:34 --> Model Class Initialized
INFO - 2018-03-25 19:59:34 --> Model Class Initialized
INFO - 2018-03-25 19:59:34 --> Model Class Initialized
INFO - 2018-03-25 19:59:34 --> Model Class Initialized
INFO - 2018-03-25 19:59:34 --> Model Class Initialized
INFO - 2018-03-25 19:59:34 --> Model Class Initialized
INFO - 2018-03-25 19:59:34 --> Model Class Initialized
INFO - 2018-03-25 19:59:34 --> Model Class Initialized
INFO - 2018-03-25 19:59:34 --> Model Class Initialized
INFO - 2018-03-25 19:59:34 --> Model Class Initialized
INFO - 2018-03-25 19:59:34 --> Model Class Initialized
INFO - 2018-03-25 19:59:34 --> Model Class Initialized
INFO - 2018-03-25 19:59:34 --> Helper loaded: date_helper
INFO - 2018-03-25 19:59:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 19:59:51 --> Config Class Initialized
INFO - 2018-03-25 19:59:51 --> Hooks Class Initialized
DEBUG - 2018-03-25 19:59:51 --> UTF-8 Support Enabled
INFO - 2018-03-25 19:59:51 --> Utf8 Class Initialized
INFO - 2018-03-25 19:59:51 --> URI Class Initialized
INFO - 2018-03-25 19:59:51 --> Router Class Initialized
INFO - 2018-03-25 19:59:51 --> Output Class Initialized
INFO - 2018-03-25 19:59:51 --> Security Class Initialized
DEBUG - 2018-03-25 19:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 19:59:51 --> Input Class Initialized
INFO - 2018-03-25 19:59:51 --> Language Class Initialized
INFO - 2018-03-25 19:59:51 --> Loader Class Initialized
INFO - 2018-03-25 19:59:51 --> Helper loaded: url_helper
INFO - 2018-03-25 19:59:51 --> Helper loaded: form_helper
INFO - 2018-03-25 19:59:51 --> Database Driver Class Initialized
DEBUG - 2018-03-25 19:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 19:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 19:59:51 --> Controller Class Initialized
INFO - 2018-03-25 19:59:51 --> Model Class Initialized
INFO - 2018-03-25 19:59:51 --> Model Class Initialized
INFO - 2018-03-25 19:59:51 --> Model Class Initialized
INFO - 2018-03-25 19:59:51 --> Model Class Initialized
INFO - 2018-03-25 19:59:51 --> Model Class Initialized
INFO - 2018-03-25 19:59:51 --> Model Class Initialized
INFO - 2018-03-25 19:59:51 --> Model Class Initialized
INFO - 2018-03-25 19:59:51 --> Model Class Initialized
INFO - 2018-03-25 19:59:51 --> Model Class Initialized
INFO - 2018-03-25 19:59:51 --> Model Class Initialized
INFO - 2018-03-25 19:59:51 --> Model Class Initialized
INFO - 2018-03-25 19:59:51 --> Model Class Initialized
INFO - 2018-03-25 19:59:51 --> Helper loaded: date_helper
INFO - 2018-03-25 19:59:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 20:00:14 --> Config Class Initialized
INFO - 2018-03-25 20:00:14 --> Hooks Class Initialized
DEBUG - 2018-03-25 20:00:14 --> UTF-8 Support Enabled
INFO - 2018-03-25 20:00:14 --> Utf8 Class Initialized
INFO - 2018-03-25 20:00:14 --> URI Class Initialized
INFO - 2018-03-25 20:00:14 --> Router Class Initialized
INFO - 2018-03-25 20:00:14 --> Output Class Initialized
INFO - 2018-03-25 20:00:14 --> Security Class Initialized
DEBUG - 2018-03-25 20:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 20:00:14 --> Input Class Initialized
INFO - 2018-03-25 20:00:14 --> Language Class Initialized
INFO - 2018-03-25 20:00:14 --> Loader Class Initialized
INFO - 2018-03-25 20:00:14 --> Helper loaded: url_helper
INFO - 2018-03-25 20:00:14 --> Helper loaded: form_helper
INFO - 2018-03-25 20:00:14 --> Database Driver Class Initialized
DEBUG - 2018-03-25 20:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 20:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 20:00:14 --> Controller Class Initialized
INFO - 2018-03-25 20:00:14 --> Model Class Initialized
INFO - 2018-03-25 20:00:14 --> Model Class Initialized
INFO - 2018-03-25 20:00:14 --> Model Class Initialized
INFO - 2018-03-25 20:00:14 --> Model Class Initialized
INFO - 2018-03-25 20:00:14 --> Model Class Initialized
INFO - 2018-03-25 20:00:14 --> Model Class Initialized
INFO - 2018-03-25 20:00:14 --> Model Class Initialized
INFO - 2018-03-25 20:00:14 --> Model Class Initialized
INFO - 2018-03-25 20:00:14 --> Model Class Initialized
INFO - 2018-03-25 20:00:14 --> Model Class Initialized
INFO - 2018-03-25 20:00:14 --> Model Class Initialized
INFO - 2018-03-25 20:00:14 --> Model Class Initialized
INFO - 2018-03-25 20:00:14 --> Helper loaded: date_helper
INFO - 2018-03-25 20:00:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 20:00:35 --> Config Class Initialized
INFO - 2018-03-25 20:00:35 --> Hooks Class Initialized
DEBUG - 2018-03-25 20:00:35 --> UTF-8 Support Enabled
INFO - 2018-03-25 20:00:35 --> Utf8 Class Initialized
INFO - 2018-03-25 20:00:35 --> URI Class Initialized
INFO - 2018-03-25 20:00:35 --> Router Class Initialized
INFO - 2018-03-25 20:00:35 --> Output Class Initialized
INFO - 2018-03-25 20:00:35 --> Security Class Initialized
DEBUG - 2018-03-25 20:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 20:00:35 --> Input Class Initialized
INFO - 2018-03-25 20:00:35 --> Language Class Initialized
INFO - 2018-03-25 20:00:35 --> Loader Class Initialized
INFO - 2018-03-25 20:00:35 --> Helper loaded: url_helper
INFO - 2018-03-25 20:00:35 --> Helper loaded: form_helper
INFO - 2018-03-25 20:00:35 --> Database Driver Class Initialized
DEBUG - 2018-03-25 20:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 20:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 20:00:35 --> Controller Class Initialized
INFO - 2018-03-25 20:00:35 --> Model Class Initialized
INFO - 2018-03-25 20:00:35 --> Model Class Initialized
INFO - 2018-03-25 20:00:35 --> Model Class Initialized
INFO - 2018-03-25 20:00:35 --> Model Class Initialized
INFO - 2018-03-25 20:00:35 --> Model Class Initialized
INFO - 2018-03-25 20:00:35 --> Model Class Initialized
INFO - 2018-03-25 20:00:35 --> Model Class Initialized
INFO - 2018-03-25 20:00:35 --> Model Class Initialized
INFO - 2018-03-25 20:00:35 --> Model Class Initialized
INFO - 2018-03-25 20:00:35 --> Model Class Initialized
INFO - 2018-03-25 20:00:35 --> Model Class Initialized
INFO - 2018-03-25 20:00:35 --> Model Class Initialized
INFO - 2018-03-25 20:00:35 --> Helper loaded: date_helper
INFO - 2018-03-25 20:00:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 20:00:47 --> Config Class Initialized
INFO - 2018-03-25 20:00:47 --> Hooks Class Initialized
DEBUG - 2018-03-25 20:00:47 --> UTF-8 Support Enabled
INFO - 2018-03-25 20:00:47 --> Utf8 Class Initialized
INFO - 2018-03-25 20:00:47 --> URI Class Initialized
INFO - 2018-03-25 20:00:47 --> Router Class Initialized
INFO - 2018-03-25 20:00:47 --> Output Class Initialized
INFO - 2018-03-25 20:00:47 --> Security Class Initialized
DEBUG - 2018-03-25 20:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 20:00:47 --> Input Class Initialized
INFO - 2018-03-25 20:00:47 --> Language Class Initialized
INFO - 2018-03-25 20:00:47 --> Loader Class Initialized
INFO - 2018-03-25 20:00:47 --> Helper loaded: url_helper
INFO - 2018-03-25 20:00:47 --> Helper loaded: form_helper
INFO - 2018-03-25 20:00:47 --> Database Driver Class Initialized
DEBUG - 2018-03-25 20:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 20:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 20:00:47 --> Controller Class Initialized
INFO - 2018-03-25 20:00:47 --> Model Class Initialized
INFO - 2018-03-25 20:00:47 --> Model Class Initialized
INFO - 2018-03-25 20:00:47 --> Model Class Initialized
INFO - 2018-03-25 20:00:47 --> Model Class Initialized
INFO - 2018-03-25 20:00:47 --> Model Class Initialized
INFO - 2018-03-25 20:00:47 --> Model Class Initialized
INFO - 2018-03-25 20:00:47 --> Model Class Initialized
INFO - 2018-03-25 20:00:47 --> Model Class Initialized
INFO - 2018-03-25 20:00:47 --> Model Class Initialized
INFO - 2018-03-25 20:00:47 --> Model Class Initialized
INFO - 2018-03-25 20:00:47 --> Model Class Initialized
INFO - 2018-03-25 20:00:47 --> Model Class Initialized
INFO - 2018-03-25 20:00:47 --> Helper loaded: date_helper
INFO - 2018-03-25 20:00:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 20:00:57 --> Config Class Initialized
INFO - 2018-03-25 20:00:57 --> Hooks Class Initialized
DEBUG - 2018-03-25 20:00:57 --> UTF-8 Support Enabled
INFO - 2018-03-25 20:00:57 --> Utf8 Class Initialized
INFO - 2018-03-25 20:00:57 --> URI Class Initialized
INFO - 2018-03-25 20:00:57 --> Router Class Initialized
INFO - 2018-03-25 20:00:57 --> Output Class Initialized
INFO - 2018-03-25 20:00:57 --> Security Class Initialized
DEBUG - 2018-03-25 20:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 20:00:57 --> Input Class Initialized
INFO - 2018-03-25 20:00:57 --> Language Class Initialized
INFO - 2018-03-25 20:00:57 --> Loader Class Initialized
INFO - 2018-03-25 20:00:57 --> Helper loaded: url_helper
INFO - 2018-03-25 20:00:57 --> Helper loaded: form_helper
INFO - 2018-03-25 20:00:57 --> Database Driver Class Initialized
DEBUG - 2018-03-25 20:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 20:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 20:00:57 --> Controller Class Initialized
INFO - 2018-03-25 20:00:57 --> Model Class Initialized
INFO - 2018-03-25 20:00:57 --> Model Class Initialized
INFO - 2018-03-25 20:00:57 --> Model Class Initialized
INFO - 2018-03-25 20:00:57 --> Model Class Initialized
INFO - 2018-03-25 20:00:57 --> Model Class Initialized
INFO - 2018-03-25 20:00:57 --> Model Class Initialized
INFO - 2018-03-25 20:00:57 --> Model Class Initialized
INFO - 2018-03-25 20:00:57 --> Model Class Initialized
INFO - 2018-03-25 20:00:57 --> Model Class Initialized
INFO - 2018-03-25 20:00:57 --> Model Class Initialized
INFO - 2018-03-25 20:00:57 --> Model Class Initialized
INFO - 2018-03-25 20:00:57 --> Model Class Initialized
INFO - 2018-03-25 20:00:57 --> Helper loaded: date_helper
INFO - 2018-03-25 20:00:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 20:01:03 --> Config Class Initialized
INFO - 2018-03-25 20:01:03 --> Hooks Class Initialized
DEBUG - 2018-03-25 20:01:03 --> UTF-8 Support Enabled
INFO - 2018-03-25 20:01:03 --> Utf8 Class Initialized
INFO - 2018-03-25 20:01:03 --> URI Class Initialized
INFO - 2018-03-25 20:01:03 --> Router Class Initialized
INFO - 2018-03-25 20:01:03 --> Output Class Initialized
INFO - 2018-03-25 20:01:03 --> Security Class Initialized
DEBUG - 2018-03-25 20:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 20:01:03 --> Input Class Initialized
INFO - 2018-03-25 20:01:03 --> Language Class Initialized
INFO - 2018-03-25 20:01:03 --> Loader Class Initialized
INFO - 2018-03-25 20:01:03 --> Helper loaded: url_helper
INFO - 2018-03-25 20:01:03 --> Helper loaded: form_helper
INFO - 2018-03-25 20:01:03 --> Database Driver Class Initialized
DEBUG - 2018-03-25 20:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 20:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 20:01:03 --> Controller Class Initialized
INFO - 2018-03-25 20:01:03 --> Model Class Initialized
INFO - 2018-03-25 20:01:03 --> Model Class Initialized
INFO - 2018-03-25 20:01:03 --> Model Class Initialized
INFO - 2018-03-25 20:01:03 --> Model Class Initialized
INFO - 2018-03-25 20:01:03 --> Model Class Initialized
INFO - 2018-03-25 20:01:03 --> Model Class Initialized
INFO - 2018-03-25 20:01:03 --> Model Class Initialized
INFO - 2018-03-25 20:01:03 --> Model Class Initialized
INFO - 2018-03-25 20:01:03 --> Model Class Initialized
INFO - 2018-03-25 20:01:03 --> Model Class Initialized
INFO - 2018-03-25 20:01:03 --> Model Class Initialized
INFO - 2018-03-25 20:01:03 --> Model Class Initialized
INFO - 2018-03-25 20:01:03 --> Helper loaded: date_helper
INFO - 2018-03-25 20:01:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 20:01:10 --> Config Class Initialized
INFO - 2018-03-25 20:01:10 --> Hooks Class Initialized
DEBUG - 2018-03-25 20:01:10 --> UTF-8 Support Enabled
INFO - 2018-03-25 20:01:10 --> Utf8 Class Initialized
INFO - 2018-03-25 20:01:10 --> URI Class Initialized
INFO - 2018-03-25 20:01:10 --> Router Class Initialized
INFO - 2018-03-25 20:01:10 --> Output Class Initialized
INFO - 2018-03-25 20:01:10 --> Security Class Initialized
DEBUG - 2018-03-25 20:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 20:01:10 --> Input Class Initialized
INFO - 2018-03-25 20:01:10 --> Language Class Initialized
INFO - 2018-03-25 20:01:10 --> Loader Class Initialized
INFO - 2018-03-25 20:01:10 --> Helper loaded: url_helper
INFO - 2018-03-25 20:01:10 --> Helper loaded: form_helper
INFO - 2018-03-25 20:01:10 --> Database Driver Class Initialized
DEBUG - 2018-03-25 20:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 20:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 20:01:10 --> Controller Class Initialized
INFO - 2018-03-25 20:01:10 --> Model Class Initialized
INFO - 2018-03-25 20:01:10 --> Model Class Initialized
INFO - 2018-03-25 20:01:10 --> Model Class Initialized
INFO - 2018-03-25 20:01:10 --> Model Class Initialized
INFO - 2018-03-25 20:01:10 --> Model Class Initialized
INFO - 2018-03-25 20:01:10 --> Model Class Initialized
INFO - 2018-03-25 20:01:10 --> Model Class Initialized
INFO - 2018-03-25 20:01:10 --> Model Class Initialized
INFO - 2018-03-25 20:01:10 --> Model Class Initialized
INFO - 2018-03-25 20:01:10 --> Model Class Initialized
INFO - 2018-03-25 20:01:10 --> Model Class Initialized
INFO - 2018-03-25 20:01:10 --> Model Class Initialized
INFO - 2018-03-25 20:01:10 --> Helper loaded: date_helper
INFO - 2018-03-25 20:01:10 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 20:01:22 --> Config Class Initialized
INFO - 2018-03-25 20:01:22 --> Hooks Class Initialized
DEBUG - 2018-03-25 20:01:22 --> UTF-8 Support Enabled
INFO - 2018-03-25 20:01:22 --> Utf8 Class Initialized
INFO - 2018-03-25 20:01:22 --> URI Class Initialized
INFO - 2018-03-25 20:01:22 --> Router Class Initialized
INFO - 2018-03-25 20:01:22 --> Output Class Initialized
INFO - 2018-03-25 20:01:22 --> Security Class Initialized
DEBUG - 2018-03-25 20:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 20:01:22 --> Input Class Initialized
INFO - 2018-03-25 20:01:22 --> Language Class Initialized
INFO - 2018-03-25 20:01:22 --> Loader Class Initialized
INFO - 2018-03-25 20:01:22 --> Helper loaded: url_helper
INFO - 2018-03-25 20:01:22 --> Helper loaded: form_helper
INFO - 2018-03-25 20:01:22 --> Database Driver Class Initialized
DEBUG - 2018-03-25 20:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 20:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 20:01:22 --> Controller Class Initialized
INFO - 2018-03-25 20:01:22 --> Model Class Initialized
INFO - 2018-03-25 20:01:22 --> Model Class Initialized
INFO - 2018-03-25 20:01:22 --> Model Class Initialized
INFO - 2018-03-25 20:01:22 --> Model Class Initialized
INFO - 2018-03-25 20:01:22 --> Model Class Initialized
INFO - 2018-03-25 20:01:22 --> Model Class Initialized
INFO - 2018-03-25 20:01:22 --> Model Class Initialized
INFO - 2018-03-25 20:01:22 --> Model Class Initialized
INFO - 2018-03-25 20:01:22 --> Model Class Initialized
INFO - 2018-03-25 20:01:22 --> Model Class Initialized
INFO - 2018-03-25 20:01:22 --> Model Class Initialized
INFO - 2018-03-25 20:01:22 --> Model Class Initialized
INFO - 2018-03-25 20:01:22 --> Helper loaded: date_helper
INFO - 2018-03-25 20:01:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 20:01:52 --> Config Class Initialized
INFO - 2018-03-25 20:01:52 --> Hooks Class Initialized
DEBUG - 2018-03-25 20:01:52 --> UTF-8 Support Enabled
INFO - 2018-03-25 20:01:52 --> Utf8 Class Initialized
INFO - 2018-03-25 20:01:52 --> URI Class Initialized
INFO - 2018-03-25 20:01:52 --> Router Class Initialized
INFO - 2018-03-25 20:01:52 --> Output Class Initialized
INFO - 2018-03-25 20:01:52 --> Security Class Initialized
DEBUG - 2018-03-25 20:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 20:01:52 --> Input Class Initialized
INFO - 2018-03-25 20:01:52 --> Language Class Initialized
INFO - 2018-03-25 20:01:52 --> Loader Class Initialized
INFO - 2018-03-25 20:01:52 --> Helper loaded: url_helper
INFO - 2018-03-25 20:01:52 --> Helper loaded: form_helper
INFO - 2018-03-25 20:01:52 --> Database Driver Class Initialized
DEBUG - 2018-03-25 20:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 20:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 20:01:52 --> Controller Class Initialized
INFO - 2018-03-25 20:01:52 --> Model Class Initialized
INFO - 2018-03-25 20:01:52 --> Model Class Initialized
INFO - 2018-03-25 20:01:52 --> Model Class Initialized
INFO - 2018-03-25 20:01:52 --> Model Class Initialized
INFO - 2018-03-25 20:01:52 --> Model Class Initialized
INFO - 2018-03-25 20:01:52 --> Model Class Initialized
INFO - 2018-03-25 20:01:52 --> Model Class Initialized
INFO - 2018-03-25 20:01:52 --> Model Class Initialized
INFO - 2018-03-25 20:01:52 --> Model Class Initialized
INFO - 2018-03-25 20:01:52 --> Model Class Initialized
INFO - 2018-03-25 20:01:52 --> Model Class Initialized
INFO - 2018-03-25 20:01:52 --> Model Class Initialized
INFO - 2018-03-25 20:01:52 --> Helper loaded: date_helper
INFO - 2018-03-25 20:01:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-25 20:01:59 --> Config Class Initialized
INFO - 2018-03-25 20:01:59 --> Hooks Class Initialized
DEBUG - 2018-03-25 20:02:00 --> UTF-8 Support Enabled
INFO - 2018-03-25 20:02:00 --> Utf8 Class Initialized
INFO - 2018-03-25 20:02:00 --> URI Class Initialized
INFO - 2018-03-25 20:02:00 --> Router Class Initialized
INFO - 2018-03-25 20:02:00 --> Output Class Initialized
INFO - 2018-03-25 20:02:00 --> Security Class Initialized
DEBUG - 2018-03-25 20:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-25 20:02:00 --> Input Class Initialized
INFO - 2018-03-25 20:02:00 --> Language Class Initialized
INFO - 2018-03-25 20:02:00 --> Loader Class Initialized
INFO - 2018-03-25 20:02:00 --> Helper loaded: url_helper
INFO - 2018-03-25 20:02:00 --> Helper loaded: form_helper
INFO - 2018-03-25 20:02:00 --> Database Driver Class Initialized
DEBUG - 2018-03-25 20:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-25 20:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-25 20:02:00 --> Controller Class Initialized
INFO - 2018-03-25 20:02:00 --> Model Class Initialized
INFO - 2018-03-25 20:02:00 --> Model Class Initialized
INFO - 2018-03-25 20:02:00 --> Model Class Initialized
INFO - 2018-03-25 20:02:00 --> Model Class Initialized
INFO - 2018-03-25 20:02:00 --> Model Class Initialized
INFO - 2018-03-25 20:02:00 --> Model Class Initialized
INFO - 2018-03-25 20:02:00 --> Model Class Initialized
INFO - 2018-03-25 20:02:00 --> Model Class Initialized
INFO - 2018-03-25 20:02:00 --> Model Class Initialized
INFO - 2018-03-25 20:02:00 --> Model Class Initialized
INFO - 2018-03-25 20:02:00 --> Model Class Initialized
INFO - 2018-03-25 20:02:00 --> Model Class Initialized
INFO - 2018-03-25 20:02:00 --> Helper loaded: date_helper
INFO - 2018-03-25 20:02:00 --> Helper loaded: tanggal_helper
