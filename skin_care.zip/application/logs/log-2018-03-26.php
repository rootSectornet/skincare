<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-26 00:00:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:00:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:00:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:00:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:00:22 --> Final output sent to browser
DEBUG - 2018-03-26 00:00:22 --> Total execution time: 0.1123
INFO - 2018-03-26 00:00:48 --> Final output sent to browser
DEBUG - 2018-03-26 00:00:48 --> Total execution time: 0.1363
INFO - 2018-03-26 00:00:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:00:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:00:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-26 00:00:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:00:50 --> Final output sent to browser
DEBUG - 2018-03-26 00:00:50 --> Total execution time: 0.1252
INFO - 2018-03-26 00:00:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:00:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:00:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:00:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:00:56 --> Final output sent to browser
DEBUG - 2018-03-26 00:00:56 --> Total execution time: 0.1556
INFO - 2018-03-26 00:03:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:03:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:03:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:03:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:03:21 --> Final output sent to browser
DEBUG - 2018-03-26 00:03:21 --> Total execution time: 0.1190
INFO - 2018-03-26 00:06:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:06:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:06:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:06:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:06:49 --> Final output sent to browser
DEBUG - 2018-03-26 00:06:49 --> Total execution time: 0.1152
INFO - 2018-03-26 00:07:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:07:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:07:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:07:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:07:04 --> Final output sent to browser
DEBUG - 2018-03-26 00:07:04 --> Total execution time: 0.1681
INFO - 2018-03-26 00:07:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:07:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:07:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:07:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:07:13 --> Final output sent to browser
DEBUG - 2018-03-26 00:07:13 --> Total execution time: 0.1615
INFO - 2018-03-26 00:07:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:07:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:07:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:07:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:07:23 --> Final output sent to browser
DEBUG - 2018-03-26 00:07:23 --> Total execution time: 0.1259
INFO - 2018-03-26 00:08:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:08:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:08:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:08:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:08:08 --> Final output sent to browser
DEBUG - 2018-03-26 00:08:08 --> Total execution time: 0.1215
INFO - 2018-03-26 00:11:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:11:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:11:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:11:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:11:22 --> Final output sent to browser
DEBUG - 2018-03-26 00:11:23 --> Total execution time: 0.1344
INFO - 2018-03-26 00:11:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:11:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:11:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:11:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:11:37 --> Final output sent to browser
DEBUG - 2018-03-26 00:11:37 --> Total execution time: 0.1167
INFO - 2018-03-26 00:13:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:13:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:13:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:13:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:13:15 --> Final output sent to browser
DEBUG - 2018-03-26 00:13:15 --> Total execution time: 0.1188
INFO - 2018-03-26 00:13:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:13:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:13:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:13:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:13:22 --> Final output sent to browser
DEBUG - 2018-03-26 00:13:22 --> Total execution time: 0.1381
INFO - 2018-03-26 00:14:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:14:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:14:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:14:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:14:12 --> Final output sent to browser
DEBUG - 2018-03-26 00:14:12 --> Total execution time: 0.1062
INFO - 2018-03-26 00:14:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:14:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:14:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:14:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:14:24 --> Final output sent to browser
DEBUG - 2018-03-26 00:14:24 --> Total execution time: 0.1265
INFO - 2018-03-26 00:14:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:14:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:14:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:14:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:14:35 --> Final output sent to browser
DEBUG - 2018-03-26 00:14:35 --> Total execution time: 0.1384
INFO - 2018-03-26 00:14:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:14:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:14:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:14:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:14:59 --> Final output sent to browser
DEBUG - 2018-03-26 00:14:59 --> Total execution time: 0.1100
INFO - 2018-03-26 00:15:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:15:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:15:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:15:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:15:45 --> Final output sent to browser
DEBUG - 2018-03-26 00:15:45 --> Total execution time: 0.1653
INFO - 2018-03-26 00:17:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:17:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:17:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:17:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:17:04 --> Final output sent to browser
DEBUG - 2018-03-26 00:17:04 --> Total execution time: 0.1050
INFO - 2018-03-26 00:26:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:26:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:26:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:26:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:26:03 --> Final output sent to browser
DEBUG - 2018-03-26 00:26:03 --> Total execution time: 0.1592
INFO - 2018-03-26 00:26:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:26:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:26:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:26:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:26:16 --> Final output sent to browser
DEBUG - 2018-03-26 00:26:16 --> Total execution time: 0.1552
INFO - 2018-03-26 00:27:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:27:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:27:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-26 00:27:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:27:14 --> Final output sent to browser
DEBUG - 2018-03-26 00:27:14 --> Total execution time: 0.1093
INFO - 2018-03-26 00:27:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 00:27:18 --> Final output sent to browser
DEBUG - 2018-03-26 00:27:18 --> Total execution time: 0.1442
INFO - 2018-03-26 00:28:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:28:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:28:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:28:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:28:07 --> Final output sent to browser
DEBUG - 2018-03-26 00:28:07 --> Total execution time: 0.1537
INFO - 2018-03-26 00:28:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:28:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:28:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-26 00:28:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:28:09 --> Final output sent to browser
DEBUG - 2018-03-26 00:28:09 --> Total execution time: 0.1690
INFO - 2018-03-26 00:28:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 00:28:13 --> Final output sent to browser
DEBUG - 2018-03-26 00:28:13 --> Total execution time: 0.1155
INFO - 2018-03-26 00:28:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:28:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:28:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:28:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:28:14 --> Final output sent to browser
DEBUG - 2018-03-26 00:28:14 --> Total execution time: 0.1096
INFO - 2018-03-26 00:28:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:28:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:28:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-26 00:28:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:28:16 --> Final output sent to browser
DEBUG - 2018-03-26 00:28:16 --> Total execution time: 0.1213
INFO - 2018-03-26 00:28:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 00:28:18 --> Final output sent to browser
DEBUG - 2018-03-26 00:28:18 --> Total execution time: 0.1641
INFO - 2018-03-26 00:28:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 00:28:21 --> Final output sent to browser
DEBUG - 2018-03-26 00:28:21 --> Total execution time: 0.1351
INFO - 2018-03-26 00:28:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:28:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:28:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:28:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:28:21 --> Final output sent to browser
DEBUG - 2018-03-26 00:28:21 --> Total execution time: 0.1407
INFO - 2018-03-26 00:34:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:34:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:34:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:34:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:34:15 --> Final output sent to browser
DEBUG - 2018-03-26 00:34:15 --> Total execution time: 0.0956
INFO - 2018-03-26 00:35:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:35:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:35:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:35:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:35:09 --> Final output sent to browser
DEBUG - 2018-03-26 00:35:09 --> Total execution time: 0.0864
INFO - 2018-03-26 00:35:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:35:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:35:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:35:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:35:24 --> Final output sent to browser
DEBUG - 2018-03-26 00:35:24 --> Total execution time: 0.0877
INFO - 2018-03-26 00:42:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:42:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:42:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:42:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:42:12 --> Final output sent to browser
DEBUG - 2018-03-26 00:42:12 --> Total execution time: 0.1194
INFO - 2018-03-26 00:42:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:42:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:42:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-26 00:42:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:42:14 --> Final output sent to browser
DEBUG - 2018-03-26 00:42:14 --> Total execution time: 0.1102
INFO - 2018-03-26 00:42:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 00:42:18 --> Final output sent to browser
DEBUG - 2018-03-26 00:42:18 --> Total execution time: 0.1022
INFO - 2018-03-26 00:42:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:42:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:42:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:42:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:42:19 --> Final output sent to browser
DEBUG - 2018-03-26 00:42:19 --> Total execution time: 0.0939
INFO - 2018-03-26 00:42:45 --> Model Class Initialized
INFO - 2018-03-26 00:42:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:42:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:42:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-26 00:42:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:42:45 --> Final output sent to browser
DEBUG - 2018-03-26 00:42:45 --> Total execution time: 0.1567
INFO - 2018-03-26 00:42:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-26 00:42:48 --> Final output sent to browser
DEBUG - 2018-03-26 00:42:48 --> Total execution time: 0.0918
INFO - 2018-03-26 00:42:50 --> Model Class Initialized
INFO - 2018-03-26 00:42:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:42:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:42:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-26 00:42:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:42:50 --> Final output sent to browser
DEBUG - 2018-03-26 00:42:50 --> Total execution time: 0.1180
INFO - 2018-03-26 00:42:55 --> Final output sent to browser
DEBUG - 2018-03-26 00:42:55 --> Total execution time: 0.0950
INFO - 2018-03-26 00:43:00 --> Final output sent to browser
DEBUG - 2018-03-26 00:43:00 --> Total execution time: 0.2106
INFO - 2018-03-26 00:43:26 --> Model Class Initialized
INFO - 2018-03-26 00:43:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:43:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:43:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-26 00:43:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:43:26 --> Final output sent to browser
DEBUG - 2018-03-26 00:43:26 --> Total execution time: 0.0956
INFO - 2018-03-26 00:46:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:46:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:46:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:46:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:46:41 --> Final output sent to browser
DEBUG - 2018-03-26 00:46:41 --> Total execution time: 0.1095
INFO - 2018-03-26 00:47:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:47:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:47:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:47:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:47:14 --> Final output sent to browser
DEBUG - 2018-03-26 00:47:14 --> Total execution time: 0.1159
INFO - 2018-03-26 00:48:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:48:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:48:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:48:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:48:04 --> Final output sent to browser
DEBUG - 2018-03-26 00:48:04 --> Total execution time: 0.1123
INFO - 2018-03-26 00:48:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:48:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:48:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:48:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:48:46 --> Final output sent to browser
DEBUG - 2018-03-26 00:48:46 --> Total execution time: 0.1012
INFO - 2018-03-26 00:51:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:51:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:51:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:51:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:51:27 --> Final output sent to browser
DEBUG - 2018-03-26 00:51:27 --> Total execution time: 0.1210
INFO - 2018-03-26 00:51:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:51:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:51:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:51:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:51:41 --> Final output sent to browser
DEBUG - 2018-03-26 00:51:41 --> Total execution time: 0.1033
INFO - 2018-03-26 00:51:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:51:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:51:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:51:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:51:59 --> Final output sent to browser
DEBUG - 2018-03-26 00:51:59 --> Total execution time: 0.1076
INFO - 2018-03-26 00:52:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:52:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:52:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:52:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:52:09 --> Final output sent to browser
DEBUG - 2018-03-26 00:52:09 --> Total execution time: 0.1045
INFO - 2018-03-26 00:52:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:52:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:52:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:52:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:52:52 --> Final output sent to browser
DEBUG - 2018-03-26 00:52:52 --> Total execution time: 0.1111
INFO - 2018-03-26 00:54:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:54:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:54:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:54:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:54:03 --> Final output sent to browser
DEBUG - 2018-03-26 00:54:03 --> Total execution time: 0.1140
INFO - 2018-03-26 00:54:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:54:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:54:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:54:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:54:22 --> Final output sent to browser
DEBUG - 2018-03-26 00:54:22 --> Total execution time: 0.1085
INFO - 2018-03-26 00:54:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:54:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:54:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:54:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:54:46 --> Final output sent to browser
DEBUG - 2018-03-26 00:54:46 --> Total execution time: 0.1053
INFO - 2018-03-26 00:55:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:55:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:55:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:55:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:55:01 --> Final output sent to browser
DEBUG - 2018-03-26 00:55:01 --> Total execution time: 0.1051
INFO - 2018-03-26 00:55:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:55:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:55:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:55:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:55:32 --> Final output sent to browser
DEBUG - 2018-03-26 00:55:32 --> Total execution time: 0.1124
INFO - 2018-03-26 00:56:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:56:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:56:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:56:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:56:00 --> Final output sent to browser
DEBUG - 2018-03-26 00:56:00 --> Total execution time: 0.1094
INFO - 2018-03-26 00:59:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:59:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:59:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:59:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:59:34 --> Final output sent to browser
DEBUG - 2018-03-26 00:59:34 --> Total execution time: 0.1065
INFO - 2018-03-26 00:59:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 00:59:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 00:59:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 00:59:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 00:59:51 --> Final output sent to browser
DEBUG - 2018-03-26 00:59:51 --> Total execution time: 0.1416
INFO - 2018-03-26 01:00:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 01:00:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 01:00:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 01:00:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 01:00:14 --> Final output sent to browser
DEBUG - 2018-03-26 01:00:14 --> Total execution time: 0.1163
INFO - 2018-03-26 01:00:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 01:00:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 01:00:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 01:00:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 01:00:35 --> Final output sent to browser
DEBUG - 2018-03-26 01:00:35 --> Total execution time: 0.1014
INFO - 2018-03-26 01:00:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 01:00:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 01:00:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 01:00:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 01:00:47 --> Final output sent to browser
DEBUG - 2018-03-26 01:00:47 --> Total execution time: 0.1083
INFO - 2018-03-26 01:00:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 01:00:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 01:00:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 01:00:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 01:00:57 --> Final output sent to browser
DEBUG - 2018-03-26 01:00:57 --> Total execution time: 0.1207
INFO - 2018-03-26 01:01:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 01:01:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 01:01:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 01:01:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 01:01:03 --> Final output sent to browser
DEBUG - 2018-03-26 01:01:03 --> Total execution time: 0.1018
INFO - 2018-03-26 01:01:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 01:01:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 01:01:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 01:01:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 01:01:10 --> Final output sent to browser
DEBUG - 2018-03-26 01:01:10 --> Total execution time: 0.0918
INFO - 2018-03-26 01:01:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 01:01:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 01:01:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 01:01:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 01:01:22 --> Final output sent to browser
DEBUG - 2018-03-26 01:01:22 --> Total execution time: 0.1152
INFO - 2018-03-26 01:01:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 01:01:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 01:01:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 01:01:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 01:01:52 --> Final output sent to browser
DEBUG - 2018-03-26 01:01:52 --> Total execution time: 0.1119
INFO - 2018-03-26 01:02:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 01:02:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 01:02:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 01:02:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 01:02:00 --> Final output sent to browser
DEBUG - 2018-03-26 01:02:00 --> Total execution time: 0.1176
INFO - 2018-03-26 10:34:56 --> Config Class Initialized
INFO - 2018-03-26 10:34:56 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:34:56 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:34:56 --> Utf8 Class Initialized
INFO - 2018-03-26 10:34:56 --> URI Class Initialized
INFO - 2018-03-26 10:34:56 --> Router Class Initialized
INFO - 2018-03-26 10:34:56 --> Output Class Initialized
INFO - 2018-03-26 10:34:56 --> Security Class Initialized
DEBUG - 2018-03-26 10:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:34:56 --> Input Class Initialized
INFO - 2018-03-26 10:34:56 --> Language Class Initialized
INFO - 2018-03-26 10:34:56 --> Loader Class Initialized
INFO - 2018-03-26 10:34:56 --> Helper loaded: url_helper
INFO - 2018-03-26 10:34:56 --> Helper loaded: form_helper
INFO - 2018-03-26 10:34:56 --> Database Driver Class Initialized
ERROR - 2018-03-26 10:34:58 --> Unable to connect to the database
DEBUG - 2018-03-26 10:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 10:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:34:58 --> Controller Class Initialized
INFO - 2018-03-26 10:34:58 --> Config Class Initialized
INFO - 2018-03-26 10:34:58 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:34:58 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:34:58 --> Utf8 Class Initialized
INFO - 2018-03-26 10:34:58 --> URI Class Initialized
INFO - 2018-03-26 10:34:58 --> Router Class Initialized
INFO - 2018-03-26 10:34:58 --> Output Class Initialized
INFO - 2018-03-26 10:34:58 --> Security Class Initialized
DEBUG - 2018-03-26 10:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:34:58 --> Input Class Initialized
INFO - 2018-03-26 10:34:58 --> Language Class Initialized
INFO - 2018-03-26 10:34:58 --> Loader Class Initialized
INFO - 2018-03-26 10:34:58 --> Helper loaded: url_helper
INFO - 2018-03-26 10:34:58 --> Helper loaded: form_helper
INFO - 2018-03-26 10:34:58 --> Database Driver Class Initialized
ERROR - 2018-03-26 10:35:00 --> Unable to connect to the database
DEBUG - 2018-03-26 10:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 10:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:35:00 --> Controller Class Initialized
INFO - 2018-03-26 10:35:00 --> Model Class Initialized
INFO - 2018-03-26 10:35:00 --> Model Class Initialized
INFO - 2018-03-26 10:35:00 --> Model Class Initialized
INFO - 2018-03-26 10:35:00 --> Helper loaded: date_helper
INFO - 2018-03-26 15:35:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-26 15:35:00 --> Final output sent to browser
DEBUG - 2018-03-26 15:35:00 --> Total execution time: 2.0996
INFO - 2018-03-26 10:35:25 --> Config Class Initialized
INFO - 2018-03-26 10:35:25 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:35:25 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:35:25 --> Utf8 Class Initialized
INFO - 2018-03-26 10:35:25 --> URI Class Initialized
INFO - 2018-03-26 10:35:25 --> Router Class Initialized
INFO - 2018-03-26 10:35:25 --> Output Class Initialized
INFO - 2018-03-26 10:35:25 --> Security Class Initialized
DEBUG - 2018-03-26 10:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:35:25 --> Input Class Initialized
INFO - 2018-03-26 10:35:25 --> Language Class Initialized
INFO - 2018-03-26 10:35:25 --> Loader Class Initialized
INFO - 2018-03-26 10:35:25 --> Helper loaded: url_helper
INFO - 2018-03-26 10:35:25 --> Helper loaded: form_helper
INFO - 2018-03-26 10:35:25 --> Database Driver Class Initialized
DEBUG - 2018-03-26 10:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 10:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:35:25 --> Controller Class Initialized
INFO - 2018-03-26 10:35:25 --> Model Class Initialized
INFO - 2018-03-26 10:35:25 --> Model Class Initialized
INFO - 2018-03-26 10:35:25 --> Model Class Initialized
INFO - 2018-03-26 10:35:25 --> Helper loaded: date_helper
INFO - 2018-03-26 10:35:25 --> Config Class Initialized
INFO - 2018-03-26 10:35:25 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:35:25 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:35:25 --> Utf8 Class Initialized
INFO - 2018-03-26 10:35:25 --> URI Class Initialized
INFO - 2018-03-26 10:35:25 --> Router Class Initialized
INFO - 2018-03-26 10:35:25 --> Output Class Initialized
INFO - 2018-03-26 10:35:25 --> Security Class Initialized
DEBUG - 2018-03-26 10:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:35:25 --> Input Class Initialized
INFO - 2018-03-26 10:35:25 --> Language Class Initialized
INFO - 2018-03-26 10:35:25 --> Loader Class Initialized
INFO - 2018-03-26 10:35:25 --> Helper loaded: url_helper
INFO - 2018-03-26 10:35:25 --> Helper loaded: form_helper
INFO - 2018-03-26 10:35:25 --> Database Driver Class Initialized
DEBUG - 2018-03-26 10:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 10:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:35:25 --> Controller Class Initialized
INFO - 2018-03-26 10:35:25 --> Model Class Initialized
INFO - 2018-03-26 10:35:25 --> Model Class Initialized
INFO - 2018-03-26 10:35:25 --> Model Class Initialized
INFO - 2018-03-26 10:35:25 --> Model Class Initialized
INFO - 2018-03-26 10:35:25 --> Model Class Initialized
INFO - 2018-03-26 10:35:25 --> Helper loaded: date_helper
INFO - 2018-03-26 15:35:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 15:35:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 15:35:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 15:35:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 15:35:25 --> Final output sent to browser
DEBUG - 2018-03-26 15:35:25 --> Total execution time: 0.1128
INFO - 2018-03-26 10:35:28 --> Config Class Initialized
INFO - 2018-03-26 10:35:28 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:35:28 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:35:28 --> Utf8 Class Initialized
INFO - 2018-03-26 10:35:28 --> URI Class Initialized
INFO - 2018-03-26 10:35:28 --> Router Class Initialized
INFO - 2018-03-26 10:35:28 --> Output Class Initialized
INFO - 2018-03-26 10:35:28 --> Security Class Initialized
DEBUG - 2018-03-26 10:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:35:28 --> Input Class Initialized
INFO - 2018-03-26 10:35:28 --> Language Class Initialized
INFO - 2018-03-26 10:35:28 --> Loader Class Initialized
INFO - 2018-03-26 10:35:28 --> Helper loaded: url_helper
INFO - 2018-03-26 10:35:28 --> Helper loaded: form_helper
INFO - 2018-03-26 10:35:28 --> Database Driver Class Initialized
DEBUG - 2018-03-26 10:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 10:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:35:28 --> Controller Class Initialized
INFO - 2018-03-26 10:35:28 --> Model Class Initialized
INFO - 2018-03-26 10:35:28 --> Model Class Initialized
INFO - 2018-03-26 10:35:28 --> Model Class Initialized
INFO - 2018-03-26 10:35:28 --> Model Class Initialized
INFO - 2018-03-26 10:35:28 --> Model Class Initialized
INFO - 2018-03-26 10:35:28 --> Model Class Initialized
INFO - 2018-03-26 10:35:28 --> Model Class Initialized
INFO - 2018-03-26 10:35:28 --> Model Class Initialized
INFO - 2018-03-26 10:35:28 --> Model Class Initialized
INFO - 2018-03-26 10:35:28 --> Model Class Initialized
INFO - 2018-03-26 10:35:28 --> Model Class Initialized
INFO - 2018-03-26 10:35:28 --> Model Class Initialized
INFO - 2018-03-26 10:35:28 --> Helper loaded: date_helper
INFO - 2018-03-26 10:35:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 15:35:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 15:35:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 15:35:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-26 15:35:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 15:35:28 --> Final output sent to browser
DEBUG - 2018-03-26 15:35:28 --> Total execution time: 0.1069
INFO - 2018-03-26 10:35:35 --> Config Class Initialized
INFO - 2018-03-26 10:35:35 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:35:35 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:35:35 --> Utf8 Class Initialized
INFO - 2018-03-26 10:35:35 --> URI Class Initialized
INFO - 2018-03-26 10:35:35 --> Router Class Initialized
INFO - 2018-03-26 10:35:35 --> Output Class Initialized
INFO - 2018-03-26 10:35:35 --> Security Class Initialized
DEBUG - 2018-03-26 10:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:35:35 --> Input Class Initialized
INFO - 2018-03-26 10:35:35 --> Language Class Initialized
INFO - 2018-03-26 10:35:35 --> Loader Class Initialized
INFO - 2018-03-26 10:35:35 --> Helper loaded: url_helper
INFO - 2018-03-26 10:35:35 --> Helper loaded: form_helper
INFO - 2018-03-26 10:35:35 --> Database Driver Class Initialized
DEBUG - 2018-03-26 10:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 10:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:35:35 --> Controller Class Initialized
INFO - 2018-03-26 10:35:35 --> Model Class Initialized
INFO - 2018-03-26 10:35:35 --> Model Class Initialized
INFO - 2018-03-26 10:35:35 --> Model Class Initialized
INFO - 2018-03-26 10:35:35 --> Model Class Initialized
INFO - 2018-03-26 10:35:35 --> Model Class Initialized
INFO - 2018-03-26 10:35:35 --> Model Class Initialized
INFO - 2018-03-26 10:35:35 --> Model Class Initialized
INFO - 2018-03-26 10:35:35 --> Model Class Initialized
INFO - 2018-03-26 10:35:35 --> Model Class Initialized
INFO - 2018-03-26 10:35:35 --> Model Class Initialized
INFO - 2018-03-26 10:35:35 --> Model Class Initialized
INFO - 2018-03-26 10:35:35 --> Model Class Initialized
INFO - 2018-03-26 10:35:35 --> Helper loaded: date_helper
INFO - 2018-03-26 10:35:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 15:35:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 15:35:35 --> Final output sent to browser
DEBUG - 2018-03-26 15:35:35 --> Total execution time: 0.0852
INFO - 2018-03-26 10:35:36 --> Config Class Initialized
INFO - 2018-03-26 10:35:36 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:35:36 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:35:36 --> Utf8 Class Initialized
INFO - 2018-03-26 10:35:36 --> URI Class Initialized
INFO - 2018-03-26 10:35:36 --> Router Class Initialized
INFO - 2018-03-26 10:35:36 --> Output Class Initialized
INFO - 2018-03-26 10:35:36 --> Security Class Initialized
DEBUG - 2018-03-26 10:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:35:36 --> Input Class Initialized
INFO - 2018-03-26 10:35:36 --> Language Class Initialized
INFO - 2018-03-26 10:35:36 --> Loader Class Initialized
INFO - 2018-03-26 10:35:36 --> Helper loaded: url_helper
INFO - 2018-03-26 10:35:36 --> Helper loaded: form_helper
INFO - 2018-03-26 10:35:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 10:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 10:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:35:36 --> Controller Class Initialized
INFO - 2018-03-26 10:35:36 --> Model Class Initialized
INFO - 2018-03-26 10:35:36 --> Model Class Initialized
INFO - 2018-03-26 10:35:36 --> Model Class Initialized
INFO - 2018-03-26 10:35:36 --> Model Class Initialized
INFO - 2018-03-26 10:35:36 --> Model Class Initialized
INFO - 2018-03-26 10:35:36 --> Model Class Initialized
INFO - 2018-03-26 10:35:36 --> Model Class Initialized
INFO - 2018-03-26 10:35:36 --> Model Class Initialized
INFO - 2018-03-26 10:35:36 --> Model Class Initialized
INFO - 2018-03-26 10:35:36 --> Model Class Initialized
INFO - 2018-03-26 10:35:36 --> Model Class Initialized
INFO - 2018-03-26 10:35:36 --> Model Class Initialized
INFO - 2018-03-26 10:35:36 --> Helper loaded: date_helper
INFO - 2018-03-26 10:35:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 15:35:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 15:35:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 15:35:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 15:35:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 15:35:36 --> Final output sent to browser
DEBUG - 2018-03-26 15:35:36 --> Total execution time: 0.0969
INFO - 2018-03-26 10:37:27 --> Config Class Initialized
INFO - 2018-03-26 10:37:27 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:37:27 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:37:27 --> Utf8 Class Initialized
INFO - 2018-03-26 10:37:27 --> URI Class Initialized
INFO - 2018-03-26 10:37:27 --> Router Class Initialized
INFO - 2018-03-26 10:37:27 --> Output Class Initialized
INFO - 2018-03-26 10:37:27 --> Security Class Initialized
DEBUG - 2018-03-26 10:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:37:27 --> Input Class Initialized
INFO - 2018-03-26 10:37:27 --> Language Class Initialized
INFO - 2018-03-26 10:37:27 --> Loader Class Initialized
INFO - 2018-03-26 10:37:27 --> Helper loaded: url_helper
INFO - 2018-03-26 10:37:27 --> Helper loaded: form_helper
INFO - 2018-03-26 10:37:27 --> Database Driver Class Initialized
DEBUG - 2018-03-26 10:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 10:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:37:27 --> Controller Class Initialized
INFO - 2018-03-26 10:37:27 --> Model Class Initialized
INFO - 2018-03-26 10:37:27 --> Model Class Initialized
INFO - 2018-03-26 10:37:27 --> Model Class Initialized
INFO - 2018-03-26 10:37:27 --> Model Class Initialized
INFO - 2018-03-26 10:37:27 --> Model Class Initialized
INFO - 2018-03-26 10:37:27 --> Model Class Initialized
INFO - 2018-03-26 10:37:27 --> Model Class Initialized
INFO - 2018-03-26 10:37:27 --> Model Class Initialized
INFO - 2018-03-26 10:37:27 --> Model Class Initialized
INFO - 2018-03-26 10:37:27 --> Model Class Initialized
INFO - 2018-03-26 10:37:27 --> Model Class Initialized
INFO - 2018-03-26 10:37:27 --> Model Class Initialized
INFO - 2018-03-26 10:37:27 --> Helper loaded: date_helper
INFO - 2018-03-26 10:37:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 15:37:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 15:37:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 15:37:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 15:37:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 15:37:27 --> Final output sent to browser
DEBUG - 2018-03-26 15:37:27 --> Total execution time: 0.0993
INFO - 2018-03-26 10:39:20 --> Config Class Initialized
INFO - 2018-03-26 10:39:20 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:39:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:39:20 --> Utf8 Class Initialized
INFO - 2018-03-26 10:39:20 --> URI Class Initialized
INFO - 2018-03-26 10:39:20 --> Router Class Initialized
INFO - 2018-03-26 10:39:20 --> Output Class Initialized
INFO - 2018-03-26 10:39:20 --> Security Class Initialized
DEBUG - 2018-03-26 10:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:39:20 --> Input Class Initialized
INFO - 2018-03-26 10:39:20 --> Language Class Initialized
INFO - 2018-03-26 10:39:20 --> Loader Class Initialized
INFO - 2018-03-26 10:39:20 --> Helper loaded: url_helper
INFO - 2018-03-26 10:39:20 --> Helper loaded: form_helper
INFO - 2018-03-26 10:39:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 10:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 10:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:39:20 --> Controller Class Initialized
INFO - 2018-03-26 10:39:20 --> Model Class Initialized
INFO - 2018-03-26 10:39:20 --> Model Class Initialized
INFO - 2018-03-26 10:39:20 --> Model Class Initialized
INFO - 2018-03-26 10:39:20 --> Model Class Initialized
INFO - 2018-03-26 10:39:20 --> Model Class Initialized
INFO - 2018-03-26 10:39:20 --> Model Class Initialized
INFO - 2018-03-26 10:39:20 --> Model Class Initialized
INFO - 2018-03-26 10:39:20 --> Model Class Initialized
INFO - 2018-03-26 10:39:20 --> Model Class Initialized
INFO - 2018-03-26 10:39:20 --> Model Class Initialized
INFO - 2018-03-26 10:39:20 --> Model Class Initialized
INFO - 2018-03-26 10:39:20 --> Model Class Initialized
INFO - 2018-03-26 10:39:20 --> Helper loaded: date_helper
INFO - 2018-03-26 10:39:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 15:39:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 15:39:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 15:39:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 15:39:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 15:39:20 --> Final output sent to browser
DEBUG - 2018-03-26 15:39:20 --> Total execution time: 0.1160
INFO - 2018-03-26 10:40:36 --> Config Class Initialized
INFO - 2018-03-26 10:40:36 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:40:36 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:40:36 --> Utf8 Class Initialized
INFO - 2018-03-26 10:40:36 --> URI Class Initialized
INFO - 2018-03-26 10:40:36 --> Router Class Initialized
INFO - 2018-03-26 10:40:36 --> Output Class Initialized
INFO - 2018-03-26 10:40:36 --> Security Class Initialized
DEBUG - 2018-03-26 10:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:40:36 --> Input Class Initialized
INFO - 2018-03-26 10:40:36 --> Language Class Initialized
INFO - 2018-03-26 10:40:36 --> Loader Class Initialized
INFO - 2018-03-26 10:40:36 --> Helper loaded: url_helper
INFO - 2018-03-26 10:40:36 --> Helper loaded: form_helper
INFO - 2018-03-26 10:40:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 10:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 10:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:40:36 --> Controller Class Initialized
INFO - 2018-03-26 10:40:36 --> Model Class Initialized
INFO - 2018-03-26 10:40:36 --> Model Class Initialized
INFO - 2018-03-26 10:40:36 --> Model Class Initialized
INFO - 2018-03-26 10:40:36 --> Model Class Initialized
INFO - 2018-03-26 10:40:36 --> Model Class Initialized
INFO - 2018-03-26 10:40:36 --> Model Class Initialized
INFO - 2018-03-26 10:40:36 --> Model Class Initialized
INFO - 2018-03-26 10:40:36 --> Model Class Initialized
INFO - 2018-03-26 10:40:36 --> Model Class Initialized
INFO - 2018-03-26 10:40:36 --> Model Class Initialized
INFO - 2018-03-26 10:40:36 --> Model Class Initialized
INFO - 2018-03-26 10:40:36 --> Model Class Initialized
INFO - 2018-03-26 10:40:36 --> Helper loaded: date_helper
INFO - 2018-03-26 10:40:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 15:40:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 15:40:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 15:40:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 15:40:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 15:40:36 --> Final output sent to browser
DEBUG - 2018-03-26 15:40:36 --> Total execution time: 0.1074
INFO - 2018-03-26 10:42:05 --> Config Class Initialized
INFO - 2018-03-26 10:42:05 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:42:05 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:42:05 --> Utf8 Class Initialized
INFO - 2018-03-26 10:42:05 --> URI Class Initialized
INFO - 2018-03-26 10:42:05 --> Router Class Initialized
INFO - 2018-03-26 10:42:05 --> Output Class Initialized
INFO - 2018-03-26 10:42:05 --> Security Class Initialized
DEBUG - 2018-03-26 10:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:42:05 --> Input Class Initialized
INFO - 2018-03-26 10:42:05 --> Language Class Initialized
INFO - 2018-03-26 10:42:05 --> Loader Class Initialized
INFO - 2018-03-26 10:42:05 --> Helper loaded: url_helper
INFO - 2018-03-26 10:42:05 --> Helper loaded: form_helper
INFO - 2018-03-26 10:42:05 --> Database Driver Class Initialized
DEBUG - 2018-03-26 10:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 10:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:42:05 --> Controller Class Initialized
INFO - 2018-03-26 10:42:05 --> Model Class Initialized
INFO - 2018-03-26 10:42:05 --> Model Class Initialized
INFO - 2018-03-26 10:42:05 --> Model Class Initialized
INFO - 2018-03-26 10:42:05 --> Model Class Initialized
INFO - 2018-03-26 10:42:05 --> Model Class Initialized
INFO - 2018-03-26 10:42:05 --> Model Class Initialized
INFO - 2018-03-26 10:42:05 --> Model Class Initialized
INFO - 2018-03-26 10:42:05 --> Model Class Initialized
INFO - 2018-03-26 10:42:05 --> Model Class Initialized
INFO - 2018-03-26 10:42:05 --> Model Class Initialized
INFO - 2018-03-26 10:42:05 --> Model Class Initialized
INFO - 2018-03-26 10:42:05 --> Model Class Initialized
INFO - 2018-03-26 10:42:05 --> Helper loaded: date_helper
INFO - 2018-03-26 10:42:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 15:42:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 15:42:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 15:42:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 15:42:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 15:42:05 --> Final output sent to browser
DEBUG - 2018-03-26 15:42:05 --> Total execution time: 0.1023
INFO - 2018-03-26 10:42:13 --> Config Class Initialized
INFO - 2018-03-26 10:42:13 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:42:13 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:42:13 --> Utf8 Class Initialized
INFO - 2018-03-26 10:42:13 --> URI Class Initialized
INFO - 2018-03-26 10:42:13 --> Router Class Initialized
INFO - 2018-03-26 10:42:13 --> Output Class Initialized
INFO - 2018-03-26 10:42:13 --> Security Class Initialized
DEBUG - 2018-03-26 10:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:42:13 --> Input Class Initialized
INFO - 2018-03-26 10:42:13 --> Language Class Initialized
INFO - 2018-03-26 10:42:13 --> Loader Class Initialized
INFO - 2018-03-26 10:42:13 --> Helper loaded: url_helper
INFO - 2018-03-26 10:42:13 --> Helper loaded: form_helper
INFO - 2018-03-26 10:42:13 --> Database Driver Class Initialized
DEBUG - 2018-03-26 10:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 10:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:42:13 --> Controller Class Initialized
INFO - 2018-03-26 10:42:13 --> Model Class Initialized
INFO - 2018-03-26 10:42:13 --> Model Class Initialized
INFO - 2018-03-26 10:42:13 --> Model Class Initialized
INFO - 2018-03-26 10:42:13 --> Model Class Initialized
INFO - 2018-03-26 10:42:13 --> Model Class Initialized
INFO - 2018-03-26 10:42:13 --> Model Class Initialized
INFO - 2018-03-26 10:42:13 --> Model Class Initialized
INFO - 2018-03-26 10:42:13 --> Model Class Initialized
INFO - 2018-03-26 10:42:13 --> Model Class Initialized
INFO - 2018-03-26 10:42:13 --> Model Class Initialized
INFO - 2018-03-26 10:42:13 --> Model Class Initialized
INFO - 2018-03-26 10:42:13 --> Model Class Initialized
INFO - 2018-03-26 10:42:13 --> Helper loaded: date_helper
INFO - 2018-03-26 10:42:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 15:42:13 --> Final output sent to browser
DEBUG - 2018-03-26 15:42:13 --> Total execution time: 0.0659
INFO - 2018-03-26 10:48:22 --> Config Class Initialized
INFO - 2018-03-26 10:48:22 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:48:22 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:48:22 --> Utf8 Class Initialized
INFO - 2018-03-26 10:48:22 --> URI Class Initialized
INFO - 2018-03-26 10:48:22 --> Router Class Initialized
INFO - 2018-03-26 10:48:22 --> Output Class Initialized
INFO - 2018-03-26 10:48:22 --> Security Class Initialized
DEBUG - 2018-03-26 10:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:48:22 --> Input Class Initialized
INFO - 2018-03-26 10:48:22 --> Language Class Initialized
INFO - 2018-03-26 10:48:22 --> Loader Class Initialized
INFO - 2018-03-26 10:48:22 --> Helper loaded: url_helper
INFO - 2018-03-26 10:48:22 --> Helper loaded: form_helper
INFO - 2018-03-26 10:48:22 --> Database Driver Class Initialized
DEBUG - 2018-03-26 10:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 10:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:48:22 --> Controller Class Initialized
INFO - 2018-03-26 10:48:22 --> Model Class Initialized
INFO - 2018-03-26 10:48:22 --> Model Class Initialized
INFO - 2018-03-26 10:48:22 --> Model Class Initialized
INFO - 2018-03-26 10:48:22 --> Model Class Initialized
INFO - 2018-03-26 10:48:22 --> Model Class Initialized
INFO - 2018-03-26 10:48:22 --> Model Class Initialized
INFO - 2018-03-26 10:48:22 --> Model Class Initialized
INFO - 2018-03-26 10:48:22 --> Model Class Initialized
INFO - 2018-03-26 10:48:22 --> Model Class Initialized
INFO - 2018-03-26 10:48:22 --> Model Class Initialized
INFO - 2018-03-26 10:48:22 --> Model Class Initialized
INFO - 2018-03-26 10:48:22 --> Model Class Initialized
INFO - 2018-03-26 10:48:22 --> Helper loaded: date_helper
INFO - 2018-03-26 10:48:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 15:48:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 15:48:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 15:48:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 15:48:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 15:48:22 --> Final output sent to browser
DEBUG - 2018-03-26 15:48:22 --> Total execution time: 0.0976
INFO - 2018-03-26 10:48:50 --> Config Class Initialized
INFO - 2018-03-26 10:48:50 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:48:50 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:48:50 --> Utf8 Class Initialized
INFO - 2018-03-26 10:48:50 --> URI Class Initialized
INFO - 2018-03-26 10:48:50 --> Router Class Initialized
INFO - 2018-03-26 10:48:50 --> Output Class Initialized
INFO - 2018-03-26 10:48:50 --> Security Class Initialized
DEBUG - 2018-03-26 10:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:48:50 --> Input Class Initialized
INFO - 2018-03-26 10:48:50 --> Language Class Initialized
INFO - 2018-03-26 10:48:50 --> Loader Class Initialized
INFO - 2018-03-26 10:48:50 --> Helper loaded: url_helper
INFO - 2018-03-26 10:48:50 --> Helper loaded: form_helper
INFO - 2018-03-26 10:48:50 --> Database Driver Class Initialized
DEBUG - 2018-03-26 10:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 10:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:48:50 --> Controller Class Initialized
INFO - 2018-03-26 10:48:50 --> Model Class Initialized
INFO - 2018-03-26 10:48:50 --> Model Class Initialized
INFO - 2018-03-26 10:48:50 --> Model Class Initialized
INFO - 2018-03-26 10:48:50 --> Model Class Initialized
INFO - 2018-03-26 10:48:50 --> Model Class Initialized
INFO - 2018-03-26 10:48:50 --> Model Class Initialized
INFO - 2018-03-26 10:48:50 --> Model Class Initialized
INFO - 2018-03-26 10:48:50 --> Model Class Initialized
INFO - 2018-03-26 10:48:50 --> Model Class Initialized
INFO - 2018-03-26 10:48:50 --> Model Class Initialized
INFO - 2018-03-26 10:48:50 --> Model Class Initialized
INFO - 2018-03-26 10:48:50 --> Model Class Initialized
INFO - 2018-03-26 10:48:50 --> Helper loaded: date_helper
INFO - 2018-03-26 10:48:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 15:48:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 15:48:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 15:48:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 15:48:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 15:48:50 --> Final output sent to browser
DEBUG - 2018-03-26 15:48:50 --> Total execution time: 0.1166
INFO - 2018-03-26 10:49:00 --> Config Class Initialized
INFO - 2018-03-26 10:49:00 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:49:00 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:49:00 --> Utf8 Class Initialized
INFO - 2018-03-26 10:49:00 --> URI Class Initialized
INFO - 2018-03-26 10:49:00 --> Router Class Initialized
INFO - 2018-03-26 10:49:00 --> Output Class Initialized
INFO - 2018-03-26 10:49:00 --> Security Class Initialized
DEBUG - 2018-03-26 10:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:49:00 --> Input Class Initialized
INFO - 2018-03-26 10:49:00 --> Language Class Initialized
INFO - 2018-03-26 10:49:00 --> Loader Class Initialized
INFO - 2018-03-26 10:49:00 --> Helper loaded: url_helper
INFO - 2018-03-26 10:49:01 --> Helper loaded: form_helper
INFO - 2018-03-26 10:49:01 --> Database Driver Class Initialized
DEBUG - 2018-03-26 10:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 10:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:49:01 --> Controller Class Initialized
INFO - 2018-03-26 10:49:01 --> Model Class Initialized
INFO - 2018-03-26 10:49:01 --> Model Class Initialized
INFO - 2018-03-26 10:49:01 --> Model Class Initialized
INFO - 2018-03-26 10:49:01 --> Model Class Initialized
INFO - 2018-03-26 10:49:01 --> Model Class Initialized
INFO - 2018-03-26 10:49:01 --> Model Class Initialized
INFO - 2018-03-26 10:49:01 --> Model Class Initialized
INFO - 2018-03-26 10:49:01 --> Model Class Initialized
INFO - 2018-03-26 10:49:01 --> Model Class Initialized
INFO - 2018-03-26 10:49:01 --> Model Class Initialized
INFO - 2018-03-26 10:49:01 --> Model Class Initialized
INFO - 2018-03-26 10:49:01 --> Model Class Initialized
INFO - 2018-03-26 10:49:01 --> Helper loaded: date_helper
INFO - 2018-03-26 10:49:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 15:49:01 --> Final output sent to browser
DEBUG - 2018-03-26 15:49:01 --> Total execution time: 0.0812
INFO - 2018-03-26 10:59:31 --> Config Class Initialized
INFO - 2018-03-26 10:59:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:59:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:59:31 --> Utf8 Class Initialized
INFO - 2018-03-26 10:59:31 --> URI Class Initialized
INFO - 2018-03-26 10:59:31 --> Router Class Initialized
INFO - 2018-03-26 10:59:31 --> Output Class Initialized
INFO - 2018-03-26 10:59:31 --> Security Class Initialized
DEBUG - 2018-03-26 10:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:59:31 --> Input Class Initialized
INFO - 2018-03-26 10:59:31 --> Language Class Initialized
ERROR - 2018-03-26 10:59:31 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' E:\xampp\htdocs\skin_care\application\controllers\Kasir\Kasir.php 65
INFO - 2018-03-26 10:59:45 --> Config Class Initialized
INFO - 2018-03-26 10:59:45 --> Hooks Class Initialized
DEBUG - 2018-03-26 10:59:45 --> UTF-8 Support Enabled
INFO - 2018-03-26 10:59:45 --> Utf8 Class Initialized
INFO - 2018-03-26 10:59:45 --> URI Class Initialized
INFO - 2018-03-26 10:59:45 --> Router Class Initialized
INFO - 2018-03-26 10:59:45 --> Output Class Initialized
INFO - 2018-03-26 10:59:45 --> Security Class Initialized
DEBUG - 2018-03-26 10:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 10:59:45 --> Input Class Initialized
INFO - 2018-03-26 10:59:45 --> Language Class Initialized
INFO - 2018-03-26 10:59:45 --> Loader Class Initialized
INFO - 2018-03-26 10:59:45 --> Helper loaded: url_helper
INFO - 2018-03-26 10:59:45 --> Helper loaded: form_helper
INFO - 2018-03-26 10:59:45 --> Database Driver Class Initialized
DEBUG - 2018-03-26 10:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 10:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 10:59:45 --> Controller Class Initialized
INFO - 2018-03-26 10:59:45 --> Model Class Initialized
INFO - 2018-03-26 10:59:45 --> Model Class Initialized
INFO - 2018-03-26 10:59:45 --> Model Class Initialized
INFO - 2018-03-26 10:59:45 --> Model Class Initialized
INFO - 2018-03-26 10:59:45 --> Model Class Initialized
INFO - 2018-03-26 10:59:45 --> Model Class Initialized
INFO - 2018-03-26 10:59:45 --> Model Class Initialized
INFO - 2018-03-26 10:59:45 --> Model Class Initialized
INFO - 2018-03-26 10:59:45 --> Model Class Initialized
INFO - 2018-03-26 10:59:45 --> Model Class Initialized
INFO - 2018-03-26 10:59:45 --> Model Class Initialized
INFO - 2018-03-26 10:59:45 --> Model Class Initialized
INFO - 2018-03-26 10:59:45 --> Helper loaded: date_helper
INFO - 2018-03-26 10:59:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 15:59:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 15:59:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 15:59:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 15:59:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 15:59:45 --> Final output sent to browser
DEBUG - 2018-03-26 15:59:45 --> Total execution time: 0.0998
INFO - 2018-03-26 11:00:07 --> Config Class Initialized
INFO - 2018-03-26 11:00:07 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:00:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:00:07 --> Utf8 Class Initialized
INFO - 2018-03-26 11:00:07 --> URI Class Initialized
INFO - 2018-03-26 11:00:07 --> Router Class Initialized
INFO - 2018-03-26 11:00:07 --> Output Class Initialized
INFO - 2018-03-26 11:00:07 --> Security Class Initialized
DEBUG - 2018-03-26 11:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:00:07 --> Input Class Initialized
INFO - 2018-03-26 11:00:07 --> Language Class Initialized
INFO - 2018-03-26 11:00:07 --> Loader Class Initialized
INFO - 2018-03-26 11:00:07 --> Helper loaded: url_helper
INFO - 2018-03-26 11:00:07 --> Helper loaded: form_helper
INFO - 2018-03-26 11:00:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:00:07 --> Controller Class Initialized
INFO - 2018-03-26 11:00:07 --> Model Class Initialized
INFO - 2018-03-26 11:00:07 --> Model Class Initialized
INFO - 2018-03-26 11:00:07 --> Model Class Initialized
INFO - 2018-03-26 11:00:07 --> Model Class Initialized
INFO - 2018-03-26 11:00:07 --> Model Class Initialized
INFO - 2018-03-26 11:00:07 --> Model Class Initialized
INFO - 2018-03-26 11:00:08 --> Model Class Initialized
INFO - 2018-03-26 11:00:08 --> Model Class Initialized
INFO - 2018-03-26 11:00:08 --> Model Class Initialized
INFO - 2018-03-26 11:00:08 --> Model Class Initialized
INFO - 2018-03-26 11:00:08 --> Model Class Initialized
INFO - 2018-03-26 11:00:08 --> Model Class Initialized
INFO - 2018-03-26 11:00:08 --> Helper loaded: date_helper
INFO - 2018-03-26 11:00:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:00:08 --> Final output sent to browser
DEBUG - 2018-03-26 16:00:08 --> Total execution time: 0.0862
INFO - 2018-03-26 11:07:30 --> Config Class Initialized
INFO - 2018-03-26 11:07:30 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:07:30 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:07:30 --> Utf8 Class Initialized
INFO - 2018-03-26 11:07:30 --> URI Class Initialized
INFO - 2018-03-26 11:07:30 --> Router Class Initialized
INFO - 2018-03-26 11:07:30 --> Output Class Initialized
INFO - 2018-03-26 11:07:30 --> Security Class Initialized
DEBUG - 2018-03-26 11:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:07:30 --> Input Class Initialized
INFO - 2018-03-26 11:07:30 --> Language Class Initialized
INFO - 2018-03-26 11:07:30 --> Loader Class Initialized
INFO - 2018-03-26 11:07:30 --> Helper loaded: url_helper
INFO - 2018-03-26 11:07:30 --> Helper loaded: form_helper
INFO - 2018-03-26 11:07:30 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:07:30 --> Controller Class Initialized
INFO - 2018-03-26 11:07:30 --> Model Class Initialized
INFO - 2018-03-26 11:07:30 --> Model Class Initialized
INFO - 2018-03-26 11:07:30 --> Model Class Initialized
INFO - 2018-03-26 11:07:30 --> Model Class Initialized
INFO - 2018-03-26 11:07:30 --> Model Class Initialized
INFO - 2018-03-26 11:07:30 --> Model Class Initialized
INFO - 2018-03-26 11:07:30 --> Model Class Initialized
INFO - 2018-03-26 11:07:30 --> Model Class Initialized
INFO - 2018-03-26 11:07:30 --> Model Class Initialized
INFO - 2018-03-26 11:07:30 --> Model Class Initialized
INFO - 2018-03-26 11:07:30 --> Model Class Initialized
INFO - 2018-03-26 11:07:30 --> Model Class Initialized
INFO - 2018-03-26 11:07:30 --> Helper loaded: date_helper
INFO - 2018-03-26 11:07:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:07:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:07:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:07:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:07:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:07:30 --> Final output sent to browser
DEBUG - 2018-03-26 16:07:30 --> Total execution time: 0.0912
INFO - 2018-03-26 11:07:39 --> Config Class Initialized
INFO - 2018-03-26 11:07:39 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:07:39 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:07:39 --> Utf8 Class Initialized
INFO - 2018-03-26 11:07:39 --> URI Class Initialized
INFO - 2018-03-26 11:07:39 --> Router Class Initialized
INFO - 2018-03-26 11:07:39 --> Output Class Initialized
INFO - 2018-03-26 11:07:39 --> Security Class Initialized
DEBUG - 2018-03-26 11:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:07:39 --> Input Class Initialized
INFO - 2018-03-26 11:07:39 --> Language Class Initialized
INFO - 2018-03-26 11:07:39 --> Loader Class Initialized
INFO - 2018-03-26 11:07:39 --> Helper loaded: url_helper
INFO - 2018-03-26 11:07:39 --> Helper loaded: form_helper
INFO - 2018-03-26 11:07:39 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:07:39 --> Controller Class Initialized
INFO - 2018-03-26 11:07:39 --> Model Class Initialized
INFO - 2018-03-26 11:07:39 --> Model Class Initialized
INFO - 2018-03-26 11:07:39 --> Model Class Initialized
INFO - 2018-03-26 11:07:39 --> Model Class Initialized
INFO - 2018-03-26 11:07:39 --> Model Class Initialized
INFO - 2018-03-26 11:07:39 --> Model Class Initialized
INFO - 2018-03-26 11:07:39 --> Model Class Initialized
INFO - 2018-03-26 11:07:39 --> Model Class Initialized
INFO - 2018-03-26 11:07:39 --> Model Class Initialized
INFO - 2018-03-26 11:07:39 --> Model Class Initialized
INFO - 2018-03-26 11:07:39 --> Model Class Initialized
INFO - 2018-03-26 11:07:39 --> Model Class Initialized
INFO - 2018-03-26 11:07:39 --> Helper loaded: date_helper
INFO - 2018-03-26 11:07:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:07:39 --> Final output sent to browser
DEBUG - 2018-03-26 16:07:39 --> Total execution time: 0.0802
INFO - 2018-03-26 11:10:09 --> Config Class Initialized
INFO - 2018-03-26 11:10:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:09 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:09 --> URI Class Initialized
INFO - 2018-03-26 11:10:09 --> Router Class Initialized
INFO - 2018-03-26 11:10:09 --> Output Class Initialized
INFO - 2018-03-26 11:10:09 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:09 --> Input Class Initialized
INFO - 2018-03-26 11:10:09 --> Language Class Initialized
INFO - 2018-03-26 11:10:10 --> Loader Class Initialized
INFO - 2018-03-26 11:10:10 --> Helper loaded: url_helper
INFO - 2018-03-26 11:10:10 --> Helper loaded: form_helper
INFO - 2018-03-26 11:10:10 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:10:10 --> Controller Class Initialized
INFO - 2018-03-26 11:10:10 --> Model Class Initialized
INFO - 2018-03-26 11:10:10 --> Model Class Initialized
INFO - 2018-03-26 11:10:10 --> Model Class Initialized
INFO - 2018-03-26 11:10:10 --> Model Class Initialized
INFO - 2018-03-26 11:10:10 --> Model Class Initialized
INFO - 2018-03-26 11:10:10 --> Model Class Initialized
INFO - 2018-03-26 11:10:10 --> Model Class Initialized
INFO - 2018-03-26 11:10:10 --> Model Class Initialized
INFO - 2018-03-26 11:10:10 --> Model Class Initialized
INFO - 2018-03-26 11:10:10 --> Model Class Initialized
INFO - 2018-03-26 11:10:10 --> Helper loaded: date_helper
INFO - 2018-03-26 11:10:10 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:10:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:10:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:10:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/detail.php
INFO - 2018-03-26 16:10:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:10:10 --> Final output sent to browser
DEBUG - 2018-03-26 16:10:10 --> Total execution time: 0.1440
INFO - 2018-03-26 11:10:45 --> Config Class Initialized
INFO - 2018-03-26 11:10:45 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:10:45 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:10:45 --> Utf8 Class Initialized
INFO - 2018-03-26 11:10:45 --> URI Class Initialized
INFO - 2018-03-26 11:10:45 --> Router Class Initialized
INFO - 2018-03-26 11:10:45 --> Output Class Initialized
INFO - 2018-03-26 11:10:45 --> Security Class Initialized
DEBUG - 2018-03-26 11:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:10:45 --> Input Class Initialized
INFO - 2018-03-26 11:10:45 --> Language Class Initialized
INFO - 2018-03-26 11:10:45 --> Loader Class Initialized
INFO - 2018-03-26 11:10:45 --> Helper loaded: url_helper
INFO - 2018-03-26 11:10:45 --> Helper loaded: form_helper
INFO - 2018-03-26 11:10:45 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:10:45 --> Controller Class Initialized
INFO - 2018-03-26 11:10:45 --> Model Class Initialized
INFO - 2018-03-26 11:10:45 --> Model Class Initialized
INFO - 2018-03-26 11:10:45 --> Model Class Initialized
INFO - 2018-03-26 11:10:45 --> Model Class Initialized
INFO - 2018-03-26 11:10:45 --> Model Class Initialized
INFO - 2018-03-26 11:10:45 --> Model Class Initialized
INFO - 2018-03-26 11:10:45 --> Model Class Initialized
INFO - 2018-03-26 11:10:45 --> Model Class Initialized
INFO - 2018-03-26 11:10:45 --> Model Class Initialized
INFO - 2018-03-26 11:10:45 --> Model Class Initialized
INFO - 2018-03-26 11:10:45 --> Model Class Initialized
INFO - 2018-03-26 11:10:45 --> Model Class Initialized
INFO - 2018-03-26 11:10:45 --> Helper loaded: date_helper
INFO - 2018-03-26 11:10:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:10:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:10:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:10:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:10:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:10:45 --> Final output sent to browser
DEBUG - 2018-03-26 16:10:45 --> Total execution time: 0.0999
INFO - 2018-03-26 11:11:24 --> Config Class Initialized
INFO - 2018-03-26 11:11:24 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:11:24 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:11:24 --> Utf8 Class Initialized
INFO - 2018-03-26 11:11:25 --> URI Class Initialized
INFO - 2018-03-26 11:11:25 --> Router Class Initialized
INFO - 2018-03-26 11:11:25 --> Output Class Initialized
INFO - 2018-03-26 11:11:25 --> Security Class Initialized
DEBUG - 2018-03-26 11:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:11:25 --> Input Class Initialized
INFO - 2018-03-26 11:11:25 --> Language Class Initialized
INFO - 2018-03-26 11:11:25 --> Loader Class Initialized
INFO - 2018-03-26 11:11:25 --> Helper loaded: url_helper
INFO - 2018-03-26 11:11:25 --> Helper loaded: form_helper
INFO - 2018-03-26 11:11:25 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:11:25 --> Controller Class Initialized
INFO - 2018-03-26 11:11:25 --> Model Class Initialized
INFO - 2018-03-26 11:11:25 --> Model Class Initialized
INFO - 2018-03-26 11:11:25 --> Helper loaded: date_helper
INFO - 2018-03-26 11:11:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:11:25 --> Model Class Initialized
INFO - 2018-03-26 16:11:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:11:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:11:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\suplier/table.php
INFO - 2018-03-26 16:11:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:11:25 --> Final output sent to browser
DEBUG - 2018-03-26 16:11:25 --> Total execution time: 0.1124
INFO - 2018-03-26 11:11:32 --> Config Class Initialized
INFO - 2018-03-26 11:11:32 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:11:32 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:11:32 --> Utf8 Class Initialized
INFO - 2018-03-26 11:11:32 --> URI Class Initialized
INFO - 2018-03-26 11:11:32 --> Router Class Initialized
INFO - 2018-03-26 11:11:32 --> Output Class Initialized
INFO - 2018-03-26 11:11:32 --> Security Class Initialized
DEBUG - 2018-03-26 11:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:11:32 --> Input Class Initialized
INFO - 2018-03-26 11:11:32 --> Language Class Initialized
INFO - 2018-03-26 11:11:32 --> Loader Class Initialized
INFO - 2018-03-26 11:11:32 --> Helper loaded: url_helper
INFO - 2018-03-26 11:11:32 --> Helper loaded: form_helper
INFO - 2018-03-26 11:11:32 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:11:32 --> Controller Class Initialized
INFO - 2018-03-26 11:11:32 --> Model Class Initialized
INFO - 2018-03-26 11:11:32 --> Model Class Initialized
INFO - 2018-03-26 11:11:32 --> Model Class Initialized
INFO - 2018-03-26 11:11:32 --> Model Class Initialized
INFO - 2018-03-26 11:11:32 --> Model Class Initialized
INFO - 2018-03-26 11:11:32 --> Model Class Initialized
INFO - 2018-03-26 11:11:32 --> Model Class Initialized
INFO - 2018-03-26 11:11:32 --> Model Class Initialized
INFO - 2018-03-26 11:11:32 --> Model Class Initialized
INFO - 2018-03-26 11:11:32 --> Model Class Initialized
INFO - 2018-03-26 11:11:32 --> Model Class Initialized
INFO - 2018-03-26 11:11:32 --> Model Class Initialized
INFO - 2018-03-26 11:11:32 --> Helper loaded: date_helper
INFO - 2018-03-26 11:11:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:11:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:11:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:11:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-26 16:11:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:11:32 --> Final output sent to browser
DEBUG - 2018-03-26 16:11:32 --> Total execution time: 0.1080
INFO - 2018-03-26 11:11:35 --> Config Class Initialized
INFO - 2018-03-26 11:11:35 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:11:35 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:11:35 --> Utf8 Class Initialized
INFO - 2018-03-26 11:11:35 --> URI Class Initialized
INFO - 2018-03-26 11:11:35 --> Router Class Initialized
INFO - 2018-03-26 11:11:35 --> Output Class Initialized
INFO - 2018-03-26 11:11:35 --> Security Class Initialized
DEBUG - 2018-03-26 11:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:11:35 --> Input Class Initialized
INFO - 2018-03-26 11:11:35 --> Language Class Initialized
INFO - 2018-03-26 11:11:35 --> Loader Class Initialized
INFO - 2018-03-26 11:11:35 --> Helper loaded: url_helper
INFO - 2018-03-26 11:11:35 --> Helper loaded: form_helper
INFO - 2018-03-26 11:11:35 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:11:35 --> Controller Class Initialized
INFO - 2018-03-26 11:11:35 --> Model Class Initialized
INFO - 2018-03-26 11:11:35 --> Model Class Initialized
INFO - 2018-03-26 11:11:35 --> Model Class Initialized
INFO - 2018-03-26 11:11:35 --> Model Class Initialized
INFO - 2018-03-26 11:11:35 --> Model Class Initialized
INFO - 2018-03-26 11:11:35 --> Model Class Initialized
INFO - 2018-03-26 11:11:35 --> Model Class Initialized
INFO - 2018-03-26 11:11:35 --> Model Class Initialized
INFO - 2018-03-26 11:11:35 --> Model Class Initialized
INFO - 2018-03-26 11:11:35 --> Model Class Initialized
INFO - 2018-03-26 11:11:35 --> Model Class Initialized
INFO - 2018-03-26 11:11:35 --> Model Class Initialized
INFO - 2018-03-26 11:11:35 --> Helper loaded: date_helper
INFO - 2018-03-26 11:11:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:11:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:11:35 --> Final output sent to browser
DEBUG - 2018-03-26 16:11:35 --> Total execution time: 0.0934
INFO - 2018-03-26 11:11:38 --> Config Class Initialized
INFO - 2018-03-26 11:11:38 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:11:38 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:11:38 --> Utf8 Class Initialized
INFO - 2018-03-26 11:11:38 --> URI Class Initialized
INFO - 2018-03-26 11:11:38 --> Router Class Initialized
INFO - 2018-03-26 11:11:38 --> Output Class Initialized
INFO - 2018-03-26 11:11:38 --> Security Class Initialized
DEBUG - 2018-03-26 11:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:11:38 --> Input Class Initialized
INFO - 2018-03-26 11:11:38 --> Language Class Initialized
INFO - 2018-03-26 11:11:38 --> Loader Class Initialized
INFO - 2018-03-26 11:11:38 --> Helper loaded: url_helper
INFO - 2018-03-26 11:11:38 --> Helper loaded: form_helper
INFO - 2018-03-26 11:11:38 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:11:38 --> Controller Class Initialized
INFO - 2018-03-26 11:11:38 --> Model Class Initialized
INFO - 2018-03-26 11:11:38 --> Model Class Initialized
INFO - 2018-03-26 11:11:38 --> Model Class Initialized
INFO - 2018-03-26 11:11:38 --> Model Class Initialized
INFO - 2018-03-26 11:11:38 --> Model Class Initialized
INFO - 2018-03-26 11:11:38 --> Model Class Initialized
INFO - 2018-03-26 11:11:38 --> Model Class Initialized
INFO - 2018-03-26 11:11:38 --> Model Class Initialized
INFO - 2018-03-26 11:11:38 --> Model Class Initialized
INFO - 2018-03-26 11:11:38 --> Model Class Initialized
INFO - 2018-03-26 11:11:38 --> Model Class Initialized
INFO - 2018-03-26 11:11:38 --> Model Class Initialized
INFO - 2018-03-26 11:11:38 --> Helper loaded: date_helper
INFO - 2018-03-26 11:11:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:11:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:11:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:11:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:11:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:11:38 --> Final output sent to browser
DEBUG - 2018-03-26 16:11:38 --> Total execution time: 0.0845
INFO - 2018-03-26 11:15:03 --> Config Class Initialized
INFO - 2018-03-26 11:15:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:15:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:15:03 --> Utf8 Class Initialized
INFO - 2018-03-26 11:15:03 --> URI Class Initialized
INFO - 2018-03-26 11:15:03 --> Router Class Initialized
INFO - 2018-03-26 11:15:03 --> Output Class Initialized
INFO - 2018-03-26 11:15:03 --> Security Class Initialized
DEBUG - 2018-03-26 11:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:15:03 --> Input Class Initialized
INFO - 2018-03-26 11:15:03 --> Language Class Initialized
INFO - 2018-03-26 11:15:03 --> Loader Class Initialized
INFO - 2018-03-26 11:15:03 --> Helper loaded: url_helper
INFO - 2018-03-26 11:15:03 --> Helper loaded: form_helper
INFO - 2018-03-26 11:15:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:15:03 --> Controller Class Initialized
INFO - 2018-03-26 11:15:03 --> Model Class Initialized
INFO - 2018-03-26 11:15:03 --> Model Class Initialized
INFO - 2018-03-26 11:15:03 --> Model Class Initialized
INFO - 2018-03-26 11:15:03 --> Model Class Initialized
INFO - 2018-03-26 11:15:03 --> Model Class Initialized
INFO - 2018-03-26 11:15:03 --> Model Class Initialized
INFO - 2018-03-26 11:15:03 --> Model Class Initialized
INFO - 2018-03-26 11:15:03 --> Model Class Initialized
INFO - 2018-03-26 11:15:03 --> Model Class Initialized
INFO - 2018-03-26 11:15:03 --> Model Class Initialized
INFO - 2018-03-26 11:15:03 --> Model Class Initialized
INFO - 2018-03-26 11:15:03 --> Model Class Initialized
INFO - 2018-03-26 11:15:03 --> Helper loaded: date_helper
INFO - 2018-03-26 11:15:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:15:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:15:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:15:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:15:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:15:03 --> Final output sent to browser
DEBUG - 2018-03-26 16:15:03 --> Total execution time: 0.0987
INFO - 2018-03-26 11:15:09 --> Config Class Initialized
INFO - 2018-03-26 11:15:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:15:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:15:09 --> Utf8 Class Initialized
INFO - 2018-03-26 11:15:09 --> URI Class Initialized
INFO - 2018-03-26 11:15:09 --> Router Class Initialized
INFO - 2018-03-26 11:15:09 --> Output Class Initialized
INFO - 2018-03-26 11:15:09 --> Security Class Initialized
DEBUG - 2018-03-26 11:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:15:09 --> Input Class Initialized
INFO - 2018-03-26 11:15:09 --> Language Class Initialized
INFO - 2018-03-26 11:15:09 --> Loader Class Initialized
INFO - 2018-03-26 11:15:09 --> Helper loaded: url_helper
INFO - 2018-03-26 11:15:09 --> Helper loaded: form_helper
INFO - 2018-03-26 11:15:09 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:15:09 --> Controller Class Initialized
INFO - 2018-03-26 11:15:09 --> Model Class Initialized
INFO - 2018-03-26 11:15:09 --> Model Class Initialized
INFO - 2018-03-26 11:15:09 --> Model Class Initialized
INFO - 2018-03-26 11:15:09 --> Model Class Initialized
INFO - 2018-03-26 11:15:09 --> Model Class Initialized
INFO - 2018-03-26 11:15:09 --> Model Class Initialized
INFO - 2018-03-26 11:15:09 --> Model Class Initialized
INFO - 2018-03-26 11:15:09 --> Model Class Initialized
INFO - 2018-03-26 11:15:09 --> Model Class Initialized
INFO - 2018-03-26 11:15:09 --> Model Class Initialized
INFO - 2018-03-26 11:15:09 --> Model Class Initialized
INFO - 2018-03-26 11:15:09 --> Model Class Initialized
INFO - 2018-03-26 11:15:09 --> Helper loaded: date_helper
INFO - 2018-03-26 11:15:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:15:09 --> Final output sent to browser
DEBUG - 2018-03-26 16:15:09 --> Total execution time: 0.0908
INFO - 2018-03-26 11:17:01 --> Config Class Initialized
INFO - 2018-03-26 11:17:01 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:17:01 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:17:01 --> Utf8 Class Initialized
INFO - 2018-03-26 11:17:01 --> URI Class Initialized
INFO - 2018-03-26 11:17:01 --> Router Class Initialized
INFO - 2018-03-26 11:17:01 --> Output Class Initialized
INFO - 2018-03-26 11:17:01 --> Security Class Initialized
DEBUG - 2018-03-26 11:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:17:01 --> Input Class Initialized
INFO - 2018-03-26 11:17:01 --> Language Class Initialized
INFO - 2018-03-26 11:17:01 --> Loader Class Initialized
INFO - 2018-03-26 11:17:01 --> Helper loaded: url_helper
INFO - 2018-03-26 11:17:01 --> Helper loaded: form_helper
INFO - 2018-03-26 11:17:01 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:17:01 --> Controller Class Initialized
INFO - 2018-03-26 11:17:01 --> Model Class Initialized
INFO - 2018-03-26 11:17:01 --> Model Class Initialized
INFO - 2018-03-26 11:17:01 --> Model Class Initialized
INFO - 2018-03-26 11:17:01 --> Model Class Initialized
INFO - 2018-03-26 11:17:01 --> Model Class Initialized
INFO - 2018-03-26 11:17:01 --> Model Class Initialized
INFO - 2018-03-26 11:17:01 --> Model Class Initialized
INFO - 2018-03-26 11:17:01 --> Model Class Initialized
INFO - 2018-03-26 11:17:01 --> Model Class Initialized
INFO - 2018-03-26 11:17:01 --> Model Class Initialized
INFO - 2018-03-26 11:17:01 --> Model Class Initialized
INFO - 2018-03-26 11:17:01 --> Model Class Initialized
INFO - 2018-03-26 11:17:01 --> Helper loaded: date_helper
INFO - 2018-03-26 11:17:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:17:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:17:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:17:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:17:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:17:01 --> Final output sent to browser
DEBUG - 2018-03-26 16:17:01 --> Total execution time: 0.0922
INFO - 2018-03-26 11:17:05 --> Config Class Initialized
INFO - 2018-03-26 11:17:05 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:17:05 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:17:05 --> Utf8 Class Initialized
INFO - 2018-03-26 11:17:05 --> URI Class Initialized
INFO - 2018-03-26 11:17:05 --> Router Class Initialized
INFO - 2018-03-26 11:17:05 --> Output Class Initialized
INFO - 2018-03-26 11:17:05 --> Security Class Initialized
DEBUG - 2018-03-26 11:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:17:05 --> Input Class Initialized
INFO - 2018-03-26 11:17:05 --> Language Class Initialized
INFO - 2018-03-26 11:17:05 --> Loader Class Initialized
INFO - 2018-03-26 11:17:05 --> Helper loaded: url_helper
INFO - 2018-03-26 11:17:05 --> Helper loaded: form_helper
INFO - 2018-03-26 11:17:05 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:17:05 --> Controller Class Initialized
INFO - 2018-03-26 11:17:05 --> Model Class Initialized
INFO - 2018-03-26 11:17:05 --> Model Class Initialized
INFO - 2018-03-26 11:17:05 --> Model Class Initialized
INFO - 2018-03-26 11:17:05 --> Model Class Initialized
INFO - 2018-03-26 11:17:05 --> Model Class Initialized
INFO - 2018-03-26 11:17:05 --> Model Class Initialized
INFO - 2018-03-26 11:17:05 --> Model Class Initialized
INFO - 2018-03-26 11:17:05 --> Model Class Initialized
INFO - 2018-03-26 11:17:05 --> Model Class Initialized
INFO - 2018-03-26 11:17:05 --> Model Class Initialized
INFO - 2018-03-26 11:17:05 --> Model Class Initialized
INFO - 2018-03-26 11:17:05 --> Model Class Initialized
INFO - 2018-03-26 11:17:05 --> Helper loaded: date_helper
INFO - 2018-03-26 11:17:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:17:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:17:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:17:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:17:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:17:05 --> Final output sent to browser
DEBUG - 2018-03-26 16:17:05 --> Total execution time: 0.1060
INFO - 2018-03-26 11:17:12 --> Config Class Initialized
INFO - 2018-03-26 11:17:12 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:17:12 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:17:12 --> Utf8 Class Initialized
INFO - 2018-03-26 11:17:12 --> URI Class Initialized
INFO - 2018-03-26 11:17:12 --> Router Class Initialized
INFO - 2018-03-26 11:17:12 --> Output Class Initialized
INFO - 2018-03-26 11:17:12 --> Security Class Initialized
DEBUG - 2018-03-26 11:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:17:12 --> Input Class Initialized
INFO - 2018-03-26 11:17:12 --> Language Class Initialized
INFO - 2018-03-26 11:17:12 --> Loader Class Initialized
INFO - 2018-03-26 11:17:12 --> Helper loaded: url_helper
INFO - 2018-03-26 11:17:12 --> Helper loaded: form_helper
INFO - 2018-03-26 11:17:12 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:17:12 --> Controller Class Initialized
INFO - 2018-03-26 11:17:12 --> Model Class Initialized
INFO - 2018-03-26 11:17:12 --> Model Class Initialized
INFO - 2018-03-26 11:17:12 --> Model Class Initialized
INFO - 2018-03-26 11:17:12 --> Model Class Initialized
INFO - 2018-03-26 11:17:12 --> Model Class Initialized
INFO - 2018-03-26 11:17:12 --> Model Class Initialized
INFO - 2018-03-26 11:17:12 --> Model Class Initialized
INFO - 2018-03-26 11:17:12 --> Model Class Initialized
INFO - 2018-03-26 11:17:12 --> Model Class Initialized
INFO - 2018-03-26 11:17:12 --> Model Class Initialized
INFO - 2018-03-26 11:17:12 --> Model Class Initialized
INFO - 2018-03-26 11:17:12 --> Model Class Initialized
INFO - 2018-03-26 11:17:12 --> Helper loaded: date_helper
INFO - 2018-03-26 11:17:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:17:12 --> Final output sent to browser
DEBUG - 2018-03-26 16:17:12 --> Total execution time: 0.0860
INFO - 2018-03-26 11:17:21 --> Config Class Initialized
INFO - 2018-03-26 11:17:21 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:17:21 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:17:21 --> Utf8 Class Initialized
INFO - 2018-03-26 11:17:21 --> URI Class Initialized
INFO - 2018-03-26 11:17:21 --> Router Class Initialized
INFO - 2018-03-26 11:17:21 --> Output Class Initialized
INFO - 2018-03-26 11:17:21 --> Security Class Initialized
DEBUG - 2018-03-26 11:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:17:21 --> Input Class Initialized
INFO - 2018-03-26 11:17:21 --> Language Class Initialized
INFO - 2018-03-26 11:17:21 --> Loader Class Initialized
INFO - 2018-03-26 11:17:21 --> Helper loaded: url_helper
INFO - 2018-03-26 11:17:21 --> Helper loaded: form_helper
INFO - 2018-03-26 11:17:21 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:17:21 --> Controller Class Initialized
INFO - 2018-03-26 11:17:21 --> Model Class Initialized
INFO - 2018-03-26 11:17:21 --> Model Class Initialized
INFO - 2018-03-26 11:17:21 --> Model Class Initialized
INFO - 2018-03-26 11:17:21 --> Model Class Initialized
INFO - 2018-03-26 11:17:21 --> Model Class Initialized
INFO - 2018-03-26 11:17:21 --> Model Class Initialized
INFO - 2018-03-26 11:17:21 --> Model Class Initialized
INFO - 2018-03-26 11:17:21 --> Model Class Initialized
INFO - 2018-03-26 11:17:21 --> Model Class Initialized
INFO - 2018-03-26 11:17:21 --> Model Class Initialized
INFO - 2018-03-26 11:17:21 --> Model Class Initialized
INFO - 2018-03-26 11:17:21 --> Model Class Initialized
INFO - 2018-03-26 11:17:21 --> Helper loaded: date_helper
INFO - 2018-03-26 11:17:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:17:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:17:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:17:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:17:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:17:21 --> Final output sent to browser
DEBUG - 2018-03-26 16:17:21 --> Total execution time: 0.0870
INFO - 2018-03-26 11:20:31 --> Config Class Initialized
INFO - 2018-03-26 11:20:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:20:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:20:31 --> Utf8 Class Initialized
INFO - 2018-03-26 11:20:31 --> URI Class Initialized
INFO - 2018-03-26 11:20:31 --> Router Class Initialized
INFO - 2018-03-26 11:20:31 --> Output Class Initialized
INFO - 2018-03-26 11:20:31 --> Security Class Initialized
DEBUG - 2018-03-26 11:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:20:31 --> Input Class Initialized
INFO - 2018-03-26 11:20:31 --> Language Class Initialized
INFO - 2018-03-26 11:20:31 --> Loader Class Initialized
INFO - 2018-03-26 11:20:31 --> Helper loaded: url_helper
INFO - 2018-03-26 11:20:31 --> Helper loaded: form_helper
INFO - 2018-03-26 11:20:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:20:31 --> Controller Class Initialized
INFO - 2018-03-26 11:20:31 --> Model Class Initialized
INFO - 2018-03-26 11:20:31 --> Model Class Initialized
INFO - 2018-03-26 11:20:31 --> Model Class Initialized
INFO - 2018-03-26 11:20:31 --> Model Class Initialized
INFO - 2018-03-26 11:20:31 --> Model Class Initialized
INFO - 2018-03-26 11:20:31 --> Model Class Initialized
INFO - 2018-03-26 11:20:31 --> Model Class Initialized
INFO - 2018-03-26 11:20:31 --> Model Class Initialized
INFO - 2018-03-26 11:20:31 --> Model Class Initialized
INFO - 2018-03-26 11:20:31 --> Model Class Initialized
INFO - 2018-03-26 11:20:31 --> Model Class Initialized
INFO - 2018-03-26 11:20:31 --> Model Class Initialized
INFO - 2018-03-26 11:20:31 --> Helper loaded: date_helper
INFO - 2018-03-26 11:20:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:20:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:20:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:20:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:20:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:20:31 --> Final output sent to browser
DEBUG - 2018-03-26 16:20:31 --> Total execution time: 0.0947
INFO - 2018-03-26 11:20:33 --> Config Class Initialized
INFO - 2018-03-26 11:20:33 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:20:33 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:20:33 --> Utf8 Class Initialized
INFO - 2018-03-26 11:20:33 --> URI Class Initialized
INFO - 2018-03-26 11:20:33 --> Router Class Initialized
INFO - 2018-03-26 11:20:33 --> Output Class Initialized
INFO - 2018-03-26 11:20:33 --> Security Class Initialized
DEBUG - 2018-03-26 11:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:20:33 --> Input Class Initialized
INFO - 2018-03-26 11:20:33 --> Language Class Initialized
INFO - 2018-03-26 11:20:33 --> Loader Class Initialized
INFO - 2018-03-26 11:20:33 --> Helper loaded: url_helper
INFO - 2018-03-26 11:20:33 --> Helper loaded: form_helper
INFO - 2018-03-26 11:20:33 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:20:33 --> Controller Class Initialized
INFO - 2018-03-26 11:20:33 --> Model Class Initialized
INFO - 2018-03-26 11:20:33 --> Model Class Initialized
INFO - 2018-03-26 11:20:33 --> Model Class Initialized
INFO - 2018-03-26 11:20:33 --> Model Class Initialized
INFO - 2018-03-26 11:20:33 --> Model Class Initialized
INFO - 2018-03-26 11:20:33 --> Model Class Initialized
INFO - 2018-03-26 11:20:33 --> Model Class Initialized
INFO - 2018-03-26 11:20:33 --> Model Class Initialized
INFO - 2018-03-26 11:20:33 --> Model Class Initialized
INFO - 2018-03-26 11:20:33 --> Model Class Initialized
INFO - 2018-03-26 11:20:33 --> Model Class Initialized
INFO - 2018-03-26 11:20:33 --> Model Class Initialized
INFO - 2018-03-26 11:20:33 --> Helper loaded: date_helper
INFO - 2018-03-26 11:20:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:20:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:20:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:20:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:20:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:20:34 --> Final output sent to browser
DEBUG - 2018-03-26 16:20:34 --> Total execution time: 0.1228
INFO - 2018-03-26 11:20:35 --> Config Class Initialized
INFO - 2018-03-26 11:20:35 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:20:35 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:20:35 --> Utf8 Class Initialized
INFO - 2018-03-26 11:20:35 --> URI Class Initialized
INFO - 2018-03-26 11:20:35 --> Router Class Initialized
INFO - 2018-03-26 11:20:35 --> Output Class Initialized
INFO - 2018-03-26 11:20:35 --> Security Class Initialized
DEBUG - 2018-03-26 11:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:20:35 --> Input Class Initialized
INFO - 2018-03-26 11:20:35 --> Language Class Initialized
INFO - 2018-03-26 11:20:35 --> Loader Class Initialized
INFO - 2018-03-26 11:20:35 --> Helper loaded: url_helper
INFO - 2018-03-26 11:20:35 --> Helper loaded: form_helper
INFO - 2018-03-26 11:20:35 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:20:36 --> Controller Class Initialized
INFO - 2018-03-26 11:20:36 --> Model Class Initialized
INFO - 2018-03-26 11:20:36 --> Model Class Initialized
INFO - 2018-03-26 11:20:36 --> Model Class Initialized
INFO - 2018-03-26 11:20:36 --> Model Class Initialized
INFO - 2018-03-26 11:20:36 --> Model Class Initialized
INFO - 2018-03-26 11:20:36 --> Model Class Initialized
INFO - 2018-03-26 11:20:36 --> Model Class Initialized
INFO - 2018-03-26 11:20:36 --> Model Class Initialized
INFO - 2018-03-26 11:20:36 --> Model Class Initialized
INFO - 2018-03-26 11:20:36 --> Model Class Initialized
INFO - 2018-03-26 11:20:36 --> Model Class Initialized
INFO - 2018-03-26 11:20:36 --> Model Class Initialized
INFO - 2018-03-26 11:20:36 --> Helper loaded: date_helper
INFO - 2018-03-26 11:20:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:20:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:20:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:20:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:20:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:20:36 --> Final output sent to browser
DEBUG - 2018-03-26 16:20:36 --> Total execution time: 0.0968
INFO - 2018-03-26 11:20:37 --> Config Class Initialized
INFO - 2018-03-26 11:20:37 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:20:37 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:20:37 --> Utf8 Class Initialized
INFO - 2018-03-26 11:20:37 --> URI Class Initialized
INFO - 2018-03-26 11:20:37 --> Router Class Initialized
INFO - 2018-03-26 11:20:37 --> Output Class Initialized
INFO - 2018-03-26 11:20:37 --> Security Class Initialized
DEBUG - 2018-03-26 11:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:20:37 --> Input Class Initialized
INFO - 2018-03-26 11:20:37 --> Language Class Initialized
INFO - 2018-03-26 11:20:37 --> Loader Class Initialized
INFO - 2018-03-26 11:20:37 --> Helper loaded: url_helper
INFO - 2018-03-26 11:20:37 --> Helper loaded: form_helper
INFO - 2018-03-26 11:20:37 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:20:37 --> Controller Class Initialized
INFO - 2018-03-26 11:20:37 --> Model Class Initialized
INFO - 2018-03-26 11:20:37 --> Model Class Initialized
INFO - 2018-03-26 11:20:37 --> Model Class Initialized
INFO - 2018-03-26 11:20:37 --> Model Class Initialized
INFO - 2018-03-26 11:20:37 --> Model Class Initialized
INFO - 2018-03-26 11:20:37 --> Model Class Initialized
INFO - 2018-03-26 11:20:37 --> Model Class Initialized
INFO - 2018-03-26 11:20:37 --> Model Class Initialized
INFO - 2018-03-26 11:20:37 --> Model Class Initialized
INFO - 2018-03-26 11:20:37 --> Model Class Initialized
INFO - 2018-03-26 11:20:37 --> Model Class Initialized
INFO - 2018-03-26 11:20:37 --> Model Class Initialized
INFO - 2018-03-26 11:20:37 --> Helper loaded: date_helper
INFO - 2018-03-26 11:20:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:20:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:20:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:20:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:20:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:20:38 --> Final output sent to browser
DEBUG - 2018-03-26 16:20:38 --> Total execution time: 0.1026
INFO - 2018-03-26 11:21:01 --> Config Class Initialized
INFO - 2018-03-26 11:21:01 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:21:01 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:21:01 --> Utf8 Class Initialized
INFO - 2018-03-26 11:21:01 --> URI Class Initialized
INFO - 2018-03-26 11:21:01 --> Router Class Initialized
INFO - 2018-03-26 11:21:01 --> Output Class Initialized
INFO - 2018-03-26 11:21:01 --> Security Class Initialized
DEBUG - 2018-03-26 11:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:21:01 --> Input Class Initialized
INFO - 2018-03-26 11:21:01 --> Language Class Initialized
INFO - 2018-03-26 11:21:01 --> Loader Class Initialized
INFO - 2018-03-26 11:21:01 --> Helper loaded: url_helper
INFO - 2018-03-26 11:21:01 --> Helper loaded: form_helper
INFO - 2018-03-26 11:21:01 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:21:01 --> Controller Class Initialized
INFO - 2018-03-26 11:21:01 --> Model Class Initialized
INFO - 2018-03-26 11:21:01 --> Model Class Initialized
INFO - 2018-03-26 11:21:01 --> Model Class Initialized
INFO - 2018-03-26 11:21:01 --> Model Class Initialized
INFO - 2018-03-26 11:21:01 --> Model Class Initialized
INFO - 2018-03-26 11:21:01 --> Model Class Initialized
INFO - 2018-03-26 11:21:01 --> Model Class Initialized
INFO - 2018-03-26 11:21:01 --> Model Class Initialized
INFO - 2018-03-26 11:21:01 --> Model Class Initialized
INFO - 2018-03-26 11:21:01 --> Model Class Initialized
INFO - 2018-03-26 11:21:01 --> Model Class Initialized
INFO - 2018-03-26 11:21:01 --> Model Class Initialized
INFO - 2018-03-26 11:21:01 --> Helper loaded: date_helper
INFO - 2018-03-26 11:21:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:21:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:21:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:21:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:21:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:21:02 --> Final output sent to browser
DEBUG - 2018-03-26 16:21:02 --> Total execution time: 0.0852
INFO - 2018-03-26 11:21:07 --> Config Class Initialized
INFO - 2018-03-26 11:21:07 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:21:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:21:07 --> Utf8 Class Initialized
INFO - 2018-03-26 11:21:07 --> URI Class Initialized
INFO - 2018-03-26 11:21:07 --> Router Class Initialized
INFO - 2018-03-26 11:21:07 --> Output Class Initialized
INFO - 2018-03-26 11:21:07 --> Security Class Initialized
DEBUG - 2018-03-26 11:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:21:07 --> Input Class Initialized
INFO - 2018-03-26 11:21:07 --> Language Class Initialized
INFO - 2018-03-26 11:21:07 --> Loader Class Initialized
INFO - 2018-03-26 11:21:07 --> Helper loaded: url_helper
INFO - 2018-03-26 11:21:07 --> Helper loaded: form_helper
INFO - 2018-03-26 11:21:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:21:07 --> Controller Class Initialized
INFO - 2018-03-26 11:21:07 --> Model Class Initialized
INFO - 2018-03-26 11:21:07 --> Model Class Initialized
INFO - 2018-03-26 11:21:07 --> Model Class Initialized
INFO - 2018-03-26 11:21:07 --> Model Class Initialized
INFO - 2018-03-26 11:21:07 --> Model Class Initialized
INFO - 2018-03-26 11:21:07 --> Model Class Initialized
INFO - 2018-03-26 11:21:07 --> Model Class Initialized
INFO - 2018-03-26 11:21:07 --> Model Class Initialized
INFO - 2018-03-26 11:21:07 --> Model Class Initialized
INFO - 2018-03-26 11:21:07 --> Model Class Initialized
INFO - 2018-03-26 11:21:07 --> Model Class Initialized
INFO - 2018-03-26 11:21:07 --> Model Class Initialized
INFO - 2018-03-26 11:21:07 --> Helper loaded: date_helper
INFO - 2018-03-26 11:21:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:21:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:21:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:21:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:21:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:21:07 --> Final output sent to browser
DEBUG - 2018-03-26 16:21:07 --> Total execution time: 0.1036
INFO - 2018-03-26 11:21:09 --> Config Class Initialized
INFO - 2018-03-26 11:21:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:21:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:21:09 --> Utf8 Class Initialized
INFO - 2018-03-26 11:21:09 --> URI Class Initialized
INFO - 2018-03-26 11:21:09 --> Router Class Initialized
INFO - 2018-03-26 11:21:09 --> Output Class Initialized
INFO - 2018-03-26 11:21:09 --> Security Class Initialized
DEBUG - 2018-03-26 11:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:21:09 --> Input Class Initialized
INFO - 2018-03-26 11:21:09 --> Language Class Initialized
INFO - 2018-03-26 11:21:09 --> Loader Class Initialized
INFO - 2018-03-26 11:21:09 --> Helper loaded: url_helper
INFO - 2018-03-26 11:21:09 --> Helper loaded: form_helper
INFO - 2018-03-26 11:21:09 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:21:09 --> Controller Class Initialized
INFO - 2018-03-26 11:21:09 --> Model Class Initialized
INFO - 2018-03-26 11:21:09 --> Model Class Initialized
INFO - 2018-03-26 11:21:09 --> Model Class Initialized
INFO - 2018-03-26 11:21:09 --> Model Class Initialized
INFO - 2018-03-26 11:21:09 --> Model Class Initialized
INFO - 2018-03-26 11:21:09 --> Model Class Initialized
INFO - 2018-03-26 11:21:09 --> Model Class Initialized
INFO - 2018-03-26 11:21:09 --> Model Class Initialized
INFO - 2018-03-26 11:21:09 --> Model Class Initialized
INFO - 2018-03-26 11:21:09 --> Model Class Initialized
INFO - 2018-03-26 11:21:09 --> Model Class Initialized
INFO - 2018-03-26 11:21:09 --> Model Class Initialized
INFO - 2018-03-26 11:21:09 --> Helper loaded: date_helper
INFO - 2018-03-26 11:21:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:21:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:21:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:21:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:21:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:21:09 --> Final output sent to browser
DEBUG - 2018-03-26 16:21:09 --> Total execution time: 0.1020
INFO - 2018-03-26 11:21:12 --> Config Class Initialized
INFO - 2018-03-26 11:21:12 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:21:12 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:21:12 --> Utf8 Class Initialized
INFO - 2018-03-26 11:21:12 --> URI Class Initialized
INFO - 2018-03-26 11:21:12 --> Router Class Initialized
INFO - 2018-03-26 11:21:12 --> Output Class Initialized
INFO - 2018-03-26 11:21:12 --> Security Class Initialized
DEBUG - 2018-03-26 11:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:21:12 --> Input Class Initialized
INFO - 2018-03-26 11:21:12 --> Language Class Initialized
INFO - 2018-03-26 11:21:12 --> Loader Class Initialized
INFO - 2018-03-26 11:21:12 --> Helper loaded: url_helper
INFO - 2018-03-26 11:21:12 --> Helper loaded: form_helper
INFO - 2018-03-26 11:21:12 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:21:12 --> Controller Class Initialized
INFO - 2018-03-26 11:21:12 --> Model Class Initialized
INFO - 2018-03-26 11:21:12 --> Model Class Initialized
INFO - 2018-03-26 11:21:12 --> Model Class Initialized
INFO - 2018-03-26 11:21:12 --> Model Class Initialized
INFO - 2018-03-26 11:21:12 --> Model Class Initialized
INFO - 2018-03-26 11:21:12 --> Model Class Initialized
INFO - 2018-03-26 11:21:12 --> Model Class Initialized
INFO - 2018-03-26 11:21:12 --> Model Class Initialized
INFO - 2018-03-26 11:21:12 --> Model Class Initialized
INFO - 2018-03-26 11:21:12 --> Model Class Initialized
INFO - 2018-03-26 11:21:12 --> Model Class Initialized
INFO - 2018-03-26 11:21:12 --> Model Class Initialized
INFO - 2018-03-26 11:21:12 --> Helper loaded: date_helper
INFO - 2018-03-26 11:21:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:21:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:21:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:21:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:21:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:21:12 --> Final output sent to browser
DEBUG - 2018-03-26 16:21:12 --> Total execution time: 0.0967
INFO - 2018-03-26 11:22:00 --> Config Class Initialized
INFO - 2018-03-26 11:22:00 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:22:00 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:22:00 --> Utf8 Class Initialized
INFO - 2018-03-26 11:22:00 --> URI Class Initialized
INFO - 2018-03-26 11:22:00 --> Router Class Initialized
INFO - 2018-03-26 11:22:00 --> Output Class Initialized
INFO - 2018-03-26 11:22:00 --> Security Class Initialized
DEBUG - 2018-03-26 11:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:22:00 --> Input Class Initialized
INFO - 2018-03-26 11:22:00 --> Language Class Initialized
INFO - 2018-03-26 11:22:00 --> Loader Class Initialized
INFO - 2018-03-26 11:22:00 --> Helper loaded: url_helper
INFO - 2018-03-26 11:22:00 --> Helper loaded: form_helper
INFO - 2018-03-26 11:22:00 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:22:00 --> Controller Class Initialized
INFO - 2018-03-26 11:22:00 --> Model Class Initialized
INFO - 2018-03-26 11:22:00 --> Model Class Initialized
INFO - 2018-03-26 11:22:00 --> Model Class Initialized
INFO - 2018-03-26 11:22:00 --> Model Class Initialized
INFO - 2018-03-26 11:22:00 --> Model Class Initialized
INFO - 2018-03-26 11:22:00 --> Model Class Initialized
INFO - 2018-03-26 11:22:00 --> Model Class Initialized
INFO - 2018-03-26 11:22:00 --> Model Class Initialized
INFO - 2018-03-26 11:22:00 --> Model Class Initialized
INFO - 2018-03-26 11:22:00 --> Model Class Initialized
INFO - 2018-03-26 11:22:00 --> Model Class Initialized
INFO - 2018-03-26 11:22:00 --> Model Class Initialized
INFO - 2018-03-26 11:22:00 --> Helper loaded: date_helper
INFO - 2018-03-26 11:22:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:22:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:22:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:22:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:22:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:22:00 --> Final output sent to browser
DEBUG - 2018-03-26 16:22:00 --> Total execution time: 0.0978
INFO - 2018-03-26 11:22:06 --> Config Class Initialized
INFO - 2018-03-26 11:22:06 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:22:06 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:22:06 --> Utf8 Class Initialized
INFO - 2018-03-26 11:22:06 --> URI Class Initialized
INFO - 2018-03-26 11:22:06 --> Router Class Initialized
INFO - 2018-03-26 11:22:06 --> Output Class Initialized
INFO - 2018-03-26 11:22:06 --> Security Class Initialized
DEBUG - 2018-03-26 11:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:22:06 --> Input Class Initialized
INFO - 2018-03-26 11:22:06 --> Language Class Initialized
INFO - 2018-03-26 11:22:06 --> Loader Class Initialized
INFO - 2018-03-26 11:22:06 --> Helper loaded: url_helper
INFO - 2018-03-26 11:22:06 --> Helper loaded: form_helper
INFO - 2018-03-26 11:22:06 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:22:06 --> Controller Class Initialized
INFO - 2018-03-26 11:22:06 --> Model Class Initialized
INFO - 2018-03-26 11:22:06 --> Model Class Initialized
INFO - 2018-03-26 11:22:06 --> Model Class Initialized
INFO - 2018-03-26 11:22:06 --> Model Class Initialized
INFO - 2018-03-26 11:22:06 --> Model Class Initialized
INFO - 2018-03-26 11:22:06 --> Model Class Initialized
INFO - 2018-03-26 11:22:06 --> Model Class Initialized
INFO - 2018-03-26 11:22:06 --> Model Class Initialized
INFO - 2018-03-26 11:22:06 --> Model Class Initialized
INFO - 2018-03-26 11:22:06 --> Model Class Initialized
INFO - 2018-03-26 11:22:06 --> Model Class Initialized
INFO - 2018-03-26 11:22:06 --> Model Class Initialized
INFO - 2018-03-26 11:22:06 --> Helper loaded: date_helper
INFO - 2018-03-26 11:22:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:22:06 --> Final output sent to browser
DEBUG - 2018-03-26 16:22:06 --> Total execution time: 0.0768
INFO - 2018-03-26 11:22:13 --> Config Class Initialized
INFO - 2018-03-26 11:22:13 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:22:13 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:22:13 --> Utf8 Class Initialized
INFO - 2018-03-26 11:22:13 --> URI Class Initialized
INFO - 2018-03-26 11:22:13 --> Router Class Initialized
INFO - 2018-03-26 11:22:13 --> Output Class Initialized
INFO - 2018-03-26 11:22:13 --> Security Class Initialized
DEBUG - 2018-03-26 11:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:22:13 --> Input Class Initialized
INFO - 2018-03-26 11:22:13 --> Language Class Initialized
INFO - 2018-03-26 11:22:13 --> Loader Class Initialized
INFO - 2018-03-26 11:22:13 --> Helper loaded: url_helper
INFO - 2018-03-26 11:22:13 --> Helper loaded: form_helper
INFO - 2018-03-26 11:22:13 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:22:13 --> Controller Class Initialized
INFO - 2018-03-26 11:22:13 --> Model Class Initialized
INFO - 2018-03-26 11:22:13 --> Model Class Initialized
INFO - 2018-03-26 11:22:13 --> Model Class Initialized
INFO - 2018-03-26 11:22:13 --> Model Class Initialized
INFO - 2018-03-26 11:22:13 --> Model Class Initialized
INFO - 2018-03-26 11:22:13 --> Model Class Initialized
INFO - 2018-03-26 11:22:13 --> Model Class Initialized
INFO - 2018-03-26 11:22:13 --> Model Class Initialized
INFO - 2018-03-26 11:22:13 --> Model Class Initialized
INFO - 2018-03-26 11:22:13 --> Model Class Initialized
INFO - 2018-03-26 11:22:13 --> Model Class Initialized
INFO - 2018-03-26 11:22:13 --> Model Class Initialized
INFO - 2018-03-26 11:22:13 --> Helper loaded: date_helper
INFO - 2018-03-26 11:22:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:22:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:22:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:22:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:22:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:22:13 --> Final output sent to browser
DEBUG - 2018-03-26 16:22:13 --> Total execution time: 0.0931
INFO - 2018-03-26 11:22:20 --> Config Class Initialized
INFO - 2018-03-26 11:22:20 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:22:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:22:20 --> Utf8 Class Initialized
INFO - 2018-03-26 11:22:20 --> URI Class Initialized
INFO - 2018-03-26 11:22:20 --> Router Class Initialized
INFO - 2018-03-26 11:22:20 --> Output Class Initialized
INFO - 2018-03-26 11:22:20 --> Security Class Initialized
DEBUG - 2018-03-26 11:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:22:20 --> Input Class Initialized
INFO - 2018-03-26 11:22:20 --> Language Class Initialized
INFO - 2018-03-26 11:22:20 --> Loader Class Initialized
INFO - 2018-03-26 11:22:20 --> Helper loaded: url_helper
INFO - 2018-03-26 11:22:20 --> Helper loaded: form_helper
INFO - 2018-03-26 11:22:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:22:20 --> Controller Class Initialized
INFO - 2018-03-26 11:22:20 --> Model Class Initialized
INFO - 2018-03-26 11:22:20 --> Model Class Initialized
INFO - 2018-03-26 11:22:20 --> Model Class Initialized
INFO - 2018-03-26 11:22:20 --> Model Class Initialized
INFO - 2018-03-26 11:22:20 --> Model Class Initialized
INFO - 2018-03-26 11:22:20 --> Model Class Initialized
INFO - 2018-03-26 11:22:20 --> Model Class Initialized
INFO - 2018-03-26 11:22:20 --> Model Class Initialized
INFO - 2018-03-26 11:22:20 --> Model Class Initialized
INFO - 2018-03-26 11:22:20 --> Model Class Initialized
INFO - 2018-03-26 11:22:20 --> Model Class Initialized
INFO - 2018-03-26 11:22:20 --> Model Class Initialized
INFO - 2018-03-26 11:22:20 --> Helper loaded: date_helper
INFO - 2018-03-26 11:22:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:22:20 --> Final output sent to browser
DEBUG - 2018-03-26 16:22:20 --> Total execution time: 0.0871
INFO - 2018-03-26 11:22:59 --> Config Class Initialized
INFO - 2018-03-26 11:22:59 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:22:59 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:22:59 --> Utf8 Class Initialized
INFO - 2018-03-26 11:22:59 --> URI Class Initialized
INFO - 2018-03-26 11:22:59 --> Router Class Initialized
INFO - 2018-03-26 11:22:59 --> Output Class Initialized
INFO - 2018-03-26 11:22:59 --> Security Class Initialized
DEBUG - 2018-03-26 11:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:22:59 --> Input Class Initialized
INFO - 2018-03-26 11:22:59 --> Language Class Initialized
INFO - 2018-03-26 11:22:59 --> Loader Class Initialized
INFO - 2018-03-26 11:22:59 --> Helper loaded: url_helper
INFO - 2018-03-26 11:22:59 --> Helper loaded: form_helper
INFO - 2018-03-26 11:22:59 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:22:59 --> Controller Class Initialized
INFO - 2018-03-26 11:22:59 --> Model Class Initialized
INFO - 2018-03-26 11:22:59 --> Model Class Initialized
INFO - 2018-03-26 11:22:59 --> Model Class Initialized
INFO - 2018-03-26 11:22:59 --> Model Class Initialized
INFO - 2018-03-26 11:22:59 --> Model Class Initialized
INFO - 2018-03-26 11:22:59 --> Model Class Initialized
INFO - 2018-03-26 11:22:59 --> Model Class Initialized
INFO - 2018-03-26 11:22:59 --> Model Class Initialized
INFO - 2018-03-26 11:22:59 --> Model Class Initialized
INFO - 2018-03-26 11:22:59 --> Model Class Initialized
INFO - 2018-03-26 11:22:59 --> Model Class Initialized
INFO - 2018-03-26 11:22:59 --> Model Class Initialized
INFO - 2018-03-26 11:22:59 --> Helper loaded: date_helper
INFO - 2018-03-26 11:22:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:22:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:22:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:22:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:22:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:22:59 --> Final output sent to browser
DEBUG - 2018-03-26 16:22:59 --> Total execution time: 0.0954
INFO - 2018-03-26 11:23:19 --> Config Class Initialized
INFO - 2018-03-26 11:23:19 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:23:19 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:23:19 --> Utf8 Class Initialized
INFO - 2018-03-26 11:23:19 --> URI Class Initialized
INFO - 2018-03-26 11:23:19 --> Router Class Initialized
INFO - 2018-03-26 11:23:19 --> Output Class Initialized
INFO - 2018-03-26 11:23:19 --> Security Class Initialized
DEBUG - 2018-03-26 11:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:23:19 --> Input Class Initialized
INFO - 2018-03-26 11:23:19 --> Language Class Initialized
INFO - 2018-03-26 11:23:19 --> Loader Class Initialized
INFO - 2018-03-26 11:23:19 --> Helper loaded: url_helper
INFO - 2018-03-26 11:23:19 --> Helper loaded: form_helper
INFO - 2018-03-26 11:23:19 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:23:19 --> Controller Class Initialized
INFO - 2018-03-26 11:23:19 --> Model Class Initialized
INFO - 2018-03-26 11:23:19 --> Model Class Initialized
INFO - 2018-03-26 11:23:19 --> Model Class Initialized
INFO - 2018-03-26 11:23:19 --> Model Class Initialized
INFO - 2018-03-26 11:23:19 --> Model Class Initialized
INFO - 2018-03-26 11:23:19 --> Model Class Initialized
INFO - 2018-03-26 11:23:19 --> Model Class Initialized
INFO - 2018-03-26 11:23:19 --> Model Class Initialized
INFO - 2018-03-26 11:23:19 --> Model Class Initialized
INFO - 2018-03-26 11:23:19 --> Model Class Initialized
INFO - 2018-03-26 11:23:19 --> Model Class Initialized
INFO - 2018-03-26 11:23:19 --> Model Class Initialized
INFO - 2018-03-26 11:23:20 --> Helper loaded: date_helper
INFO - 2018-03-26 11:23:20 --> Helper loaded: tanggal_helper
ERROR - 2018-03-26 16:23:20 --> Severity: error --> Exception: Call to undefined method Billing_model::update() E:\xampp\htdocs\skin_care\application\controllers\Kasir\Kasir.php 61
INFO - 2018-03-26 11:23:30 --> Config Class Initialized
INFO - 2018-03-26 11:23:30 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:23:30 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:23:30 --> Utf8 Class Initialized
INFO - 2018-03-26 11:23:30 --> URI Class Initialized
INFO - 2018-03-26 11:23:30 --> Router Class Initialized
INFO - 2018-03-26 11:23:30 --> Output Class Initialized
INFO - 2018-03-26 11:23:30 --> Security Class Initialized
DEBUG - 2018-03-26 11:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:23:30 --> Input Class Initialized
INFO - 2018-03-26 11:23:30 --> Language Class Initialized
INFO - 2018-03-26 11:23:30 --> Loader Class Initialized
INFO - 2018-03-26 11:23:30 --> Helper loaded: url_helper
INFO - 2018-03-26 11:23:30 --> Helper loaded: form_helper
INFO - 2018-03-26 11:23:30 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:23:30 --> Controller Class Initialized
INFO - 2018-03-26 11:23:30 --> Model Class Initialized
INFO - 2018-03-26 11:23:30 --> Model Class Initialized
INFO - 2018-03-26 11:23:30 --> Model Class Initialized
INFO - 2018-03-26 11:23:30 --> Model Class Initialized
INFO - 2018-03-26 11:23:30 --> Model Class Initialized
INFO - 2018-03-26 11:23:30 --> Model Class Initialized
INFO - 2018-03-26 11:23:30 --> Model Class Initialized
INFO - 2018-03-26 11:23:30 --> Model Class Initialized
INFO - 2018-03-26 11:23:30 --> Model Class Initialized
INFO - 2018-03-26 11:23:30 --> Model Class Initialized
INFO - 2018-03-26 11:23:30 --> Model Class Initialized
INFO - 2018-03-26 11:23:30 --> Model Class Initialized
INFO - 2018-03-26 11:23:30 --> Helper loaded: date_helper
INFO - 2018-03-26 11:23:30 --> Helper loaded: tanggal_helper
ERROR - 2018-03-26 16:23:30 --> Severity: error --> Exception: Call to undefined method Billing_model::update() E:\xampp\htdocs\skin_care\application\controllers\Kasir\Kasir.php 61
INFO - 2018-03-26 11:24:39 --> Config Class Initialized
INFO - 2018-03-26 11:24:39 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:24:39 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:24:39 --> Utf8 Class Initialized
INFO - 2018-03-26 11:24:39 --> URI Class Initialized
INFO - 2018-03-26 11:24:39 --> Router Class Initialized
INFO - 2018-03-26 11:24:39 --> Output Class Initialized
INFO - 2018-03-26 11:24:39 --> Security Class Initialized
DEBUG - 2018-03-26 11:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:24:39 --> Input Class Initialized
INFO - 2018-03-26 11:24:39 --> Language Class Initialized
INFO - 2018-03-26 11:24:39 --> Loader Class Initialized
INFO - 2018-03-26 11:24:39 --> Helper loaded: url_helper
INFO - 2018-03-26 11:24:39 --> Helper loaded: form_helper
INFO - 2018-03-26 11:24:39 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:24:39 --> Controller Class Initialized
INFO - 2018-03-26 11:24:39 --> Model Class Initialized
INFO - 2018-03-26 11:24:39 --> Model Class Initialized
INFO - 2018-03-26 11:24:39 --> Model Class Initialized
INFO - 2018-03-26 11:24:39 --> Model Class Initialized
INFO - 2018-03-26 11:24:39 --> Model Class Initialized
INFO - 2018-03-26 11:24:39 --> Model Class Initialized
INFO - 2018-03-26 11:24:39 --> Model Class Initialized
INFO - 2018-03-26 11:24:39 --> Model Class Initialized
INFO - 2018-03-26 11:24:39 --> Model Class Initialized
INFO - 2018-03-26 11:24:39 --> Model Class Initialized
INFO - 2018-03-26 11:24:39 --> Model Class Initialized
INFO - 2018-03-26 11:24:39 --> Model Class Initialized
INFO - 2018-03-26 11:24:39 --> Helper loaded: date_helper
INFO - 2018-03-26 11:24:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:24:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:24:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:24:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:24:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:24:39 --> Final output sent to browser
DEBUG - 2018-03-26 16:24:39 --> Total execution time: 0.1138
INFO - 2018-03-26 11:24:47 --> Config Class Initialized
INFO - 2018-03-26 11:24:47 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:24:47 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:24:47 --> Utf8 Class Initialized
INFO - 2018-03-26 11:24:47 --> URI Class Initialized
INFO - 2018-03-26 11:24:47 --> Router Class Initialized
INFO - 2018-03-26 11:24:47 --> Output Class Initialized
INFO - 2018-03-26 11:24:47 --> Security Class Initialized
DEBUG - 2018-03-26 11:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:24:47 --> Input Class Initialized
INFO - 2018-03-26 11:24:47 --> Language Class Initialized
INFO - 2018-03-26 11:24:47 --> Loader Class Initialized
INFO - 2018-03-26 11:24:47 --> Helper loaded: url_helper
INFO - 2018-03-26 11:24:47 --> Helper loaded: form_helper
INFO - 2018-03-26 11:24:47 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:24:47 --> Controller Class Initialized
INFO - 2018-03-26 11:24:47 --> Model Class Initialized
INFO - 2018-03-26 11:24:47 --> Model Class Initialized
INFO - 2018-03-26 11:24:47 --> Model Class Initialized
INFO - 2018-03-26 11:24:47 --> Model Class Initialized
INFO - 2018-03-26 11:24:47 --> Model Class Initialized
INFO - 2018-03-26 11:24:47 --> Model Class Initialized
INFO - 2018-03-26 11:24:47 --> Model Class Initialized
INFO - 2018-03-26 11:24:47 --> Model Class Initialized
INFO - 2018-03-26 11:24:47 --> Model Class Initialized
INFO - 2018-03-26 11:24:47 --> Model Class Initialized
INFO - 2018-03-26 11:24:47 --> Model Class Initialized
INFO - 2018-03-26 11:24:47 --> Model Class Initialized
INFO - 2018-03-26 11:24:47 --> Helper loaded: date_helper
INFO - 2018-03-26 11:24:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:24:47 --> Final output sent to browser
DEBUG - 2018-03-26 16:24:47 --> Total execution time: 0.2104
INFO - 2018-03-26 11:30:20 --> Config Class Initialized
INFO - 2018-03-26 11:30:20 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:30:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:30:20 --> Utf8 Class Initialized
INFO - 2018-03-26 11:30:20 --> URI Class Initialized
INFO - 2018-03-26 11:30:20 --> Router Class Initialized
INFO - 2018-03-26 11:30:20 --> Output Class Initialized
INFO - 2018-03-26 11:30:20 --> Security Class Initialized
DEBUG - 2018-03-26 11:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:30:20 --> Input Class Initialized
INFO - 2018-03-26 11:30:20 --> Language Class Initialized
INFO - 2018-03-26 11:30:20 --> Loader Class Initialized
INFO - 2018-03-26 11:30:20 --> Helper loaded: url_helper
INFO - 2018-03-26 11:30:20 --> Helper loaded: form_helper
INFO - 2018-03-26 11:30:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:30:20 --> Controller Class Initialized
INFO - 2018-03-26 11:30:20 --> Model Class Initialized
INFO - 2018-03-26 11:30:20 --> Model Class Initialized
INFO - 2018-03-26 11:30:20 --> Model Class Initialized
INFO - 2018-03-26 11:30:20 --> Model Class Initialized
INFO - 2018-03-26 11:30:20 --> Model Class Initialized
INFO - 2018-03-26 11:30:20 --> Model Class Initialized
INFO - 2018-03-26 11:30:20 --> Model Class Initialized
INFO - 2018-03-26 11:30:20 --> Model Class Initialized
INFO - 2018-03-26 11:30:20 --> Model Class Initialized
INFO - 2018-03-26 11:30:20 --> Model Class Initialized
INFO - 2018-03-26 11:30:20 --> Model Class Initialized
INFO - 2018-03-26 11:30:20 --> Model Class Initialized
INFO - 2018-03-26 11:30:20 --> Helper loaded: date_helper
INFO - 2018-03-26 11:30:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:30:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:30:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:30:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:30:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:30:20 --> Final output sent to browser
DEBUG - 2018-03-26 16:30:20 --> Total execution time: 0.1028
INFO - 2018-03-26 11:32:28 --> Config Class Initialized
INFO - 2018-03-26 11:32:28 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:28 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:28 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:28 --> URI Class Initialized
INFO - 2018-03-26 11:32:28 --> Router Class Initialized
INFO - 2018-03-26 11:32:28 --> Output Class Initialized
INFO - 2018-03-26 11:32:28 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:28 --> Input Class Initialized
INFO - 2018-03-26 11:32:28 --> Language Class Initialized
INFO - 2018-03-26 11:32:28 --> Loader Class Initialized
INFO - 2018-03-26 11:32:28 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:28 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:28 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:28 --> Controller Class Initialized
INFO - 2018-03-26 11:32:28 --> Model Class Initialized
INFO - 2018-03-26 11:32:28 --> Model Class Initialized
INFO - 2018-03-26 11:32:28 --> Model Class Initialized
INFO - 2018-03-26 11:32:28 --> Model Class Initialized
INFO - 2018-03-26 11:32:28 --> Model Class Initialized
INFO - 2018-03-26 11:32:28 --> Model Class Initialized
INFO - 2018-03-26 11:32:28 --> Model Class Initialized
INFO - 2018-03-26 11:32:28 --> Model Class Initialized
INFO - 2018-03-26 11:32:28 --> Model Class Initialized
INFO - 2018-03-26 11:32:28 --> Model Class Initialized
INFO - 2018-03-26 11:32:28 --> Model Class Initialized
INFO - 2018-03-26 11:32:28 --> Model Class Initialized
INFO - 2018-03-26 11:32:28 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:32:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:32:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-26 16:32:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:32:28 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:28 --> Total execution time: 0.0931
INFO - 2018-03-26 11:32:31 --> Config Class Initialized
INFO - 2018-03-26 11:32:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:31 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:31 --> URI Class Initialized
INFO - 2018-03-26 11:32:31 --> Router Class Initialized
INFO - 2018-03-26 11:32:31 --> Output Class Initialized
INFO - 2018-03-26 11:32:31 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:31 --> Input Class Initialized
INFO - 2018-03-26 11:32:31 --> Language Class Initialized
INFO - 2018-03-26 11:32:31 --> Loader Class Initialized
INFO - 2018-03-26 11:32:31 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:31 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:31 --> Controller Class Initialized
INFO - 2018-03-26 11:32:31 --> Model Class Initialized
INFO - 2018-03-26 11:32:31 --> Model Class Initialized
INFO - 2018-03-26 11:32:31 --> Model Class Initialized
INFO - 2018-03-26 11:32:31 --> Model Class Initialized
INFO - 2018-03-26 11:32:31 --> Model Class Initialized
INFO - 2018-03-26 11:32:31 --> Model Class Initialized
INFO - 2018-03-26 11:32:31 --> Model Class Initialized
INFO - 2018-03-26 11:32:31 --> Model Class Initialized
INFO - 2018-03-26 11:32:31 --> Model Class Initialized
INFO - 2018-03-26 11:32:31 --> Model Class Initialized
INFO - 2018-03-26 11:32:31 --> Model Class Initialized
INFO - 2018-03-26 11:32:31 --> Model Class Initialized
INFO - 2018-03-26 11:32:31 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:31 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:31 --> Total execution time: 0.0675
INFO - 2018-03-26 11:32:34 --> Config Class Initialized
INFO - 2018-03-26 11:32:34 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:34 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:34 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:34 --> URI Class Initialized
INFO - 2018-03-26 11:32:34 --> Router Class Initialized
INFO - 2018-03-26 11:32:34 --> Output Class Initialized
INFO - 2018-03-26 11:32:34 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:34 --> Input Class Initialized
INFO - 2018-03-26 11:32:34 --> Language Class Initialized
INFO - 2018-03-26 11:32:34 --> Loader Class Initialized
INFO - 2018-03-26 11:32:34 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:34 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:34 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:34 --> Controller Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:34 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:34 --> Total execution time: 0.0767
INFO - 2018-03-26 11:32:34 --> Config Class Initialized
INFO - 2018-03-26 11:32:34 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:34 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:34 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:34 --> URI Class Initialized
INFO - 2018-03-26 11:32:34 --> Router Class Initialized
INFO - 2018-03-26 11:32:34 --> Output Class Initialized
INFO - 2018-03-26 11:32:34 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:34 --> Input Class Initialized
INFO - 2018-03-26 11:32:34 --> Language Class Initialized
INFO - 2018-03-26 11:32:34 --> Loader Class Initialized
INFO - 2018-03-26 11:32:34 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:34 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:34 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:34 --> Controller Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Model Class Initialized
INFO - 2018-03-26 11:32:34 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:34 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:34 --> Total execution time: 0.0678
INFO - 2018-03-26 11:32:35 --> Config Class Initialized
INFO - 2018-03-26 11:32:35 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:35 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:35 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:35 --> URI Class Initialized
INFO - 2018-03-26 11:32:35 --> Router Class Initialized
INFO - 2018-03-26 11:32:35 --> Output Class Initialized
INFO - 2018-03-26 11:32:35 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:35 --> Input Class Initialized
INFO - 2018-03-26 11:32:35 --> Language Class Initialized
INFO - 2018-03-26 11:32:35 --> Loader Class Initialized
INFO - 2018-03-26 11:32:35 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:35 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:35 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:35 --> Controller Class Initialized
INFO - 2018-03-26 11:32:35 --> Model Class Initialized
INFO - 2018-03-26 11:32:35 --> Model Class Initialized
INFO - 2018-03-26 11:32:35 --> Model Class Initialized
INFO - 2018-03-26 11:32:35 --> Model Class Initialized
INFO - 2018-03-26 11:32:35 --> Model Class Initialized
INFO - 2018-03-26 11:32:35 --> Model Class Initialized
INFO - 2018-03-26 11:32:35 --> Model Class Initialized
INFO - 2018-03-26 11:32:35 --> Model Class Initialized
INFO - 2018-03-26 11:32:35 --> Model Class Initialized
INFO - 2018-03-26 11:32:35 --> Model Class Initialized
INFO - 2018-03-26 11:32:35 --> Model Class Initialized
INFO - 2018-03-26 11:32:35 --> Model Class Initialized
INFO - 2018-03-26 11:32:35 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:35 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:35 --> Total execution time: 0.1066
INFO - 2018-03-26 11:32:36 --> Config Class Initialized
INFO - 2018-03-26 11:32:36 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:36 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:36 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:36 --> URI Class Initialized
INFO - 2018-03-26 11:32:36 --> Router Class Initialized
INFO - 2018-03-26 11:32:36 --> Output Class Initialized
INFO - 2018-03-26 11:32:36 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:36 --> Input Class Initialized
INFO - 2018-03-26 11:32:36 --> Language Class Initialized
INFO - 2018-03-26 11:32:36 --> Loader Class Initialized
INFO - 2018-03-26 11:32:36 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:36 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:36 --> Controller Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:36 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:36 --> Total execution time: 0.0672
INFO - 2018-03-26 11:32:36 --> Config Class Initialized
INFO - 2018-03-26 11:32:36 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:36 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:36 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:36 --> URI Class Initialized
INFO - 2018-03-26 11:32:36 --> Router Class Initialized
INFO - 2018-03-26 11:32:36 --> Output Class Initialized
INFO - 2018-03-26 11:32:36 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:36 --> Input Class Initialized
INFO - 2018-03-26 11:32:36 --> Language Class Initialized
INFO - 2018-03-26 11:32:36 --> Loader Class Initialized
INFO - 2018-03-26 11:32:36 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:36 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:36 --> Controller Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Model Class Initialized
INFO - 2018-03-26 11:32:36 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:36 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:36 --> Total execution time: 0.0928
INFO - 2018-03-26 11:32:40 --> Config Class Initialized
INFO - 2018-03-26 11:32:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:40 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:40 --> URI Class Initialized
INFO - 2018-03-26 11:32:40 --> Router Class Initialized
INFO - 2018-03-26 11:32:40 --> Output Class Initialized
INFO - 2018-03-26 11:32:40 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:40 --> Input Class Initialized
INFO - 2018-03-26 11:32:40 --> Language Class Initialized
INFO - 2018-03-26 11:32:40 --> Loader Class Initialized
INFO - 2018-03-26 11:32:40 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:40 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:40 --> Controller Class Initialized
INFO - 2018-03-26 11:32:40 --> Model Class Initialized
INFO - 2018-03-26 11:32:40 --> Model Class Initialized
INFO - 2018-03-26 11:32:40 --> Model Class Initialized
INFO - 2018-03-26 11:32:40 --> Model Class Initialized
INFO - 2018-03-26 11:32:40 --> Model Class Initialized
INFO - 2018-03-26 11:32:40 --> Model Class Initialized
INFO - 2018-03-26 11:32:40 --> Model Class Initialized
INFO - 2018-03-26 11:32:40 --> Model Class Initialized
INFO - 2018-03-26 11:32:40 --> Model Class Initialized
INFO - 2018-03-26 11:32:40 --> Model Class Initialized
INFO - 2018-03-26 11:32:40 --> Model Class Initialized
INFO - 2018-03-26 11:32:40 --> Model Class Initialized
INFO - 2018-03-26 11:32:40 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:40 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:40 --> Total execution time: 0.0705
INFO - 2018-03-26 11:32:43 --> Config Class Initialized
INFO - 2018-03-26 11:32:43 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:43 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:43 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:43 --> URI Class Initialized
INFO - 2018-03-26 11:32:43 --> Router Class Initialized
INFO - 2018-03-26 11:32:43 --> Output Class Initialized
INFO - 2018-03-26 11:32:43 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:43 --> Input Class Initialized
INFO - 2018-03-26 11:32:43 --> Language Class Initialized
INFO - 2018-03-26 11:32:43 --> Loader Class Initialized
INFO - 2018-03-26 11:32:43 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:43 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:43 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:43 --> Controller Class Initialized
INFO - 2018-03-26 11:32:43 --> Model Class Initialized
INFO - 2018-03-26 11:32:43 --> Model Class Initialized
INFO - 2018-03-26 11:32:43 --> Model Class Initialized
INFO - 2018-03-26 11:32:43 --> Model Class Initialized
INFO - 2018-03-26 11:32:43 --> Model Class Initialized
INFO - 2018-03-26 11:32:43 --> Model Class Initialized
INFO - 2018-03-26 11:32:43 --> Model Class Initialized
INFO - 2018-03-26 11:32:43 --> Model Class Initialized
INFO - 2018-03-26 11:32:43 --> Model Class Initialized
INFO - 2018-03-26 11:32:43 --> Model Class Initialized
INFO - 2018-03-26 11:32:43 --> Model Class Initialized
INFO - 2018-03-26 11:32:43 --> Model Class Initialized
INFO - 2018-03-26 11:32:43 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:43 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:43 --> Total execution time: 0.0716
INFO - 2018-03-26 11:32:44 --> Config Class Initialized
INFO - 2018-03-26 11:32:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:44 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:44 --> URI Class Initialized
INFO - 2018-03-26 11:32:44 --> Router Class Initialized
INFO - 2018-03-26 11:32:44 --> Output Class Initialized
INFO - 2018-03-26 11:32:44 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:44 --> Input Class Initialized
INFO - 2018-03-26 11:32:44 --> Language Class Initialized
INFO - 2018-03-26 11:32:44 --> Loader Class Initialized
INFO - 2018-03-26 11:32:44 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:44 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:44 --> Controller Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:44 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:44 --> Total execution time: 0.0695
INFO - 2018-03-26 11:32:44 --> Config Class Initialized
INFO - 2018-03-26 11:32:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:44 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:44 --> URI Class Initialized
INFO - 2018-03-26 11:32:44 --> Router Class Initialized
INFO - 2018-03-26 11:32:44 --> Output Class Initialized
INFO - 2018-03-26 11:32:44 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:44 --> Input Class Initialized
INFO - 2018-03-26 11:32:44 --> Language Class Initialized
INFO - 2018-03-26 11:32:44 --> Loader Class Initialized
INFO - 2018-03-26 11:32:44 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:44 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:44 --> Controller Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:44 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:44 --> Total execution time: 0.0769
INFO - 2018-03-26 11:32:44 --> Config Class Initialized
INFO - 2018-03-26 11:32:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:44 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:44 --> URI Class Initialized
INFO - 2018-03-26 11:32:44 --> Router Class Initialized
INFO - 2018-03-26 11:32:44 --> Output Class Initialized
INFO - 2018-03-26 11:32:44 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:44 --> Input Class Initialized
INFO - 2018-03-26 11:32:44 --> Language Class Initialized
INFO - 2018-03-26 11:32:44 --> Loader Class Initialized
INFO - 2018-03-26 11:32:44 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:44 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:44 --> Controller Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:44 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:44 --> Total execution time: 0.0768
INFO - 2018-03-26 11:32:44 --> Config Class Initialized
INFO - 2018-03-26 11:32:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:44 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:44 --> URI Class Initialized
INFO - 2018-03-26 11:32:44 --> Router Class Initialized
INFO - 2018-03-26 11:32:44 --> Output Class Initialized
INFO - 2018-03-26 11:32:44 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:44 --> Input Class Initialized
INFO - 2018-03-26 11:32:44 --> Language Class Initialized
INFO - 2018-03-26 11:32:44 --> Loader Class Initialized
INFO - 2018-03-26 11:32:44 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:44 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:44 --> Controller Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:44 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:44 --> Total execution time: 0.0991
INFO - 2018-03-26 11:32:44 --> Config Class Initialized
INFO - 2018-03-26 11:32:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:44 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:44 --> URI Class Initialized
INFO - 2018-03-26 11:32:44 --> Router Class Initialized
INFO - 2018-03-26 11:32:44 --> Output Class Initialized
INFO - 2018-03-26 11:32:44 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:44 --> Input Class Initialized
INFO - 2018-03-26 11:32:44 --> Language Class Initialized
INFO - 2018-03-26 11:32:44 --> Loader Class Initialized
INFO - 2018-03-26 11:32:44 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:44 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:44 --> Controller Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:44 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:45 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:45 --> Total execution time: 0.0810
INFO - 2018-03-26 11:32:45 --> Config Class Initialized
INFO - 2018-03-26 11:32:45 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:45 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:45 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:45 --> URI Class Initialized
INFO - 2018-03-26 11:32:45 --> Router Class Initialized
INFO - 2018-03-26 11:32:45 --> Output Class Initialized
INFO - 2018-03-26 11:32:45 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:45 --> Input Class Initialized
INFO - 2018-03-26 11:32:45 --> Language Class Initialized
INFO - 2018-03-26 11:32:45 --> Loader Class Initialized
INFO - 2018-03-26 11:32:45 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:45 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:45 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:45 --> Controller Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:45 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:45 --> Total execution time: 0.1056
INFO - 2018-03-26 11:32:45 --> Config Class Initialized
INFO - 2018-03-26 11:32:45 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:45 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:45 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:45 --> URI Class Initialized
INFO - 2018-03-26 11:32:45 --> Router Class Initialized
INFO - 2018-03-26 11:32:45 --> Output Class Initialized
INFO - 2018-03-26 11:32:45 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:45 --> Input Class Initialized
INFO - 2018-03-26 11:32:45 --> Language Class Initialized
INFO - 2018-03-26 11:32:45 --> Loader Class Initialized
INFO - 2018-03-26 11:32:45 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:45 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:45 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:45 --> Controller Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:45 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:45 --> Total execution time: 0.0779
INFO - 2018-03-26 11:32:45 --> Config Class Initialized
INFO - 2018-03-26 11:32:45 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:45 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:45 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:45 --> URI Class Initialized
INFO - 2018-03-26 11:32:45 --> Router Class Initialized
INFO - 2018-03-26 11:32:45 --> Output Class Initialized
INFO - 2018-03-26 11:32:45 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:45 --> Input Class Initialized
INFO - 2018-03-26 11:32:45 --> Language Class Initialized
INFO - 2018-03-26 11:32:45 --> Loader Class Initialized
INFO - 2018-03-26 11:32:45 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:45 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:45 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:45 --> Controller Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Model Class Initialized
INFO - 2018-03-26 11:32:45 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:45 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:45 --> Total execution time: 0.0989
INFO - 2018-03-26 11:32:46 --> Config Class Initialized
INFO - 2018-03-26 11:32:46 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:46 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:46 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:46 --> URI Class Initialized
INFO - 2018-03-26 11:32:46 --> Router Class Initialized
INFO - 2018-03-26 11:32:46 --> Output Class Initialized
INFO - 2018-03-26 11:32:46 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:46 --> Input Class Initialized
INFO - 2018-03-26 11:32:46 --> Language Class Initialized
INFO - 2018-03-26 11:32:46 --> Loader Class Initialized
INFO - 2018-03-26 11:32:46 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:46 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:46 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:46 --> Controller Class Initialized
INFO - 2018-03-26 11:32:46 --> Model Class Initialized
INFO - 2018-03-26 11:32:46 --> Model Class Initialized
INFO - 2018-03-26 11:32:46 --> Model Class Initialized
INFO - 2018-03-26 11:32:46 --> Model Class Initialized
INFO - 2018-03-26 11:32:46 --> Model Class Initialized
INFO - 2018-03-26 11:32:46 --> Model Class Initialized
INFO - 2018-03-26 11:32:46 --> Model Class Initialized
INFO - 2018-03-26 11:32:46 --> Model Class Initialized
INFO - 2018-03-26 11:32:46 --> Model Class Initialized
INFO - 2018-03-26 11:32:46 --> Model Class Initialized
INFO - 2018-03-26 11:32:46 --> Model Class Initialized
INFO - 2018-03-26 11:32:46 --> Model Class Initialized
INFO - 2018-03-26 11:32:46 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:46 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:46 --> Total execution time: 0.0675
INFO - 2018-03-26 11:32:47 --> Config Class Initialized
INFO - 2018-03-26 11:32:47 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:47 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:47 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:47 --> URI Class Initialized
INFO - 2018-03-26 11:32:47 --> Router Class Initialized
INFO - 2018-03-26 11:32:47 --> Output Class Initialized
INFO - 2018-03-26 11:32:47 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:47 --> Input Class Initialized
INFO - 2018-03-26 11:32:47 --> Language Class Initialized
INFO - 2018-03-26 11:32:47 --> Loader Class Initialized
INFO - 2018-03-26 11:32:47 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:47 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:47 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:47 --> Controller Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:47 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:47 --> Total execution time: 0.0708
INFO - 2018-03-26 11:32:47 --> Config Class Initialized
INFO - 2018-03-26 11:32:47 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:32:47 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:32:47 --> Utf8 Class Initialized
INFO - 2018-03-26 11:32:47 --> URI Class Initialized
INFO - 2018-03-26 11:32:47 --> Router Class Initialized
INFO - 2018-03-26 11:32:47 --> Output Class Initialized
INFO - 2018-03-26 11:32:47 --> Security Class Initialized
DEBUG - 2018-03-26 11:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:32:47 --> Input Class Initialized
INFO - 2018-03-26 11:32:47 --> Language Class Initialized
INFO - 2018-03-26 11:32:47 --> Loader Class Initialized
INFO - 2018-03-26 11:32:47 --> Helper loaded: url_helper
INFO - 2018-03-26 11:32:47 --> Helper loaded: form_helper
INFO - 2018-03-26 11:32:47 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:32:47 --> Controller Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Model Class Initialized
INFO - 2018-03-26 11:32:47 --> Helper loaded: date_helper
INFO - 2018-03-26 11:32:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:32:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:32:47 --> Final output sent to browser
DEBUG - 2018-03-26 16:32:47 --> Total execution time: 0.0934
INFO - 2018-03-26 11:33:04 --> Config Class Initialized
INFO - 2018-03-26 11:33:04 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:33:04 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:33:04 --> Utf8 Class Initialized
INFO - 2018-03-26 11:33:04 --> URI Class Initialized
INFO - 2018-03-26 11:33:04 --> Router Class Initialized
INFO - 2018-03-26 11:33:04 --> Output Class Initialized
INFO - 2018-03-26 11:33:04 --> Security Class Initialized
DEBUG - 2018-03-26 11:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:33:04 --> Input Class Initialized
INFO - 2018-03-26 11:33:04 --> Language Class Initialized
INFO - 2018-03-26 11:33:04 --> Loader Class Initialized
INFO - 2018-03-26 11:33:04 --> Helper loaded: url_helper
INFO - 2018-03-26 11:33:04 --> Helper loaded: form_helper
INFO - 2018-03-26 11:33:04 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:33:04 --> Controller Class Initialized
INFO - 2018-03-26 11:33:04 --> Model Class Initialized
INFO - 2018-03-26 11:33:04 --> Model Class Initialized
INFO - 2018-03-26 11:33:04 --> Model Class Initialized
INFO - 2018-03-26 11:33:04 --> Model Class Initialized
INFO - 2018-03-26 11:33:04 --> Model Class Initialized
INFO - 2018-03-26 11:33:04 --> Model Class Initialized
INFO - 2018-03-26 11:33:04 --> Model Class Initialized
INFO - 2018-03-26 11:33:04 --> Model Class Initialized
INFO - 2018-03-26 11:33:04 --> Model Class Initialized
INFO - 2018-03-26 11:33:04 --> Model Class Initialized
INFO - 2018-03-26 11:33:04 --> Model Class Initialized
INFO - 2018-03-26 11:33:04 --> Model Class Initialized
INFO - 2018-03-26 11:33:04 --> Helper loaded: date_helper
INFO - 2018-03-26 11:33:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:33:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:33:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:33:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-26 16:33:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:33:04 --> Final output sent to browser
DEBUG - 2018-03-26 16:33:04 --> Total execution time: 0.0895
INFO - 2018-03-26 11:33:07 --> Config Class Initialized
INFO - 2018-03-26 11:33:07 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:33:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:33:07 --> Utf8 Class Initialized
INFO - 2018-03-26 11:33:07 --> URI Class Initialized
INFO - 2018-03-26 11:33:07 --> Router Class Initialized
INFO - 2018-03-26 11:33:07 --> Output Class Initialized
INFO - 2018-03-26 11:33:07 --> Security Class Initialized
DEBUG - 2018-03-26 11:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:33:07 --> Input Class Initialized
INFO - 2018-03-26 11:33:07 --> Language Class Initialized
INFO - 2018-03-26 11:33:07 --> Loader Class Initialized
INFO - 2018-03-26 11:33:07 --> Helper loaded: url_helper
INFO - 2018-03-26 11:33:07 --> Helper loaded: form_helper
INFO - 2018-03-26 11:33:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:33:07 --> Controller Class Initialized
INFO - 2018-03-26 11:33:07 --> Model Class Initialized
INFO - 2018-03-26 11:33:07 --> Model Class Initialized
INFO - 2018-03-26 11:33:07 --> Model Class Initialized
INFO - 2018-03-26 11:33:07 --> Model Class Initialized
INFO - 2018-03-26 11:33:07 --> Model Class Initialized
INFO - 2018-03-26 11:33:07 --> Model Class Initialized
INFO - 2018-03-26 11:33:07 --> Model Class Initialized
INFO - 2018-03-26 11:33:07 --> Model Class Initialized
INFO - 2018-03-26 11:33:07 --> Model Class Initialized
INFO - 2018-03-26 11:33:07 --> Model Class Initialized
INFO - 2018-03-26 11:33:07 --> Model Class Initialized
INFO - 2018-03-26 11:33:07 --> Model Class Initialized
INFO - 2018-03-26 11:33:07 --> Helper loaded: date_helper
INFO - 2018-03-26 11:33:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:33:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:33:07 --> Final output sent to browser
DEBUG - 2018-03-26 16:33:07 --> Total execution time: 0.0683
INFO - 2018-03-26 11:33:13 --> Config Class Initialized
INFO - 2018-03-26 11:33:13 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:33:13 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:33:13 --> Utf8 Class Initialized
INFO - 2018-03-26 11:33:13 --> URI Class Initialized
INFO - 2018-03-26 11:33:13 --> Router Class Initialized
INFO - 2018-03-26 11:33:13 --> Output Class Initialized
INFO - 2018-03-26 11:33:13 --> Security Class Initialized
DEBUG - 2018-03-26 11:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:33:13 --> Input Class Initialized
INFO - 2018-03-26 11:33:13 --> Language Class Initialized
INFO - 2018-03-26 11:33:13 --> Loader Class Initialized
INFO - 2018-03-26 11:33:13 --> Helper loaded: url_helper
INFO - 2018-03-26 11:33:13 --> Helper loaded: form_helper
INFO - 2018-03-26 11:33:13 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:33:13 --> Controller Class Initialized
INFO - 2018-03-26 11:33:13 --> Model Class Initialized
INFO - 2018-03-26 11:33:13 --> Model Class Initialized
INFO - 2018-03-26 11:33:13 --> Model Class Initialized
INFO - 2018-03-26 11:33:13 --> Model Class Initialized
INFO - 2018-03-26 11:33:13 --> Model Class Initialized
INFO - 2018-03-26 11:33:13 --> Model Class Initialized
INFO - 2018-03-26 11:33:13 --> Model Class Initialized
INFO - 2018-03-26 11:33:13 --> Model Class Initialized
INFO - 2018-03-26 11:33:13 --> Model Class Initialized
INFO - 2018-03-26 11:33:13 --> Model Class Initialized
INFO - 2018-03-26 11:33:13 --> Model Class Initialized
INFO - 2018-03-26 11:33:13 --> Model Class Initialized
INFO - 2018-03-26 11:33:13 --> Helper loaded: date_helper
INFO - 2018-03-26 11:33:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:33:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:33:13 --> Final output sent to browser
DEBUG - 2018-03-26 16:33:13 --> Total execution time: 0.0695
INFO - 2018-03-26 11:33:17 --> Config Class Initialized
INFO - 2018-03-26 11:33:17 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:33:17 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:33:17 --> Utf8 Class Initialized
INFO - 2018-03-26 11:33:17 --> URI Class Initialized
INFO - 2018-03-26 11:33:17 --> Router Class Initialized
INFO - 2018-03-26 11:33:17 --> Output Class Initialized
INFO - 2018-03-26 11:33:17 --> Security Class Initialized
DEBUG - 2018-03-26 11:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:33:17 --> Input Class Initialized
INFO - 2018-03-26 11:33:17 --> Language Class Initialized
INFO - 2018-03-26 11:33:17 --> Loader Class Initialized
INFO - 2018-03-26 11:33:17 --> Helper loaded: url_helper
INFO - 2018-03-26 11:33:17 --> Helper loaded: form_helper
INFO - 2018-03-26 11:33:17 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:33:17 --> Controller Class Initialized
INFO - 2018-03-26 11:33:17 --> Model Class Initialized
INFO - 2018-03-26 11:33:17 --> Model Class Initialized
INFO - 2018-03-26 11:33:17 --> Model Class Initialized
INFO - 2018-03-26 11:33:17 --> Model Class Initialized
INFO - 2018-03-26 11:33:17 --> Model Class Initialized
INFO - 2018-03-26 11:33:17 --> Model Class Initialized
INFO - 2018-03-26 11:33:17 --> Model Class Initialized
INFO - 2018-03-26 11:33:17 --> Model Class Initialized
INFO - 2018-03-26 11:33:17 --> Model Class Initialized
INFO - 2018-03-26 11:33:17 --> Model Class Initialized
INFO - 2018-03-26 11:33:17 --> Model Class Initialized
INFO - 2018-03-26 11:33:17 --> Model Class Initialized
INFO - 2018-03-26 11:33:17 --> Helper loaded: date_helper
INFO - 2018-03-26 11:33:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:33:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:33:17 --> Final output sent to browser
DEBUG - 2018-03-26 16:33:17 --> Total execution time: 0.0769
INFO - 2018-03-26 11:33:26 --> Config Class Initialized
INFO - 2018-03-26 11:33:26 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:33:26 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:33:26 --> Utf8 Class Initialized
INFO - 2018-03-26 11:33:26 --> URI Class Initialized
INFO - 2018-03-26 11:33:26 --> Router Class Initialized
INFO - 2018-03-26 11:33:26 --> Output Class Initialized
INFO - 2018-03-26 11:33:26 --> Security Class Initialized
DEBUG - 2018-03-26 11:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:33:26 --> Input Class Initialized
INFO - 2018-03-26 11:33:26 --> Language Class Initialized
INFO - 2018-03-26 11:33:26 --> Loader Class Initialized
INFO - 2018-03-26 11:33:26 --> Helper loaded: url_helper
INFO - 2018-03-26 11:33:26 --> Helper loaded: form_helper
INFO - 2018-03-26 11:33:26 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:33:26 --> Controller Class Initialized
INFO - 2018-03-26 11:33:26 --> Model Class Initialized
INFO - 2018-03-26 11:33:26 --> Model Class Initialized
INFO - 2018-03-26 11:33:26 --> Model Class Initialized
INFO - 2018-03-26 11:33:26 --> Model Class Initialized
INFO - 2018-03-26 11:33:26 --> Model Class Initialized
INFO - 2018-03-26 11:33:26 --> Model Class Initialized
INFO - 2018-03-26 11:33:26 --> Model Class Initialized
INFO - 2018-03-26 11:33:26 --> Model Class Initialized
INFO - 2018-03-26 11:33:26 --> Model Class Initialized
INFO - 2018-03-26 11:33:26 --> Model Class Initialized
INFO - 2018-03-26 11:33:26 --> Model Class Initialized
INFO - 2018-03-26 11:33:26 --> Model Class Initialized
INFO - 2018-03-26 11:33:26 --> Helper loaded: date_helper
INFO - 2018-03-26 11:33:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:33:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-26 16:33:26 --> Final output sent to browser
DEBUG - 2018-03-26 16:33:26 --> Total execution time: 0.0811
INFO - 2018-03-26 11:33:55 --> Config Class Initialized
INFO - 2018-03-26 11:33:55 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:33:55 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:33:55 --> Utf8 Class Initialized
INFO - 2018-03-26 11:33:55 --> URI Class Initialized
INFO - 2018-03-26 11:33:55 --> Router Class Initialized
INFO - 2018-03-26 11:33:55 --> Output Class Initialized
INFO - 2018-03-26 11:33:55 --> Security Class Initialized
DEBUG - 2018-03-26 11:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:33:55 --> Input Class Initialized
INFO - 2018-03-26 11:33:55 --> Language Class Initialized
INFO - 2018-03-26 11:33:55 --> Loader Class Initialized
INFO - 2018-03-26 11:33:55 --> Helper loaded: url_helper
INFO - 2018-03-26 11:33:55 --> Helper loaded: form_helper
INFO - 2018-03-26 11:33:55 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:33:55 --> Controller Class Initialized
INFO - 2018-03-26 11:33:55 --> Model Class Initialized
INFO - 2018-03-26 11:33:55 --> Model Class Initialized
INFO - 2018-03-26 11:33:55 --> Model Class Initialized
INFO - 2018-03-26 11:33:55 --> Model Class Initialized
INFO - 2018-03-26 11:33:55 --> Model Class Initialized
INFO - 2018-03-26 11:33:55 --> Model Class Initialized
INFO - 2018-03-26 11:33:55 --> Model Class Initialized
INFO - 2018-03-26 11:33:55 --> Model Class Initialized
INFO - 2018-03-26 11:33:55 --> Model Class Initialized
INFO - 2018-03-26 11:33:55 --> Model Class Initialized
INFO - 2018-03-26 11:33:55 --> Model Class Initialized
INFO - 2018-03-26 11:33:55 --> Model Class Initialized
INFO - 2018-03-26 11:33:55 --> Helper loaded: date_helper
INFO - 2018-03-26 11:33:55 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:33:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:33:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:33:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-26 16:33:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:33:55 --> Final output sent to browser
DEBUG - 2018-03-26 16:33:55 --> Total execution time: 0.0945
INFO - 2018-03-26 11:33:59 --> Config Class Initialized
INFO - 2018-03-26 11:33:59 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:33:59 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:33:59 --> Utf8 Class Initialized
INFO - 2018-03-26 11:33:59 --> URI Class Initialized
INFO - 2018-03-26 11:33:59 --> Router Class Initialized
INFO - 2018-03-26 11:33:59 --> Output Class Initialized
INFO - 2018-03-26 11:33:59 --> Security Class Initialized
DEBUG - 2018-03-26 11:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:33:59 --> Input Class Initialized
INFO - 2018-03-26 11:33:59 --> Language Class Initialized
INFO - 2018-03-26 11:33:59 --> Loader Class Initialized
INFO - 2018-03-26 11:33:59 --> Helper loaded: url_helper
INFO - 2018-03-26 11:33:59 --> Helper loaded: form_helper
INFO - 2018-03-26 11:33:59 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:33:59 --> Controller Class Initialized
INFO - 2018-03-26 11:33:59 --> Model Class Initialized
INFO - 2018-03-26 11:33:59 --> Model Class Initialized
INFO - 2018-03-26 11:33:59 --> Model Class Initialized
INFO - 2018-03-26 11:33:59 --> Model Class Initialized
INFO - 2018-03-26 11:33:59 --> Model Class Initialized
INFO - 2018-03-26 11:33:59 --> Model Class Initialized
INFO - 2018-03-26 11:33:59 --> Model Class Initialized
INFO - 2018-03-26 11:33:59 --> Model Class Initialized
INFO - 2018-03-26 11:33:59 --> Model Class Initialized
INFO - 2018-03-26 11:33:59 --> Model Class Initialized
INFO - 2018-03-26 11:33:59 --> Model Class Initialized
INFO - 2018-03-26 11:33:59 --> Model Class Initialized
INFO - 2018-03-26 11:33:59 --> Model Class Initialized
INFO - 2018-03-26 11:33:59 --> Model Class Initialized
INFO - 2018-03-26 11:33:59 --> Helper loaded: date_helper
INFO - 2018-03-26 11:33:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:33:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:33:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:33:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:33:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:33:59 --> Final output sent to browser
DEBUG - 2018-03-26 16:33:59 --> Total execution time: 0.1319
INFO - 2018-03-26 11:34:02 --> Config Class Initialized
INFO - 2018-03-26 11:34:02 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:34:02 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:34:02 --> Utf8 Class Initialized
INFO - 2018-03-26 11:34:02 --> URI Class Initialized
INFO - 2018-03-26 11:34:02 --> Router Class Initialized
INFO - 2018-03-26 11:34:02 --> Output Class Initialized
INFO - 2018-03-26 11:34:02 --> Security Class Initialized
DEBUG - 2018-03-26 11:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:34:02 --> Input Class Initialized
INFO - 2018-03-26 11:34:02 --> Language Class Initialized
INFO - 2018-03-26 11:34:02 --> Loader Class Initialized
INFO - 2018-03-26 11:34:02 --> Helper loaded: url_helper
INFO - 2018-03-26 11:34:02 --> Helper loaded: form_helper
INFO - 2018-03-26 11:34:02 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:34:02 --> Controller Class Initialized
INFO - 2018-03-26 11:34:02 --> Model Class Initialized
INFO - 2018-03-26 11:34:02 --> Model Class Initialized
INFO - 2018-03-26 11:34:02 --> Model Class Initialized
INFO - 2018-03-26 11:34:02 --> Model Class Initialized
INFO - 2018-03-26 11:34:02 --> Model Class Initialized
INFO - 2018-03-26 11:34:02 --> Model Class Initialized
INFO - 2018-03-26 11:34:02 --> Model Class Initialized
INFO - 2018-03-26 11:34:02 --> Model Class Initialized
INFO - 2018-03-26 11:34:02 --> Model Class Initialized
INFO - 2018-03-26 11:34:02 --> Model Class Initialized
INFO - 2018-03-26 11:34:02 --> Helper loaded: date_helper
INFO - 2018-03-26 11:34:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:34:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:34:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:34:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-26 16:34:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:34:02 --> Final output sent to browser
DEBUG - 2018-03-26 16:34:02 --> Total execution time: 0.1140
INFO - 2018-03-26 11:34:04 --> Config Class Initialized
INFO - 2018-03-26 11:34:04 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:34:04 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:34:04 --> Utf8 Class Initialized
INFO - 2018-03-26 11:34:04 --> URI Class Initialized
INFO - 2018-03-26 11:34:04 --> Router Class Initialized
INFO - 2018-03-26 11:34:04 --> Output Class Initialized
INFO - 2018-03-26 11:34:04 --> Security Class Initialized
DEBUG - 2018-03-26 11:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:34:04 --> Input Class Initialized
INFO - 2018-03-26 11:34:04 --> Language Class Initialized
INFO - 2018-03-26 11:34:04 --> Loader Class Initialized
INFO - 2018-03-26 11:34:04 --> Helper loaded: url_helper
INFO - 2018-03-26 11:34:04 --> Helper loaded: form_helper
INFO - 2018-03-26 11:34:04 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:34:04 --> Controller Class Initialized
INFO - 2018-03-26 11:34:04 --> Model Class Initialized
INFO - 2018-03-26 11:34:04 --> Model Class Initialized
INFO - 2018-03-26 11:34:04 --> Model Class Initialized
INFO - 2018-03-26 11:34:04 --> Model Class Initialized
INFO - 2018-03-26 11:34:04 --> Model Class Initialized
INFO - 2018-03-26 11:34:04 --> Model Class Initialized
INFO - 2018-03-26 11:34:04 --> Model Class Initialized
INFO - 2018-03-26 11:34:04 --> Model Class Initialized
INFO - 2018-03-26 11:34:04 --> Model Class Initialized
INFO - 2018-03-26 11:34:04 --> Model Class Initialized
INFO - 2018-03-26 11:34:04 --> Helper loaded: date_helper
INFO - 2018-03-26 11:34:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:34:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:34:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:34:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/create.php
INFO - 2018-03-26 16:34:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:34:04 --> Final output sent to browser
DEBUG - 2018-03-26 16:34:04 --> Total execution time: 0.1200
INFO - 2018-03-26 11:34:34 --> Config Class Initialized
INFO - 2018-03-26 11:34:34 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:34:34 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:34:34 --> Utf8 Class Initialized
INFO - 2018-03-26 11:34:34 --> URI Class Initialized
INFO - 2018-03-26 11:34:34 --> Router Class Initialized
INFO - 2018-03-26 11:34:34 --> Output Class Initialized
INFO - 2018-03-26 11:34:34 --> Security Class Initialized
DEBUG - 2018-03-26 11:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:34:34 --> Input Class Initialized
INFO - 2018-03-26 11:34:34 --> Language Class Initialized
INFO - 2018-03-26 11:34:34 --> Loader Class Initialized
INFO - 2018-03-26 11:34:34 --> Helper loaded: url_helper
INFO - 2018-03-26 11:34:34 --> Helper loaded: form_helper
INFO - 2018-03-26 11:34:34 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:34:34 --> Controller Class Initialized
INFO - 2018-03-26 11:34:34 --> Model Class Initialized
INFO - 2018-03-26 11:34:34 --> Model Class Initialized
INFO - 2018-03-26 11:34:34 --> Model Class Initialized
INFO - 2018-03-26 11:34:34 --> Model Class Initialized
INFO - 2018-03-26 11:34:34 --> Model Class Initialized
INFO - 2018-03-26 11:34:34 --> Model Class Initialized
INFO - 2018-03-26 11:34:34 --> Model Class Initialized
INFO - 2018-03-26 11:34:34 --> Model Class Initialized
INFO - 2018-03-26 11:34:34 --> Model Class Initialized
INFO - 2018-03-26 11:34:34 --> Model Class Initialized
INFO - 2018-03-26 11:34:34 --> Helper loaded: date_helper
INFO - 2018-03-26 11:34:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:34:34 --> Final output sent to browser
DEBUG - 2018-03-26 16:34:34 --> Total execution time: 0.0759
INFO - 2018-03-26 11:34:36 --> Config Class Initialized
INFO - 2018-03-26 11:34:36 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:34:36 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:34:36 --> Utf8 Class Initialized
INFO - 2018-03-26 11:34:36 --> URI Class Initialized
INFO - 2018-03-26 11:34:36 --> Router Class Initialized
INFO - 2018-03-26 11:34:36 --> Output Class Initialized
INFO - 2018-03-26 11:34:36 --> Security Class Initialized
DEBUG - 2018-03-26 11:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:34:36 --> Input Class Initialized
INFO - 2018-03-26 11:34:36 --> Language Class Initialized
INFO - 2018-03-26 11:34:36 --> Loader Class Initialized
INFO - 2018-03-26 11:34:36 --> Helper loaded: url_helper
INFO - 2018-03-26 11:34:36 --> Helper loaded: form_helper
INFO - 2018-03-26 11:34:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:34:36 --> Controller Class Initialized
INFO - 2018-03-26 11:34:36 --> Model Class Initialized
INFO - 2018-03-26 11:34:36 --> Model Class Initialized
INFO - 2018-03-26 11:34:36 --> Model Class Initialized
INFO - 2018-03-26 11:34:36 --> Model Class Initialized
INFO - 2018-03-26 11:34:36 --> Model Class Initialized
INFO - 2018-03-26 11:34:36 --> Model Class Initialized
INFO - 2018-03-26 11:34:36 --> Model Class Initialized
INFO - 2018-03-26 11:34:36 --> Model Class Initialized
INFO - 2018-03-26 11:34:36 --> Model Class Initialized
INFO - 2018-03-26 11:34:36 --> Model Class Initialized
INFO - 2018-03-26 11:34:36 --> Helper loaded: date_helper
INFO - 2018-03-26 11:34:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 11:34:37 --> Config Class Initialized
INFO - 2018-03-26 11:34:37 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:34:37 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:34:37 --> Utf8 Class Initialized
INFO - 2018-03-26 11:34:37 --> URI Class Initialized
INFO - 2018-03-26 11:34:37 --> Router Class Initialized
INFO - 2018-03-26 11:34:37 --> Output Class Initialized
INFO - 2018-03-26 11:34:37 --> Security Class Initialized
DEBUG - 2018-03-26 11:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:34:37 --> Input Class Initialized
INFO - 2018-03-26 11:34:37 --> Language Class Initialized
INFO - 2018-03-26 11:34:37 --> Loader Class Initialized
INFO - 2018-03-26 11:34:37 --> Helper loaded: url_helper
INFO - 2018-03-26 11:34:37 --> Helper loaded: form_helper
INFO - 2018-03-26 11:34:37 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:34:37 --> Controller Class Initialized
INFO - 2018-03-26 11:34:37 --> Model Class Initialized
INFO - 2018-03-26 11:34:37 --> Model Class Initialized
INFO - 2018-03-26 11:34:37 --> Model Class Initialized
INFO - 2018-03-26 11:34:37 --> Model Class Initialized
INFO - 2018-03-26 11:34:37 --> Model Class Initialized
INFO - 2018-03-26 11:34:37 --> Model Class Initialized
INFO - 2018-03-26 11:34:37 --> Model Class Initialized
INFO - 2018-03-26 11:34:37 --> Model Class Initialized
INFO - 2018-03-26 11:34:37 --> Model Class Initialized
INFO - 2018-03-26 11:34:37 --> Model Class Initialized
INFO - 2018-03-26 11:34:37 --> Helper loaded: date_helper
INFO - 2018-03-26 11:34:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:34:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:34:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:34:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-26 16:34:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:34:37 --> Final output sent to browser
DEBUG - 2018-03-26 16:34:37 --> Total execution time: 0.0841
INFO - 2018-03-26 11:34:44 --> Config Class Initialized
INFO - 2018-03-26 11:34:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:34:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:34:44 --> Utf8 Class Initialized
INFO - 2018-03-26 11:34:44 --> URI Class Initialized
INFO - 2018-03-26 11:34:44 --> Router Class Initialized
INFO - 2018-03-26 11:34:44 --> Output Class Initialized
INFO - 2018-03-26 11:34:44 --> Security Class Initialized
DEBUG - 2018-03-26 11:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:34:44 --> Input Class Initialized
INFO - 2018-03-26 11:34:44 --> Language Class Initialized
INFO - 2018-03-26 11:34:44 --> Loader Class Initialized
INFO - 2018-03-26 11:34:44 --> Helper loaded: url_helper
INFO - 2018-03-26 11:34:44 --> Helper loaded: form_helper
INFO - 2018-03-26 11:34:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:34:44 --> Controller Class Initialized
INFO - 2018-03-26 11:34:44 --> Model Class Initialized
INFO - 2018-03-26 11:34:44 --> Model Class Initialized
INFO - 2018-03-26 11:34:44 --> Model Class Initialized
INFO - 2018-03-26 11:34:44 --> Model Class Initialized
INFO - 2018-03-26 11:34:44 --> Model Class Initialized
INFO - 2018-03-26 11:34:44 --> Model Class Initialized
INFO - 2018-03-26 11:34:44 --> Model Class Initialized
INFO - 2018-03-26 11:34:44 --> Model Class Initialized
INFO - 2018-03-26 11:34:44 --> Model Class Initialized
INFO - 2018-03-26 11:34:44 --> Model Class Initialized
INFO - 2018-03-26 11:34:44 --> Helper loaded: date_helper
INFO - 2018-03-26 11:34:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:34:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:34:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:34:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/detail.php
INFO - 2018-03-26 16:34:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:34:44 --> Final output sent to browser
DEBUG - 2018-03-26 16:34:44 --> Total execution time: 0.0792
INFO - 2018-03-26 11:35:03 --> Config Class Initialized
INFO - 2018-03-26 11:35:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:35:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:35:03 --> Utf8 Class Initialized
INFO - 2018-03-26 11:35:03 --> URI Class Initialized
INFO - 2018-03-26 11:35:03 --> Router Class Initialized
INFO - 2018-03-26 11:35:03 --> Output Class Initialized
INFO - 2018-03-26 11:35:03 --> Security Class Initialized
DEBUG - 2018-03-26 11:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:35:03 --> Input Class Initialized
INFO - 2018-03-26 11:35:03 --> Language Class Initialized
INFO - 2018-03-26 11:35:03 --> Loader Class Initialized
INFO - 2018-03-26 11:35:03 --> Helper loaded: url_helper
INFO - 2018-03-26 11:35:03 --> Helper loaded: form_helper
INFO - 2018-03-26 11:35:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:35:03 --> Controller Class Initialized
INFO - 2018-03-26 11:35:03 --> Model Class Initialized
INFO - 2018-03-26 11:35:03 --> Model Class Initialized
INFO - 2018-03-26 11:35:03 --> Model Class Initialized
INFO - 2018-03-26 11:35:03 --> Model Class Initialized
INFO - 2018-03-26 11:35:03 --> Model Class Initialized
INFO - 2018-03-26 11:35:03 --> Model Class Initialized
INFO - 2018-03-26 11:35:03 --> Model Class Initialized
INFO - 2018-03-26 11:35:03 --> Model Class Initialized
INFO - 2018-03-26 11:35:03 --> Model Class Initialized
INFO - 2018-03-26 11:35:03 --> Model Class Initialized
INFO - 2018-03-26 11:35:03 --> Helper loaded: date_helper
INFO - 2018-03-26 11:35:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:35:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:35:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:35:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/detail.php
INFO - 2018-03-26 16:35:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:35:03 --> Final output sent to browser
DEBUG - 2018-03-26 16:35:03 --> Total execution time: 0.0804
INFO - 2018-03-26 11:35:07 --> Config Class Initialized
INFO - 2018-03-26 11:35:07 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:35:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:35:07 --> Utf8 Class Initialized
INFO - 2018-03-26 11:35:07 --> URI Class Initialized
INFO - 2018-03-26 11:35:07 --> Router Class Initialized
INFO - 2018-03-26 11:35:07 --> Output Class Initialized
INFO - 2018-03-26 11:35:07 --> Security Class Initialized
DEBUG - 2018-03-26 11:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:35:07 --> Input Class Initialized
INFO - 2018-03-26 11:35:07 --> Language Class Initialized
INFO - 2018-03-26 11:35:07 --> Loader Class Initialized
INFO - 2018-03-26 11:35:07 --> Helper loaded: url_helper
INFO - 2018-03-26 11:35:07 --> Helper loaded: form_helper
INFO - 2018-03-26 11:35:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:35:07 --> Controller Class Initialized
INFO - 2018-03-26 11:35:07 --> Model Class Initialized
INFO - 2018-03-26 11:35:07 --> Model Class Initialized
INFO - 2018-03-26 11:35:07 --> Model Class Initialized
INFO - 2018-03-26 11:35:07 --> Model Class Initialized
INFO - 2018-03-26 11:35:07 --> Model Class Initialized
INFO - 2018-03-26 11:35:07 --> Model Class Initialized
INFO - 2018-03-26 11:35:07 --> Model Class Initialized
INFO - 2018-03-26 11:35:07 --> Model Class Initialized
INFO - 2018-03-26 11:35:07 --> Model Class Initialized
INFO - 2018-03-26 11:35:07 --> Model Class Initialized
INFO - 2018-03-26 11:35:07 --> Model Class Initialized
INFO - 2018-03-26 11:35:07 --> Model Class Initialized
INFO - 2018-03-26 11:35:07 --> Model Class Initialized
INFO - 2018-03-26 11:35:07 --> Model Class Initialized
INFO - 2018-03-26 11:35:07 --> Helper loaded: date_helper
INFO - 2018-03-26 11:35:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:35:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:35:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:35:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:35:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:35:07 --> Final output sent to browser
DEBUG - 2018-03-26 16:35:07 --> Total execution time: 0.0829
INFO - 2018-03-26 11:35:11 --> Config Class Initialized
INFO - 2018-03-26 11:35:11 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:35:11 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:35:11 --> Utf8 Class Initialized
INFO - 2018-03-26 11:35:11 --> URI Class Initialized
INFO - 2018-03-26 11:35:11 --> Router Class Initialized
INFO - 2018-03-26 11:35:11 --> Output Class Initialized
INFO - 2018-03-26 11:35:11 --> Security Class Initialized
DEBUG - 2018-03-26 11:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:35:11 --> Input Class Initialized
INFO - 2018-03-26 11:35:11 --> Language Class Initialized
INFO - 2018-03-26 11:35:11 --> Loader Class Initialized
INFO - 2018-03-26 11:35:11 --> Helper loaded: url_helper
INFO - 2018-03-26 11:35:11 --> Helper loaded: form_helper
INFO - 2018-03-26 11:35:11 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:35:11 --> Controller Class Initialized
INFO - 2018-03-26 11:35:11 --> Model Class Initialized
INFO - 2018-03-26 11:35:11 --> Model Class Initialized
INFO - 2018-03-26 11:35:11 --> Model Class Initialized
INFO - 2018-03-26 11:35:11 --> Model Class Initialized
INFO - 2018-03-26 11:35:11 --> Model Class Initialized
INFO - 2018-03-26 11:35:11 --> Model Class Initialized
INFO - 2018-03-26 11:35:11 --> Model Class Initialized
INFO - 2018-03-26 11:35:11 --> Model Class Initialized
INFO - 2018-03-26 11:35:11 --> Model Class Initialized
INFO - 2018-03-26 11:35:11 --> Model Class Initialized
INFO - 2018-03-26 11:35:11 --> Model Class Initialized
INFO - 2018-03-26 11:35:11 --> Model Class Initialized
INFO - 2018-03-26 11:35:11 --> Model Class Initialized
INFO - 2018-03-26 11:35:11 --> Model Class Initialized
INFO - 2018-03-26 11:35:11 --> Helper loaded: date_helper
INFO - 2018-03-26 11:35:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:35:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:35:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:35:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/create.php
INFO - 2018-03-26 16:35:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:35:11 --> Final output sent to browser
DEBUG - 2018-03-26 16:35:11 --> Total execution time: 0.1293
INFO - 2018-03-26 11:35:16 --> Config Class Initialized
INFO - 2018-03-26 11:35:16 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:35:16 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:35:16 --> Utf8 Class Initialized
INFO - 2018-03-26 11:35:16 --> URI Class Initialized
INFO - 2018-03-26 11:35:16 --> Router Class Initialized
INFO - 2018-03-26 11:35:16 --> Output Class Initialized
INFO - 2018-03-26 11:35:16 --> Security Class Initialized
DEBUG - 2018-03-26 11:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:35:16 --> Input Class Initialized
INFO - 2018-03-26 11:35:16 --> Language Class Initialized
INFO - 2018-03-26 11:35:16 --> Loader Class Initialized
INFO - 2018-03-26 11:35:16 --> Helper loaded: url_helper
INFO - 2018-03-26 11:35:16 --> Helper loaded: form_helper
INFO - 2018-03-26 11:35:16 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:35:16 --> Controller Class Initialized
INFO - 2018-03-26 11:35:16 --> Model Class Initialized
INFO - 2018-03-26 11:35:16 --> Model Class Initialized
INFO - 2018-03-26 11:35:16 --> Model Class Initialized
INFO - 2018-03-26 11:35:16 --> Model Class Initialized
INFO - 2018-03-26 11:35:16 --> Model Class Initialized
INFO - 2018-03-26 11:35:16 --> Model Class Initialized
INFO - 2018-03-26 11:35:16 --> Model Class Initialized
INFO - 2018-03-26 11:35:16 --> Model Class Initialized
INFO - 2018-03-26 11:35:16 --> Model Class Initialized
INFO - 2018-03-26 11:35:16 --> Model Class Initialized
INFO - 2018-03-26 11:35:16 --> Model Class Initialized
INFO - 2018-03-26 11:35:16 --> Model Class Initialized
INFO - 2018-03-26 11:35:16 --> Model Class Initialized
INFO - 2018-03-26 11:35:16 --> Model Class Initialized
INFO - 2018-03-26 11:35:16 --> Helper loaded: date_helper
INFO - 2018-03-26 11:35:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:35:16 --> Final output sent to browser
DEBUG - 2018-03-26 16:35:16 --> Total execution time: 0.0733
INFO - 2018-03-26 11:35:29 --> Config Class Initialized
INFO - 2018-03-26 11:35:29 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:35:29 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:35:29 --> Utf8 Class Initialized
INFO - 2018-03-26 11:35:29 --> URI Class Initialized
INFO - 2018-03-26 11:35:29 --> Router Class Initialized
INFO - 2018-03-26 11:35:29 --> Output Class Initialized
INFO - 2018-03-26 11:35:29 --> Security Class Initialized
DEBUG - 2018-03-26 11:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:35:29 --> Input Class Initialized
INFO - 2018-03-26 11:35:29 --> Language Class Initialized
INFO - 2018-03-26 11:35:29 --> Loader Class Initialized
INFO - 2018-03-26 11:35:29 --> Helper loaded: url_helper
INFO - 2018-03-26 11:35:29 --> Helper loaded: form_helper
INFO - 2018-03-26 11:35:29 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:35:29 --> Controller Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Helper loaded: date_helper
INFO - 2018-03-26 11:35:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 11:35:29 --> Config Class Initialized
INFO - 2018-03-26 11:35:29 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:35:29 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:35:29 --> Utf8 Class Initialized
INFO - 2018-03-26 11:35:29 --> URI Class Initialized
INFO - 2018-03-26 11:35:29 --> Router Class Initialized
INFO - 2018-03-26 11:35:29 --> Output Class Initialized
INFO - 2018-03-26 11:35:29 --> Security Class Initialized
DEBUG - 2018-03-26 11:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:35:29 --> Input Class Initialized
INFO - 2018-03-26 11:35:29 --> Language Class Initialized
INFO - 2018-03-26 11:35:29 --> Loader Class Initialized
INFO - 2018-03-26 11:35:29 --> Helper loaded: url_helper
INFO - 2018-03-26 11:35:29 --> Helper loaded: form_helper
INFO - 2018-03-26 11:35:29 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:35:29 --> Controller Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Model Class Initialized
INFO - 2018-03-26 11:35:29 --> Helper loaded: date_helper
INFO - 2018-03-26 11:35:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:35:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:35:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:35:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:35:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:35:30 --> Final output sent to browser
DEBUG - 2018-03-26 16:35:30 --> Total execution time: 0.0863
INFO - 2018-03-26 11:35:35 --> Config Class Initialized
INFO - 2018-03-26 11:35:35 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:35:35 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:35:35 --> Utf8 Class Initialized
INFO - 2018-03-26 11:35:35 --> URI Class Initialized
INFO - 2018-03-26 11:35:35 --> Router Class Initialized
INFO - 2018-03-26 11:35:35 --> Output Class Initialized
INFO - 2018-03-26 11:35:35 --> Security Class Initialized
DEBUG - 2018-03-26 11:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:35:35 --> Input Class Initialized
INFO - 2018-03-26 11:35:35 --> Language Class Initialized
INFO - 2018-03-26 11:35:35 --> Loader Class Initialized
INFO - 2018-03-26 11:35:35 --> Helper loaded: url_helper
INFO - 2018-03-26 11:35:35 --> Helper loaded: form_helper
INFO - 2018-03-26 11:35:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:35:36 --> Controller Class Initialized
INFO - 2018-03-26 11:35:36 --> Model Class Initialized
INFO - 2018-03-26 11:35:36 --> Model Class Initialized
INFO - 2018-03-26 11:35:36 --> Model Class Initialized
INFO - 2018-03-26 11:35:36 --> Model Class Initialized
INFO - 2018-03-26 11:35:36 --> Model Class Initialized
INFO - 2018-03-26 11:35:36 --> Model Class Initialized
INFO - 2018-03-26 11:35:36 --> Model Class Initialized
INFO - 2018-03-26 11:35:36 --> Model Class Initialized
INFO - 2018-03-26 11:35:36 --> Model Class Initialized
INFO - 2018-03-26 11:35:36 --> Model Class Initialized
INFO - 2018-03-26 11:35:36 --> Model Class Initialized
INFO - 2018-03-26 11:35:36 --> Model Class Initialized
INFO - 2018-03-26 11:35:36 --> Model Class Initialized
INFO - 2018-03-26 11:35:36 --> Model Class Initialized
INFO - 2018-03-26 11:35:36 --> Helper loaded: date_helper
INFO - 2018-03-26 11:35:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:35:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:35:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:35:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-26 16:35:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:35:36 --> Final output sent to browser
DEBUG - 2018-03-26 16:35:36 --> Total execution time: 0.0866
INFO - 2018-03-26 11:35:41 --> Config Class Initialized
INFO - 2018-03-26 11:35:41 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:35:41 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:35:41 --> Utf8 Class Initialized
INFO - 2018-03-26 11:35:41 --> URI Class Initialized
INFO - 2018-03-26 11:35:41 --> Router Class Initialized
INFO - 2018-03-26 11:35:41 --> Output Class Initialized
INFO - 2018-03-26 11:35:41 --> Security Class Initialized
DEBUG - 2018-03-26 11:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:35:41 --> Input Class Initialized
INFO - 2018-03-26 11:35:41 --> Language Class Initialized
INFO - 2018-03-26 11:35:41 --> Loader Class Initialized
INFO - 2018-03-26 11:35:41 --> Helper loaded: url_helper
INFO - 2018-03-26 11:35:41 --> Helper loaded: form_helper
INFO - 2018-03-26 11:35:41 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:35:41 --> Controller Class Initialized
INFO - 2018-03-26 11:35:41 --> Model Class Initialized
INFO - 2018-03-26 11:35:41 --> Model Class Initialized
INFO - 2018-03-26 11:35:41 --> Model Class Initialized
INFO - 2018-03-26 11:35:41 --> Model Class Initialized
INFO - 2018-03-26 11:35:41 --> Model Class Initialized
INFO - 2018-03-26 11:35:41 --> Model Class Initialized
INFO - 2018-03-26 11:35:41 --> Model Class Initialized
INFO - 2018-03-26 11:35:41 --> Model Class Initialized
INFO - 2018-03-26 11:35:41 --> Model Class Initialized
INFO - 2018-03-26 11:35:41 --> Model Class Initialized
INFO - 2018-03-26 11:35:41 --> Model Class Initialized
INFO - 2018-03-26 11:35:41 --> Model Class Initialized
INFO - 2018-03-26 11:35:41 --> Model Class Initialized
INFO - 2018-03-26 11:35:41 --> Model Class Initialized
INFO - 2018-03-26 11:35:41 --> Helper loaded: date_helper
INFO - 2018-03-26 11:35:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:35:41 --> Final output sent to browser
DEBUG - 2018-03-26 16:35:41 --> Total execution time: 0.0694
INFO - 2018-03-26 11:35:44 --> Config Class Initialized
INFO - 2018-03-26 11:35:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:35:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:35:44 --> Utf8 Class Initialized
INFO - 2018-03-26 11:35:44 --> URI Class Initialized
INFO - 2018-03-26 11:35:44 --> Router Class Initialized
INFO - 2018-03-26 11:35:44 --> Output Class Initialized
INFO - 2018-03-26 11:35:44 --> Security Class Initialized
DEBUG - 2018-03-26 11:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:35:44 --> Input Class Initialized
INFO - 2018-03-26 11:35:44 --> Language Class Initialized
INFO - 2018-03-26 11:35:44 --> Loader Class Initialized
INFO - 2018-03-26 11:35:44 --> Helper loaded: url_helper
INFO - 2018-03-26 11:35:44 --> Helper loaded: form_helper
INFO - 2018-03-26 11:35:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:35:44 --> Controller Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Helper loaded: date_helper
INFO - 2018-03-26 11:35:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 11:35:44 --> Config Class Initialized
INFO - 2018-03-26 11:35:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:35:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:35:44 --> Utf8 Class Initialized
INFO - 2018-03-26 11:35:44 --> URI Class Initialized
INFO - 2018-03-26 11:35:44 --> Router Class Initialized
INFO - 2018-03-26 11:35:44 --> Output Class Initialized
INFO - 2018-03-26 11:35:44 --> Security Class Initialized
DEBUG - 2018-03-26 11:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:35:44 --> Input Class Initialized
INFO - 2018-03-26 11:35:44 --> Language Class Initialized
INFO - 2018-03-26 11:35:44 --> Loader Class Initialized
INFO - 2018-03-26 11:35:44 --> Helper loaded: url_helper
INFO - 2018-03-26 11:35:44 --> Helper loaded: form_helper
INFO - 2018-03-26 11:35:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:35:44 --> Controller Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:44 --> Model Class Initialized
INFO - 2018-03-26 11:35:45 --> Model Class Initialized
INFO - 2018-03-26 11:35:45 --> Model Class Initialized
INFO - 2018-03-26 11:35:45 --> Model Class Initialized
INFO - 2018-03-26 11:35:45 --> Model Class Initialized
INFO - 2018-03-26 11:35:45 --> Model Class Initialized
INFO - 2018-03-26 11:35:45 --> Helper loaded: date_helper
INFO - 2018-03-26 11:35:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:35:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:35:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:35:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-26 16:35:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:35:45 --> Final output sent to browser
DEBUG - 2018-03-26 16:35:45 --> Total execution time: 0.0857
INFO - 2018-03-26 11:35:49 --> Config Class Initialized
INFO - 2018-03-26 11:35:49 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:35:49 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:35:49 --> Utf8 Class Initialized
INFO - 2018-03-26 11:35:49 --> URI Class Initialized
INFO - 2018-03-26 11:35:49 --> Router Class Initialized
INFO - 2018-03-26 11:35:49 --> Output Class Initialized
INFO - 2018-03-26 11:35:49 --> Security Class Initialized
DEBUG - 2018-03-26 11:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:35:49 --> Input Class Initialized
INFO - 2018-03-26 11:35:49 --> Language Class Initialized
INFO - 2018-03-26 11:35:49 --> Loader Class Initialized
INFO - 2018-03-26 11:35:49 --> Helper loaded: url_helper
INFO - 2018-03-26 11:35:49 --> Helper loaded: form_helper
INFO - 2018-03-26 11:35:49 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:35:49 --> Controller Class Initialized
INFO - 2018-03-26 11:35:49 --> Model Class Initialized
INFO - 2018-03-26 11:35:49 --> Model Class Initialized
INFO - 2018-03-26 11:35:49 --> Helper loaded: date_helper
INFO - 2018-03-26 11:35:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:35:49 --> Final output sent to browser
DEBUG - 2018-03-26 16:35:49 --> Total execution time: 0.0810
INFO - 2018-03-26 11:35:49 --> Config Class Initialized
INFO - 2018-03-26 11:35:49 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:35:49 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:35:49 --> Utf8 Class Initialized
INFO - 2018-03-26 11:35:49 --> URI Class Initialized
INFO - 2018-03-26 11:35:49 --> Router Class Initialized
INFO - 2018-03-26 11:35:49 --> Output Class Initialized
INFO - 2018-03-26 11:35:49 --> Security Class Initialized
DEBUG - 2018-03-26 11:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:35:49 --> Input Class Initialized
INFO - 2018-03-26 11:35:49 --> Language Class Initialized
INFO - 2018-03-26 11:35:49 --> Loader Class Initialized
INFO - 2018-03-26 11:35:49 --> Helper loaded: url_helper
INFO - 2018-03-26 11:35:49 --> Helper loaded: form_helper
INFO - 2018-03-26 11:35:49 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:35:49 --> Controller Class Initialized
INFO - 2018-03-26 11:35:49 --> Model Class Initialized
INFO - 2018-03-26 11:35:49 --> Model Class Initialized
INFO - 2018-03-26 11:35:49 --> Helper loaded: date_helper
INFO - 2018-03-26 11:35:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:35:49 --> Final output sent to browser
DEBUG - 2018-03-26 16:35:49 --> Total execution time: 0.0656
INFO - 2018-03-26 11:35:50 --> Config Class Initialized
INFO - 2018-03-26 11:35:50 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:35:50 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:35:50 --> Utf8 Class Initialized
INFO - 2018-03-26 11:35:50 --> URI Class Initialized
INFO - 2018-03-26 11:35:50 --> Router Class Initialized
INFO - 2018-03-26 11:35:50 --> Output Class Initialized
INFO - 2018-03-26 11:35:50 --> Security Class Initialized
DEBUG - 2018-03-26 11:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:35:50 --> Input Class Initialized
INFO - 2018-03-26 11:35:50 --> Language Class Initialized
INFO - 2018-03-26 11:35:50 --> Loader Class Initialized
INFO - 2018-03-26 11:35:50 --> Helper loaded: url_helper
INFO - 2018-03-26 11:35:50 --> Helper loaded: form_helper
INFO - 2018-03-26 11:35:50 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:35:50 --> Controller Class Initialized
INFO - 2018-03-26 11:35:50 --> Model Class Initialized
INFO - 2018-03-26 11:35:50 --> Model Class Initialized
INFO - 2018-03-26 11:35:50 --> Helper loaded: date_helper
INFO - 2018-03-26 11:35:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:35:50 --> Final output sent to browser
DEBUG - 2018-03-26 16:35:50 --> Total execution time: 0.0532
INFO - 2018-03-26 11:35:53 --> Config Class Initialized
INFO - 2018-03-26 11:35:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:35:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:35:53 --> Utf8 Class Initialized
INFO - 2018-03-26 11:35:53 --> URI Class Initialized
INFO - 2018-03-26 11:35:53 --> Router Class Initialized
INFO - 2018-03-26 11:35:53 --> Output Class Initialized
INFO - 2018-03-26 11:35:53 --> Security Class Initialized
DEBUG - 2018-03-26 11:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:35:53 --> Input Class Initialized
INFO - 2018-03-26 11:35:53 --> Language Class Initialized
INFO - 2018-03-26 11:35:53 --> Loader Class Initialized
INFO - 2018-03-26 11:35:53 --> Helper loaded: url_helper
INFO - 2018-03-26 11:35:53 --> Helper loaded: form_helper
INFO - 2018-03-26 11:35:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:35:53 --> Controller Class Initialized
INFO - 2018-03-26 11:35:53 --> Model Class Initialized
INFO - 2018-03-26 11:35:53 --> Model Class Initialized
INFO - 2018-03-26 11:35:53 --> Model Class Initialized
INFO - 2018-03-26 11:35:53 --> Model Class Initialized
INFO - 2018-03-26 11:35:53 --> Model Class Initialized
INFO - 2018-03-26 11:35:53 --> Model Class Initialized
INFO - 2018-03-26 11:35:53 --> Model Class Initialized
INFO - 2018-03-26 11:35:53 --> Model Class Initialized
INFO - 2018-03-26 11:35:53 --> Model Class Initialized
INFO - 2018-03-26 11:35:53 --> Model Class Initialized
INFO - 2018-03-26 11:35:53 --> Model Class Initialized
INFO - 2018-03-26 11:35:53 --> Model Class Initialized
INFO - 2018-03-26 11:35:53 --> Model Class Initialized
INFO - 2018-03-26 11:35:53 --> Model Class Initialized
INFO - 2018-03-26 11:35:53 --> Helper loaded: date_helper
INFO - 2018-03-26 11:35:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 11:35:54 --> Config Class Initialized
INFO - 2018-03-26 11:35:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:35:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:35:54 --> Utf8 Class Initialized
INFO - 2018-03-26 11:35:54 --> URI Class Initialized
INFO - 2018-03-26 11:35:54 --> Router Class Initialized
INFO - 2018-03-26 11:35:54 --> Output Class Initialized
INFO - 2018-03-26 11:35:54 --> Security Class Initialized
DEBUG - 2018-03-26 11:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:35:54 --> Input Class Initialized
INFO - 2018-03-26 11:35:54 --> Language Class Initialized
INFO - 2018-03-26 11:35:54 --> Loader Class Initialized
INFO - 2018-03-26 11:35:54 --> Helper loaded: url_helper
INFO - 2018-03-26 11:35:54 --> Helper loaded: form_helper
INFO - 2018-03-26 11:35:54 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:35:54 --> Controller Class Initialized
INFO - 2018-03-26 11:35:54 --> Model Class Initialized
INFO - 2018-03-26 11:35:54 --> Model Class Initialized
INFO - 2018-03-26 11:35:54 --> Model Class Initialized
INFO - 2018-03-26 11:35:54 --> Model Class Initialized
INFO - 2018-03-26 11:35:54 --> Model Class Initialized
INFO - 2018-03-26 11:35:54 --> Model Class Initialized
INFO - 2018-03-26 11:35:54 --> Model Class Initialized
INFO - 2018-03-26 11:35:54 --> Model Class Initialized
INFO - 2018-03-26 11:35:54 --> Model Class Initialized
INFO - 2018-03-26 11:35:54 --> Model Class Initialized
INFO - 2018-03-26 11:35:54 --> Model Class Initialized
INFO - 2018-03-26 11:35:54 --> Model Class Initialized
INFO - 2018-03-26 11:35:54 --> Model Class Initialized
INFO - 2018-03-26 11:35:54 --> Model Class Initialized
INFO - 2018-03-26 11:35:54 --> Helper loaded: date_helper
INFO - 2018-03-26 11:35:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:35:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:35:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:35:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-26 16:35:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:35:54 --> Final output sent to browser
DEBUG - 2018-03-26 16:35:54 --> Total execution time: 0.1308
INFO - 2018-03-26 11:36:01 --> Config Class Initialized
INFO - 2018-03-26 11:36:01 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:36:01 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:36:01 --> Utf8 Class Initialized
INFO - 2018-03-26 11:36:01 --> URI Class Initialized
INFO - 2018-03-26 11:36:01 --> Router Class Initialized
INFO - 2018-03-26 11:36:01 --> Output Class Initialized
INFO - 2018-03-26 11:36:01 --> Security Class Initialized
DEBUG - 2018-03-26 11:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:36:01 --> Input Class Initialized
INFO - 2018-03-26 11:36:01 --> Language Class Initialized
INFO - 2018-03-26 11:36:01 --> Loader Class Initialized
INFO - 2018-03-26 11:36:01 --> Helper loaded: url_helper
INFO - 2018-03-26 11:36:01 --> Helper loaded: form_helper
INFO - 2018-03-26 11:36:01 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:36:01 --> Controller Class Initialized
INFO - 2018-03-26 11:36:01 --> Model Class Initialized
INFO - 2018-03-26 11:36:01 --> Model Class Initialized
INFO - 2018-03-26 11:36:01 --> Helper loaded: date_helper
INFO - 2018-03-26 11:36:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:36:01 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:01 --> Total execution time: 0.0546
INFO - 2018-03-26 11:36:03 --> Config Class Initialized
INFO - 2018-03-26 11:36:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:36:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:36:03 --> Utf8 Class Initialized
INFO - 2018-03-26 11:36:03 --> URI Class Initialized
INFO - 2018-03-26 11:36:03 --> Router Class Initialized
INFO - 2018-03-26 11:36:03 --> Output Class Initialized
INFO - 2018-03-26 11:36:03 --> Security Class Initialized
DEBUG - 2018-03-26 11:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:36:03 --> Input Class Initialized
INFO - 2018-03-26 11:36:03 --> Language Class Initialized
INFO - 2018-03-26 11:36:03 --> Loader Class Initialized
INFO - 2018-03-26 11:36:03 --> Helper loaded: url_helper
INFO - 2018-03-26 11:36:03 --> Helper loaded: form_helper
INFO - 2018-03-26 11:36:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:36:03 --> Controller Class Initialized
INFO - 2018-03-26 11:36:03 --> Model Class Initialized
INFO - 2018-03-26 11:36:03 --> Model Class Initialized
INFO - 2018-03-26 11:36:03 --> Model Class Initialized
INFO - 2018-03-26 11:36:03 --> Model Class Initialized
INFO - 2018-03-26 11:36:03 --> Model Class Initialized
INFO - 2018-03-26 11:36:03 --> Model Class Initialized
INFO - 2018-03-26 11:36:03 --> Model Class Initialized
INFO - 2018-03-26 11:36:03 --> Model Class Initialized
INFO - 2018-03-26 11:36:03 --> Model Class Initialized
INFO - 2018-03-26 11:36:03 --> Model Class Initialized
INFO - 2018-03-26 11:36:03 --> Model Class Initialized
INFO - 2018-03-26 11:36:03 --> Model Class Initialized
INFO - 2018-03-26 11:36:03 --> Model Class Initialized
INFO - 2018-03-26 11:36:03 --> Model Class Initialized
INFO - 2018-03-26 11:36:03 --> Helper loaded: date_helper
INFO - 2018-03-26 11:36:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 11:36:04 --> Config Class Initialized
INFO - 2018-03-26 11:36:04 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:36:04 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:36:04 --> Utf8 Class Initialized
INFO - 2018-03-26 11:36:04 --> URI Class Initialized
INFO - 2018-03-26 11:36:04 --> Router Class Initialized
INFO - 2018-03-26 11:36:04 --> Output Class Initialized
INFO - 2018-03-26 11:36:04 --> Security Class Initialized
DEBUG - 2018-03-26 11:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:36:04 --> Input Class Initialized
INFO - 2018-03-26 11:36:04 --> Language Class Initialized
INFO - 2018-03-26 11:36:04 --> Loader Class Initialized
INFO - 2018-03-26 11:36:04 --> Helper loaded: url_helper
INFO - 2018-03-26 11:36:04 --> Helper loaded: form_helper
INFO - 2018-03-26 11:36:04 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:36:04 --> Controller Class Initialized
INFO - 2018-03-26 11:36:04 --> Model Class Initialized
INFO - 2018-03-26 11:36:04 --> Model Class Initialized
INFO - 2018-03-26 11:36:04 --> Model Class Initialized
INFO - 2018-03-26 11:36:04 --> Model Class Initialized
INFO - 2018-03-26 11:36:04 --> Model Class Initialized
INFO - 2018-03-26 11:36:04 --> Model Class Initialized
INFO - 2018-03-26 11:36:04 --> Model Class Initialized
INFO - 2018-03-26 11:36:04 --> Model Class Initialized
INFO - 2018-03-26 11:36:04 --> Model Class Initialized
INFO - 2018-03-26 11:36:04 --> Model Class Initialized
INFO - 2018-03-26 11:36:04 --> Model Class Initialized
INFO - 2018-03-26 11:36:04 --> Model Class Initialized
INFO - 2018-03-26 11:36:04 --> Model Class Initialized
INFO - 2018-03-26 11:36:04 --> Model Class Initialized
INFO - 2018-03-26 11:36:04 --> Helper loaded: date_helper
INFO - 2018-03-26 11:36:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:36:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:36:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:36:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-26 16:36:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:36:04 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:04 --> Total execution time: 0.0851
INFO - 2018-03-26 11:36:07 --> Config Class Initialized
INFO - 2018-03-26 11:36:07 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:36:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:36:07 --> Utf8 Class Initialized
INFO - 2018-03-26 11:36:07 --> URI Class Initialized
INFO - 2018-03-26 11:36:07 --> Router Class Initialized
INFO - 2018-03-26 11:36:07 --> Output Class Initialized
INFO - 2018-03-26 11:36:07 --> Security Class Initialized
DEBUG - 2018-03-26 11:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:36:07 --> Input Class Initialized
INFO - 2018-03-26 11:36:07 --> Language Class Initialized
INFO - 2018-03-26 11:36:07 --> Loader Class Initialized
INFO - 2018-03-26 11:36:07 --> Helper loaded: url_helper
INFO - 2018-03-26 11:36:07 --> Helper loaded: form_helper
INFO - 2018-03-26 11:36:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:36:07 --> Controller Class Initialized
INFO - 2018-03-26 11:36:07 --> Model Class Initialized
INFO - 2018-03-26 11:36:07 --> Model Class Initialized
INFO - 2018-03-26 11:36:07 --> Helper loaded: date_helper
INFO - 2018-03-26 11:36:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:36:07 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:07 --> Total execution time: 0.0538
INFO - 2018-03-26 11:36:20 --> Config Class Initialized
INFO - 2018-03-26 11:36:20 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:36:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:36:20 --> Utf8 Class Initialized
INFO - 2018-03-26 11:36:20 --> URI Class Initialized
INFO - 2018-03-26 11:36:20 --> Router Class Initialized
INFO - 2018-03-26 11:36:20 --> Output Class Initialized
INFO - 2018-03-26 11:36:20 --> Security Class Initialized
DEBUG - 2018-03-26 11:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:36:20 --> Input Class Initialized
INFO - 2018-03-26 11:36:20 --> Language Class Initialized
INFO - 2018-03-26 11:36:20 --> Loader Class Initialized
INFO - 2018-03-26 11:36:20 --> Helper loaded: url_helper
INFO - 2018-03-26 11:36:20 --> Helper loaded: form_helper
INFO - 2018-03-26 11:36:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:36:20 --> Controller Class Initialized
INFO - 2018-03-26 11:36:20 --> Model Class Initialized
INFO - 2018-03-26 11:36:20 --> Model Class Initialized
INFO - 2018-03-26 11:36:20 --> Model Class Initialized
INFO - 2018-03-26 11:36:20 --> Model Class Initialized
INFO - 2018-03-26 11:36:20 --> Model Class Initialized
INFO - 2018-03-26 11:36:20 --> Model Class Initialized
INFO - 2018-03-26 11:36:20 --> Model Class Initialized
INFO - 2018-03-26 11:36:20 --> Model Class Initialized
INFO - 2018-03-26 11:36:20 --> Model Class Initialized
INFO - 2018-03-26 11:36:20 --> Model Class Initialized
INFO - 2018-03-26 11:36:20 --> Model Class Initialized
INFO - 2018-03-26 11:36:20 --> Model Class Initialized
INFO - 2018-03-26 11:36:20 --> Helper loaded: date_helper
INFO - 2018-03-26 11:36:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:36:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:36:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:36:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-26 16:36:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:36:20 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:20 --> Total execution time: 0.0830
INFO - 2018-03-26 11:36:22 --> Config Class Initialized
INFO - 2018-03-26 11:36:22 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:36:22 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:36:22 --> Utf8 Class Initialized
INFO - 2018-03-26 11:36:22 --> URI Class Initialized
INFO - 2018-03-26 11:36:22 --> Router Class Initialized
INFO - 2018-03-26 11:36:22 --> Output Class Initialized
INFO - 2018-03-26 11:36:22 --> Security Class Initialized
DEBUG - 2018-03-26 11:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:36:22 --> Input Class Initialized
INFO - 2018-03-26 11:36:22 --> Language Class Initialized
INFO - 2018-03-26 11:36:22 --> Loader Class Initialized
INFO - 2018-03-26 11:36:22 --> Helper loaded: url_helper
INFO - 2018-03-26 11:36:22 --> Helper loaded: form_helper
INFO - 2018-03-26 11:36:22 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:36:22 --> Controller Class Initialized
INFO - 2018-03-26 11:36:22 --> Model Class Initialized
INFO - 2018-03-26 11:36:22 --> Model Class Initialized
INFO - 2018-03-26 11:36:22 --> Model Class Initialized
INFO - 2018-03-26 11:36:22 --> Model Class Initialized
INFO - 2018-03-26 11:36:22 --> Model Class Initialized
INFO - 2018-03-26 11:36:22 --> Model Class Initialized
INFO - 2018-03-26 11:36:22 --> Model Class Initialized
INFO - 2018-03-26 11:36:22 --> Model Class Initialized
INFO - 2018-03-26 11:36:22 --> Model Class Initialized
INFO - 2018-03-26 11:36:22 --> Model Class Initialized
INFO - 2018-03-26 11:36:22 --> Model Class Initialized
INFO - 2018-03-26 11:36:22 --> Model Class Initialized
INFO - 2018-03-26 11:36:22 --> Helper loaded: date_helper
INFO - 2018-03-26 11:36:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:36:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:36:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:36:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:36:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:36:22 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:22 --> Total execution time: 0.0747
INFO - 2018-03-26 11:36:41 --> Config Class Initialized
INFO - 2018-03-26 11:36:41 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:36:41 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:36:41 --> Utf8 Class Initialized
INFO - 2018-03-26 11:36:41 --> URI Class Initialized
INFO - 2018-03-26 11:36:41 --> Router Class Initialized
INFO - 2018-03-26 11:36:41 --> Output Class Initialized
INFO - 2018-03-26 11:36:41 --> Security Class Initialized
DEBUG - 2018-03-26 11:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:36:41 --> Input Class Initialized
INFO - 2018-03-26 11:36:41 --> Language Class Initialized
INFO - 2018-03-26 11:36:41 --> Loader Class Initialized
INFO - 2018-03-26 11:36:41 --> Helper loaded: url_helper
INFO - 2018-03-26 11:36:41 --> Helper loaded: form_helper
INFO - 2018-03-26 11:36:41 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:36:41 --> Controller Class Initialized
INFO - 2018-03-26 11:36:41 --> Model Class Initialized
INFO - 2018-03-26 11:36:41 --> Model Class Initialized
INFO - 2018-03-26 11:36:41 --> Model Class Initialized
INFO - 2018-03-26 11:36:41 --> Model Class Initialized
INFO - 2018-03-26 11:36:41 --> Model Class Initialized
INFO - 2018-03-26 11:36:41 --> Model Class Initialized
INFO - 2018-03-26 11:36:41 --> Model Class Initialized
INFO - 2018-03-26 11:36:41 --> Model Class Initialized
INFO - 2018-03-26 11:36:41 --> Model Class Initialized
INFO - 2018-03-26 11:36:41 --> Model Class Initialized
INFO - 2018-03-26 11:36:41 --> Model Class Initialized
INFO - 2018-03-26 11:36:41 --> Model Class Initialized
INFO - 2018-03-26 11:36:41 --> Helper loaded: date_helper
INFO - 2018-03-26 11:36:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:36:41 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:41 --> Total execution time: 0.1200
INFO - 2018-03-26 11:36:53 --> Config Class Initialized
INFO - 2018-03-26 11:36:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:36:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:36:53 --> Utf8 Class Initialized
INFO - 2018-03-26 11:36:53 --> URI Class Initialized
INFO - 2018-03-26 11:36:53 --> Router Class Initialized
INFO - 2018-03-26 11:36:53 --> Output Class Initialized
INFO - 2018-03-26 11:36:53 --> Security Class Initialized
DEBUG - 2018-03-26 11:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:36:53 --> Input Class Initialized
INFO - 2018-03-26 11:36:53 --> Language Class Initialized
INFO - 2018-03-26 11:36:53 --> Loader Class Initialized
INFO - 2018-03-26 11:36:53 --> Helper loaded: url_helper
INFO - 2018-03-26 11:36:53 --> Helper loaded: form_helper
INFO - 2018-03-26 11:36:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:36:53 --> Controller Class Initialized
INFO - 2018-03-26 11:36:53 --> Model Class Initialized
INFO - 2018-03-26 11:36:53 --> Model Class Initialized
INFO - 2018-03-26 11:36:53 --> Model Class Initialized
INFO - 2018-03-26 11:36:53 --> Model Class Initialized
INFO - 2018-03-26 11:36:53 --> Model Class Initialized
INFO - 2018-03-26 11:36:53 --> Model Class Initialized
INFO - 2018-03-26 11:36:53 --> Model Class Initialized
INFO - 2018-03-26 11:36:53 --> Model Class Initialized
INFO - 2018-03-26 11:36:53 --> Model Class Initialized
INFO - 2018-03-26 11:36:53 --> Model Class Initialized
INFO - 2018-03-26 11:36:53 --> Model Class Initialized
INFO - 2018-03-26 11:36:53 --> Model Class Initialized
INFO - 2018-03-26 11:36:53 --> Helper loaded: date_helper
INFO - 2018-03-26 11:36:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:36:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:36:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:36:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-26 16:36:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:36:53 --> Final output sent to browser
DEBUG - 2018-03-26 16:36:53 --> Total execution time: 0.0899
INFO - 2018-03-26 11:37:03 --> Config Class Initialized
INFO - 2018-03-26 11:37:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:37:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:37:03 --> Utf8 Class Initialized
INFO - 2018-03-26 11:37:03 --> URI Class Initialized
INFO - 2018-03-26 11:37:03 --> Router Class Initialized
INFO - 2018-03-26 11:37:03 --> Output Class Initialized
INFO - 2018-03-26 11:37:03 --> Security Class Initialized
DEBUG - 2018-03-26 11:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:37:03 --> Input Class Initialized
INFO - 2018-03-26 11:37:03 --> Language Class Initialized
INFO - 2018-03-26 11:37:03 --> Loader Class Initialized
INFO - 2018-03-26 11:37:03 --> Helper loaded: url_helper
INFO - 2018-03-26 11:37:03 --> Helper loaded: form_helper
INFO - 2018-03-26 11:37:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:37:03 --> Controller Class Initialized
INFO - 2018-03-26 11:37:03 --> Model Class Initialized
INFO - 2018-03-26 11:37:03 --> Model Class Initialized
INFO - 2018-03-26 11:37:03 --> Model Class Initialized
INFO - 2018-03-26 11:37:03 --> Model Class Initialized
INFO - 2018-03-26 11:37:03 --> Model Class Initialized
INFO - 2018-03-26 11:37:03 --> Model Class Initialized
INFO - 2018-03-26 11:37:03 --> Model Class Initialized
INFO - 2018-03-26 11:37:03 --> Model Class Initialized
INFO - 2018-03-26 11:37:03 --> Model Class Initialized
INFO - 2018-03-26 11:37:03 --> Model Class Initialized
INFO - 2018-03-26 11:37:03 --> Model Class Initialized
INFO - 2018-03-26 11:37:03 --> Model Class Initialized
INFO - 2018-03-26 11:37:03 --> Helper loaded: date_helper
INFO - 2018-03-26 11:37:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:37:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:37:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:37:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-26 16:37:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:37:03 --> Final output sent to browser
DEBUG - 2018-03-26 16:37:03 --> Total execution time: 0.0792
INFO - 2018-03-26 11:38:02 --> Config Class Initialized
INFO - 2018-03-26 11:38:02 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:38:02 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:38:02 --> Utf8 Class Initialized
INFO - 2018-03-26 11:38:02 --> URI Class Initialized
INFO - 2018-03-26 11:38:02 --> Router Class Initialized
INFO - 2018-03-26 11:38:02 --> Output Class Initialized
INFO - 2018-03-26 11:38:02 --> Security Class Initialized
DEBUG - 2018-03-26 11:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:38:02 --> Input Class Initialized
INFO - 2018-03-26 11:38:02 --> Language Class Initialized
INFO - 2018-03-26 11:38:02 --> Loader Class Initialized
INFO - 2018-03-26 11:38:02 --> Helper loaded: url_helper
INFO - 2018-03-26 11:38:02 --> Helper loaded: form_helper
INFO - 2018-03-26 11:38:02 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:38:02 --> Controller Class Initialized
INFO - 2018-03-26 11:38:02 --> Model Class Initialized
INFO - 2018-03-26 11:38:02 --> Model Class Initialized
INFO - 2018-03-26 11:38:02 --> Model Class Initialized
INFO - 2018-03-26 11:38:02 --> Model Class Initialized
INFO - 2018-03-26 11:38:02 --> Model Class Initialized
INFO - 2018-03-26 11:38:02 --> Helper loaded: date_helper
INFO - 2018-03-26 16:38:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:38:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:38:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 16:38:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:38:02 --> Final output sent to browser
DEBUG - 2018-03-26 16:38:02 --> Total execution time: 0.0809
INFO - 2018-03-26 11:38:05 --> Config Class Initialized
INFO - 2018-03-26 11:38:05 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:38:05 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:38:05 --> Utf8 Class Initialized
INFO - 2018-03-26 11:38:05 --> URI Class Initialized
INFO - 2018-03-26 11:38:05 --> Router Class Initialized
INFO - 2018-03-26 11:38:05 --> Output Class Initialized
INFO - 2018-03-26 11:38:05 --> Security Class Initialized
DEBUG - 2018-03-26 11:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:38:05 --> Input Class Initialized
INFO - 2018-03-26 11:38:05 --> Language Class Initialized
INFO - 2018-03-26 11:38:05 --> Loader Class Initialized
INFO - 2018-03-26 11:38:05 --> Helper loaded: url_helper
INFO - 2018-03-26 11:38:05 --> Helper loaded: form_helper
INFO - 2018-03-26 11:38:05 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:38:05 --> Controller Class Initialized
INFO - 2018-03-26 11:38:05 --> Model Class Initialized
INFO - 2018-03-26 11:38:05 --> Model Class Initialized
INFO - 2018-03-26 11:38:05 --> Model Class Initialized
INFO - 2018-03-26 11:38:05 --> Model Class Initialized
INFO - 2018-03-26 11:38:05 --> Model Class Initialized
INFO - 2018-03-26 11:38:05 --> Helper loaded: date_helper
INFO - 2018-03-26 16:38:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:38:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:38:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 16:38:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:38:05 --> Final output sent to browser
DEBUG - 2018-03-26 16:38:05 --> Total execution time: 0.0716
INFO - 2018-03-26 11:38:07 --> Config Class Initialized
INFO - 2018-03-26 11:38:07 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:38:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:38:07 --> Utf8 Class Initialized
INFO - 2018-03-26 11:38:07 --> URI Class Initialized
INFO - 2018-03-26 11:38:07 --> Router Class Initialized
INFO - 2018-03-26 11:38:07 --> Output Class Initialized
INFO - 2018-03-26 11:38:07 --> Security Class Initialized
DEBUG - 2018-03-26 11:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:38:07 --> Input Class Initialized
INFO - 2018-03-26 11:38:07 --> Language Class Initialized
INFO - 2018-03-26 11:38:07 --> Loader Class Initialized
INFO - 2018-03-26 11:38:07 --> Helper loaded: url_helper
INFO - 2018-03-26 11:38:07 --> Helper loaded: form_helper
INFO - 2018-03-26 11:38:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:38:07 --> Controller Class Initialized
INFO - 2018-03-26 11:38:07 --> Model Class Initialized
INFO - 2018-03-26 11:38:07 --> Model Class Initialized
INFO - 2018-03-26 11:38:07 --> Model Class Initialized
INFO - 2018-03-26 11:38:07 --> Model Class Initialized
INFO - 2018-03-26 11:38:07 --> Model Class Initialized
INFO - 2018-03-26 11:38:07 --> Helper loaded: date_helper
INFO - 2018-03-26 16:38:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:38:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:38:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 16:38:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:38:07 --> Final output sent to browser
DEBUG - 2018-03-26 16:38:07 --> Total execution time: 0.0663
INFO - 2018-03-26 11:38:09 --> Config Class Initialized
INFO - 2018-03-26 11:38:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:38:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:38:09 --> Utf8 Class Initialized
INFO - 2018-03-26 11:38:09 --> URI Class Initialized
INFO - 2018-03-26 11:38:09 --> Router Class Initialized
INFO - 2018-03-26 11:38:09 --> Output Class Initialized
INFO - 2018-03-26 11:38:09 --> Security Class Initialized
DEBUG - 2018-03-26 11:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:38:09 --> Input Class Initialized
INFO - 2018-03-26 11:38:09 --> Language Class Initialized
INFO - 2018-03-26 11:38:09 --> Loader Class Initialized
INFO - 2018-03-26 11:38:09 --> Helper loaded: url_helper
INFO - 2018-03-26 11:38:09 --> Helper loaded: form_helper
INFO - 2018-03-26 11:38:09 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:38:09 --> Controller Class Initialized
INFO - 2018-03-26 11:38:09 --> Model Class Initialized
INFO - 2018-03-26 11:38:09 --> Model Class Initialized
INFO - 2018-03-26 11:38:09 --> Model Class Initialized
INFO - 2018-03-26 11:38:09 --> Model Class Initialized
INFO - 2018-03-26 11:38:09 --> Model Class Initialized
INFO - 2018-03-26 11:38:09 --> Helper loaded: date_helper
INFO - 2018-03-26 16:38:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:38:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:38:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 16:38:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:38:09 --> Final output sent to browser
DEBUG - 2018-03-26 16:38:09 --> Total execution time: 0.0636
INFO - 2018-03-26 11:38:10 --> Config Class Initialized
INFO - 2018-03-26 11:38:10 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:38:10 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:38:10 --> Utf8 Class Initialized
INFO - 2018-03-26 11:38:10 --> URI Class Initialized
INFO - 2018-03-26 11:38:10 --> Router Class Initialized
INFO - 2018-03-26 11:38:10 --> Output Class Initialized
INFO - 2018-03-26 11:38:10 --> Security Class Initialized
DEBUG - 2018-03-26 11:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:38:10 --> Input Class Initialized
INFO - 2018-03-26 11:38:10 --> Language Class Initialized
INFO - 2018-03-26 11:38:10 --> Loader Class Initialized
INFO - 2018-03-26 11:38:10 --> Helper loaded: url_helper
INFO - 2018-03-26 11:38:10 --> Helper loaded: form_helper
INFO - 2018-03-26 11:38:10 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:38:10 --> Controller Class Initialized
INFO - 2018-03-26 11:38:10 --> Model Class Initialized
INFO - 2018-03-26 11:38:10 --> Model Class Initialized
INFO - 2018-03-26 11:38:10 --> Model Class Initialized
INFO - 2018-03-26 11:38:10 --> Model Class Initialized
INFO - 2018-03-26 11:38:10 --> Model Class Initialized
INFO - 2018-03-26 11:38:10 --> Helper loaded: date_helper
INFO - 2018-03-26 16:38:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:38:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:38:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 16:38:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:38:10 --> Final output sent to browser
DEBUG - 2018-03-26 16:38:11 --> Total execution time: 0.0877
INFO - 2018-03-26 11:38:12 --> Config Class Initialized
INFO - 2018-03-26 11:38:12 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:38:12 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:38:12 --> Utf8 Class Initialized
INFO - 2018-03-26 11:38:12 --> URI Class Initialized
INFO - 2018-03-26 11:38:12 --> Router Class Initialized
INFO - 2018-03-26 11:38:12 --> Output Class Initialized
INFO - 2018-03-26 11:38:12 --> Security Class Initialized
DEBUG - 2018-03-26 11:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:38:12 --> Input Class Initialized
INFO - 2018-03-26 11:38:12 --> Language Class Initialized
INFO - 2018-03-26 11:38:12 --> Loader Class Initialized
INFO - 2018-03-26 11:38:12 --> Helper loaded: url_helper
INFO - 2018-03-26 11:38:12 --> Helper loaded: form_helper
INFO - 2018-03-26 11:38:12 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:38:12 --> Controller Class Initialized
INFO - 2018-03-26 11:38:12 --> Model Class Initialized
INFO - 2018-03-26 11:38:12 --> Model Class Initialized
INFO - 2018-03-26 11:38:12 --> Model Class Initialized
INFO - 2018-03-26 11:38:12 --> Model Class Initialized
INFO - 2018-03-26 11:38:12 --> Model Class Initialized
INFO - 2018-03-26 11:38:12 --> Helper loaded: date_helper
INFO - 2018-03-26 16:38:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:38:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:38:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 16:38:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:38:12 --> Final output sent to browser
DEBUG - 2018-03-26 16:38:12 --> Total execution time: 0.0776
INFO - 2018-03-26 11:38:14 --> Config Class Initialized
INFO - 2018-03-26 11:38:14 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:38:14 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:38:14 --> Utf8 Class Initialized
INFO - 2018-03-26 11:38:14 --> URI Class Initialized
INFO - 2018-03-26 11:38:14 --> Router Class Initialized
INFO - 2018-03-26 11:38:14 --> Output Class Initialized
INFO - 2018-03-26 11:38:14 --> Security Class Initialized
DEBUG - 2018-03-26 11:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:38:14 --> Input Class Initialized
INFO - 2018-03-26 11:38:14 --> Language Class Initialized
INFO - 2018-03-26 11:38:14 --> Loader Class Initialized
INFO - 2018-03-26 11:38:14 --> Helper loaded: url_helper
INFO - 2018-03-26 11:38:14 --> Helper loaded: form_helper
INFO - 2018-03-26 11:38:14 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:38:14 --> Controller Class Initialized
INFO - 2018-03-26 11:38:14 --> Model Class Initialized
INFO - 2018-03-26 11:38:14 --> Model Class Initialized
INFO - 2018-03-26 11:38:14 --> Model Class Initialized
INFO - 2018-03-26 11:38:14 --> Model Class Initialized
INFO - 2018-03-26 11:38:14 --> Model Class Initialized
INFO - 2018-03-26 11:38:14 --> Helper loaded: date_helper
INFO - 2018-03-26 16:38:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:38:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:38:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 16:38:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:38:14 --> Final output sent to browser
DEBUG - 2018-03-26 16:38:14 --> Total execution time: 0.0596
INFO - 2018-03-26 11:41:36 --> Config Class Initialized
INFO - 2018-03-26 11:41:36 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:41:36 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:41:36 --> Utf8 Class Initialized
INFO - 2018-03-26 11:41:36 --> URI Class Initialized
INFO - 2018-03-26 11:41:36 --> Router Class Initialized
INFO - 2018-03-26 11:41:36 --> Output Class Initialized
INFO - 2018-03-26 11:41:36 --> Security Class Initialized
DEBUG - 2018-03-26 11:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:41:36 --> Input Class Initialized
INFO - 2018-03-26 11:41:36 --> Language Class Initialized
INFO - 2018-03-26 11:41:36 --> Loader Class Initialized
INFO - 2018-03-26 11:41:36 --> Helper loaded: url_helper
INFO - 2018-03-26 11:41:36 --> Helper loaded: form_helper
INFO - 2018-03-26 11:41:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:41:36 --> Controller Class Initialized
INFO - 2018-03-26 11:41:36 --> Model Class Initialized
INFO - 2018-03-26 11:41:36 --> Model Class Initialized
INFO - 2018-03-26 11:41:36 --> Model Class Initialized
INFO - 2018-03-26 11:41:36 --> Model Class Initialized
INFO - 2018-03-26 11:41:36 --> Model Class Initialized
INFO - 2018-03-26 11:41:36 --> Model Class Initialized
INFO - 2018-03-26 11:41:36 --> Model Class Initialized
INFO - 2018-03-26 11:41:36 --> Model Class Initialized
INFO - 2018-03-26 11:41:36 --> Model Class Initialized
INFO - 2018-03-26 11:41:36 --> Model Class Initialized
INFO - 2018-03-26 11:41:36 --> Model Class Initialized
INFO - 2018-03-26 11:41:36 --> Model Class Initialized
INFO - 2018-03-26 11:41:36 --> Model Class Initialized
INFO - 2018-03-26 11:41:36 --> Model Class Initialized
INFO - 2018-03-26 11:41:36 --> Helper loaded: date_helper
INFO - 2018-03-26 11:41:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:41:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:41:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:41:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:41:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:41:36 --> Final output sent to browser
DEBUG - 2018-03-26 16:41:36 --> Total execution time: 0.0943
INFO - 2018-03-26 11:41:49 --> Config Class Initialized
INFO - 2018-03-26 11:41:49 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:41:49 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:41:49 --> Utf8 Class Initialized
INFO - 2018-03-26 11:41:49 --> URI Class Initialized
INFO - 2018-03-26 11:41:49 --> Router Class Initialized
INFO - 2018-03-26 11:41:49 --> Output Class Initialized
INFO - 2018-03-26 11:41:49 --> Security Class Initialized
DEBUG - 2018-03-26 11:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:41:49 --> Input Class Initialized
INFO - 2018-03-26 11:41:49 --> Language Class Initialized
INFO - 2018-03-26 11:41:49 --> Loader Class Initialized
INFO - 2018-03-26 11:41:49 --> Helper loaded: url_helper
INFO - 2018-03-26 11:41:49 --> Helper loaded: form_helper
INFO - 2018-03-26 11:41:49 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:41:49 --> Controller Class Initialized
INFO - 2018-03-26 11:41:49 --> Model Class Initialized
INFO - 2018-03-26 11:41:49 --> Model Class Initialized
INFO - 2018-03-26 11:41:49 --> Model Class Initialized
INFO - 2018-03-26 11:41:49 --> Model Class Initialized
INFO - 2018-03-26 11:41:49 --> Model Class Initialized
INFO - 2018-03-26 11:41:49 --> Model Class Initialized
INFO - 2018-03-26 11:41:49 --> Model Class Initialized
INFO - 2018-03-26 11:41:49 --> Model Class Initialized
INFO - 2018-03-26 11:41:49 --> Model Class Initialized
INFO - 2018-03-26 11:41:49 --> Model Class Initialized
INFO - 2018-03-26 11:41:49 --> Model Class Initialized
INFO - 2018-03-26 11:41:49 --> Model Class Initialized
INFO - 2018-03-26 11:41:49 --> Model Class Initialized
INFO - 2018-03-26 11:41:49 --> Model Class Initialized
INFO - 2018-03-26 11:41:49 --> Helper loaded: date_helper
INFO - 2018-03-26 11:41:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:41:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:41:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:41:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-26 16:41:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:41:49 --> Final output sent to browser
DEBUG - 2018-03-26 16:41:49 --> Total execution time: 0.0992
INFO - 2018-03-26 11:42:00 --> Config Class Initialized
INFO - 2018-03-26 11:42:00 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:42:00 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:42:00 --> Utf8 Class Initialized
INFO - 2018-03-26 11:42:00 --> URI Class Initialized
INFO - 2018-03-26 11:42:00 --> Router Class Initialized
INFO - 2018-03-26 11:42:00 --> Output Class Initialized
INFO - 2018-03-26 11:42:00 --> Security Class Initialized
DEBUG - 2018-03-26 11:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:42:00 --> Input Class Initialized
INFO - 2018-03-26 11:42:00 --> Language Class Initialized
INFO - 2018-03-26 11:42:00 --> Loader Class Initialized
INFO - 2018-03-26 11:42:00 --> Helper loaded: url_helper
INFO - 2018-03-26 11:42:00 --> Helper loaded: form_helper
INFO - 2018-03-26 11:42:00 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:42:00 --> Controller Class Initialized
INFO - 2018-03-26 11:42:00 --> Model Class Initialized
INFO - 2018-03-26 11:42:00 --> Model Class Initialized
INFO - 2018-03-26 11:42:00 --> Model Class Initialized
INFO - 2018-03-26 11:42:00 --> Model Class Initialized
INFO - 2018-03-26 11:42:00 --> Model Class Initialized
INFO - 2018-03-26 11:42:00 --> Model Class Initialized
INFO - 2018-03-26 11:42:00 --> Model Class Initialized
INFO - 2018-03-26 11:42:00 --> Model Class Initialized
INFO - 2018-03-26 11:42:00 --> Model Class Initialized
INFO - 2018-03-26 11:42:00 --> Model Class Initialized
INFO - 2018-03-26 11:42:00 --> Model Class Initialized
INFO - 2018-03-26 11:42:00 --> Model Class Initialized
INFO - 2018-03-26 11:42:00 --> Model Class Initialized
INFO - 2018-03-26 11:42:00 --> Model Class Initialized
INFO - 2018-03-26 11:42:00 --> Helper loaded: date_helper
INFO - 2018-03-26 11:42:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:42:00 --> Final output sent to browser
DEBUG - 2018-03-26 16:42:00 --> Total execution time: 0.0687
INFO - 2018-03-26 11:42:03 --> Config Class Initialized
INFO - 2018-03-26 11:42:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:42:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:42:03 --> Utf8 Class Initialized
INFO - 2018-03-26 11:42:03 --> URI Class Initialized
INFO - 2018-03-26 11:42:03 --> Router Class Initialized
INFO - 2018-03-26 11:42:03 --> Output Class Initialized
INFO - 2018-03-26 11:42:03 --> Security Class Initialized
DEBUG - 2018-03-26 11:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:42:03 --> Input Class Initialized
INFO - 2018-03-26 11:42:03 --> Language Class Initialized
INFO - 2018-03-26 11:42:03 --> Loader Class Initialized
INFO - 2018-03-26 11:42:03 --> Helper loaded: url_helper
INFO - 2018-03-26 11:42:03 --> Helper loaded: form_helper
INFO - 2018-03-26 11:42:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:42:03 --> Controller Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Helper loaded: date_helper
INFO - 2018-03-26 11:42:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 11:42:03 --> Config Class Initialized
INFO - 2018-03-26 11:42:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:42:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:42:03 --> Utf8 Class Initialized
INFO - 2018-03-26 11:42:03 --> URI Class Initialized
INFO - 2018-03-26 11:42:03 --> Router Class Initialized
INFO - 2018-03-26 11:42:03 --> Output Class Initialized
INFO - 2018-03-26 11:42:03 --> Security Class Initialized
DEBUG - 2018-03-26 11:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:42:03 --> Input Class Initialized
INFO - 2018-03-26 11:42:03 --> Language Class Initialized
INFO - 2018-03-26 11:42:03 --> Loader Class Initialized
INFO - 2018-03-26 11:42:03 --> Helper loaded: url_helper
INFO - 2018-03-26 11:42:03 --> Helper loaded: form_helper
INFO - 2018-03-26 11:42:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:42:03 --> Controller Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Model Class Initialized
INFO - 2018-03-26 11:42:03 --> Helper loaded: date_helper
INFO - 2018-03-26 11:42:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:42:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:42:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:42:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-26 16:42:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:42:03 --> Final output sent to browser
DEBUG - 2018-03-26 16:42:03 --> Total execution time: 0.0906
INFO - 2018-03-26 11:42:16 --> Config Class Initialized
INFO - 2018-03-26 11:42:16 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:42:16 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:42:16 --> Utf8 Class Initialized
INFO - 2018-03-26 11:42:16 --> URI Class Initialized
INFO - 2018-03-26 11:42:16 --> Router Class Initialized
INFO - 2018-03-26 11:42:16 --> Output Class Initialized
INFO - 2018-03-26 11:42:16 --> Security Class Initialized
DEBUG - 2018-03-26 11:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:42:16 --> Input Class Initialized
INFO - 2018-03-26 11:42:16 --> Language Class Initialized
INFO - 2018-03-26 11:42:16 --> Loader Class Initialized
INFO - 2018-03-26 11:42:16 --> Helper loaded: url_helper
INFO - 2018-03-26 11:42:16 --> Helper loaded: form_helper
INFO - 2018-03-26 11:42:16 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:42:16 --> Controller Class Initialized
INFO - 2018-03-26 11:42:16 --> Model Class Initialized
INFO - 2018-03-26 11:42:16 --> Model Class Initialized
INFO - 2018-03-26 11:42:16 --> Model Class Initialized
INFO - 2018-03-26 11:42:16 --> Model Class Initialized
INFO - 2018-03-26 11:42:16 --> Model Class Initialized
INFO - 2018-03-26 11:42:16 --> Model Class Initialized
INFO - 2018-03-26 11:42:16 --> Model Class Initialized
INFO - 2018-03-26 11:42:16 --> Model Class Initialized
INFO - 2018-03-26 11:42:16 --> Model Class Initialized
INFO - 2018-03-26 11:42:16 --> Model Class Initialized
INFO - 2018-03-26 11:42:16 --> Model Class Initialized
INFO - 2018-03-26 11:42:16 --> Model Class Initialized
INFO - 2018-03-26 11:42:16 --> Helper loaded: date_helper
INFO - 2018-03-26 11:42:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:42:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:42:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:42:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-26 16:42:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:42:16 --> Final output sent to browser
DEBUG - 2018-03-26 16:42:16 --> Total execution time: 0.0758
INFO - 2018-03-26 11:42:20 --> Config Class Initialized
INFO - 2018-03-26 11:42:20 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:42:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:42:20 --> Utf8 Class Initialized
INFO - 2018-03-26 11:42:20 --> URI Class Initialized
INFO - 2018-03-26 11:42:20 --> Router Class Initialized
INFO - 2018-03-26 11:42:20 --> Output Class Initialized
INFO - 2018-03-26 11:42:20 --> Security Class Initialized
DEBUG - 2018-03-26 11:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:42:20 --> Input Class Initialized
INFO - 2018-03-26 11:42:20 --> Language Class Initialized
INFO - 2018-03-26 11:42:20 --> Loader Class Initialized
INFO - 2018-03-26 11:42:20 --> Helper loaded: url_helper
INFO - 2018-03-26 11:42:20 --> Helper loaded: form_helper
INFO - 2018-03-26 11:42:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:42:20 --> Controller Class Initialized
INFO - 2018-03-26 11:42:20 --> Model Class Initialized
INFO - 2018-03-26 11:42:20 --> Model Class Initialized
INFO - 2018-03-26 11:42:20 --> Model Class Initialized
INFO - 2018-03-26 11:42:20 --> Model Class Initialized
INFO - 2018-03-26 11:42:20 --> Model Class Initialized
INFO - 2018-03-26 11:42:20 --> Model Class Initialized
INFO - 2018-03-26 11:42:20 --> Model Class Initialized
INFO - 2018-03-26 11:42:20 --> Model Class Initialized
INFO - 2018-03-26 11:42:20 --> Model Class Initialized
INFO - 2018-03-26 11:42:20 --> Model Class Initialized
INFO - 2018-03-26 11:42:20 --> Model Class Initialized
INFO - 2018-03-26 11:42:20 --> Model Class Initialized
INFO - 2018-03-26 11:42:20 --> Model Class Initialized
INFO - 2018-03-26 11:42:20 --> Model Class Initialized
INFO - 2018-03-26 11:42:20 --> Helper loaded: date_helper
INFO - 2018-03-26 11:42:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:42:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:42:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:42:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:42:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:42:20 --> Final output sent to browser
DEBUG - 2018-03-26 16:42:20 --> Total execution time: 0.0929
INFO - 2018-03-26 11:43:01 --> Config Class Initialized
INFO - 2018-03-26 11:43:01 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:43:01 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:43:01 --> Utf8 Class Initialized
INFO - 2018-03-26 11:43:01 --> URI Class Initialized
INFO - 2018-03-26 11:43:02 --> Router Class Initialized
INFO - 2018-03-26 11:43:02 --> Output Class Initialized
INFO - 2018-03-26 11:43:02 --> Security Class Initialized
DEBUG - 2018-03-26 11:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:43:02 --> Input Class Initialized
INFO - 2018-03-26 11:43:02 --> Language Class Initialized
INFO - 2018-03-26 11:43:02 --> Loader Class Initialized
INFO - 2018-03-26 11:43:02 --> Helper loaded: url_helper
INFO - 2018-03-26 11:43:02 --> Helper loaded: form_helper
INFO - 2018-03-26 11:43:02 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:43:02 --> Controller Class Initialized
INFO - 2018-03-26 11:43:02 --> Model Class Initialized
INFO - 2018-03-26 11:43:02 --> Model Class Initialized
INFO - 2018-03-26 11:43:02 --> Model Class Initialized
INFO - 2018-03-26 11:43:02 --> Model Class Initialized
INFO - 2018-03-26 11:43:02 --> Model Class Initialized
INFO - 2018-03-26 11:43:02 --> Model Class Initialized
INFO - 2018-03-26 11:43:02 --> Model Class Initialized
INFO - 2018-03-26 11:43:02 --> Model Class Initialized
INFO - 2018-03-26 11:43:02 --> Model Class Initialized
INFO - 2018-03-26 11:43:02 --> Model Class Initialized
INFO - 2018-03-26 11:43:02 --> Model Class Initialized
INFO - 2018-03-26 11:43:02 --> Model Class Initialized
INFO - 2018-03-26 11:43:02 --> Model Class Initialized
INFO - 2018-03-26 11:43:02 --> Model Class Initialized
INFO - 2018-03-26 11:43:02 --> Helper loaded: date_helper
INFO - 2018-03-26 11:43:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:43:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:43:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:43:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:43:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:43:02 --> Final output sent to browser
DEBUG - 2018-03-26 16:43:02 --> Total execution time: 0.1054
INFO - 2018-03-26 11:43:22 --> Config Class Initialized
INFO - 2018-03-26 11:43:22 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:43:22 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:43:22 --> Utf8 Class Initialized
INFO - 2018-03-26 11:43:22 --> URI Class Initialized
INFO - 2018-03-26 11:43:22 --> Router Class Initialized
INFO - 2018-03-26 11:43:22 --> Output Class Initialized
INFO - 2018-03-26 11:43:22 --> Security Class Initialized
DEBUG - 2018-03-26 11:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:43:22 --> Input Class Initialized
INFO - 2018-03-26 11:43:22 --> Language Class Initialized
INFO - 2018-03-26 11:43:22 --> Loader Class Initialized
INFO - 2018-03-26 11:43:22 --> Helper loaded: url_helper
INFO - 2018-03-26 11:43:22 --> Helper loaded: form_helper
INFO - 2018-03-26 11:43:22 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:43:22 --> Controller Class Initialized
INFO - 2018-03-26 11:43:22 --> Model Class Initialized
INFO - 2018-03-26 11:43:22 --> Model Class Initialized
INFO - 2018-03-26 11:43:22 --> Model Class Initialized
INFO - 2018-03-26 11:43:22 --> Model Class Initialized
INFO - 2018-03-26 11:43:22 --> Model Class Initialized
INFO - 2018-03-26 11:43:22 --> Model Class Initialized
INFO - 2018-03-26 11:43:22 --> Model Class Initialized
INFO - 2018-03-26 11:43:22 --> Model Class Initialized
INFO - 2018-03-26 11:43:22 --> Model Class Initialized
INFO - 2018-03-26 11:43:22 --> Model Class Initialized
INFO - 2018-03-26 11:43:22 --> Model Class Initialized
INFO - 2018-03-26 11:43:22 --> Model Class Initialized
INFO - 2018-03-26 11:43:22 --> Model Class Initialized
INFO - 2018-03-26 11:43:22 --> Model Class Initialized
INFO - 2018-03-26 11:43:22 --> Helper loaded: date_helper
INFO - 2018-03-26 11:43:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:43:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/list.php
INFO - 2018-03-26 16:43:22 --> Final output sent to browser
DEBUG - 2018-03-26 16:43:22 --> Total execution time: 0.0725
INFO - 2018-03-26 11:43:27 --> Config Class Initialized
INFO - 2018-03-26 11:43:27 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:43:27 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:43:27 --> Utf8 Class Initialized
INFO - 2018-03-26 11:43:27 --> URI Class Initialized
INFO - 2018-03-26 11:43:27 --> Router Class Initialized
INFO - 2018-03-26 11:43:27 --> Output Class Initialized
INFO - 2018-03-26 11:43:27 --> Security Class Initialized
DEBUG - 2018-03-26 11:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:43:27 --> Input Class Initialized
INFO - 2018-03-26 11:43:27 --> Language Class Initialized
INFO - 2018-03-26 11:43:27 --> Loader Class Initialized
INFO - 2018-03-26 11:43:27 --> Helper loaded: url_helper
INFO - 2018-03-26 11:43:27 --> Helper loaded: form_helper
INFO - 2018-03-26 11:43:27 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:43:27 --> Controller Class Initialized
INFO - 2018-03-26 11:43:27 --> Model Class Initialized
INFO - 2018-03-26 11:43:27 --> Model Class Initialized
INFO - 2018-03-26 11:43:27 --> Model Class Initialized
INFO - 2018-03-26 11:43:27 --> Model Class Initialized
INFO - 2018-03-26 11:43:27 --> Model Class Initialized
INFO - 2018-03-26 11:43:27 --> Model Class Initialized
INFO - 2018-03-26 11:43:27 --> Model Class Initialized
INFO - 2018-03-26 11:43:27 --> Model Class Initialized
INFO - 2018-03-26 11:43:27 --> Model Class Initialized
INFO - 2018-03-26 11:43:27 --> Model Class Initialized
INFO - 2018-03-26 11:43:27 --> Model Class Initialized
INFO - 2018-03-26 11:43:27 --> Model Class Initialized
INFO - 2018-03-26 11:43:27 --> Model Class Initialized
INFO - 2018-03-26 11:43:27 --> Model Class Initialized
INFO - 2018-03-26 11:43:27 --> Helper loaded: date_helper
INFO - 2018-03-26 11:43:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:43:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/list.php
INFO - 2018-03-26 16:43:27 --> Final output sent to browser
DEBUG - 2018-03-26 16:43:27 --> Total execution time: 0.0756
INFO - 2018-03-26 11:49:50 --> Config Class Initialized
INFO - 2018-03-26 11:49:50 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:49:50 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:49:50 --> Utf8 Class Initialized
INFO - 2018-03-26 11:49:50 --> URI Class Initialized
INFO - 2018-03-26 11:49:50 --> Router Class Initialized
INFO - 2018-03-26 11:49:50 --> Output Class Initialized
INFO - 2018-03-26 11:49:50 --> Security Class Initialized
DEBUG - 2018-03-26 11:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:49:50 --> Input Class Initialized
INFO - 2018-03-26 11:49:50 --> Language Class Initialized
INFO - 2018-03-26 11:49:50 --> Loader Class Initialized
INFO - 2018-03-26 11:49:50 --> Helper loaded: url_helper
INFO - 2018-03-26 11:49:50 --> Helper loaded: form_helper
INFO - 2018-03-26 11:49:50 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:49:50 --> Controller Class Initialized
INFO - 2018-03-26 11:49:50 --> Model Class Initialized
INFO - 2018-03-26 11:49:50 --> Model Class Initialized
INFO - 2018-03-26 11:49:50 --> Model Class Initialized
INFO - 2018-03-26 11:49:50 --> Model Class Initialized
INFO - 2018-03-26 11:49:50 --> Model Class Initialized
INFO - 2018-03-26 11:49:50 --> Model Class Initialized
INFO - 2018-03-26 11:49:50 --> Model Class Initialized
INFO - 2018-03-26 11:49:50 --> Model Class Initialized
INFO - 2018-03-26 11:49:50 --> Model Class Initialized
INFO - 2018-03-26 11:49:50 --> Model Class Initialized
INFO - 2018-03-26 11:49:50 --> Model Class Initialized
INFO - 2018-03-26 11:49:50 --> Model Class Initialized
INFO - 2018-03-26 11:49:50 --> Model Class Initialized
INFO - 2018-03-26 11:49:50 --> Model Class Initialized
INFO - 2018-03-26 11:49:50 --> Helper loaded: date_helper
INFO - 2018-03-26 11:49:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:49:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:49:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:49:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:49:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:49:50 --> Final output sent to browser
DEBUG - 2018-03-26 16:49:50 --> Total execution time: 0.0883
INFO - 2018-03-26 11:50:28 --> Config Class Initialized
INFO - 2018-03-26 11:50:28 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:50:28 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:50:28 --> Utf8 Class Initialized
INFO - 2018-03-26 11:50:28 --> URI Class Initialized
INFO - 2018-03-26 11:50:28 --> Router Class Initialized
INFO - 2018-03-26 11:50:28 --> Output Class Initialized
INFO - 2018-03-26 11:50:28 --> Security Class Initialized
DEBUG - 2018-03-26 11:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:50:28 --> Input Class Initialized
INFO - 2018-03-26 11:50:28 --> Language Class Initialized
INFO - 2018-03-26 11:50:28 --> Loader Class Initialized
INFO - 2018-03-26 11:50:28 --> Helper loaded: url_helper
INFO - 2018-03-26 11:50:28 --> Helper loaded: form_helper
INFO - 2018-03-26 11:50:28 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:50:28 --> Controller Class Initialized
INFO - 2018-03-26 11:50:28 --> Model Class Initialized
INFO - 2018-03-26 11:50:28 --> Model Class Initialized
INFO - 2018-03-26 11:50:28 --> Model Class Initialized
INFO - 2018-03-26 11:50:28 --> Model Class Initialized
INFO - 2018-03-26 11:50:28 --> Model Class Initialized
INFO - 2018-03-26 11:50:28 --> Model Class Initialized
INFO - 2018-03-26 11:50:28 --> Model Class Initialized
INFO - 2018-03-26 11:50:28 --> Model Class Initialized
INFO - 2018-03-26 11:50:28 --> Model Class Initialized
INFO - 2018-03-26 11:50:28 --> Model Class Initialized
INFO - 2018-03-26 11:50:28 --> Model Class Initialized
INFO - 2018-03-26 11:50:28 --> Model Class Initialized
INFO - 2018-03-26 11:50:28 --> Model Class Initialized
INFO - 2018-03-26 11:50:28 --> Model Class Initialized
INFO - 2018-03-26 11:50:28 --> Helper loaded: date_helper
INFO - 2018-03-26 11:50:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:50:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:50:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:50:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:50:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:50:28 --> Final output sent to browser
DEBUG - 2018-03-26 16:50:28 --> Total execution time: 0.1012
INFO - 2018-03-26 11:50:31 --> Config Class Initialized
INFO - 2018-03-26 11:50:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:50:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:50:31 --> Utf8 Class Initialized
INFO - 2018-03-26 11:50:32 --> URI Class Initialized
INFO - 2018-03-26 11:50:32 --> Router Class Initialized
INFO - 2018-03-26 11:50:32 --> Output Class Initialized
INFO - 2018-03-26 11:50:32 --> Security Class Initialized
DEBUG - 2018-03-26 11:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:50:32 --> Input Class Initialized
INFO - 2018-03-26 11:50:32 --> Language Class Initialized
INFO - 2018-03-26 11:50:32 --> Loader Class Initialized
INFO - 2018-03-26 11:50:32 --> Helper loaded: url_helper
INFO - 2018-03-26 11:50:32 --> Helper loaded: form_helper
INFO - 2018-03-26 11:50:32 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:50:32 --> Controller Class Initialized
INFO - 2018-03-26 11:50:32 --> Model Class Initialized
INFO - 2018-03-26 11:50:32 --> Model Class Initialized
INFO - 2018-03-26 11:50:32 --> Model Class Initialized
INFO - 2018-03-26 11:50:32 --> Model Class Initialized
INFO - 2018-03-26 11:50:32 --> Model Class Initialized
INFO - 2018-03-26 11:50:32 --> Model Class Initialized
INFO - 2018-03-26 11:50:32 --> Model Class Initialized
INFO - 2018-03-26 11:50:32 --> Model Class Initialized
INFO - 2018-03-26 11:50:32 --> Model Class Initialized
INFO - 2018-03-26 11:50:32 --> Model Class Initialized
INFO - 2018-03-26 11:50:32 --> Model Class Initialized
INFO - 2018-03-26 11:50:32 --> Model Class Initialized
INFO - 2018-03-26 11:50:32 --> Model Class Initialized
INFO - 2018-03-26 11:50:32 --> Model Class Initialized
INFO - 2018-03-26 11:50:32 --> Helper loaded: date_helper
INFO - 2018-03-26 11:50:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:50:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:50:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:50:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:50:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:50:32 --> Final output sent to browser
DEBUG - 2018-03-26 16:50:32 --> Total execution time: 0.0897
INFO - 2018-03-26 11:51:17 --> Config Class Initialized
INFO - 2018-03-26 11:51:17 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:51:17 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:51:17 --> Utf8 Class Initialized
INFO - 2018-03-26 11:51:17 --> URI Class Initialized
INFO - 2018-03-26 11:51:17 --> Router Class Initialized
INFO - 2018-03-26 11:51:17 --> Output Class Initialized
INFO - 2018-03-26 11:51:17 --> Security Class Initialized
DEBUG - 2018-03-26 11:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:51:17 --> Input Class Initialized
INFO - 2018-03-26 11:51:17 --> Language Class Initialized
INFO - 2018-03-26 11:51:17 --> Loader Class Initialized
INFO - 2018-03-26 11:51:17 --> Helper loaded: url_helper
INFO - 2018-03-26 11:51:17 --> Helper loaded: form_helper
INFO - 2018-03-26 11:51:17 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:51:17 --> Controller Class Initialized
INFO - 2018-03-26 11:51:17 --> Model Class Initialized
INFO - 2018-03-26 11:51:17 --> Model Class Initialized
INFO - 2018-03-26 11:51:17 --> Model Class Initialized
INFO - 2018-03-26 11:51:17 --> Model Class Initialized
INFO - 2018-03-26 11:51:17 --> Model Class Initialized
INFO - 2018-03-26 11:51:17 --> Helper loaded: date_helper
INFO - 2018-03-26 16:51:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:51:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:51:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 16:51:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:51:17 --> Final output sent to browser
DEBUG - 2018-03-26 16:51:17 --> Total execution time: 0.0698
INFO - 2018-03-26 11:51:20 --> Config Class Initialized
INFO - 2018-03-26 11:51:20 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:51:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:51:20 --> Utf8 Class Initialized
INFO - 2018-03-26 11:51:20 --> URI Class Initialized
INFO - 2018-03-26 11:51:20 --> Router Class Initialized
INFO - 2018-03-26 11:51:20 --> Output Class Initialized
INFO - 2018-03-26 11:51:20 --> Security Class Initialized
DEBUG - 2018-03-26 11:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:51:20 --> Input Class Initialized
INFO - 2018-03-26 11:51:20 --> Language Class Initialized
INFO - 2018-03-26 11:51:20 --> Loader Class Initialized
INFO - 2018-03-26 11:51:20 --> Helper loaded: url_helper
INFO - 2018-03-26 11:51:20 --> Helper loaded: form_helper
INFO - 2018-03-26 11:51:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:51:20 --> Controller Class Initialized
INFO - 2018-03-26 11:51:20 --> Model Class Initialized
INFO - 2018-03-26 11:51:20 --> Model Class Initialized
INFO - 2018-03-26 11:51:20 --> Model Class Initialized
INFO - 2018-03-26 11:51:20 --> Model Class Initialized
INFO - 2018-03-26 11:51:20 --> Model Class Initialized
INFO - 2018-03-26 11:51:20 --> Model Class Initialized
INFO - 2018-03-26 11:51:20 --> Model Class Initialized
INFO - 2018-03-26 11:51:20 --> Model Class Initialized
INFO - 2018-03-26 11:51:20 --> Model Class Initialized
INFO - 2018-03-26 11:51:20 --> Model Class Initialized
INFO - 2018-03-26 11:51:20 --> Helper loaded: date_helper
INFO - 2018-03-26 11:51:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:51:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:51:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:51:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-26 16:51:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:51:20 --> Final output sent to browser
DEBUG - 2018-03-26 16:51:20 --> Total execution time: 0.0836
INFO - 2018-03-26 11:51:23 --> Config Class Initialized
INFO - 2018-03-26 11:51:23 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:51:23 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:51:23 --> Utf8 Class Initialized
INFO - 2018-03-26 11:51:23 --> URI Class Initialized
INFO - 2018-03-26 11:51:23 --> Router Class Initialized
INFO - 2018-03-26 11:51:23 --> Output Class Initialized
INFO - 2018-03-26 11:51:23 --> Security Class Initialized
DEBUG - 2018-03-26 11:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:51:23 --> Input Class Initialized
INFO - 2018-03-26 11:51:23 --> Language Class Initialized
INFO - 2018-03-26 11:51:23 --> Loader Class Initialized
INFO - 2018-03-26 11:51:23 --> Helper loaded: url_helper
INFO - 2018-03-26 11:51:23 --> Helper loaded: form_helper
INFO - 2018-03-26 11:51:23 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:51:23 --> Controller Class Initialized
INFO - 2018-03-26 11:51:23 --> Model Class Initialized
INFO - 2018-03-26 11:51:23 --> Model Class Initialized
INFO - 2018-03-26 11:51:23 --> Model Class Initialized
INFO - 2018-03-26 11:51:23 --> Model Class Initialized
INFO - 2018-03-26 11:51:23 --> Model Class Initialized
INFO - 2018-03-26 11:51:23 --> Model Class Initialized
INFO - 2018-03-26 11:51:23 --> Model Class Initialized
INFO - 2018-03-26 11:51:23 --> Model Class Initialized
INFO - 2018-03-26 11:51:23 --> Model Class Initialized
INFO - 2018-03-26 11:51:23 --> Model Class Initialized
INFO - 2018-03-26 11:51:23 --> Model Class Initialized
INFO - 2018-03-26 11:51:23 --> Model Class Initialized
INFO - 2018-03-26 11:51:23 --> Model Class Initialized
INFO - 2018-03-26 11:51:23 --> Model Class Initialized
INFO - 2018-03-26 11:51:23 --> Helper loaded: date_helper
INFO - 2018-03-26 11:51:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:51:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:51:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:51:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:51:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:51:23 --> Final output sent to browser
DEBUG - 2018-03-26 16:51:23 --> Total execution time: 0.0881
INFO - 2018-03-26 11:52:44 --> Config Class Initialized
INFO - 2018-03-26 11:52:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:52:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:52:44 --> Utf8 Class Initialized
INFO - 2018-03-26 11:52:44 --> URI Class Initialized
INFO - 2018-03-26 11:52:44 --> Router Class Initialized
INFO - 2018-03-26 11:52:44 --> Output Class Initialized
INFO - 2018-03-26 11:52:44 --> Security Class Initialized
DEBUG - 2018-03-26 11:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:52:44 --> Input Class Initialized
INFO - 2018-03-26 11:52:44 --> Language Class Initialized
INFO - 2018-03-26 11:52:44 --> Loader Class Initialized
INFO - 2018-03-26 11:52:44 --> Helper loaded: url_helper
INFO - 2018-03-26 11:52:44 --> Helper loaded: form_helper
INFO - 2018-03-26 11:52:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:52:44 --> Controller Class Initialized
INFO - 2018-03-26 11:52:44 --> Model Class Initialized
INFO - 2018-03-26 11:52:44 --> Model Class Initialized
INFO - 2018-03-26 11:52:44 --> Model Class Initialized
INFO - 2018-03-26 11:52:44 --> Model Class Initialized
INFO - 2018-03-26 11:52:44 --> Model Class Initialized
INFO - 2018-03-26 11:52:44 --> Model Class Initialized
INFO - 2018-03-26 11:52:44 --> Model Class Initialized
INFO - 2018-03-26 11:52:44 --> Model Class Initialized
INFO - 2018-03-26 11:52:44 --> Model Class Initialized
INFO - 2018-03-26 11:52:44 --> Model Class Initialized
INFO - 2018-03-26 11:52:44 --> Model Class Initialized
INFO - 2018-03-26 11:52:44 --> Model Class Initialized
INFO - 2018-03-26 11:52:44 --> Model Class Initialized
INFO - 2018-03-26 11:52:44 --> Model Class Initialized
INFO - 2018-03-26 11:52:44 --> Helper loaded: date_helper
INFO - 2018-03-26 11:52:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:52:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:52:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:52:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:52:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:52:44 --> Final output sent to browser
DEBUG - 2018-03-26 16:52:44 --> Total execution time: 0.0936
INFO - 2018-03-26 11:52:52 --> Config Class Initialized
INFO - 2018-03-26 11:52:52 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:52:52 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:52:52 --> Utf8 Class Initialized
INFO - 2018-03-26 11:52:52 --> URI Class Initialized
INFO - 2018-03-26 11:52:52 --> Router Class Initialized
INFO - 2018-03-26 11:52:52 --> Output Class Initialized
INFO - 2018-03-26 11:52:52 --> Security Class Initialized
DEBUG - 2018-03-26 11:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:52:52 --> Input Class Initialized
INFO - 2018-03-26 11:52:52 --> Language Class Initialized
INFO - 2018-03-26 11:52:52 --> Loader Class Initialized
INFO - 2018-03-26 11:52:52 --> Helper loaded: url_helper
INFO - 2018-03-26 11:52:52 --> Helper loaded: form_helper
INFO - 2018-03-26 11:52:52 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:52:52 --> Controller Class Initialized
INFO - 2018-03-26 11:52:52 --> Model Class Initialized
INFO - 2018-03-26 11:52:52 --> Model Class Initialized
INFO - 2018-03-26 11:52:52 --> Model Class Initialized
INFO - 2018-03-26 11:52:52 --> Model Class Initialized
INFO - 2018-03-26 11:52:52 --> Model Class Initialized
INFO - 2018-03-26 11:52:52 --> Model Class Initialized
INFO - 2018-03-26 11:52:52 --> Model Class Initialized
INFO - 2018-03-26 11:52:52 --> Model Class Initialized
INFO - 2018-03-26 11:52:52 --> Model Class Initialized
INFO - 2018-03-26 11:52:52 --> Model Class Initialized
INFO - 2018-03-26 11:52:52 --> Model Class Initialized
INFO - 2018-03-26 11:52:52 --> Model Class Initialized
INFO - 2018-03-26 11:52:52 --> Model Class Initialized
INFO - 2018-03-26 11:52:52 --> Model Class Initialized
INFO - 2018-03-26 11:52:52 --> Helper loaded: date_helper
INFO - 2018-03-26 11:52:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:52:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:52:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:52:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:52:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:52:52 --> Final output sent to browser
DEBUG - 2018-03-26 16:52:52 --> Total execution time: 0.0988
INFO - 2018-03-26 11:52:56 --> Config Class Initialized
INFO - 2018-03-26 11:52:56 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:52:56 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:52:56 --> Utf8 Class Initialized
INFO - 2018-03-26 11:52:56 --> URI Class Initialized
INFO - 2018-03-26 11:52:56 --> Router Class Initialized
INFO - 2018-03-26 11:52:56 --> Output Class Initialized
INFO - 2018-03-26 11:52:56 --> Security Class Initialized
DEBUG - 2018-03-26 11:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:52:56 --> Input Class Initialized
INFO - 2018-03-26 11:52:56 --> Language Class Initialized
INFO - 2018-03-26 11:52:56 --> Loader Class Initialized
INFO - 2018-03-26 11:52:56 --> Helper loaded: url_helper
INFO - 2018-03-26 11:52:56 --> Helper loaded: form_helper
INFO - 2018-03-26 11:52:56 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:52:56 --> Controller Class Initialized
INFO - 2018-03-26 11:52:56 --> Model Class Initialized
INFO - 2018-03-26 11:52:56 --> Model Class Initialized
INFO - 2018-03-26 11:52:56 --> Model Class Initialized
INFO - 2018-03-26 11:52:56 --> Model Class Initialized
INFO - 2018-03-26 11:52:56 --> Model Class Initialized
INFO - 2018-03-26 11:52:56 --> Model Class Initialized
INFO - 2018-03-26 11:52:56 --> Model Class Initialized
INFO - 2018-03-26 11:52:56 --> Model Class Initialized
INFO - 2018-03-26 11:52:56 --> Model Class Initialized
INFO - 2018-03-26 11:52:56 --> Model Class Initialized
INFO - 2018-03-26 11:52:56 --> Model Class Initialized
INFO - 2018-03-26 11:52:56 --> Model Class Initialized
INFO - 2018-03-26 11:52:56 --> Model Class Initialized
INFO - 2018-03-26 11:52:56 --> Model Class Initialized
INFO - 2018-03-26 11:52:56 --> Helper loaded: date_helper
INFO - 2018-03-26 11:52:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:52:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:52:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:52:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:52:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:52:56 --> Final output sent to browser
DEBUG - 2018-03-26 16:52:56 --> Total execution time: 0.0937
INFO - 2018-03-26 11:53:23 --> Config Class Initialized
INFO - 2018-03-26 11:53:23 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:53:23 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:53:23 --> Utf8 Class Initialized
INFO - 2018-03-26 11:53:23 --> URI Class Initialized
INFO - 2018-03-26 11:53:23 --> Router Class Initialized
INFO - 2018-03-26 11:53:23 --> Output Class Initialized
INFO - 2018-03-26 11:53:23 --> Security Class Initialized
DEBUG - 2018-03-26 11:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:53:23 --> Input Class Initialized
INFO - 2018-03-26 11:53:23 --> Language Class Initialized
INFO - 2018-03-26 11:53:23 --> Loader Class Initialized
INFO - 2018-03-26 11:53:23 --> Helper loaded: url_helper
INFO - 2018-03-26 11:53:23 --> Helper loaded: form_helper
INFO - 2018-03-26 11:53:23 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:53:23 --> Controller Class Initialized
INFO - 2018-03-26 11:53:23 --> Model Class Initialized
INFO - 2018-03-26 11:53:23 --> Model Class Initialized
INFO - 2018-03-26 11:53:23 --> Model Class Initialized
INFO - 2018-03-26 11:53:23 --> Model Class Initialized
INFO - 2018-03-26 11:53:23 --> Model Class Initialized
INFO - 2018-03-26 11:53:23 --> Model Class Initialized
INFO - 2018-03-26 11:53:23 --> Model Class Initialized
INFO - 2018-03-26 11:53:23 --> Model Class Initialized
INFO - 2018-03-26 11:53:23 --> Model Class Initialized
INFO - 2018-03-26 11:53:23 --> Model Class Initialized
INFO - 2018-03-26 11:53:23 --> Model Class Initialized
INFO - 2018-03-26 11:53:23 --> Model Class Initialized
INFO - 2018-03-26 11:53:23 --> Model Class Initialized
INFO - 2018-03-26 11:53:23 --> Model Class Initialized
INFO - 2018-03-26 11:53:23 --> Helper loaded: date_helper
INFO - 2018-03-26 11:53:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:53:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:53:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:53:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:53:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:53:23 --> Final output sent to browser
DEBUG - 2018-03-26 16:53:23 --> Total execution time: 0.0915
INFO - 2018-03-26 11:53:48 --> Config Class Initialized
INFO - 2018-03-26 11:53:48 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:53:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:53:48 --> Utf8 Class Initialized
INFO - 2018-03-26 11:53:48 --> URI Class Initialized
INFO - 2018-03-26 11:53:48 --> Router Class Initialized
INFO - 2018-03-26 11:53:48 --> Output Class Initialized
INFO - 2018-03-26 11:53:48 --> Security Class Initialized
DEBUG - 2018-03-26 11:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:53:48 --> Input Class Initialized
INFO - 2018-03-26 11:53:48 --> Language Class Initialized
INFO - 2018-03-26 11:53:48 --> Loader Class Initialized
INFO - 2018-03-26 11:53:48 --> Helper loaded: url_helper
INFO - 2018-03-26 11:53:48 --> Helper loaded: form_helper
INFO - 2018-03-26 11:53:48 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:53:48 --> Controller Class Initialized
INFO - 2018-03-26 11:53:48 --> Model Class Initialized
INFO - 2018-03-26 11:53:48 --> Model Class Initialized
INFO - 2018-03-26 11:53:48 --> Model Class Initialized
INFO - 2018-03-26 11:53:48 --> Model Class Initialized
INFO - 2018-03-26 11:53:48 --> Model Class Initialized
INFO - 2018-03-26 11:53:48 --> Model Class Initialized
INFO - 2018-03-26 11:53:48 --> Model Class Initialized
INFO - 2018-03-26 11:53:48 --> Model Class Initialized
INFO - 2018-03-26 11:53:48 --> Model Class Initialized
INFO - 2018-03-26 11:53:48 --> Model Class Initialized
INFO - 2018-03-26 11:53:48 --> Model Class Initialized
INFO - 2018-03-26 11:53:48 --> Model Class Initialized
INFO - 2018-03-26 11:53:48 --> Model Class Initialized
INFO - 2018-03-26 11:53:48 --> Model Class Initialized
INFO - 2018-03-26 11:53:48 --> Helper loaded: date_helper
INFO - 2018-03-26 11:53:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:53:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:53:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:53:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:53:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:53:48 --> Final output sent to browser
DEBUG - 2018-03-26 16:53:48 --> Total execution time: 0.0946
INFO - 2018-03-26 11:53:57 --> Config Class Initialized
INFO - 2018-03-26 11:53:57 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:53:57 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:53:57 --> Utf8 Class Initialized
INFO - 2018-03-26 11:53:57 --> URI Class Initialized
INFO - 2018-03-26 11:53:57 --> Router Class Initialized
INFO - 2018-03-26 11:53:57 --> Output Class Initialized
INFO - 2018-03-26 11:53:57 --> Security Class Initialized
DEBUG - 2018-03-26 11:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:53:57 --> Input Class Initialized
INFO - 2018-03-26 11:53:57 --> Language Class Initialized
INFO - 2018-03-26 11:53:57 --> Loader Class Initialized
INFO - 2018-03-26 11:53:57 --> Helper loaded: url_helper
INFO - 2018-03-26 11:53:57 --> Helper loaded: form_helper
INFO - 2018-03-26 11:53:57 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:53:57 --> Controller Class Initialized
INFO - 2018-03-26 11:53:57 --> Model Class Initialized
INFO - 2018-03-26 11:53:57 --> Model Class Initialized
INFO - 2018-03-26 11:53:57 --> Model Class Initialized
INFO - 2018-03-26 11:53:57 --> Model Class Initialized
INFO - 2018-03-26 11:53:57 --> Model Class Initialized
INFO - 2018-03-26 11:53:57 --> Model Class Initialized
INFO - 2018-03-26 11:53:57 --> Model Class Initialized
INFO - 2018-03-26 11:53:57 --> Model Class Initialized
INFO - 2018-03-26 11:53:57 --> Model Class Initialized
INFO - 2018-03-26 11:53:57 --> Model Class Initialized
INFO - 2018-03-26 11:53:57 --> Model Class Initialized
INFO - 2018-03-26 11:53:57 --> Model Class Initialized
INFO - 2018-03-26 11:53:57 --> Model Class Initialized
INFO - 2018-03-26 11:53:57 --> Model Class Initialized
INFO - 2018-03-26 11:53:57 --> Helper loaded: date_helper
INFO - 2018-03-26 11:53:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:53:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:53:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:53:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:53:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:53:57 --> Final output sent to browser
DEBUG - 2018-03-26 16:53:57 --> Total execution time: 0.1129
INFO - 2018-03-26 11:54:12 --> Config Class Initialized
INFO - 2018-03-26 11:54:12 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:54:12 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:54:12 --> Utf8 Class Initialized
INFO - 2018-03-26 11:54:12 --> URI Class Initialized
INFO - 2018-03-26 11:54:12 --> Router Class Initialized
INFO - 2018-03-26 11:54:12 --> Output Class Initialized
INFO - 2018-03-26 11:54:12 --> Security Class Initialized
DEBUG - 2018-03-26 11:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:54:12 --> Input Class Initialized
INFO - 2018-03-26 11:54:12 --> Language Class Initialized
INFO - 2018-03-26 11:54:12 --> Loader Class Initialized
INFO - 2018-03-26 11:54:12 --> Helper loaded: url_helper
INFO - 2018-03-26 11:54:12 --> Helper loaded: form_helper
INFO - 2018-03-26 11:54:12 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:54:12 --> Controller Class Initialized
INFO - 2018-03-26 11:54:12 --> Model Class Initialized
INFO - 2018-03-26 11:54:12 --> Model Class Initialized
INFO - 2018-03-26 11:54:12 --> Model Class Initialized
INFO - 2018-03-26 11:54:12 --> Model Class Initialized
INFO - 2018-03-26 11:54:12 --> Model Class Initialized
INFO - 2018-03-26 11:54:12 --> Model Class Initialized
INFO - 2018-03-26 11:54:12 --> Model Class Initialized
INFO - 2018-03-26 11:54:12 --> Model Class Initialized
INFO - 2018-03-26 11:54:12 --> Model Class Initialized
INFO - 2018-03-26 11:54:12 --> Model Class Initialized
INFO - 2018-03-26 11:54:12 --> Model Class Initialized
INFO - 2018-03-26 11:54:12 --> Model Class Initialized
INFO - 2018-03-26 11:54:12 --> Model Class Initialized
INFO - 2018-03-26 11:54:12 --> Model Class Initialized
INFO - 2018-03-26 11:54:12 --> Helper loaded: date_helper
INFO - 2018-03-26 11:54:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:54:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:54:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:54:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-26 16:54:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:54:12 --> Final output sent to browser
DEBUG - 2018-03-26 16:54:12 --> Total execution time: 0.0930
INFO - 2018-03-26 11:54:28 --> Config Class Initialized
INFO - 2018-03-26 11:54:28 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:54:28 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:54:28 --> Utf8 Class Initialized
INFO - 2018-03-26 11:54:28 --> URI Class Initialized
INFO - 2018-03-26 11:54:28 --> Router Class Initialized
INFO - 2018-03-26 11:54:28 --> Output Class Initialized
INFO - 2018-03-26 11:54:28 --> Security Class Initialized
DEBUG - 2018-03-26 11:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:54:28 --> Input Class Initialized
INFO - 2018-03-26 11:54:28 --> Language Class Initialized
INFO - 2018-03-26 11:54:28 --> Loader Class Initialized
INFO - 2018-03-26 11:54:28 --> Helper loaded: url_helper
INFO - 2018-03-26 11:54:28 --> Helper loaded: form_helper
INFO - 2018-03-26 11:54:28 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:54:28 --> Controller Class Initialized
INFO - 2018-03-26 11:54:28 --> Model Class Initialized
INFO - 2018-03-26 11:54:28 --> Model Class Initialized
INFO - 2018-03-26 11:54:28 --> Model Class Initialized
INFO - 2018-03-26 11:54:28 --> Model Class Initialized
INFO - 2018-03-26 11:54:28 --> Model Class Initialized
INFO - 2018-03-26 11:54:28 --> Model Class Initialized
INFO - 2018-03-26 11:54:28 --> Model Class Initialized
INFO - 2018-03-26 11:54:28 --> Model Class Initialized
INFO - 2018-03-26 11:54:28 --> Model Class Initialized
INFO - 2018-03-26 11:54:28 --> Model Class Initialized
INFO - 2018-03-26 11:54:28 --> Model Class Initialized
INFO - 2018-03-26 11:54:28 --> Model Class Initialized
INFO - 2018-03-26 11:54:28 --> Model Class Initialized
INFO - 2018-03-26 11:54:28 --> Model Class Initialized
INFO - 2018-03-26 11:54:28 --> Helper loaded: date_helper
INFO - 2018-03-26 11:54:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:54:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:54:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:54:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/create.php
INFO - 2018-03-26 16:54:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:54:28 --> Final output sent to browser
DEBUG - 2018-03-26 16:54:28 --> Total execution time: 0.0910
INFO - 2018-03-26 11:54:54 --> Config Class Initialized
INFO - 2018-03-26 11:54:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:54:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:54:54 --> Utf8 Class Initialized
INFO - 2018-03-26 11:54:54 --> URI Class Initialized
INFO - 2018-03-26 11:54:54 --> Router Class Initialized
INFO - 2018-03-26 11:54:54 --> Output Class Initialized
INFO - 2018-03-26 11:54:54 --> Security Class Initialized
DEBUG - 2018-03-26 11:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:54:54 --> Input Class Initialized
INFO - 2018-03-26 11:54:54 --> Language Class Initialized
INFO - 2018-03-26 11:54:54 --> Loader Class Initialized
INFO - 2018-03-26 11:54:54 --> Helper loaded: url_helper
INFO - 2018-03-26 11:54:54 --> Helper loaded: form_helper
INFO - 2018-03-26 11:54:54 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:54:54 --> Controller Class Initialized
INFO - 2018-03-26 11:54:54 --> Model Class Initialized
INFO - 2018-03-26 11:54:54 --> Model Class Initialized
INFO - 2018-03-26 11:54:54 --> Model Class Initialized
INFO - 2018-03-26 11:54:54 --> Model Class Initialized
INFO - 2018-03-26 11:54:54 --> Model Class Initialized
INFO - 2018-03-26 11:54:54 --> Model Class Initialized
INFO - 2018-03-26 11:54:54 --> Model Class Initialized
INFO - 2018-03-26 11:54:54 --> Model Class Initialized
INFO - 2018-03-26 11:54:54 --> Model Class Initialized
INFO - 2018-03-26 11:54:54 --> Model Class Initialized
INFO - 2018-03-26 11:54:54 --> Model Class Initialized
INFO - 2018-03-26 11:54:54 --> Model Class Initialized
INFO - 2018-03-26 11:54:54 --> Helper loaded: date_helper
INFO - 2018-03-26 11:54:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:54:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:54:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:54:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-26 16:54:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:54:54 --> Final output sent to browser
DEBUG - 2018-03-26 16:54:54 --> Total execution time: 0.0789
INFO - 2018-03-26 11:54:57 --> Config Class Initialized
INFO - 2018-03-26 11:54:57 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:54:57 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:54:57 --> Utf8 Class Initialized
INFO - 2018-03-26 11:54:57 --> URI Class Initialized
INFO - 2018-03-26 11:54:57 --> Router Class Initialized
INFO - 2018-03-26 11:54:57 --> Output Class Initialized
INFO - 2018-03-26 11:54:57 --> Security Class Initialized
DEBUG - 2018-03-26 11:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:54:57 --> Input Class Initialized
INFO - 2018-03-26 11:54:57 --> Language Class Initialized
ERROR - 2018-03-26 11:54:57 --> 404 Page Not Found: Kasir/Tpenjualan/index
INFO - 2018-03-26 11:55:04 --> Config Class Initialized
INFO - 2018-03-26 11:55:04 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:55:04 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:55:04 --> Utf8 Class Initialized
INFO - 2018-03-26 11:55:04 --> URI Class Initialized
INFO - 2018-03-26 11:55:05 --> Router Class Initialized
INFO - 2018-03-26 11:55:05 --> Output Class Initialized
INFO - 2018-03-26 11:55:05 --> Security Class Initialized
DEBUG - 2018-03-26 11:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:55:05 --> Input Class Initialized
INFO - 2018-03-26 11:55:05 --> Language Class Initialized
INFO - 2018-03-26 11:55:05 --> Loader Class Initialized
INFO - 2018-03-26 11:55:05 --> Helper loaded: url_helper
INFO - 2018-03-26 11:55:05 --> Helper loaded: form_helper
INFO - 2018-03-26 11:55:05 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:55:05 --> Controller Class Initialized
INFO - 2018-03-26 11:55:05 --> Model Class Initialized
INFO - 2018-03-26 11:55:05 --> Model Class Initialized
INFO - 2018-03-26 11:55:05 --> Model Class Initialized
INFO - 2018-03-26 11:55:05 --> Model Class Initialized
INFO - 2018-03-26 11:55:05 --> Model Class Initialized
INFO - 2018-03-26 11:55:05 --> Model Class Initialized
INFO - 2018-03-26 11:55:05 --> Model Class Initialized
INFO - 2018-03-26 11:55:05 --> Model Class Initialized
INFO - 2018-03-26 11:55:05 --> Model Class Initialized
INFO - 2018-03-26 11:55:05 --> Model Class Initialized
INFO - 2018-03-26 11:55:05 --> Model Class Initialized
INFO - 2018-03-26 11:55:05 --> Model Class Initialized
INFO - 2018-03-26 11:55:05 --> Helper loaded: date_helper
INFO - 2018-03-26 11:55:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:55:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:55:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:55:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-26 16:55:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:55:05 --> Final output sent to browser
DEBUG - 2018-03-26 16:55:05 --> Total execution time: 0.1002
INFO - 2018-03-26 11:56:23 --> Config Class Initialized
INFO - 2018-03-26 11:56:23 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:56:23 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:56:23 --> Utf8 Class Initialized
INFO - 2018-03-26 11:56:23 --> URI Class Initialized
INFO - 2018-03-26 11:56:23 --> Router Class Initialized
INFO - 2018-03-26 11:56:23 --> Output Class Initialized
INFO - 2018-03-26 11:56:23 --> Security Class Initialized
DEBUG - 2018-03-26 11:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:56:23 --> Input Class Initialized
INFO - 2018-03-26 11:56:23 --> Language Class Initialized
INFO - 2018-03-26 11:56:23 --> Loader Class Initialized
INFO - 2018-03-26 11:56:23 --> Helper loaded: url_helper
INFO - 2018-03-26 11:56:23 --> Helper loaded: form_helper
INFO - 2018-03-26 11:56:23 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:56:23 --> Controller Class Initialized
INFO - 2018-03-26 11:56:23 --> Model Class Initialized
INFO - 2018-03-26 11:56:23 --> Model Class Initialized
INFO - 2018-03-26 11:56:23 --> Model Class Initialized
INFO - 2018-03-26 11:56:23 --> Model Class Initialized
INFO - 2018-03-26 11:56:23 --> Model Class Initialized
INFO - 2018-03-26 11:56:23 --> Model Class Initialized
INFO - 2018-03-26 11:56:23 --> Model Class Initialized
INFO - 2018-03-26 11:56:23 --> Helper loaded: date_helper
INFO - 2018-03-26 11:56:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:56:23 --> Model Class Initialized
INFO - 2018-03-26 16:56:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:56:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:56:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-26 16:56:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:56:24 --> Final output sent to browser
DEBUG - 2018-03-26 16:56:24 --> Total execution time: 0.2278
INFO - 2018-03-26 11:56:30 --> Config Class Initialized
INFO - 2018-03-26 11:56:30 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:56:30 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:56:30 --> Utf8 Class Initialized
INFO - 2018-03-26 11:56:30 --> URI Class Initialized
INFO - 2018-03-26 11:56:30 --> Router Class Initialized
INFO - 2018-03-26 11:56:30 --> Output Class Initialized
INFO - 2018-03-26 11:56:30 --> Security Class Initialized
DEBUG - 2018-03-26 11:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:56:30 --> Input Class Initialized
INFO - 2018-03-26 11:56:30 --> Language Class Initialized
INFO - 2018-03-26 11:56:30 --> Loader Class Initialized
INFO - 2018-03-26 11:56:30 --> Helper loaded: url_helper
INFO - 2018-03-26 11:56:30 --> Helper loaded: form_helper
INFO - 2018-03-26 11:56:30 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:56:30 --> Controller Class Initialized
INFO - 2018-03-26 11:56:30 --> Model Class Initialized
INFO - 2018-03-26 11:56:30 --> Model Class Initialized
INFO - 2018-03-26 11:56:30 --> Model Class Initialized
INFO - 2018-03-26 11:56:30 --> Model Class Initialized
INFO - 2018-03-26 11:56:30 --> Model Class Initialized
INFO - 2018-03-26 11:56:30 --> Model Class Initialized
INFO - 2018-03-26 11:56:30 --> Model Class Initialized
INFO - 2018-03-26 11:56:30 --> Helper loaded: date_helper
INFO - 2018-03-26 11:56:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:56:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-26 16:56:31 --> Final output sent to browser
DEBUG - 2018-03-26 16:56:31 --> Total execution time: 0.0814
INFO - 2018-03-26 11:56:35 --> Config Class Initialized
INFO - 2018-03-26 11:56:35 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:56:35 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:56:35 --> Utf8 Class Initialized
INFO - 2018-03-26 11:56:35 --> URI Class Initialized
INFO - 2018-03-26 11:56:35 --> Router Class Initialized
INFO - 2018-03-26 11:56:35 --> Output Class Initialized
INFO - 2018-03-26 11:56:35 --> Security Class Initialized
DEBUG - 2018-03-26 11:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:56:35 --> Input Class Initialized
INFO - 2018-03-26 11:56:35 --> Language Class Initialized
INFO - 2018-03-26 11:56:35 --> Loader Class Initialized
INFO - 2018-03-26 11:56:35 --> Helper loaded: url_helper
INFO - 2018-03-26 11:56:35 --> Helper loaded: form_helper
INFO - 2018-03-26 11:56:35 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:56:35 --> Controller Class Initialized
INFO - 2018-03-26 11:56:35 --> Model Class Initialized
INFO - 2018-03-26 11:56:35 --> Model Class Initialized
INFO - 2018-03-26 11:56:35 --> Model Class Initialized
INFO - 2018-03-26 11:56:35 --> Model Class Initialized
INFO - 2018-03-26 11:56:35 --> Model Class Initialized
INFO - 2018-03-26 11:56:35 --> Model Class Initialized
INFO - 2018-03-26 11:56:35 --> Model Class Initialized
INFO - 2018-03-26 11:56:35 --> Helper loaded: date_helper
INFO - 2018-03-26 11:56:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:56:35 --> Model Class Initialized
INFO - 2018-03-26 16:56:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:56:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:56:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-26 16:56:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:56:35 --> Final output sent to browser
DEBUG - 2018-03-26 16:56:35 --> Total execution time: 0.1776
INFO - 2018-03-26 11:56:44 --> Config Class Initialized
INFO - 2018-03-26 11:56:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:56:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:56:44 --> Utf8 Class Initialized
INFO - 2018-03-26 11:56:44 --> URI Class Initialized
INFO - 2018-03-26 11:56:44 --> Router Class Initialized
INFO - 2018-03-26 11:56:44 --> Output Class Initialized
INFO - 2018-03-26 11:56:44 --> Security Class Initialized
DEBUG - 2018-03-26 11:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:56:44 --> Input Class Initialized
INFO - 2018-03-26 11:56:44 --> Language Class Initialized
INFO - 2018-03-26 11:56:44 --> Loader Class Initialized
INFO - 2018-03-26 11:56:44 --> Helper loaded: url_helper
INFO - 2018-03-26 11:56:44 --> Helper loaded: form_helper
INFO - 2018-03-26 11:56:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:56:44 --> Controller Class Initialized
INFO - 2018-03-26 11:56:44 --> Model Class Initialized
INFO - 2018-03-26 11:56:44 --> Model Class Initialized
INFO - 2018-03-26 11:56:44 --> Model Class Initialized
INFO - 2018-03-26 11:56:44 --> Model Class Initialized
INFO - 2018-03-26 11:56:44 --> Model Class Initialized
INFO - 2018-03-26 11:56:44 --> Model Class Initialized
INFO - 2018-03-26 11:56:44 --> Model Class Initialized
INFO - 2018-03-26 11:56:44 --> Helper loaded: date_helper
INFO - 2018-03-26 11:56:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:56:44 --> Model Class Initialized
INFO - 2018-03-26 16:56:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:56:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:56:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-26 16:56:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:56:44 --> Final output sent to browser
DEBUG - 2018-03-26 16:56:44 --> Total execution time: 0.0934
INFO - 2018-03-26 11:56:46 --> Config Class Initialized
INFO - 2018-03-26 11:56:46 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:56:46 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:56:46 --> Utf8 Class Initialized
INFO - 2018-03-26 11:56:46 --> URI Class Initialized
INFO - 2018-03-26 11:56:46 --> Router Class Initialized
INFO - 2018-03-26 11:56:46 --> Output Class Initialized
INFO - 2018-03-26 11:56:46 --> Security Class Initialized
DEBUG - 2018-03-26 11:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:56:46 --> Input Class Initialized
INFO - 2018-03-26 11:56:46 --> Language Class Initialized
INFO - 2018-03-26 11:56:46 --> Loader Class Initialized
INFO - 2018-03-26 11:56:46 --> Helper loaded: url_helper
INFO - 2018-03-26 11:56:46 --> Helper loaded: form_helper
INFO - 2018-03-26 11:56:46 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:56:46 --> Controller Class Initialized
INFO - 2018-03-26 11:56:46 --> Model Class Initialized
INFO - 2018-03-26 11:56:46 --> Model Class Initialized
INFO - 2018-03-26 11:56:46 --> Model Class Initialized
INFO - 2018-03-26 11:56:46 --> Model Class Initialized
INFO - 2018-03-26 11:56:46 --> Model Class Initialized
INFO - 2018-03-26 11:56:46 --> Model Class Initialized
INFO - 2018-03-26 11:56:46 --> Model Class Initialized
INFO - 2018-03-26 11:56:46 --> Helper loaded: date_helper
INFO - 2018-03-26 11:56:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:56:46 --> Model Class Initialized
INFO - 2018-03-26 16:56:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:56:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:56:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-26 16:56:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:56:46 --> Final output sent to browser
DEBUG - 2018-03-26 16:56:46 --> Total execution time: 0.0934
INFO - 2018-03-26 11:57:11 --> Config Class Initialized
INFO - 2018-03-26 11:57:11 --> Hooks Class Initialized
DEBUG - 2018-03-26 11:57:11 --> UTF-8 Support Enabled
INFO - 2018-03-26 11:57:11 --> Utf8 Class Initialized
INFO - 2018-03-26 11:57:11 --> URI Class Initialized
INFO - 2018-03-26 11:57:11 --> Router Class Initialized
INFO - 2018-03-26 11:57:11 --> Output Class Initialized
INFO - 2018-03-26 11:57:11 --> Security Class Initialized
DEBUG - 2018-03-26 11:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 11:57:11 --> Input Class Initialized
INFO - 2018-03-26 11:57:11 --> Language Class Initialized
INFO - 2018-03-26 11:57:11 --> Loader Class Initialized
INFO - 2018-03-26 11:57:11 --> Helper loaded: url_helper
INFO - 2018-03-26 11:57:11 --> Helper loaded: form_helper
INFO - 2018-03-26 11:57:11 --> Database Driver Class Initialized
DEBUG - 2018-03-26 11:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 11:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 11:57:11 --> Controller Class Initialized
INFO - 2018-03-26 11:57:11 --> Model Class Initialized
INFO - 2018-03-26 11:57:11 --> Model Class Initialized
INFO - 2018-03-26 11:57:11 --> Model Class Initialized
INFO - 2018-03-26 11:57:11 --> Model Class Initialized
INFO - 2018-03-26 11:57:11 --> Model Class Initialized
INFO - 2018-03-26 11:57:11 --> Model Class Initialized
INFO - 2018-03-26 11:57:11 --> Model Class Initialized
INFO - 2018-03-26 11:57:11 --> Helper loaded: date_helper
INFO - 2018-03-26 11:57:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 16:57:11 --> Model Class Initialized
INFO - 2018-03-26 16:57:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 16:57:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 16:57:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-26 16:57:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 16:57:11 --> Final output sent to browser
DEBUG - 2018-03-26 16:57:11 --> Total execution time: 0.0908
INFO - 2018-03-26 15:05:46 --> Config Class Initialized
INFO - 2018-03-26 15:05:46 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:05:46 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:05:46 --> Utf8 Class Initialized
INFO - 2018-03-26 15:05:46 --> URI Class Initialized
INFO - 2018-03-26 15:05:46 --> Router Class Initialized
INFO - 2018-03-26 15:05:46 --> Output Class Initialized
INFO - 2018-03-26 15:05:46 --> Security Class Initialized
DEBUG - 2018-03-26 15:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:05:46 --> Input Class Initialized
INFO - 2018-03-26 15:05:46 --> Language Class Initialized
INFO - 2018-03-26 15:05:46 --> Loader Class Initialized
INFO - 2018-03-26 15:05:46 --> Helper loaded: url_helper
INFO - 2018-03-26 15:05:46 --> Helper loaded: form_helper
INFO - 2018-03-26 15:05:46 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:05:46 --> Controller Class Initialized
INFO - 2018-03-26 15:05:46 --> Config Class Initialized
INFO - 2018-03-26 15:05:46 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:05:46 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:05:46 --> Utf8 Class Initialized
INFO - 2018-03-26 15:05:46 --> URI Class Initialized
INFO - 2018-03-26 15:05:46 --> Router Class Initialized
INFO - 2018-03-26 15:05:46 --> Output Class Initialized
INFO - 2018-03-26 15:05:46 --> Security Class Initialized
DEBUG - 2018-03-26 15:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:05:46 --> Input Class Initialized
INFO - 2018-03-26 15:05:46 --> Language Class Initialized
INFO - 2018-03-26 15:05:46 --> Loader Class Initialized
INFO - 2018-03-26 15:05:46 --> Helper loaded: url_helper
INFO - 2018-03-26 15:05:46 --> Helper loaded: form_helper
INFO - 2018-03-26 15:05:46 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:05:46 --> Controller Class Initialized
INFO - 2018-03-26 15:05:46 --> Model Class Initialized
INFO - 2018-03-26 15:05:46 --> Model Class Initialized
INFO - 2018-03-26 15:05:46 --> Model Class Initialized
INFO - 2018-03-26 15:05:46 --> Helper loaded: date_helper
INFO - 2018-03-26 20:05:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-26 20:05:46 --> Final output sent to browser
DEBUG - 2018-03-26 20:05:46 --> Total execution time: 0.0880
INFO - 2018-03-26 15:05:52 --> Config Class Initialized
INFO - 2018-03-26 15:05:52 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:05:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:05:53 --> Utf8 Class Initialized
INFO - 2018-03-26 15:05:53 --> URI Class Initialized
INFO - 2018-03-26 15:05:53 --> Router Class Initialized
INFO - 2018-03-26 15:05:53 --> Output Class Initialized
INFO - 2018-03-26 15:05:53 --> Security Class Initialized
DEBUG - 2018-03-26 15:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:05:53 --> Input Class Initialized
INFO - 2018-03-26 15:05:53 --> Language Class Initialized
INFO - 2018-03-26 15:05:53 --> Loader Class Initialized
INFO - 2018-03-26 15:05:53 --> Helper loaded: url_helper
INFO - 2018-03-26 15:05:53 --> Helper loaded: form_helper
INFO - 2018-03-26 15:05:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:05:53 --> Controller Class Initialized
INFO - 2018-03-26 15:05:53 --> Model Class Initialized
INFO - 2018-03-26 15:05:53 --> Model Class Initialized
INFO - 2018-03-26 15:05:53 --> Model Class Initialized
INFO - 2018-03-26 15:05:53 --> Helper loaded: date_helper
INFO - 2018-03-26 15:05:53 --> Config Class Initialized
INFO - 2018-03-26 15:05:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:05:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:05:53 --> Utf8 Class Initialized
INFO - 2018-03-26 15:05:53 --> URI Class Initialized
INFO - 2018-03-26 15:05:53 --> Router Class Initialized
INFO - 2018-03-26 15:05:53 --> Output Class Initialized
INFO - 2018-03-26 15:05:53 --> Security Class Initialized
DEBUG - 2018-03-26 15:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:05:53 --> Input Class Initialized
INFO - 2018-03-26 15:05:53 --> Language Class Initialized
INFO - 2018-03-26 15:05:53 --> Loader Class Initialized
INFO - 2018-03-26 15:05:53 --> Helper loaded: url_helper
INFO - 2018-03-26 15:05:53 --> Helper loaded: form_helper
INFO - 2018-03-26 15:05:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:05:53 --> Controller Class Initialized
INFO - 2018-03-26 15:05:53 --> Model Class Initialized
INFO - 2018-03-26 15:05:53 --> Model Class Initialized
INFO - 2018-03-26 15:05:53 --> Model Class Initialized
INFO - 2018-03-26 15:05:53 --> Model Class Initialized
INFO - 2018-03-26 15:05:53 --> Model Class Initialized
INFO - 2018-03-26 15:05:53 --> Helper loaded: date_helper
INFO - 2018-03-26 20:05:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:05:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:05:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 20:05:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:05:53 --> Final output sent to browser
DEBUG - 2018-03-26 20:05:53 --> Total execution time: 0.1130
INFO - 2018-03-26 15:05:56 --> Config Class Initialized
INFO - 2018-03-26 15:05:56 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:05:56 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:05:56 --> Utf8 Class Initialized
INFO - 2018-03-26 15:05:56 --> URI Class Initialized
INFO - 2018-03-26 15:05:56 --> Router Class Initialized
INFO - 2018-03-26 15:05:56 --> Output Class Initialized
INFO - 2018-03-26 15:05:56 --> Security Class Initialized
DEBUG - 2018-03-26 15:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:05:56 --> Input Class Initialized
INFO - 2018-03-26 15:05:56 --> Language Class Initialized
INFO - 2018-03-26 15:05:56 --> Loader Class Initialized
INFO - 2018-03-26 15:05:56 --> Helper loaded: url_helper
INFO - 2018-03-26 15:05:56 --> Helper loaded: form_helper
INFO - 2018-03-26 15:05:56 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:05:56 --> Controller Class Initialized
INFO - 2018-03-26 15:05:56 --> Model Class Initialized
INFO - 2018-03-26 15:05:56 --> Model Class Initialized
INFO - 2018-03-26 15:05:56 --> Model Class Initialized
INFO - 2018-03-26 15:05:56 --> Model Class Initialized
INFO - 2018-03-26 15:05:56 --> Model Class Initialized
INFO - 2018-03-26 15:05:56 --> Model Class Initialized
INFO - 2018-03-26 15:05:56 --> Model Class Initialized
INFO - 2018-03-26 15:05:56 --> Model Class Initialized
INFO - 2018-03-26 15:05:56 --> Model Class Initialized
INFO - 2018-03-26 15:05:56 --> Model Class Initialized
INFO - 2018-03-26 15:05:56 --> Model Class Initialized
INFO - 2018-03-26 15:05:56 --> Model Class Initialized
INFO - 2018-03-26 15:05:56 --> Helper loaded: date_helper
INFO - 2018-03-26 15:05:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:05:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:05:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:05:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-26 20:05:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:05:56 --> Final output sent to browser
DEBUG - 2018-03-26 20:05:56 --> Total execution time: 0.1214
INFO - 2018-03-26 15:07:03 --> Config Class Initialized
INFO - 2018-03-26 15:07:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:07:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:07:03 --> Utf8 Class Initialized
INFO - 2018-03-26 15:07:03 --> URI Class Initialized
INFO - 2018-03-26 15:07:03 --> Router Class Initialized
INFO - 2018-03-26 15:07:03 --> Output Class Initialized
INFO - 2018-03-26 15:07:03 --> Security Class Initialized
DEBUG - 2018-03-26 15:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:07:03 --> Input Class Initialized
INFO - 2018-03-26 15:07:03 --> Language Class Initialized
INFO - 2018-03-26 15:07:03 --> Loader Class Initialized
INFO - 2018-03-26 15:07:03 --> Helper loaded: url_helper
INFO - 2018-03-26 15:07:03 --> Helper loaded: form_helper
INFO - 2018-03-26 15:07:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:07:03 --> Controller Class Initialized
INFO - 2018-03-26 15:07:03 --> Model Class Initialized
INFO - 2018-03-26 15:07:03 --> Model Class Initialized
INFO - 2018-03-26 15:07:03 --> Model Class Initialized
INFO - 2018-03-26 15:07:03 --> Model Class Initialized
INFO - 2018-03-26 15:07:03 --> Model Class Initialized
INFO - 2018-03-26 15:07:03 --> Helper loaded: date_helper
INFO - 2018-03-26 20:07:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:07:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:07:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 20:07:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:07:03 --> Final output sent to browser
DEBUG - 2018-03-26 20:07:03 --> Total execution time: 0.0844
INFO - 2018-03-26 15:07:07 --> Config Class Initialized
INFO - 2018-03-26 15:07:07 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:07:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:07:07 --> Utf8 Class Initialized
INFO - 2018-03-26 15:07:07 --> URI Class Initialized
INFO - 2018-03-26 15:07:07 --> Router Class Initialized
INFO - 2018-03-26 15:07:07 --> Output Class Initialized
INFO - 2018-03-26 15:07:07 --> Security Class Initialized
DEBUG - 2018-03-26 15:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:07:07 --> Input Class Initialized
INFO - 2018-03-26 15:07:07 --> Language Class Initialized
INFO - 2018-03-26 15:07:07 --> Loader Class Initialized
INFO - 2018-03-26 15:07:07 --> Helper loaded: url_helper
INFO - 2018-03-26 15:07:07 --> Helper loaded: form_helper
INFO - 2018-03-26 15:07:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:07:07 --> Controller Class Initialized
INFO - 2018-03-26 15:07:07 --> Model Class Initialized
INFO - 2018-03-26 15:07:07 --> Model Class Initialized
INFO - 2018-03-26 15:07:07 --> Model Class Initialized
INFO - 2018-03-26 15:07:07 --> Model Class Initialized
INFO - 2018-03-26 15:07:07 --> Model Class Initialized
INFO - 2018-03-26 15:07:07 --> Model Class Initialized
INFO - 2018-03-26 15:07:07 --> Model Class Initialized
INFO - 2018-03-26 15:07:07 --> Helper loaded: date_helper
INFO - 2018-03-26 15:07:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:07:07 --> Model Class Initialized
INFO - 2018-03-26 20:07:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:07:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:07:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-26 20:07:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:07:07 --> Final output sent to browser
DEBUG - 2018-03-26 20:07:07 --> Total execution time: 0.0971
INFO - 2018-03-26 15:07:09 --> Config Class Initialized
INFO - 2018-03-26 15:07:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:07:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:07:09 --> Utf8 Class Initialized
INFO - 2018-03-26 15:07:09 --> URI Class Initialized
INFO - 2018-03-26 15:07:09 --> Router Class Initialized
INFO - 2018-03-26 15:07:09 --> Output Class Initialized
INFO - 2018-03-26 15:07:09 --> Security Class Initialized
DEBUG - 2018-03-26 15:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:07:09 --> Input Class Initialized
INFO - 2018-03-26 15:07:09 --> Language Class Initialized
INFO - 2018-03-26 15:07:09 --> Loader Class Initialized
INFO - 2018-03-26 15:07:09 --> Helper loaded: url_helper
INFO - 2018-03-26 15:07:09 --> Helper loaded: form_helper
INFO - 2018-03-26 15:07:09 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:07:09 --> Controller Class Initialized
INFO - 2018-03-26 15:07:09 --> Model Class Initialized
INFO - 2018-03-26 15:07:09 --> Model Class Initialized
INFO - 2018-03-26 15:07:09 --> Model Class Initialized
INFO - 2018-03-26 15:07:09 --> Model Class Initialized
INFO - 2018-03-26 15:07:09 --> Model Class Initialized
INFO - 2018-03-26 15:07:09 --> Model Class Initialized
INFO - 2018-03-26 15:07:09 --> Model Class Initialized
INFO - 2018-03-26 15:07:09 --> Helper loaded: date_helper
INFO - 2018-03-26 15:07:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:07:09 --> Model Class Initialized
INFO - 2018-03-26 20:07:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:07:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:07:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/create.php
INFO - 2018-03-26 20:07:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:07:09 --> Final output sent to browser
DEBUG - 2018-03-26 20:07:09 --> Total execution time: 0.1231
INFO - 2018-03-26 15:07:17 --> Config Class Initialized
INFO - 2018-03-26 15:07:17 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:07:17 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:07:17 --> Utf8 Class Initialized
INFO - 2018-03-26 15:07:17 --> URI Class Initialized
INFO - 2018-03-26 15:07:17 --> Router Class Initialized
INFO - 2018-03-26 15:07:17 --> Output Class Initialized
INFO - 2018-03-26 15:07:17 --> Security Class Initialized
DEBUG - 2018-03-26 15:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:07:17 --> Input Class Initialized
INFO - 2018-03-26 15:07:17 --> Language Class Initialized
INFO - 2018-03-26 15:07:17 --> Loader Class Initialized
INFO - 2018-03-26 15:07:17 --> Helper loaded: url_helper
INFO - 2018-03-26 15:07:17 --> Helper loaded: form_helper
INFO - 2018-03-26 15:07:17 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:07:17 --> Controller Class Initialized
INFO - 2018-03-26 15:07:17 --> Model Class Initialized
INFO - 2018-03-26 15:07:17 --> Model Class Initialized
INFO - 2018-03-26 15:07:17 --> Helper loaded: date_helper
INFO - 2018-03-26 15:07:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:07:17 --> Final output sent to browser
DEBUG - 2018-03-26 20:07:17 --> Total execution time: 0.0936
INFO - 2018-03-26 15:07:25 --> Config Class Initialized
INFO - 2018-03-26 15:07:25 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:07:25 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:07:25 --> Utf8 Class Initialized
INFO - 2018-03-26 15:07:25 --> URI Class Initialized
INFO - 2018-03-26 15:07:25 --> Router Class Initialized
INFO - 2018-03-26 15:07:25 --> Output Class Initialized
INFO - 2018-03-26 15:07:25 --> Security Class Initialized
DEBUG - 2018-03-26 15:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:07:25 --> Input Class Initialized
INFO - 2018-03-26 15:07:25 --> Language Class Initialized
INFO - 2018-03-26 15:07:25 --> Loader Class Initialized
INFO - 2018-03-26 15:07:25 --> Helper loaded: url_helper
INFO - 2018-03-26 15:07:25 --> Helper loaded: form_helper
INFO - 2018-03-26 15:07:25 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:07:25 --> Controller Class Initialized
INFO - 2018-03-26 15:07:25 --> Model Class Initialized
INFO - 2018-03-26 15:07:25 --> Model Class Initialized
INFO - 2018-03-26 15:07:25 --> Helper loaded: date_helper
INFO - 2018-03-26 15:07:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:07:25 --> Final output sent to browser
DEBUG - 2018-03-26 20:07:25 --> Total execution time: 0.0819
INFO - 2018-03-26 15:07:29 --> Config Class Initialized
INFO - 2018-03-26 15:07:29 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:07:29 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:07:29 --> Utf8 Class Initialized
INFO - 2018-03-26 15:07:29 --> URI Class Initialized
INFO - 2018-03-26 15:07:29 --> Router Class Initialized
INFO - 2018-03-26 15:07:29 --> Output Class Initialized
INFO - 2018-03-26 15:07:29 --> Security Class Initialized
DEBUG - 2018-03-26 15:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:07:29 --> Input Class Initialized
INFO - 2018-03-26 15:07:29 --> Language Class Initialized
INFO - 2018-03-26 15:07:29 --> Loader Class Initialized
INFO - 2018-03-26 15:07:29 --> Helper loaded: url_helper
INFO - 2018-03-26 15:07:29 --> Helper loaded: form_helper
INFO - 2018-03-26 15:07:29 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:07:29 --> Controller Class Initialized
INFO - 2018-03-26 15:07:29 --> Model Class Initialized
INFO - 2018-03-26 15:07:29 --> Model Class Initialized
INFO - 2018-03-26 15:07:29 --> Model Class Initialized
INFO - 2018-03-26 15:07:29 --> Model Class Initialized
INFO - 2018-03-26 15:07:29 --> Model Class Initialized
INFO - 2018-03-26 15:07:29 --> Model Class Initialized
INFO - 2018-03-26 15:07:29 --> Model Class Initialized
INFO - 2018-03-26 15:07:29 --> Helper loaded: date_helper
INFO - 2018-03-26 15:07:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 15:07:30 --> Config Class Initialized
INFO - 2018-03-26 15:07:30 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:07:30 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:07:30 --> Utf8 Class Initialized
INFO - 2018-03-26 15:07:30 --> URI Class Initialized
INFO - 2018-03-26 15:07:30 --> Router Class Initialized
INFO - 2018-03-26 15:07:30 --> Output Class Initialized
INFO - 2018-03-26 15:07:30 --> Security Class Initialized
DEBUG - 2018-03-26 15:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:07:30 --> Input Class Initialized
INFO - 2018-03-26 15:07:30 --> Language Class Initialized
INFO - 2018-03-26 15:07:30 --> Loader Class Initialized
INFO - 2018-03-26 15:07:30 --> Helper loaded: url_helper
INFO - 2018-03-26 15:07:30 --> Helper loaded: form_helper
INFO - 2018-03-26 15:07:30 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:07:30 --> Controller Class Initialized
INFO - 2018-03-26 15:07:30 --> Model Class Initialized
INFO - 2018-03-26 15:07:30 --> Model Class Initialized
INFO - 2018-03-26 15:07:30 --> Model Class Initialized
INFO - 2018-03-26 15:07:30 --> Model Class Initialized
INFO - 2018-03-26 15:07:30 --> Model Class Initialized
INFO - 2018-03-26 15:07:30 --> Model Class Initialized
INFO - 2018-03-26 15:07:30 --> Model Class Initialized
INFO - 2018-03-26 15:07:30 --> Helper loaded: date_helper
INFO - 2018-03-26 15:07:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:07:30 --> Model Class Initialized
INFO - 2018-03-26 20:07:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:07:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:07:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-26 20:07:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:07:30 --> Final output sent to browser
DEBUG - 2018-03-26 20:07:30 --> Total execution time: 0.1085
INFO - 2018-03-26 15:07:34 --> Config Class Initialized
INFO - 2018-03-26 15:07:34 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:07:34 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:07:34 --> Utf8 Class Initialized
INFO - 2018-03-26 15:07:34 --> URI Class Initialized
INFO - 2018-03-26 15:07:34 --> Router Class Initialized
INFO - 2018-03-26 15:07:34 --> Output Class Initialized
INFO - 2018-03-26 15:07:34 --> Security Class Initialized
DEBUG - 2018-03-26 15:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:07:34 --> Input Class Initialized
INFO - 2018-03-26 15:07:34 --> Language Class Initialized
INFO - 2018-03-26 15:07:34 --> Loader Class Initialized
INFO - 2018-03-26 15:07:34 --> Helper loaded: url_helper
INFO - 2018-03-26 15:07:34 --> Helper loaded: form_helper
INFO - 2018-03-26 15:07:34 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:07:34 --> Controller Class Initialized
INFO - 2018-03-26 15:07:34 --> Model Class Initialized
INFO - 2018-03-26 15:07:34 --> Model Class Initialized
INFO - 2018-03-26 15:07:34 --> Model Class Initialized
INFO - 2018-03-26 15:07:34 --> Model Class Initialized
INFO - 2018-03-26 15:07:34 --> Model Class Initialized
INFO - 2018-03-26 15:07:34 --> Model Class Initialized
INFO - 2018-03-26 15:07:34 --> Model Class Initialized
INFO - 2018-03-26 15:07:34 --> Model Class Initialized
INFO - 2018-03-26 15:07:34 --> Model Class Initialized
INFO - 2018-03-26 15:07:34 --> Model Class Initialized
INFO - 2018-03-26 15:07:34 --> Model Class Initialized
INFO - 2018-03-26 15:07:34 --> Model Class Initialized
INFO - 2018-03-26 15:07:34 --> Helper loaded: date_helper
INFO - 2018-03-26 15:07:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:07:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:07:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:07:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-26 20:07:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:07:34 --> Final output sent to browser
DEBUG - 2018-03-26 20:07:34 --> Total execution time: 0.0935
INFO - 2018-03-26 15:08:00 --> Config Class Initialized
INFO - 2018-03-26 15:08:00 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:08:00 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:08:00 --> Utf8 Class Initialized
INFO - 2018-03-26 15:08:00 --> URI Class Initialized
INFO - 2018-03-26 15:08:00 --> Router Class Initialized
INFO - 2018-03-26 15:08:00 --> Output Class Initialized
INFO - 2018-03-26 15:08:00 --> Security Class Initialized
DEBUG - 2018-03-26 15:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:08:00 --> Input Class Initialized
INFO - 2018-03-26 15:08:00 --> Language Class Initialized
INFO - 2018-03-26 15:08:00 --> Loader Class Initialized
INFO - 2018-03-26 15:08:00 --> Helper loaded: url_helper
INFO - 2018-03-26 15:08:00 --> Helper loaded: form_helper
INFO - 2018-03-26 15:08:00 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:08:00 --> Controller Class Initialized
INFO - 2018-03-26 15:08:00 --> Model Class Initialized
INFO - 2018-03-26 15:08:00 --> Model Class Initialized
INFO - 2018-03-26 15:08:00 --> Model Class Initialized
INFO - 2018-03-26 15:08:00 --> Model Class Initialized
INFO - 2018-03-26 15:08:00 --> Model Class Initialized
INFO - 2018-03-26 15:08:00 --> Model Class Initialized
INFO - 2018-03-26 15:08:00 --> Model Class Initialized
INFO - 2018-03-26 15:08:00 --> Model Class Initialized
INFO - 2018-03-26 15:08:00 --> Model Class Initialized
INFO - 2018-03-26 15:08:00 --> Model Class Initialized
INFO - 2018-03-26 15:08:00 --> Model Class Initialized
INFO - 2018-03-26 15:08:00 --> Model Class Initialized
INFO - 2018-03-26 15:08:00 --> Helper loaded: date_helper
INFO - 2018-03-26 15:08:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:08:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:08:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:08:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-26 20:08:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:08:00 --> Final output sent to browser
DEBUG - 2018-03-26 20:08:00 --> Total execution time: 0.1045
INFO - 2018-03-26 15:15:40 --> Config Class Initialized
INFO - 2018-03-26 15:15:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:15:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:15:40 --> Utf8 Class Initialized
INFO - 2018-03-26 15:15:40 --> URI Class Initialized
INFO - 2018-03-26 15:15:40 --> Router Class Initialized
INFO - 2018-03-26 15:15:40 --> Output Class Initialized
INFO - 2018-03-26 15:15:40 --> Security Class Initialized
DEBUG - 2018-03-26 15:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:15:40 --> Input Class Initialized
INFO - 2018-03-26 15:15:40 --> Language Class Initialized
INFO - 2018-03-26 15:15:40 --> Loader Class Initialized
INFO - 2018-03-26 15:15:40 --> Helper loaded: url_helper
INFO - 2018-03-26 15:15:40 --> Helper loaded: form_helper
INFO - 2018-03-26 15:15:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:15:40 --> Controller Class Initialized
INFO - 2018-03-26 15:15:40 --> Model Class Initialized
INFO - 2018-03-26 15:15:40 --> Model Class Initialized
INFO - 2018-03-26 15:15:40 --> Model Class Initialized
INFO - 2018-03-26 15:15:40 --> Model Class Initialized
INFO - 2018-03-26 15:15:40 --> Model Class Initialized
INFO - 2018-03-26 15:15:40 --> Model Class Initialized
INFO - 2018-03-26 15:15:40 --> Model Class Initialized
INFO - 2018-03-26 15:15:40 --> Model Class Initialized
INFO - 2018-03-26 15:15:40 --> Model Class Initialized
INFO - 2018-03-26 15:15:40 --> Model Class Initialized
INFO - 2018-03-26 15:15:40 --> Model Class Initialized
INFO - 2018-03-26 15:15:40 --> Model Class Initialized
INFO - 2018-03-26 15:15:40 --> Helper loaded: date_helper
INFO - 2018-03-26 15:15:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:15:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:15:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:15:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-26 20:15:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:15:40 --> Final output sent to browser
DEBUG - 2018-03-26 20:15:40 --> Total execution time: 0.1080
INFO - 2018-03-26 15:15:52 --> Config Class Initialized
INFO - 2018-03-26 15:15:52 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:15:52 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:15:52 --> Utf8 Class Initialized
INFO - 2018-03-26 15:15:52 --> URI Class Initialized
INFO - 2018-03-26 15:15:52 --> Router Class Initialized
INFO - 2018-03-26 15:15:52 --> Output Class Initialized
INFO - 2018-03-26 15:15:52 --> Security Class Initialized
DEBUG - 2018-03-26 15:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:15:52 --> Input Class Initialized
INFO - 2018-03-26 15:15:52 --> Language Class Initialized
INFO - 2018-03-26 15:15:52 --> Loader Class Initialized
INFO - 2018-03-26 15:15:52 --> Helper loaded: url_helper
INFO - 2018-03-26 15:15:52 --> Helper loaded: form_helper
INFO - 2018-03-26 15:15:52 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:15:52 --> Controller Class Initialized
INFO - 2018-03-26 15:15:52 --> Model Class Initialized
INFO - 2018-03-26 15:15:52 --> Model Class Initialized
INFO - 2018-03-26 15:15:52 --> Model Class Initialized
INFO - 2018-03-26 15:15:52 --> Model Class Initialized
INFO - 2018-03-26 15:15:52 --> Model Class Initialized
INFO - 2018-03-26 15:15:52 --> Model Class Initialized
INFO - 2018-03-26 15:15:52 --> Model Class Initialized
INFO - 2018-03-26 15:15:52 --> Model Class Initialized
INFO - 2018-03-26 15:15:52 --> Model Class Initialized
INFO - 2018-03-26 15:15:52 --> Model Class Initialized
INFO - 2018-03-26 15:15:52 --> Model Class Initialized
INFO - 2018-03-26 15:15:52 --> Model Class Initialized
INFO - 2018-03-26 15:15:52 --> Helper loaded: date_helper
INFO - 2018-03-26 15:15:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:15:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:15:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:15:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-26 20:15:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:15:53 --> Final output sent to browser
DEBUG - 2018-03-26 20:15:53 --> Total execution time: 0.1036
INFO - 2018-03-26 15:16:07 --> Config Class Initialized
INFO - 2018-03-26 15:16:07 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:16:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:16:07 --> Utf8 Class Initialized
INFO - 2018-03-26 15:16:07 --> URI Class Initialized
INFO - 2018-03-26 15:16:07 --> Router Class Initialized
INFO - 2018-03-26 15:16:07 --> Output Class Initialized
INFO - 2018-03-26 15:16:07 --> Security Class Initialized
DEBUG - 2018-03-26 15:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:16:07 --> Input Class Initialized
INFO - 2018-03-26 15:16:07 --> Language Class Initialized
INFO - 2018-03-26 15:16:07 --> Loader Class Initialized
INFO - 2018-03-26 15:16:07 --> Helper loaded: url_helper
INFO - 2018-03-26 15:16:07 --> Helper loaded: form_helper
INFO - 2018-03-26 15:16:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:16:07 --> Controller Class Initialized
INFO - 2018-03-26 15:16:07 --> Model Class Initialized
INFO - 2018-03-26 15:16:07 --> Model Class Initialized
INFO - 2018-03-26 15:16:07 --> Model Class Initialized
INFO - 2018-03-26 15:16:07 --> Model Class Initialized
INFO - 2018-03-26 15:16:07 --> Model Class Initialized
INFO - 2018-03-26 15:16:07 --> Model Class Initialized
INFO - 2018-03-26 15:16:07 --> Model Class Initialized
INFO - 2018-03-26 15:16:07 --> Model Class Initialized
INFO - 2018-03-26 15:16:07 --> Model Class Initialized
INFO - 2018-03-26 15:16:07 --> Model Class Initialized
INFO - 2018-03-26 15:16:07 --> Model Class Initialized
INFO - 2018-03-26 15:16:07 --> Model Class Initialized
INFO - 2018-03-26 15:16:07 --> Helper loaded: date_helper
INFO - 2018-03-26 15:16:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:16:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/list.php
INFO - 2018-03-26 20:16:07 --> Final output sent to browser
DEBUG - 2018-03-26 20:16:07 --> Total execution time: 0.1015
INFO - 2018-03-26 15:16:08 --> Config Class Initialized
INFO - 2018-03-26 15:16:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:16:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:16:08 --> Utf8 Class Initialized
INFO - 2018-03-26 15:16:08 --> URI Class Initialized
INFO - 2018-03-26 15:16:08 --> Router Class Initialized
INFO - 2018-03-26 15:16:08 --> Output Class Initialized
INFO - 2018-03-26 15:16:08 --> Security Class Initialized
DEBUG - 2018-03-26 15:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:16:08 --> Input Class Initialized
INFO - 2018-03-26 15:16:08 --> Language Class Initialized
INFO - 2018-03-26 15:16:08 --> Loader Class Initialized
INFO - 2018-03-26 15:16:08 --> Helper loaded: url_helper
INFO - 2018-03-26 15:16:08 --> Helper loaded: form_helper
INFO - 2018-03-26 15:16:08 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:16:08 --> Controller Class Initialized
INFO - 2018-03-26 15:16:08 --> Model Class Initialized
INFO - 2018-03-26 15:16:08 --> Model Class Initialized
INFO - 2018-03-26 15:16:08 --> Model Class Initialized
INFO - 2018-03-26 15:16:08 --> Model Class Initialized
INFO - 2018-03-26 15:16:08 --> Model Class Initialized
INFO - 2018-03-26 15:16:08 --> Model Class Initialized
INFO - 2018-03-26 15:16:08 --> Model Class Initialized
INFO - 2018-03-26 15:16:08 --> Model Class Initialized
INFO - 2018-03-26 15:16:08 --> Model Class Initialized
INFO - 2018-03-26 15:16:08 --> Model Class Initialized
INFO - 2018-03-26 15:16:08 --> Model Class Initialized
INFO - 2018-03-26 15:16:08 --> Model Class Initialized
INFO - 2018-03-26 15:16:08 --> Helper loaded: date_helper
INFO - 2018-03-26 15:16:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:16:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/list.php
INFO - 2018-03-26 20:16:09 --> Final output sent to browser
DEBUG - 2018-03-26 20:16:09 --> Total execution time: 0.0896
INFO - 2018-03-26 15:16:10 --> Config Class Initialized
INFO - 2018-03-26 15:16:10 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:16:10 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:16:10 --> Utf8 Class Initialized
INFO - 2018-03-26 15:16:10 --> URI Class Initialized
INFO - 2018-03-26 15:16:10 --> Router Class Initialized
INFO - 2018-03-26 15:16:10 --> Output Class Initialized
INFO - 2018-03-26 15:16:10 --> Security Class Initialized
DEBUG - 2018-03-26 15:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:16:10 --> Input Class Initialized
INFO - 2018-03-26 15:16:10 --> Language Class Initialized
INFO - 2018-03-26 15:16:10 --> Loader Class Initialized
INFO - 2018-03-26 15:16:10 --> Helper loaded: url_helper
INFO - 2018-03-26 15:16:10 --> Helper loaded: form_helper
INFO - 2018-03-26 15:16:10 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:16:10 --> Controller Class Initialized
INFO - 2018-03-26 15:16:10 --> Model Class Initialized
INFO - 2018-03-26 15:16:10 --> Model Class Initialized
INFO - 2018-03-26 15:16:10 --> Model Class Initialized
INFO - 2018-03-26 15:16:10 --> Model Class Initialized
INFO - 2018-03-26 15:16:10 --> Model Class Initialized
INFO - 2018-03-26 15:16:10 --> Model Class Initialized
INFO - 2018-03-26 15:16:10 --> Model Class Initialized
INFO - 2018-03-26 15:16:10 --> Model Class Initialized
INFO - 2018-03-26 15:16:10 --> Model Class Initialized
INFO - 2018-03-26 15:16:10 --> Model Class Initialized
INFO - 2018-03-26 15:16:10 --> Model Class Initialized
INFO - 2018-03-26 15:16:10 --> Model Class Initialized
INFO - 2018-03-26 15:16:10 --> Helper loaded: date_helper
INFO - 2018-03-26 15:16:10 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:16:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:16:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:16:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-26 20:16:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:16:10 --> Final output sent to browser
DEBUG - 2018-03-26 20:16:10 --> Total execution time: 0.1060
INFO - 2018-03-26 15:16:14 --> Config Class Initialized
INFO - 2018-03-26 15:16:14 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:16:14 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:16:14 --> Utf8 Class Initialized
INFO - 2018-03-26 15:16:14 --> URI Class Initialized
INFO - 2018-03-26 15:16:14 --> Router Class Initialized
INFO - 2018-03-26 15:16:14 --> Output Class Initialized
INFO - 2018-03-26 15:16:14 --> Security Class Initialized
DEBUG - 2018-03-26 15:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:16:14 --> Input Class Initialized
INFO - 2018-03-26 15:16:14 --> Language Class Initialized
INFO - 2018-03-26 15:16:14 --> Loader Class Initialized
INFO - 2018-03-26 15:16:14 --> Helper loaded: url_helper
INFO - 2018-03-26 15:16:14 --> Helper loaded: form_helper
INFO - 2018-03-26 15:16:14 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:16:15 --> Controller Class Initialized
INFO - 2018-03-26 15:16:15 --> Model Class Initialized
INFO - 2018-03-26 15:16:15 --> Model Class Initialized
INFO - 2018-03-26 15:16:15 --> Model Class Initialized
INFO - 2018-03-26 15:16:15 --> Model Class Initialized
INFO - 2018-03-26 15:16:15 --> Model Class Initialized
INFO - 2018-03-26 15:16:15 --> Model Class Initialized
INFO - 2018-03-26 15:16:15 --> Model Class Initialized
INFO - 2018-03-26 15:16:15 --> Model Class Initialized
INFO - 2018-03-26 15:16:15 --> Model Class Initialized
INFO - 2018-03-26 15:16:15 --> Model Class Initialized
INFO - 2018-03-26 15:16:15 --> Model Class Initialized
INFO - 2018-03-26 15:16:15 --> Model Class Initialized
INFO - 2018-03-26 15:16:15 --> Helper loaded: date_helper
INFO - 2018-03-26 15:16:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:16:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/list.php
INFO - 2018-03-26 20:16:15 --> Final output sent to browser
DEBUG - 2018-03-26 20:16:15 --> Total execution time: 0.1042
INFO - 2018-03-26 15:16:16 --> Config Class Initialized
INFO - 2018-03-26 15:16:16 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:16:16 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:16:16 --> Utf8 Class Initialized
INFO - 2018-03-26 15:16:16 --> URI Class Initialized
INFO - 2018-03-26 15:16:16 --> Router Class Initialized
INFO - 2018-03-26 15:16:16 --> Output Class Initialized
INFO - 2018-03-26 15:16:16 --> Security Class Initialized
DEBUG - 2018-03-26 15:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:16:16 --> Input Class Initialized
INFO - 2018-03-26 15:16:16 --> Language Class Initialized
INFO - 2018-03-26 15:16:16 --> Loader Class Initialized
INFO - 2018-03-26 15:16:16 --> Helper loaded: url_helper
INFO - 2018-03-26 15:16:16 --> Helper loaded: form_helper
INFO - 2018-03-26 15:16:16 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:16:16 --> Controller Class Initialized
INFO - 2018-03-26 15:16:16 --> Model Class Initialized
INFO - 2018-03-26 15:16:16 --> Model Class Initialized
INFO - 2018-03-26 15:16:16 --> Model Class Initialized
INFO - 2018-03-26 15:16:16 --> Model Class Initialized
INFO - 2018-03-26 15:16:16 --> Model Class Initialized
INFO - 2018-03-26 15:16:16 --> Model Class Initialized
INFO - 2018-03-26 15:16:16 --> Model Class Initialized
INFO - 2018-03-26 15:16:16 --> Model Class Initialized
INFO - 2018-03-26 15:16:16 --> Model Class Initialized
INFO - 2018-03-26 15:16:16 --> Model Class Initialized
INFO - 2018-03-26 15:16:16 --> Model Class Initialized
INFO - 2018-03-26 15:16:16 --> Model Class Initialized
INFO - 2018-03-26 15:16:16 --> Helper loaded: date_helper
INFO - 2018-03-26 15:16:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:16:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/list.php
INFO - 2018-03-26 20:16:16 --> Final output sent to browser
DEBUG - 2018-03-26 20:16:16 --> Total execution time: 0.0853
INFO - 2018-03-26 15:16:19 --> Config Class Initialized
INFO - 2018-03-26 15:16:19 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:16:19 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:16:19 --> Utf8 Class Initialized
INFO - 2018-03-26 15:16:19 --> URI Class Initialized
INFO - 2018-03-26 15:16:19 --> Router Class Initialized
INFO - 2018-03-26 15:16:19 --> Output Class Initialized
INFO - 2018-03-26 15:16:19 --> Security Class Initialized
DEBUG - 2018-03-26 15:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:16:19 --> Input Class Initialized
INFO - 2018-03-26 15:16:19 --> Language Class Initialized
INFO - 2018-03-26 15:16:19 --> Loader Class Initialized
INFO - 2018-03-26 15:16:19 --> Helper loaded: url_helper
INFO - 2018-03-26 15:16:19 --> Helper loaded: form_helper
INFO - 2018-03-26 15:16:19 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:16:19 --> Controller Class Initialized
INFO - 2018-03-26 15:16:19 --> Model Class Initialized
INFO - 2018-03-26 15:16:19 --> Model Class Initialized
INFO - 2018-03-26 15:16:19 --> Model Class Initialized
INFO - 2018-03-26 15:16:19 --> Model Class Initialized
INFO - 2018-03-26 15:16:19 --> Model Class Initialized
INFO - 2018-03-26 15:16:19 --> Model Class Initialized
INFO - 2018-03-26 15:16:19 --> Model Class Initialized
INFO - 2018-03-26 15:16:19 --> Model Class Initialized
INFO - 2018-03-26 15:16:19 --> Model Class Initialized
INFO - 2018-03-26 15:16:19 --> Model Class Initialized
INFO - 2018-03-26 15:16:19 --> Model Class Initialized
INFO - 2018-03-26 15:16:19 --> Model Class Initialized
INFO - 2018-03-26 15:16:19 --> Helper loaded: date_helper
INFO - 2018-03-26 15:16:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:16:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/list.php
INFO - 2018-03-26 20:16:19 --> Final output sent to browser
DEBUG - 2018-03-26 20:16:19 --> Total execution time: 0.0909
INFO - 2018-03-26 15:16:29 --> Config Class Initialized
INFO - 2018-03-26 15:16:29 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:16:29 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:16:29 --> Utf8 Class Initialized
INFO - 2018-03-26 15:16:29 --> URI Class Initialized
INFO - 2018-03-26 15:16:29 --> Router Class Initialized
INFO - 2018-03-26 15:16:29 --> Output Class Initialized
INFO - 2018-03-26 15:16:29 --> Security Class Initialized
DEBUG - 2018-03-26 15:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:16:29 --> Input Class Initialized
INFO - 2018-03-26 15:16:29 --> Language Class Initialized
INFO - 2018-03-26 15:16:29 --> Loader Class Initialized
INFO - 2018-03-26 15:16:29 --> Helper loaded: url_helper
INFO - 2018-03-26 15:16:29 --> Helper loaded: form_helper
INFO - 2018-03-26 15:16:29 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:16:29 --> Controller Class Initialized
INFO - 2018-03-26 15:16:29 --> Model Class Initialized
INFO - 2018-03-26 15:16:29 --> Model Class Initialized
INFO - 2018-03-26 15:16:29 --> Model Class Initialized
INFO - 2018-03-26 15:16:29 --> Model Class Initialized
INFO - 2018-03-26 15:16:29 --> Model Class Initialized
INFO - 2018-03-26 15:16:29 --> Model Class Initialized
INFO - 2018-03-26 15:16:29 --> Model Class Initialized
INFO - 2018-03-26 15:16:29 --> Model Class Initialized
INFO - 2018-03-26 15:16:29 --> Model Class Initialized
INFO - 2018-03-26 15:16:29 --> Model Class Initialized
INFO - 2018-03-26 15:16:29 --> Model Class Initialized
INFO - 2018-03-26 15:16:29 --> Model Class Initialized
INFO - 2018-03-26 15:16:29 --> Helper loaded: date_helper
INFO - 2018-03-26 15:16:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:16:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:16:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:16:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-26 20:16:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:16:29 --> Final output sent to browser
DEBUG - 2018-03-26 20:16:29 --> Total execution time: 0.1335
INFO - 2018-03-26 15:16:34 --> Config Class Initialized
INFO - 2018-03-26 15:16:34 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:16:34 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:16:34 --> Utf8 Class Initialized
INFO - 2018-03-26 15:16:34 --> URI Class Initialized
INFO - 2018-03-26 15:16:34 --> Router Class Initialized
INFO - 2018-03-26 15:16:34 --> Output Class Initialized
INFO - 2018-03-26 15:16:34 --> Security Class Initialized
DEBUG - 2018-03-26 15:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:16:34 --> Input Class Initialized
INFO - 2018-03-26 15:16:34 --> Language Class Initialized
INFO - 2018-03-26 15:16:34 --> Loader Class Initialized
INFO - 2018-03-26 15:16:34 --> Helper loaded: url_helper
INFO - 2018-03-26 15:16:34 --> Helper loaded: form_helper
INFO - 2018-03-26 15:16:34 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:16:34 --> Controller Class Initialized
INFO - 2018-03-26 15:16:34 --> Model Class Initialized
INFO - 2018-03-26 15:16:34 --> Model Class Initialized
INFO - 2018-03-26 15:16:34 --> Model Class Initialized
INFO - 2018-03-26 15:16:34 --> Model Class Initialized
INFO - 2018-03-26 15:16:34 --> Model Class Initialized
INFO - 2018-03-26 15:16:34 --> Model Class Initialized
INFO - 2018-03-26 15:16:34 --> Model Class Initialized
INFO - 2018-03-26 15:16:34 --> Model Class Initialized
INFO - 2018-03-26 15:16:34 --> Model Class Initialized
INFO - 2018-03-26 15:16:34 --> Model Class Initialized
INFO - 2018-03-26 15:16:34 --> Model Class Initialized
INFO - 2018-03-26 15:16:34 --> Model Class Initialized
INFO - 2018-03-26 15:16:34 --> Helper loaded: date_helper
INFO - 2018-03-26 15:16:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:16:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/list.php
INFO - 2018-03-26 20:16:34 --> Final output sent to browser
DEBUG - 2018-03-26 20:16:34 --> Total execution time: 0.1004
INFO - 2018-03-26 15:25:01 --> Config Class Initialized
INFO - 2018-03-26 15:25:01 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:25:01 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:25:01 --> Utf8 Class Initialized
INFO - 2018-03-26 15:25:01 --> URI Class Initialized
INFO - 2018-03-26 15:25:01 --> Router Class Initialized
INFO - 2018-03-26 15:25:01 --> Output Class Initialized
INFO - 2018-03-26 15:25:01 --> Security Class Initialized
DEBUG - 2018-03-26 15:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:25:01 --> Input Class Initialized
INFO - 2018-03-26 15:25:01 --> Language Class Initialized
INFO - 2018-03-26 15:25:01 --> Loader Class Initialized
INFO - 2018-03-26 15:25:01 --> Helper loaded: url_helper
INFO - 2018-03-26 15:25:01 --> Helper loaded: form_helper
INFO - 2018-03-26 15:25:01 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:25:01 --> Controller Class Initialized
INFO - 2018-03-26 15:25:01 --> Model Class Initialized
INFO - 2018-03-26 15:25:01 --> Model Class Initialized
INFO - 2018-03-26 15:25:01 --> Model Class Initialized
INFO - 2018-03-26 15:25:01 --> Model Class Initialized
INFO - 2018-03-26 15:25:01 --> Model Class Initialized
INFO - 2018-03-26 15:25:01 --> Model Class Initialized
INFO - 2018-03-26 15:25:01 --> Model Class Initialized
INFO - 2018-03-26 15:25:01 --> Model Class Initialized
INFO - 2018-03-26 15:25:01 --> Model Class Initialized
INFO - 2018-03-26 15:25:01 --> Model Class Initialized
INFO - 2018-03-26 15:25:01 --> Model Class Initialized
INFO - 2018-03-26 15:25:01 --> Model Class Initialized
INFO - 2018-03-26 15:25:01 --> Helper loaded: date_helper
INFO - 2018-03-26 15:25:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:25:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:25:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:25:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-26 20:25:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:25:01 --> Final output sent to browser
DEBUG - 2018-03-26 20:25:01 --> Total execution time: 0.1042
INFO - 2018-03-26 15:25:03 --> Config Class Initialized
INFO - 2018-03-26 15:25:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:25:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:25:03 --> Utf8 Class Initialized
INFO - 2018-03-26 15:25:03 --> URI Class Initialized
INFO - 2018-03-26 15:25:03 --> Router Class Initialized
INFO - 2018-03-26 15:25:03 --> Output Class Initialized
INFO - 2018-03-26 15:25:03 --> Security Class Initialized
DEBUG - 2018-03-26 15:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:25:03 --> Input Class Initialized
INFO - 2018-03-26 15:25:03 --> Language Class Initialized
INFO - 2018-03-26 15:25:03 --> Loader Class Initialized
INFO - 2018-03-26 15:25:03 --> Helper loaded: url_helper
INFO - 2018-03-26 15:25:03 --> Helper loaded: form_helper
INFO - 2018-03-26 15:25:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:25:03 --> Controller Class Initialized
INFO - 2018-03-26 15:25:03 --> Model Class Initialized
INFO - 2018-03-26 15:25:03 --> Model Class Initialized
INFO - 2018-03-26 15:25:03 --> Model Class Initialized
INFO - 2018-03-26 15:25:03 --> Model Class Initialized
INFO - 2018-03-26 15:25:03 --> Model Class Initialized
INFO - 2018-03-26 15:25:03 --> Model Class Initialized
INFO - 2018-03-26 15:25:03 --> Model Class Initialized
INFO - 2018-03-26 15:25:03 --> Model Class Initialized
INFO - 2018-03-26 15:25:03 --> Model Class Initialized
INFO - 2018-03-26 15:25:03 --> Model Class Initialized
INFO - 2018-03-26 15:25:03 --> Model Class Initialized
INFO - 2018-03-26 15:25:03 --> Model Class Initialized
INFO - 2018-03-26 15:25:03 --> Helper loaded: date_helper
INFO - 2018-03-26 15:25:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:25:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:25:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:25:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-26 20:25:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:25:03 --> Final output sent to browser
DEBUG - 2018-03-26 20:25:03 --> Total execution time: 0.1195
INFO - 2018-03-26 15:33:09 --> Config Class Initialized
INFO - 2018-03-26 15:33:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:33:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:33:09 --> Utf8 Class Initialized
INFO - 2018-03-26 15:33:09 --> URI Class Initialized
INFO - 2018-03-26 15:33:09 --> Router Class Initialized
INFO - 2018-03-26 15:33:09 --> Output Class Initialized
INFO - 2018-03-26 15:33:09 --> Security Class Initialized
DEBUG - 2018-03-26 15:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:33:09 --> Input Class Initialized
INFO - 2018-03-26 15:33:09 --> Language Class Initialized
INFO - 2018-03-26 15:33:09 --> Loader Class Initialized
INFO - 2018-03-26 15:33:09 --> Helper loaded: url_helper
INFO - 2018-03-26 15:33:09 --> Helper loaded: form_helper
INFO - 2018-03-26 15:33:09 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:33:09 --> Controller Class Initialized
INFO - 2018-03-26 15:33:09 --> Model Class Initialized
INFO - 2018-03-26 15:33:09 --> Model Class Initialized
INFO - 2018-03-26 15:33:09 --> Model Class Initialized
INFO - 2018-03-26 15:33:09 --> Model Class Initialized
INFO - 2018-03-26 15:33:09 --> Model Class Initialized
INFO - 2018-03-26 15:33:09 --> Model Class Initialized
INFO - 2018-03-26 15:33:09 --> Model Class Initialized
INFO - 2018-03-26 15:33:09 --> Model Class Initialized
INFO - 2018-03-26 15:33:09 --> Model Class Initialized
INFO - 2018-03-26 15:33:09 --> Model Class Initialized
INFO - 2018-03-26 15:33:09 --> Model Class Initialized
INFO - 2018-03-26 15:33:09 --> Model Class Initialized
INFO - 2018-03-26 15:33:09 --> Helper loaded: date_helper
INFO - 2018-03-26 15:33:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:33:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:33:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:33:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-26 20:33:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:33:09 --> Final output sent to browser
DEBUG - 2018-03-26 20:33:09 --> Total execution time: 0.1087
INFO - 2018-03-26 15:34:15 --> Config Class Initialized
INFO - 2018-03-26 15:34:15 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:34:15 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:34:15 --> Utf8 Class Initialized
INFO - 2018-03-26 15:34:15 --> URI Class Initialized
INFO - 2018-03-26 15:34:15 --> Router Class Initialized
INFO - 2018-03-26 15:34:15 --> Output Class Initialized
INFO - 2018-03-26 15:34:15 --> Security Class Initialized
DEBUG - 2018-03-26 15:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:34:15 --> Input Class Initialized
INFO - 2018-03-26 15:34:15 --> Language Class Initialized
INFO - 2018-03-26 15:34:15 --> Loader Class Initialized
INFO - 2018-03-26 15:34:15 --> Helper loaded: url_helper
INFO - 2018-03-26 15:34:15 --> Helper loaded: form_helper
INFO - 2018-03-26 15:34:15 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:34:15 --> Controller Class Initialized
INFO - 2018-03-26 15:34:15 --> Model Class Initialized
INFO - 2018-03-26 15:34:15 --> Model Class Initialized
INFO - 2018-03-26 15:34:15 --> Model Class Initialized
INFO - 2018-03-26 15:34:15 --> Model Class Initialized
INFO - 2018-03-26 15:34:15 --> Model Class Initialized
INFO - 2018-03-26 15:34:15 --> Model Class Initialized
INFO - 2018-03-26 15:34:15 --> Model Class Initialized
INFO - 2018-03-26 15:34:15 --> Model Class Initialized
INFO - 2018-03-26 15:34:15 --> Model Class Initialized
INFO - 2018-03-26 15:34:15 --> Model Class Initialized
INFO - 2018-03-26 15:34:15 --> Model Class Initialized
INFO - 2018-03-26 15:34:15 --> Model Class Initialized
INFO - 2018-03-26 15:34:15 --> Helper loaded: date_helper
INFO - 2018-03-26 15:34:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:34:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:34:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:34:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-26 20:34:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:34:15 --> Final output sent to browser
DEBUG - 2018-03-26 20:34:15 --> Total execution time: 0.1096
INFO - 2018-03-26 15:34:43 --> Config Class Initialized
INFO - 2018-03-26 15:34:43 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:34:43 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:34:43 --> Utf8 Class Initialized
INFO - 2018-03-26 15:34:43 --> URI Class Initialized
INFO - 2018-03-26 15:34:43 --> Router Class Initialized
INFO - 2018-03-26 15:34:43 --> Output Class Initialized
INFO - 2018-03-26 15:34:43 --> Security Class Initialized
DEBUG - 2018-03-26 15:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:34:43 --> Input Class Initialized
INFO - 2018-03-26 15:34:43 --> Language Class Initialized
INFO - 2018-03-26 15:34:43 --> Loader Class Initialized
INFO - 2018-03-26 15:34:43 --> Helper loaded: url_helper
INFO - 2018-03-26 15:34:43 --> Helper loaded: form_helper
INFO - 2018-03-26 15:34:43 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:34:43 --> Controller Class Initialized
INFO - 2018-03-26 15:34:43 --> Model Class Initialized
INFO - 2018-03-26 15:34:43 --> Model Class Initialized
INFO - 2018-03-26 15:34:43 --> Model Class Initialized
INFO - 2018-03-26 15:34:43 --> Model Class Initialized
INFO - 2018-03-26 15:34:43 --> Model Class Initialized
INFO - 2018-03-26 15:34:43 --> Model Class Initialized
INFO - 2018-03-26 15:34:43 --> Model Class Initialized
INFO - 2018-03-26 15:34:43 --> Model Class Initialized
INFO - 2018-03-26 15:34:43 --> Model Class Initialized
INFO - 2018-03-26 15:34:43 --> Model Class Initialized
INFO - 2018-03-26 15:34:43 --> Model Class Initialized
INFO - 2018-03-26 15:34:43 --> Model Class Initialized
INFO - 2018-03-26 15:34:43 --> Helper loaded: date_helper
INFO - 2018-03-26 15:34:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:34:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:34:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:34:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-26 20:34:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:34:43 --> Final output sent to browser
DEBUG - 2018-03-26 20:34:43 --> Total execution time: 0.1161
INFO - 2018-03-26 15:42:26 --> Config Class Initialized
INFO - 2018-03-26 15:42:26 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:42:26 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:42:26 --> Utf8 Class Initialized
INFO - 2018-03-26 15:42:26 --> URI Class Initialized
INFO - 2018-03-26 15:42:26 --> Router Class Initialized
INFO - 2018-03-26 15:42:26 --> Output Class Initialized
INFO - 2018-03-26 15:42:26 --> Security Class Initialized
DEBUG - 2018-03-26 15:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:42:26 --> Input Class Initialized
INFO - 2018-03-26 15:42:26 --> Language Class Initialized
INFO - 2018-03-26 15:42:26 --> Loader Class Initialized
INFO - 2018-03-26 15:42:26 --> Helper loaded: url_helper
INFO - 2018-03-26 15:42:26 --> Helper loaded: form_helper
INFO - 2018-03-26 15:42:26 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:42:26 --> Controller Class Initialized
INFO - 2018-03-26 15:42:26 --> Model Class Initialized
INFO - 2018-03-26 15:42:26 --> Model Class Initialized
INFO - 2018-03-26 15:42:26 --> Model Class Initialized
INFO - 2018-03-26 15:42:26 --> Model Class Initialized
INFO - 2018-03-26 15:42:26 --> Model Class Initialized
INFO - 2018-03-26 15:42:26 --> Model Class Initialized
INFO - 2018-03-26 15:42:26 --> Model Class Initialized
INFO - 2018-03-26 15:42:26 --> Model Class Initialized
INFO - 2018-03-26 15:42:26 --> Model Class Initialized
INFO - 2018-03-26 15:42:26 --> Model Class Initialized
INFO - 2018-03-26 15:42:26 --> Model Class Initialized
INFO - 2018-03-26 15:42:26 --> Model Class Initialized
INFO - 2018-03-26 15:42:26 --> Helper loaded: date_helper
INFO - 2018-03-26 15:42:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:42:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:42:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:42:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-26 20:42:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:42:26 --> Final output sent to browser
DEBUG - 2018-03-26 20:42:26 --> Total execution time: 0.1203
INFO - 2018-03-26 15:54:04 --> Config Class Initialized
INFO - 2018-03-26 15:54:04 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:54:04 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:54:04 --> Utf8 Class Initialized
INFO - 2018-03-26 15:54:04 --> URI Class Initialized
INFO - 2018-03-26 15:54:04 --> Router Class Initialized
INFO - 2018-03-26 15:54:04 --> Output Class Initialized
INFO - 2018-03-26 15:54:04 --> Security Class Initialized
DEBUG - 2018-03-26 15:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:54:04 --> Input Class Initialized
INFO - 2018-03-26 15:54:04 --> Language Class Initialized
INFO - 2018-03-26 15:54:04 --> Loader Class Initialized
INFO - 2018-03-26 15:54:04 --> Helper loaded: url_helper
INFO - 2018-03-26 15:54:04 --> Helper loaded: form_helper
INFO - 2018-03-26 15:54:04 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:54:04 --> Controller Class Initialized
INFO - 2018-03-26 15:54:04 --> Model Class Initialized
INFO - 2018-03-26 15:54:04 --> Model Class Initialized
INFO - 2018-03-26 15:54:04 --> Model Class Initialized
INFO - 2018-03-26 15:54:04 --> Model Class Initialized
INFO - 2018-03-26 15:54:04 --> Model Class Initialized
INFO - 2018-03-26 15:54:04 --> Model Class Initialized
INFO - 2018-03-26 15:54:04 --> Model Class Initialized
INFO - 2018-03-26 15:54:04 --> Model Class Initialized
INFO - 2018-03-26 15:54:04 --> Model Class Initialized
INFO - 2018-03-26 15:54:04 --> Model Class Initialized
INFO - 2018-03-26 15:54:04 --> Model Class Initialized
INFO - 2018-03-26 15:54:04 --> Model Class Initialized
INFO - 2018-03-26 15:54:04 --> Helper loaded: date_helper
INFO - 2018-03-26 15:54:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:54:04 --> Model Class Initialized
INFO - 2018-03-26 20:54:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:54:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:54:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-26 20:54:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:54:04 --> Final output sent to browser
DEBUG - 2018-03-26 20:54:04 --> Total execution time: 0.1219
INFO - 2018-03-26 15:54:45 --> Config Class Initialized
INFO - 2018-03-26 15:54:45 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:54:45 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:54:45 --> Utf8 Class Initialized
INFO - 2018-03-26 15:54:45 --> URI Class Initialized
INFO - 2018-03-26 15:54:45 --> Router Class Initialized
INFO - 2018-03-26 15:54:45 --> Output Class Initialized
INFO - 2018-03-26 15:54:45 --> Security Class Initialized
DEBUG - 2018-03-26 15:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:54:45 --> Input Class Initialized
INFO - 2018-03-26 15:54:45 --> Language Class Initialized
INFO - 2018-03-26 15:54:45 --> Loader Class Initialized
INFO - 2018-03-26 15:54:45 --> Helper loaded: url_helper
INFO - 2018-03-26 15:54:45 --> Helper loaded: form_helper
INFO - 2018-03-26 15:54:45 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:54:45 --> Controller Class Initialized
INFO - 2018-03-26 15:54:45 --> Model Class Initialized
INFO - 2018-03-26 15:54:45 --> Model Class Initialized
INFO - 2018-03-26 15:54:45 --> Model Class Initialized
INFO - 2018-03-26 15:54:45 --> Model Class Initialized
INFO - 2018-03-26 15:54:45 --> Model Class Initialized
INFO - 2018-03-26 15:54:45 --> Model Class Initialized
INFO - 2018-03-26 15:54:45 --> Model Class Initialized
INFO - 2018-03-26 15:54:45 --> Model Class Initialized
INFO - 2018-03-26 15:54:45 --> Model Class Initialized
INFO - 2018-03-26 15:54:45 --> Model Class Initialized
INFO - 2018-03-26 15:54:45 --> Model Class Initialized
INFO - 2018-03-26 15:54:45 --> Model Class Initialized
INFO - 2018-03-26 15:54:45 --> Helper loaded: date_helper
INFO - 2018-03-26 15:54:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:54:45 --> Model Class Initialized
INFO - 2018-03-26 20:54:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:54:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:54:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-26 20:54:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:54:45 --> Final output sent to browser
DEBUG - 2018-03-26 20:54:45 --> Total execution time: 0.1261
INFO - 2018-03-26 15:55:55 --> Config Class Initialized
INFO - 2018-03-26 15:55:55 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:55:55 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:55:55 --> Utf8 Class Initialized
INFO - 2018-03-26 15:55:55 --> URI Class Initialized
INFO - 2018-03-26 15:55:55 --> Router Class Initialized
INFO - 2018-03-26 15:55:55 --> Output Class Initialized
INFO - 2018-03-26 15:55:55 --> Security Class Initialized
DEBUG - 2018-03-26 15:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:55:55 --> Input Class Initialized
INFO - 2018-03-26 15:55:55 --> Language Class Initialized
INFO - 2018-03-26 15:55:55 --> Loader Class Initialized
INFO - 2018-03-26 15:55:55 --> Helper loaded: url_helper
INFO - 2018-03-26 15:55:55 --> Helper loaded: form_helper
INFO - 2018-03-26 15:55:55 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:55:55 --> Controller Class Initialized
INFO - 2018-03-26 15:55:55 --> Model Class Initialized
INFO - 2018-03-26 15:55:55 --> Model Class Initialized
INFO - 2018-03-26 15:55:55 --> Model Class Initialized
INFO - 2018-03-26 15:55:55 --> Model Class Initialized
INFO - 2018-03-26 15:55:55 --> Model Class Initialized
INFO - 2018-03-26 15:55:55 --> Model Class Initialized
INFO - 2018-03-26 15:55:55 --> Model Class Initialized
INFO - 2018-03-26 15:55:55 --> Model Class Initialized
INFO - 2018-03-26 15:55:55 --> Model Class Initialized
INFO - 2018-03-26 15:55:55 --> Model Class Initialized
INFO - 2018-03-26 15:55:55 --> Model Class Initialized
INFO - 2018-03-26 15:55:55 --> Model Class Initialized
INFO - 2018-03-26 15:55:55 --> Helper loaded: date_helper
INFO - 2018-03-26 15:55:55 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:55:55 --> Model Class Initialized
INFO - 2018-03-26 20:55:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:55:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:55:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-26 20:55:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:55:55 --> Final output sent to browser
DEBUG - 2018-03-26 20:55:55 --> Total execution time: 0.1042
INFO - 2018-03-26 15:57:06 --> Config Class Initialized
INFO - 2018-03-26 15:57:06 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:57:06 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:57:06 --> Utf8 Class Initialized
INFO - 2018-03-26 15:57:06 --> URI Class Initialized
INFO - 2018-03-26 15:57:06 --> Router Class Initialized
INFO - 2018-03-26 15:57:06 --> Output Class Initialized
INFO - 2018-03-26 15:57:06 --> Security Class Initialized
DEBUG - 2018-03-26 15:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:57:06 --> Input Class Initialized
INFO - 2018-03-26 15:57:06 --> Language Class Initialized
INFO - 2018-03-26 15:57:06 --> Loader Class Initialized
INFO - 2018-03-26 15:57:06 --> Helper loaded: url_helper
INFO - 2018-03-26 15:57:06 --> Helper loaded: form_helper
INFO - 2018-03-26 15:57:06 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:57:06 --> Controller Class Initialized
INFO - 2018-03-26 15:57:06 --> Model Class Initialized
INFO - 2018-03-26 15:57:06 --> Model Class Initialized
INFO - 2018-03-26 15:57:06 --> Helper loaded: date_helper
INFO - 2018-03-26 15:57:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:57:06 --> Model Class Initialized
INFO - 2018-03-26 20:57:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:57:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:57:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-26 20:57:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:57:06 --> Final output sent to browser
DEBUG - 2018-03-26 20:57:06 --> Total execution time: 0.0848
INFO - 2018-03-26 15:57:32 --> Config Class Initialized
INFO - 2018-03-26 15:57:32 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:57:32 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:57:32 --> Utf8 Class Initialized
INFO - 2018-03-26 15:57:32 --> URI Class Initialized
INFO - 2018-03-26 15:57:32 --> Router Class Initialized
INFO - 2018-03-26 15:57:32 --> Output Class Initialized
INFO - 2018-03-26 15:57:32 --> Security Class Initialized
DEBUG - 2018-03-26 15:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:57:32 --> Input Class Initialized
INFO - 2018-03-26 15:57:32 --> Language Class Initialized
INFO - 2018-03-26 15:57:32 --> Loader Class Initialized
INFO - 2018-03-26 15:57:32 --> Helper loaded: url_helper
INFO - 2018-03-26 15:57:32 --> Helper loaded: form_helper
INFO - 2018-03-26 15:57:32 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:57:32 --> Controller Class Initialized
INFO - 2018-03-26 15:57:32 --> Model Class Initialized
INFO - 2018-03-26 15:57:32 --> Model Class Initialized
INFO - 2018-03-26 15:57:32 --> Helper loaded: date_helper
INFO - 2018-03-26 15:57:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:57:32 --> Model Class Initialized
INFO - 2018-03-26 20:57:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:57:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:57:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-26 20:57:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:57:32 --> Final output sent to browser
DEBUG - 2018-03-26 20:57:32 --> Total execution time: 0.1021
INFO - 2018-03-26 15:57:59 --> Config Class Initialized
INFO - 2018-03-26 15:57:59 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:57:59 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:57:59 --> Utf8 Class Initialized
INFO - 2018-03-26 15:57:59 --> URI Class Initialized
INFO - 2018-03-26 15:57:59 --> Router Class Initialized
INFO - 2018-03-26 15:57:59 --> Output Class Initialized
INFO - 2018-03-26 15:57:59 --> Security Class Initialized
DEBUG - 2018-03-26 15:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:57:59 --> Input Class Initialized
INFO - 2018-03-26 15:57:59 --> Language Class Initialized
INFO - 2018-03-26 15:57:59 --> Loader Class Initialized
INFO - 2018-03-26 15:57:59 --> Helper loaded: url_helper
INFO - 2018-03-26 15:57:59 --> Helper loaded: form_helper
INFO - 2018-03-26 15:57:59 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:57:59 --> Controller Class Initialized
INFO - 2018-03-26 15:57:59 --> Model Class Initialized
INFO - 2018-03-26 15:57:59 --> Model Class Initialized
INFO - 2018-03-26 15:57:59 --> Model Class Initialized
INFO - 2018-03-26 15:57:59 --> Model Class Initialized
INFO - 2018-03-26 15:57:59 --> Model Class Initialized
INFO - 2018-03-26 15:57:59 --> Helper loaded: date_helper
INFO - 2018-03-26 20:57:59 --> Model Class Initialized
INFO - 2018-03-26 20:57:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:57:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:57:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 20:57:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:57:59 --> Final output sent to browser
DEBUG - 2018-03-26 20:57:59 --> Total execution time: 0.1212
INFO - 2018-03-26 15:58:27 --> Config Class Initialized
INFO - 2018-03-26 15:58:27 --> Hooks Class Initialized
DEBUG - 2018-03-26 15:58:27 --> UTF-8 Support Enabled
INFO - 2018-03-26 15:58:27 --> Utf8 Class Initialized
INFO - 2018-03-26 15:58:27 --> URI Class Initialized
INFO - 2018-03-26 15:58:27 --> Router Class Initialized
INFO - 2018-03-26 15:58:27 --> Output Class Initialized
INFO - 2018-03-26 15:58:27 --> Security Class Initialized
DEBUG - 2018-03-26 15:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 15:58:27 --> Input Class Initialized
INFO - 2018-03-26 15:58:27 --> Language Class Initialized
INFO - 2018-03-26 15:58:27 --> Loader Class Initialized
INFO - 2018-03-26 15:58:27 --> Helper loaded: url_helper
INFO - 2018-03-26 15:58:27 --> Helper loaded: form_helper
INFO - 2018-03-26 15:58:27 --> Database Driver Class Initialized
DEBUG - 2018-03-26 15:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 15:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 15:58:27 --> Controller Class Initialized
INFO - 2018-03-26 15:58:27 --> Model Class Initialized
INFO - 2018-03-26 15:58:27 --> Model Class Initialized
INFO - 2018-03-26 15:58:27 --> Model Class Initialized
INFO - 2018-03-26 15:58:27 --> Model Class Initialized
INFO - 2018-03-26 15:58:27 --> Model Class Initialized
INFO - 2018-03-26 15:58:27 --> Helper loaded: date_helper
INFO - 2018-03-26 20:58:27 --> Model Class Initialized
INFO - 2018-03-26 20:58:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 20:58:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 20:58:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 20:58:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 20:58:27 --> Final output sent to browser
DEBUG - 2018-03-26 20:58:27 --> Total execution time: 0.0973
INFO - 2018-03-26 17:17:04 --> Config Class Initialized
INFO - 2018-03-26 17:17:04 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:17:04 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:17:04 --> Utf8 Class Initialized
INFO - 2018-03-26 17:17:04 --> URI Class Initialized
INFO - 2018-03-26 17:17:04 --> Router Class Initialized
INFO - 2018-03-26 17:17:04 --> Output Class Initialized
INFO - 2018-03-26 17:17:04 --> Security Class Initialized
DEBUG - 2018-03-26 17:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:17:04 --> Input Class Initialized
INFO - 2018-03-26 17:17:04 --> Language Class Initialized
INFO - 2018-03-26 17:17:04 --> Loader Class Initialized
INFO - 2018-03-26 17:17:04 --> Helper loaded: url_helper
INFO - 2018-03-26 17:17:04 --> Helper loaded: form_helper
INFO - 2018-03-26 17:17:04 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:17:04 --> Controller Class Initialized
INFO - 2018-03-26 17:17:04 --> Model Class Initialized
INFO - 2018-03-26 17:17:04 --> Model Class Initialized
INFO - 2018-03-26 17:17:04 --> Model Class Initialized
INFO - 2018-03-26 17:17:04 --> Model Class Initialized
INFO - 2018-03-26 17:17:04 --> Model Class Initialized
INFO - 2018-03-26 17:17:04 --> Helper loaded: date_helper
INFO - 2018-03-26 22:17:04 --> Model Class Initialized
INFO - 2018-03-26 22:17:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:17:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:17:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 22:17:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:17:04 --> Final output sent to browser
DEBUG - 2018-03-26 22:17:04 --> Total execution time: 0.5611
INFO - 2018-03-26 17:20:10 --> Config Class Initialized
INFO - 2018-03-26 17:20:10 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:20:10 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:20:10 --> Utf8 Class Initialized
INFO - 2018-03-26 17:20:10 --> URI Class Initialized
INFO - 2018-03-26 17:20:10 --> Router Class Initialized
INFO - 2018-03-26 17:20:10 --> Output Class Initialized
INFO - 2018-03-26 17:20:10 --> Security Class Initialized
DEBUG - 2018-03-26 17:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:20:10 --> Input Class Initialized
INFO - 2018-03-26 17:20:10 --> Language Class Initialized
INFO - 2018-03-26 17:20:10 --> Loader Class Initialized
INFO - 2018-03-26 17:20:10 --> Helper loaded: url_helper
INFO - 2018-03-26 17:20:10 --> Helper loaded: form_helper
INFO - 2018-03-26 17:20:10 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:20:10 --> Controller Class Initialized
INFO - 2018-03-26 17:20:10 --> Model Class Initialized
INFO - 2018-03-26 17:20:10 --> Model Class Initialized
INFO - 2018-03-26 17:20:10 --> Model Class Initialized
INFO - 2018-03-26 17:20:10 --> Model Class Initialized
INFO - 2018-03-26 17:20:10 --> Model Class Initialized
INFO - 2018-03-26 17:20:10 --> Helper loaded: date_helper
INFO - 2018-03-26 22:20:10 --> Model Class Initialized
INFO - 2018-03-26 22:20:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:20:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:20:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 22:20:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:20:10 --> Final output sent to browser
DEBUG - 2018-03-26 22:20:10 --> Total execution time: 0.0980
INFO - 2018-03-26 17:21:00 --> Config Class Initialized
INFO - 2018-03-26 17:21:00 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:21:00 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:21:00 --> Utf8 Class Initialized
INFO - 2018-03-26 17:21:00 --> URI Class Initialized
INFO - 2018-03-26 17:21:00 --> Router Class Initialized
INFO - 2018-03-26 17:21:00 --> Output Class Initialized
INFO - 2018-03-26 17:21:00 --> Security Class Initialized
DEBUG - 2018-03-26 17:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:21:00 --> Input Class Initialized
INFO - 2018-03-26 17:21:00 --> Language Class Initialized
INFO - 2018-03-26 17:21:00 --> Loader Class Initialized
INFO - 2018-03-26 17:21:00 --> Helper loaded: url_helper
INFO - 2018-03-26 17:21:00 --> Helper loaded: form_helper
INFO - 2018-03-26 17:21:00 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:21:00 --> Controller Class Initialized
INFO - 2018-03-26 17:21:00 --> Model Class Initialized
INFO - 2018-03-26 17:21:00 --> Model Class Initialized
INFO - 2018-03-26 17:21:00 --> Model Class Initialized
INFO - 2018-03-26 17:21:00 --> Model Class Initialized
INFO - 2018-03-26 17:21:00 --> Model Class Initialized
INFO - 2018-03-26 17:21:00 --> Helper loaded: date_helper
INFO - 2018-03-26 22:21:00 --> Model Class Initialized
INFO - 2018-03-26 22:21:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:21:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:21:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 22:21:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:21:00 --> Final output sent to browser
DEBUG - 2018-03-26 22:21:00 --> Total execution time: 0.0854
INFO - 2018-03-26 17:22:34 --> Config Class Initialized
INFO - 2018-03-26 17:22:34 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:22:34 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:22:34 --> Utf8 Class Initialized
INFO - 2018-03-26 17:22:34 --> URI Class Initialized
INFO - 2018-03-26 17:22:34 --> Router Class Initialized
INFO - 2018-03-26 17:22:34 --> Output Class Initialized
INFO - 2018-03-26 17:22:34 --> Security Class Initialized
DEBUG - 2018-03-26 17:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:22:34 --> Input Class Initialized
INFO - 2018-03-26 17:22:34 --> Language Class Initialized
INFO - 2018-03-26 17:22:34 --> Loader Class Initialized
INFO - 2018-03-26 17:22:34 --> Helper loaded: url_helper
INFO - 2018-03-26 17:22:34 --> Helper loaded: form_helper
INFO - 2018-03-26 17:22:34 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:22:34 --> Controller Class Initialized
INFO - 2018-03-26 17:22:34 --> Model Class Initialized
INFO - 2018-03-26 17:22:34 --> Model Class Initialized
INFO - 2018-03-26 17:22:34 --> Model Class Initialized
INFO - 2018-03-26 17:22:34 --> Model Class Initialized
INFO - 2018-03-26 17:22:34 --> Model Class Initialized
INFO - 2018-03-26 17:22:34 --> Helper loaded: date_helper
INFO - 2018-03-26 22:22:34 --> Model Class Initialized
INFO - 2018-03-26 22:22:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:22:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:22:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 22:22:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:22:34 --> Final output sent to browser
DEBUG - 2018-03-26 22:22:34 --> Total execution time: 0.1158
INFO - 2018-03-26 17:22:49 --> Config Class Initialized
INFO - 2018-03-26 17:22:49 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:22:49 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:22:49 --> Utf8 Class Initialized
INFO - 2018-03-26 17:22:49 --> URI Class Initialized
INFO - 2018-03-26 17:22:49 --> Router Class Initialized
INFO - 2018-03-26 17:22:49 --> Output Class Initialized
INFO - 2018-03-26 17:22:49 --> Security Class Initialized
DEBUG - 2018-03-26 17:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:22:49 --> Input Class Initialized
INFO - 2018-03-26 17:22:49 --> Language Class Initialized
INFO - 2018-03-26 17:22:49 --> Loader Class Initialized
INFO - 2018-03-26 17:22:49 --> Helper loaded: url_helper
INFO - 2018-03-26 17:22:49 --> Helper loaded: form_helper
INFO - 2018-03-26 17:22:49 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:22:49 --> Controller Class Initialized
INFO - 2018-03-26 17:22:49 --> Model Class Initialized
INFO - 2018-03-26 17:22:49 --> Model Class Initialized
INFO - 2018-03-26 17:22:49 --> Model Class Initialized
INFO - 2018-03-26 17:22:49 --> Model Class Initialized
INFO - 2018-03-26 17:22:49 --> Model Class Initialized
INFO - 2018-03-26 17:22:49 --> Helper loaded: date_helper
INFO - 2018-03-26 22:22:49 --> Model Class Initialized
INFO - 2018-03-26 22:22:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:22:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:22:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 22:22:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:22:49 --> Final output sent to browser
DEBUG - 2018-03-26 22:22:49 --> Total execution time: 0.0980
INFO - 2018-03-26 17:23:03 --> Config Class Initialized
INFO - 2018-03-26 17:23:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:23:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:23:03 --> Utf8 Class Initialized
INFO - 2018-03-26 17:23:03 --> URI Class Initialized
INFO - 2018-03-26 17:23:03 --> Router Class Initialized
INFO - 2018-03-26 17:23:03 --> Output Class Initialized
INFO - 2018-03-26 17:23:03 --> Security Class Initialized
DEBUG - 2018-03-26 17:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:23:03 --> Input Class Initialized
INFO - 2018-03-26 17:23:03 --> Language Class Initialized
INFO - 2018-03-26 17:23:03 --> Loader Class Initialized
INFO - 2018-03-26 17:23:03 --> Helper loaded: url_helper
INFO - 2018-03-26 17:23:03 --> Helper loaded: form_helper
INFO - 2018-03-26 17:23:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:23:03 --> Controller Class Initialized
INFO - 2018-03-26 17:23:03 --> Model Class Initialized
INFO - 2018-03-26 17:23:03 --> Model Class Initialized
INFO - 2018-03-26 17:23:03 --> Model Class Initialized
INFO - 2018-03-26 17:23:03 --> Model Class Initialized
INFO - 2018-03-26 17:23:03 --> Model Class Initialized
INFO - 2018-03-26 17:23:03 --> Helper loaded: date_helper
INFO - 2018-03-26 22:23:03 --> Model Class Initialized
INFO - 2018-03-26 22:23:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:23:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:23:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 22:23:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:23:03 --> Final output sent to browser
DEBUG - 2018-03-26 22:23:03 --> Total execution time: 0.0915
INFO - 2018-03-26 17:23:23 --> Config Class Initialized
INFO - 2018-03-26 17:23:23 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:23:23 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:23:23 --> Utf8 Class Initialized
INFO - 2018-03-26 17:23:23 --> URI Class Initialized
INFO - 2018-03-26 17:23:23 --> Router Class Initialized
INFO - 2018-03-26 17:23:23 --> Output Class Initialized
INFO - 2018-03-26 17:23:23 --> Security Class Initialized
DEBUG - 2018-03-26 17:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:23:23 --> Input Class Initialized
INFO - 2018-03-26 17:23:23 --> Language Class Initialized
INFO - 2018-03-26 17:23:23 --> Loader Class Initialized
INFO - 2018-03-26 17:23:23 --> Helper loaded: url_helper
INFO - 2018-03-26 17:23:23 --> Helper loaded: form_helper
INFO - 2018-03-26 17:23:23 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:23:23 --> Controller Class Initialized
INFO - 2018-03-26 17:23:23 --> Model Class Initialized
INFO - 2018-03-26 17:23:23 --> Model Class Initialized
INFO - 2018-03-26 17:23:23 --> Model Class Initialized
INFO - 2018-03-26 17:23:23 --> Model Class Initialized
INFO - 2018-03-26 17:23:23 --> Model Class Initialized
INFO - 2018-03-26 17:23:23 --> Helper loaded: date_helper
INFO - 2018-03-26 22:23:23 --> Model Class Initialized
INFO - 2018-03-26 22:23:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:23:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:23:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 22:23:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:23:23 --> Final output sent to browser
DEBUG - 2018-03-26 22:23:23 --> Total execution time: 0.0975
INFO - 2018-03-26 17:23:55 --> Config Class Initialized
INFO - 2018-03-26 17:23:55 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:23:55 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:23:55 --> Utf8 Class Initialized
INFO - 2018-03-26 17:23:55 --> URI Class Initialized
INFO - 2018-03-26 17:23:55 --> Router Class Initialized
INFO - 2018-03-26 17:23:55 --> Output Class Initialized
INFO - 2018-03-26 17:23:55 --> Security Class Initialized
DEBUG - 2018-03-26 17:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:23:55 --> Input Class Initialized
INFO - 2018-03-26 17:23:55 --> Language Class Initialized
INFO - 2018-03-26 17:23:55 --> Loader Class Initialized
INFO - 2018-03-26 17:23:55 --> Helper loaded: url_helper
INFO - 2018-03-26 17:23:55 --> Helper loaded: form_helper
INFO - 2018-03-26 17:23:55 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:23:55 --> Controller Class Initialized
INFO - 2018-03-26 17:23:55 --> Model Class Initialized
INFO - 2018-03-26 17:23:55 --> Model Class Initialized
INFO - 2018-03-26 17:23:55 --> Model Class Initialized
INFO - 2018-03-26 17:23:55 --> Model Class Initialized
INFO - 2018-03-26 17:23:55 --> Model Class Initialized
INFO - 2018-03-26 17:23:56 --> Helper loaded: date_helper
INFO - 2018-03-26 22:23:56 --> Model Class Initialized
INFO - 2018-03-26 22:23:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:23:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:23:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-26 22:23:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:23:56 --> Final output sent to browser
DEBUG - 2018-03-26 22:23:56 --> Total execution time: 0.0881
INFO - 2018-03-26 17:25:00 --> Config Class Initialized
INFO - 2018-03-26 17:25:00 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:25:00 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:25:00 --> Utf8 Class Initialized
INFO - 2018-03-26 17:25:00 --> URI Class Initialized
INFO - 2018-03-26 17:25:00 --> Router Class Initialized
INFO - 2018-03-26 17:25:00 --> Output Class Initialized
INFO - 2018-03-26 17:25:00 --> Security Class Initialized
DEBUG - 2018-03-26 17:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:25:00 --> Input Class Initialized
INFO - 2018-03-26 17:25:00 --> Language Class Initialized
INFO - 2018-03-26 17:25:00 --> Loader Class Initialized
INFO - 2018-03-26 17:25:00 --> Helper loaded: url_helper
INFO - 2018-03-26 17:25:00 --> Helper loaded: form_helper
INFO - 2018-03-26 17:25:00 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:25:00 --> Controller Class Initialized
INFO - 2018-03-26 17:25:00 --> Model Class Initialized
INFO - 2018-03-26 17:25:00 --> Model Class Initialized
INFO - 2018-03-26 17:25:00 --> Model Class Initialized
INFO - 2018-03-26 17:25:00 --> Model Class Initialized
INFO - 2018-03-26 17:25:00 --> Model Class Initialized
INFO - 2018-03-26 17:25:00 --> Model Class Initialized
INFO - 2018-03-26 17:25:00 --> Model Class Initialized
INFO - 2018-03-26 17:25:00 --> Model Class Initialized
INFO - 2018-03-26 17:25:00 --> Model Class Initialized
INFO - 2018-03-26 17:25:00 --> Model Class Initialized
INFO - 2018-03-26 17:25:00 --> Helper loaded: date_helper
INFO - 2018-03-26 17:25:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:25:00 --> Model Class Initialized
INFO - 2018-03-26 22:25:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:25:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:25:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-26 22:25:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:25:00 --> Final output sent to browser
DEBUG - 2018-03-26 22:25:00 --> Total execution time: 0.2185
INFO - 2018-03-26 17:25:11 --> Config Class Initialized
INFO - 2018-03-26 17:25:11 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:25:11 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:25:11 --> Utf8 Class Initialized
INFO - 2018-03-26 17:25:11 --> URI Class Initialized
INFO - 2018-03-26 17:25:11 --> Router Class Initialized
INFO - 2018-03-26 17:25:11 --> Output Class Initialized
INFO - 2018-03-26 17:25:11 --> Security Class Initialized
DEBUG - 2018-03-26 17:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:25:11 --> Input Class Initialized
INFO - 2018-03-26 17:25:11 --> Language Class Initialized
INFO - 2018-03-26 17:25:11 --> Loader Class Initialized
INFO - 2018-03-26 17:25:11 --> Helper loaded: url_helper
INFO - 2018-03-26 17:25:11 --> Helper loaded: form_helper
INFO - 2018-03-26 17:25:11 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:25:11 --> Controller Class Initialized
INFO - 2018-03-26 17:25:11 --> Model Class Initialized
INFO - 2018-03-26 17:25:11 --> Model Class Initialized
INFO - 2018-03-26 17:25:11 --> Helper loaded: date_helper
INFO - 2018-03-26 17:25:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:25:11 --> Model Class Initialized
INFO - 2018-03-26 22:25:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:25:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:25:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-26 22:25:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:25:11 --> Final output sent to browser
DEBUG - 2018-03-26 22:25:11 --> Total execution time: 0.2890
INFO - 2018-03-26 17:26:04 --> Config Class Initialized
INFO - 2018-03-26 17:26:04 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:26:04 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:26:04 --> Utf8 Class Initialized
INFO - 2018-03-26 17:26:04 --> URI Class Initialized
INFO - 2018-03-26 17:26:04 --> Router Class Initialized
INFO - 2018-03-26 17:26:04 --> Output Class Initialized
INFO - 2018-03-26 17:26:04 --> Security Class Initialized
DEBUG - 2018-03-26 17:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:26:04 --> Input Class Initialized
INFO - 2018-03-26 17:26:04 --> Language Class Initialized
INFO - 2018-03-26 17:26:04 --> Loader Class Initialized
INFO - 2018-03-26 17:26:04 --> Helper loaded: url_helper
INFO - 2018-03-26 17:26:04 --> Helper loaded: form_helper
INFO - 2018-03-26 17:26:04 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:26:04 --> Controller Class Initialized
INFO - 2018-03-26 17:26:04 --> Model Class Initialized
INFO - 2018-03-26 17:26:04 --> Model Class Initialized
INFO - 2018-03-26 17:26:04 --> Model Class Initialized
INFO - 2018-03-26 17:26:04 --> Model Class Initialized
INFO - 2018-03-26 17:26:04 --> Model Class Initialized
INFO - 2018-03-26 17:26:04 --> Helper loaded: date_helper
INFO - 2018-03-26 22:26:04 --> Model Class Initialized
INFO - 2018-03-26 22:26:04 --> Model Class Initialized
INFO - 2018-03-26 22:26:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:26:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:26:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-26 22:26:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:26:04 --> Final output sent to browser
DEBUG - 2018-03-26 22:26:04 --> Total execution time: 0.1655
INFO - 2018-03-26 17:27:16 --> Config Class Initialized
INFO - 2018-03-26 17:27:16 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:27:16 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:27:16 --> Utf8 Class Initialized
INFO - 2018-03-26 17:27:16 --> URI Class Initialized
INFO - 2018-03-26 17:27:16 --> Router Class Initialized
INFO - 2018-03-26 17:27:16 --> Output Class Initialized
INFO - 2018-03-26 17:27:16 --> Security Class Initialized
DEBUG - 2018-03-26 17:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:27:16 --> Input Class Initialized
INFO - 2018-03-26 17:27:16 --> Language Class Initialized
INFO - 2018-03-26 17:27:16 --> Loader Class Initialized
INFO - 2018-03-26 17:27:16 --> Helper loaded: url_helper
INFO - 2018-03-26 17:27:16 --> Helper loaded: form_helper
INFO - 2018-03-26 17:27:16 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:27:16 --> Controller Class Initialized
INFO - 2018-03-26 17:27:16 --> Model Class Initialized
INFO - 2018-03-26 17:27:16 --> Model Class Initialized
INFO - 2018-03-26 17:27:16 --> Model Class Initialized
INFO - 2018-03-26 17:27:16 --> Model Class Initialized
INFO - 2018-03-26 17:27:16 --> Model Class Initialized
INFO - 2018-03-26 17:27:16 --> Helper loaded: date_helper
INFO - 2018-03-26 22:27:16 --> Model Class Initialized
INFO - 2018-03-26 22:27:16 --> Model Class Initialized
INFO - 2018-03-26 22:27:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:27:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:27:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-26 22:27:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:27:16 --> Final output sent to browser
DEBUG - 2018-03-26 22:27:16 --> Total execution time: 0.1107
INFO - 2018-03-26 17:27:32 --> Config Class Initialized
INFO - 2018-03-26 17:27:32 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:27:32 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:27:32 --> Utf8 Class Initialized
INFO - 2018-03-26 17:27:32 --> URI Class Initialized
INFO - 2018-03-26 17:27:32 --> Router Class Initialized
INFO - 2018-03-26 17:27:32 --> Output Class Initialized
INFO - 2018-03-26 17:27:32 --> Security Class Initialized
DEBUG - 2018-03-26 17:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:27:32 --> Input Class Initialized
INFO - 2018-03-26 17:27:32 --> Language Class Initialized
INFO - 2018-03-26 17:27:32 --> Loader Class Initialized
INFO - 2018-03-26 17:27:32 --> Helper loaded: url_helper
INFO - 2018-03-26 17:27:32 --> Helper loaded: form_helper
INFO - 2018-03-26 17:27:32 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:27:32 --> Controller Class Initialized
INFO - 2018-03-26 17:27:32 --> Model Class Initialized
INFO - 2018-03-26 17:27:32 --> Model Class Initialized
INFO - 2018-03-26 17:27:32 --> Model Class Initialized
INFO - 2018-03-26 17:27:32 --> Model Class Initialized
INFO - 2018-03-26 17:27:32 --> Model Class Initialized
INFO - 2018-03-26 17:27:32 --> Helper loaded: date_helper
INFO - 2018-03-26 22:27:32 --> Model Class Initialized
INFO - 2018-03-26 22:27:32 --> Model Class Initialized
INFO - 2018-03-26 22:27:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:27:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:27:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-26 22:27:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:27:32 --> Final output sent to browser
DEBUG - 2018-03-26 22:27:32 --> Total execution time: 0.1169
INFO - 2018-03-26 17:39:22 --> Config Class Initialized
INFO - 2018-03-26 17:39:22 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:39:22 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:39:22 --> Utf8 Class Initialized
INFO - 2018-03-26 17:39:22 --> URI Class Initialized
INFO - 2018-03-26 17:39:22 --> Router Class Initialized
INFO - 2018-03-26 17:39:22 --> Output Class Initialized
INFO - 2018-03-26 17:39:22 --> Security Class Initialized
DEBUG - 2018-03-26 17:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:39:22 --> Input Class Initialized
INFO - 2018-03-26 17:39:22 --> Language Class Initialized
INFO - 2018-03-26 17:39:22 --> Loader Class Initialized
INFO - 2018-03-26 17:39:22 --> Helper loaded: url_helper
INFO - 2018-03-26 17:39:22 --> Helper loaded: form_helper
INFO - 2018-03-26 17:39:22 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:39:22 --> Controller Class Initialized
INFO - 2018-03-26 17:39:22 --> Model Class Initialized
INFO - 2018-03-26 17:39:22 --> Model Class Initialized
INFO - 2018-03-26 17:39:22 --> Model Class Initialized
INFO - 2018-03-26 17:39:22 --> Model Class Initialized
INFO - 2018-03-26 17:39:22 --> Model Class Initialized
INFO - 2018-03-26 17:39:22 --> Helper loaded: date_helper
INFO - 2018-03-26 22:39:22 --> Model Class Initialized
INFO - 2018-03-26 22:39:22 --> Model Class Initialized
INFO - 2018-03-26 22:39:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:39:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:39:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-26 22:39:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:39:22 --> Final output sent to browser
DEBUG - 2018-03-26 22:39:22 --> Total execution time: 0.0994
INFO - 2018-03-26 17:39:41 --> Config Class Initialized
INFO - 2018-03-26 17:39:41 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:39:41 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:39:41 --> Utf8 Class Initialized
INFO - 2018-03-26 17:39:41 --> URI Class Initialized
INFO - 2018-03-26 17:39:41 --> Router Class Initialized
INFO - 2018-03-26 17:39:41 --> Output Class Initialized
INFO - 2018-03-26 17:39:41 --> Security Class Initialized
DEBUG - 2018-03-26 17:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:39:41 --> Input Class Initialized
INFO - 2018-03-26 17:39:41 --> Language Class Initialized
INFO - 2018-03-26 17:39:41 --> Loader Class Initialized
INFO - 2018-03-26 17:39:41 --> Helper loaded: url_helper
INFO - 2018-03-26 17:39:41 --> Helper loaded: form_helper
INFO - 2018-03-26 17:39:41 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:39:41 --> Controller Class Initialized
INFO - 2018-03-26 17:39:41 --> Model Class Initialized
INFO - 2018-03-26 17:39:41 --> Model Class Initialized
INFO - 2018-03-26 17:39:41 --> Model Class Initialized
INFO - 2018-03-26 17:39:41 --> Model Class Initialized
INFO - 2018-03-26 17:39:41 --> Model Class Initialized
INFO - 2018-03-26 17:39:41 --> Helper loaded: date_helper
INFO - 2018-03-26 22:39:41 --> Model Class Initialized
INFO - 2018-03-26 22:39:41 --> Model Class Initialized
INFO - 2018-03-26 22:39:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:39:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:39:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-26 22:39:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:39:41 --> Final output sent to browser
DEBUG - 2018-03-26 22:39:41 --> Total execution time: 0.0998
INFO - 2018-03-26 17:39:53 --> Config Class Initialized
INFO - 2018-03-26 17:39:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:39:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:39:53 --> Utf8 Class Initialized
INFO - 2018-03-26 17:39:53 --> URI Class Initialized
INFO - 2018-03-26 17:39:53 --> Router Class Initialized
INFO - 2018-03-26 17:39:53 --> Output Class Initialized
INFO - 2018-03-26 17:39:53 --> Security Class Initialized
DEBUG - 2018-03-26 17:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:39:53 --> Input Class Initialized
INFO - 2018-03-26 17:39:53 --> Language Class Initialized
INFO - 2018-03-26 17:39:53 --> Loader Class Initialized
INFO - 2018-03-26 17:39:53 --> Helper loaded: url_helper
INFO - 2018-03-26 17:39:53 --> Helper loaded: form_helper
INFO - 2018-03-26 17:39:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:39:53 --> Controller Class Initialized
INFO - 2018-03-26 17:39:53 --> Model Class Initialized
INFO - 2018-03-26 17:39:53 --> Model Class Initialized
INFO - 2018-03-26 17:39:53 --> Model Class Initialized
INFO - 2018-03-26 17:39:53 --> Model Class Initialized
INFO - 2018-03-26 17:39:53 --> Model Class Initialized
INFO - 2018-03-26 17:39:53 --> Helper loaded: date_helper
INFO - 2018-03-26 22:39:53 --> Model Class Initialized
INFO - 2018-03-26 22:39:53 --> Model Class Initialized
INFO - 2018-03-26 22:39:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:39:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:39:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-26 22:39:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:39:53 --> Final output sent to browser
DEBUG - 2018-03-26 22:39:53 --> Total execution time: 0.0889
INFO - 2018-03-26 17:45:50 --> Config Class Initialized
INFO - 2018-03-26 17:45:50 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:45:50 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:45:50 --> Utf8 Class Initialized
INFO - 2018-03-26 17:45:50 --> URI Class Initialized
INFO - 2018-03-26 17:45:50 --> Router Class Initialized
INFO - 2018-03-26 17:45:50 --> Output Class Initialized
INFO - 2018-03-26 17:45:50 --> Security Class Initialized
DEBUG - 2018-03-26 17:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:45:50 --> Input Class Initialized
INFO - 2018-03-26 17:45:50 --> Language Class Initialized
INFO - 2018-03-26 17:45:50 --> Loader Class Initialized
INFO - 2018-03-26 17:45:50 --> Helper loaded: url_helper
INFO - 2018-03-26 17:45:50 --> Helper loaded: form_helper
INFO - 2018-03-26 17:45:50 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:45:50 --> Controller Class Initialized
INFO - 2018-03-26 17:45:50 --> Model Class Initialized
INFO - 2018-03-26 17:45:50 --> Model Class Initialized
INFO - 2018-03-26 17:45:50 --> Model Class Initialized
INFO - 2018-03-26 17:45:50 --> Model Class Initialized
INFO - 2018-03-26 17:45:50 --> Model Class Initialized
INFO - 2018-03-26 17:45:50 --> Model Class Initialized
INFO - 2018-03-26 17:45:50 --> Model Class Initialized
INFO - 2018-03-26 17:45:50 --> Model Class Initialized
INFO - 2018-03-26 17:45:50 --> Model Class Initialized
INFO - 2018-03-26 17:45:50 --> Model Class Initialized
INFO - 2018-03-26 17:45:50 --> Helper loaded: date_helper
INFO - 2018-03-26 17:45:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:45:50 --> Model Class Initialized
INFO - 2018-03-26 22:45:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:45:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:45:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-26 22:45:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:45:50 --> Final output sent to browser
DEBUG - 2018-03-26 22:45:50 --> Total execution time: 0.0903
INFO - 2018-03-26 17:45:53 --> Config Class Initialized
INFO - 2018-03-26 17:45:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:45:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:45:53 --> Utf8 Class Initialized
INFO - 2018-03-26 17:45:53 --> URI Class Initialized
INFO - 2018-03-26 17:45:53 --> Router Class Initialized
INFO - 2018-03-26 17:45:53 --> Output Class Initialized
INFO - 2018-03-26 17:45:53 --> Security Class Initialized
DEBUG - 2018-03-26 17:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:45:53 --> Input Class Initialized
INFO - 2018-03-26 17:45:53 --> Language Class Initialized
INFO - 2018-03-26 17:45:53 --> Loader Class Initialized
INFO - 2018-03-26 17:45:53 --> Helper loaded: url_helper
INFO - 2018-03-26 17:45:53 --> Helper loaded: form_helper
INFO - 2018-03-26 17:45:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:45:53 --> Controller Class Initialized
INFO - 2018-03-26 17:45:53 --> Model Class Initialized
INFO - 2018-03-26 17:45:53 --> Model Class Initialized
INFO - 2018-03-26 17:45:53 --> Model Class Initialized
INFO - 2018-03-26 17:45:53 --> Model Class Initialized
INFO - 2018-03-26 17:45:53 --> Model Class Initialized
INFO - 2018-03-26 17:45:53 --> Model Class Initialized
INFO - 2018-03-26 17:45:53 --> Model Class Initialized
INFO - 2018-03-26 17:45:53 --> Model Class Initialized
INFO - 2018-03-26 17:45:53 --> Model Class Initialized
INFO - 2018-03-26 17:45:53 --> Model Class Initialized
INFO - 2018-03-26 17:45:53 --> Helper loaded: date_helper
INFO - 2018-03-26 17:45:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:45:53 --> Model Class Initialized
INFO - 2018-03-26 22:45:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:45:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:45:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/create.php
INFO - 2018-03-26 22:45:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:45:53 --> Final output sent to browser
DEBUG - 2018-03-26 22:45:53 --> Total execution time: 0.1476
INFO - 2018-03-26 17:45:56 --> Config Class Initialized
INFO - 2018-03-26 17:45:56 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:45:56 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:45:56 --> Utf8 Class Initialized
INFO - 2018-03-26 17:45:56 --> URI Class Initialized
INFO - 2018-03-26 17:45:56 --> Router Class Initialized
INFO - 2018-03-26 17:45:56 --> Output Class Initialized
INFO - 2018-03-26 17:45:56 --> Security Class Initialized
DEBUG - 2018-03-26 17:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:45:56 --> Input Class Initialized
INFO - 2018-03-26 17:45:56 --> Language Class Initialized
INFO - 2018-03-26 17:45:56 --> Loader Class Initialized
INFO - 2018-03-26 17:45:56 --> Helper loaded: url_helper
INFO - 2018-03-26 17:45:56 --> Helper loaded: form_helper
INFO - 2018-03-26 17:45:56 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:45:56 --> Controller Class Initialized
INFO - 2018-03-26 17:45:56 --> Model Class Initialized
INFO - 2018-03-26 17:45:56 --> Model Class Initialized
INFO - 2018-03-26 17:45:56 --> Model Class Initialized
INFO - 2018-03-26 17:45:56 --> Model Class Initialized
INFO - 2018-03-26 17:45:56 --> Model Class Initialized
INFO - 2018-03-26 17:45:56 --> Model Class Initialized
INFO - 2018-03-26 17:45:56 --> Model Class Initialized
INFO - 2018-03-26 17:45:56 --> Model Class Initialized
INFO - 2018-03-26 17:45:56 --> Model Class Initialized
INFO - 2018-03-26 17:45:56 --> Model Class Initialized
INFO - 2018-03-26 17:45:56 --> Helper loaded: date_helper
INFO - 2018-03-26 17:45:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:45:56 --> Final output sent to browser
DEBUG - 2018-03-26 22:45:56 --> Total execution time: 0.1045
INFO - 2018-03-26 17:53:08 --> Config Class Initialized
INFO - 2018-03-26 17:53:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 17:53:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 17:53:08 --> Utf8 Class Initialized
INFO - 2018-03-26 17:53:08 --> URI Class Initialized
INFO - 2018-03-26 17:53:08 --> Router Class Initialized
INFO - 2018-03-26 17:53:08 --> Output Class Initialized
INFO - 2018-03-26 17:53:08 --> Security Class Initialized
DEBUG - 2018-03-26 17:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 17:53:08 --> Input Class Initialized
INFO - 2018-03-26 17:53:08 --> Language Class Initialized
INFO - 2018-03-26 17:53:08 --> Loader Class Initialized
INFO - 2018-03-26 17:53:08 --> Helper loaded: url_helper
INFO - 2018-03-26 17:53:08 --> Helper loaded: form_helper
INFO - 2018-03-26 17:53:08 --> Database Driver Class Initialized
DEBUG - 2018-03-26 17:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 17:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 17:53:08 --> Controller Class Initialized
INFO - 2018-03-26 17:53:08 --> Model Class Initialized
INFO - 2018-03-26 17:53:08 --> Model Class Initialized
INFO - 2018-03-26 17:53:08 --> Model Class Initialized
INFO - 2018-03-26 17:53:08 --> Model Class Initialized
INFO - 2018-03-26 17:53:08 --> Model Class Initialized
INFO - 2018-03-26 17:53:08 --> Model Class Initialized
INFO - 2018-03-26 17:53:08 --> Model Class Initialized
INFO - 2018-03-26 17:53:08 --> Model Class Initialized
INFO - 2018-03-26 17:53:08 --> Model Class Initialized
INFO - 2018-03-26 17:53:08 --> Model Class Initialized
INFO - 2018-03-26 17:53:08 --> Helper loaded: date_helper
INFO - 2018-03-26 17:53:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:53:08 --> Model Class Initialized
INFO - 2018-03-26 22:53:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-26 22:53:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-26 22:53:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/create.php
INFO - 2018-03-26 22:53:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-26 22:53:08 --> Final output sent to browser
DEBUG - 2018-03-26 22:53:08 --> Total execution time: 0.1073
INFO - 2018-03-26 19:32:06 --> Config Class Initialized
INFO - 2018-03-26 19:32:06 --> Hooks Class Initialized
DEBUG - 2018-03-26 19:32:06 --> UTF-8 Support Enabled
INFO - 2018-03-26 19:32:06 --> Utf8 Class Initialized
INFO - 2018-03-26 19:32:06 --> URI Class Initialized
INFO - 2018-03-26 19:32:06 --> Router Class Initialized
INFO - 2018-03-26 19:32:06 --> Output Class Initialized
INFO - 2018-03-26 19:32:06 --> Security Class Initialized
DEBUG - 2018-03-26 19:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 19:32:06 --> Input Class Initialized
INFO - 2018-03-26 19:32:06 --> Language Class Initialized
INFO - 2018-03-26 19:32:06 --> Loader Class Initialized
INFO - 2018-03-26 19:32:06 --> Helper loaded: url_helper
INFO - 2018-03-26 19:32:06 --> Helper loaded: form_helper
INFO - 2018-03-26 19:32:06 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:32:06 --> Controller Class Initialized
INFO - 2018-03-26 19:32:06 --> Model Class Initialized
INFO - 2018-03-26 19:32:06 --> Model Class Initialized
INFO - 2018-03-26 19:32:06 --> Model Class Initialized
INFO - 2018-03-26 19:32:06 --> Model Class Initialized
INFO - 2018-03-26 19:32:06 --> Model Class Initialized
INFO - 2018-03-26 19:32:06 --> Model Class Initialized
INFO - 2018-03-26 19:32:06 --> Model Class Initialized
INFO - 2018-03-26 19:32:06 --> Model Class Initialized
INFO - 2018-03-26 19:32:06 --> Model Class Initialized
INFO - 2018-03-26 19:32:06 --> Model Class Initialized
INFO - 2018-03-26 19:32:06 --> Model Class Initialized
INFO - 2018-03-26 19:32:06 --> Model Class Initialized
INFO - 2018-03-26 19:32:06 --> Helper loaded: date_helper
INFO - 2018-03-26 19:32:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 19:32:37 --> Config Class Initialized
INFO - 2018-03-26 19:32:37 --> Hooks Class Initialized
DEBUG - 2018-03-26 19:32:37 --> UTF-8 Support Enabled
INFO - 2018-03-26 19:32:37 --> Utf8 Class Initialized
INFO - 2018-03-26 19:32:37 --> URI Class Initialized
INFO - 2018-03-26 19:32:37 --> Router Class Initialized
INFO - 2018-03-26 19:32:37 --> Output Class Initialized
INFO - 2018-03-26 19:32:37 --> Security Class Initialized
DEBUG - 2018-03-26 19:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 19:32:37 --> Input Class Initialized
INFO - 2018-03-26 19:32:37 --> Language Class Initialized
INFO - 2018-03-26 19:32:37 --> Loader Class Initialized
INFO - 2018-03-26 19:32:37 --> Helper loaded: url_helper
INFO - 2018-03-26 19:32:37 --> Helper loaded: form_helper
INFO - 2018-03-26 19:32:37 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:32:37 --> Controller Class Initialized
INFO - 2018-03-26 19:32:37 --> Model Class Initialized
INFO - 2018-03-26 19:32:37 --> Model Class Initialized
INFO - 2018-03-26 19:32:37 --> Model Class Initialized
INFO - 2018-03-26 19:32:37 --> Model Class Initialized
INFO - 2018-03-26 19:32:37 --> Model Class Initialized
INFO - 2018-03-26 19:32:37 --> Model Class Initialized
INFO - 2018-03-26 19:32:37 --> Model Class Initialized
INFO - 2018-03-26 19:32:37 --> Model Class Initialized
INFO - 2018-03-26 19:32:37 --> Model Class Initialized
INFO - 2018-03-26 19:32:37 --> Model Class Initialized
INFO - 2018-03-26 19:32:37 --> Model Class Initialized
INFO - 2018-03-26 19:32:37 --> Model Class Initialized
INFO - 2018-03-26 19:32:37 --> Helper loaded: date_helper
INFO - 2018-03-26 19:32:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 19:32:38 --> Config Class Initialized
INFO - 2018-03-26 19:32:38 --> Hooks Class Initialized
DEBUG - 2018-03-26 19:32:38 --> UTF-8 Support Enabled
INFO - 2018-03-26 19:32:38 --> Utf8 Class Initialized
INFO - 2018-03-26 19:32:38 --> URI Class Initialized
INFO - 2018-03-26 19:32:38 --> Router Class Initialized
INFO - 2018-03-26 19:32:38 --> Output Class Initialized
INFO - 2018-03-26 19:32:38 --> Security Class Initialized
DEBUG - 2018-03-26 19:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 19:32:38 --> Input Class Initialized
INFO - 2018-03-26 19:32:38 --> Language Class Initialized
INFO - 2018-03-26 19:32:38 --> Loader Class Initialized
INFO - 2018-03-26 19:32:39 --> Helper loaded: url_helper
INFO - 2018-03-26 19:32:39 --> Helper loaded: form_helper
INFO - 2018-03-26 19:32:39 --> Database Driver Class Initialized
DEBUG - 2018-03-26 19:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 19:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 19:32:39 --> Controller Class Initialized
INFO - 2018-03-26 19:32:39 --> Model Class Initialized
INFO - 2018-03-26 19:32:39 --> Model Class Initialized
INFO - 2018-03-26 19:32:39 --> Model Class Initialized
INFO - 2018-03-26 19:32:39 --> Model Class Initialized
INFO - 2018-03-26 19:32:39 --> Model Class Initialized
INFO - 2018-03-26 19:32:39 --> Model Class Initialized
INFO - 2018-03-26 19:32:39 --> Model Class Initialized
INFO - 2018-03-26 19:32:39 --> Model Class Initialized
INFO - 2018-03-26 19:32:39 --> Model Class Initialized
INFO - 2018-03-26 19:32:39 --> Model Class Initialized
INFO - 2018-03-26 19:32:39 --> Model Class Initialized
INFO - 2018-03-26 19:32:39 --> Model Class Initialized
INFO - 2018-03-26 19:32:39 --> Helper loaded: date_helper
INFO - 2018-03-26 19:32:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:06:40 --> Config Class Initialized
INFO - 2018-03-26 20:06:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:06:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:06:40 --> Utf8 Class Initialized
INFO - 2018-03-26 20:06:40 --> URI Class Initialized
INFO - 2018-03-26 20:06:40 --> Router Class Initialized
INFO - 2018-03-26 20:06:40 --> Output Class Initialized
INFO - 2018-03-26 20:06:40 --> Security Class Initialized
DEBUG - 2018-03-26 20:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:06:40 --> Input Class Initialized
INFO - 2018-03-26 20:06:40 --> Language Class Initialized
INFO - 2018-03-26 20:06:41 --> Loader Class Initialized
INFO - 2018-03-26 20:06:41 --> Helper loaded: url_helper
INFO - 2018-03-26 20:06:41 --> Helper loaded: form_helper
INFO - 2018-03-26 20:06:41 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:06:41 --> Controller Class Initialized
INFO - 2018-03-26 20:06:41 --> Model Class Initialized
INFO - 2018-03-26 20:06:41 --> Model Class Initialized
INFO - 2018-03-26 20:06:41 --> Model Class Initialized
INFO - 2018-03-26 20:06:41 --> Model Class Initialized
INFO - 2018-03-26 20:06:41 --> Model Class Initialized
INFO - 2018-03-26 20:06:41 --> Model Class Initialized
INFO - 2018-03-26 20:06:41 --> Model Class Initialized
INFO - 2018-03-26 20:06:41 --> Model Class Initialized
INFO - 2018-03-26 20:06:41 --> Model Class Initialized
INFO - 2018-03-26 20:06:41 --> Model Class Initialized
INFO - 2018-03-26 20:06:41 --> Model Class Initialized
INFO - 2018-03-26 20:06:41 --> Model Class Initialized
INFO - 2018-03-26 20:06:41 --> Helper loaded: date_helper
INFO - 2018-03-26 20:06:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:06:52 --> Config Class Initialized
INFO - 2018-03-26 20:06:52 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:06:52 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:06:52 --> Utf8 Class Initialized
INFO - 2018-03-26 20:06:52 --> URI Class Initialized
INFO - 2018-03-26 20:06:52 --> Router Class Initialized
INFO - 2018-03-26 20:06:52 --> Output Class Initialized
INFO - 2018-03-26 20:06:52 --> Security Class Initialized
DEBUG - 2018-03-26 20:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:06:52 --> Input Class Initialized
INFO - 2018-03-26 20:06:52 --> Language Class Initialized
INFO - 2018-03-26 20:06:52 --> Loader Class Initialized
INFO - 2018-03-26 20:06:52 --> Helper loaded: url_helper
INFO - 2018-03-26 20:06:52 --> Helper loaded: form_helper
INFO - 2018-03-26 20:06:52 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:06:52 --> Controller Class Initialized
INFO - 2018-03-26 20:06:52 --> Model Class Initialized
INFO - 2018-03-26 20:06:52 --> Model Class Initialized
INFO - 2018-03-26 20:06:52 --> Helper loaded: date_helper
INFO - 2018-03-26 20:13:31 --> Config Class Initialized
INFO - 2018-03-26 20:13:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:13:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:13:31 --> Utf8 Class Initialized
INFO - 2018-03-26 20:13:31 --> URI Class Initialized
INFO - 2018-03-26 20:13:31 --> Router Class Initialized
INFO - 2018-03-26 20:13:31 --> Output Class Initialized
INFO - 2018-03-26 20:13:31 --> Security Class Initialized
DEBUG - 2018-03-26 20:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:13:31 --> Input Class Initialized
INFO - 2018-03-26 20:13:31 --> Language Class Initialized
INFO - 2018-03-26 20:13:31 --> Loader Class Initialized
INFO - 2018-03-26 20:13:31 --> Helper loaded: url_helper
INFO - 2018-03-26 20:13:31 --> Helper loaded: form_helper
INFO - 2018-03-26 20:13:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:13:31 --> Controller Class Initialized
INFO - 2018-03-26 20:13:31 --> Model Class Initialized
INFO - 2018-03-26 20:13:31 --> Model Class Initialized
INFO - 2018-03-26 20:13:31 --> Model Class Initialized
INFO - 2018-03-26 20:13:31 --> Model Class Initialized
INFO - 2018-03-26 20:13:31 --> Model Class Initialized
INFO - 2018-03-26 20:13:31 --> Model Class Initialized
INFO - 2018-03-26 20:13:31 --> Model Class Initialized
INFO - 2018-03-26 20:13:31 --> Model Class Initialized
INFO - 2018-03-26 20:13:31 --> Model Class Initialized
INFO - 2018-03-26 20:13:31 --> Model Class Initialized
INFO - 2018-03-26 20:13:31 --> Model Class Initialized
INFO - 2018-03-26 20:13:31 --> Model Class Initialized
INFO - 2018-03-26 20:13:31 --> Helper loaded: date_helper
INFO - 2018-03-26 20:13:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:13:34 --> Config Class Initialized
INFO - 2018-03-26 20:13:34 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:13:34 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:13:34 --> Utf8 Class Initialized
INFO - 2018-03-26 20:13:34 --> URI Class Initialized
INFO - 2018-03-26 20:13:34 --> Router Class Initialized
INFO - 2018-03-26 20:13:34 --> Output Class Initialized
INFO - 2018-03-26 20:13:34 --> Security Class Initialized
DEBUG - 2018-03-26 20:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:13:34 --> Input Class Initialized
INFO - 2018-03-26 20:13:34 --> Language Class Initialized
INFO - 2018-03-26 20:13:34 --> Loader Class Initialized
INFO - 2018-03-26 20:13:34 --> Helper loaded: url_helper
INFO - 2018-03-26 20:13:34 --> Helper loaded: form_helper
INFO - 2018-03-26 20:13:34 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:13:34 --> Controller Class Initialized
INFO - 2018-03-26 20:13:34 --> Model Class Initialized
INFO - 2018-03-26 20:13:34 --> Model Class Initialized
INFO - 2018-03-26 20:13:34 --> Model Class Initialized
INFO - 2018-03-26 20:13:34 --> Model Class Initialized
INFO - 2018-03-26 20:13:34 --> Model Class Initialized
INFO - 2018-03-26 20:13:34 --> Model Class Initialized
INFO - 2018-03-26 20:13:34 --> Model Class Initialized
INFO - 2018-03-26 20:13:34 --> Model Class Initialized
INFO - 2018-03-26 20:13:34 --> Model Class Initialized
INFO - 2018-03-26 20:13:34 --> Model Class Initialized
INFO - 2018-03-26 20:13:34 --> Model Class Initialized
INFO - 2018-03-26 20:13:34 --> Model Class Initialized
INFO - 2018-03-26 20:13:34 --> Helper loaded: date_helper
INFO - 2018-03-26 20:13:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:13:35 --> Config Class Initialized
INFO - 2018-03-26 20:13:35 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:13:35 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:13:35 --> Utf8 Class Initialized
INFO - 2018-03-26 20:13:35 --> URI Class Initialized
INFO - 2018-03-26 20:13:35 --> Router Class Initialized
INFO - 2018-03-26 20:13:35 --> Output Class Initialized
INFO - 2018-03-26 20:13:35 --> Security Class Initialized
DEBUG - 2018-03-26 20:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:13:35 --> Input Class Initialized
INFO - 2018-03-26 20:13:35 --> Language Class Initialized
INFO - 2018-03-26 20:13:35 --> Loader Class Initialized
INFO - 2018-03-26 20:13:35 --> Helper loaded: url_helper
INFO - 2018-03-26 20:13:35 --> Helper loaded: form_helper
INFO - 2018-03-26 20:13:35 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:13:35 --> Controller Class Initialized
INFO - 2018-03-26 20:13:35 --> Model Class Initialized
INFO - 2018-03-26 20:13:35 --> Model Class Initialized
INFO - 2018-03-26 20:13:35 --> Model Class Initialized
INFO - 2018-03-26 20:13:35 --> Model Class Initialized
INFO - 2018-03-26 20:13:35 --> Model Class Initialized
INFO - 2018-03-26 20:13:35 --> Model Class Initialized
INFO - 2018-03-26 20:13:35 --> Model Class Initialized
INFO - 2018-03-26 20:13:35 --> Model Class Initialized
INFO - 2018-03-26 20:13:35 --> Model Class Initialized
INFO - 2018-03-26 20:13:35 --> Model Class Initialized
INFO - 2018-03-26 20:13:35 --> Model Class Initialized
INFO - 2018-03-26 20:13:35 --> Model Class Initialized
INFO - 2018-03-26 20:13:35 --> Helper loaded: date_helper
INFO - 2018-03-26 20:13:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:14:22 --> Config Class Initialized
INFO - 2018-03-26 20:14:22 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:14:22 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:14:22 --> Utf8 Class Initialized
INFO - 2018-03-26 20:14:22 --> URI Class Initialized
INFO - 2018-03-26 20:14:22 --> Router Class Initialized
INFO - 2018-03-26 20:14:22 --> Output Class Initialized
INFO - 2018-03-26 20:14:22 --> Security Class Initialized
DEBUG - 2018-03-26 20:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:14:22 --> Input Class Initialized
INFO - 2018-03-26 20:14:22 --> Language Class Initialized
INFO - 2018-03-26 20:14:22 --> Loader Class Initialized
INFO - 2018-03-26 20:14:22 --> Helper loaded: url_helper
INFO - 2018-03-26 20:14:22 --> Helper loaded: form_helper
INFO - 2018-03-26 20:14:22 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:14:22 --> Controller Class Initialized
INFO - 2018-03-26 20:14:22 --> Model Class Initialized
INFO - 2018-03-26 20:14:22 --> Model Class Initialized
INFO - 2018-03-26 20:14:22 --> Model Class Initialized
INFO - 2018-03-26 20:14:22 --> Model Class Initialized
INFO - 2018-03-26 20:14:22 --> Model Class Initialized
INFO - 2018-03-26 20:14:22 --> Model Class Initialized
INFO - 2018-03-26 20:14:22 --> Model Class Initialized
INFO - 2018-03-26 20:14:22 --> Helper loaded: date_helper
INFO - 2018-03-26 20:14:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:14:26 --> Config Class Initialized
INFO - 2018-03-26 20:14:26 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:14:26 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:14:26 --> Utf8 Class Initialized
INFO - 2018-03-26 20:14:26 --> URI Class Initialized
INFO - 2018-03-26 20:14:26 --> Router Class Initialized
INFO - 2018-03-26 20:14:26 --> Output Class Initialized
INFO - 2018-03-26 20:14:26 --> Security Class Initialized
DEBUG - 2018-03-26 20:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:14:26 --> Input Class Initialized
INFO - 2018-03-26 20:14:26 --> Language Class Initialized
INFO - 2018-03-26 20:14:26 --> Loader Class Initialized
INFO - 2018-03-26 20:14:26 --> Helper loaded: url_helper
INFO - 2018-03-26 20:14:26 --> Helper loaded: form_helper
INFO - 2018-03-26 20:14:26 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:14:26 --> Controller Class Initialized
INFO - 2018-03-26 20:14:26 --> Model Class Initialized
INFO - 2018-03-26 20:14:26 --> Model Class Initialized
INFO - 2018-03-26 20:14:26 --> Model Class Initialized
INFO - 2018-03-26 20:14:26 --> Model Class Initialized
INFO - 2018-03-26 20:14:26 --> Model Class Initialized
INFO - 2018-03-26 20:14:26 --> Model Class Initialized
INFO - 2018-03-26 20:14:26 --> Model Class Initialized
INFO - 2018-03-26 20:14:26 --> Helper loaded: date_helper
INFO - 2018-03-26 20:14:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:14:28 --> Config Class Initialized
INFO - 2018-03-26 20:14:28 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:14:28 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:14:28 --> Utf8 Class Initialized
INFO - 2018-03-26 20:14:28 --> URI Class Initialized
INFO - 2018-03-26 20:14:28 --> Router Class Initialized
INFO - 2018-03-26 20:14:28 --> Output Class Initialized
INFO - 2018-03-26 20:14:28 --> Security Class Initialized
DEBUG - 2018-03-26 20:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:14:28 --> Input Class Initialized
INFO - 2018-03-26 20:14:28 --> Language Class Initialized
INFO - 2018-03-26 20:14:28 --> Loader Class Initialized
INFO - 2018-03-26 20:14:28 --> Helper loaded: url_helper
INFO - 2018-03-26 20:14:28 --> Helper loaded: form_helper
INFO - 2018-03-26 20:14:28 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:14:28 --> Controller Class Initialized
INFO - 2018-03-26 20:14:28 --> Model Class Initialized
INFO - 2018-03-26 20:14:28 --> Model Class Initialized
INFO - 2018-03-26 20:14:28 --> Model Class Initialized
INFO - 2018-03-26 20:14:28 --> Model Class Initialized
INFO - 2018-03-26 20:14:28 --> Model Class Initialized
INFO - 2018-03-26 20:14:28 --> Model Class Initialized
INFO - 2018-03-26 20:14:28 --> Model Class Initialized
INFO - 2018-03-26 20:14:28 --> Helper loaded: date_helper
INFO - 2018-03-26 20:14:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:14:44 --> Config Class Initialized
INFO - 2018-03-26 20:14:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:14:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:14:44 --> Utf8 Class Initialized
INFO - 2018-03-26 20:14:44 --> URI Class Initialized
INFO - 2018-03-26 20:14:44 --> Router Class Initialized
INFO - 2018-03-26 20:14:44 --> Output Class Initialized
INFO - 2018-03-26 20:14:44 --> Security Class Initialized
DEBUG - 2018-03-26 20:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:14:44 --> Input Class Initialized
INFO - 2018-03-26 20:14:44 --> Language Class Initialized
INFO - 2018-03-26 20:14:44 --> Loader Class Initialized
INFO - 2018-03-26 20:14:44 --> Helper loaded: url_helper
INFO - 2018-03-26 20:14:44 --> Helper loaded: form_helper
INFO - 2018-03-26 20:14:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:14:44 --> Controller Class Initialized
INFO - 2018-03-26 20:14:44 --> Model Class Initialized
INFO - 2018-03-26 20:14:44 --> Model Class Initialized
INFO - 2018-03-26 20:14:44 --> Model Class Initialized
INFO - 2018-03-26 20:14:44 --> Model Class Initialized
INFO - 2018-03-26 20:14:44 --> Model Class Initialized
INFO - 2018-03-26 20:14:44 --> Model Class Initialized
INFO - 2018-03-26 20:14:44 --> Model Class Initialized
INFO - 2018-03-26 20:14:44 --> Model Class Initialized
INFO - 2018-03-26 20:14:44 --> Model Class Initialized
INFO - 2018-03-26 20:14:44 --> Model Class Initialized
INFO - 2018-03-26 20:14:44 --> Model Class Initialized
INFO - 2018-03-26 20:14:44 --> Model Class Initialized
INFO - 2018-03-26 20:14:45 --> Helper loaded: date_helper
INFO - 2018-03-26 20:14:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:14:47 --> Config Class Initialized
INFO - 2018-03-26 20:14:47 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:14:47 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:14:47 --> Utf8 Class Initialized
INFO - 2018-03-26 20:14:47 --> URI Class Initialized
INFO - 2018-03-26 20:14:47 --> Router Class Initialized
INFO - 2018-03-26 20:14:47 --> Output Class Initialized
INFO - 2018-03-26 20:14:47 --> Security Class Initialized
DEBUG - 2018-03-26 20:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:14:47 --> Input Class Initialized
INFO - 2018-03-26 20:14:47 --> Language Class Initialized
INFO - 2018-03-26 20:14:47 --> Loader Class Initialized
INFO - 2018-03-26 20:14:47 --> Helper loaded: url_helper
INFO - 2018-03-26 20:14:47 --> Helper loaded: form_helper
INFO - 2018-03-26 20:14:47 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:14:47 --> Controller Class Initialized
INFO - 2018-03-26 20:14:47 --> Model Class Initialized
INFO - 2018-03-26 20:14:47 --> Model Class Initialized
INFO - 2018-03-26 20:14:47 --> Model Class Initialized
INFO - 2018-03-26 20:14:47 --> Model Class Initialized
INFO - 2018-03-26 20:14:47 --> Model Class Initialized
INFO - 2018-03-26 20:14:47 --> Model Class Initialized
INFO - 2018-03-26 20:14:47 --> Model Class Initialized
INFO - 2018-03-26 20:14:47 --> Model Class Initialized
INFO - 2018-03-26 20:14:47 --> Model Class Initialized
INFO - 2018-03-26 20:14:47 --> Model Class Initialized
INFO - 2018-03-26 20:14:47 --> Model Class Initialized
INFO - 2018-03-26 20:14:47 --> Model Class Initialized
INFO - 2018-03-26 20:14:47 --> Helper loaded: date_helper
INFO - 2018-03-26 20:14:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:14:49 --> Config Class Initialized
INFO - 2018-03-26 20:14:49 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:14:49 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:14:49 --> Utf8 Class Initialized
INFO - 2018-03-26 20:14:49 --> URI Class Initialized
INFO - 2018-03-26 20:14:49 --> Router Class Initialized
INFO - 2018-03-26 20:14:49 --> Output Class Initialized
INFO - 2018-03-26 20:14:49 --> Security Class Initialized
DEBUG - 2018-03-26 20:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:14:49 --> Input Class Initialized
INFO - 2018-03-26 20:14:49 --> Language Class Initialized
INFO - 2018-03-26 20:14:49 --> Loader Class Initialized
INFO - 2018-03-26 20:14:49 --> Helper loaded: url_helper
INFO - 2018-03-26 20:14:49 --> Helper loaded: form_helper
INFO - 2018-03-26 20:14:49 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:14:49 --> Controller Class Initialized
INFO - 2018-03-26 20:14:49 --> Model Class Initialized
INFO - 2018-03-26 20:14:49 --> Model Class Initialized
INFO - 2018-03-26 20:14:49 --> Model Class Initialized
INFO - 2018-03-26 20:14:49 --> Model Class Initialized
INFO - 2018-03-26 20:14:49 --> Model Class Initialized
INFO - 2018-03-26 20:14:49 --> Model Class Initialized
INFO - 2018-03-26 20:14:49 --> Model Class Initialized
INFO - 2018-03-26 20:14:49 --> Model Class Initialized
INFO - 2018-03-26 20:14:49 --> Model Class Initialized
INFO - 2018-03-26 20:14:49 --> Model Class Initialized
INFO - 2018-03-26 20:14:49 --> Model Class Initialized
INFO - 2018-03-26 20:14:49 --> Model Class Initialized
INFO - 2018-03-26 20:14:49 --> Helper loaded: date_helper
INFO - 2018-03-26 20:14:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:16:27 --> Config Class Initialized
INFO - 2018-03-26 20:16:27 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:16:27 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:16:27 --> Utf8 Class Initialized
INFO - 2018-03-26 20:16:27 --> URI Class Initialized
INFO - 2018-03-26 20:16:27 --> Router Class Initialized
INFO - 2018-03-26 20:16:27 --> Output Class Initialized
INFO - 2018-03-26 20:16:27 --> Security Class Initialized
DEBUG - 2018-03-26 20:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:16:27 --> Input Class Initialized
INFO - 2018-03-26 20:16:27 --> Language Class Initialized
INFO - 2018-03-26 20:16:27 --> Loader Class Initialized
INFO - 2018-03-26 20:16:27 --> Helper loaded: url_helper
INFO - 2018-03-26 20:16:27 --> Helper loaded: form_helper
INFO - 2018-03-26 20:16:27 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:16:27 --> Controller Class Initialized
INFO - 2018-03-26 20:16:27 --> Model Class Initialized
INFO - 2018-03-26 20:16:27 --> Model Class Initialized
INFO - 2018-03-26 20:16:27 --> Model Class Initialized
INFO - 2018-03-26 20:16:27 --> Model Class Initialized
INFO - 2018-03-26 20:16:27 --> Model Class Initialized
INFO - 2018-03-26 20:16:27 --> Model Class Initialized
INFO - 2018-03-26 20:16:27 --> Model Class Initialized
INFO - 2018-03-26 20:16:27 --> Helper loaded: date_helper
INFO - 2018-03-26 20:16:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:16:30 --> Config Class Initialized
INFO - 2018-03-26 20:16:30 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:16:30 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:16:30 --> Utf8 Class Initialized
INFO - 2018-03-26 20:16:30 --> URI Class Initialized
INFO - 2018-03-26 20:16:30 --> Router Class Initialized
INFO - 2018-03-26 20:16:30 --> Output Class Initialized
INFO - 2018-03-26 20:16:30 --> Security Class Initialized
DEBUG - 2018-03-26 20:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:16:30 --> Input Class Initialized
INFO - 2018-03-26 20:16:30 --> Language Class Initialized
INFO - 2018-03-26 20:16:30 --> Loader Class Initialized
INFO - 2018-03-26 20:16:30 --> Helper loaded: url_helper
INFO - 2018-03-26 20:16:30 --> Helper loaded: form_helper
INFO - 2018-03-26 20:16:30 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:16:30 --> Controller Class Initialized
INFO - 2018-03-26 20:16:30 --> Model Class Initialized
INFO - 2018-03-26 20:16:30 --> Model Class Initialized
INFO - 2018-03-26 20:16:30 --> Model Class Initialized
INFO - 2018-03-26 20:16:30 --> Model Class Initialized
INFO - 2018-03-26 20:16:30 --> Model Class Initialized
INFO - 2018-03-26 20:16:30 --> Model Class Initialized
INFO - 2018-03-26 20:16:30 --> Model Class Initialized
INFO - 2018-03-26 20:16:30 --> Helper loaded: date_helper
INFO - 2018-03-26 20:16:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:17:02 --> Config Class Initialized
INFO - 2018-03-26 20:17:02 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:17:02 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:17:02 --> Utf8 Class Initialized
INFO - 2018-03-26 20:17:02 --> URI Class Initialized
INFO - 2018-03-26 20:17:02 --> Router Class Initialized
INFO - 2018-03-26 20:17:02 --> Output Class Initialized
INFO - 2018-03-26 20:17:02 --> Security Class Initialized
DEBUG - 2018-03-26 20:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:17:02 --> Input Class Initialized
INFO - 2018-03-26 20:17:02 --> Language Class Initialized
INFO - 2018-03-26 20:17:02 --> Loader Class Initialized
INFO - 2018-03-26 20:17:02 --> Helper loaded: url_helper
INFO - 2018-03-26 20:17:02 --> Helper loaded: form_helper
INFO - 2018-03-26 20:17:02 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:17:02 --> Controller Class Initialized
INFO - 2018-03-26 20:17:02 --> Model Class Initialized
INFO - 2018-03-26 20:17:02 --> Model Class Initialized
INFO - 2018-03-26 20:17:02 --> Model Class Initialized
INFO - 2018-03-26 20:17:02 --> Model Class Initialized
INFO - 2018-03-26 20:17:02 --> Model Class Initialized
INFO - 2018-03-26 20:17:02 --> Model Class Initialized
INFO - 2018-03-26 20:17:02 --> Model Class Initialized
INFO - 2018-03-26 20:17:02 --> Model Class Initialized
INFO - 2018-03-26 20:17:02 --> Model Class Initialized
INFO - 2018-03-26 20:17:02 --> Model Class Initialized
INFO - 2018-03-26 20:17:02 --> Model Class Initialized
INFO - 2018-03-26 20:17:02 --> Model Class Initialized
INFO - 2018-03-26 20:17:02 --> Helper loaded: date_helper
INFO - 2018-03-26 20:17:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:17:06 --> Config Class Initialized
INFO - 2018-03-26 20:17:06 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:17:06 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:17:06 --> Utf8 Class Initialized
INFO - 2018-03-26 20:17:06 --> URI Class Initialized
INFO - 2018-03-26 20:17:06 --> Router Class Initialized
INFO - 2018-03-26 20:17:06 --> Output Class Initialized
INFO - 2018-03-26 20:17:06 --> Security Class Initialized
DEBUG - 2018-03-26 20:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:17:06 --> Input Class Initialized
INFO - 2018-03-26 20:17:06 --> Language Class Initialized
INFO - 2018-03-26 20:17:06 --> Loader Class Initialized
INFO - 2018-03-26 20:17:06 --> Helper loaded: url_helper
INFO - 2018-03-26 20:17:06 --> Helper loaded: form_helper
INFO - 2018-03-26 20:17:06 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:17:06 --> Controller Class Initialized
INFO - 2018-03-26 20:17:06 --> Model Class Initialized
INFO - 2018-03-26 20:17:06 --> Model Class Initialized
INFO - 2018-03-26 20:17:06 --> Model Class Initialized
INFO - 2018-03-26 20:17:06 --> Model Class Initialized
INFO - 2018-03-26 20:17:06 --> Model Class Initialized
INFO - 2018-03-26 20:17:06 --> Model Class Initialized
INFO - 2018-03-26 20:17:06 --> Model Class Initialized
INFO - 2018-03-26 20:17:06 --> Model Class Initialized
INFO - 2018-03-26 20:17:06 --> Model Class Initialized
INFO - 2018-03-26 20:17:06 --> Model Class Initialized
INFO - 2018-03-26 20:17:06 --> Model Class Initialized
INFO - 2018-03-26 20:17:06 --> Model Class Initialized
INFO - 2018-03-26 20:17:06 --> Helper loaded: date_helper
INFO - 2018-03-26 20:17:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:17:08 --> Config Class Initialized
INFO - 2018-03-26 20:17:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:17:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:17:08 --> Utf8 Class Initialized
INFO - 2018-03-26 20:17:08 --> URI Class Initialized
INFO - 2018-03-26 20:17:08 --> Router Class Initialized
INFO - 2018-03-26 20:17:08 --> Output Class Initialized
INFO - 2018-03-26 20:17:08 --> Security Class Initialized
DEBUG - 2018-03-26 20:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:17:08 --> Input Class Initialized
INFO - 2018-03-26 20:17:08 --> Language Class Initialized
INFO - 2018-03-26 20:17:08 --> Loader Class Initialized
INFO - 2018-03-26 20:17:08 --> Helper loaded: url_helper
INFO - 2018-03-26 20:17:08 --> Helper loaded: form_helper
INFO - 2018-03-26 20:17:08 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:17:08 --> Controller Class Initialized
INFO - 2018-03-26 20:17:08 --> Model Class Initialized
INFO - 2018-03-26 20:17:08 --> Model Class Initialized
INFO - 2018-03-26 20:17:08 --> Model Class Initialized
INFO - 2018-03-26 20:17:08 --> Model Class Initialized
INFO - 2018-03-26 20:17:08 --> Model Class Initialized
INFO - 2018-03-26 20:17:08 --> Model Class Initialized
INFO - 2018-03-26 20:17:08 --> Model Class Initialized
INFO - 2018-03-26 20:17:08 --> Model Class Initialized
INFO - 2018-03-26 20:17:08 --> Model Class Initialized
INFO - 2018-03-26 20:17:08 --> Model Class Initialized
INFO - 2018-03-26 20:17:08 --> Model Class Initialized
INFO - 2018-03-26 20:17:08 --> Model Class Initialized
INFO - 2018-03-26 20:17:08 --> Helper loaded: date_helper
INFO - 2018-03-26 20:17:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:17:59 --> Config Class Initialized
INFO - 2018-03-26 20:17:59 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:17:59 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:17:59 --> Utf8 Class Initialized
INFO - 2018-03-26 20:17:59 --> URI Class Initialized
INFO - 2018-03-26 20:17:59 --> Router Class Initialized
INFO - 2018-03-26 20:17:59 --> Output Class Initialized
INFO - 2018-03-26 20:17:59 --> Security Class Initialized
DEBUG - 2018-03-26 20:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:17:59 --> Input Class Initialized
INFO - 2018-03-26 20:17:59 --> Language Class Initialized
INFO - 2018-03-26 20:17:59 --> Loader Class Initialized
INFO - 2018-03-26 20:17:59 --> Helper loaded: url_helper
INFO - 2018-03-26 20:17:59 --> Helper loaded: form_helper
INFO - 2018-03-26 20:17:59 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:17:59 --> Controller Class Initialized
INFO - 2018-03-26 20:17:59 --> Model Class Initialized
INFO - 2018-03-26 20:17:59 --> Model Class Initialized
INFO - 2018-03-26 20:17:59 --> Model Class Initialized
INFO - 2018-03-26 20:17:59 --> Model Class Initialized
INFO - 2018-03-26 20:17:59 --> Model Class Initialized
INFO - 2018-03-26 20:17:59 --> Model Class Initialized
INFO - 2018-03-26 20:17:59 --> Model Class Initialized
INFO - 2018-03-26 20:17:59 --> Model Class Initialized
INFO - 2018-03-26 20:17:59 --> Model Class Initialized
INFO - 2018-03-26 20:17:59 --> Model Class Initialized
INFO - 2018-03-26 20:17:59 --> Model Class Initialized
INFO - 2018-03-26 20:17:59 --> Model Class Initialized
INFO - 2018-03-26 20:17:59 --> Helper loaded: date_helper
INFO - 2018-03-26 20:17:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:24:17 --> Config Class Initialized
INFO - 2018-03-26 20:24:17 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:24:17 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:24:17 --> Utf8 Class Initialized
INFO - 2018-03-26 20:24:17 --> URI Class Initialized
INFO - 2018-03-26 20:24:17 --> Router Class Initialized
INFO - 2018-03-26 20:24:17 --> Output Class Initialized
INFO - 2018-03-26 20:24:17 --> Security Class Initialized
DEBUG - 2018-03-26 20:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:24:17 --> Input Class Initialized
INFO - 2018-03-26 20:24:17 --> Language Class Initialized
INFO - 2018-03-26 20:24:17 --> Loader Class Initialized
INFO - 2018-03-26 20:24:17 --> Helper loaded: url_helper
INFO - 2018-03-26 20:24:17 --> Helper loaded: form_helper
INFO - 2018-03-26 20:24:17 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:24:17 --> Controller Class Initialized
INFO - 2018-03-26 20:24:17 --> Model Class Initialized
INFO - 2018-03-26 20:24:17 --> Model Class Initialized
INFO - 2018-03-26 20:24:17 --> Model Class Initialized
INFO - 2018-03-26 20:24:17 --> Model Class Initialized
INFO - 2018-03-26 20:24:17 --> Model Class Initialized
INFO - 2018-03-26 20:24:17 --> Model Class Initialized
INFO - 2018-03-26 20:24:17 --> Model Class Initialized
INFO - 2018-03-26 20:24:17 --> Model Class Initialized
INFO - 2018-03-26 20:24:17 --> Model Class Initialized
INFO - 2018-03-26 20:24:17 --> Model Class Initialized
INFO - 2018-03-26 20:24:17 --> Model Class Initialized
INFO - 2018-03-26 20:24:17 --> Model Class Initialized
INFO - 2018-03-26 20:24:17 --> Helper loaded: date_helper
INFO - 2018-03-26 20:24:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:24:36 --> Config Class Initialized
INFO - 2018-03-26 20:24:36 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:24:36 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:24:36 --> Utf8 Class Initialized
INFO - 2018-03-26 20:24:36 --> URI Class Initialized
INFO - 2018-03-26 20:24:36 --> Router Class Initialized
INFO - 2018-03-26 20:24:36 --> Output Class Initialized
INFO - 2018-03-26 20:24:36 --> Security Class Initialized
DEBUG - 2018-03-26 20:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:24:36 --> Input Class Initialized
INFO - 2018-03-26 20:24:36 --> Language Class Initialized
INFO - 2018-03-26 20:24:36 --> Loader Class Initialized
INFO - 2018-03-26 20:24:36 --> Helper loaded: url_helper
INFO - 2018-03-26 20:24:36 --> Helper loaded: form_helper
INFO - 2018-03-26 20:24:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:24:36 --> Controller Class Initialized
INFO - 2018-03-26 20:24:36 --> Model Class Initialized
INFO - 2018-03-26 20:24:36 --> Model Class Initialized
INFO - 2018-03-26 20:24:36 --> Model Class Initialized
INFO - 2018-03-26 20:24:36 --> Model Class Initialized
INFO - 2018-03-26 20:24:36 --> Model Class Initialized
INFO - 2018-03-26 20:24:36 --> Model Class Initialized
INFO - 2018-03-26 20:24:36 --> Model Class Initialized
INFO - 2018-03-26 20:24:36 --> Model Class Initialized
INFO - 2018-03-26 20:24:36 --> Model Class Initialized
INFO - 2018-03-26 20:24:36 --> Model Class Initialized
INFO - 2018-03-26 20:24:36 --> Model Class Initialized
INFO - 2018-03-26 20:24:36 --> Model Class Initialized
INFO - 2018-03-26 20:24:36 --> Helper loaded: date_helper
INFO - 2018-03-26 20:24:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:25:21 --> Config Class Initialized
INFO - 2018-03-26 20:25:21 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:25:21 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:25:21 --> Utf8 Class Initialized
INFO - 2018-03-26 20:25:21 --> URI Class Initialized
INFO - 2018-03-26 20:25:21 --> Router Class Initialized
INFO - 2018-03-26 20:25:21 --> Output Class Initialized
INFO - 2018-03-26 20:25:21 --> Security Class Initialized
DEBUG - 2018-03-26 20:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:25:21 --> Input Class Initialized
INFO - 2018-03-26 20:25:21 --> Language Class Initialized
INFO - 2018-03-26 20:25:21 --> Loader Class Initialized
INFO - 2018-03-26 20:25:21 --> Helper loaded: url_helper
INFO - 2018-03-26 20:25:21 --> Helper loaded: form_helper
INFO - 2018-03-26 20:25:21 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:25:21 --> Controller Class Initialized
INFO - 2018-03-26 20:25:21 --> Model Class Initialized
INFO - 2018-03-26 20:25:21 --> Model Class Initialized
INFO - 2018-03-26 20:25:21 --> Model Class Initialized
INFO - 2018-03-26 20:25:21 --> Model Class Initialized
INFO - 2018-03-26 20:25:21 --> Model Class Initialized
INFO - 2018-03-26 20:25:21 --> Model Class Initialized
INFO - 2018-03-26 20:25:21 --> Model Class Initialized
INFO - 2018-03-26 20:25:21 --> Model Class Initialized
INFO - 2018-03-26 20:25:21 --> Model Class Initialized
INFO - 2018-03-26 20:25:21 --> Model Class Initialized
INFO - 2018-03-26 20:25:21 --> Model Class Initialized
INFO - 2018-03-26 20:25:21 --> Model Class Initialized
INFO - 2018-03-26 20:25:21 --> Helper loaded: date_helper
INFO - 2018-03-26 20:25:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:25:40 --> Config Class Initialized
INFO - 2018-03-26 20:25:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:25:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:25:40 --> Utf8 Class Initialized
INFO - 2018-03-26 20:25:40 --> URI Class Initialized
INFO - 2018-03-26 20:25:40 --> Router Class Initialized
INFO - 2018-03-26 20:25:40 --> Output Class Initialized
INFO - 2018-03-26 20:25:40 --> Security Class Initialized
DEBUG - 2018-03-26 20:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:25:40 --> Input Class Initialized
INFO - 2018-03-26 20:25:40 --> Language Class Initialized
INFO - 2018-03-26 20:25:40 --> Loader Class Initialized
INFO - 2018-03-26 20:25:40 --> Helper loaded: url_helper
INFO - 2018-03-26 20:25:40 --> Helper loaded: form_helper
INFO - 2018-03-26 20:25:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:25:40 --> Controller Class Initialized
INFO - 2018-03-26 20:25:40 --> Model Class Initialized
INFO - 2018-03-26 20:25:40 --> Model Class Initialized
INFO - 2018-03-26 20:25:40 --> Model Class Initialized
INFO - 2018-03-26 20:25:40 --> Model Class Initialized
INFO - 2018-03-26 20:25:40 --> Model Class Initialized
INFO - 2018-03-26 20:25:40 --> Model Class Initialized
INFO - 2018-03-26 20:25:40 --> Model Class Initialized
INFO - 2018-03-26 20:25:40 --> Model Class Initialized
INFO - 2018-03-26 20:25:40 --> Model Class Initialized
INFO - 2018-03-26 20:25:40 --> Model Class Initialized
INFO - 2018-03-26 20:25:40 --> Model Class Initialized
INFO - 2018-03-26 20:25:40 --> Model Class Initialized
INFO - 2018-03-26 20:25:40 --> Helper loaded: date_helper
INFO - 2018-03-26 20:25:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:26:16 --> Config Class Initialized
INFO - 2018-03-26 20:26:16 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:26:16 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:26:16 --> Utf8 Class Initialized
INFO - 2018-03-26 20:26:16 --> URI Class Initialized
INFO - 2018-03-26 20:26:16 --> Router Class Initialized
INFO - 2018-03-26 20:26:16 --> Output Class Initialized
INFO - 2018-03-26 20:26:16 --> Security Class Initialized
DEBUG - 2018-03-26 20:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:26:16 --> Input Class Initialized
INFO - 2018-03-26 20:26:16 --> Language Class Initialized
INFO - 2018-03-26 20:26:16 --> Loader Class Initialized
INFO - 2018-03-26 20:26:16 --> Helper loaded: url_helper
INFO - 2018-03-26 20:26:16 --> Helper loaded: form_helper
INFO - 2018-03-26 20:26:16 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:26:16 --> Controller Class Initialized
INFO - 2018-03-26 20:26:16 --> Model Class Initialized
INFO - 2018-03-26 20:26:16 --> Model Class Initialized
INFO - 2018-03-26 20:26:16 --> Model Class Initialized
INFO - 2018-03-26 20:26:16 --> Model Class Initialized
INFO - 2018-03-26 20:26:16 --> Model Class Initialized
INFO - 2018-03-26 20:26:16 --> Model Class Initialized
INFO - 2018-03-26 20:26:16 --> Model Class Initialized
INFO - 2018-03-26 20:26:16 --> Model Class Initialized
INFO - 2018-03-26 20:26:16 --> Model Class Initialized
INFO - 2018-03-26 20:26:16 --> Model Class Initialized
INFO - 2018-03-26 20:26:16 --> Model Class Initialized
INFO - 2018-03-26 20:26:16 --> Model Class Initialized
INFO - 2018-03-26 20:26:16 --> Helper loaded: date_helper
INFO - 2018-03-26 20:26:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:26:26 --> Config Class Initialized
INFO - 2018-03-26 20:26:26 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:26:26 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:26:26 --> Utf8 Class Initialized
INFO - 2018-03-26 20:26:26 --> URI Class Initialized
INFO - 2018-03-26 20:26:26 --> Router Class Initialized
INFO - 2018-03-26 20:26:26 --> Output Class Initialized
INFO - 2018-03-26 20:26:26 --> Security Class Initialized
DEBUG - 2018-03-26 20:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:26:26 --> Input Class Initialized
INFO - 2018-03-26 20:26:26 --> Language Class Initialized
INFO - 2018-03-26 20:26:26 --> Loader Class Initialized
INFO - 2018-03-26 20:26:26 --> Helper loaded: url_helper
INFO - 2018-03-26 20:26:26 --> Helper loaded: form_helper
INFO - 2018-03-26 20:26:26 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:26:26 --> Controller Class Initialized
INFO - 2018-03-26 20:26:26 --> Model Class Initialized
INFO - 2018-03-26 20:26:26 --> Model Class Initialized
INFO - 2018-03-26 20:26:26 --> Model Class Initialized
INFO - 2018-03-26 20:26:26 --> Model Class Initialized
INFO - 2018-03-26 20:26:26 --> Model Class Initialized
INFO - 2018-03-26 20:26:26 --> Model Class Initialized
INFO - 2018-03-26 20:26:26 --> Model Class Initialized
INFO - 2018-03-26 20:26:26 --> Model Class Initialized
INFO - 2018-03-26 20:26:26 --> Model Class Initialized
INFO - 2018-03-26 20:26:26 --> Model Class Initialized
INFO - 2018-03-26 20:26:26 --> Helper loaded: date_helper
INFO - 2018-03-26 20:26:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:26:30 --> Config Class Initialized
INFO - 2018-03-26 20:26:30 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:26:30 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:26:30 --> Utf8 Class Initialized
INFO - 2018-03-26 20:26:30 --> URI Class Initialized
INFO - 2018-03-26 20:26:30 --> Router Class Initialized
INFO - 2018-03-26 20:26:30 --> Output Class Initialized
INFO - 2018-03-26 20:26:30 --> Security Class Initialized
DEBUG - 2018-03-26 20:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:26:30 --> Input Class Initialized
INFO - 2018-03-26 20:26:30 --> Language Class Initialized
INFO - 2018-03-26 20:26:30 --> Loader Class Initialized
INFO - 2018-03-26 20:26:30 --> Helper loaded: url_helper
INFO - 2018-03-26 20:26:30 --> Helper loaded: form_helper
INFO - 2018-03-26 20:26:30 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:26:30 --> Controller Class Initialized
INFO - 2018-03-26 20:26:30 --> Model Class Initialized
INFO - 2018-03-26 20:26:30 --> Model Class Initialized
INFO - 2018-03-26 20:26:30 --> Model Class Initialized
INFO - 2018-03-26 20:26:30 --> Model Class Initialized
INFO - 2018-03-26 20:26:30 --> Model Class Initialized
INFO - 2018-03-26 20:26:30 --> Model Class Initialized
INFO - 2018-03-26 20:26:30 --> Model Class Initialized
INFO - 2018-03-26 20:26:30 --> Helper loaded: date_helper
INFO - 2018-03-26 20:26:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:26:33 --> Config Class Initialized
INFO - 2018-03-26 20:26:33 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:26:33 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:26:33 --> Utf8 Class Initialized
INFO - 2018-03-26 20:26:33 --> URI Class Initialized
INFO - 2018-03-26 20:26:33 --> Router Class Initialized
INFO - 2018-03-26 20:26:33 --> Output Class Initialized
INFO - 2018-03-26 20:26:33 --> Security Class Initialized
DEBUG - 2018-03-26 20:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:26:33 --> Input Class Initialized
INFO - 2018-03-26 20:26:33 --> Language Class Initialized
INFO - 2018-03-26 20:26:33 --> Loader Class Initialized
INFO - 2018-03-26 20:26:33 --> Helper loaded: url_helper
INFO - 2018-03-26 20:26:33 --> Helper loaded: form_helper
INFO - 2018-03-26 20:26:33 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:26:33 --> Controller Class Initialized
INFO - 2018-03-26 20:26:33 --> Model Class Initialized
INFO - 2018-03-26 20:26:33 --> Model Class Initialized
INFO - 2018-03-26 20:26:33 --> Model Class Initialized
INFO - 2018-03-26 20:26:33 --> Model Class Initialized
INFO - 2018-03-26 20:26:33 --> Model Class Initialized
INFO - 2018-03-26 20:26:33 --> Model Class Initialized
INFO - 2018-03-26 20:26:33 --> Model Class Initialized
INFO - 2018-03-26 20:26:33 --> Helper loaded: date_helper
INFO - 2018-03-26 20:26:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:26:40 --> Config Class Initialized
INFO - 2018-03-26 20:26:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:26:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:26:40 --> Utf8 Class Initialized
INFO - 2018-03-26 20:26:40 --> URI Class Initialized
INFO - 2018-03-26 20:26:40 --> Router Class Initialized
INFO - 2018-03-26 20:26:40 --> Output Class Initialized
INFO - 2018-03-26 20:26:40 --> Security Class Initialized
DEBUG - 2018-03-26 20:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:26:40 --> Input Class Initialized
INFO - 2018-03-26 20:26:40 --> Language Class Initialized
INFO - 2018-03-26 20:26:40 --> Loader Class Initialized
INFO - 2018-03-26 20:26:40 --> Helper loaded: url_helper
INFO - 2018-03-26 20:26:40 --> Helper loaded: form_helper
INFO - 2018-03-26 20:26:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:26:40 --> Controller Class Initialized
INFO - 2018-03-26 20:26:40 --> Model Class Initialized
INFO - 2018-03-26 20:26:40 --> Model Class Initialized
INFO - 2018-03-26 20:26:40 --> Model Class Initialized
INFO - 2018-03-26 20:26:40 --> Model Class Initialized
INFO - 2018-03-26 20:26:40 --> Model Class Initialized
INFO - 2018-03-26 20:26:40 --> Model Class Initialized
INFO - 2018-03-26 20:26:40 --> Model Class Initialized
INFO - 2018-03-26 20:26:40 --> Model Class Initialized
INFO - 2018-03-26 20:26:40 --> Model Class Initialized
INFO - 2018-03-26 20:26:40 --> Model Class Initialized
INFO - 2018-03-26 20:26:40 --> Model Class Initialized
INFO - 2018-03-26 20:26:40 --> Model Class Initialized
INFO - 2018-03-26 20:26:40 --> Helper loaded: date_helper
INFO - 2018-03-26 20:26:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:26:44 --> Config Class Initialized
INFO - 2018-03-26 20:26:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:26:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:26:44 --> Utf8 Class Initialized
INFO - 2018-03-26 20:26:44 --> URI Class Initialized
INFO - 2018-03-26 20:26:44 --> Router Class Initialized
INFO - 2018-03-26 20:26:44 --> Output Class Initialized
INFO - 2018-03-26 20:26:44 --> Security Class Initialized
DEBUG - 2018-03-26 20:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:26:44 --> Input Class Initialized
INFO - 2018-03-26 20:26:44 --> Language Class Initialized
INFO - 2018-03-26 20:26:44 --> Loader Class Initialized
INFO - 2018-03-26 20:26:44 --> Helper loaded: url_helper
INFO - 2018-03-26 20:26:44 --> Helper loaded: form_helper
INFO - 2018-03-26 20:26:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:26:44 --> Controller Class Initialized
INFO - 2018-03-26 20:26:44 --> Model Class Initialized
INFO - 2018-03-26 20:26:44 --> Model Class Initialized
INFO - 2018-03-26 20:26:44 --> Model Class Initialized
INFO - 2018-03-26 20:26:44 --> Model Class Initialized
INFO - 2018-03-26 20:26:44 --> Model Class Initialized
INFO - 2018-03-26 20:26:44 --> Model Class Initialized
INFO - 2018-03-26 20:26:44 --> Model Class Initialized
INFO - 2018-03-26 20:26:44 --> Model Class Initialized
INFO - 2018-03-26 20:26:44 --> Model Class Initialized
INFO - 2018-03-26 20:26:44 --> Model Class Initialized
INFO - 2018-03-26 20:26:44 --> Model Class Initialized
INFO - 2018-03-26 20:26:44 --> Model Class Initialized
INFO - 2018-03-26 20:26:44 --> Helper loaded: date_helper
INFO - 2018-03-26 20:26:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:26:45 --> Config Class Initialized
INFO - 2018-03-26 20:26:45 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:26:45 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:26:45 --> Utf8 Class Initialized
INFO - 2018-03-26 20:26:45 --> URI Class Initialized
INFO - 2018-03-26 20:26:45 --> Router Class Initialized
INFO - 2018-03-26 20:26:45 --> Output Class Initialized
INFO - 2018-03-26 20:26:45 --> Security Class Initialized
DEBUG - 2018-03-26 20:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:26:45 --> Input Class Initialized
INFO - 2018-03-26 20:26:45 --> Language Class Initialized
INFO - 2018-03-26 20:26:45 --> Loader Class Initialized
INFO - 2018-03-26 20:26:45 --> Helper loaded: url_helper
INFO - 2018-03-26 20:26:45 --> Helper loaded: form_helper
INFO - 2018-03-26 20:26:45 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:26:45 --> Controller Class Initialized
INFO - 2018-03-26 20:26:45 --> Model Class Initialized
INFO - 2018-03-26 20:26:45 --> Model Class Initialized
INFO - 2018-03-26 20:26:45 --> Model Class Initialized
INFO - 2018-03-26 20:26:45 --> Model Class Initialized
INFO - 2018-03-26 20:26:45 --> Model Class Initialized
INFO - 2018-03-26 20:26:45 --> Model Class Initialized
INFO - 2018-03-26 20:26:45 --> Model Class Initialized
INFO - 2018-03-26 20:26:45 --> Model Class Initialized
INFO - 2018-03-26 20:26:45 --> Model Class Initialized
INFO - 2018-03-26 20:26:45 --> Model Class Initialized
INFO - 2018-03-26 20:26:45 --> Model Class Initialized
INFO - 2018-03-26 20:26:45 --> Model Class Initialized
INFO - 2018-03-26 20:26:45 --> Helper loaded: date_helper
INFO - 2018-03-26 20:26:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:27:13 --> Config Class Initialized
INFO - 2018-03-26 20:27:13 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:27:13 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:27:13 --> Utf8 Class Initialized
INFO - 2018-03-26 20:27:13 --> URI Class Initialized
INFO - 2018-03-26 20:27:13 --> Router Class Initialized
INFO - 2018-03-26 20:27:13 --> Output Class Initialized
INFO - 2018-03-26 20:27:13 --> Security Class Initialized
DEBUG - 2018-03-26 20:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:27:13 --> Input Class Initialized
INFO - 2018-03-26 20:27:13 --> Language Class Initialized
INFO - 2018-03-26 20:27:13 --> Loader Class Initialized
INFO - 2018-03-26 20:27:13 --> Helper loaded: url_helper
INFO - 2018-03-26 20:27:13 --> Helper loaded: form_helper
INFO - 2018-03-26 20:27:13 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:27:13 --> Controller Class Initialized
INFO - 2018-03-26 20:27:13 --> Model Class Initialized
INFO - 2018-03-26 20:27:13 --> Model Class Initialized
INFO - 2018-03-26 20:27:13 --> Model Class Initialized
INFO - 2018-03-26 20:27:13 --> Model Class Initialized
INFO - 2018-03-26 20:27:13 --> Model Class Initialized
INFO - 2018-03-26 20:27:13 --> Model Class Initialized
INFO - 2018-03-26 20:27:13 --> Model Class Initialized
INFO - 2018-03-26 20:27:13 --> Model Class Initialized
INFO - 2018-03-26 20:27:13 --> Model Class Initialized
INFO - 2018-03-26 20:27:13 --> Model Class Initialized
INFO - 2018-03-26 20:27:13 --> Model Class Initialized
INFO - 2018-03-26 20:27:13 --> Model Class Initialized
INFO - 2018-03-26 20:27:13 --> Helper loaded: date_helper
INFO - 2018-03-26 20:27:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:27:17 --> Config Class Initialized
INFO - 2018-03-26 20:27:17 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:27:17 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:27:17 --> Utf8 Class Initialized
INFO - 2018-03-26 20:27:17 --> URI Class Initialized
INFO - 2018-03-26 20:27:17 --> Router Class Initialized
INFO - 2018-03-26 20:27:17 --> Output Class Initialized
INFO - 2018-03-26 20:27:17 --> Security Class Initialized
DEBUG - 2018-03-26 20:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:27:17 --> Input Class Initialized
INFO - 2018-03-26 20:27:17 --> Language Class Initialized
INFO - 2018-03-26 20:27:17 --> Loader Class Initialized
INFO - 2018-03-26 20:27:17 --> Helper loaded: url_helper
INFO - 2018-03-26 20:27:17 --> Helper loaded: form_helper
INFO - 2018-03-26 20:27:17 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:27:17 --> Controller Class Initialized
INFO - 2018-03-26 20:27:17 --> Model Class Initialized
INFO - 2018-03-26 20:27:17 --> Model Class Initialized
INFO - 2018-03-26 20:27:17 --> Model Class Initialized
INFO - 2018-03-26 20:27:17 --> Model Class Initialized
INFO - 2018-03-26 20:27:17 --> Model Class Initialized
INFO - 2018-03-26 20:27:17 --> Model Class Initialized
INFO - 2018-03-26 20:27:17 --> Model Class Initialized
INFO - 2018-03-26 20:27:17 --> Model Class Initialized
INFO - 2018-03-26 20:27:17 --> Model Class Initialized
INFO - 2018-03-26 20:27:17 --> Model Class Initialized
INFO - 2018-03-26 20:27:17 --> Model Class Initialized
INFO - 2018-03-26 20:27:17 --> Model Class Initialized
INFO - 2018-03-26 20:27:17 --> Helper loaded: date_helper
INFO - 2018-03-26 20:27:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:27:20 --> Config Class Initialized
INFO - 2018-03-26 20:27:20 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:27:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:27:20 --> Utf8 Class Initialized
INFO - 2018-03-26 20:27:20 --> URI Class Initialized
INFO - 2018-03-26 20:27:20 --> Router Class Initialized
INFO - 2018-03-26 20:27:20 --> Output Class Initialized
INFO - 2018-03-26 20:27:20 --> Security Class Initialized
DEBUG - 2018-03-26 20:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:27:20 --> Input Class Initialized
INFO - 2018-03-26 20:27:20 --> Language Class Initialized
INFO - 2018-03-26 20:27:20 --> Loader Class Initialized
INFO - 2018-03-26 20:27:20 --> Helper loaded: url_helper
INFO - 2018-03-26 20:27:20 --> Helper loaded: form_helper
INFO - 2018-03-26 20:27:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:27:20 --> Controller Class Initialized
INFO - 2018-03-26 20:27:20 --> Model Class Initialized
INFO - 2018-03-26 20:27:20 --> Model Class Initialized
INFO - 2018-03-26 20:27:20 --> Model Class Initialized
INFO - 2018-03-26 20:27:20 --> Model Class Initialized
INFO - 2018-03-26 20:27:20 --> Model Class Initialized
INFO - 2018-03-26 20:27:20 --> Model Class Initialized
INFO - 2018-03-26 20:27:20 --> Model Class Initialized
INFO - 2018-03-26 20:27:20 --> Model Class Initialized
INFO - 2018-03-26 20:27:20 --> Model Class Initialized
INFO - 2018-03-26 20:27:20 --> Model Class Initialized
INFO - 2018-03-26 20:27:20 --> Model Class Initialized
INFO - 2018-03-26 20:27:20 --> Model Class Initialized
INFO - 2018-03-26 20:27:20 --> Helper loaded: date_helper
INFO - 2018-03-26 20:27:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:27:31 --> Config Class Initialized
INFO - 2018-03-26 20:27:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:27:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:27:31 --> Utf8 Class Initialized
INFO - 2018-03-26 20:27:31 --> URI Class Initialized
INFO - 2018-03-26 20:27:31 --> Router Class Initialized
INFO - 2018-03-26 20:27:31 --> Output Class Initialized
INFO - 2018-03-26 20:27:31 --> Security Class Initialized
DEBUG - 2018-03-26 20:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:27:31 --> Input Class Initialized
INFO - 2018-03-26 20:27:31 --> Language Class Initialized
INFO - 2018-03-26 20:27:31 --> Loader Class Initialized
INFO - 2018-03-26 20:27:31 --> Helper loaded: url_helper
INFO - 2018-03-26 20:27:31 --> Helper loaded: form_helper
INFO - 2018-03-26 20:27:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:27:31 --> Controller Class Initialized
INFO - 2018-03-26 20:27:31 --> Model Class Initialized
INFO - 2018-03-26 20:27:31 --> Model Class Initialized
INFO - 2018-03-26 20:27:31 --> Model Class Initialized
INFO - 2018-03-26 20:27:31 --> Model Class Initialized
INFO - 2018-03-26 20:27:31 --> Model Class Initialized
INFO - 2018-03-26 20:27:31 --> Model Class Initialized
INFO - 2018-03-26 20:27:31 --> Model Class Initialized
INFO - 2018-03-26 20:27:31 --> Model Class Initialized
INFO - 2018-03-26 20:27:31 --> Model Class Initialized
INFO - 2018-03-26 20:27:31 --> Model Class Initialized
INFO - 2018-03-26 20:27:31 --> Model Class Initialized
INFO - 2018-03-26 20:27:31 --> Model Class Initialized
INFO - 2018-03-26 20:27:31 --> Helper loaded: date_helper
INFO - 2018-03-26 20:27:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:28:04 --> Config Class Initialized
INFO - 2018-03-26 20:28:04 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:28:04 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:28:04 --> Utf8 Class Initialized
INFO - 2018-03-26 20:28:04 --> URI Class Initialized
INFO - 2018-03-26 20:28:04 --> Router Class Initialized
INFO - 2018-03-26 20:28:04 --> Output Class Initialized
INFO - 2018-03-26 20:28:04 --> Security Class Initialized
DEBUG - 2018-03-26 20:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:28:04 --> Input Class Initialized
INFO - 2018-03-26 20:28:04 --> Language Class Initialized
INFO - 2018-03-26 20:28:04 --> Loader Class Initialized
INFO - 2018-03-26 20:28:04 --> Helper loaded: url_helper
INFO - 2018-03-26 20:28:04 --> Helper loaded: form_helper
INFO - 2018-03-26 20:28:04 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:28:04 --> Controller Class Initialized
INFO - 2018-03-26 20:28:04 --> Model Class Initialized
INFO - 2018-03-26 20:28:04 --> Model Class Initialized
INFO - 2018-03-26 20:28:04 --> Model Class Initialized
INFO - 2018-03-26 20:28:04 --> Model Class Initialized
INFO - 2018-03-26 20:28:04 --> Model Class Initialized
INFO - 2018-03-26 20:28:04 --> Model Class Initialized
INFO - 2018-03-26 20:28:04 --> Model Class Initialized
INFO - 2018-03-26 20:28:04 --> Model Class Initialized
INFO - 2018-03-26 20:28:04 --> Model Class Initialized
INFO - 2018-03-26 20:28:04 --> Model Class Initialized
INFO - 2018-03-26 20:28:04 --> Model Class Initialized
INFO - 2018-03-26 20:28:04 --> Model Class Initialized
INFO - 2018-03-26 20:28:04 --> Helper loaded: date_helper
INFO - 2018-03-26 20:28:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:28:59 --> Config Class Initialized
INFO - 2018-03-26 20:28:59 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:28:59 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:28:59 --> Utf8 Class Initialized
INFO - 2018-03-26 20:28:59 --> URI Class Initialized
INFO - 2018-03-26 20:28:59 --> Router Class Initialized
INFO - 2018-03-26 20:28:59 --> Output Class Initialized
INFO - 2018-03-26 20:28:59 --> Security Class Initialized
DEBUG - 2018-03-26 20:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:28:59 --> Input Class Initialized
INFO - 2018-03-26 20:28:59 --> Language Class Initialized
INFO - 2018-03-26 20:28:59 --> Loader Class Initialized
INFO - 2018-03-26 20:28:59 --> Helper loaded: url_helper
INFO - 2018-03-26 20:28:59 --> Helper loaded: form_helper
INFO - 2018-03-26 20:28:59 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:28:59 --> Controller Class Initialized
INFO - 2018-03-26 20:28:59 --> Model Class Initialized
INFO - 2018-03-26 20:28:59 --> Model Class Initialized
INFO - 2018-03-26 20:28:59 --> Model Class Initialized
INFO - 2018-03-26 20:28:59 --> Model Class Initialized
INFO - 2018-03-26 20:28:59 --> Model Class Initialized
INFO - 2018-03-26 20:28:59 --> Model Class Initialized
INFO - 2018-03-26 20:28:59 --> Model Class Initialized
INFO - 2018-03-26 20:28:59 --> Model Class Initialized
INFO - 2018-03-26 20:28:59 --> Model Class Initialized
INFO - 2018-03-26 20:28:59 --> Model Class Initialized
INFO - 2018-03-26 20:28:59 --> Model Class Initialized
INFO - 2018-03-26 20:28:59 --> Model Class Initialized
INFO - 2018-03-26 20:28:59 --> Helper loaded: date_helper
INFO - 2018-03-26 20:28:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:29:11 --> Config Class Initialized
INFO - 2018-03-26 20:29:11 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:29:11 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:29:11 --> Utf8 Class Initialized
INFO - 2018-03-26 20:29:11 --> URI Class Initialized
INFO - 2018-03-26 20:29:11 --> Router Class Initialized
INFO - 2018-03-26 20:29:11 --> Output Class Initialized
INFO - 2018-03-26 20:29:11 --> Security Class Initialized
DEBUG - 2018-03-26 20:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:29:11 --> Input Class Initialized
INFO - 2018-03-26 20:29:11 --> Language Class Initialized
INFO - 2018-03-26 20:29:11 --> Loader Class Initialized
INFO - 2018-03-26 20:29:11 --> Helper loaded: url_helper
INFO - 2018-03-26 20:29:11 --> Helper loaded: form_helper
INFO - 2018-03-26 20:29:11 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:29:11 --> Controller Class Initialized
INFO - 2018-03-26 20:29:11 --> Model Class Initialized
INFO - 2018-03-26 20:29:11 --> Model Class Initialized
INFO - 2018-03-26 20:29:11 --> Model Class Initialized
INFO - 2018-03-26 20:29:11 --> Model Class Initialized
INFO - 2018-03-26 20:29:11 --> Model Class Initialized
INFO - 2018-03-26 20:29:11 --> Model Class Initialized
INFO - 2018-03-26 20:29:11 --> Model Class Initialized
INFO - 2018-03-26 20:29:11 --> Model Class Initialized
INFO - 2018-03-26 20:29:11 --> Model Class Initialized
INFO - 2018-03-26 20:29:11 --> Model Class Initialized
INFO - 2018-03-26 20:29:11 --> Model Class Initialized
INFO - 2018-03-26 20:29:11 --> Model Class Initialized
INFO - 2018-03-26 20:29:11 --> Helper loaded: date_helper
INFO - 2018-03-26 20:29:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:30:31 --> Config Class Initialized
INFO - 2018-03-26 20:30:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:30:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:30:31 --> Utf8 Class Initialized
INFO - 2018-03-26 20:30:31 --> URI Class Initialized
INFO - 2018-03-26 20:30:31 --> Router Class Initialized
INFO - 2018-03-26 20:30:31 --> Output Class Initialized
INFO - 2018-03-26 20:30:31 --> Security Class Initialized
DEBUG - 2018-03-26 20:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:30:31 --> Input Class Initialized
INFO - 2018-03-26 20:30:31 --> Language Class Initialized
INFO - 2018-03-26 20:30:31 --> Loader Class Initialized
INFO - 2018-03-26 20:30:31 --> Helper loaded: url_helper
INFO - 2018-03-26 20:30:31 --> Helper loaded: form_helper
INFO - 2018-03-26 20:30:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:30:31 --> Controller Class Initialized
INFO - 2018-03-26 20:30:31 --> Model Class Initialized
INFO - 2018-03-26 20:30:31 --> Model Class Initialized
INFO - 2018-03-26 20:30:31 --> Model Class Initialized
INFO - 2018-03-26 20:30:31 --> Model Class Initialized
INFO - 2018-03-26 20:30:31 --> Model Class Initialized
INFO - 2018-03-26 20:30:31 --> Model Class Initialized
INFO - 2018-03-26 20:30:31 --> Model Class Initialized
INFO - 2018-03-26 20:30:31 --> Model Class Initialized
INFO - 2018-03-26 20:30:31 --> Model Class Initialized
INFO - 2018-03-26 20:30:31 --> Model Class Initialized
INFO - 2018-03-26 20:30:31 --> Model Class Initialized
INFO - 2018-03-26 20:30:31 --> Model Class Initialized
INFO - 2018-03-26 20:30:31 --> Helper loaded: date_helper
INFO - 2018-03-26 20:30:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:31:08 --> Config Class Initialized
INFO - 2018-03-26 20:31:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:31:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:31:08 --> Utf8 Class Initialized
INFO - 2018-03-26 20:31:08 --> URI Class Initialized
INFO - 2018-03-26 20:31:08 --> Router Class Initialized
INFO - 2018-03-26 20:31:08 --> Output Class Initialized
INFO - 2018-03-26 20:31:08 --> Security Class Initialized
DEBUG - 2018-03-26 20:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:31:08 --> Input Class Initialized
INFO - 2018-03-26 20:31:08 --> Language Class Initialized
INFO - 2018-03-26 20:31:08 --> Loader Class Initialized
INFO - 2018-03-26 20:31:08 --> Helper loaded: url_helper
INFO - 2018-03-26 20:31:08 --> Helper loaded: form_helper
INFO - 2018-03-26 20:31:08 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:31:08 --> Controller Class Initialized
INFO - 2018-03-26 20:31:08 --> Model Class Initialized
INFO - 2018-03-26 20:31:08 --> Model Class Initialized
INFO - 2018-03-26 20:31:08 --> Model Class Initialized
INFO - 2018-03-26 20:31:08 --> Model Class Initialized
INFO - 2018-03-26 20:31:08 --> Model Class Initialized
INFO - 2018-03-26 20:31:08 --> Model Class Initialized
INFO - 2018-03-26 20:31:08 --> Model Class Initialized
INFO - 2018-03-26 20:31:08 --> Model Class Initialized
INFO - 2018-03-26 20:31:08 --> Model Class Initialized
INFO - 2018-03-26 20:31:08 --> Model Class Initialized
INFO - 2018-03-26 20:31:08 --> Model Class Initialized
INFO - 2018-03-26 20:31:08 --> Model Class Initialized
INFO - 2018-03-26 20:31:08 --> Helper loaded: date_helper
INFO - 2018-03-26 20:31:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:33:40 --> Config Class Initialized
INFO - 2018-03-26 20:33:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:33:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:33:40 --> Utf8 Class Initialized
INFO - 2018-03-26 20:33:40 --> URI Class Initialized
INFO - 2018-03-26 20:33:40 --> Router Class Initialized
INFO - 2018-03-26 20:33:40 --> Output Class Initialized
INFO - 2018-03-26 20:33:40 --> Security Class Initialized
DEBUG - 2018-03-26 20:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:33:40 --> Input Class Initialized
INFO - 2018-03-26 20:33:40 --> Language Class Initialized
INFO - 2018-03-26 20:33:40 --> Loader Class Initialized
INFO - 2018-03-26 20:33:40 --> Helper loaded: url_helper
INFO - 2018-03-26 20:33:40 --> Helper loaded: form_helper
INFO - 2018-03-26 20:33:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:33:40 --> Controller Class Initialized
INFO - 2018-03-26 20:33:40 --> Model Class Initialized
INFO - 2018-03-26 20:33:40 --> Model Class Initialized
INFO - 2018-03-26 20:33:40 --> Model Class Initialized
INFO - 2018-03-26 20:33:40 --> Model Class Initialized
INFO - 2018-03-26 20:33:40 --> Model Class Initialized
INFO - 2018-03-26 20:33:40 --> Helper loaded: date_helper
INFO - 2018-03-26 20:33:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:33:49 --> Config Class Initialized
INFO - 2018-03-26 20:33:49 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:33:49 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:33:49 --> Utf8 Class Initialized
INFO - 2018-03-26 20:33:49 --> URI Class Initialized
INFO - 2018-03-26 20:33:49 --> Router Class Initialized
INFO - 2018-03-26 20:33:49 --> Output Class Initialized
INFO - 2018-03-26 20:33:49 --> Security Class Initialized
DEBUG - 2018-03-26 20:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:33:49 --> Input Class Initialized
INFO - 2018-03-26 20:33:49 --> Language Class Initialized
INFO - 2018-03-26 20:33:49 --> Loader Class Initialized
INFO - 2018-03-26 20:33:49 --> Helper loaded: url_helper
INFO - 2018-03-26 20:33:49 --> Helper loaded: form_helper
INFO - 2018-03-26 20:33:49 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:33:49 --> Controller Class Initialized
INFO - 2018-03-26 20:33:49 --> Model Class Initialized
INFO - 2018-03-26 20:33:49 --> Model Class Initialized
INFO - 2018-03-26 20:33:49 --> Model Class Initialized
INFO - 2018-03-26 20:33:49 --> Model Class Initialized
INFO - 2018-03-26 20:33:49 --> Model Class Initialized
INFO - 2018-03-26 20:33:49 --> Helper loaded: date_helper
INFO - 2018-03-26 20:33:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:33:50 --> Config Class Initialized
INFO - 2018-03-26 20:33:50 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:33:50 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:33:50 --> Utf8 Class Initialized
INFO - 2018-03-26 20:33:50 --> URI Class Initialized
INFO - 2018-03-26 20:33:50 --> Router Class Initialized
INFO - 2018-03-26 20:33:50 --> Output Class Initialized
INFO - 2018-03-26 20:33:50 --> Security Class Initialized
DEBUG - 2018-03-26 20:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:33:50 --> Input Class Initialized
INFO - 2018-03-26 20:33:50 --> Language Class Initialized
INFO - 2018-03-26 20:33:50 --> Loader Class Initialized
INFO - 2018-03-26 20:33:50 --> Helper loaded: url_helper
INFO - 2018-03-26 20:33:50 --> Helper loaded: form_helper
INFO - 2018-03-26 20:33:50 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:33:50 --> Controller Class Initialized
INFO - 2018-03-26 20:33:50 --> Model Class Initialized
INFO - 2018-03-26 20:33:50 --> Model Class Initialized
INFO - 2018-03-26 20:33:50 --> Model Class Initialized
INFO - 2018-03-26 20:33:50 --> Model Class Initialized
INFO - 2018-03-26 20:33:50 --> Model Class Initialized
INFO - 2018-03-26 20:33:50 --> Helper loaded: date_helper
INFO - 2018-03-26 20:33:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:33:55 --> Config Class Initialized
INFO - 2018-03-26 20:33:55 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:33:55 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:33:55 --> Utf8 Class Initialized
INFO - 2018-03-26 20:33:55 --> URI Class Initialized
INFO - 2018-03-26 20:33:55 --> Router Class Initialized
INFO - 2018-03-26 20:33:55 --> Output Class Initialized
INFO - 2018-03-26 20:33:55 --> Security Class Initialized
DEBUG - 2018-03-26 20:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:33:55 --> Input Class Initialized
INFO - 2018-03-26 20:33:55 --> Language Class Initialized
INFO - 2018-03-26 20:33:55 --> Loader Class Initialized
INFO - 2018-03-26 20:33:55 --> Helper loaded: url_helper
INFO - 2018-03-26 20:33:55 --> Helper loaded: form_helper
INFO - 2018-03-26 20:33:55 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:33:55 --> Controller Class Initialized
INFO - 2018-03-26 20:33:55 --> Model Class Initialized
INFO - 2018-03-26 20:33:55 --> Model Class Initialized
INFO - 2018-03-26 20:33:55 --> Model Class Initialized
INFO - 2018-03-26 20:33:55 --> Model Class Initialized
INFO - 2018-03-26 20:33:55 --> Model Class Initialized
INFO - 2018-03-26 20:33:55 --> Helper loaded: date_helper
INFO - 2018-03-26 20:33:55 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:37:21 --> Config Class Initialized
INFO - 2018-03-26 20:37:21 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:37:21 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:37:21 --> Utf8 Class Initialized
INFO - 2018-03-26 20:37:21 --> URI Class Initialized
INFO - 2018-03-26 20:37:21 --> Router Class Initialized
INFO - 2018-03-26 20:37:21 --> Output Class Initialized
INFO - 2018-03-26 20:37:21 --> Security Class Initialized
DEBUG - 2018-03-26 20:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:37:21 --> Input Class Initialized
INFO - 2018-03-26 20:37:21 --> Language Class Initialized
INFO - 2018-03-26 20:37:21 --> Loader Class Initialized
INFO - 2018-03-26 20:37:21 --> Helper loaded: url_helper
INFO - 2018-03-26 20:37:21 --> Helper loaded: form_helper
INFO - 2018-03-26 20:37:21 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:37:21 --> Controller Class Initialized
INFO - 2018-03-26 20:37:21 --> Model Class Initialized
INFO - 2018-03-26 20:37:21 --> Model Class Initialized
INFO - 2018-03-26 20:37:21 --> Model Class Initialized
INFO - 2018-03-26 20:37:21 --> Model Class Initialized
INFO - 2018-03-26 20:37:21 --> Model Class Initialized
INFO - 2018-03-26 20:37:21 --> Model Class Initialized
INFO - 2018-03-26 20:37:21 --> Model Class Initialized
INFO - 2018-03-26 20:37:21 --> Model Class Initialized
INFO - 2018-03-26 20:37:21 --> Model Class Initialized
INFO - 2018-03-26 20:37:21 --> Model Class Initialized
INFO - 2018-03-26 20:37:21 --> Model Class Initialized
INFO - 2018-03-26 20:37:21 --> Model Class Initialized
INFO - 2018-03-26 20:37:21 --> Model Class Initialized
ERROR - 2018-03-26 20:37:21 --> Severity: error --> Exception: syntax error, unexpected '}' E:\xampp\htdocs\skin_care\application\models\Detail_penjualan_model.php 45
INFO - 2018-03-26 20:37:35 --> Config Class Initialized
INFO - 2018-03-26 20:37:35 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:37:35 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:37:35 --> Utf8 Class Initialized
INFO - 2018-03-26 20:37:35 --> URI Class Initialized
INFO - 2018-03-26 20:37:35 --> Router Class Initialized
INFO - 2018-03-26 20:37:35 --> Output Class Initialized
INFO - 2018-03-26 20:37:35 --> Security Class Initialized
DEBUG - 2018-03-26 20:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:37:35 --> Input Class Initialized
INFO - 2018-03-26 20:37:35 --> Language Class Initialized
INFO - 2018-03-26 20:37:35 --> Loader Class Initialized
INFO - 2018-03-26 20:37:35 --> Helper loaded: url_helper
INFO - 2018-03-26 20:37:35 --> Helper loaded: form_helper
INFO - 2018-03-26 20:37:35 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:37:35 --> Controller Class Initialized
INFO - 2018-03-26 20:37:35 --> Model Class Initialized
INFO - 2018-03-26 20:37:35 --> Model Class Initialized
INFO - 2018-03-26 20:37:35 --> Model Class Initialized
INFO - 2018-03-26 20:37:35 --> Model Class Initialized
INFO - 2018-03-26 20:37:35 --> Model Class Initialized
INFO - 2018-03-26 20:37:35 --> Model Class Initialized
INFO - 2018-03-26 20:37:35 --> Model Class Initialized
INFO - 2018-03-26 20:37:35 --> Model Class Initialized
INFO - 2018-03-26 20:37:35 --> Model Class Initialized
INFO - 2018-03-26 20:37:35 --> Model Class Initialized
INFO - 2018-03-26 20:37:35 --> Model Class Initialized
INFO - 2018-03-26 20:37:35 --> Model Class Initialized
INFO - 2018-03-26 20:37:35 --> Model Class Initialized
INFO - 2018-03-26 20:37:35 --> Model Class Initialized
INFO - 2018-03-26 20:37:35 --> Helper loaded: date_helper
INFO - 2018-03-26 20:37:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:38:33 --> Config Class Initialized
INFO - 2018-03-26 20:38:33 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:38:33 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:38:33 --> Utf8 Class Initialized
INFO - 2018-03-26 20:38:33 --> URI Class Initialized
INFO - 2018-03-26 20:38:33 --> Router Class Initialized
INFO - 2018-03-26 20:38:33 --> Output Class Initialized
INFO - 2018-03-26 20:38:33 --> Security Class Initialized
DEBUG - 2018-03-26 20:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:38:33 --> Input Class Initialized
INFO - 2018-03-26 20:38:33 --> Language Class Initialized
INFO - 2018-03-26 20:38:33 --> Loader Class Initialized
INFO - 2018-03-26 20:38:33 --> Helper loaded: url_helper
INFO - 2018-03-26 20:38:33 --> Helper loaded: form_helper
INFO - 2018-03-26 20:38:33 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:38:33 --> Controller Class Initialized
INFO - 2018-03-26 20:38:33 --> Model Class Initialized
INFO - 2018-03-26 20:38:33 --> Model Class Initialized
INFO - 2018-03-26 20:38:33 --> Model Class Initialized
INFO - 2018-03-26 20:38:33 --> Model Class Initialized
INFO - 2018-03-26 20:38:33 --> Model Class Initialized
INFO - 2018-03-26 20:38:33 --> Model Class Initialized
INFO - 2018-03-26 20:38:34 --> Model Class Initialized
INFO - 2018-03-26 20:38:34 --> Model Class Initialized
INFO - 2018-03-26 20:38:34 --> Model Class Initialized
INFO - 2018-03-26 20:38:34 --> Model Class Initialized
INFO - 2018-03-26 20:38:34 --> Model Class Initialized
INFO - 2018-03-26 20:38:34 --> Model Class Initialized
INFO - 2018-03-26 20:38:34 --> Model Class Initialized
INFO - 2018-03-26 20:38:34 --> Model Class Initialized
INFO - 2018-03-26 20:38:34 --> Helper loaded: date_helper
INFO - 2018-03-26 20:38:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:39:14 --> Config Class Initialized
INFO - 2018-03-26 20:39:14 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:39:14 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:39:14 --> Utf8 Class Initialized
INFO - 2018-03-26 20:39:14 --> URI Class Initialized
INFO - 2018-03-26 20:39:14 --> Router Class Initialized
INFO - 2018-03-26 20:39:14 --> Output Class Initialized
INFO - 2018-03-26 20:39:14 --> Security Class Initialized
DEBUG - 2018-03-26 20:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:39:14 --> Input Class Initialized
INFO - 2018-03-26 20:39:14 --> Language Class Initialized
INFO - 2018-03-26 20:39:14 --> Loader Class Initialized
INFO - 2018-03-26 20:39:14 --> Helper loaded: url_helper
INFO - 2018-03-26 20:39:14 --> Helper loaded: form_helper
INFO - 2018-03-26 20:39:14 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:39:14 --> Controller Class Initialized
INFO - 2018-03-26 20:39:14 --> Model Class Initialized
INFO - 2018-03-26 20:39:14 --> Model Class Initialized
INFO - 2018-03-26 20:39:14 --> Model Class Initialized
INFO - 2018-03-26 20:39:14 --> Model Class Initialized
INFO - 2018-03-26 20:39:14 --> Model Class Initialized
INFO - 2018-03-26 20:39:14 --> Model Class Initialized
INFO - 2018-03-26 20:39:14 --> Model Class Initialized
INFO - 2018-03-26 20:39:14 --> Model Class Initialized
INFO - 2018-03-26 20:39:14 --> Model Class Initialized
INFO - 2018-03-26 20:39:14 --> Model Class Initialized
INFO - 2018-03-26 20:39:14 --> Model Class Initialized
INFO - 2018-03-26 20:39:14 --> Model Class Initialized
INFO - 2018-03-26 20:39:14 --> Model Class Initialized
INFO - 2018-03-26 20:39:14 --> Model Class Initialized
INFO - 2018-03-26 20:39:14 --> Helper loaded: date_helper
INFO - 2018-03-26 20:39:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:39:38 --> Config Class Initialized
INFO - 2018-03-26 20:39:38 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:39:38 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:39:38 --> Utf8 Class Initialized
INFO - 2018-03-26 20:39:38 --> URI Class Initialized
INFO - 2018-03-26 20:39:38 --> Router Class Initialized
INFO - 2018-03-26 20:39:38 --> Output Class Initialized
INFO - 2018-03-26 20:39:38 --> Security Class Initialized
DEBUG - 2018-03-26 20:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:39:38 --> Input Class Initialized
INFO - 2018-03-26 20:39:38 --> Language Class Initialized
INFO - 2018-03-26 20:39:38 --> Loader Class Initialized
INFO - 2018-03-26 20:39:38 --> Helper loaded: url_helper
INFO - 2018-03-26 20:39:38 --> Helper loaded: form_helper
INFO - 2018-03-26 20:39:38 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:39:38 --> Controller Class Initialized
INFO - 2018-03-26 20:39:38 --> Model Class Initialized
INFO - 2018-03-26 20:39:38 --> Model Class Initialized
INFO - 2018-03-26 20:39:38 --> Model Class Initialized
INFO - 2018-03-26 20:39:38 --> Model Class Initialized
INFO - 2018-03-26 20:39:38 --> Model Class Initialized
INFO - 2018-03-26 20:39:38 --> Model Class Initialized
INFO - 2018-03-26 20:39:38 --> Model Class Initialized
INFO - 2018-03-26 20:39:38 --> Model Class Initialized
INFO - 2018-03-26 20:39:38 --> Model Class Initialized
INFO - 2018-03-26 20:39:38 --> Model Class Initialized
INFO - 2018-03-26 20:39:38 --> Model Class Initialized
INFO - 2018-03-26 20:39:38 --> Model Class Initialized
INFO - 2018-03-26 20:39:38 --> Model Class Initialized
INFO - 2018-03-26 20:39:38 --> Model Class Initialized
INFO - 2018-03-26 20:39:38 --> Helper loaded: date_helper
INFO - 2018-03-26 20:39:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:39:40 --> Config Class Initialized
INFO - 2018-03-26 20:39:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:39:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:39:40 --> Utf8 Class Initialized
INFO - 2018-03-26 20:39:40 --> URI Class Initialized
INFO - 2018-03-26 20:39:40 --> Router Class Initialized
INFO - 2018-03-26 20:39:40 --> Output Class Initialized
INFO - 2018-03-26 20:39:40 --> Security Class Initialized
DEBUG - 2018-03-26 20:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:39:40 --> Input Class Initialized
INFO - 2018-03-26 20:39:40 --> Language Class Initialized
INFO - 2018-03-26 20:39:40 --> Loader Class Initialized
INFO - 2018-03-26 20:39:40 --> Helper loaded: url_helper
INFO - 2018-03-26 20:39:40 --> Helper loaded: form_helper
INFO - 2018-03-26 20:39:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:39:40 --> Controller Class Initialized
INFO - 2018-03-26 20:39:40 --> Model Class Initialized
INFO - 2018-03-26 20:39:40 --> Model Class Initialized
INFO - 2018-03-26 20:39:40 --> Model Class Initialized
INFO - 2018-03-26 20:39:40 --> Model Class Initialized
INFO - 2018-03-26 20:39:40 --> Model Class Initialized
INFO - 2018-03-26 20:39:40 --> Model Class Initialized
INFO - 2018-03-26 20:39:40 --> Model Class Initialized
INFO - 2018-03-26 20:39:40 --> Model Class Initialized
INFO - 2018-03-26 20:39:40 --> Model Class Initialized
INFO - 2018-03-26 20:39:40 --> Model Class Initialized
INFO - 2018-03-26 20:39:40 --> Model Class Initialized
INFO - 2018-03-26 20:39:40 --> Model Class Initialized
INFO - 2018-03-26 20:39:40 --> Model Class Initialized
INFO - 2018-03-26 20:39:40 --> Model Class Initialized
INFO - 2018-03-26 20:39:40 --> Helper loaded: date_helper
INFO - 2018-03-26 20:39:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:40:19 --> Config Class Initialized
INFO - 2018-03-26 20:40:19 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:40:19 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:40:19 --> Utf8 Class Initialized
INFO - 2018-03-26 20:40:19 --> URI Class Initialized
INFO - 2018-03-26 20:40:19 --> Router Class Initialized
INFO - 2018-03-26 20:40:19 --> Output Class Initialized
INFO - 2018-03-26 20:40:19 --> Security Class Initialized
DEBUG - 2018-03-26 20:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:40:19 --> Input Class Initialized
INFO - 2018-03-26 20:40:19 --> Language Class Initialized
INFO - 2018-03-26 20:40:19 --> Loader Class Initialized
INFO - 2018-03-26 20:40:19 --> Helper loaded: url_helper
INFO - 2018-03-26 20:40:19 --> Helper loaded: form_helper
INFO - 2018-03-26 20:40:19 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:40:19 --> Controller Class Initialized
INFO - 2018-03-26 20:40:19 --> Model Class Initialized
INFO - 2018-03-26 20:40:19 --> Model Class Initialized
INFO - 2018-03-26 20:40:19 --> Model Class Initialized
INFO - 2018-03-26 20:40:19 --> Model Class Initialized
INFO - 2018-03-26 20:40:19 --> Model Class Initialized
INFO - 2018-03-26 20:40:19 --> Model Class Initialized
INFO - 2018-03-26 20:40:19 --> Model Class Initialized
INFO - 2018-03-26 20:40:19 --> Model Class Initialized
INFO - 2018-03-26 20:40:19 --> Model Class Initialized
INFO - 2018-03-26 20:40:19 --> Model Class Initialized
INFO - 2018-03-26 20:40:19 --> Model Class Initialized
INFO - 2018-03-26 20:40:19 --> Model Class Initialized
INFO - 2018-03-26 20:40:19 --> Model Class Initialized
INFO - 2018-03-26 20:40:19 --> Model Class Initialized
INFO - 2018-03-26 20:40:19 --> Helper loaded: date_helper
INFO - 2018-03-26 20:40:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:40:52 --> Config Class Initialized
INFO - 2018-03-26 20:40:52 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:40:52 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:40:52 --> Utf8 Class Initialized
INFO - 2018-03-26 20:40:52 --> URI Class Initialized
INFO - 2018-03-26 20:40:52 --> Router Class Initialized
INFO - 2018-03-26 20:40:52 --> Output Class Initialized
INFO - 2018-03-26 20:40:52 --> Security Class Initialized
DEBUG - 2018-03-26 20:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:40:52 --> Input Class Initialized
INFO - 2018-03-26 20:40:52 --> Language Class Initialized
INFO - 2018-03-26 20:40:52 --> Loader Class Initialized
INFO - 2018-03-26 20:40:52 --> Helper loaded: url_helper
INFO - 2018-03-26 20:40:52 --> Helper loaded: form_helper
INFO - 2018-03-26 20:40:52 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:40:52 --> Controller Class Initialized
INFO - 2018-03-26 20:40:52 --> Model Class Initialized
INFO - 2018-03-26 20:40:52 --> Model Class Initialized
INFO - 2018-03-26 20:40:52 --> Model Class Initialized
INFO - 2018-03-26 20:40:52 --> Model Class Initialized
INFO - 2018-03-26 20:40:52 --> Model Class Initialized
INFO - 2018-03-26 20:40:52 --> Model Class Initialized
INFO - 2018-03-26 20:40:52 --> Model Class Initialized
INFO - 2018-03-26 20:40:52 --> Model Class Initialized
INFO - 2018-03-26 20:40:52 --> Model Class Initialized
INFO - 2018-03-26 20:40:52 --> Model Class Initialized
INFO - 2018-03-26 20:40:52 --> Model Class Initialized
INFO - 2018-03-26 20:40:52 --> Model Class Initialized
INFO - 2018-03-26 20:40:52 --> Model Class Initialized
INFO - 2018-03-26 20:40:52 --> Model Class Initialized
INFO - 2018-03-26 20:40:52 --> Helper loaded: date_helper
INFO - 2018-03-26 20:40:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:41:29 --> Config Class Initialized
INFO - 2018-03-26 20:41:29 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:41:29 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:41:29 --> Utf8 Class Initialized
INFO - 2018-03-26 20:41:29 --> URI Class Initialized
INFO - 2018-03-26 20:41:29 --> Router Class Initialized
INFO - 2018-03-26 20:41:29 --> Output Class Initialized
INFO - 2018-03-26 20:41:29 --> Security Class Initialized
DEBUG - 2018-03-26 20:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:41:29 --> Input Class Initialized
INFO - 2018-03-26 20:41:29 --> Language Class Initialized
INFO - 2018-03-26 20:41:29 --> Loader Class Initialized
INFO - 2018-03-26 20:41:29 --> Helper loaded: url_helper
INFO - 2018-03-26 20:41:29 --> Helper loaded: form_helper
INFO - 2018-03-26 20:41:29 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:41:29 --> Controller Class Initialized
INFO - 2018-03-26 20:41:29 --> Model Class Initialized
INFO - 2018-03-26 20:41:29 --> Model Class Initialized
INFO - 2018-03-26 20:41:29 --> Model Class Initialized
INFO - 2018-03-26 20:41:29 --> Model Class Initialized
INFO - 2018-03-26 20:41:29 --> Model Class Initialized
INFO - 2018-03-26 20:41:29 --> Model Class Initialized
INFO - 2018-03-26 20:41:29 --> Model Class Initialized
INFO - 2018-03-26 20:41:29 --> Model Class Initialized
INFO - 2018-03-26 20:41:29 --> Model Class Initialized
INFO - 2018-03-26 20:41:29 --> Model Class Initialized
INFO - 2018-03-26 20:41:29 --> Model Class Initialized
INFO - 2018-03-26 20:41:29 --> Model Class Initialized
INFO - 2018-03-26 20:41:29 --> Model Class Initialized
INFO - 2018-03-26 20:41:29 --> Model Class Initialized
INFO - 2018-03-26 20:41:29 --> Model Class Initialized
INFO - 2018-03-26 20:41:29 --> Helper loaded: date_helper
INFO - 2018-03-26 20:41:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:44:26 --> Config Class Initialized
INFO - 2018-03-26 20:44:26 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:44:26 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:44:26 --> Utf8 Class Initialized
INFO - 2018-03-26 20:44:26 --> URI Class Initialized
INFO - 2018-03-26 20:44:26 --> Router Class Initialized
INFO - 2018-03-26 20:44:26 --> Output Class Initialized
INFO - 2018-03-26 20:44:26 --> Security Class Initialized
DEBUG - 2018-03-26 20:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:44:26 --> Input Class Initialized
INFO - 2018-03-26 20:44:26 --> Language Class Initialized
INFO - 2018-03-26 20:44:26 --> Loader Class Initialized
INFO - 2018-03-26 20:44:26 --> Helper loaded: url_helper
INFO - 2018-03-26 20:44:26 --> Helper loaded: form_helper
INFO - 2018-03-26 20:44:26 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:44:26 --> Controller Class Initialized
INFO - 2018-03-26 20:44:26 --> Model Class Initialized
INFO - 2018-03-26 20:44:26 --> Model Class Initialized
INFO - 2018-03-26 20:44:26 --> Model Class Initialized
INFO - 2018-03-26 20:44:26 --> Model Class Initialized
INFO - 2018-03-26 20:44:26 --> Model Class Initialized
INFO - 2018-03-26 20:44:26 --> Model Class Initialized
INFO - 2018-03-26 20:44:26 --> Model Class Initialized
INFO - 2018-03-26 20:44:26 --> Model Class Initialized
INFO - 2018-03-26 20:44:26 --> Model Class Initialized
INFO - 2018-03-26 20:44:26 --> Model Class Initialized
INFO - 2018-03-26 20:44:26 --> Model Class Initialized
INFO - 2018-03-26 20:44:26 --> Model Class Initialized
INFO - 2018-03-26 20:44:26 --> Model Class Initialized
INFO - 2018-03-26 20:44:26 --> Model Class Initialized
INFO - 2018-03-26 20:44:26 --> Model Class Initialized
INFO - 2018-03-26 20:44:26 --> Helper loaded: date_helper
INFO - 2018-03-26 20:44:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:44:33 --> Config Class Initialized
INFO - 2018-03-26 20:44:33 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:44:33 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:44:33 --> Utf8 Class Initialized
INFO - 2018-03-26 20:44:33 --> URI Class Initialized
INFO - 2018-03-26 20:44:33 --> Router Class Initialized
INFO - 2018-03-26 20:44:33 --> Output Class Initialized
INFO - 2018-03-26 20:44:33 --> Security Class Initialized
DEBUG - 2018-03-26 20:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:44:33 --> Input Class Initialized
INFO - 2018-03-26 20:44:33 --> Language Class Initialized
INFO - 2018-03-26 20:44:33 --> Loader Class Initialized
INFO - 2018-03-26 20:44:33 --> Helper loaded: url_helper
INFO - 2018-03-26 20:44:33 --> Helper loaded: form_helper
INFO - 2018-03-26 20:44:33 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:44:33 --> Controller Class Initialized
INFO - 2018-03-26 20:44:33 --> Model Class Initialized
INFO - 2018-03-26 20:44:33 --> Model Class Initialized
INFO - 2018-03-26 20:44:33 --> Model Class Initialized
INFO - 2018-03-26 20:44:33 --> Model Class Initialized
INFO - 2018-03-26 20:44:33 --> Model Class Initialized
INFO - 2018-03-26 20:44:33 --> Model Class Initialized
INFO - 2018-03-26 20:44:33 --> Model Class Initialized
INFO - 2018-03-26 20:44:33 --> Model Class Initialized
INFO - 2018-03-26 20:44:33 --> Model Class Initialized
INFO - 2018-03-26 20:44:33 --> Model Class Initialized
INFO - 2018-03-26 20:44:33 --> Model Class Initialized
INFO - 2018-03-26 20:44:33 --> Model Class Initialized
INFO - 2018-03-26 20:44:33 --> Model Class Initialized
INFO - 2018-03-26 20:44:33 --> Model Class Initialized
INFO - 2018-03-26 20:44:33 --> Model Class Initialized
INFO - 2018-03-26 20:44:33 --> Helper loaded: date_helper
INFO - 2018-03-26 20:44:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:47:20 --> Config Class Initialized
INFO - 2018-03-26 20:47:20 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:47:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:47:20 --> Utf8 Class Initialized
INFO - 2018-03-26 20:47:20 --> URI Class Initialized
INFO - 2018-03-26 20:47:20 --> Router Class Initialized
INFO - 2018-03-26 20:47:20 --> Output Class Initialized
INFO - 2018-03-26 20:47:20 --> Security Class Initialized
DEBUG - 2018-03-26 20:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:47:20 --> Input Class Initialized
INFO - 2018-03-26 20:47:20 --> Language Class Initialized
INFO - 2018-03-26 20:47:20 --> Loader Class Initialized
INFO - 2018-03-26 20:47:20 --> Helper loaded: url_helper
INFO - 2018-03-26 20:47:20 --> Helper loaded: form_helper
INFO - 2018-03-26 20:47:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:47:20 --> Controller Class Initialized
INFO - 2018-03-26 20:47:20 --> Model Class Initialized
INFO - 2018-03-26 20:47:20 --> Model Class Initialized
INFO - 2018-03-26 20:47:20 --> Model Class Initialized
INFO - 2018-03-26 20:47:20 --> Model Class Initialized
INFO - 2018-03-26 20:47:20 --> Model Class Initialized
INFO - 2018-03-26 20:47:20 --> Model Class Initialized
INFO - 2018-03-26 20:47:20 --> Model Class Initialized
INFO - 2018-03-26 20:47:20 --> Model Class Initialized
INFO - 2018-03-26 20:47:20 --> Model Class Initialized
INFO - 2018-03-26 20:47:20 --> Model Class Initialized
INFO - 2018-03-26 20:47:20 --> Model Class Initialized
INFO - 2018-03-26 20:47:20 --> Model Class Initialized
INFO - 2018-03-26 20:47:20 --> Model Class Initialized
INFO - 2018-03-26 20:47:20 --> Model Class Initialized
INFO - 2018-03-26 20:47:20 --> Model Class Initialized
INFO - 2018-03-26 20:47:20 --> Helper loaded: date_helper
INFO - 2018-03-26 20:47:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:48:30 --> Config Class Initialized
INFO - 2018-03-26 20:48:30 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:48:30 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:48:30 --> Utf8 Class Initialized
INFO - 2018-03-26 20:48:30 --> URI Class Initialized
INFO - 2018-03-26 20:48:30 --> Router Class Initialized
INFO - 2018-03-26 20:48:30 --> Output Class Initialized
INFO - 2018-03-26 20:48:30 --> Security Class Initialized
DEBUG - 2018-03-26 20:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:48:30 --> Input Class Initialized
INFO - 2018-03-26 20:48:30 --> Language Class Initialized
INFO - 2018-03-26 20:48:30 --> Loader Class Initialized
INFO - 2018-03-26 20:48:30 --> Helper loaded: url_helper
INFO - 2018-03-26 20:48:30 --> Helper loaded: form_helper
INFO - 2018-03-26 20:48:30 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:48:30 --> Controller Class Initialized
INFO - 2018-03-26 20:48:30 --> Model Class Initialized
INFO - 2018-03-26 20:48:30 --> Model Class Initialized
INFO - 2018-03-26 20:48:30 --> Model Class Initialized
INFO - 2018-03-26 20:48:30 --> Model Class Initialized
INFO - 2018-03-26 20:48:30 --> Model Class Initialized
INFO - 2018-03-26 20:48:30 --> Model Class Initialized
INFO - 2018-03-26 20:48:30 --> Model Class Initialized
INFO - 2018-03-26 20:48:30 --> Model Class Initialized
INFO - 2018-03-26 20:48:30 --> Model Class Initialized
INFO - 2018-03-26 20:48:30 --> Model Class Initialized
INFO - 2018-03-26 20:48:30 --> Model Class Initialized
INFO - 2018-03-26 20:48:30 --> Model Class Initialized
INFO - 2018-03-26 20:48:30 --> Model Class Initialized
INFO - 2018-03-26 20:48:30 --> Model Class Initialized
INFO - 2018-03-26 20:48:30 --> Model Class Initialized
INFO - 2018-03-26 20:48:30 --> Helper loaded: date_helper
INFO - 2018-03-26 20:48:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:49:20 --> Config Class Initialized
INFO - 2018-03-26 20:49:20 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:49:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:49:20 --> Utf8 Class Initialized
INFO - 2018-03-26 20:49:20 --> URI Class Initialized
INFO - 2018-03-26 20:49:20 --> Router Class Initialized
INFO - 2018-03-26 20:49:20 --> Output Class Initialized
INFO - 2018-03-26 20:49:20 --> Security Class Initialized
DEBUG - 2018-03-26 20:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:49:20 --> Input Class Initialized
INFO - 2018-03-26 20:49:20 --> Language Class Initialized
INFO - 2018-03-26 20:49:20 --> Loader Class Initialized
INFO - 2018-03-26 20:49:20 --> Helper loaded: url_helper
INFO - 2018-03-26 20:49:20 --> Helper loaded: form_helper
INFO - 2018-03-26 20:49:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:49:21 --> Controller Class Initialized
INFO - 2018-03-26 20:49:21 --> Model Class Initialized
INFO - 2018-03-26 20:49:21 --> Model Class Initialized
INFO - 2018-03-26 20:49:21 --> Model Class Initialized
INFO - 2018-03-26 20:49:21 --> Model Class Initialized
INFO - 2018-03-26 20:49:21 --> Model Class Initialized
INFO - 2018-03-26 20:49:21 --> Model Class Initialized
INFO - 2018-03-26 20:49:21 --> Model Class Initialized
INFO - 2018-03-26 20:49:21 --> Model Class Initialized
INFO - 2018-03-26 20:49:21 --> Model Class Initialized
INFO - 2018-03-26 20:49:21 --> Model Class Initialized
INFO - 2018-03-26 20:49:21 --> Model Class Initialized
INFO - 2018-03-26 20:49:21 --> Model Class Initialized
INFO - 2018-03-26 20:49:21 --> Model Class Initialized
INFO - 2018-03-26 20:49:21 --> Model Class Initialized
INFO - 2018-03-26 20:49:21 --> Model Class Initialized
INFO - 2018-03-26 20:49:21 --> Helper loaded: date_helper
INFO - 2018-03-26 20:49:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:49:26 --> Config Class Initialized
INFO - 2018-03-26 20:49:26 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:49:26 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:49:26 --> Utf8 Class Initialized
INFO - 2018-03-26 20:49:26 --> URI Class Initialized
INFO - 2018-03-26 20:49:26 --> Router Class Initialized
INFO - 2018-03-26 20:49:26 --> Output Class Initialized
INFO - 2018-03-26 20:49:26 --> Security Class Initialized
DEBUG - 2018-03-26 20:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:49:26 --> Input Class Initialized
INFO - 2018-03-26 20:49:26 --> Language Class Initialized
INFO - 2018-03-26 20:49:26 --> Loader Class Initialized
INFO - 2018-03-26 20:49:26 --> Helper loaded: url_helper
INFO - 2018-03-26 20:49:26 --> Helper loaded: form_helper
INFO - 2018-03-26 20:49:26 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:49:26 --> Controller Class Initialized
INFO - 2018-03-26 20:49:26 --> Model Class Initialized
INFO - 2018-03-26 20:49:26 --> Model Class Initialized
INFO - 2018-03-26 20:49:26 --> Model Class Initialized
INFO - 2018-03-26 20:49:26 --> Model Class Initialized
INFO - 2018-03-26 20:49:26 --> Model Class Initialized
INFO - 2018-03-26 20:49:26 --> Model Class Initialized
INFO - 2018-03-26 20:49:26 --> Model Class Initialized
INFO - 2018-03-26 20:49:26 --> Model Class Initialized
INFO - 2018-03-26 20:49:26 --> Model Class Initialized
INFO - 2018-03-26 20:49:26 --> Model Class Initialized
INFO - 2018-03-26 20:49:26 --> Model Class Initialized
INFO - 2018-03-26 20:49:26 --> Model Class Initialized
INFO - 2018-03-26 20:49:26 --> Model Class Initialized
INFO - 2018-03-26 20:49:26 --> Model Class Initialized
INFO - 2018-03-26 20:49:26 --> Model Class Initialized
INFO - 2018-03-26 20:49:26 --> Helper loaded: date_helper
INFO - 2018-03-26 20:49:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:49:31 --> Config Class Initialized
INFO - 2018-03-26 20:49:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:49:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:49:31 --> Utf8 Class Initialized
INFO - 2018-03-26 20:49:31 --> URI Class Initialized
INFO - 2018-03-26 20:49:31 --> Router Class Initialized
INFO - 2018-03-26 20:49:31 --> Output Class Initialized
INFO - 2018-03-26 20:49:31 --> Security Class Initialized
DEBUG - 2018-03-26 20:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:49:31 --> Input Class Initialized
INFO - 2018-03-26 20:49:31 --> Language Class Initialized
INFO - 2018-03-26 20:49:31 --> Loader Class Initialized
INFO - 2018-03-26 20:49:31 --> Helper loaded: url_helper
INFO - 2018-03-26 20:49:31 --> Helper loaded: form_helper
INFO - 2018-03-26 20:49:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:49:31 --> Controller Class Initialized
INFO - 2018-03-26 20:49:31 --> Model Class Initialized
INFO - 2018-03-26 20:49:31 --> Model Class Initialized
INFO - 2018-03-26 20:49:31 --> Model Class Initialized
INFO - 2018-03-26 20:49:31 --> Model Class Initialized
INFO - 2018-03-26 20:49:31 --> Model Class Initialized
INFO - 2018-03-26 20:49:31 --> Model Class Initialized
INFO - 2018-03-26 20:49:31 --> Model Class Initialized
INFO - 2018-03-26 20:49:31 --> Model Class Initialized
INFO - 2018-03-26 20:49:31 --> Model Class Initialized
INFO - 2018-03-26 20:49:31 --> Model Class Initialized
INFO - 2018-03-26 20:49:31 --> Model Class Initialized
INFO - 2018-03-26 20:49:31 --> Model Class Initialized
INFO - 2018-03-26 20:49:31 --> Model Class Initialized
INFO - 2018-03-26 20:49:31 --> Model Class Initialized
INFO - 2018-03-26 20:49:31 --> Model Class Initialized
INFO - 2018-03-26 20:49:31 --> Helper loaded: date_helper
INFO - 2018-03-26 20:49:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:50:09 --> Config Class Initialized
INFO - 2018-03-26 20:50:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:50:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:50:09 --> Utf8 Class Initialized
INFO - 2018-03-26 20:50:09 --> URI Class Initialized
INFO - 2018-03-26 20:50:09 --> Router Class Initialized
INFO - 2018-03-26 20:50:09 --> Output Class Initialized
INFO - 2018-03-26 20:50:09 --> Security Class Initialized
DEBUG - 2018-03-26 20:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:50:09 --> Input Class Initialized
INFO - 2018-03-26 20:50:09 --> Language Class Initialized
INFO - 2018-03-26 20:50:09 --> Loader Class Initialized
INFO - 2018-03-26 20:50:09 --> Helper loaded: url_helper
INFO - 2018-03-26 20:50:09 --> Helper loaded: form_helper
INFO - 2018-03-26 20:50:09 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:50:09 --> Controller Class Initialized
INFO - 2018-03-26 20:50:09 --> Model Class Initialized
INFO - 2018-03-26 20:50:09 --> Model Class Initialized
INFO - 2018-03-26 20:50:09 --> Model Class Initialized
INFO - 2018-03-26 20:50:09 --> Model Class Initialized
INFO - 2018-03-26 20:50:09 --> Model Class Initialized
INFO - 2018-03-26 20:50:09 --> Model Class Initialized
INFO - 2018-03-26 20:50:09 --> Model Class Initialized
INFO - 2018-03-26 20:50:09 --> Model Class Initialized
INFO - 2018-03-26 20:50:09 --> Model Class Initialized
INFO - 2018-03-26 20:50:09 --> Model Class Initialized
INFO - 2018-03-26 20:50:09 --> Model Class Initialized
INFO - 2018-03-26 20:50:09 --> Model Class Initialized
INFO - 2018-03-26 20:50:09 --> Model Class Initialized
INFO - 2018-03-26 20:50:09 --> Model Class Initialized
INFO - 2018-03-26 20:50:09 --> Model Class Initialized
INFO - 2018-03-26 20:50:09 --> Helper loaded: date_helper
INFO - 2018-03-26 20:50:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:50:35 --> Config Class Initialized
INFO - 2018-03-26 20:50:35 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:50:35 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:50:35 --> Utf8 Class Initialized
INFO - 2018-03-26 20:50:35 --> URI Class Initialized
INFO - 2018-03-26 20:50:35 --> Router Class Initialized
INFO - 2018-03-26 20:50:35 --> Output Class Initialized
INFO - 2018-03-26 20:50:35 --> Security Class Initialized
DEBUG - 2018-03-26 20:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:50:35 --> Input Class Initialized
INFO - 2018-03-26 20:50:35 --> Language Class Initialized
INFO - 2018-03-26 20:50:35 --> Loader Class Initialized
INFO - 2018-03-26 20:50:35 --> Helper loaded: url_helper
INFO - 2018-03-26 20:50:35 --> Helper loaded: form_helper
INFO - 2018-03-26 20:50:35 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:50:35 --> Controller Class Initialized
INFO - 2018-03-26 20:50:35 --> Model Class Initialized
INFO - 2018-03-26 20:50:35 --> Model Class Initialized
INFO - 2018-03-26 20:50:35 --> Model Class Initialized
INFO - 2018-03-26 20:50:35 --> Model Class Initialized
INFO - 2018-03-26 20:50:35 --> Model Class Initialized
INFO - 2018-03-26 20:50:35 --> Model Class Initialized
INFO - 2018-03-26 20:50:35 --> Model Class Initialized
INFO - 2018-03-26 20:50:35 --> Model Class Initialized
INFO - 2018-03-26 20:50:35 --> Model Class Initialized
INFO - 2018-03-26 20:50:35 --> Model Class Initialized
INFO - 2018-03-26 20:50:35 --> Model Class Initialized
INFO - 2018-03-26 20:50:35 --> Model Class Initialized
INFO - 2018-03-26 20:50:35 --> Model Class Initialized
INFO - 2018-03-26 20:50:35 --> Model Class Initialized
INFO - 2018-03-26 20:50:35 --> Model Class Initialized
INFO - 2018-03-26 20:50:35 --> Helper loaded: date_helper
INFO - 2018-03-26 20:50:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:50:40 --> Config Class Initialized
INFO - 2018-03-26 20:50:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:50:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:50:40 --> Utf8 Class Initialized
INFO - 2018-03-26 20:50:40 --> URI Class Initialized
INFO - 2018-03-26 20:50:40 --> Router Class Initialized
INFO - 2018-03-26 20:50:40 --> Output Class Initialized
INFO - 2018-03-26 20:50:40 --> Security Class Initialized
DEBUG - 2018-03-26 20:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:50:40 --> Input Class Initialized
INFO - 2018-03-26 20:50:40 --> Language Class Initialized
INFO - 2018-03-26 20:50:40 --> Loader Class Initialized
INFO - 2018-03-26 20:50:40 --> Helper loaded: url_helper
INFO - 2018-03-26 20:50:40 --> Helper loaded: form_helper
INFO - 2018-03-26 20:50:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:50:40 --> Controller Class Initialized
INFO - 2018-03-26 20:50:40 --> Model Class Initialized
INFO - 2018-03-26 20:50:40 --> Model Class Initialized
INFO - 2018-03-26 20:50:40 --> Model Class Initialized
INFO - 2018-03-26 20:50:40 --> Model Class Initialized
INFO - 2018-03-26 20:50:40 --> Model Class Initialized
INFO - 2018-03-26 20:50:40 --> Model Class Initialized
INFO - 2018-03-26 20:50:40 --> Model Class Initialized
INFO - 2018-03-26 20:50:40 --> Model Class Initialized
INFO - 2018-03-26 20:50:40 --> Model Class Initialized
INFO - 2018-03-26 20:50:40 --> Model Class Initialized
INFO - 2018-03-26 20:50:40 --> Model Class Initialized
INFO - 2018-03-26 20:50:40 --> Model Class Initialized
INFO - 2018-03-26 20:50:40 --> Model Class Initialized
INFO - 2018-03-26 20:50:40 --> Model Class Initialized
INFO - 2018-03-26 20:50:40 --> Model Class Initialized
INFO - 2018-03-26 20:50:40 --> Helper loaded: date_helper
INFO - 2018-03-26 20:50:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:51:05 --> Config Class Initialized
INFO - 2018-03-26 20:51:05 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:51:05 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:51:05 --> Utf8 Class Initialized
INFO - 2018-03-26 20:51:05 --> URI Class Initialized
INFO - 2018-03-26 20:51:05 --> Router Class Initialized
INFO - 2018-03-26 20:51:05 --> Output Class Initialized
INFO - 2018-03-26 20:51:05 --> Security Class Initialized
DEBUG - 2018-03-26 20:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:51:05 --> Input Class Initialized
INFO - 2018-03-26 20:51:05 --> Language Class Initialized
INFO - 2018-03-26 20:51:05 --> Loader Class Initialized
INFO - 2018-03-26 20:51:05 --> Helper loaded: url_helper
INFO - 2018-03-26 20:51:05 --> Helper loaded: form_helper
INFO - 2018-03-26 20:51:05 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:51:05 --> Controller Class Initialized
INFO - 2018-03-26 20:51:05 --> Model Class Initialized
INFO - 2018-03-26 20:51:05 --> Model Class Initialized
INFO - 2018-03-26 20:51:05 --> Model Class Initialized
INFO - 2018-03-26 20:51:05 --> Model Class Initialized
INFO - 2018-03-26 20:51:05 --> Model Class Initialized
INFO - 2018-03-26 20:51:05 --> Model Class Initialized
INFO - 2018-03-26 20:51:05 --> Model Class Initialized
INFO - 2018-03-26 20:51:05 --> Model Class Initialized
INFO - 2018-03-26 20:51:05 --> Model Class Initialized
INFO - 2018-03-26 20:51:05 --> Model Class Initialized
INFO - 2018-03-26 20:51:05 --> Model Class Initialized
INFO - 2018-03-26 20:51:05 --> Model Class Initialized
INFO - 2018-03-26 20:51:05 --> Model Class Initialized
INFO - 2018-03-26 20:51:05 --> Model Class Initialized
INFO - 2018-03-26 20:51:05 --> Model Class Initialized
INFO - 2018-03-26 20:51:05 --> Helper loaded: date_helper
INFO - 2018-03-26 20:51:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:52:37 --> Config Class Initialized
INFO - 2018-03-26 20:52:37 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:52:37 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:52:37 --> Utf8 Class Initialized
INFO - 2018-03-26 20:52:37 --> URI Class Initialized
INFO - 2018-03-26 20:52:37 --> Router Class Initialized
INFO - 2018-03-26 20:52:37 --> Output Class Initialized
INFO - 2018-03-26 20:52:37 --> Security Class Initialized
DEBUG - 2018-03-26 20:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:52:37 --> Input Class Initialized
INFO - 2018-03-26 20:52:37 --> Language Class Initialized
INFO - 2018-03-26 20:52:37 --> Loader Class Initialized
INFO - 2018-03-26 20:52:37 --> Helper loaded: url_helper
INFO - 2018-03-26 20:52:37 --> Helper loaded: form_helper
INFO - 2018-03-26 20:52:37 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:52:37 --> Controller Class Initialized
INFO - 2018-03-26 20:52:37 --> Model Class Initialized
INFO - 2018-03-26 20:52:37 --> Model Class Initialized
INFO - 2018-03-26 20:52:37 --> Model Class Initialized
INFO - 2018-03-26 20:52:37 --> Model Class Initialized
INFO - 2018-03-26 20:52:37 --> Model Class Initialized
INFO - 2018-03-26 20:52:37 --> Model Class Initialized
INFO - 2018-03-26 20:52:37 --> Model Class Initialized
INFO - 2018-03-26 20:52:37 --> Model Class Initialized
INFO - 2018-03-26 20:52:37 --> Model Class Initialized
INFO - 2018-03-26 20:52:37 --> Model Class Initialized
INFO - 2018-03-26 20:52:37 --> Model Class Initialized
INFO - 2018-03-26 20:52:37 --> Model Class Initialized
INFO - 2018-03-26 20:52:37 --> Model Class Initialized
INFO - 2018-03-26 20:52:37 --> Model Class Initialized
INFO - 2018-03-26 20:52:37 --> Model Class Initialized
INFO - 2018-03-26 20:52:37 --> Helper loaded: date_helper
INFO - 2018-03-26 20:52:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:52:59 --> Config Class Initialized
INFO - 2018-03-26 20:52:59 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:52:59 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:52:59 --> Utf8 Class Initialized
INFO - 2018-03-26 20:52:59 --> URI Class Initialized
INFO - 2018-03-26 20:52:59 --> Router Class Initialized
INFO - 2018-03-26 20:52:59 --> Output Class Initialized
INFO - 2018-03-26 20:52:59 --> Security Class Initialized
DEBUG - 2018-03-26 20:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:52:59 --> Input Class Initialized
INFO - 2018-03-26 20:52:59 --> Language Class Initialized
INFO - 2018-03-26 20:52:59 --> Loader Class Initialized
INFO - 2018-03-26 20:52:59 --> Helper loaded: url_helper
INFO - 2018-03-26 20:52:59 --> Helper loaded: form_helper
INFO - 2018-03-26 20:52:59 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:52:59 --> Controller Class Initialized
INFO - 2018-03-26 20:52:59 --> Model Class Initialized
INFO - 2018-03-26 20:52:59 --> Model Class Initialized
INFO - 2018-03-26 20:52:59 --> Model Class Initialized
INFO - 2018-03-26 20:52:59 --> Model Class Initialized
INFO - 2018-03-26 20:52:59 --> Model Class Initialized
INFO - 2018-03-26 20:52:59 --> Model Class Initialized
INFO - 2018-03-26 20:52:59 --> Model Class Initialized
INFO - 2018-03-26 20:52:59 --> Model Class Initialized
INFO - 2018-03-26 20:52:59 --> Model Class Initialized
INFO - 2018-03-26 20:52:59 --> Model Class Initialized
INFO - 2018-03-26 20:52:59 --> Model Class Initialized
INFO - 2018-03-26 20:52:59 --> Model Class Initialized
INFO - 2018-03-26 20:52:59 --> Model Class Initialized
INFO - 2018-03-26 20:52:59 --> Model Class Initialized
INFO - 2018-03-26 20:52:59 --> Model Class Initialized
INFO - 2018-03-26 20:52:59 --> Helper loaded: date_helper
INFO - 2018-03-26 20:52:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:53:29 --> Config Class Initialized
INFO - 2018-03-26 20:53:29 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:53:29 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:53:29 --> Utf8 Class Initialized
INFO - 2018-03-26 20:53:29 --> URI Class Initialized
INFO - 2018-03-26 20:53:29 --> Router Class Initialized
INFO - 2018-03-26 20:53:29 --> Output Class Initialized
INFO - 2018-03-26 20:53:29 --> Security Class Initialized
DEBUG - 2018-03-26 20:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:53:29 --> Input Class Initialized
INFO - 2018-03-26 20:53:29 --> Language Class Initialized
INFO - 2018-03-26 20:53:29 --> Loader Class Initialized
INFO - 2018-03-26 20:53:29 --> Helper loaded: url_helper
INFO - 2018-03-26 20:53:29 --> Helper loaded: form_helper
INFO - 2018-03-26 20:53:29 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:53:29 --> Controller Class Initialized
INFO - 2018-03-26 20:53:29 --> Model Class Initialized
INFO - 2018-03-26 20:53:29 --> Model Class Initialized
INFO - 2018-03-26 20:53:29 --> Model Class Initialized
INFO - 2018-03-26 20:53:29 --> Model Class Initialized
INFO - 2018-03-26 20:53:29 --> Model Class Initialized
INFO - 2018-03-26 20:53:29 --> Model Class Initialized
INFO - 2018-03-26 20:53:29 --> Model Class Initialized
INFO - 2018-03-26 20:53:29 --> Model Class Initialized
INFO - 2018-03-26 20:53:29 --> Model Class Initialized
INFO - 2018-03-26 20:53:29 --> Model Class Initialized
INFO - 2018-03-26 20:53:29 --> Model Class Initialized
INFO - 2018-03-26 20:53:29 --> Model Class Initialized
INFO - 2018-03-26 20:53:29 --> Model Class Initialized
INFO - 2018-03-26 20:53:29 --> Model Class Initialized
INFO - 2018-03-26 20:53:29 --> Model Class Initialized
INFO - 2018-03-26 20:53:29 --> Helper loaded: date_helper
INFO - 2018-03-26 20:53:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:53:33 --> Config Class Initialized
INFO - 2018-03-26 20:53:33 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:53:33 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:53:33 --> Utf8 Class Initialized
INFO - 2018-03-26 20:53:33 --> URI Class Initialized
INFO - 2018-03-26 20:53:33 --> Router Class Initialized
INFO - 2018-03-26 20:53:33 --> Output Class Initialized
INFO - 2018-03-26 20:53:33 --> Security Class Initialized
DEBUG - 2018-03-26 20:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:53:33 --> Input Class Initialized
INFO - 2018-03-26 20:53:33 --> Language Class Initialized
INFO - 2018-03-26 20:53:33 --> Loader Class Initialized
INFO - 2018-03-26 20:53:33 --> Helper loaded: url_helper
INFO - 2018-03-26 20:53:33 --> Helper loaded: form_helper
INFO - 2018-03-26 20:53:33 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:53:33 --> Controller Class Initialized
INFO - 2018-03-26 20:53:33 --> Model Class Initialized
INFO - 2018-03-26 20:53:33 --> Model Class Initialized
INFO - 2018-03-26 20:53:33 --> Model Class Initialized
INFO - 2018-03-26 20:53:33 --> Model Class Initialized
INFO - 2018-03-26 20:53:33 --> Model Class Initialized
INFO - 2018-03-26 20:53:33 --> Model Class Initialized
INFO - 2018-03-26 20:53:33 --> Model Class Initialized
INFO - 2018-03-26 20:53:33 --> Model Class Initialized
INFO - 2018-03-26 20:53:33 --> Model Class Initialized
INFO - 2018-03-26 20:53:33 --> Model Class Initialized
INFO - 2018-03-26 20:53:33 --> Model Class Initialized
INFO - 2018-03-26 20:53:33 --> Model Class Initialized
INFO - 2018-03-26 20:53:33 --> Model Class Initialized
INFO - 2018-03-26 20:53:33 --> Model Class Initialized
INFO - 2018-03-26 20:53:33 --> Model Class Initialized
INFO - 2018-03-26 20:53:33 --> Helper loaded: date_helper
INFO - 2018-03-26 20:53:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:53:34 --> Config Class Initialized
INFO - 2018-03-26 20:53:34 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:53:34 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:53:34 --> Utf8 Class Initialized
INFO - 2018-03-26 20:53:34 --> URI Class Initialized
INFO - 2018-03-26 20:53:34 --> Router Class Initialized
INFO - 2018-03-26 20:53:34 --> Output Class Initialized
INFO - 2018-03-26 20:53:34 --> Security Class Initialized
DEBUG - 2018-03-26 20:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:53:34 --> Input Class Initialized
INFO - 2018-03-26 20:53:34 --> Language Class Initialized
INFO - 2018-03-26 20:53:34 --> Loader Class Initialized
INFO - 2018-03-26 20:53:34 --> Helper loaded: url_helper
INFO - 2018-03-26 20:53:34 --> Helper loaded: form_helper
INFO - 2018-03-26 20:53:34 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:53:34 --> Controller Class Initialized
INFO - 2018-03-26 20:53:34 --> Model Class Initialized
INFO - 2018-03-26 20:53:34 --> Model Class Initialized
INFO - 2018-03-26 20:53:34 --> Model Class Initialized
INFO - 2018-03-26 20:53:34 --> Model Class Initialized
INFO - 2018-03-26 20:53:34 --> Model Class Initialized
INFO - 2018-03-26 20:53:34 --> Model Class Initialized
INFO - 2018-03-26 20:53:34 --> Model Class Initialized
INFO - 2018-03-26 20:53:34 --> Model Class Initialized
INFO - 2018-03-26 20:53:34 --> Model Class Initialized
INFO - 2018-03-26 20:53:34 --> Model Class Initialized
INFO - 2018-03-26 20:53:34 --> Model Class Initialized
INFO - 2018-03-26 20:53:34 --> Model Class Initialized
INFO - 2018-03-26 20:53:34 --> Model Class Initialized
INFO - 2018-03-26 20:53:34 --> Model Class Initialized
INFO - 2018-03-26 20:53:34 --> Model Class Initialized
INFO - 2018-03-26 20:53:34 --> Helper loaded: date_helper
INFO - 2018-03-26 20:53:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:55:24 --> Config Class Initialized
INFO - 2018-03-26 20:55:24 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:55:24 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:55:24 --> Utf8 Class Initialized
INFO - 2018-03-26 20:55:24 --> URI Class Initialized
INFO - 2018-03-26 20:55:24 --> Router Class Initialized
INFO - 2018-03-26 20:55:24 --> Output Class Initialized
INFO - 2018-03-26 20:55:24 --> Security Class Initialized
DEBUG - 2018-03-26 20:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:55:24 --> Input Class Initialized
INFO - 2018-03-26 20:55:24 --> Language Class Initialized
INFO - 2018-03-26 20:55:24 --> Loader Class Initialized
INFO - 2018-03-26 20:55:24 --> Helper loaded: url_helper
INFO - 2018-03-26 20:55:24 --> Helper loaded: form_helper
INFO - 2018-03-26 20:55:24 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:55:24 --> Controller Class Initialized
INFO - 2018-03-26 20:55:24 --> Model Class Initialized
INFO - 2018-03-26 20:55:24 --> Model Class Initialized
INFO - 2018-03-26 20:55:24 --> Model Class Initialized
INFO - 2018-03-26 20:55:24 --> Model Class Initialized
INFO - 2018-03-26 20:55:24 --> Model Class Initialized
INFO - 2018-03-26 20:55:24 --> Model Class Initialized
INFO - 2018-03-26 20:55:24 --> Model Class Initialized
INFO - 2018-03-26 20:55:24 --> Model Class Initialized
INFO - 2018-03-26 20:55:24 --> Model Class Initialized
INFO - 2018-03-26 20:55:24 --> Model Class Initialized
INFO - 2018-03-26 20:55:24 --> Model Class Initialized
INFO - 2018-03-26 20:55:24 --> Model Class Initialized
INFO - 2018-03-26 20:55:24 --> Model Class Initialized
INFO - 2018-03-26 20:55:24 --> Model Class Initialized
INFO - 2018-03-26 20:55:24 --> Model Class Initialized
INFO - 2018-03-26 20:55:24 --> Helper loaded: date_helper
INFO - 2018-03-26 20:55:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:55:44 --> Config Class Initialized
INFO - 2018-03-26 20:55:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:55:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:55:44 --> Utf8 Class Initialized
INFO - 2018-03-26 20:55:44 --> URI Class Initialized
INFO - 2018-03-26 20:55:44 --> Router Class Initialized
INFO - 2018-03-26 20:55:44 --> Output Class Initialized
INFO - 2018-03-26 20:55:44 --> Security Class Initialized
DEBUG - 2018-03-26 20:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:55:44 --> Input Class Initialized
INFO - 2018-03-26 20:55:44 --> Language Class Initialized
INFO - 2018-03-26 20:55:44 --> Loader Class Initialized
INFO - 2018-03-26 20:55:44 --> Helper loaded: url_helper
INFO - 2018-03-26 20:55:44 --> Helper loaded: form_helper
INFO - 2018-03-26 20:55:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:55:44 --> Controller Class Initialized
INFO - 2018-03-26 20:55:44 --> Model Class Initialized
INFO - 2018-03-26 20:55:44 --> Model Class Initialized
INFO - 2018-03-26 20:55:44 --> Model Class Initialized
INFO - 2018-03-26 20:55:44 --> Model Class Initialized
INFO - 2018-03-26 20:55:44 --> Model Class Initialized
INFO - 2018-03-26 20:55:44 --> Model Class Initialized
INFO - 2018-03-26 20:55:44 --> Model Class Initialized
INFO - 2018-03-26 20:55:44 --> Model Class Initialized
INFO - 2018-03-26 20:55:44 --> Model Class Initialized
INFO - 2018-03-26 20:55:44 --> Model Class Initialized
INFO - 2018-03-26 20:55:44 --> Model Class Initialized
INFO - 2018-03-26 20:55:44 --> Model Class Initialized
INFO - 2018-03-26 20:55:44 --> Model Class Initialized
INFO - 2018-03-26 20:55:44 --> Model Class Initialized
INFO - 2018-03-26 20:55:44 --> Model Class Initialized
INFO - 2018-03-26 20:55:44 --> Helper loaded: date_helper
INFO - 2018-03-26 20:55:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:56:04 --> Config Class Initialized
INFO - 2018-03-26 20:56:04 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:56:04 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:56:04 --> Utf8 Class Initialized
INFO - 2018-03-26 20:56:04 --> URI Class Initialized
INFO - 2018-03-26 20:56:04 --> Router Class Initialized
INFO - 2018-03-26 20:56:04 --> Output Class Initialized
INFO - 2018-03-26 20:56:04 --> Security Class Initialized
DEBUG - 2018-03-26 20:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:56:04 --> Input Class Initialized
INFO - 2018-03-26 20:56:04 --> Language Class Initialized
INFO - 2018-03-26 20:56:04 --> Loader Class Initialized
INFO - 2018-03-26 20:56:04 --> Helper loaded: url_helper
INFO - 2018-03-26 20:56:04 --> Helper loaded: form_helper
INFO - 2018-03-26 20:56:04 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:56:04 --> Controller Class Initialized
INFO - 2018-03-26 20:56:04 --> Model Class Initialized
INFO - 2018-03-26 20:56:04 --> Model Class Initialized
INFO - 2018-03-26 20:56:04 --> Model Class Initialized
INFO - 2018-03-26 20:56:04 --> Model Class Initialized
INFO - 2018-03-26 20:56:04 --> Model Class Initialized
INFO - 2018-03-26 20:56:04 --> Model Class Initialized
INFO - 2018-03-26 20:56:04 --> Model Class Initialized
INFO - 2018-03-26 20:56:04 --> Model Class Initialized
INFO - 2018-03-26 20:56:04 --> Model Class Initialized
INFO - 2018-03-26 20:56:04 --> Model Class Initialized
INFO - 2018-03-26 20:56:04 --> Model Class Initialized
INFO - 2018-03-26 20:56:04 --> Model Class Initialized
INFO - 2018-03-26 20:56:04 --> Model Class Initialized
INFO - 2018-03-26 20:56:04 --> Model Class Initialized
INFO - 2018-03-26 20:56:04 --> Model Class Initialized
INFO - 2018-03-26 20:56:04 --> Helper loaded: date_helper
INFO - 2018-03-26 20:56:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:56:59 --> Config Class Initialized
INFO - 2018-03-26 20:56:59 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:56:59 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:56:59 --> Utf8 Class Initialized
INFO - 2018-03-26 20:56:59 --> URI Class Initialized
INFO - 2018-03-26 20:56:59 --> Router Class Initialized
INFO - 2018-03-26 20:56:59 --> Output Class Initialized
INFO - 2018-03-26 20:56:59 --> Security Class Initialized
DEBUG - 2018-03-26 20:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:56:59 --> Input Class Initialized
INFO - 2018-03-26 20:56:59 --> Language Class Initialized
INFO - 2018-03-26 20:56:59 --> Loader Class Initialized
INFO - 2018-03-26 20:56:59 --> Helper loaded: url_helper
INFO - 2018-03-26 20:56:59 --> Helper loaded: form_helper
INFO - 2018-03-26 20:56:59 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:56:59 --> Controller Class Initialized
INFO - 2018-03-26 20:56:59 --> Model Class Initialized
INFO - 2018-03-26 20:56:59 --> Model Class Initialized
INFO - 2018-03-26 20:56:59 --> Model Class Initialized
INFO - 2018-03-26 20:56:59 --> Model Class Initialized
INFO - 2018-03-26 20:56:59 --> Model Class Initialized
INFO - 2018-03-26 20:56:59 --> Model Class Initialized
INFO - 2018-03-26 20:56:59 --> Model Class Initialized
INFO - 2018-03-26 20:56:59 --> Model Class Initialized
INFO - 2018-03-26 20:56:59 --> Model Class Initialized
INFO - 2018-03-26 20:56:59 --> Model Class Initialized
INFO - 2018-03-26 20:56:59 --> Model Class Initialized
INFO - 2018-03-26 20:56:59 --> Model Class Initialized
INFO - 2018-03-26 20:56:59 --> Helper loaded: date_helper
INFO - 2018-03-26 20:56:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:57:02 --> Config Class Initialized
INFO - 2018-03-26 20:57:02 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:57:02 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:57:02 --> Utf8 Class Initialized
INFO - 2018-03-26 20:57:02 --> URI Class Initialized
INFO - 2018-03-26 20:57:02 --> Router Class Initialized
INFO - 2018-03-26 20:57:02 --> Output Class Initialized
INFO - 2018-03-26 20:57:02 --> Security Class Initialized
DEBUG - 2018-03-26 20:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:57:02 --> Input Class Initialized
INFO - 2018-03-26 20:57:02 --> Language Class Initialized
INFO - 2018-03-26 20:57:02 --> Loader Class Initialized
INFO - 2018-03-26 20:57:02 --> Helper loaded: url_helper
INFO - 2018-03-26 20:57:02 --> Helper loaded: form_helper
INFO - 2018-03-26 20:57:02 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:57:02 --> Controller Class Initialized
INFO - 2018-03-26 20:57:02 --> Model Class Initialized
INFO - 2018-03-26 20:57:02 --> Model Class Initialized
INFO - 2018-03-26 20:57:02 --> Model Class Initialized
INFO - 2018-03-26 20:57:02 --> Model Class Initialized
INFO - 2018-03-26 20:57:02 --> Model Class Initialized
INFO - 2018-03-26 20:57:02 --> Model Class Initialized
INFO - 2018-03-26 20:57:02 --> Model Class Initialized
INFO - 2018-03-26 20:57:02 --> Model Class Initialized
INFO - 2018-03-26 20:57:02 --> Model Class Initialized
INFO - 2018-03-26 20:57:02 --> Model Class Initialized
INFO - 2018-03-26 20:57:02 --> Model Class Initialized
INFO - 2018-03-26 20:57:02 --> Model Class Initialized
INFO - 2018-03-26 20:57:02 --> Helper loaded: date_helper
INFO - 2018-03-26 20:57:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:57:04 --> Config Class Initialized
INFO - 2018-03-26 20:57:04 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:57:04 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:57:04 --> Utf8 Class Initialized
INFO - 2018-03-26 20:57:04 --> URI Class Initialized
INFO - 2018-03-26 20:57:04 --> Router Class Initialized
INFO - 2018-03-26 20:57:04 --> Output Class Initialized
INFO - 2018-03-26 20:57:04 --> Security Class Initialized
DEBUG - 2018-03-26 20:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:57:04 --> Input Class Initialized
INFO - 2018-03-26 20:57:04 --> Language Class Initialized
INFO - 2018-03-26 20:57:04 --> Loader Class Initialized
INFO - 2018-03-26 20:57:04 --> Helper loaded: url_helper
INFO - 2018-03-26 20:57:04 --> Helper loaded: form_helper
INFO - 2018-03-26 20:57:04 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:57:04 --> Controller Class Initialized
INFO - 2018-03-26 20:57:04 --> Model Class Initialized
INFO - 2018-03-26 20:57:04 --> Model Class Initialized
INFO - 2018-03-26 20:57:04 --> Model Class Initialized
INFO - 2018-03-26 20:57:04 --> Model Class Initialized
INFO - 2018-03-26 20:57:04 --> Model Class Initialized
INFO - 2018-03-26 20:57:04 --> Model Class Initialized
INFO - 2018-03-26 20:57:04 --> Model Class Initialized
INFO - 2018-03-26 20:57:04 --> Model Class Initialized
INFO - 2018-03-26 20:57:04 --> Model Class Initialized
INFO - 2018-03-26 20:57:04 --> Model Class Initialized
INFO - 2018-03-26 20:57:04 --> Model Class Initialized
INFO - 2018-03-26 20:57:04 --> Model Class Initialized
INFO - 2018-03-26 20:57:04 --> Helper loaded: date_helper
INFO - 2018-03-26 20:57:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:57:07 --> Config Class Initialized
INFO - 2018-03-26 20:57:07 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:57:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:57:07 --> Utf8 Class Initialized
INFO - 2018-03-26 20:57:07 --> URI Class Initialized
INFO - 2018-03-26 20:57:07 --> Router Class Initialized
INFO - 2018-03-26 20:57:07 --> Output Class Initialized
INFO - 2018-03-26 20:57:07 --> Security Class Initialized
DEBUG - 2018-03-26 20:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:57:07 --> Input Class Initialized
INFO - 2018-03-26 20:57:07 --> Language Class Initialized
INFO - 2018-03-26 20:57:07 --> Loader Class Initialized
INFO - 2018-03-26 20:57:07 --> Helper loaded: url_helper
INFO - 2018-03-26 20:57:07 --> Helper loaded: form_helper
INFO - 2018-03-26 20:57:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:57:07 --> Controller Class Initialized
INFO - 2018-03-26 20:57:07 --> Model Class Initialized
INFO - 2018-03-26 20:57:07 --> Model Class Initialized
INFO - 2018-03-26 20:57:07 --> Model Class Initialized
INFO - 2018-03-26 20:57:07 --> Model Class Initialized
INFO - 2018-03-26 20:57:07 --> Model Class Initialized
INFO - 2018-03-26 20:57:07 --> Model Class Initialized
INFO - 2018-03-26 20:57:07 --> Model Class Initialized
INFO - 2018-03-26 20:57:07 --> Model Class Initialized
INFO - 2018-03-26 20:57:07 --> Model Class Initialized
INFO - 2018-03-26 20:57:07 --> Model Class Initialized
INFO - 2018-03-26 20:57:07 --> Model Class Initialized
INFO - 2018-03-26 20:57:07 --> Model Class Initialized
INFO - 2018-03-26 20:57:07 --> Helper loaded: date_helper
INFO - 2018-03-26 20:57:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:58:49 --> Config Class Initialized
INFO - 2018-03-26 20:58:49 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:58:49 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:58:49 --> Utf8 Class Initialized
INFO - 2018-03-26 20:58:49 --> URI Class Initialized
INFO - 2018-03-26 20:58:49 --> Router Class Initialized
INFO - 2018-03-26 20:58:49 --> Output Class Initialized
INFO - 2018-03-26 20:58:49 --> Security Class Initialized
DEBUG - 2018-03-26 20:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:58:49 --> Input Class Initialized
INFO - 2018-03-26 20:58:49 --> Language Class Initialized
INFO - 2018-03-26 20:58:49 --> Loader Class Initialized
INFO - 2018-03-26 20:58:49 --> Helper loaded: url_helper
INFO - 2018-03-26 20:58:49 --> Helper loaded: form_helper
INFO - 2018-03-26 20:58:49 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:58:49 --> Controller Class Initialized
INFO - 2018-03-26 20:58:49 --> Model Class Initialized
INFO - 2018-03-26 20:58:49 --> Model Class Initialized
INFO - 2018-03-26 20:58:49 --> Model Class Initialized
INFO - 2018-03-26 20:58:49 --> Model Class Initialized
INFO - 2018-03-26 20:58:49 --> Model Class Initialized
INFO - 2018-03-26 20:58:49 --> Model Class Initialized
INFO - 2018-03-26 20:58:49 --> Model Class Initialized
INFO - 2018-03-26 20:58:49 --> Model Class Initialized
INFO - 2018-03-26 20:58:49 --> Model Class Initialized
INFO - 2018-03-26 20:58:49 --> Model Class Initialized
INFO - 2018-03-26 20:58:49 --> Model Class Initialized
INFO - 2018-03-26 20:58:50 --> Model Class Initialized
INFO - 2018-03-26 20:58:50 --> Model Class Initialized
INFO - 2018-03-26 20:58:50 --> Model Class Initialized
INFO - 2018-03-26 20:58:50 --> Model Class Initialized
INFO - 2018-03-26 20:58:50 --> Helper loaded: date_helper
INFO - 2018-03-26 20:58:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 20:58:53 --> Config Class Initialized
INFO - 2018-03-26 20:58:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 20:58:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 20:58:53 --> Utf8 Class Initialized
INFO - 2018-03-26 20:58:53 --> URI Class Initialized
INFO - 2018-03-26 20:58:53 --> Router Class Initialized
INFO - 2018-03-26 20:58:53 --> Output Class Initialized
INFO - 2018-03-26 20:58:53 --> Security Class Initialized
DEBUG - 2018-03-26 20:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 20:58:53 --> Input Class Initialized
INFO - 2018-03-26 20:58:53 --> Language Class Initialized
INFO - 2018-03-26 20:58:53 --> Loader Class Initialized
INFO - 2018-03-26 20:58:53 --> Helper loaded: url_helper
INFO - 2018-03-26 20:58:53 --> Helper loaded: form_helper
INFO - 2018-03-26 20:58:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 20:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 20:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 20:58:53 --> Controller Class Initialized
INFO - 2018-03-26 20:58:53 --> Model Class Initialized
INFO - 2018-03-26 20:58:53 --> Model Class Initialized
INFO - 2018-03-26 20:58:53 --> Model Class Initialized
INFO - 2018-03-26 20:58:53 --> Model Class Initialized
INFO - 2018-03-26 20:58:54 --> Model Class Initialized
INFO - 2018-03-26 20:58:54 --> Model Class Initialized
INFO - 2018-03-26 20:58:54 --> Model Class Initialized
INFO - 2018-03-26 20:58:54 --> Model Class Initialized
INFO - 2018-03-26 20:58:54 --> Model Class Initialized
INFO - 2018-03-26 20:58:54 --> Model Class Initialized
INFO - 2018-03-26 20:58:54 --> Model Class Initialized
INFO - 2018-03-26 20:58:54 --> Model Class Initialized
INFO - 2018-03-26 20:58:54 --> Model Class Initialized
INFO - 2018-03-26 20:58:54 --> Model Class Initialized
INFO - 2018-03-26 20:58:54 --> Model Class Initialized
INFO - 2018-03-26 20:58:54 --> Helper loaded: date_helper
INFO - 2018-03-26 20:58:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:06:33 --> Config Class Initialized
INFO - 2018-03-26 21:06:33 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:06:33 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:06:33 --> Utf8 Class Initialized
INFO - 2018-03-26 21:06:33 --> URI Class Initialized
INFO - 2018-03-26 21:06:33 --> Router Class Initialized
INFO - 2018-03-26 21:06:33 --> Output Class Initialized
INFO - 2018-03-26 21:06:33 --> Security Class Initialized
DEBUG - 2018-03-26 21:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:06:33 --> Input Class Initialized
INFO - 2018-03-26 21:06:33 --> Language Class Initialized
INFO - 2018-03-26 21:06:33 --> Loader Class Initialized
INFO - 2018-03-26 21:06:33 --> Helper loaded: url_helper
INFO - 2018-03-26 21:06:33 --> Helper loaded: form_helper
INFO - 2018-03-26 21:06:33 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:06:33 --> Controller Class Initialized
INFO - 2018-03-26 21:06:33 --> Model Class Initialized
INFO - 2018-03-26 21:06:33 --> Model Class Initialized
INFO - 2018-03-26 21:06:33 --> Model Class Initialized
INFO - 2018-03-26 21:06:33 --> Model Class Initialized
INFO - 2018-03-26 21:06:33 --> Model Class Initialized
INFO - 2018-03-26 21:06:33 --> Model Class Initialized
INFO - 2018-03-26 21:06:33 --> Model Class Initialized
INFO - 2018-03-26 21:06:33 --> Model Class Initialized
INFO - 2018-03-26 21:06:33 --> Model Class Initialized
INFO - 2018-03-26 21:06:33 --> Model Class Initialized
INFO - 2018-03-26 21:06:33 --> Model Class Initialized
INFO - 2018-03-26 21:06:33 --> Model Class Initialized
INFO - 2018-03-26 21:06:33 --> Model Class Initialized
INFO - 2018-03-26 21:06:33 --> Model Class Initialized
INFO - 2018-03-26 21:06:33 --> Model Class Initialized
INFO - 2018-03-26 21:06:33 --> Helper loaded: date_helper
INFO - 2018-03-26 21:06:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:06:51 --> Config Class Initialized
INFO - 2018-03-26 21:06:51 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:06:51 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:06:51 --> Utf8 Class Initialized
INFO - 2018-03-26 21:06:51 --> URI Class Initialized
INFO - 2018-03-26 21:06:51 --> Router Class Initialized
INFO - 2018-03-26 21:06:51 --> Output Class Initialized
INFO - 2018-03-26 21:06:51 --> Security Class Initialized
DEBUG - 2018-03-26 21:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:06:51 --> Input Class Initialized
INFO - 2018-03-26 21:06:51 --> Language Class Initialized
INFO - 2018-03-26 21:06:51 --> Loader Class Initialized
INFO - 2018-03-26 21:06:51 --> Helper loaded: url_helper
INFO - 2018-03-26 21:06:51 --> Helper loaded: form_helper
INFO - 2018-03-26 21:06:51 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:06:51 --> Controller Class Initialized
INFO - 2018-03-26 21:06:51 --> Model Class Initialized
INFO - 2018-03-26 21:06:51 --> Model Class Initialized
INFO - 2018-03-26 21:06:51 --> Model Class Initialized
INFO - 2018-03-26 21:06:51 --> Model Class Initialized
INFO - 2018-03-26 21:06:51 --> Model Class Initialized
INFO - 2018-03-26 21:06:51 --> Model Class Initialized
INFO - 2018-03-26 21:06:51 --> Model Class Initialized
INFO - 2018-03-26 21:06:51 --> Model Class Initialized
INFO - 2018-03-26 21:06:51 --> Model Class Initialized
INFO - 2018-03-26 21:06:51 --> Model Class Initialized
INFO - 2018-03-26 21:06:51 --> Model Class Initialized
INFO - 2018-03-26 21:06:51 --> Model Class Initialized
INFO - 2018-03-26 21:06:51 --> Model Class Initialized
INFO - 2018-03-26 21:06:51 --> Model Class Initialized
INFO - 2018-03-26 21:06:51 --> Model Class Initialized
INFO - 2018-03-26 21:06:51 --> Helper loaded: date_helper
INFO - 2018-03-26 21:06:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:08:03 --> Config Class Initialized
INFO - 2018-03-26 21:08:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:08:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:08:03 --> Utf8 Class Initialized
INFO - 2018-03-26 21:08:03 --> URI Class Initialized
INFO - 2018-03-26 21:08:03 --> Router Class Initialized
INFO - 2018-03-26 21:08:03 --> Output Class Initialized
INFO - 2018-03-26 21:08:03 --> Security Class Initialized
DEBUG - 2018-03-26 21:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:08:03 --> Input Class Initialized
INFO - 2018-03-26 21:08:03 --> Language Class Initialized
INFO - 2018-03-26 21:08:03 --> Loader Class Initialized
INFO - 2018-03-26 21:08:03 --> Helper loaded: url_helper
INFO - 2018-03-26 21:08:03 --> Helper loaded: form_helper
INFO - 2018-03-26 21:08:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:08:03 --> Controller Class Initialized
INFO - 2018-03-26 21:08:03 --> Model Class Initialized
INFO - 2018-03-26 21:08:03 --> Model Class Initialized
INFO - 2018-03-26 21:08:03 --> Model Class Initialized
INFO - 2018-03-26 21:08:03 --> Model Class Initialized
INFO - 2018-03-26 21:08:03 --> Model Class Initialized
INFO - 2018-03-26 21:08:03 --> Model Class Initialized
INFO - 2018-03-26 21:08:03 --> Model Class Initialized
INFO - 2018-03-26 21:08:03 --> Model Class Initialized
INFO - 2018-03-26 21:08:03 --> Model Class Initialized
INFO - 2018-03-26 21:08:03 --> Model Class Initialized
INFO - 2018-03-26 21:08:03 --> Model Class Initialized
INFO - 2018-03-26 21:08:03 --> Model Class Initialized
INFO - 2018-03-26 21:08:03 --> Model Class Initialized
INFO - 2018-03-26 21:08:03 --> Model Class Initialized
INFO - 2018-03-26 21:08:03 --> Model Class Initialized
INFO - 2018-03-26 21:08:03 --> Helper loaded: date_helper
INFO - 2018-03-26 21:08:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:08:29 --> Config Class Initialized
INFO - 2018-03-26 21:08:29 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:08:29 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:08:29 --> Utf8 Class Initialized
INFO - 2018-03-26 21:08:29 --> URI Class Initialized
INFO - 2018-03-26 21:08:29 --> Router Class Initialized
INFO - 2018-03-26 21:08:29 --> Output Class Initialized
INFO - 2018-03-26 21:08:29 --> Security Class Initialized
DEBUG - 2018-03-26 21:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:08:29 --> Input Class Initialized
INFO - 2018-03-26 21:08:29 --> Language Class Initialized
INFO - 2018-03-26 21:08:29 --> Loader Class Initialized
INFO - 2018-03-26 21:08:29 --> Helper loaded: url_helper
INFO - 2018-03-26 21:08:29 --> Helper loaded: form_helper
INFO - 2018-03-26 21:08:29 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:08:29 --> Controller Class Initialized
INFO - 2018-03-26 21:08:29 --> Model Class Initialized
INFO - 2018-03-26 21:08:29 --> Model Class Initialized
INFO - 2018-03-26 21:08:29 --> Model Class Initialized
INFO - 2018-03-26 21:08:29 --> Model Class Initialized
INFO - 2018-03-26 21:08:29 --> Model Class Initialized
INFO - 2018-03-26 21:08:29 --> Model Class Initialized
INFO - 2018-03-26 21:08:29 --> Model Class Initialized
INFO - 2018-03-26 21:08:29 --> Model Class Initialized
INFO - 2018-03-26 21:08:29 --> Model Class Initialized
INFO - 2018-03-26 21:08:29 --> Model Class Initialized
INFO - 2018-03-26 21:08:29 --> Model Class Initialized
INFO - 2018-03-26 21:08:29 --> Model Class Initialized
INFO - 2018-03-26 21:08:29 --> Model Class Initialized
INFO - 2018-03-26 21:08:29 --> Model Class Initialized
INFO - 2018-03-26 21:08:29 --> Model Class Initialized
INFO - 2018-03-26 21:08:29 --> Helper loaded: date_helper
INFO - 2018-03-26 21:08:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:08:39 --> Config Class Initialized
INFO - 2018-03-26 21:08:39 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:08:39 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:08:39 --> Utf8 Class Initialized
INFO - 2018-03-26 21:08:39 --> URI Class Initialized
INFO - 2018-03-26 21:08:39 --> Router Class Initialized
INFO - 2018-03-26 21:08:39 --> Output Class Initialized
INFO - 2018-03-26 21:08:39 --> Security Class Initialized
DEBUG - 2018-03-26 21:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:08:39 --> Input Class Initialized
INFO - 2018-03-26 21:08:39 --> Language Class Initialized
INFO - 2018-03-26 21:08:39 --> Loader Class Initialized
INFO - 2018-03-26 21:08:39 --> Helper loaded: url_helper
INFO - 2018-03-26 21:08:39 --> Helper loaded: form_helper
INFO - 2018-03-26 21:08:39 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:08:39 --> Controller Class Initialized
INFO - 2018-03-26 21:08:39 --> Model Class Initialized
INFO - 2018-03-26 21:08:39 --> Model Class Initialized
INFO - 2018-03-26 21:08:39 --> Model Class Initialized
INFO - 2018-03-26 21:08:39 --> Model Class Initialized
INFO - 2018-03-26 21:08:39 --> Model Class Initialized
INFO - 2018-03-26 21:08:39 --> Model Class Initialized
INFO - 2018-03-26 21:08:39 --> Model Class Initialized
INFO - 2018-03-26 21:08:39 --> Model Class Initialized
INFO - 2018-03-26 21:08:39 --> Model Class Initialized
INFO - 2018-03-26 21:08:39 --> Model Class Initialized
INFO - 2018-03-26 21:08:39 --> Model Class Initialized
INFO - 2018-03-26 21:08:39 --> Model Class Initialized
INFO - 2018-03-26 21:08:39 --> Model Class Initialized
INFO - 2018-03-26 21:08:39 --> Model Class Initialized
INFO - 2018-03-26 21:08:39 --> Model Class Initialized
INFO - 2018-03-26 21:08:39 --> Helper loaded: date_helper
INFO - 2018-03-26 21:08:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:08:48 --> Config Class Initialized
INFO - 2018-03-26 21:08:48 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:08:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:08:48 --> Utf8 Class Initialized
INFO - 2018-03-26 21:08:48 --> URI Class Initialized
INFO - 2018-03-26 21:08:48 --> Router Class Initialized
INFO - 2018-03-26 21:08:48 --> Output Class Initialized
INFO - 2018-03-26 21:08:48 --> Security Class Initialized
DEBUG - 2018-03-26 21:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:08:48 --> Input Class Initialized
INFO - 2018-03-26 21:08:48 --> Language Class Initialized
INFO - 2018-03-26 21:08:48 --> Loader Class Initialized
INFO - 2018-03-26 21:08:48 --> Helper loaded: url_helper
INFO - 2018-03-26 21:08:48 --> Helper loaded: form_helper
INFO - 2018-03-26 21:08:48 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:08:48 --> Controller Class Initialized
INFO - 2018-03-26 21:08:48 --> Model Class Initialized
INFO - 2018-03-26 21:08:48 --> Model Class Initialized
INFO - 2018-03-26 21:08:48 --> Model Class Initialized
INFO - 2018-03-26 21:08:48 --> Model Class Initialized
INFO - 2018-03-26 21:08:48 --> Model Class Initialized
INFO - 2018-03-26 21:08:48 --> Model Class Initialized
INFO - 2018-03-26 21:08:48 --> Model Class Initialized
INFO - 2018-03-26 21:08:48 --> Model Class Initialized
INFO - 2018-03-26 21:08:48 --> Model Class Initialized
INFO - 2018-03-26 21:08:48 --> Model Class Initialized
INFO - 2018-03-26 21:08:48 --> Model Class Initialized
INFO - 2018-03-26 21:08:48 --> Model Class Initialized
INFO - 2018-03-26 21:08:48 --> Model Class Initialized
INFO - 2018-03-26 21:08:48 --> Model Class Initialized
INFO - 2018-03-26 21:08:48 --> Model Class Initialized
INFO - 2018-03-26 21:08:48 --> Helper loaded: date_helper
INFO - 2018-03-26 21:08:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:09:24 --> Config Class Initialized
INFO - 2018-03-26 21:09:24 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:09:24 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:09:24 --> Utf8 Class Initialized
INFO - 2018-03-26 21:09:24 --> URI Class Initialized
INFO - 2018-03-26 21:09:24 --> Router Class Initialized
INFO - 2018-03-26 21:09:24 --> Output Class Initialized
INFO - 2018-03-26 21:09:24 --> Security Class Initialized
DEBUG - 2018-03-26 21:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:09:24 --> Input Class Initialized
INFO - 2018-03-26 21:09:24 --> Language Class Initialized
INFO - 2018-03-26 21:09:24 --> Loader Class Initialized
INFO - 2018-03-26 21:09:24 --> Helper loaded: url_helper
INFO - 2018-03-26 21:09:24 --> Helper loaded: form_helper
INFO - 2018-03-26 21:09:24 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:09:24 --> Controller Class Initialized
INFO - 2018-03-26 21:09:24 --> Model Class Initialized
INFO - 2018-03-26 21:09:24 --> Model Class Initialized
INFO - 2018-03-26 21:09:24 --> Model Class Initialized
INFO - 2018-03-26 21:09:24 --> Model Class Initialized
INFO - 2018-03-26 21:09:24 --> Model Class Initialized
INFO - 2018-03-26 21:09:24 --> Model Class Initialized
INFO - 2018-03-26 21:09:24 --> Model Class Initialized
INFO - 2018-03-26 21:09:24 --> Model Class Initialized
INFO - 2018-03-26 21:09:24 --> Model Class Initialized
INFO - 2018-03-26 21:09:24 --> Model Class Initialized
INFO - 2018-03-26 21:09:24 --> Model Class Initialized
INFO - 2018-03-26 21:09:24 --> Model Class Initialized
INFO - 2018-03-26 21:09:24 --> Model Class Initialized
INFO - 2018-03-26 21:09:24 --> Model Class Initialized
INFO - 2018-03-26 21:09:24 --> Model Class Initialized
INFO - 2018-03-26 21:09:24 --> Helper loaded: date_helper
INFO - 2018-03-26 21:09:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:11:19 --> Config Class Initialized
INFO - 2018-03-26 21:11:19 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:11:19 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:11:19 --> Utf8 Class Initialized
INFO - 2018-03-26 21:11:19 --> URI Class Initialized
INFO - 2018-03-26 21:11:19 --> Router Class Initialized
INFO - 2018-03-26 21:11:19 --> Output Class Initialized
INFO - 2018-03-26 21:11:19 --> Security Class Initialized
DEBUG - 2018-03-26 21:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:11:19 --> Input Class Initialized
INFO - 2018-03-26 21:11:19 --> Language Class Initialized
INFO - 2018-03-26 21:11:19 --> Loader Class Initialized
INFO - 2018-03-26 21:11:19 --> Helper loaded: url_helper
INFO - 2018-03-26 21:11:19 --> Helper loaded: form_helper
INFO - 2018-03-26 21:11:19 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:11:19 --> Controller Class Initialized
INFO - 2018-03-26 21:11:19 --> Model Class Initialized
INFO - 2018-03-26 21:11:19 --> Model Class Initialized
INFO - 2018-03-26 21:11:19 --> Model Class Initialized
INFO - 2018-03-26 21:11:19 --> Model Class Initialized
INFO - 2018-03-26 21:11:19 --> Model Class Initialized
INFO - 2018-03-26 21:11:19 --> Model Class Initialized
INFO - 2018-03-26 21:11:19 --> Model Class Initialized
INFO - 2018-03-26 21:11:19 --> Model Class Initialized
INFO - 2018-03-26 21:11:19 --> Model Class Initialized
INFO - 2018-03-26 21:11:19 --> Model Class Initialized
INFO - 2018-03-26 21:11:19 --> Model Class Initialized
INFO - 2018-03-26 21:11:19 --> Model Class Initialized
INFO - 2018-03-26 21:11:19 --> Model Class Initialized
INFO - 2018-03-26 21:11:19 --> Model Class Initialized
INFO - 2018-03-26 21:11:19 --> Model Class Initialized
INFO - 2018-03-26 21:11:19 --> Helper loaded: date_helper
INFO - 2018-03-26 21:11:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:11:29 --> Config Class Initialized
INFO - 2018-03-26 21:11:29 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:11:29 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:11:29 --> Utf8 Class Initialized
INFO - 2018-03-26 21:11:29 --> URI Class Initialized
INFO - 2018-03-26 21:11:29 --> Router Class Initialized
INFO - 2018-03-26 21:11:29 --> Output Class Initialized
INFO - 2018-03-26 21:11:29 --> Security Class Initialized
DEBUG - 2018-03-26 21:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:11:29 --> Input Class Initialized
INFO - 2018-03-26 21:11:29 --> Language Class Initialized
INFO - 2018-03-26 21:11:29 --> Loader Class Initialized
INFO - 2018-03-26 21:11:29 --> Helper loaded: url_helper
INFO - 2018-03-26 21:11:29 --> Helper loaded: form_helper
INFO - 2018-03-26 21:11:29 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:11:29 --> Controller Class Initialized
INFO - 2018-03-26 21:11:29 --> Model Class Initialized
INFO - 2018-03-26 21:11:29 --> Model Class Initialized
INFO - 2018-03-26 21:11:29 --> Model Class Initialized
INFO - 2018-03-26 21:11:29 --> Model Class Initialized
INFO - 2018-03-26 21:11:29 --> Model Class Initialized
INFO - 2018-03-26 21:11:29 --> Model Class Initialized
INFO - 2018-03-26 21:11:29 --> Model Class Initialized
INFO - 2018-03-26 21:11:29 --> Model Class Initialized
INFO - 2018-03-26 21:11:29 --> Model Class Initialized
INFO - 2018-03-26 21:11:29 --> Model Class Initialized
INFO - 2018-03-26 21:11:29 --> Model Class Initialized
INFO - 2018-03-26 21:11:29 --> Model Class Initialized
INFO - 2018-03-26 21:11:29 --> Model Class Initialized
INFO - 2018-03-26 21:11:29 --> Model Class Initialized
INFO - 2018-03-26 21:11:29 --> Model Class Initialized
INFO - 2018-03-26 21:11:29 --> Helper loaded: date_helper
INFO - 2018-03-26 21:11:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:11:35 --> Config Class Initialized
INFO - 2018-03-26 21:11:35 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:11:35 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:11:35 --> Utf8 Class Initialized
INFO - 2018-03-26 21:11:35 --> URI Class Initialized
INFO - 2018-03-26 21:11:35 --> Router Class Initialized
INFO - 2018-03-26 21:11:35 --> Output Class Initialized
INFO - 2018-03-26 21:11:35 --> Security Class Initialized
DEBUG - 2018-03-26 21:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:11:35 --> Input Class Initialized
INFO - 2018-03-26 21:11:35 --> Language Class Initialized
INFO - 2018-03-26 21:11:35 --> Loader Class Initialized
INFO - 2018-03-26 21:11:35 --> Helper loaded: url_helper
INFO - 2018-03-26 21:11:35 --> Helper loaded: form_helper
INFO - 2018-03-26 21:11:35 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:11:35 --> Controller Class Initialized
INFO - 2018-03-26 21:11:35 --> Model Class Initialized
INFO - 2018-03-26 21:11:35 --> Model Class Initialized
INFO - 2018-03-26 21:11:35 --> Model Class Initialized
INFO - 2018-03-26 21:11:35 --> Model Class Initialized
INFO - 2018-03-26 21:11:35 --> Model Class Initialized
INFO - 2018-03-26 21:11:35 --> Helper loaded: date_helper
INFO - 2018-03-26 21:11:43 --> Config Class Initialized
INFO - 2018-03-26 21:11:43 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:11:43 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:11:43 --> Utf8 Class Initialized
INFO - 2018-03-26 21:11:43 --> URI Class Initialized
INFO - 2018-03-26 21:11:43 --> Router Class Initialized
INFO - 2018-03-26 21:11:43 --> Output Class Initialized
INFO - 2018-03-26 21:11:43 --> Security Class Initialized
DEBUG - 2018-03-26 21:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:11:43 --> Input Class Initialized
INFO - 2018-03-26 21:11:43 --> Language Class Initialized
INFO - 2018-03-26 21:11:43 --> Loader Class Initialized
INFO - 2018-03-26 21:11:43 --> Helper loaded: url_helper
INFO - 2018-03-26 21:11:43 --> Helper loaded: form_helper
INFO - 2018-03-26 21:11:43 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:11:43 --> Controller Class Initialized
INFO - 2018-03-26 21:11:43 --> Model Class Initialized
INFO - 2018-03-26 21:11:43 --> Model Class Initialized
INFO - 2018-03-26 21:11:43 --> Model Class Initialized
INFO - 2018-03-26 21:11:43 --> Model Class Initialized
INFO - 2018-03-26 21:11:43 --> Model Class Initialized
INFO - 2018-03-26 21:11:43 --> Helper loaded: date_helper
INFO - 2018-03-26 21:11:47 --> Config Class Initialized
INFO - 2018-03-26 21:11:47 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:11:47 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:11:47 --> Utf8 Class Initialized
INFO - 2018-03-26 21:11:47 --> URI Class Initialized
INFO - 2018-03-26 21:11:47 --> Router Class Initialized
INFO - 2018-03-26 21:11:47 --> Output Class Initialized
INFO - 2018-03-26 21:11:47 --> Security Class Initialized
DEBUG - 2018-03-26 21:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:11:47 --> Input Class Initialized
INFO - 2018-03-26 21:11:47 --> Language Class Initialized
INFO - 2018-03-26 21:11:47 --> Loader Class Initialized
INFO - 2018-03-26 21:11:47 --> Helper loaded: url_helper
INFO - 2018-03-26 21:11:47 --> Helper loaded: form_helper
INFO - 2018-03-26 21:11:47 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:11:47 --> Controller Class Initialized
INFO - 2018-03-26 21:11:47 --> Model Class Initialized
INFO - 2018-03-26 21:11:47 --> Model Class Initialized
INFO - 2018-03-26 21:11:47 --> Model Class Initialized
INFO - 2018-03-26 21:11:47 --> Model Class Initialized
INFO - 2018-03-26 21:11:47 --> Model Class Initialized
INFO - 2018-03-26 21:11:47 --> Helper loaded: date_helper
INFO - 2018-03-26 21:11:49 --> Config Class Initialized
INFO - 2018-03-26 21:11:49 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:11:49 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:11:49 --> Utf8 Class Initialized
INFO - 2018-03-26 21:11:49 --> URI Class Initialized
INFO - 2018-03-26 21:11:49 --> Router Class Initialized
INFO - 2018-03-26 21:11:49 --> Output Class Initialized
INFO - 2018-03-26 21:11:49 --> Security Class Initialized
DEBUG - 2018-03-26 21:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:11:49 --> Input Class Initialized
INFO - 2018-03-26 21:11:49 --> Language Class Initialized
INFO - 2018-03-26 21:11:49 --> Loader Class Initialized
INFO - 2018-03-26 21:11:49 --> Helper loaded: url_helper
INFO - 2018-03-26 21:11:49 --> Helper loaded: form_helper
INFO - 2018-03-26 21:11:49 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:11:49 --> Controller Class Initialized
INFO - 2018-03-26 21:11:49 --> Model Class Initialized
INFO - 2018-03-26 21:11:49 --> Model Class Initialized
INFO - 2018-03-26 21:11:49 --> Model Class Initialized
INFO - 2018-03-26 21:11:49 --> Model Class Initialized
INFO - 2018-03-26 21:11:49 --> Model Class Initialized
INFO - 2018-03-26 21:11:49 --> Helper loaded: date_helper
INFO - 2018-03-26 21:11:54 --> Config Class Initialized
INFO - 2018-03-26 21:11:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:11:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:11:54 --> Utf8 Class Initialized
INFO - 2018-03-26 21:11:54 --> URI Class Initialized
INFO - 2018-03-26 21:11:54 --> Router Class Initialized
INFO - 2018-03-26 21:11:54 --> Output Class Initialized
INFO - 2018-03-26 21:11:54 --> Security Class Initialized
DEBUG - 2018-03-26 21:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:11:54 --> Input Class Initialized
INFO - 2018-03-26 21:11:54 --> Language Class Initialized
INFO - 2018-03-26 21:11:54 --> Loader Class Initialized
INFO - 2018-03-26 21:11:54 --> Helper loaded: url_helper
INFO - 2018-03-26 21:11:54 --> Helper loaded: form_helper
INFO - 2018-03-26 21:11:54 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:11:54 --> Controller Class Initialized
INFO - 2018-03-26 21:11:54 --> Model Class Initialized
INFO - 2018-03-26 21:11:54 --> Model Class Initialized
INFO - 2018-03-26 21:11:54 --> Model Class Initialized
INFO - 2018-03-26 21:11:54 --> Model Class Initialized
INFO - 2018-03-26 21:11:54 --> Model Class Initialized
INFO - 2018-03-26 21:11:54 --> Model Class Initialized
INFO - 2018-03-26 21:11:54 --> Model Class Initialized
INFO - 2018-03-26 21:11:54 --> Model Class Initialized
INFO - 2018-03-26 21:11:54 --> Model Class Initialized
INFO - 2018-03-26 21:11:54 --> Model Class Initialized
INFO - 2018-03-26 21:11:54 --> Model Class Initialized
INFO - 2018-03-26 21:11:54 --> Model Class Initialized
INFO - 2018-03-26 21:11:54 --> Helper loaded: date_helper
INFO - 2018-03-26 21:11:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:12:16 --> Config Class Initialized
INFO - 2018-03-26 21:12:16 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:12:16 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:12:16 --> Utf8 Class Initialized
INFO - 2018-03-26 21:12:16 --> URI Class Initialized
INFO - 2018-03-26 21:12:16 --> Router Class Initialized
INFO - 2018-03-26 21:12:16 --> Output Class Initialized
INFO - 2018-03-26 21:12:16 --> Security Class Initialized
DEBUG - 2018-03-26 21:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:12:16 --> Input Class Initialized
INFO - 2018-03-26 21:12:16 --> Language Class Initialized
INFO - 2018-03-26 21:12:16 --> Loader Class Initialized
INFO - 2018-03-26 21:12:16 --> Helper loaded: url_helper
INFO - 2018-03-26 21:12:16 --> Helper loaded: form_helper
INFO - 2018-03-26 21:12:16 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:12:16 --> Controller Class Initialized
INFO - 2018-03-26 21:12:16 --> Model Class Initialized
INFO - 2018-03-26 21:12:16 --> Model Class Initialized
INFO - 2018-03-26 21:12:16 --> Model Class Initialized
INFO - 2018-03-26 21:12:16 --> Model Class Initialized
INFO - 2018-03-26 21:12:16 --> Model Class Initialized
INFO - 2018-03-26 21:12:16 --> Model Class Initialized
INFO - 2018-03-26 21:12:16 --> Model Class Initialized
INFO - 2018-03-26 21:12:16 --> Model Class Initialized
INFO - 2018-03-26 21:12:16 --> Model Class Initialized
INFO - 2018-03-26 21:12:16 --> Model Class Initialized
INFO - 2018-03-26 21:12:16 --> Model Class Initialized
INFO - 2018-03-26 21:12:16 --> Model Class Initialized
INFO - 2018-03-26 21:12:16 --> Helper loaded: date_helper
INFO - 2018-03-26 21:12:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:12:37 --> Config Class Initialized
INFO - 2018-03-26 21:12:37 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:12:37 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:12:37 --> Utf8 Class Initialized
INFO - 2018-03-26 21:12:37 --> URI Class Initialized
INFO - 2018-03-26 21:12:37 --> Router Class Initialized
INFO - 2018-03-26 21:12:37 --> Output Class Initialized
INFO - 2018-03-26 21:12:37 --> Security Class Initialized
DEBUG - 2018-03-26 21:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:12:37 --> Input Class Initialized
INFO - 2018-03-26 21:12:37 --> Language Class Initialized
INFO - 2018-03-26 21:12:37 --> Loader Class Initialized
INFO - 2018-03-26 21:12:37 --> Helper loaded: url_helper
INFO - 2018-03-26 21:12:37 --> Helper loaded: form_helper
INFO - 2018-03-26 21:12:37 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:12:37 --> Controller Class Initialized
INFO - 2018-03-26 21:12:37 --> Model Class Initialized
INFO - 2018-03-26 21:12:37 --> Model Class Initialized
INFO - 2018-03-26 21:12:37 --> Model Class Initialized
INFO - 2018-03-26 21:12:37 --> Model Class Initialized
INFO - 2018-03-26 21:12:37 --> Model Class Initialized
INFO - 2018-03-26 21:12:37 --> Helper loaded: date_helper
INFO - 2018-03-26 21:12:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:12:43 --> Config Class Initialized
INFO - 2018-03-26 21:12:43 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:12:43 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:12:43 --> Utf8 Class Initialized
INFO - 2018-03-26 21:12:43 --> URI Class Initialized
INFO - 2018-03-26 21:12:43 --> Router Class Initialized
INFO - 2018-03-26 21:12:43 --> Output Class Initialized
INFO - 2018-03-26 21:12:43 --> Security Class Initialized
DEBUG - 2018-03-26 21:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:12:43 --> Input Class Initialized
INFO - 2018-03-26 21:12:43 --> Language Class Initialized
INFO - 2018-03-26 21:12:43 --> Loader Class Initialized
INFO - 2018-03-26 21:12:43 --> Helper loaded: url_helper
INFO - 2018-03-26 21:12:43 --> Helper loaded: form_helper
INFO - 2018-03-26 21:12:43 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:12:43 --> Controller Class Initialized
INFO - 2018-03-26 21:12:43 --> Model Class Initialized
INFO - 2018-03-26 21:12:43 --> Model Class Initialized
INFO - 2018-03-26 21:12:43 --> Model Class Initialized
INFO - 2018-03-26 21:12:43 --> Model Class Initialized
INFO - 2018-03-26 21:12:43 --> Model Class Initialized
INFO - 2018-03-26 21:12:43 --> Model Class Initialized
INFO - 2018-03-26 21:12:43 --> Model Class Initialized
INFO - 2018-03-26 21:12:43 --> Model Class Initialized
INFO - 2018-03-26 21:12:43 --> Model Class Initialized
INFO - 2018-03-26 21:12:43 --> Model Class Initialized
INFO - 2018-03-26 21:12:43 --> Model Class Initialized
INFO - 2018-03-26 21:12:43 --> Model Class Initialized
INFO - 2018-03-26 21:12:43 --> Helper loaded: date_helper
INFO - 2018-03-26 21:12:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:12:50 --> Config Class Initialized
INFO - 2018-03-26 21:12:50 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:12:50 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:12:50 --> Utf8 Class Initialized
INFO - 2018-03-26 21:12:50 --> URI Class Initialized
INFO - 2018-03-26 21:12:50 --> Router Class Initialized
INFO - 2018-03-26 21:12:50 --> Output Class Initialized
INFO - 2018-03-26 21:12:50 --> Security Class Initialized
DEBUG - 2018-03-26 21:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:12:50 --> Input Class Initialized
INFO - 2018-03-26 21:12:50 --> Language Class Initialized
ERROR - 2018-03-26 21:12:50 --> 404 Page Not Found: Sdm/Pegawai/profile
INFO - 2018-03-26 21:12:53 --> Config Class Initialized
INFO - 2018-03-26 21:12:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:12:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:12:53 --> Utf8 Class Initialized
INFO - 2018-03-26 21:12:53 --> URI Class Initialized
INFO - 2018-03-26 21:12:53 --> Router Class Initialized
INFO - 2018-03-26 21:12:53 --> Output Class Initialized
INFO - 2018-03-26 21:12:53 --> Security Class Initialized
DEBUG - 2018-03-26 21:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:12:53 --> Input Class Initialized
INFO - 2018-03-26 21:12:53 --> Language Class Initialized
INFO - 2018-03-26 21:12:53 --> Loader Class Initialized
INFO - 2018-03-26 21:12:53 --> Helper loaded: url_helper
INFO - 2018-03-26 21:12:53 --> Helper loaded: form_helper
INFO - 2018-03-26 21:12:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:12:53 --> Controller Class Initialized
INFO - 2018-03-26 21:12:53 --> Model Class Initialized
INFO - 2018-03-26 21:12:53 --> Model Class Initialized
INFO - 2018-03-26 21:12:53 --> Model Class Initialized
INFO - 2018-03-26 21:12:53 --> Model Class Initialized
INFO - 2018-03-26 21:12:53 --> Model Class Initialized
INFO - 2018-03-26 21:12:53 --> Helper loaded: date_helper
INFO - 2018-03-26 21:12:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:13:57 --> Config Class Initialized
INFO - 2018-03-26 21:13:57 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:13:57 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:13:57 --> Utf8 Class Initialized
INFO - 2018-03-26 21:13:57 --> URI Class Initialized
INFO - 2018-03-26 21:13:57 --> Router Class Initialized
INFO - 2018-03-26 21:13:57 --> Output Class Initialized
INFO - 2018-03-26 21:13:57 --> Security Class Initialized
DEBUG - 2018-03-26 21:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:13:57 --> Input Class Initialized
INFO - 2018-03-26 21:13:57 --> Language Class Initialized
INFO - 2018-03-26 21:13:57 --> Loader Class Initialized
INFO - 2018-03-26 21:13:57 --> Helper loaded: url_helper
INFO - 2018-03-26 21:13:57 --> Helper loaded: form_helper
INFO - 2018-03-26 21:13:57 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:13:57 --> Controller Class Initialized
INFO - 2018-03-26 21:13:57 --> Model Class Initialized
INFO - 2018-03-26 21:13:57 --> Model Class Initialized
INFO - 2018-03-26 21:13:57 --> Model Class Initialized
INFO - 2018-03-26 21:13:57 --> Model Class Initialized
INFO - 2018-03-26 21:13:57 --> Model Class Initialized
INFO - 2018-03-26 21:13:57 --> Helper loaded: date_helper
INFO - 2018-03-26 21:13:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:13:59 --> Config Class Initialized
INFO - 2018-03-26 21:13:59 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:13:59 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:13:59 --> Utf8 Class Initialized
INFO - 2018-03-26 21:13:59 --> URI Class Initialized
INFO - 2018-03-26 21:13:59 --> Router Class Initialized
INFO - 2018-03-26 21:13:59 --> Output Class Initialized
INFO - 2018-03-26 21:13:59 --> Security Class Initialized
DEBUG - 2018-03-26 21:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:13:59 --> Input Class Initialized
INFO - 2018-03-26 21:13:59 --> Language Class Initialized
INFO - 2018-03-26 21:13:59 --> Loader Class Initialized
INFO - 2018-03-26 21:13:59 --> Helper loaded: url_helper
INFO - 2018-03-26 21:13:59 --> Helper loaded: form_helper
INFO - 2018-03-26 21:13:59 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:13:59 --> Controller Class Initialized
INFO - 2018-03-26 21:13:59 --> Model Class Initialized
INFO - 2018-03-26 21:13:59 --> Model Class Initialized
INFO - 2018-03-26 21:13:59 --> Helper loaded: date_helper
INFO - 2018-03-26 21:14:01 --> Config Class Initialized
INFO - 2018-03-26 21:14:01 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:14:01 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:14:01 --> Utf8 Class Initialized
INFO - 2018-03-26 21:14:01 --> URI Class Initialized
INFO - 2018-03-26 21:14:01 --> Router Class Initialized
INFO - 2018-03-26 21:14:01 --> Output Class Initialized
INFO - 2018-03-26 21:14:01 --> Security Class Initialized
DEBUG - 2018-03-26 21:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:14:01 --> Input Class Initialized
INFO - 2018-03-26 21:14:01 --> Language Class Initialized
INFO - 2018-03-26 21:14:01 --> Loader Class Initialized
INFO - 2018-03-26 21:14:01 --> Helper loaded: url_helper
INFO - 2018-03-26 21:14:01 --> Helper loaded: form_helper
INFO - 2018-03-26 21:14:01 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:14:01 --> Controller Class Initialized
INFO - 2018-03-26 21:14:01 --> Model Class Initialized
INFO - 2018-03-26 21:14:01 --> Model Class Initialized
INFO - 2018-03-26 21:14:01 --> Helper loaded: date_helper
INFO - 2018-03-26 21:16:38 --> Config Class Initialized
INFO - 2018-03-26 21:16:38 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:16:38 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:16:38 --> Utf8 Class Initialized
INFO - 2018-03-26 21:16:38 --> URI Class Initialized
INFO - 2018-03-26 21:16:38 --> Router Class Initialized
INFO - 2018-03-26 21:16:38 --> Output Class Initialized
INFO - 2018-03-26 21:16:38 --> Security Class Initialized
DEBUG - 2018-03-26 21:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:16:38 --> Input Class Initialized
INFO - 2018-03-26 21:16:38 --> Language Class Initialized
INFO - 2018-03-26 21:16:38 --> Loader Class Initialized
INFO - 2018-03-26 21:16:38 --> Helper loaded: url_helper
INFO - 2018-03-26 21:16:38 --> Helper loaded: form_helper
INFO - 2018-03-26 21:16:38 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:16:38 --> Controller Class Initialized
INFO - 2018-03-26 21:16:38 --> Model Class Initialized
INFO - 2018-03-26 21:16:38 --> Model Class Initialized
INFO - 2018-03-26 21:16:38 --> Helper loaded: date_helper
INFO - 2018-03-26 21:16:40 --> Config Class Initialized
INFO - 2018-03-26 21:16:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:16:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:16:40 --> Utf8 Class Initialized
INFO - 2018-03-26 21:16:40 --> URI Class Initialized
INFO - 2018-03-26 21:16:40 --> Router Class Initialized
INFO - 2018-03-26 21:16:40 --> Output Class Initialized
INFO - 2018-03-26 21:16:40 --> Security Class Initialized
DEBUG - 2018-03-26 21:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:16:40 --> Input Class Initialized
INFO - 2018-03-26 21:16:40 --> Language Class Initialized
INFO - 2018-03-26 21:16:40 --> Loader Class Initialized
INFO - 2018-03-26 21:16:40 --> Helper loaded: url_helper
INFO - 2018-03-26 21:16:40 --> Helper loaded: form_helper
INFO - 2018-03-26 21:16:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:16:40 --> Controller Class Initialized
INFO - 2018-03-26 21:16:40 --> Model Class Initialized
INFO - 2018-03-26 21:16:40 --> Model Class Initialized
INFO - 2018-03-26 21:16:40 --> Helper loaded: date_helper
INFO - 2018-03-26 21:17:20 --> Config Class Initialized
INFO - 2018-03-26 21:17:20 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:17:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:17:20 --> Utf8 Class Initialized
INFO - 2018-03-26 21:17:20 --> URI Class Initialized
INFO - 2018-03-26 21:17:20 --> Router Class Initialized
INFO - 2018-03-26 21:17:20 --> Output Class Initialized
INFO - 2018-03-26 21:17:20 --> Security Class Initialized
DEBUG - 2018-03-26 21:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:17:20 --> Input Class Initialized
INFO - 2018-03-26 21:17:20 --> Language Class Initialized
INFO - 2018-03-26 21:17:20 --> Loader Class Initialized
INFO - 2018-03-26 21:17:20 --> Helper loaded: url_helper
INFO - 2018-03-26 21:17:20 --> Helper loaded: form_helper
INFO - 2018-03-26 21:17:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:17:20 --> Controller Class Initialized
INFO - 2018-03-26 21:17:20 --> Model Class Initialized
INFO - 2018-03-26 21:17:20 --> Model Class Initialized
INFO - 2018-03-26 21:17:20 --> Helper loaded: date_helper
INFO - 2018-03-26 21:17:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:20:08 --> Config Class Initialized
INFO - 2018-03-26 21:20:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:20:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:20:08 --> Utf8 Class Initialized
INFO - 2018-03-26 21:20:08 --> URI Class Initialized
INFO - 2018-03-26 21:20:08 --> Router Class Initialized
INFO - 2018-03-26 21:20:08 --> Output Class Initialized
INFO - 2018-03-26 21:20:08 --> Security Class Initialized
DEBUG - 2018-03-26 21:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:20:08 --> Input Class Initialized
INFO - 2018-03-26 21:20:08 --> Language Class Initialized
INFO - 2018-03-26 21:20:08 --> Loader Class Initialized
INFO - 2018-03-26 21:20:09 --> Helper loaded: url_helper
INFO - 2018-03-26 21:20:09 --> Helper loaded: form_helper
INFO - 2018-03-26 21:20:09 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:20:09 --> Controller Class Initialized
INFO - 2018-03-26 21:20:09 --> Model Class Initialized
INFO - 2018-03-26 21:20:09 --> Model Class Initialized
INFO - 2018-03-26 21:20:09 --> Helper loaded: date_helper
INFO - 2018-03-26 21:20:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:22:48 --> Config Class Initialized
INFO - 2018-03-26 21:22:48 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:22:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:22:48 --> Utf8 Class Initialized
INFO - 2018-03-26 21:22:48 --> URI Class Initialized
INFO - 2018-03-26 21:22:48 --> Router Class Initialized
INFO - 2018-03-26 21:22:48 --> Output Class Initialized
INFO - 2018-03-26 21:22:48 --> Security Class Initialized
DEBUG - 2018-03-26 21:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:22:48 --> Input Class Initialized
INFO - 2018-03-26 21:22:48 --> Language Class Initialized
INFO - 2018-03-26 21:22:48 --> Loader Class Initialized
INFO - 2018-03-26 21:22:48 --> Helper loaded: url_helper
INFO - 2018-03-26 21:22:48 --> Helper loaded: form_helper
INFO - 2018-03-26 21:22:48 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:22:48 --> Controller Class Initialized
INFO - 2018-03-26 21:22:48 --> Model Class Initialized
INFO - 2018-03-26 21:22:48 --> Model Class Initialized
INFO - 2018-03-26 21:22:48 --> Helper loaded: date_helper
INFO - 2018-03-26 21:22:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:22:48 --> Config Class Initialized
INFO - 2018-03-26 21:22:48 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:22:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:22:48 --> Utf8 Class Initialized
INFO - 2018-03-26 21:22:48 --> URI Class Initialized
INFO - 2018-03-26 21:22:48 --> Router Class Initialized
INFO - 2018-03-26 21:22:48 --> Output Class Initialized
INFO - 2018-03-26 21:22:48 --> Security Class Initialized
DEBUG - 2018-03-26 21:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:22:48 --> Input Class Initialized
INFO - 2018-03-26 21:22:48 --> Language Class Initialized
ERROR - 2018-03-26 21:22:48 --> 404 Page Not Found: Sdm/Dist/img
INFO - 2018-03-26 21:22:48 --> Config Class Initialized
INFO - 2018-03-26 21:22:48 --> Config Class Initialized
INFO - 2018-03-26 21:22:48 --> Hooks Class Initialized
INFO - 2018-03-26 21:22:48 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:22:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:22:48 --> Utf8 Class Initialized
DEBUG - 2018-03-26 21:22:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:22:48 --> Utf8 Class Initialized
INFO - 2018-03-26 21:22:48 --> URI Class Initialized
INFO - 2018-03-26 21:22:48 --> URI Class Initialized
INFO - 2018-03-26 21:22:48 --> Router Class Initialized
INFO - 2018-03-26 21:22:48 --> Router Class Initialized
INFO - 2018-03-26 21:22:48 --> Output Class Initialized
INFO - 2018-03-26 21:22:48 --> Output Class Initialized
INFO - 2018-03-26 21:22:48 --> Security Class Initialized
INFO - 2018-03-26 21:22:48 --> Config Class Initialized
INFO - 2018-03-26 21:22:48 --> Security Class Initialized
DEBUG - 2018-03-26 21:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:22:48 --> Hooks Class Initialized
INFO - 2018-03-26 21:22:48 --> Input Class Initialized
DEBUG - 2018-03-26 21:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:22:48 --> Input Class Initialized
INFO - 2018-03-26 21:22:48 --> Language Class Initialized
INFO - 2018-03-26 21:22:48 --> Config Class Initialized
INFO - 2018-03-26 21:22:48 --> Hooks Class Initialized
ERROR - 2018-03-26 21:22:48 --> 404 Page Not Found: Sdm/Dist/img
INFO - 2018-03-26 21:22:48 --> Language Class Initialized
DEBUG - 2018-03-26 21:22:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:22:48 --> Utf8 Class Initialized
DEBUG - 2018-03-26 21:22:48 --> UTF-8 Support Enabled
ERROR - 2018-03-26 21:22:48 --> 404 Page Not Found: Sdm/Dist/img
INFO - 2018-03-26 21:22:48 --> URI Class Initialized
INFO - 2018-03-26 21:22:48 --> Utf8 Class Initialized
INFO - 2018-03-26 21:22:48 --> Config Class Initialized
INFO - 2018-03-26 21:22:48 --> URI Class Initialized
INFO - 2018-03-26 21:22:48 --> Router Class Initialized
INFO - 2018-03-26 21:22:48 --> Hooks Class Initialized
INFO - 2018-03-26 21:22:48 --> Config Class Initialized
INFO - 2018-03-26 21:22:48 --> Hooks Class Initialized
INFO - 2018-03-26 21:22:48 --> Output Class Initialized
INFO - 2018-03-26 21:22:48 --> Router Class Initialized
DEBUG - 2018-03-26 21:22:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:22:48 --> Utf8 Class Initialized
INFO - 2018-03-26 21:22:48 --> Security Class Initialized
DEBUG - 2018-03-26 21:22:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:22:48 --> Output Class Initialized
INFO - 2018-03-26 21:22:48 --> URI Class Initialized
INFO - 2018-03-26 21:22:48 --> Utf8 Class Initialized
DEBUG - 2018-03-26 21:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:22:48 --> Security Class Initialized
INFO - 2018-03-26 21:22:48 --> Input Class Initialized
INFO - 2018-03-26 21:22:48 --> Router Class Initialized
INFO - 2018-03-26 21:22:48 --> URI Class Initialized
DEBUG - 2018-03-26 21:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:22:48 --> Language Class Initialized
INFO - 2018-03-26 21:22:48 --> Input Class Initialized
INFO - 2018-03-26 21:22:48 --> Router Class Initialized
ERROR - 2018-03-26 21:22:48 --> 404 Page Not Found: Sdm/Dist/img
INFO - 2018-03-26 21:22:48 --> Output Class Initialized
INFO - 2018-03-26 21:22:48 --> Language Class Initialized
INFO - 2018-03-26 21:22:48 --> Output Class Initialized
INFO - 2018-03-26 21:22:48 --> Security Class Initialized
ERROR - 2018-03-26 21:22:48 --> 404 Page Not Found: Sdm/Dist/img
DEBUG - 2018-03-26 21:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:22:48 --> Security Class Initialized
INFO - 2018-03-26 21:22:48 --> Input Class Initialized
DEBUG - 2018-03-26 21:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:22:48 --> Language Class Initialized
INFO - 2018-03-26 21:22:48 --> Input Class Initialized
ERROR - 2018-03-26 21:22:48 --> 404 Page Not Found: Sdm/Dist/img
INFO - 2018-03-26 21:22:48 --> Language Class Initialized
ERROR - 2018-03-26 21:22:48 --> 404 Page Not Found: Sdm/Dist/img
INFO - 2018-03-26 21:22:48 --> Config Class Initialized
INFO - 2018-03-26 21:22:48 --> Hooks Class Initialized
INFO - 2018-03-26 21:22:48 --> Config Class Initialized
INFO - 2018-03-26 21:22:48 --> Config Class Initialized
INFO - 2018-03-26 21:22:48 --> Hooks Class Initialized
INFO - 2018-03-26 21:22:48 --> Config Class Initialized
DEBUG - 2018-03-26 21:22:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:22:48 --> Hooks Class Initialized
INFO - 2018-03-26 21:22:48 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:22:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:22:48 --> Utf8 Class Initialized
INFO - 2018-03-26 21:22:48 --> Utf8 Class Initialized
DEBUG - 2018-03-26 21:22:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:22:48 --> URI Class Initialized
INFO - 2018-03-26 21:22:48 --> Utf8 Class Initialized
INFO - 2018-03-26 21:22:48 --> Config Class Initialized
INFO - 2018-03-26 21:22:48 --> URI Class Initialized
INFO - 2018-03-26 21:22:48 --> Config Class Initialized
INFO - 2018-03-26 21:22:48 --> URI Class Initialized
INFO - 2018-03-26 21:22:48 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:22:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:22:48 --> Hooks Class Initialized
INFO - 2018-03-26 21:22:48 --> Router Class Initialized
INFO - 2018-03-26 21:22:48 --> Router Class Initialized
INFO - 2018-03-26 21:22:48 --> Router Class Initialized
DEBUG - 2018-03-26 21:22:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:22:48 --> Utf8 Class Initialized
INFO - 2018-03-26 21:22:48 --> Utf8 Class Initialized
DEBUG - 2018-03-26 21:22:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:22:48 --> Output Class Initialized
INFO - 2018-03-26 21:22:48 --> Output Class Initialized
INFO - 2018-03-26 21:22:48 --> URI Class Initialized
INFO - 2018-03-26 21:22:48 --> Output Class Initialized
INFO - 2018-03-26 21:22:48 --> Utf8 Class Initialized
INFO - 2018-03-26 21:22:48 --> URI Class Initialized
INFO - 2018-03-26 21:22:48 --> Security Class Initialized
INFO - 2018-03-26 21:22:48 --> Security Class Initialized
INFO - 2018-03-26 21:22:48 --> URI Class Initialized
INFO - 2018-03-26 21:22:48 --> Security Class Initialized
INFO - 2018-03-26 21:22:48 --> Router Class Initialized
INFO - 2018-03-26 21:22:48 --> Router Class Initialized
DEBUG - 2018-03-26 21:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-26 21:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:22:48 --> Router Class Initialized
DEBUG - 2018-03-26 21:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:22:48 --> Output Class Initialized
INFO - 2018-03-26 21:22:48 --> Input Class Initialized
INFO - 2018-03-26 21:22:48 --> Output Class Initialized
INFO - 2018-03-26 21:22:48 --> Input Class Initialized
INFO - 2018-03-26 21:22:48 --> Language Class Initialized
INFO - 2018-03-26 21:22:48 --> Security Class Initialized
INFO - 2018-03-26 21:22:48 --> Output Class Initialized
INFO - 2018-03-26 21:22:48 --> Language Class Initialized
INFO - 2018-03-26 21:22:48 --> Security Class Initialized
ERROR - 2018-03-26 21:22:48 --> 404 Page Not Found: Sdm/Dist/img
DEBUG - 2018-03-26 21:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:22:48 --> Security Class Initialized
INFO - 2018-03-26 21:22:48 --> Input Class Initialized
DEBUG - 2018-03-26 21:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-26 21:22:48 --> 404 Page Not Found: Sdm/Dist/img
DEBUG - 2018-03-26 21:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:22:48 --> Input Class Initialized
INFO - 2018-03-26 21:22:48 --> Language Class Initialized
INFO - 2018-03-26 21:22:48 --> Input Class Initialized
INFO - 2018-03-26 21:22:48 --> Input Class Initialized
INFO - 2018-03-26 21:22:48 --> Language Class Initialized
ERROR - 2018-03-26 21:22:48 --> 404 Page Not Found: Sdm/Dist/img
INFO - 2018-03-26 21:22:48 --> Language Class Initialized
INFO - 2018-03-26 21:22:48 --> Language Class Initialized
ERROR - 2018-03-26 21:22:48 --> 404 Page Not Found: Sdm/Dist/img
ERROR - 2018-03-26 21:22:48 --> 404 Page Not Found: Sdm/Dist/img
ERROR - 2018-03-26 21:22:48 --> 404 Page Not Found: Sdm/Dist/img
INFO - 2018-03-26 21:22:48 --> Config Class Initialized
INFO - 2018-03-26 21:22:48 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:22:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:22:48 --> Utf8 Class Initialized
INFO - 2018-03-26 21:22:48 --> URI Class Initialized
INFO - 2018-03-26 21:22:48 --> Router Class Initialized
INFO - 2018-03-26 21:22:48 --> Output Class Initialized
INFO - 2018-03-26 21:22:48 --> Security Class Initialized
DEBUG - 2018-03-26 21:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:22:48 --> Input Class Initialized
INFO - 2018-03-26 21:22:48 --> Language Class Initialized
ERROR - 2018-03-26 21:22:48 --> 404 Page Not Found: Sdm/Dist/img
INFO - 2018-03-26 21:24:33 --> Config Class Initialized
INFO - 2018-03-26 21:24:33 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:24:33 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:24:33 --> Utf8 Class Initialized
INFO - 2018-03-26 21:24:33 --> URI Class Initialized
INFO - 2018-03-26 21:24:33 --> Router Class Initialized
INFO - 2018-03-26 21:24:33 --> Output Class Initialized
INFO - 2018-03-26 21:24:33 --> Security Class Initialized
DEBUG - 2018-03-26 21:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:24:33 --> Input Class Initialized
INFO - 2018-03-26 21:24:33 --> Language Class Initialized
INFO - 2018-03-26 21:24:33 --> Loader Class Initialized
INFO - 2018-03-26 21:24:33 --> Helper loaded: url_helper
INFO - 2018-03-26 21:24:33 --> Helper loaded: form_helper
INFO - 2018-03-26 21:24:33 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:24:33 --> Controller Class Initialized
INFO - 2018-03-26 21:24:33 --> Model Class Initialized
INFO - 2018-03-26 21:24:33 --> Model Class Initialized
INFO - 2018-03-26 21:24:33 --> Helper loaded: date_helper
INFO - 2018-03-26 21:24:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:24:34 --> Config Class Initialized
INFO - 2018-03-26 21:24:34 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:24:34 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:24:34 --> Utf8 Class Initialized
INFO - 2018-03-26 21:24:34 --> URI Class Initialized
INFO - 2018-03-26 21:24:34 --> Router Class Initialized
INFO - 2018-03-26 21:24:34 --> Output Class Initialized
INFO - 2018-03-26 21:24:34 --> Security Class Initialized
DEBUG - 2018-03-26 21:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:24:34 --> Input Class Initialized
INFO - 2018-03-26 21:24:34 --> Language Class Initialized
INFO - 2018-03-26 21:24:34 --> Loader Class Initialized
INFO - 2018-03-26 21:24:34 --> Helper loaded: url_helper
INFO - 2018-03-26 21:24:34 --> Helper loaded: form_helper
INFO - 2018-03-26 21:24:34 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:24:34 --> Controller Class Initialized
INFO - 2018-03-26 21:24:34 --> Model Class Initialized
INFO - 2018-03-26 21:24:34 --> Model Class Initialized
INFO - 2018-03-26 21:24:34 --> Helper loaded: date_helper
INFO - 2018-03-26 21:24:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:24:36 --> Config Class Initialized
INFO - 2018-03-26 21:24:36 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:24:36 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:24:36 --> Utf8 Class Initialized
INFO - 2018-03-26 21:24:36 --> URI Class Initialized
INFO - 2018-03-26 21:24:36 --> Router Class Initialized
INFO - 2018-03-26 21:24:36 --> Output Class Initialized
INFO - 2018-03-26 21:24:36 --> Security Class Initialized
DEBUG - 2018-03-26 21:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:24:36 --> Input Class Initialized
INFO - 2018-03-26 21:24:36 --> Language Class Initialized
INFO - 2018-03-26 21:24:36 --> Loader Class Initialized
INFO - 2018-03-26 21:24:36 --> Helper loaded: url_helper
INFO - 2018-03-26 21:24:36 --> Helper loaded: form_helper
INFO - 2018-03-26 21:24:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:24:36 --> Controller Class Initialized
INFO - 2018-03-26 21:24:36 --> Model Class Initialized
INFO - 2018-03-26 21:24:36 --> Model Class Initialized
INFO - 2018-03-26 21:24:36 --> Helper loaded: date_helper
INFO - 2018-03-26 21:24:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:24:44 --> Config Class Initialized
INFO - 2018-03-26 21:24:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:24:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:24:44 --> Utf8 Class Initialized
INFO - 2018-03-26 21:24:44 --> URI Class Initialized
INFO - 2018-03-26 21:24:44 --> Router Class Initialized
INFO - 2018-03-26 21:24:44 --> Output Class Initialized
INFO - 2018-03-26 21:24:44 --> Security Class Initialized
DEBUG - 2018-03-26 21:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:24:44 --> Input Class Initialized
INFO - 2018-03-26 21:24:44 --> Language Class Initialized
INFO - 2018-03-26 21:24:44 --> Loader Class Initialized
INFO - 2018-03-26 21:24:44 --> Helper loaded: url_helper
INFO - 2018-03-26 21:24:44 --> Helper loaded: form_helper
INFO - 2018-03-26 21:24:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:24:44 --> Controller Class Initialized
INFO - 2018-03-26 21:24:44 --> Model Class Initialized
INFO - 2018-03-26 21:24:44 --> Model Class Initialized
INFO - 2018-03-26 21:24:44 --> Helper loaded: date_helper
INFO - 2018-03-26 21:24:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:25:03 --> Config Class Initialized
INFO - 2018-03-26 21:25:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:25:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:25:03 --> Utf8 Class Initialized
INFO - 2018-03-26 21:25:03 --> URI Class Initialized
INFO - 2018-03-26 21:25:03 --> Router Class Initialized
INFO - 2018-03-26 21:25:03 --> Output Class Initialized
INFO - 2018-03-26 21:25:03 --> Security Class Initialized
DEBUG - 2018-03-26 21:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:25:03 --> Input Class Initialized
INFO - 2018-03-26 21:25:03 --> Language Class Initialized
INFO - 2018-03-26 21:25:03 --> Loader Class Initialized
INFO - 2018-03-26 21:25:03 --> Helper loaded: url_helper
INFO - 2018-03-26 21:25:03 --> Helper loaded: form_helper
INFO - 2018-03-26 21:25:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:25:03 --> Controller Class Initialized
INFO - 2018-03-26 21:25:03 --> Model Class Initialized
INFO - 2018-03-26 21:25:03 --> Model Class Initialized
INFO - 2018-03-26 21:25:03 --> Helper loaded: date_helper
INFO - 2018-03-26 21:25:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:25:06 --> Config Class Initialized
INFO - 2018-03-26 21:25:06 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:25:06 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:25:06 --> Utf8 Class Initialized
INFO - 2018-03-26 21:25:06 --> URI Class Initialized
INFO - 2018-03-26 21:25:06 --> Router Class Initialized
INFO - 2018-03-26 21:25:06 --> Output Class Initialized
INFO - 2018-03-26 21:25:06 --> Security Class Initialized
DEBUG - 2018-03-26 21:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:25:06 --> Input Class Initialized
INFO - 2018-03-26 21:25:06 --> Language Class Initialized
INFO - 2018-03-26 21:25:06 --> Loader Class Initialized
INFO - 2018-03-26 21:25:06 --> Helper loaded: url_helper
INFO - 2018-03-26 21:25:06 --> Helper loaded: form_helper
INFO - 2018-03-26 21:25:06 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:25:06 --> Controller Class Initialized
INFO - 2018-03-26 21:25:06 --> Model Class Initialized
INFO - 2018-03-26 21:25:06 --> Model Class Initialized
INFO - 2018-03-26 21:25:06 --> Helper loaded: date_helper
INFO - 2018-03-26 21:25:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:27:25 --> Config Class Initialized
INFO - 2018-03-26 21:27:25 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:27:25 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:27:25 --> Utf8 Class Initialized
INFO - 2018-03-26 21:27:25 --> URI Class Initialized
INFO - 2018-03-26 21:27:25 --> Router Class Initialized
INFO - 2018-03-26 21:27:25 --> Output Class Initialized
INFO - 2018-03-26 21:27:25 --> Security Class Initialized
DEBUG - 2018-03-26 21:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:27:25 --> Input Class Initialized
INFO - 2018-03-26 21:27:25 --> Language Class Initialized
INFO - 2018-03-26 21:27:25 --> Loader Class Initialized
INFO - 2018-03-26 21:27:25 --> Helper loaded: url_helper
INFO - 2018-03-26 21:27:25 --> Helper loaded: form_helper
INFO - 2018-03-26 21:27:25 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:27:25 --> Controller Class Initialized
INFO - 2018-03-26 21:27:25 --> Model Class Initialized
INFO - 2018-03-26 21:27:25 --> Model Class Initialized
INFO - 2018-03-26 21:27:25 --> Helper loaded: date_helper
INFO - 2018-03-26 21:27:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:27:47 --> Config Class Initialized
INFO - 2018-03-26 21:27:47 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:27:47 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:27:47 --> Utf8 Class Initialized
INFO - 2018-03-26 21:27:47 --> URI Class Initialized
INFO - 2018-03-26 21:27:47 --> Router Class Initialized
INFO - 2018-03-26 21:27:47 --> Output Class Initialized
INFO - 2018-03-26 21:27:47 --> Security Class Initialized
DEBUG - 2018-03-26 21:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:27:47 --> Input Class Initialized
INFO - 2018-03-26 21:27:47 --> Language Class Initialized
INFO - 2018-03-26 21:27:47 --> Loader Class Initialized
INFO - 2018-03-26 21:27:47 --> Helper loaded: url_helper
INFO - 2018-03-26 21:27:47 --> Helper loaded: form_helper
INFO - 2018-03-26 21:27:47 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:27:47 --> Controller Class Initialized
INFO - 2018-03-26 21:27:47 --> Model Class Initialized
INFO - 2018-03-26 21:27:47 --> Model Class Initialized
INFO - 2018-03-26 21:27:47 --> Helper loaded: date_helper
INFO - 2018-03-26 21:27:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:31:28 --> Config Class Initialized
INFO - 2018-03-26 21:31:28 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:31:28 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:31:28 --> Utf8 Class Initialized
INFO - 2018-03-26 21:31:28 --> URI Class Initialized
INFO - 2018-03-26 21:31:28 --> Router Class Initialized
INFO - 2018-03-26 21:31:28 --> Output Class Initialized
INFO - 2018-03-26 21:31:28 --> Security Class Initialized
DEBUG - 2018-03-26 21:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:31:28 --> Input Class Initialized
INFO - 2018-03-26 21:31:28 --> Language Class Initialized
INFO - 2018-03-26 21:31:28 --> Loader Class Initialized
INFO - 2018-03-26 21:31:28 --> Helper loaded: url_helper
INFO - 2018-03-26 21:31:28 --> Helper loaded: form_helper
INFO - 2018-03-26 21:31:28 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:31:28 --> Controller Class Initialized
INFO - 2018-03-26 21:31:28 --> Model Class Initialized
INFO - 2018-03-26 21:31:28 --> Model Class Initialized
INFO - 2018-03-26 21:31:28 --> Helper loaded: date_helper
INFO - 2018-03-26 21:31:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:31:32 --> Config Class Initialized
INFO - 2018-03-26 21:31:32 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:31:32 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:31:32 --> Utf8 Class Initialized
INFO - 2018-03-26 21:31:32 --> URI Class Initialized
INFO - 2018-03-26 21:31:32 --> Router Class Initialized
INFO - 2018-03-26 21:31:32 --> Output Class Initialized
INFO - 2018-03-26 21:31:32 --> Security Class Initialized
DEBUG - 2018-03-26 21:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:31:32 --> Input Class Initialized
INFO - 2018-03-26 21:31:32 --> Language Class Initialized
INFO - 2018-03-26 21:31:32 --> Loader Class Initialized
INFO - 2018-03-26 21:31:32 --> Helper loaded: url_helper
INFO - 2018-03-26 21:31:32 --> Helper loaded: form_helper
INFO - 2018-03-26 21:31:32 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:31:32 --> Controller Class Initialized
INFO - 2018-03-26 21:31:32 --> Model Class Initialized
INFO - 2018-03-26 21:31:32 --> Model Class Initialized
INFO - 2018-03-26 21:31:32 --> Helper loaded: date_helper
INFO - 2018-03-26 21:31:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:31:34 --> Config Class Initialized
INFO - 2018-03-26 21:31:34 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:31:34 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:31:34 --> Utf8 Class Initialized
INFO - 2018-03-26 21:31:34 --> URI Class Initialized
INFO - 2018-03-26 21:31:34 --> Router Class Initialized
INFO - 2018-03-26 21:31:34 --> Output Class Initialized
INFO - 2018-03-26 21:31:34 --> Security Class Initialized
DEBUG - 2018-03-26 21:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:31:34 --> Input Class Initialized
INFO - 2018-03-26 21:31:34 --> Language Class Initialized
INFO - 2018-03-26 21:31:34 --> Loader Class Initialized
INFO - 2018-03-26 21:31:34 --> Helper loaded: url_helper
INFO - 2018-03-26 21:31:34 --> Helper loaded: form_helper
INFO - 2018-03-26 21:31:34 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:31:34 --> Controller Class Initialized
INFO - 2018-03-26 21:31:34 --> Model Class Initialized
INFO - 2018-03-26 21:31:34 --> Model Class Initialized
INFO - 2018-03-26 21:31:34 --> Helper loaded: date_helper
INFO - 2018-03-26 21:31:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:31:38 --> Config Class Initialized
INFO - 2018-03-26 21:31:38 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:31:38 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:31:38 --> Utf8 Class Initialized
INFO - 2018-03-26 21:31:38 --> URI Class Initialized
INFO - 2018-03-26 21:31:38 --> Router Class Initialized
INFO - 2018-03-26 21:31:38 --> Output Class Initialized
INFO - 2018-03-26 21:31:38 --> Security Class Initialized
DEBUG - 2018-03-26 21:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:31:38 --> Input Class Initialized
INFO - 2018-03-26 21:31:38 --> Language Class Initialized
INFO - 2018-03-26 21:31:38 --> Loader Class Initialized
INFO - 2018-03-26 21:31:38 --> Helper loaded: url_helper
INFO - 2018-03-26 21:31:38 --> Helper loaded: form_helper
INFO - 2018-03-26 21:31:38 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:31:38 --> Controller Class Initialized
INFO - 2018-03-26 21:31:38 --> Model Class Initialized
INFO - 2018-03-26 21:31:38 --> Model Class Initialized
INFO - 2018-03-26 21:31:38 --> Helper loaded: date_helper
INFO - 2018-03-26 21:31:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:37:08 --> Config Class Initialized
INFO - 2018-03-26 21:37:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:37:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:37:08 --> Utf8 Class Initialized
INFO - 2018-03-26 21:37:08 --> URI Class Initialized
INFO - 2018-03-26 21:37:08 --> Router Class Initialized
INFO - 2018-03-26 21:37:08 --> Output Class Initialized
INFO - 2018-03-26 21:37:08 --> Security Class Initialized
DEBUG - 2018-03-26 21:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:37:08 --> Input Class Initialized
INFO - 2018-03-26 21:37:08 --> Language Class Initialized
INFO - 2018-03-26 21:37:08 --> Loader Class Initialized
INFO - 2018-03-26 21:37:08 --> Helper loaded: url_helper
INFO - 2018-03-26 21:37:08 --> Helper loaded: form_helper
INFO - 2018-03-26 21:37:08 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:37:08 --> Controller Class Initialized
INFO - 2018-03-26 21:37:08 --> Model Class Initialized
INFO - 2018-03-26 21:37:08 --> Model Class Initialized
INFO - 2018-03-26 21:37:08 --> Helper loaded: date_helper
INFO - 2018-03-26 21:37:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:37:43 --> Config Class Initialized
INFO - 2018-03-26 21:37:43 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:37:43 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:37:43 --> Utf8 Class Initialized
INFO - 2018-03-26 21:37:43 --> URI Class Initialized
INFO - 2018-03-26 21:37:43 --> Router Class Initialized
INFO - 2018-03-26 21:37:43 --> Output Class Initialized
INFO - 2018-03-26 21:37:43 --> Security Class Initialized
DEBUG - 2018-03-26 21:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:37:43 --> Input Class Initialized
INFO - 2018-03-26 21:37:43 --> Language Class Initialized
INFO - 2018-03-26 21:37:43 --> Loader Class Initialized
INFO - 2018-03-26 21:37:43 --> Helper loaded: url_helper
INFO - 2018-03-26 21:37:43 --> Helper loaded: form_helper
INFO - 2018-03-26 21:37:43 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:37:43 --> Controller Class Initialized
INFO - 2018-03-26 21:37:43 --> Model Class Initialized
INFO - 2018-03-26 21:37:43 --> Model Class Initialized
INFO - 2018-03-26 21:37:43 --> Helper loaded: date_helper
INFO - 2018-03-26 21:37:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:39:08 --> Config Class Initialized
INFO - 2018-03-26 21:39:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:39:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:39:08 --> Utf8 Class Initialized
INFO - 2018-03-26 21:39:08 --> URI Class Initialized
INFO - 2018-03-26 21:39:08 --> Router Class Initialized
INFO - 2018-03-26 21:39:08 --> Output Class Initialized
INFO - 2018-03-26 21:39:08 --> Security Class Initialized
DEBUG - 2018-03-26 21:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:39:08 --> Input Class Initialized
INFO - 2018-03-26 21:39:08 --> Language Class Initialized
INFO - 2018-03-26 21:39:08 --> Loader Class Initialized
INFO - 2018-03-26 21:39:08 --> Helper loaded: url_helper
INFO - 2018-03-26 21:39:08 --> Helper loaded: form_helper
INFO - 2018-03-26 21:39:08 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:39:08 --> Controller Class Initialized
INFO - 2018-03-26 21:39:08 --> Model Class Initialized
INFO - 2018-03-26 21:39:08 --> Model Class Initialized
INFO - 2018-03-26 21:39:08 --> Helper loaded: date_helper
INFO - 2018-03-26 21:39:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:41:00 --> Config Class Initialized
INFO - 2018-03-26 21:41:00 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:41:00 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:41:00 --> Utf8 Class Initialized
INFO - 2018-03-26 21:41:00 --> URI Class Initialized
INFO - 2018-03-26 21:41:00 --> Router Class Initialized
INFO - 2018-03-26 21:41:00 --> Output Class Initialized
INFO - 2018-03-26 21:41:00 --> Security Class Initialized
DEBUG - 2018-03-26 21:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:41:00 --> Input Class Initialized
INFO - 2018-03-26 21:41:00 --> Language Class Initialized
INFO - 2018-03-26 21:41:00 --> Loader Class Initialized
INFO - 2018-03-26 21:41:00 --> Helper loaded: url_helper
INFO - 2018-03-26 21:41:00 --> Helper loaded: form_helper
INFO - 2018-03-26 21:41:00 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:41:00 --> Controller Class Initialized
INFO - 2018-03-26 21:41:00 --> Model Class Initialized
INFO - 2018-03-26 21:41:00 --> Model Class Initialized
INFO - 2018-03-26 21:41:00 --> Helper loaded: date_helper
INFO - 2018-03-26 21:41:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:41:17 --> Config Class Initialized
INFO - 2018-03-26 21:41:17 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:41:17 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:41:17 --> Utf8 Class Initialized
INFO - 2018-03-26 21:41:17 --> URI Class Initialized
INFO - 2018-03-26 21:41:17 --> Router Class Initialized
INFO - 2018-03-26 21:41:17 --> Output Class Initialized
INFO - 2018-03-26 21:41:17 --> Security Class Initialized
DEBUG - 2018-03-26 21:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:41:17 --> Input Class Initialized
INFO - 2018-03-26 21:41:17 --> Language Class Initialized
INFO - 2018-03-26 21:41:17 --> Loader Class Initialized
INFO - 2018-03-26 21:41:17 --> Helper loaded: url_helper
INFO - 2018-03-26 21:41:17 --> Helper loaded: form_helper
INFO - 2018-03-26 21:41:17 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:41:17 --> Controller Class Initialized
INFO - 2018-03-26 21:41:17 --> Model Class Initialized
INFO - 2018-03-26 21:41:17 --> Model Class Initialized
INFO - 2018-03-26 21:41:17 --> Helper loaded: date_helper
INFO - 2018-03-26 21:41:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:42:12 --> Config Class Initialized
INFO - 2018-03-26 21:42:12 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:42:12 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:42:12 --> Utf8 Class Initialized
INFO - 2018-03-26 21:42:12 --> URI Class Initialized
INFO - 2018-03-26 21:42:12 --> Router Class Initialized
INFO - 2018-03-26 21:42:13 --> Output Class Initialized
INFO - 2018-03-26 21:42:13 --> Security Class Initialized
DEBUG - 2018-03-26 21:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:42:13 --> Input Class Initialized
INFO - 2018-03-26 21:42:13 --> Language Class Initialized
INFO - 2018-03-26 21:42:13 --> Loader Class Initialized
INFO - 2018-03-26 21:42:13 --> Helper loaded: url_helper
INFO - 2018-03-26 21:42:13 --> Helper loaded: form_helper
INFO - 2018-03-26 21:42:13 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:42:13 --> Controller Class Initialized
INFO - 2018-03-26 21:42:13 --> Model Class Initialized
INFO - 2018-03-26 21:42:13 --> Model Class Initialized
INFO - 2018-03-26 21:42:13 --> Helper loaded: date_helper
INFO - 2018-03-26 21:42:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:42:32 --> Config Class Initialized
INFO - 2018-03-26 21:42:32 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:42:32 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:42:32 --> Utf8 Class Initialized
INFO - 2018-03-26 21:42:32 --> URI Class Initialized
INFO - 2018-03-26 21:42:32 --> Router Class Initialized
INFO - 2018-03-26 21:42:32 --> Output Class Initialized
INFO - 2018-03-26 21:42:32 --> Security Class Initialized
DEBUG - 2018-03-26 21:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:42:32 --> Input Class Initialized
INFO - 2018-03-26 21:42:32 --> Language Class Initialized
INFO - 2018-03-26 21:42:32 --> Loader Class Initialized
INFO - 2018-03-26 21:42:32 --> Helper loaded: url_helper
INFO - 2018-03-26 21:42:32 --> Helper loaded: form_helper
INFO - 2018-03-26 21:42:32 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:42:32 --> Controller Class Initialized
INFO - 2018-03-26 21:42:32 --> Model Class Initialized
INFO - 2018-03-26 21:42:32 --> Model Class Initialized
INFO - 2018-03-26 21:42:32 --> Helper loaded: date_helper
INFO - 2018-03-26 21:42:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:42:41 --> Config Class Initialized
INFO - 2018-03-26 21:42:41 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:42:41 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:42:41 --> Utf8 Class Initialized
INFO - 2018-03-26 21:42:41 --> URI Class Initialized
INFO - 2018-03-26 21:42:41 --> Router Class Initialized
INFO - 2018-03-26 21:42:41 --> Output Class Initialized
INFO - 2018-03-26 21:42:41 --> Security Class Initialized
DEBUG - 2018-03-26 21:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:42:41 --> Input Class Initialized
INFO - 2018-03-26 21:42:41 --> Language Class Initialized
INFO - 2018-03-26 21:42:41 --> Loader Class Initialized
INFO - 2018-03-26 21:42:41 --> Helper loaded: url_helper
INFO - 2018-03-26 21:42:41 --> Helper loaded: form_helper
INFO - 2018-03-26 21:42:41 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:42:41 --> Controller Class Initialized
INFO - 2018-03-26 21:42:41 --> Model Class Initialized
INFO - 2018-03-26 21:42:41 --> Model Class Initialized
INFO - 2018-03-26 21:42:41 --> Helper loaded: date_helper
INFO - 2018-03-26 21:42:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:43:03 --> Config Class Initialized
INFO - 2018-03-26 21:43:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:43:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:43:03 --> Utf8 Class Initialized
INFO - 2018-03-26 21:43:03 --> URI Class Initialized
INFO - 2018-03-26 21:43:03 --> Router Class Initialized
INFO - 2018-03-26 21:43:03 --> Output Class Initialized
INFO - 2018-03-26 21:43:03 --> Security Class Initialized
DEBUG - 2018-03-26 21:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:43:03 --> Input Class Initialized
INFO - 2018-03-26 21:43:03 --> Language Class Initialized
INFO - 2018-03-26 21:43:03 --> Loader Class Initialized
INFO - 2018-03-26 21:43:03 --> Helper loaded: url_helper
INFO - 2018-03-26 21:43:03 --> Helper loaded: form_helper
INFO - 2018-03-26 21:43:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:43:04 --> Controller Class Initialized
INFO - 2018-03-26 21:43:04 --> Model Class Initialized
INFO - 2018-03-26 21:43:04 --> Model Class Initialized
INFO - 2018-03-26 21:43:04 --> Helper loaded: date_helper
INFO - 2018-03-26 21:43:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:43:32 --> Config Class Initialized
INFO - 2018-03-26 21:43:32 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:43:32 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:43:32 --> Utf8 Class Initialized
INFO - 2018-03-26 21:43:32 --> URI Class Initialized
INFO - 2018-03-26 21:43:32 --> Router Class Initialized
INFO - 2018-03-26 21:43:32 --> Output Class Initialized
INFO - 2018-03-26 21:43:32 --> Security Class Initialized
DEBUG - 2018-03-26 21:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:43:32 --> Input Class Initialized
INFO - 2018-03-26 21:43:32 --> Language Class Initialized
INFO - 2018-03-26 21:43:32 --> Loader Class Initialized
INFO - 2018-03-26 21:43:32 --> Helper loaded: url_helper
INFO - 2018-03-26 21:43:32 --> Helper loaded: form_helper
INFO - 2018-03-26 21:43:32 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:43:32 --> Controller Class Initialized
INFO - 2018-03-26 21:43:32 --> Model Class Initialized
INFO - 2018-03-26 21:43:32 --> Model Class Initialized
INFO - 2018-03-26 21:43:32 --> Helper loaded: date_helper
INFO - 2018-03-26 21:43:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:43:39 --> Config Class Initialized
INFO - 2018-03-26 21:43:39 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:43:39 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:43:39 --> Utf8 Class Initialized
INFO - 2018-03-26 21:43:39 --> URI Class Initialized
INFO - 2018-03-26 21:43:39 --> Router Class Initialized
INFO - 2018-03-26 21:43:39 --> Output Class Initialized
INFO - 2018-03-26 21:43:39 --> Security Class Initialized
DEBUG - 2018-03-26 21:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:43:39 --> Input Class Initialized
INFO - 2018-03-26 21:43:39 --> Language Class Initialized
INFO - 2018-03-26 21:43:39 --> Loader Class Initialized
INFO - 2018-03-26 21:43:39 --> Helper loaded: url_helper
INFO - 2018-03-26 21:43:39 --> Helper loaded: form_helper
INFO - 2018-03-26 21:43:39 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:43:39 --> Controller Class Initialized
INFO - 2018-03-26 21:43:39 --> Model Class Initialized
INFO - 2018-03-26 21:43:39 --> Model Class Initialized
INFO - 2018-03-26 21:43:39 --> Helper loaded: date_helper
INFO - 2018-03-26 21:43:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:43:40 --> Config Class Initialized
INFO - 2018-03-26 21:43:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:43:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:43:40 --> Utf8 Class Initialized
INFO - 2018-03-26 21:43:40 --> URI Class Initialized
INFO - 2018-03-26 21:43:40 --> Router Class Initialized
INFO - 2018-03-26 21:43:40 --> Output Class Initialized
INFO - 2018-03-26 21:43:40 --> Security Class Initialized
DEBUG - 2018-03-26 21:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:43:40 --> Input Class Initialized
INFO - 2018-03-26 21:43:40 --> Language Class Initialized
INFO - 2018-03-26 21:43:40 --> Loader Class Initialized
INFO - 2018-03-26 21:43:40 --> Helper loaded: url_helper
INFO - 2018-03-26 21:43:40 --> Helper loaded: form_helper
INFO - 2018-03-26 21:43:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:43:40 --> Controller Class Initialized
INFO - 2018-03-26 21:43:40 --> Model Class Initialized
INFO - 2018-03-26 21:43:40 --> Model Class Initialized
INFO - 2018-03-26 21:43:40 --> Helper loaded: date_helper
INFO - 2018-03-26 21:43:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:43:53 --> Config Class Initialized
INFO - 2018-03-26 21:43:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:43:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:43:53 --> Utf8 Class Initialized
INFO - 2018-03-26 21:43:53 --> URI Class Initialized
INFO - 2018-03-26 21:43:53 --> Router Class Initialized
INFO - 2018-03-26 21:43:53 --> Output Class Initialized
INFO - 2018-03-26 21:43:53 --> Security Class Initialized
DEBUG - 2018-03-26 21:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:43:53 --> Input Class Initialized
INFO - 2018-03-26 21:43:53 --> Language Class Initialized
INFO - 2018-03-26 21:43:53 --> Loader Class Initialized
INFO - 2018-03-26 21:43:53 --> Helper loaded: url_helper
INFO - 2018-03-26 21:43:53 --> Helper loaded: form_helper
INFO - 2018-03-26 21:43:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:43:53 --> Controller Class Initialized
INFO - 2018-03-26 21:43:53 --> Model Class Initialized
INFO - 2018-03-26 21:43:53 --> Model Class Initialized
INFO - 2018-03-26 21:43:53 --> Model Class Initialized
INFO - 2018-03-26 21:43:53 --> Helper loaded: date_helper
INFO - 2018-03-26 21:43:53 --> Config Class Initialized
INFO - 2018-03-26 21:43:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:43:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:43:53 --> Utf8 Class Initialized
INFO - 2018-03-26 21:43:53 --> URI Class Initialized
INFO - 2018-03-26 21:43:53 --> Router Class Initialized
INFO - 2018-03-26 21:43:53 --> Output Class Initialized
INFO - 2018-03-26 21:43:53 --> Security Class Initialized
DEBUG - 2018-03-26 21:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:43:53 --> Input Class Initialized
INFO - 2018-03-26 21:43:53 --> Language Class Initialized
INFO - 2018-03-26 21:43:53 --> Loader Class Initialized
INFO - 2018-03-26 21:43:53 --> Helper loaded: url_helper
INFO - 2018-03-26 21:43:53 --> Helper loaded: form_helper
INFO - 2018-03-26 21:43:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:43:53 --> Controller Class Initialized
INFO - 2018-03-26 21:43:53 --> Model Class Initialized
INFO - 2018-03-26 21:43:53 --> Model Class Initialized
INFO - 2018-03-26 21:43:53 --> Model Class Initialized
INFO - 2018-03-26 21:43:53 --> Helper loaded: date_helper
INFO - 2018-03-26 21:43:56 --> Config Class Initialized
INFO - 2018-03-26 21:43:56 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:43:56 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:43:56 --> Utf8 Class Initialized
INFO - 2018-03-26 21:43:56 --> URI Class Initialized
INFO - 2018-03-26 21:43:56 --> Router Class Initialized
INFO - 2018-03-26 21:43:56 --> Output Class Initialized
INFO - 2018-03-26 21:43:56 --> Security Class Initialized
DEBUG - 2018-03-26 21:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:43:56 --> Input Class Initialized
INFO - 2018-03-26 21:43:56 --> Language Class Initialized
INFO - 2018-03-26 21:43:56 --> Loader Class Initialized
INFO - 2018-03-26 21:43:56 --> Helper loaded: url_helper
INFO - 2018-03-26 21:43:56 --> Helper loaded: form_helper
INFO - 2018-03-26 21:43:56 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:43:56 --> Controller Class Initialized
INFO - 2018-03-26 21:43:56 --> Model Class Initialized
INFO - 2018-03-26 21:43:56 --> Model Class Initialized
INFO - 2018-03-26 21:43:56 --> Model Class Initialized
INFO - 2018-03-26 21:43:56 --> Helper loaded: date_helper
INFO - 2018-03-26 21:43:56 --> Config Class Initialized
INFO - 2018-03-26 21:43:56 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:43:56 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:43:56 --> Utf8 Class Initialized
INFO - 2018-03-26 21:43:56 --> URI Class Initialized
INFO - 2018-03-26 21:43:56 --> Router Class Initialized
INFO - 2018-03-26 21:43:56 --> Output Class Initialized
INFO - 2018-03-26 21:43:56 --> Security Class Initialized
DEBUG - 2018-03-26 21:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:43:56 --> Input Class Initialized
INFO - 2018-03-26 21:43:56 --> Language Class Initialized
INFO - 2018-03-26 21:43:56 --> Loader Class Initialized
INFO - 2018-03-26 21:43:56 --> Helper loaded: url_helper
INFO - 2018-03-26 21:43:56 --> Helper loaded: form_helper
INFO - 2018-03-26 21:43:56 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:43:56 --> Controller Class Initialized
INFO - 2018-03-26 21:43:56 --> Model Class Initialized
INFO - 2018-03-26 21:43:56 --> Model Class Initialized
INFO - 2018-03-26 21:43:56 --> Model Class Initialized
INFO - 2018-03-26 21:43:56 --> Model Class Initialized
INFO - 2018-03-26 21:43:56 --> Model Class Initialized
INFO - 2018-03-26 21:43:56 --> Helper loaded: date_helper
INFO - 2018-03-26 21:44:07 --> Config Class Initialized
INFO - 2018-03-26 21:44:07 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:44:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:44:07 --> Utf8 Class Initialized
INFO - 2018-03-26 21:44:07 --> URI Class Initialized
INFO - 2018-03-26 21:44:07 --> Router Class Initialized
INFO - 2018-03-26 21:44:07 --> Output Class Initialized
INFO - 2018-03-26 21:44:07 --> Security Class Initialized
DEBUG - 2018-03-26 21:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:44:07 --> Input Class Initialized
INFO - 2018-03-26 21:44:07 --> Language Class Initialized
INFO - 2018-03-26 21:44:07 --> Loader Class Initialized
INFO - 2018-03-26 21:44:07 --> Helper loaded: url_helper
INFO - 2018-03-26 21:44:07 --> Helper loaded: form_helper
INFO - 2018-03-26 21:44:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:44:07 --> Controller Class Initialized
INFO - 2018-03-26 21:44:07 --> Model Class Initialized
INFO - 2018-03-26 21:44:07 --> Model Class Initialized
INFO - 2018-03-26 21:44:07 --> Helper loaded: date_helper
INFO - 2018-03-26 21:44:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:44:53 --> Config Class Initialized
INFO - 2018-03-26 21:44:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:44:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:44:53 --> Utf8 Class Initialized
INFO - 2018-03-26 21:44:53 --> URI Class Initialized
INFO - 2018-03-26 21:44:53 --> Router Class Initialized
INFO - 2018-03-26 21:44:53 --> Output Class Initialized
INFO - 2018-03-26 21:44:53 --> Security Class Initialized
DEBUG - 2018-03-26 21:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:44:53 --> Input Class Initialized
INFO - 2018-03-26 21:44:53 --> Language Class Initialized
INFO - 2018-03-26 21:44:53 --> Loader Class Initialized
INFO - 2018-03-26 21:44:53 --> Helper loaded: url_helper
INFO - 2018-03-26 21:44:53 --> Helper loaded: form_helper
INFO - 2018-03-26 21:44:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:44:53 --> Controller Class Initialized
INFO - 2018-03-26 21:44:53 --> Model Class Initialized
INFO - 2018-03-26 21:44:53 --> Model Class Initialized
INFO - 2018-03-26 21:44:53 --> Helper loaded: date_helper
INFO - 2018-03-26 21:44:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:44:57 --> Config Class Initialized
INFO - 2018-03-26 21:44:57 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:44:57 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:44:57 --> Utf8 Class Initialized
INFO - 2018-03-26 21:44:57 --> URI Class Initialized
INFO - 2018-03-26 21:44:57 --> Router Class Initialized
INFO - 2018-03-26 21:44:57 --> Output Class Initialized
INFO - 2018-03-26 21:44:57 --> Security Class Initialized
DEBUG - 2018-03-26 21:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:44:57 --> Input Class Initialized
INFO - 2018-03-26 21:44:57 --> Language Class Initialized
INFO - 2018-03-26 21:44:57 --> Loader Class Initialized
INFO - 2018-03-26 21:44:57 --> Helper loaded: url_helper
INFO - 2018-03-26 21:44:57 --> Helper loaded: form_helper
INFO - 2018-03-26 21:44:57 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:44:57 --> Controller Class Initialized
INFO - 2018-03-26 21:44:57 --> Model Class Initialized
INFO - 2018-03-26 21:44:57 --> Model Class Initialized
INFO - 2018-03-26 21:44:57 --> Helper loaded: date_helper
INFO - 2018-03-26 21:44:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:44:58 --> Config Class Initialized
INFO - 2018-03-26 21:44:58 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:44:58 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:44:58 --> Utf8 Class Initialized
INFO - 2018-03-26 21:44:58 --> URI Class Initialized
INFO - 2018-03-26 21:44:58 --> Router Class Initialized
INFO - 2018-03-26 21:44:58 --> Output Class Initialized
INFO - 2018-03-26 21:44:58 --> Security Class Initialized
DEBUG - 2018-03-26 21:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:44:58 --> Input Class Initialized
INFO - 2018-03-26 21:44:58 --> Language Class Initialized
INFO - 2018-03-26 21:44:58 --> Loader Class Initialized
INFO - 2018-03-26 21:44:58 --> Helper loaded: url_helper
INFO - 2018-03-26 21:44:58 --> Helper loaded: form_helper
INFO - 2018-03-26 21:44:58 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:44:58 --> Controller Class Initialized
INFO - 2018-03-26 21:44:58 --> Model Class Initialized
INFO - 2018-03-26 21:44:58 --> Model Class Initialized
INFO - 2018-03-26 21:44:58 --> Helper loaded: date_helper
INFO - 2018-03-26 21:44:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:45:53 --> Config Class Initialized
INFO - 2018-03-26 21:45:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:45:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:45:53 --> Utf8 Class Initialized
INFO - 2018-03-26 21:45:53 --> URI Class Initialized
INFO - 2018-03-26 21:45:53 --> Router Class Initialized
INFO - 2018-03-26 21:45:53 --> Output Class Initialized
INFO - 2018-03-26 21:45:53 --> Security Class Initialized
DEBUG - 2018-03-26 21:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:45:53 --> Input Class Initialized
INFO - 2018-03-26 21:45:53 --> Language Class Initialized
INFO - 2018-03-26 21:45:53 --> Loader Class Initialized
INFO - 2018-03-26 21:45:53 --> Helper loaded: url_helper
INFO - 2018-03-26 21:45:53 --> Helper loaded: form_helper
INFO - 2018-03-26 21:45:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:45:53 --> Controller Class Initialized
INFO - 2018-03-26 21:45:53 --> Model Class Initialized
INFO - 2018-03-26 21:45:53 --> Model Class Initialized
INFO - 2018-03-26 21:45:53 --> Helper loaded: date_helper
INFO - 2018-03-26 21:45:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:45:58 --> Config Class Initialized
INFO - 2018-03-26 21:45:58 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:45:58 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:45:58 --> Utf8 Class Initialized
INFO - 2018-03-26 21:45:58 --> URI Class Initialized
INFO - 2018-03-26 21:45:58 --> Router Class Initialized
INFO - 2018-03-26 21:45:58 --> Output Class Initialized
INFO - 2018-03-26 21:45:58 --> Security Class Initialized
DEBUG - 2018-03-26 21:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:45:58 --> Input Class Initialized
INFO - 2018-03-26 21:45:58 --> Language Class Initialized
INFO - 2018-03-26 21:45:58 --> Loader Class Initialized
INFO - 2018-03-26 21:45:58 --> Helper loaded: url_helper
INFO - 2018-03-26 21:45:58 --> Helper loaded: form_helper
INFO - 2018-03-26 21:45:58 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:45:58 --> Controller Class Initialized
INFO - 2018-03-26 21:45:58 --> Model Class Initialized
INFO - 2018-03-26 21:45:58 --> Model Class Initialized
INFO - 2018-03-26 21:45:58 --> Helper loaded: date_helper
INFO - 2018-03-26 21:45:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:45:58 --> Config Class Initialized
INFO - 2018-03-26 21:45:58 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:45:58 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:45:58 --> Utf8 Class Initialized
INFO - 2018-03-26 21:45:58 --> URI Class Initialized
INFO - 2018-03-26 21:45:58 --> Router Class Initialized
INFO - 2018-03-26 21:45:58 --> Output Class Initialized
INFO - 2018-03-26 21:45:58 --> Security Class Initialized
DEBUG - 2018-03-26 21:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:45:58 --> Input Class Initialized
INFO - 2018-03-26 21:45:58 --> Language Class Initialized
INFO - 2018-03-26 21:45:58 --> Loader Class Initialized
INFO - 2018-03-26 21:45:58 --> Helper loaded: url_helper
INFO - 2018-03-26 21:45:58 --> Helper loaded: form_helper
INFO - 2018-03-26 21:45:58 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:45:58 --> Controller Class Initialized
INFO - 2018-03-26 21:45:58 --> Model Class Initialized
INFO - 2018-03-26 21:45:58 --> Model Class Initialized
INFO - 2018-03-26 21:45:58 --> Helper loaded: date_helper
INFO - 2018-03-26 21:45:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:46:03 --> Config Class Initialized
INFO - 2018-03-26 21:46:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:46:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:46:03 --> Utf8 Class Initialized
INFO - 2018-03-26 21:46:03 --> URI Class Initialized
INFO - 2018-03-26 21:46:03 --> Router Class Initialized
INFO - 2018-03-26 21:46:03 --> Output Class Initialized
INFO - 2018-03-26 21:46:03 --> Security Class Initialized
DEBUG - 2018-03-26 21:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:46:03 --> Input Class Initialized
INFO - 2018-03-26 21:46:03 --> Language Class Initialized
INFO - 2018-03-26 21:46:03 --> Loader Class Initialized
INFO - 2018-03-26 21:46:03 --> Helper loaded: url_helper
INFO - 2018-03-26 21:46:03 --> Helper loaded: form_helper
INFO - 2018-03-26 21:46:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:46:03 --> Controller Class Initialized
INFO - 2018-03-26 21:46:03 --> Model Class Initialized
INFO - 2018-03-26 21:46:03 --> Model Class Initialized
INFO - 2018-03-26 21:46:03 --> Model Class Initialized
INFO - 2018-03-26 21:46:03 --> Helper loaded: date_helper
INFO - 2018-03-26 21:46:03 --> Config Class Initialized
INFO - 2018-03-26 21:46:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:46:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:46:03 --> Utf8 Class Initialized
INFO - 2018-03-26 21:46:03 --> URI Class Initialized
INFO - 2018-03-26 21:46:03 --> Router Class Initialized
INFO - 2018-03-26 21:46:03 --> Output Class Initialized
INFO - 2018-03-26 21:46:03 --> Security Class Initialized
DEBUG - 2018-03-26 21:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:46:03 --> Input Class Initialized
INFO - 2018-03-26 21:46:03 --> Language Class Initialized
INFO - 2018-03-26 21:46:03 --> Loader Class Initialized
INFO - 2018-03-26 21:46:03 --> Helper loaded: url_helper
INFO - 2018-03-26 21:46:03 --> Helper loaded: form_helper
INFO - 2018-03-26 21:46:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:46:03 --> Controller Class Initialized
INFO - 2018-03-26 21:46:03 --> Model Class Initialized
INFO - 2018-03-26 21:46:03 --> Model Class Initialized
INFO - 2018-03-26 21:46:03 --> Model Class Initialized
INFO - 2018-03-26 21:46:03 --> Helper loaded: date_helper
INFO - 2018-03-26 21:46:06 --> Config Class Initialized
INFO - 2018-03-26 21:46:06 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:46:06 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:46:06 --> Utf8 Class Initialized
INFO - 2018-03-26 21:46:06 --> URI Class Initialized
INFO - 2018-03-26 21:46:06 --> Router Class Initialized
INFO - 2018-03-26 21:46:06 --> Output Class Initialized
INFO - 2018-03-26 21:46:06 --> Security Class Initialized
DEBUG - 2018-03-26 21:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:46:06 --> Input Class Initialized
INFO - 2018-03-26 21:46:06 --> Language Class Initialized
INFO - 2018-03-26 21:46:06 --> Loader Class Initialized
INFO - 2018-03-26 21:46:06 --> Helper loaded: url_helper
INFO - 2018-03-26 21:46:06 --> Helper loaded: form_helper
INFO - 2018-03-26 21:46:06 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:46:06 --> Controller Class Initialized
INFO - 2018-03-26 21:46:06 --> Model Class Initialized
INFO - 2018-03-26 21:46:06 --> Model Class Initialized
INFO - 2018-03-26 21:46:06 --> Model Class Initialized
INFO - 2018-03-26 21:46:06 --> Helper loaded: date_helper
INFO - 2018-03-26 21:46:10 --> Config Class Initialized
INFO - 2018-03-26 21:46:10 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:46:10 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:46:10 --> Utf8 Class Initialized
INFO - 2018-03-26 21:46:10 --> URI Class Initialized
INFO - 2018-03-26 21:46:10 --> Router Class Initialized
INFO - 2018-03-26 21:46:10 --> Output Class Initialized
INFO - 2018-03-26 21:46:10 --> Security Class Initialized
DEBUG - 2018-03-26 21:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:46:10 --> Input Class Initialized
INFO - 2018-03-26 21:46:10 --> Language Class Initialized
INFO - 2018-03-26 21:46:10 --> Loader Class Initialized
INFO - 2018-03-26 21:46:10 --> Helper loaded: url_helper
INFO - 2018-03-26 21:46:10 --> Helper loaded: form_helper
INFO - 2018-03-26 21:46:10 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:46:10 --> Controller Class Initialized
INFO - 2018-03-26 21:46:10 --> Model Class Initialized
INFO - 2018-03-26 21:46:10 --> Model Class Initialized
INFO - 2018-03-26 21:46:10 --> Model Class Initialized
INFO - 2018-03-26 21:46:10 --> Helper loaded: date_helper
INFO - 2018-03-26 21:46:15 --> Config Class Initialized
INFO - 2018-03-26 21:46:15 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:46:15 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:46:15 --> Utf8 Class Initialized
INFO - 2018-03-26 21:46:15 --> URI Class Initialized
INFO - 2018-03-26 21:46:15 --> Router Class Initialized
INFO - 2018-03-26 21:46:15 --> Output Class Initialized
INFO - 2018-03-26 21:46:15 --> Security Class Initialized
DEBUG - 2018-03-26 21:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:46:15 --> Input Class Initialized
INFO - 2018-03-26 21:46:15 --> Language Class Initialized
INFO - 2018-03-26 21:46:15 --> Loader Class Initialized
INFO - 2018-03-26 21:46:15 --> Helper loaded: url_helper
INFO - 2018-03-26 21:46:15 --> Helper loaded: form_helper
INFO - 2018-03-26 21:46:15 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:46:15 --> Controller Class Initialized
INFO - 2018-03-26 21:46:15 --> Model Class Initialized
INFO - 2018-03-26 21:46:15 --> Model Class Initialized
INFO - 2018-03-26 21:46:15 --> Model Class Initialized
INFO - 2018-03-26 21:46:15 --> Helper loaded: date_helper
INFO - 2018-03-26 21:46:16 --> Config Class Initialized
INFO - 2018-03-26 21:46:16 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:46:16 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:46:16 --> Utf8 Class Initialized
INFO - 2018-03-26 21:46:16 --> URI Class Initialized
INFO - 2018-03-26 21:46:16 --> Router Class Initialized
INFO - 2018-03-26 21:46:16 --> Output Class Initialized
INFO - 2018-03-26 21:46:16 --> Security Class Initialized
DEBUG - 2018-03-26 21:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:46:16 --> Input Class Initialized
INFO - 2018-03-26 21:46:16 --> Language Class Initialized
INFO - 2018-03-26 21:46:16 --> Loader Class Initialized
INFO - 2018-03-26 21:46:16 --> Helper loaded: url_helper
INFO - 2018-03-26 21:46:16 --> Helper loaded: form_helper
INFO - 2018-03-26 21:46:16 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:46:16 --> Controller Class Initialized
INFO - 2018-03-26 21:46:16 --> Model Class Initialized
INFO - 2018-03-26 21:46:16 --> Model Class Initialized
INFO - 2018-03-26 21:46:16 --> Model Class Initialized
INFO - 2018-03-26 21:46:16 --> Model Class Initialized
INFO - 2018-03-26 21:46:16 --> Model Class Initialized
INFO - 2018-03-26 21:46:16 --> Helper loaded: date_helper
INFO - 2018-03-26 21:46:22 --> Config Class Initialized
INFO - 2018-03-26 21:46:22 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:46:22 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:46:22 --> Utf8 Class Initialized
INFO - 2018-03-26 21:46:22 --> URI Class Initialized
INFO - 2018-03-26 21:46:22 --> Router Class Initialized
INFO - 2018-03-26 21:46:22 --> Output Class Initialized
INFO - 2018-03-26 21:46:22 --> Security Class Initialized
DEBUG - 2018-03-26 21:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:46:22 --> Input Class Initialized
INFO - 2018-03-26 21:46:22 --> Language Class Initialized
INFO - 2018-03-26 21:46:22 --> Loader Class Initialized
INFO - 2018-03-26 21:46:22 --> Helper loaded: url_helper
INFO - 2018-03-26 21:46:22 --> Helper loaded: form_helper
INFO - 2018-03-26 21:46:22 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:46:22 --> Controller Class Initialized
INFO - 2018-03-26 21:46:22 --> Model Class Initialized
INFO - 2018-03-26 21:46:22 --> Model Class Initialized
INFO - 2018-03-26 21:46:22 --> Helper loaded: date_helper
INFO - 2018-03-26 21:46:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:46:26 --> Config Class Initialized
INFO - 2018-03-26 21:46:26 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:46:26 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:46:26 --> Utf8 Class Initialized
INFO - 2018-03-26 21:46:26 --> URI Class Initialized
INFO - 2018-03-26 21:46:26 --> Router Class Initialized
INFO - 2018-03-26 21:46:26 --> Output Class Initialized
INFO - 2018-03-26 21:46:26 --> Security Class Initialized
DEBUG - 2018-03-26 21:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:46:26 --> Input Class Initialized
INFO - 2018-03-26 21:46:26 --> Language Class Initialized
INFO - 2018-03-26 21:46:26 --> Loader Class Initialized
INFO - 2018-03-26 21:46:26 --> Helper loaded: url_helper
INFO - 2018-03-26 21:46:26 --> Helper loaded: form_helper
INFO - 2018-03-26 21:46:26 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:46:26 --> Controller Class Initialized
INFO - 2018-03-26 21:46:26 --> Model Class Initialized
INFO - 2018-03-26 21:46:26 --> Model Class Initialized
INFO - 2018-03-26 21:46:26 --> Helper loaded: date_helper
INFO - 2018-03-26 21:46:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:46:26 --> Config Class Initialized
INFO - 2018-03-26 21:46:26 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:46:26 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:46:26 --> Utf8 Class Initialized
INFO - 2018-03-26 21:46:26 --> URI Class Initialized
INFO - 2018-03-26 21:46:26 --> Router Class Initialized
INFO - 2018-03-26 21:46:26 --> Output Class Initialized
INFO - 2018-03-26 21:46:26 --> Security Class Initialized
DEBUG - 2018-03-26 21:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:46:26 --> Input Class Initialized
INFO - 2018-03-26 21:46:26 --> Language Class Initialized
INFO - 2018-03-26 21:46:26 --> Loader Class Initialized
INFO - 2018-03-26 21:46:26 --> Helper loaded: url_helper
INFO - 2018-03-26 21:46:26 --> Helper loaded: form_helper
INFO - 2018-03-26 21:46:26 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:46:26 --> Controller Class Initialized
INFO - 2018-03-26 21:46:26 --> Model Class Initialized
INFO - 2018-03-26 21:46:26 --> Model Class Initialized
INFO - 2018-03-26 21:46:26 --> Helper loaded: date_helper
INFO - 2018-03-26 21:46:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:46:49 --> Config Class Initialized
INFO - 2018-03-26 21:46:49 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:46:49 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:46:49 --> Utf8 Class Initialized
INFO - 2018-03-26 21:46:49 --> URI Class Initialized
INFO - 2018-03-26 21:46:49 --> Router Class Initialized
INFO - 2018-03-26 21:46:49 --> Output Class Initialized
INFO - 2018-03-26 21:46:49 --> Security Class Initialized
DEBUG - 2018-03-26 21:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:46:49 --> Input Class Initialized
INFO - 2018-03-26 21:46:49 --> Language Class Initialized
INFO - 2018-03-26 21:46:49 --> Loader Class Initialized
INFO - 2018-03-26 21:46:49 --> Helper loaded: url_helper
INFO - 2018-03-26 21:46:49 --> Helper loaded: form_helper
INFO - 2018-03-26 21:46:49 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:46:49 --> Controller Class Initialized
INFO - 2018-03-26 21:46:49 --> Model Class Initialized
INFO - 2018-03-26 21:46:49 --> Model Class Initialized
INFO - 2018-03-26 21:46:49 --> Helper loaded: date_helper
INFO - 2018-03-26 21:46:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:46:51 --> Config Class Initialized
INFO - 2018-03-26 21:46:51 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:46:51 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:46:51 --> Utf8 Class Initialized
INFO - 2018-03-26 21:46:51 --> URI Class Initialized
INFO - 2018-03-26 21:46:51 --> Router Class Initialized
INFO - 2018-03-26 21:46:51 --> Output Class Initialized
INFO - 2018-03-26 21:46:51 --> Security Class Initialized
DEBUG - 2018-03-26 21:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:46:51 --> Input Class Initialized
INFO - 2018-03-26 21:46:51 --> Language Class Initialized
INFO - 2018-03-26 21:46:51 --> Loader Class Initialized
INFO - 2018-03-26 21:46:51 --> Helper loaded: url_helper
INFO - 2018-03-26 21:46:51 --> Helper loaded: form_helper
INFO - 2018-03-26 21:46:51 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:46:51 --> Controller Class Initialized
INFO - 2018-03-26 21:46:51 --> Model Class Initialized
INFO - 2018-03-26 21:46:51 --> Model Class Initialized
INFO - 2018-03-26 21:46:51 --> Model Class Initialized
INFO - 2018-03-26 21:46:51 --> Helper loaded: date_helper
INFO - 2018-03-26 21:46:51 --> Config Class Initialized
INFO - 2018-03-26 21:46:51 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:46:51 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:46:51 --> Utf8 Class Initialized
INFO - 2018-03-26 21:46:51 --> URI Class Initialized
INFO - 2018-03-26 21:46:51 --> Router Class Initialized
INFO - 2018-03-26 21:46:51 --> Output Class Initialized
INFO - 2018-03-26 21:46:51 --> Security Class Initialized
DEBUG - 2018-03-26 21:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:46:51 --> Input Class Initialized
INFO - 2018-03-26 21:46:51 --> Language Class Initialized
INFO - 2018-03-26 21:46:51 --> Loader Class Initialized
INFO - 2018-03-26 21:46:51 --> Helper loaded: url_helper
INFO - 2018-03-26 21:46:51 --> Helper loaded: form_helper
INFO - 2018-03-26 21:46:51 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:46:51 --> Controller Class Initialized
INFO - 2018-03-26 21:46:51 --> Model Class Initialized
INFO - 2018-03-26 21:46:51 --> Model Class Initialized
INFO - 2018-03-26 21:46:51 --> Model Class Initialized
INFO - 2018-03-26 21:46:51 --> Helper loaded: date_helper
INFO - 2018-03-26 21:46:54 --> Config Class Initialized
INFO - 2018-03-26 21:46:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:46:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:46:54 --> Utf8 Class Initialized
INFO - 2018-03-26 21:46:54 --> URI Class Initialized
INFO - 2018-03-26 21:46:54 --> Router Class Initialized
INFO - 2018-03-26 21:46:54 --> Output Class Initialized
INFO - 2018-03-26 21:46:54 --> Security Class Initialized
DEBUG - 2018-03-26 21:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:46:54 --> Input Class Initialized
INFO - 2018-03-26 21:46:54 --> Language Class Initialized
INFO - 2018-03-26 21:46:54 --> Loader Class Initialized
INFO - 2018-03-26 21:46:54 --> Helper loaded: url_helper
INFO - 2018-03-26 21:46:54 --> Helper loaded: form_helper
INFO - 2018-03-26 21:46:54 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:46:54 --> Controller Class Initialized
INFO - 2018-03-26 21:46:54 --> Model Class Initialized
INFO - 2018-03-26 21:46:54 --> Model Class Initialized
INFO - 2018-03-26 21:46:54 --> Model Class Initialized
INFO - 2018-03-26 21:46:54 --> Helper loaded: date_helper
INFO - 2018-03-26 21:46:54 --> Config Class Initialized
INFO - 2018-03-26 21:46:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:46:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:46:54 --> Utf8 Class Initialized
INFO - 2018-03-26 21:46:54 --> URI Class Initialized
INFO - 2018-03-26 21:46:54 --> Router Class Initialized
INFO - 2018-03-26 21:46:54 --> Output Class Initialized
INFO - 2018-03-26 21:46:54 --> Security Class Initialized
DEBUG - 2018-03-26 21:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:46:54 --> Input Class Initialized
INFO - 2018-03-26 21:46:54 --> Language Class Initialized
INFO - 2018-03-26 21:46:54 --> Loader Class Initialized
INFO - 2018-03-26 21:46:54 --> Helper loaded: url_helper
INFO - 2018-03-26 21:46:54 --> Helper loaded: form_helper
INFO - 2018-03-26 21:46:54 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:46:54 --> Controller Class Initialized
INFO - 2018-03-26 21:46:54 --> Model Class Initialized
INFO - 2018-03-26 21:46:54 --> Model Class Initialized
INFO - 2018-03-26 21:46:54 --> Model Class Initialized
INFO - 2018-03-26 21:46:54 --> Model Class Initialized
INFO - 2018-03-26 21:46:54 --> Model Class Initialized
INFO - 2018-03-26 21:46:54 --> Helper loaded: date_helper
INFO - 2018-03-26 21:46:56 --> Config Class Initialized
INFO - 2018-03-26 21:46:56 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:46:56 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:46:56 --> Utf8 Class Initialized
INFO - 2018-03-26 21:46:56 --> URI Class Initialized
INFO - 2018-03-26 21:46:56 --> Router Class Initialized
INFO - 2018-03-26 21:46:56 --> Output Class Initialized
INFO - 2018-03-26 21:46:56 --> Security Class Initialized
DEBUG - 2018-03-26 21:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:46:56 --> Input Class Initialized
INFO - 2018-03-26 21:46:56 --> Language Class Initialized
INFO - 2018-03-26 21:46:56 --> Loader Class Initialized
INFO - 2018-03-26 21:46:56 --> Helper loaded: url_helper
INFO - 2018-03-26 21:46:56 --> Helper loaded: form_helper
INFO - 2018-03-26 21:46:56 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:46:56 --> Controller Class Initialized
INFO - 2018-03-26 21:46:56 --> Model Class Initialized
INFO - 2018-03-26 21:46:56 --> Model Class Initialized
INFO - 2018-03-26 21:46:56 --> Helper loaded: date_helper
INFO - 2018-03-26 21:46:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:47:01 --> Config Class Initialized
INFO - 2018-03-26 21:47:01 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:47:01 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:47:01 --> Utf8 Class Initialized
INFO - 2018-03-26 21:47:01 --> URI Class Initialized
INFO - 2018-03-26 21:47:01 --> Router Class Initialized
INFO - 2018-03-26 21:47:01 --> Output Class Initialized
INFO - 2018-03-26 21:47:01 --> Security Class Initialized
DEBUG - 2018-03-26 21:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:47:01 --> Input Class Initialized
INFO - 2018-03-26 21:47:01 --> Language Class Initialized
INFO - 2018-03-26 21:47:01 --> Loader Class Initialized
INFO - 2018-03-26 21:47:01 --> Helper loaded: url_helper
INFO - 2018-03-26 21:47:01 --> Helper loaded: form_helper
INFO - 2018-03-26 21:47:01 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:47:01 --> Controller Class Initialized
INFO - 2018-03-26 21:47:01 --> Model Class Initialized
INFO - 2018-03-26 21:47:01 --> Model Class Initialized
INFO - 2018-03-26 21:47:01 --> Helper loaded: date_helper
INFO - 2018-03-26 21:47:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:47:01 --> Config Class Initialized
INFO - 2018-03-26 21:47:01 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:47:01 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:47:01 --> Utf8 Class Initialized
INFO - 2018-03-26 21:47:01 --> URI Class Initialized
INFO - 2018-03-26 21:47:01 --> Router Class Initialized
INFO - 2018-03-26 21:47:01 --> Output Class Initialized
INFO - 2018-03-26 21:47:01 --> Security Class Initialized
DEBUG - 2018-03-26 21:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:47:01 --> Input Class Initialized
INFO - 2018-03-26 21:47:01 --> Language Class Initialized
INFO - 2018-03-26 21:47:01 --> Loader Class Initialized
INFO - 2018-03-26 21:47:01 --> Helper loaded: url_helper
INFO - 2018-03-26 21:47:01 --> Helper loaded: form_helper
INFO - 2018-03-26 21:47:01 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:47:01 --> Controller Class Initialized
INFO - 2018-03-26 21:47:01 --> Model Class Initialized
INFO - 2018-03-26 21:47:01 --> Model Class Initialized
INFO - 2018-03-26 21:47:01 --> Helper loaded: date_helper
INFO - 2018-03-26 21:47:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:47:16 --> Config Class Initialized
INFO - 2018-03-26 21:47:16 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:47:16 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:47:16 --> Utf8 Class Initialized
INFO - 2018-03-26 21:47:16 --> URI Class Initialized
INFO - 2018-03-26 21:47:16 --> Router Class Initialized
INFO - 2018-03-26 21:47:16 --> Output Class Initialized
INFO - 2018-03-26 21:47:16 --> Security Class Initialized
DEBUG - 2018-03-26 21:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:47:16 --> Input Class Initialized
INFO - 2018-03-26 21:47:16 --> Language Class Initialized
INFO - 2018-03-26 21:47:16 --> Loader Class Initialized
INFO - 2018-03-26 21:47:16 --> Helper loaded: url_helper
INFO - 2018-03-26 21:47:16 --> Helper loaded: form_helper
INFO - 2018-03-26 21:47:16 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:47:16 --> Controller Class Initialized
INFO - 2018-03-26 21:47:16 --> Model Class Initialized
INFO - 2018-03-26 21:47:16 --> Model Class Initialized
INFO - 2018-03-26 21:47:16 --> Helper loaded: date_helper
INFO - 2018-03-26 21:47:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:48:49 --> Config Class Initialized
INFO - 2018-03-26 21:48:49 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:48:49 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:48:49 --> Utf8 Class Initialized
INFO - 2018-03-26 21:48:49 --> URI Class Initialized
INFO - 2018-03-26 21:48:49 --> Router Class Initialized
INFO - 2018-03-26 21:48:49 --> Output Class Initialized
INFO - 2018-03-26 21:48:49 --> Security Class Initialized
DEBUG - 2018-03-26 21:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:48:49 --> Input Class Initialized
INFO - 2018-03-26 21:48:49 --> Language Class Initialized
INFO - 2018-03-26 21:48:49 --> Loader Class Initialized
INFO - 2018-03-26 21:48:49 --> Helper loaded: url_helper
INFO - 2018-03-26 21:48:49 --> Helper loaded: form_helper
INFO - 2018-03-26 21:48:49 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:48:49 --> Controller Class Initialized
INFO - 2018-03-26 21:48:49 --> Model Class Initialized
INFO - 2018-03-26 21:48:49 --> Model Class Initialized
INFO - 2018-03-26 21:48:49 --> Model Class Initialized
INFO - 2018-03-26 21:48:49 --> Model Class Initialized
INFO - 2018-03-26 21:48:49 --> Model Class Initialized
INFO - 2018-03-26 21:48:49 --> Model Class Initialized
INFO - 2018-03-26 21:48:49 --> Model Class Initialized
INFO - 2018-03-26 21:48:49 --> Model Class Initialized
INFO - 2018-03-26 21:48:49 --> Model Class Initialized
INFO - 2018-03-26 21:48:49 --> Model Class Initialized
INFO - 2018-03-26 21:48:49 --> Model Class Initialized
INFO - 2018-03-26 21:48:49 --> Model Class Initialized
INFO - 2018-03-26 21:48:49 --> Model Class Initialized
INFO - 2018-03-26 21:48:49 --> Model Class Initialized
INFO - 2018-03-26 21:48:49 --> Helper loaded: date_helper
INFO - 2018-03-26 21:48:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:48:56 --> Config Class Initialized
INFO - 2018-03-26 21:48:56 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:48:56 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:48:56 --> Utf8 Class Initialized
INFO - 2018-03-26 21:48:56 --> URI Class Initialized
INFO - 2018-03-26 21:48:56 --> Router Class Initialized
INFO - 2018-03-26 21:48:56 --> Output Class Initialized
INFO - 2018-03-26 21:48:56 --> Security Class Initialized
DEBUG - 2018-03-26 21:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:48:56 --> Input Class Initialized
INFO - 2018-03-26 21:48:56 --> Language Class Initialized
INFO - 2018-03-26 21:48:56 --> Loader Class Initialized
INFO - 2018-03-26 21:48:56 --> Helper loaded: url_helper
INFO - 2018-03-26 21:48:56 --> Helper loaded: form_helper
INFO - 2018-03-26 21:48:56 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:48:56 --> Controller Class Initialized
INFO - 2018-03-26 21:48:56 --> Model Class Initialized
INFO - 2018-03-26 21:48:56 --> Model Class Initialized
INFO - 2018-03-26 21:48:56 --> Model Class Initialized
INFO - 2018-03-26 21:48:56 --> Model Class Initialized
INFO - 2018-03-26 21:48:56 --> Model Class Initialized
INFO - 2018-03-26 21:48:56 --> Model Class Initialized
INFO - 2018-03-26 21:48:56 --> Model Class Initialized
INFO - 2018-03-26 21:48:56 --> Model Class Initialized
INFO - 2018-03-26 21:48:56 --> Model Class Initialized
INFO - 2018-03-26 21:48:56 --> Model Class Initialized
INFO - 2018-03-26 21:48:56 --> Model Class Initialized
INFO - 2018-03-26 21:48:56 --> Model Class Initialized
INFO - 2018-03-26 21:48:56 --> Model Class Initialized
INFO - 2018-03-26 21:48:56 --> Model Class Initialized
INFO - 2018-03-26 21:48:56 --> Helper loaded: date_helper
INFO - 2018-03-26 21:48:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:48:58 --> Config Class Initialized
INFO - 2018-03-26 21:48:58 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:48:58 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:48:58 --> Utf8 Class Initialized
INFO - 2018-03-26 21:48:58 --> URI Class Initialized
INFO - 2018-03-26 21:48:58 --> Router Class Initialized
INFO - 2018-03-26 21:48:58 --> Output Class Initialized
INFO - 2018-03-26 21:48:58 --> Security Class Initialized
DEBUG - 2018-03-26 21:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:48:58 --> Input Class Initialized
INFO - 2018-03-26 21:48:58 --> Language Class Initialized
INFO - 2018-03-26 21:48:58 --> Loader Class Initialized
INFO - 2018-03-26 21:48:58 --> Helper loaded: url_helper
INFO - 2018-03-26 21:48:58 --> Helper loaded: form_helper
INFO - 2018-03-26 21:48:58 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:48:58 --> Controller Class Initialized
INFO - 2018-03-26 21:48:58 --> Model Class Initialized
INFO - 2018-03-26 21:48:58 --> Model Class Initialized
INFO - 2018-03-26 21:48:58 --> Model Class Initialized
INFO - 2018-03-26 21:48:58 --> Model Class Initialized
INFO - 2018-03-26 21:48:58 --> Model Class Initialized
INFO - 2018-03-26 21:48:58 --> Model Class Initialized
INFO - 2018-03-26 21:48:58 --> Model Class Initialized
INFO - 2018-03-26 21:48:58 --> Model Class Initialized
INFO - 2018-03-26 21:48:58 --> Model Class Initialized
INFO - 2018-03-26 21:48:58 --> Model Class Initialized
INFO - 2018-03-26 21:48:58 --> Model Class Initialized
INFO - 2018-03-26 21:48:58 --> Model Class Initialized
INFO - 2018-03-26 21:48:58 --> Model Class Initialized
INFO - 2018-03-26 21:48:58 --> Model Class Initialized
INFO - 2018-03-26 21:48:58 --> Helper loaded: date_helper
INFO - 2018-03-26 21:48:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:49:01 --> Config Class Initialized
INFO - 2018-03-26 21:49:01 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:49:01 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:49:01 --> Utf8 Class Initialized
INFO - 2018-03-26 21:49:01 --> URI Class Initialized
INFO - 2018-03-26 21:49:01 --> Router Class Initialized
INFO - 2018-03-26 21:49:01 --> Output Class Initialized
INFO - 2018-03-26 21:49:01 --> Security Class Initialized
DEBUG - 2018-03-26 21:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:49:01 --> Input Class Initialized
INFO - 2018-03-26 21:49:01 --> Language Class Initialized
INFO - 2018-03-26 21:49:01 --> Loader Class Initialized
INFO - 2018-03-26 21:49:01 --> Helper loaded: url_helper
INFO - 2018-03-26 21:49:01 --> Helper loaded: form_helper
INFO - 2018-03-26 21:49:01 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:49:01 --> Controller Class Initialized
INFO - 2018-03-26 21:49:01 --> Model Class Initialized
INFO - 2018-03-26 21:49:01 --> Model Class Initialized
INFO - 2018-03-26 21:49:01 --> Model Class Initialized
INFO - 2018-03-26 21:49:01 --> Model Class Initialized
INFO - 2018-03-26 21:49:01 --> Model Class Initialized
INFO - 2018-03-26 21:49:01 --> Model Class Initialized
INFO - 2018-03-26 21:49:01 --> Model Class Initialized
INFO - 2018-03-26 21:49:01 --> Model Class Initialized
INFO - 2018-03-26 21:49:01 --> Model Class Initialized
INFO - 2018-03-26 21:49:01 --> Model Class Initialized
INFO - 2018-03-26 21:49:01 --> Model Class Initialized
INFO - 2018-03-26 21:49:01 --> Model Class Initialized
INFO - 2018-03-26 21:49:01 --> Model Class Initialized
INFO - 2018-03-26 21:49:01 --> Model Class Initialized
INFO - 2018-03-26 21:49:01 --> Helper loaded: date_helper
INFO - 2018-03-26 21:49:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:49:18 --> Config Class Initialized
INFO - 2018-03-26 21:49:18 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:49:18 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:49:18 --> Utf8 Class Initialized
INFO - 2018-03-26 21:49:18 --> URI Class Initialized
INFO - 2018-03-26 21:49:18 --> Router Class Initialized
INFO - 2018-03-26 21:49:18 --> Output Class Initialized
INFO - 2018-03-26 21:49:18 --> Security Class Initialized
DEBUG - 2018-03-26 21:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:49:18 --> Input Class Initialized
INFO - 2018-03-26 21:49:18 --> Language Class Initialized
INFO - 2018-03-26 21:49:18 --> Loader Class Initialized
INFO - 2018-03-26 21:49:18 --> Helper loaded: url_helper
INFO - 2018-03-26 21:49:18 --> Helper loaded: form_helper
INFO - 2018-03-26 21:49:18 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:49:18 --> Controller Class Initialized
INFO - 2018-03-26 21:49:18 --> Model Class Initialized
INFO - 2018-03-26 21:49:18 --> Model Class Initialized
INFO - 2018-03-26 21:49:18 --> Model Class Initialized
INFO - 2018-03-26 21:49:18 --> Model Class Initialized
INFO - 2018-03-26 21:49:18 --> Model Class Initialized
INFO - 2018-03-26 21:49:18 --> Model Class Initialized
INFO - 2018-03-26 21:49:18 --> Model Class Initialized
INFO - 2018-03-26 21:49:18 --> Model Class Initialized
INFO - 2018-03-26 21:49:18 --> Model Class Initialized
INFO - 2018-03-26 21:49:18 --> Model Class Initialized
INFO - 2018-03-26 21:49:18 --> Model Class Initialized
INFO - 2018-03-26 21:49:18 --> Model Class Initialized
INFO - 2018-03-26 21:49:18 --> Model Class Initialized
INFO - 2018-03-26 21:49:18 --> Model Class Initialized
INFO - 2018-03-26 21:49:18 --> Helper loaded: date_helper
INFO - 2018-03-26 21:49:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:52:38 --> Config Class Initialized
INFO - 2018-03-26 21:52:38 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:52:38 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:52:38 --> Utf8 Class Initialized
INFO - 2018-03-26 21:52:38 --> URI Class Initialized
INFO - 2018-03-26 21:52:38 --> Router Class Initialized
INFO - 2018-03-26 21:52:38 --> Output Class Initialized
INFO - 2018-03-26 21:52:38 --> Security Class Initialized
DEBUG - 2018-03-26 21:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:52:38 --> Input Class Initialized
INFO - 2018-03-26 21:52:38 --> Language Class Initialized
INFO - 2018-03-26 21:52:39 --> Loader Class Initialized
INFO - 2018-03-26 21:52:39 --> Helper loaded: url_helper
INFO - 2018-03-26 21:52:39 --> Helper loaded: form_helper
INFO - 2018-03-26 21:52:39 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:52:39 --> Controller Class Initialized
INFO - 2018-03-26 21:52:39 --> Model Class Initialized
INFO - 2018-03-26 21:52:39 --> Model Class Initialized
INFO - 2018-03-26 21:52:39 --> Helper loaded: date_helper
INFO - 2018-03-26 21:52:53 --> Config Class Initialized
INFO - 2018-03-26 21:52:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:52:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:52:53 --> Utf8 Class Initialized
INFO - 2018-03-26 21:52:53 --> URI Class Initialized
INFO - 2018-03-26 21:52:53 --> Router Class Initialized
INFO - 2018-03-26 21:52:53 --> Output Class Initialized
INFO - 2018-03-26 21:52:53 --> Security Class Initialized
DEBUG - 2018-03-26 21:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:52:53 --> Input Class Initialized
INFO - 2018-03-26 21:52:53 --> Language Class Initialized
INFO - 2018-03-26 21:52:53 --> Loader Class Initialized
INFO - 2018-03-26 21:52:53 --> Helper loaded: url_helper
INFO - 2018-03-26 21:52:53 --> Helper loaded: form_helper
INFO - 2018-03-26 21:52:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:52:53 --> Controller Class Initialized
INFO - 2018-03-26 21:52:53 --> Model Class Initialized
INFO - 2018-03-26 21:52:53 --> Model Class Initialized
INFO - 2018-03-26 21:52:53 --> Helper loaded: date_helper
INFO - 2018-03-26 21:52:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:53:11 --> Config Class Initialized
INFO - 2018-03-26 21:53:11 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:53:11 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:53:11 --> Utf8 Class Initialized
INFO - 2018-03-26 21:53:11 --> URI Class Initialized
INFO - 2018-03-26 21:53:11 --> Router Class Initialized
INFO - 2018-03-26 21:53:11 --> Output Class Initialized
INFO - 2018-03-26 21:53:11 --> Security Class Initialized
DEBUG - 2018-03-26 21:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:53:11 --> Input Class Initialized
INFO - 2018-03-26 21:53:11 --> Language Class Initialized
INFO - 2018-03-26 21:53:11 --> Loader Class Initialized
INFO - 2018-03-26 21:53:11 --> Helper loaded: url_helper
INFO - 2018-03-26 21:53:11 --> Helper loaded: form_helper
INFO - 2018-03-26 21:53:11 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:53:11 --> Controller Class Initialized
INFO - 2018-03-26 21:53:11 --> Model Class Initialized
INFO - 2018-03-26 21:53:11 --> Model Class Initialized
INFO - 2018-03-26 21:53:11 --> Helper loaded: date_helper
INFO - 2018-03-26 21:53:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:53:31 --> Config Class Initialized
INFO - 2018-03-26 21:53:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:53:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:53:31 --> Utf8 Class Initialized
INFO - 2018-03-26 21:53:31 --> URI Class Initialized
INFO - 2018-03-26 21:53:31 --> Router Class Initialized
INFO - 2018-03-26 21:53:31 --> Output Class Initialized
INFO - 2018-03-26 21:53:31 --> Security Class Initialized
DEBUG - 2018-03-26 21:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:53:31 --> Input Class Initialized
INFO - 2018-03-26 21:53:31 --> Language Class Initialized
INFO - 2018-03-26 21:53:32 --> Loader Class Initialized
INFO - 2018-03-26 21:53:32 --> Helper loaded: url_helper
INFO - 2018-03-26 21:53:32 --> Helper loaded: form_helper
INFO - 2018-03-26 21:53:32 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:53:32 --> Controller Class Initialized
INFO - 2018-03-26 21:53:32 --> Model Class Initialized
INFO - 2018-03-26 21:53:32 --> Model Class Initialized
INFO - 2018-03-26 21:53:32 --> Helper loaded: date_helper
INFO - 2018-03-26 21:53:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:53:39 --> Config Class Initialized
INFO - 2018-03-26 21:53:39 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:53:39 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:53:39 --> Utf8 Class Initialized
INFO - 2018-03-26 21:53:39 --> URI Class Initialized
INFO - 2018-03-26 21:53:39 --> Router Class Initialized
INFO - 2018-03-26 21:53:40 --> Output Class Initialized
INFO - 2018-03-26 21:53:40 --> Security Class Initialized
DEBUG - 2018-03-26 21:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:53:40 --> Input Class Initialized
INFO - 2018-03-26 21:53:40 --> Language Class Initialized
INFO - 2018-03-26 21:53:40 --> Loader Class Initialized
INFO - 2018-03-26 21:53:40 --> Helper loaded: url_helper
INFO - 2018-03-26 21:53:40 --> Helper loaded: form_helper
INFO - 2018-03-26 21:53:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:53:40 --> Controller Class Initialized
INFO - 2018-03-26 21:53:40 --> Model Class Initialized
INFO - 2018-03-26 21:53:40 --> Model Class Initialized
INFO - 2018-03-26 21:53:40 --> Helper loaded: date_helper
INFO - 2018-03-26 21:53:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:53:50 --> Config Class Initialized
INFO - 2018-03-26 21:53:50 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:53:50 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:53:50 --> Utf8 Class Initialized
INFO - 2018-03-26 21:53:50 --> URI Class Initialized
INFO - 2018-03-26 21:53:50 --> Router Class Initialized
INFO - 2018-03-26 21:53:50 --> Output Class Initialized
INFO - 2018-03-26 21:53:50 --> Security Class Initialized
DEBUG - 2018-03-26 21:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:53:50 --> Input Class Initialized
INFO - 2018-03-26 21:53:50 --> Language Class Initialized
INFO - 2018-03-26 21:53:50 --> Loader Class Initialized
INFO - 2018-03-26 21:53:50 --> Helper loaded: url_helper
INFO - 2018-03-26 21:53:50 --> Helper loaded: form_helper
INFO - 2018-03-26 21:53:50 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:53:50 --> Controller Class Initialized
INFO - 2018-03-26 21:53:50 --> Model Class Initialized
INFO - 2018-03-26 21:53:50 --> Model Class Initialized
INFO - 2018-03-26 21:53:50 --> Helper loaded: date_helper
INFO - 2018-03-26 21:53:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:54:05 --> Config Class Initialized
INFO - 2018-03-26 21:54:05 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:54:05 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:54:05 --> Utf8 Class Initialized
INFO - 2018-03-26 21:54:05 --> URI Class Initialized
INFO - 2018-03-26 21:54:05 --> Router Class Initialized
INFO - 2018-03-26 21:54:05 --> Output Class Initialized
INFO - 2018-03-26 21:54:05 --> Security Class Initialized
DEBUG - 2018-03-26 21:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:54:05 --> Input Class Initialized
INFO - 2018-03-26 21:54:05 --> Language Class Initialized
INFO - 2018-03-26 21:54:05 --> Loader Class Initialized
INFO - 2018-03-26 21:54:05 --> Helper loaded: url_helper
INFO - 2018-03-26 21:54:05 --> Helper loaded: form_helper
INFO - 2018-03-26 21:54:05 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:54:05 --> Controller Class Initialized
INFO - 2018-03-26 21:54:05 --> Model Class Initialized
INFO - 2018-03-26 21:54:05 --> Model Class Initialized
INFO - 2018-03-26 21:54:05 --> Model Class Initialized
INFO - 2018-03-26 21:54:05 --> Model Class Initialized
INFO - 2018-03-26 21:54:05 --> Model Class Initialized
INFO - 2018-03-26 21:54:05 --> Helper loaded: date_helper
INFO - 2018-03-26 21:54:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:54:11 --> Config Class Initialized
INFO - 2018-03-26 21:54:11 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:54:11 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:54:11 --> Utf8 Class Initialized
INFO - 2018-03-26 21:54:11 --> URI Class Initialized
INFO - 2018-03-26 21:54:11 --> Router Class Initialized
INFO - 2018-03-26 21:54:11 --> Output Class Initialized
INFO - 2018-03-26 21:54:11 --> Security Class Initialized
DEBUG - 2018-03-26 21:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:54:11 --> Input Class Initialized
INFO - 2018-03-26 21:54:11 --> Language Class Initialized
INFO - 2018-03-26 21:54:11 --> Loader Class Initialized
INFO - 2018-03-26 21:54:11 --> Helper loaded: url_helper
INFO - 2018-03-26 21:54:11 --> Helper loaded: form_helper
INFO - 2018-03-26 21:54:11 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:54:11 --> Controller Class Initialized
INFO - 2018-03-26 21:54:11 --> Model Class Initialized
INFO - 2018-03-26 21:54:11 --> Model Class Initialized
INFO - 2018-03-26 21:54:11 --> Model Class Initialized
INFO - 2018-03-26 21:54:11 --> Model Class Initialized
INFO - 2018-03-26 21:54:11 --> Model Class Initialized
INFO - 2018-03-26 21:54:11 --> Helper loaded: date_helper
INFO - 2018-03-26 21:54:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:54:15 --> Config Class Initialized
INFO - 2018-03-26 21:54:15 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:54:15 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:54:15 --> Utf8 Class Initialized
INFO - 2018-03-26 21:54:15 --> URI Class Initialized
INFO - 2018-03-26 21:54:15 --> Router Class Initialized
INFO - 2018-03-26 21:54:15 --> Output Class Initialized
INFO - 2018-03-26 21:54:15 --> Security Class Initialized
DEBUG - 2018-03-26 21:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:54:15 --> Input Class Initialized
INFO - 2018-03-26 21:54:15 --> Language Class Initialized
INFO - 2018-03-26 21:54:15 --> Loader Class Initialized
INFO - 2018-03-26 21:54:15 --> Helper loaded: url_helper
INFO - 2018-03-26 21:54:15 --> Helper loaded: form_helper
INFO - 2018-03-26 21:54:15 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:54:15 --> Controller Class Initialized
INFO - 2018-03-26 21:54:15 --> Model Class Initialized
INFO - 2018-03-26 21:54:15 --> Model Class Initialized
INFO - 2018-03-26 21:54:15 --> Model Class Initialized
INFO - 2018-03-26 21:54:15 --> Model Class Initialized
INFO - 2018-03-26 21:54:15 --> Model Class Initialized
INFO - 2018-03-26 21:54:15 --> Helper loaded: date_helper
INFO - 2018-03-26 21:54:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 21:57:05 --> Config Class Initialized
INFO - 2018-03-26 21:57:05 --> Hooks Class Initialized
DEBUG - 2018-03-26 21:57:05 --> UTF-8 Support Enabled
INFO - 2018-03-26 21:57:05 --> Utf8 Class Initialized
INFO - 2018-03-26 21:57:05 --> URI Class Initialized
INFO - 2018-03-26 21:57:05 --> Router Class Initialized
INFO - 2018-03-26 21:57:05 --> Output Class Initialized
INFO - 2018-03-26 21:57:05 --> Security Class Initialized
DEBUG - 2018-03-26 21:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 21:57:05 --> Input Class Initialized
INFO - 2018-03-26 21:57:05 --> Language Class Initialized
INFO - 2018-03-26 21:57:05 --> Loader Class Initialized
INFO - 2018-03-26 21:57:05 --> Helper loaded: url_helper
INFO - 2018-03-26 21:57:05 --> Helper loaded: form_helper
INFO - 2018-03-26 21:57:05 --> Database Driver Class Initialized
DEBUG - 2018-03-26 21:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 21:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 21:57:05 --> Controller Class Initialized
INFO - 2018-03-26 21:57:05 --> Model Class Initialized
INFO - 2018-03-26 21:57:05 --> Model Class Initialized
INFO - 2018-03-26 21:57:05 --> Model Class Initialized
INFO - 2018-03-26 21:57:05 --> Model Class Initialized
INFO - 2018-03-26 21:57:05 --> Model Class Initialized
INFO - 2018-03-26 21:57:05 --> Helper loaded: date_helper
INFO - 2018-03-26 21:57:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:00:02 --> Config Class Initialized
INFO - 2018-03-26 22:00:02 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:00:02 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:00:02 --> Utf8 Class Initialized
INFO - 2018-03-26 22:00:02 --> URI Class Initialized
INFO - 2018-03-26 22:00:02 --> Router Class Initialized
INFO - 2018-03-26 22:00:02 --> Output Class Initialized
INFO - 2018-03-26 22:00:02 --> Security Class Initialized
DEBUG - 2018-03-26 22:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:00:02 --> Input Class Initialized
INFO - 2018-03-26 22:00:02 --> Language Class Initialized
INFO - 2018-03-26 22:00:02 --> Loader Class Initialized
INFO - 2018-03-26 22:00:02 --> Helper loaded: url_helper
INFO - 2018-03-26 22:00:02 --> Helper loaded: form_helper
INFO - 2018-03-26 22:00:02 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:00:02 --> Controller Class Initialized
INFO - 2018-03-26 22:00:02 --> Model Class Initialized
INFO - 2018-03-26 22:00:02 --> Model Class Initialized
INFO - 2018-03-26 22:00:02 --> Model Class Initialized
INFO - 2018-03-26 22:00:02 --> Model Class Initialized
INFO - 2018-03-26 22:00:02 --> Model Class Initialized
INFO - 2018-03-26 22:00:02 --> Helper loaded: date_helper
INFO - 2018-03-26 22:00:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:00:39 --> Config Class Initialized
INFO - 2018-03-26 22:00:39 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:00:39 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:00:39 --> Utf8 Class Initialized
INFO - 2018-03-26 22:00:39 --> URI Class Initialized
INFO - 2018-03-26 22:00:39 --> Router Class Initialized
INFO - 2018-03-26 22:00:39 --> Output Class Initialized
INFO - 2018-03-26 22:00:39 --> Security Class Initialized
DEBUG - 2018-03-26 22:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:00:39 --> Input Class Initialized
INFO - 2018-03-26 22:00:39 --> Language Class Initialized
INFO - 2018-03-26 22:00:39 --> Loader Class Initialized
INFO - 2018-03-26 22:00:39 --> Helper loaded: url_helper
INFO - 2018-03-26 22:00:39 --> Helper loaded: form_helper
INFO - 2018-03-26 22:00:39 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:00:39 --> Controller Class Initialized
INFO - 2018-03-26 22:00:39 --> Model Class Initialized
INFO - 2018-03-26 22:00:39 --> Model Class Initialized
INFO - 2018-03-26 22:00:39 --> Model Class Initialized
INFO - 2018-03-26 22:00:39 --> Model Class Initialized
INFO - 2018-03-26 22:00:39 --> Model Class Initialized
INFO - 2018-03-26 22:00:39 --> Model Class Initialized
INFO - 2018-03-26 22:00:39 --> Model Class Initialized
INFO - 2018-03-26 22:00:39 --> Model Class Initialized
INFO - 2018-03-26 22:00:39 --> Model Class Initialized
INFO - 2018-03-26 22:00:39 --> Model Class Initialized
INFO - 2018-03-26 22:00:39 --> Helper loaded: date_helper
INFO - 2018-03-26 22:00:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:00:41 --> Config Class Initialized
INFO - 2018-03-26 22:00:41 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:00:41 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:00:41 --> Utf8 Class Initialized
INFO - 2018-03-26 22:00:41 --> URI Class Initialized
INFO - 2018-03-26 22:00:41 --> Router Class Initialized
INFO - 2018-03-26 22:00:41 --> Output Class Initialized
INFO - 2018-03-26 22:00:41 --> Security Class Initialized
DEBUG - 2018-03-26 22:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:00:41 --> Input Class Initialized
INFO - 2018-03-26 22:00:41 --> Language Class Initialized
INFO - 2018-03-26 22:00:41 --> Loader Class Initialized
INFO - 2018-03-26 22:00:41 --> Helper loaded: url_helper
INFO - 2018-03-26 22:00:41 --> Helper loaded: form_helper
INFO - 2018-03-26 22:00:41 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:00:41 --> Controller Class Initialized
INFO - 2018-03-26 22:00:41 --> Model Class Initialized
INFO - 2018-03-26 22:00:41 --> Model Class Initialized
INFO - 2018-03-26 22:00:41 --> Model Class Initialized
INFO - 2018-03-26 22:00:41 --> Model Class Initialized
INFO - 2018-03-26 22:00:41 --> Model Class Initialized
INFO - 2018-03-26 22:00:41 --> Model Class Initialized
INFO - 2018-03-26 22:00:41 --> Model Class Initialized
INFO - 2018-03-26 22:00:41 --> Model Class Initialized
INFO - 2018-03-26 22:00:41 --> Model Class Initialized
INFO - 2018-03-26 22:00:41 --> Model Class Initialized
INFO - 2018-03-26 22:00:41 --> Helper loaded: date_helper
INFO - 2018-03-26 22:00:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:01:25 --> Config Class Initialized
INFO - 2018-03-26 22:01:25 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:01:25 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:01:25 --> Utf8 Class Initialized
INFO - 2018-03-26 22:01:25 --> URI Class Initialized
INFO - 2018-03-26 22:01:25 --> Router Class Initialized
INFO - 2018-03-26 22:01:25 --> Output Class Initialized
INFO - 2018-03-26 22:01:25 --> Security Class Initialized
DEBUG - 2018-03-26 22:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:01:25 --> Input Class Initialized
INFO - 2018-03-26 22:01:25 --> Language Class Initialized
INFO - 2018-03-26 22:01:25 --> Loader Class Initialized
INFO - 2018-03-26 22:01:25 --> Helper loaded: url_helper
INFO - 2018-03-26 22:01:25 --> Helper loaded: form_helper
INFO - 2018-03-26 22:01:25 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:01:25 --> Controller Class Initialized
INFO - 2018-03-26 22:01:25 --> Model Class Initialized
INFO - 2018-03-26 22:01:25 --> Model Class Initialized
INFO - 2018-03-26 22:01:25 --> Model Class Initialized
INFO - 2018-03-26 22:01:25 --> Model Class Initialized
INFO - 2018-03-26 22:01:25 --> Model Class Initialized
INFO - 2018-03-26 22:01:25 --> Model Class Initialized
INFO - 2018-03-26 22:01:25 --> Model Class Initialized
INFO - 2018-03-26 22:01:25 --> Model Class Initialized
INFO - 2018-03-26 22:01:25 --> Model Class Initialized
INFO - 2018-03-26 22:01:25 --> Model Class Initialized
INFO - 2018-03-26 22:01:25 --> Model Class Initialized
INFO - 2018-03-26 22:01:25 --> Model Class Initialized
INFO - 2018-03-26 22:01:25 --> Helper loaded: date_helper
INFO - 2018-03-26 22:01:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:01:47 --> Config Class Initialized
INFO - 2018-03-26 22:01:47 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:01:47 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:01:47 --> Utf8 Class Initialized
INFO - 2018-03-26 22:01:47 --> URI Class Initialized
INFO - 2018-03-26 22:01:47 --> Router Class Initialized
INFO - 2018-03-26 22:01:47 --> Output Class Initialized
INFO - 2018-03-26 22:01:47 --> Security Class Initialized
DEBUG - 2018-03-26 22:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:01:47 --> Input Class Initialized
INFO - 2018-03-26 22:01:47 --> Language Class Initialized
INFO - 2018-03-26 22:01:47 --> Loader Class Initialized
INFO - 2018-03-26 22:01:47 --> Helper loaded: url_helper
INFO - 2018-03-26 22:01:47 --> Helper loaded: form_helper
INFO - 2018-03-26 22:01:47 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:01:48 --> Controller Class Initialized
INFO - 2018-03-26 22:01:48 --> Model Class Initialized
INFO - 2018-03-26 22:01:48 --> Model Class Initialized
INFO - 2018-03-26 22:01:48 --> Model Class Initialized
INFO - 2018-03-26 22:01:48 --> Model Class Initialized
INFO - 2018-03-26 22:01:48 --> Model Class Initialized
INFO - 2018-03-26 22:01:48 --> Model Class Initialized
INFO - 2018-03-26 22:01:48 --> Model Class Initialized
INFO - 2018-03-26 22:01:48 --> Model Class Initialized
INFO - 2018-03-26 22:01:48 --> Model Class Initialized
INFO - 2018-03-26 22:01:48 --> Model Class Initialized
INFO - 2018-03-26 22:01:48 --> Helper loaded: date_helper
INFO - 2018-03-26 22:01:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:02:09 --> Config Class Initialized
INFO - 2018-03-26 22:02:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:02:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:02:09 --> Utf8 Class Initialized
INFO - 2018-03-26 22:02:09 --> URI Class Initialized
INFO - 2018-03-26 22:02:09 --> Router Class Initialized
INFO - 2018-03-26 22:02:09 --> Output Class Initialized
INFO - 2018-03-26 22:02:09 --> Security Class Initialized
DEBUG - 2018-03-26 22:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:02:09 --> Input Class Initialized
INFO - 2018-03-26 22:02:09 --> Language Class Initialized
INFO - 2018-03-26 22:02:09 --> Loader Class Initialized
INFO - 2018-03-26 22:02:09 --> Helper loaded: url_helper
INFO - 2018-03-26 22:02:09 --> Helper loaded: form_helper
INFO - 2018-03-26 22:02:09 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:02:09 --> Controller Class Initialized
INFO - 2018-03-26 22:02:09 --> Model Class Initialized
INFO - 2018-03-26 22:02:09 --> Model Class Initialized
INFO - 2018-03-26 22:02:09 --> Model Class Initialized
INFO - 2018-03-26 22:02:09 --> Model Class Initialized
INFO - 2018-03-26 22:02:09 --> Model Class Initialized
INFO - 2018-03-26 22:02:09 --> Helper loaded: date_helper
INFO - 2018-03-26 22:02:14 --> Config Class Initialized
INFO - 2018-03-26 22:02:15 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:02:15 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:02:15 --> Utf8 Class Initialized
INFO - 2018-03-26 22:02:15 --> URI Class Initialized
INFO - 2018-03-26 22:02:15 --> Router Class Initialized
INFO - 2018-03-26 22:02:15 --> Output Class Initialized
INFO - 2018-03-26 22:02:15 --> Security Class Initialized
DEBUG - 2018-03-26 22:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:02:15 --> Input Class Initialized
INFO - 2018-03-26 22:02:15 --> Language Class Initialized
INFO - 2018-03-26 22:02:15 --> Loader Class Initialized
INFO - 2018-03-26 22:02:15 --> Helper loaded: url_helper
INFO - 2018-03-26 22:02:15 --> Helper loaded: form_helper
INFO - 2018-03-26 22:02:15 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:02:15 --> Controller Class Initialized
INFO - 2018-03-26 22:02:15 --> Model Class Initialized
INFO - 2018-03-26 22:02:15 --> Model Class Initialized
INFO - 2018-03-26 22:02:15 --> Model Class Initialized
INFO - 2018-03-26 22:02:15 --> Model Class Initialized
INFO - 2018-03-26 22:02:15 --> Model Class Initialized
INFO - 2018-03-26 22:02:15 --> Helper loaded: date_helper
INFO - 2018-03-26 22:02:31 --> Config Class Initialized
INFO - 2018-03-26 22:02:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:02:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:02:31 --> Utf8 Class Initialized
INFO - 2018-03-26 22:02:31 --> URI Class Initialized
INFO - 2018-03-26 22:02:31 --> Router Class Initialized
INFO - 2018-03-26 22:02:31 --> Output Class Initialized
INFO - 2018-03-26 22:02:31 --> Security Class Initialized
DEBUG - 2018-03-26 22:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:02:31 --> Input Class Initialized
INFO - 2018-03-26 22:02:31 --> Language Class Initialized
INFO - 2018-03-26 22:02:31 --> Loader Class Initialized
INFO - 2018-03-26 22:02:31 --> Helper loaded: url_helper
INFO - 2018-03-26 22:02:31 --> Helper loaded: form_helper
INFO - 2018-03-26 22:02:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:02:31 --> Controller Class Initialized
INFO - 2018-03-26 22:02:31 --> Model Class Initialized
INFO - 2018-03-26 22:02:31 --> Model Class Initialized
INFO - 2018-03-26 22:02:31 --> Model Class Initialized
INFO - 2018-03-26 22:02:31 --> Model Class Initialized
INFO - 2018-03-26 22:02:31 --> Model Class Initialized
INFO - 2018-03-26 22:02:31 --> Helper loaded: date_helper
INFO - 2018-03-26 22:02:31 --> Config Class Initialized
INFO - 2018-03-26 22:02:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:02:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:02:31 --> Utf8 Class Initialized
INFO - 2018-03-26 22:02:31 --> URI Class Initialized
INFO - 2018-03-26 22:02:31 --> Router Class Initialized
INFO - 2018-03-26 22:02:31 --> Output Class Initialized
INFO - 2018-03-26 22:02:31 --> Security Class Initialized
DEBUG - 2018-03-26 22:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:02:31 --> Input Class Initialized
INFO - 2018-03-26 22:02:31 --> Language Class Initialized
INFO - 2018-03-26 22:02:31 --> Loader Class Initialized
INFO - 2018-03-26 22:02:31 --> Helper loaded: url_helper
INFO - 2018-03-26 22:02:31 --> Helper loaded: form_helper
INFO - 2018-03-26 22:02:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:02:31 --> Controller Class Initialized
INFO - 2018-03-26 22:02:31 --> Model Class Initialized
INFO - 2018-03-26 22:02:31 --> Model Class Initialized
INFO - 2018-03-26 22:02:31 --> Model Class Initialized
INFO - 2018-03-26 22:02:31 --> Model Class Initialized
INFO - 2018-03-26 22:02:31 --> Model Class Initialized
INFO - 2018-03-26 22:02:31 --> Helper loaded: date_helper
INFO - 2018-03-26 22:02:36 --> Config Class Initialized
INFO - 2018-03-26 22:02:36 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:02:36 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:02:36 --> Utf8 Class Initialized
INFO - 2018-03-26 22:02:36 --> URI Class Initialized
INFO - 2018-03-26 22:02:36 --> Router Class Initialized
INFO - 2018-03-26 22:02:36 --> Output Class Initialized
INFO - 2018-03-26 22:02:36 --> Security Class Initialized
DEBUG - 2018-03-26 22:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:02:36 --> Input Class Initialized
INFO - 2018-03-26 22:02:36 --> Language Class Initialized
INFO - 2018-03-26 22:02:36 --> Loader Class Initialized
INFO - 2018-03-26 22:02:36 --> Helper loaded: url_helper
INFO - 2018-03-26 22:02:36 --> Helper loaded: form_helper
INFO - 2018-03-26 22:02:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:02:36 --> Controller Class Initialized
INFO - 2018-03-26 22:02:36 --> Model Class Initialized
INFO - 2018-03-26 22:02:36 --> Model Class Initialized
INFO - 2018-03-26 22:02:36 --> Model Class Initialized
INFO - 2018-03-26 22:02:36 --> Model Class Initialized
INFO - 2018-03-26 22:02:36 --> Model Class Initialized
INFO - 2018-03-26 22:02:36 --> Helper loaded: date_helper
INFO - 2018-03-26 22:03:12 --> Config Class Initialized
INFO - 2018-03-26 22:03:12 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:03:12 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:03:12 --> Utf8 Class Initialized
INFO - 2018-03-26 22:03:12 --> URI Class Initialized
INFO - 2018-03-26 22:03:12 --> Router Class Initialized
INFO - 2018-03-26 22:03:12 --> Output Class Initialized
INFO - 2018-03-26 22:03:12 --> Security Class Initialized
DEBUG - 2018-03-26 22:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:03:12 --> Input Class Initialized
INFO - 2018-03-26 22:03:12 --> Language Class Initialized
INFO - 2018-03-26 22:03:12 --> Loader Class Initialized
INFO - 2018-03-26 22:03:12 --> Helper loaded: url_helper
INFO - 2018-03-26 22:03:12 --> Helper loaded: form_helper
INFO - 2018-03-26 22:03:12 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:03:12 --> Controller Class Initialized
INFO - 2018-03-26 22:03:12 --> Model Class Initialized
INFO - 2018-03-26 22:03:12 --> Model Class Initialized
INFO - 2018-03-26 22:03:12 --> Model Class Initialized
INFO - 2018-03-26 22:03:12 --> Model Class Initialized
INFO - 2018-03-26 22:03:12 --> Model Class Initialized
INFO - 2018-03-26 22:03:12 --> Helper loaded: date_helper
INFO - 2018-03-26 22:03:12 --> Config Class Initialized
INFO - 2018-03-26 22:03:12 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:03:12 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:03:12 --> Utf8 Class Initialized
INFO - 2018-03-26 22:03:12 --> URI Class Initialized
INFO - 2018-03-26 22:03:12 --> Router Class Initialized
INFO - 2018-03-26 22:03:12 --> Output Class Initialized
INFO - 2018-03-26 22:03:12 --> Security Class Initialized
DEBUG - 2018-03-26 22:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:03:12 --> Input Class Initialized
INFO - 2018-03-26 22:03:12 --> Language Class Initialized
INFO - 2018-03-26 22:03:12 --> Loader Class Initialized
INFO - 2018-03-26 22:03:12 --> Helper loaded: url_helper
INFO - 2018-03-26 22:03:12 --> Helper loaded: form_helper
INFO - 2018-03-26 22:03:12 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:03:12 --> Controller Class Initialized
INFO - 2018-03-26 22:03:12 --> Model Class Initialized
INFO - 2018-03-26 22:03:12 --> Model Class Initialized
INFO - 2018-03-26 22:03:12 --> Model Class Initialized
INFO - 2018-03-26 22:03:12 --> Model Class Initialized
INFO - 2018-03-26 22:03:12 --> Model Class Initialized
INFO - 2018-03-26 22:03:12 --> Helper loaded: date_helper
INFO - 2018-03-26 22:03:17 --> Config Class Initialized
INFO - 2018-03-26 22:03:17 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:03:17 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:03:17 --> Utf8 Class Initialized
INFO - 2018-03-26 22:03:17 --> URI Class Initialized
INFO - 2018-03-26 22:03:17 --> Router Class Initialized
INFO - 2018-03-26 22:03:17 --> Output Class Initialized
INFO - 2018-03-26 22:03:17 --> Security Class Initialized
DEBUG - 2018-03-26 22:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:03:17 --> Input Class Initialized
INFO - 2018-03-26 22:03:17 --> Language Class Initialized
INFO - 2018-03-26 22:03:17 --> Loader Class Initialized
INFO - 2018-03-26 22:03:17 --> Helper loaded: url_helper
INFO - 2018-03-26 22:03:17 --> Helper loaded: form_helper
INFO - 2018-03-26 22:03:17 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:03:17 --> Controller Class Initialized
INFO - 2018-03-26 22:03:17 --> Model Class Initialized
INFO - 2018-03-26 22:03:17 --> Model Class Initialized
INFO - 2018-03-26 22:03:17 --> Model Class Initialized
INFO - 2018-03-26 22:03:17 --> Model Class Initialized
INFO - 2018-03-26 22:03:17 --> Model Class Initialized
INFO - 2018-03-26 22:03:17 --> Helper loaded: date_helper
INFO - 2018-03-26 22:03:19 --> Config Class Initialized
INFO - 2018-03-26 22:03:19 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:03:19 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:03:19 --> Utf8 Class Initialized
INFO - 2018-03-26 22:03:19 --> URI Class Initialized
INFO - 2018-03-26 22:03:19 --> Router Class Initialized
INFO - 2018-03-26 22:03:19 --> Output Class Initialized
INFO - 2018-03-26 22:03:19 --> Security Class Initialized
DEBUG - 2018-03-26 22:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:03:19 --> Input Class Initialized
INFO - 2018-03-26 22:03:19 --> Language Class Initialized
INFO - 2018-03-26 22:03:19 --> Loader Class Initialized
INFO - 2018-03-26 22:03:19 --> Helper loaded: url_helper
INFO - 2018-03-26 22:03:19 --> Helper loaded: form_helper
INFO - 2018-03-26 22:03:19 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:03:19 --> Controller Class Initialized
INFO - 2018-03-26 22:03:19 --> Model Class Initialized
INFO - 2018-03-26 22:03:19 --> Model Class Initialized
INFO - 2018-03-26 22:03:19 --> Model Class Initialized
INFO - 2018-03-26 22:03:19 --> Model Class Initialized
INFO - 2018-03-26 22:03:19 --> Model Class Initialized
INFO - 2018-03-26 22:03:19 --> Helper loaded: date_helper
INFO - 2018-03-26 22:03:27 --> Config Class Initialized
INFO - 2018-03-26 22:03:27 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:03:27 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:03:27 --> Utf8 Class Initialized
INFO - 2018-03-26 22:03:27 --> URI Class Initialized
INFO - 2018-03-26 22:03:27 --> Router Class Initialized
INFO - 2018-03-26 22:03:27 --> Output Class Initialized
INFO - 2018-03-26 22:03:27 --> Security Class Initialized
DEBUG - 2018-03-26 22:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:03:27 --> Input Class Initialized
INFO - 2018-03-26 22:03:27 --> Language Class Initialized
INFO - 2018-03-26 22:03:27 --> Loader Class Initialized
INFO - 2018-03-26 22:03:27 --> Helper loaded: url_helper
INFO - 2018-03-26 22:03:27 --> Helper loaded: form_helper
INFO - 2018-03-26 22:03:27 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:03:27 --> Controller Class Initialized
INFO - 2018-03-26 22:03:27 --> Model Class Initialized
INFO - 2018-03-26 22:03:27 --> Model Class Initialized
INFO - 2018-03-26 22:03:27 --> Model Class Initialized
INFO - 2018-03-26 22:03:27 --> Model Class Initialized
INFO - 2018-03-26 22:03:27 --> Model Class Initialized
INFO - 2018-03-26 22:03:27 --> Helper loaded: date_helper
INFO - 2018-03-26 22:03:27 --> Config Class Initialized
INFO - 2018-03-26 22:03:27 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:03:27 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:03:27 --> Utf8 Class Initialized
INFO - 2018-03-26 22:03:27 --> URI Class Initialized
INFO - 2018-03-26 22:03:27 --> Router Class Initialized
INFO - 2018-03-26 22:03:27 --> Output Class Initialized
INFO - 2018-03-26 22:03:27 --> Security Class Initialized
DEBUG - 2018-03-26 22:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:03:27 --> Input Class Initialized
INFO - 2018-03-26 22:03:27 --> Language Class Initialized
INFO - 2018-03-26 22:03:28 --> Loader Class Initialized
INFO - 2018-03-26 22:03:28 --> Helper loaded: url_helper
INFO - 2018-03-26 22:03:28 --> Helper loaded: form_helper
INFO - 2018-03-26 22:03:28 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:03:28 --> Controller Class Initialized
INFO - 2018-03-26 22:03:28 --> Model Class Initialized
INFO - 2018-03-26 22:03:28 --> Model Class Initialized
INFO - 2018-03-26 22:03:28 --> Model Class Initialized
INFO - 2018-03-26 22:03:28 --> Model Class Initialized
INFO - 2018-03-26 22:03:28 --> Model Class Initialized
INFO - 2018-03-26 22:03:28 --> Helper loaded: date_helper
INFO - 2018-03-26 22:03:29 --> Config Class Initialized
INFO - 2018-03-26 22:03:29 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:03:29 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:03:29 --> Utf8 Class Initialized
INFO - 2018-03-26 22:03:29 --> URI Class Initialized
INFO - 2018-03-26 22:03:29 --> Router Class Initialized
INFO - 2018-03-26 22:03:29 --> Output Class Initialized
INFO - 2018-03-26 22:03:29 --> Security Class Initialized
DEBUG - 2018-03-26 22:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:03:29 --> Input Class Initialized
INFO - 2018-03-26 22:03:29 --> Language Class Initialized
INFO - 2018-03-26 22:03:29 --> Loader Class Initialized
INFO - 2018-03-26 22:03:29 --> Helper loaded: url_helper
INFO - 2018-03-26 22:03:29 --> Helper loaded: form_helper
INFO - 2018-03-26 22:03:29 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:03:29 --> Controller Class Initialized
INFO - 2018-03-26 22:03:29 --> Model Class Initialized
INFO - 2018-03-26 22:03:29 --> Model Class Initialized
INFO - 2018-03-26 22:03:29 --> Model Class Initialized
INFO - 2018-03-26 22:03:29 --> Model Class Initialized
INFO - 2018-03-26 22:03:29 --> Model Class Initialized
INFO - 2018-03-26 22:03:29 --> Helper loaded: date_helper
INFO - 2018-03-26 22:03:35 --> Config Class Initialized
INFO - 2018-03-26 22:03:35 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:03:35 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:03:35 --> Utf8 Class Initialized
INFO - 2018-03-26 22:03:35 --> URI Class Initialized
INFO - 2018-03-26 22:03:35 --> Router Class Initialized
INFO - 2018-03-26 22:03:35 --> Output Class Initialized
INFO - 2018-03-26 22:03:35 --> Security Class Initialized
DEBUG - 2018-03-26 22:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:03:35 --> Input Class Initialized
INFO - 2018-03-26 22:03:35 --> Language Class Initialized
INFO - 2018-03-26 22:03:35 --> Loader Class Initialized
INFO - 2018-03-26 22:03:35 --> Helper loaded: url_helper
INFO - 2018-03-26 22:03:35 --> Helper loaded: form_helper
INFO - 2018-03-26 22:03:35 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:03:35 --> Controller Class Initialized
INFO - 2018-03-26 22:03:35 --> Model Class Initialized
INFO - 2018-03-26 22:03:35 --> Model Class Initialized
INFO - 2018-03-26 22:03:35 --> Model Class Initialized
INFO - 2018-03-26 22:03:35 --> Model Class Initialized
INFO - 2018-03-26 22:03:35 --> Model Class Initialized
INFO - 2018-03-26 22:03:35 --> Helper loaded: date_helper
INFO - 2018-03-26 22:03:35 --> Config Class Initialized
INFO - 2018-03-26 22:03:35 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:03:35 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:03:35 --> Utf8 Class Initialized
INFO - 2018-03-26 22:03:35 --> URI Class Initialized
INFO - 2018-03-26 22:03:35 --> Router Class Initialized
INFO - 2018-03-26 22:03:35 --> Output Class Initialized
INFO - 2018-03-26 22:03:35 --> Security Class Initialized
DEBUG - 2018-03-26 22:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:03:35 --> Input Class Initialized
INFO - 2018-03-26 22:03:35 --> Language Class Initialized
INFO - 2018-03-26 22:03:35 --> Loader Class Initialized
INFO - 2018-03-26 22:03:35 --> Helper loaded: url_helper
INFO - 2018-03-26 22:03:35 --> Helper loaded: form_helper
INFO - 2018-03-26 22:03:35 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:03:35 --> Controller Class Initialized
INFO - 2018-03-26 22:03:35 --> Model Class Initialized
INFO - 2018-03-26 22:03:35 --> Model Class Initialized
INFO - 2018-03-26 22:03:35 --> Model Class Initialized
INFO - 2018-03-26 22:03:35 --> Model Class Initialized
INFO - 2018-03-26 22:03:35 --> Model Class Initialized
INFO - 2018-03-26 22:03:35 --> Helper loaded: date_helper
INFO - 2018-03-26 22:03:38 --> Config Class Initialized
INFO - 2018-03-26 22:03:38 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:03:38 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:03:38 --> Utf8 Class Initialized
INFO - 2018-03-26 22:03:38 --> URI Class Initialized
INFO - 2018-03-26 22:03:38 --> Router Class Initialized
INFO - 2018-03-26 22:03:38 --> Output Class Initialized
INFO - 2018-03-26 22:03:38 --> Security Class Initialized
DEBUG - 2018-03-26 22:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:03:38 --> Input Class Initialized
INFO - 2018-03-26 22:03:38 --> Language Class Initialized
ERROR - 2018-03-26 22:03:38 --> 404 Page Not Found: Laporan/Laporan
INFO - 2018-03-26 22:03:41 --> Config Class Initialized
INFO - 2018-03-26 22:03:41 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:03:41 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:03:41 --> Utf8 Class Initialized
INFO - 2018-03-26 22:03:41 --> URI Class Initialized
INFO - 2018-03-26 22:03:41 --> Router Class Initialized
INFO - 2018-03-26 22:03:41 --> Output Class Initialized
INFO - 2018-03-26 22:03:41 --> Security Class Initialized
DEBUG - 2018-03-26 22:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:03:41 --> Input Class Initialized
INFO - 2018-03-26 22:03:41 --> Language Class Initialized
INFO - 2018-03-26 22:03:41 --> Loader Class Initialized
INFO - 2018-03-26 22:03:41 --> Helper loaded: url_helper
INFO - 2018-03-26 22:03:41 --> Helper loaded: form_helper
INFO - 2018-03-26 22:03:41 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:03:41 --> Controller Class Initialized
INFO - 2018-03-26 22:03:41 --> Model Class Initialized
INFO - 2018-03-26 22:03:41 --> Model Class Initialized
INFO - 2018-03-26 22:03:41 --> Model Class Initialized
INFO - 2018-03-26 22:03:41 --> Model Class Initialized
INFO - 2018-03-26 22:03:41 --> Model Class Initialized
INFO - 2018-03-26 22:03:41 --> Helper loaded: date_helper
INFO - 2018-03-26 22:03:43 --> Config Class Initialized
INFO - 2018-03-26 22:03:43 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:03:43 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:03:43 --> Utf8 Class Initialized
INFO - 2018-03-26 22:03:43 --> URI Class Initialized
INFO - 2018-03-26 22:03:43 --> Router Class Initialized
INFO - 2018-03-26 22:03:43 --> Output Class Initialized
INFO - 2018-03-26 22:03:43 --> Security Class Initialized
DEBUG - 2018-03-26 22:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:03:43 --> Input Class Initialized
INFO - 2018-03-26 22:03:43 --> Language Class Initialized
ERROR - 2018-03-26 22:03:43 --> 404 Page Not Found: Laporan/Laporan
INFO - 2018-03-26 22:12:33 --> Config Class Initialized
INFO - 2018-03-26 22:12:33 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:12:33 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:12:33 --> Utf8 Class Initialized
INFO - 2018-03-26 22:12:33 --> URI Class Initialized
INFO - 2018-03-26 22:12:33 --> Router Class Initialized
INFO - 2018-03-26 22:12:33 --> Output Class Initialized
INFO - 2018-03-26 22:12:33 --> Security Class Initialized
DEBUG - 2018-03-26 22:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:12:33 --> Input Class Initialized
INFO - 2018-03-26 22:12:33 --> Language Class Initialized
INFO - 2018-03-26 22:12:33 --> Loader Class Initialized
INFO - 2018-03-26 22:12:33 --> Helper loaded: url_helper
INFO - 2018-03-26 22:12:33 --> Helper loaded: form_helper
INFO - 2018-03-26 22:12:33 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:12:33 --> Controller Class Initialized
INFO - 2018-03-26 22:12:33 --> Model Class Initialized
INFO - 2018-03-26 22:12:33 --> Model Class Initialized
INFO - 2018-03-26 22:12:33 --> Model Class Initialized
INFO - 2018-03-26 22:12:33 --> Model Class Initialized
INFO - 2018-03-26 22:12:33 --> Model Class Initialized
INFO - 2018-03-26 22:12:33 --> Model Class Initialized
INFO - 2018-03-26 22:12:33 --> Model Class Initialized
INFO - 2018-03-26 22:12:33 --> Model Class Initialized
INFO - 2018-03-26 22:12:33 --> Model Class Initialized
INFO - 2018-03-26 22:12:33 --> Model Class Initialized
INFO - 2018-03-26 22:12:33 --> Model Class Initialized
INFO - 2018-03-26 22:12:33 --> Model Class Initialized
INFO - 2018-03-26 22:12:33 --> Model Class Initialized
INFO - 2018-03-26 22:12:33 --> Model Class Initialized
INFO - 2018-03-26 22:12:33 --> Model Class Initialized
INFO - 2018-03-26 22:12:33 --> Helper loaded: date_helper
INFO - 2018-03-26 22:12:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:12:51 --> Config Class Initialized
INFO - 2018-03-26 22:12:51 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:12:51 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:12:51 --> Utf8 Class Initialized
INFO - 2018-03-26 22:12:51 --> URI Class Initialized
INFO - 2018-03-26 22:12:51 --> Router Class Initialized
INFO - 2018-03-26 22:12:51 --> Output Class Initialized
INFO - 2018-03-26 22:12:51 --> Security Class Initialized
DEBUG - 2018-03-26 22:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:12:51 --> Input Class Initialized
INFO - 2018-03-26 22:12:51 --> Language Class Initialized
INFO - 2018-03-26 22:12:51 --> Loader Class Initialized
INFO - 2018-03-26 22:12:51 --> Helper loaded: url_helper
INFO - 2018-03-26 22:12:51 --> Helper loaded: form_helper
INFO - 2018-03-26 22:12:51 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:12:51 --> Controller Class Initialized
INFO - 2018-03-26 22:12:51 --> Model Class Initialized
INFO - 2018-03-26 22:12:51 --> Model Class Initialized
INFO - 2018-03-26 22:12:51 --> Model Class Initialized
INFO - 2018-03-26 22:12:51 --> Model Class Initialized
INFO - 2018-03-26 22:12:51 --> Model Class Initialized
INFO - 2018-03-26 22:12:51 --> Model Class Initialized
INFO - 2018-03-26 22:12:51 --> Model Class Initialized
INFO - 2018-03-26 22:12:51 --> Model Class Initialized
INFO - 2018-03-26 22:12:51 --> Model Class Initialized
INFO - 2018-03-26 22:12:51 --> Model Class Initialized
INFO - 2018-03-26 22:12:51 --> Model Class Initialized
INFO - 2018-03-26 22:12:51 --> Model Class Initialized
INFO - 2018-03-26 22:12:51 --> Model Class Initialized
INFO - 2018-03-26 22:12:51 --> Model Class Initialized
INFO - 2018-03-26 22:12:51 --> Model Class Initialized
INFO - 2018-03-26 22:12:51 --> Helper loaded: date_helper
INFO - 2018-03-26 22:12:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:13:58 --> Config Class Initialized
INFO - 2018-03-26 22:13:58 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:13:58 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:13:58 --> Utf8 Class Initialized
INFO - 2018-03-26 22:13:58 --> URI Class Initialized
INFO - 2018-03-26 22:13:58 --> Router Class Initialized
INFO - 2018-03-26 22:13:58 --> Output Class Initialized
INFO - 2018-03-26 22:13:58 --> Security Class Initialized
DEBUG - 2018-03-26 22:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:13:58 --> Input Class Initialized
INFO - 2018-03-26 22:13:58 --> Language Class Initialized
INFO - 2018-03-26 22:13:58 --> Loader Class Initialized
INFO - 2018-03-26 22:13:58 --> Helper loaded: url_helper
INFO - 2018-03-26 22:13:58 --> Helper loaded: form_helper
INFO - 2018-03-26 22:13:58 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:13:58 --> Controller Class Initialized
INFO - 2018-03-26 22:13:58 --> Model Class Initialized
INFO - 2018-03-26 22:13:58 --> Model Class Initialized
INFO - 2018-03-26 22:13:58 --> Model Class Initialized
INFO - 2018-03-26 22:13:58 --> Model Class Initialized
INFO - 2018-03-26 22:13:58 --> Model Class Initialized
INFO - 2018-03-26 22:13:58 --> Model Class Initialized
INFO - 2018-03-26 22:13:58 --> Model Class Initialized
INFO - 2018-03-26 22:13:58 --> Model Class Initialized
INFO - 2018-03-26 22:13:58 --> Model Class Initialized
INFO - 2018-03-26 22:13:58 --> Model Class Initialized
INFO - 2018-03-26 22:13:58 --> Model Class Initialized
INFO - 2018-03-26 22:13:58 --> Model Class Initialized
INFO - 2018-03-26 22:13:58 --> Model Class Initialized
INFO - 2018-03-26 22:13:58 --> Model Class Initialized
INFO - 2018-03-26 22:13:58 --> Model Class Initialized
INFO - 2018-03-26 22:13:58 --> Helper loaded: date_helper
INFO - 2018-03-26 22:13:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:15:31 --> Config Class Initialized
INFO - 2018-03-26 22:15:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:15:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:15:31 --> Utf8 Class Initialized
INFO - 2018-03-26 22:15:31 --> URI Class Initialized
INFO - 2018-03-26 22:15:31 --> Router Class Initialized
INFO - 2018-03-26 22:15:31 --> Output Class Initialized
INFO - 2018-03-26 22:15:31 --> Security Class Initialized
DEBUG - 2018-03-26 22:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:15:31 --> Input Class Initialized
INFO - 2018-03-26 22:15:31 --> Language Class Initialized
INFO - 2018-03-26 22:15:31 --> Loader Class Initialized
INFO - 2018-03-26 22:15:31 --> Helper loaded: url_helper
INFO - 2018-03-26 22:15:31 --> Helper loaded: form_helper
INFO - 2018-03-26 22:15:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:15:31 --> Controller Class Initialized
INFO - 2018-03-26 22:15:31 --> Model Class Initialized
INFO - 2018-03-26 22:15:31 --> Model Class Initialized
INFO - 2018-03-26 22:15:31 --> Model Class Initialized
INFO - 2018-03-26 22:15:31 --> Model Class Initialized
INFO - 2018-03-26 22:15:31 --> Model Class Initialized
INFO - 2018-03-26 22:15:31 --> Model Class Initialized
INFO - 2018-03-26 22:15:31 --> Model Class Initialized
INFO - 2018-03-26 22:15:31 --> Model Class Initialized
INFO - 2018-03-26 22:15:31 --> Model Class Initialized
INFO - 2018-03-26 22:15:31 --> Model Class Initialized
INFO - 2018-03-26 22:15:31 --> Model Class Initialized
INFO - 2018-03-26 22:15:31 --> Model Class Initialized
INFO - 2018-03-26 22:15:31 --> Model Class Initialized
INFO - 2018-03-26 22:15:31 --> Model Class Initialized
INFO - 2018-03-26 22:15:31 --> Model Class Initialized
INFO - 2018-03-26 22:15:31 --> Helper loaded: date_helper
INFO - 2018-03-26 22:15:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:15:58 --> Config Class Initialized
INFO - 2018-03-26 22:15:58 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:15:58 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:15:58 --> Utf8 Class Initialized
INFO - 2018-03-26 22:15:58 --> URI Class Initialized
INFO - 2018-03-26 22:15:58 --> Router Class Initialized
INFO - 2018-03-26 22:15:58 --> Output Class Initialized
INFO - 2018-03-26 22:15:58 --> Security Class Initialized
DEBUG - 2018-03-26 22:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:15:58 --> Input Class Initialized
INFO - 2018-03-26 22:15:58 --> Language Class Initialized
INFO - 2018-03-26 22:15:58 --> Loader Class Initialized
INFO - 2018-03-26 22:15:58 --> Helper loaded: url_helper
INFO - 2018-03-26 22:15:58 --> Helper loaded: form_helper
INFO - 2018-03-26 22:15:58 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:15:58 --> Controller Class Initialized
INFO - 2018-03-26 22:15:58 --> Model Class Initialized
INFO - 2018-03-26 22:15:58 --> Model Class Initialized
INFO - 2018-03-26 22:15:58 --> Model Class Initialized
INFO - 2018-03-26 22:15:58 --> Model Class Initialized
INFO - 2018-03-26 22:15:58 --> Model Class Initialized
INFO - 2018-03-26 22:15:58 --> Model Class Initialized
INFO - 2018-03-26 22:15:58 --> Model Class Initialized
INFO - 2018-03-26 22:15:58 --> Model Class Initialized
INFO - 2018-03-26 22:15:58 --> Model Class Initialized
INFO - 2018-03-26 22:15:58 --> Model Class Initialized
INFO - 2018-03-26 22:15:58 --> Model Class Initialized
INFO - 2018-03-26 22:15:58 --> Model Class Initialized
INFO - 2018-03-26 22:15:58 --> Model Class Initialized
INFO - 2018-03-26 22:15:58 --> Model Class Initialized
INFO - 2018-03-26 22:15:58 --> Model Class Initialized
INFO - 2018-03-26 22:15:58 --> Helper loaded: date_helper
INFO - 2018-03-26 22:15:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:16:14 --> Config Class Initialized
INFO - 2018-03-26 22:16:14 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:16:14 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:16:14 --> Utf8 Class Initialized
INFO - 2018-03-26 22:16:14 --> URI Class Initialized
INFO - 2018-03-26 22:16:14 --> Router Class Initialized
INFO - 2018-03-26 22:16:14 --> Output Class Initialized
INFO - 2018-03-26 22:16:14 --> Security Class Initialized
DEBUG - 2018-03-26 22:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:16:14 --> Input Class Initialized
INFO - 2018-03-26 22:16:14 --> Language Class Initialized
INFO - 2018-03-26 22:16:14 --> Loader Class Initialized
INFO - 2018-03-26 22:16:14 --> Helper loaded: url_helper
INFO - 2018-03-26 22:16:14 --> Helper loaded: form_helper
INFO - 2018-03-26 22:16:14 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:16:14 --> Controller Class Initialized
INFO - 2018-03-26 22:16:14 --> Model Class Initialized
INFO - 2018-03-26 22:16:14 --> Model Class Initialized
INFO - 2018-03-26 22:16:14 --> Model Class Initialized
INFO - 2018-03-26 22:16:14 --> Model Class Initialized
INFO - 2018-03-26 22:16:14 --> Model Class Initialized
INFO - 2018-03-26 22:16:14 --> Model Class Initialized
INFO - 2018-03-26 22:16:14 --> Model Class Initialized
INFO - 2018-03-26 22:16:14 --> Model Class Initialized
INFO - 2018-03-26 22:16:14 --> Model Class Initialized
INFO - 2018-03-26 22:16:14 --> Model Class Initialized
INFO - 2018-03-26 22:16:14 --> Model Class Initialized
INFO - 2018-03-26 22:16:14 --> Model Class Initialized
INFO - 2018-03-26 22:16:14 --> Model Class Initialized
INFO - 2018-03-26 22:16:14 --> Model Class Initialized
INFO - 2018-03-26 22:16:14 --> Model Class Initialized
INFO - 2018-03-26 22:16:14 --> Helper loaded: date_helper
INFO - 2018-03-26 22:16:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:16:31 --> Config Class Initialized
INFO - 2018-03-26 22:16:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:16:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:16:31 --> Utf8 Class Initialized
INFO - 2018-03-26 22:16:31 --> URI Class Initialized
INFO - 2018-03-26 22:16:31 --> Router Class Initialized
INFO - 2018-03-26 22:16:31 --> Output Class Initialized
INFO - 2018-03-26 22:16:31 --> Security Class Initialized
DEBUG - 2018-03-26 22:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:16:31 --> Input Class Initialized
INFO - 2018-03-26 22:16:31 --> Language Class Initialized
INFO - 2018-03-26 22:16:31 --> Loader Class Initialized
INFO - 2018-03-26 22:16:31 --> Helper loaded: url_helper
INFO - 2018-03-26 22:16:31 --> Helper loaded: form_helper
INFO - 2018-03-26 22:16:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:16:31 --> Controller Class Initialized
INFO - 2018-03-26 22:16:31 --> Model Class Initialized
INFO - 2018-03-26 22:16:31 --> Model Class Initialized
INFO - 2018-03-26 22:16:31 --> Model Class Initialized
INFO - 2018-03-26 22:16:31 --> Model Class Initialized
INFO - 2018-03-26 22:16:31 --> Model Class Initialized
INFO - 2018-03-26 22:16:31 --> Model Class Initialized
INFO - 2018-03-26 22:16:31 --> Model Class Initialized
INFO - 2018-03-26 22:16:31 --> Model Class Initialized
INFO - 2018-03-26 22:16:31 --> Model Class Initialized
INFO - 2018-03-26 22:16:31 --> Model Class Initialized
INFO - 2018-03-26 22:16:31 --> Model Class Initialized
INFO - 2018-03-26 22:16:31 --> Model Class Initialized
INFO - 2018-03-26 22:16:31 --> Model Class Initialized
INFO - 2018-03-26 22:16:31 --> Model Class Initialized
INFO - 2018-03-26 22:16:31 --> Model Class Initialized
INFO - 2018-03-26 22:16:31 --> Helper loaded: date_helper
INFO - 2018-03-26 22:16:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:17:09 --> Config Class Initialized
INFO - 2018-03-26 22:17:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:17:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:17:09 --> Utf8 Class Initialized
INFO - 2018-03-26 22:17:09 --> URI Class Initialized
INFO - 2018-03-26 22:17:09 --> Router Class Initialized
INFO - 2018-03-26 22:17:09 --> Output Class Initialized
INFO - 2018-03-26 22:17:09 --> Security Class Initialized
DEBUG - 2018-03-26 22:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:17:09 --> Input Class Initialized
INFO - 2018-03-26 22:17:09 --> Language Class Initialized
INFO - 2018-03-26 22:17:09 --> Loader Class Initialized
INFO - 2018-03-26 22:17:09 --> Helper loaded: url_helper
INFO - 2018-03-26 22:17:09 --> Helper loaded: form_helper
INFO - 2018-03-26 22:17:09 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:17:09 --> Controller Class Initialized
INFO - 2018-03-26 22:17:09 --> Model Class Initialized
INFO - 2018-03-26 22:17:09 --> Model Class Initialized
INFO - 2018-03-26 22:17:09 --> Model Class Initialized
INFO - 2018-03-26 22:17:09 --> Model Class Initialized
INFO - 2018-03-26 22:17:09 --> Model Class Initialized
INFO - 2018-03-26 22:17:09 --> Model Class Initialized
INFO - 2018-03-26 22:17:09 --> Model Class Initialized
INFO - 2018-03-26 22:17:09 --> Model Class Initialized
INFO - 2018-03-26 22:17:09 --> Model Class Initialized
INFO - 2018-03-26 22:17:09 --> Model Class Initialized
INFO - 2018-03-26 22:17:09 --> Model Class Initialized
INFO - 2018-03-26 22:17:09 --> Model Class Initialized
INFO - 2018-03-26 22:17:09 --> Model Class Initialized
INFO - 2018-03-26 22:17:09 --> Model Class Initialized
INFO - 2018-03-26 22:17:09 --> Model Class Initialized
INFO - 2018-03-26 22:17:09 --> Helper loaded: date_helper
INFO - 2018-03-26 22:17:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:18:09 --> Config Class Initialized
INFO - 2018-03-26 22:18:09 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:18:09 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:18:09 --> Utf8 Class Initialized
INFO - 2018-03-26 22:18:09 --> URI Class Initialized
INFO - 2018-03-26 22:18:09 --> Router Class Initialized
INFO - 2018-03-26 22:18:09 --> Output Class Initialized
INFO - 2018-03-26 22:18:09 --> Security Class Initialized
DEBUG - 2018-03-26 22:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:18:09 --> Input Class Initialized
INFO - 2018-03-26 22:18:09 --> Language Class Initialized
INFO - 2018-03-26 22:18:09 --> Loader Class Initialized
INFO - 2018-03-26 22:18:09 --> Helper loaded: url_helper
INFO - 2018-03-26 22:18:09 --> Helper loaded: form_helper
INFO - 2018-03-26 22:18:09 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:18:09 --> Controller Class Initialized
INFO - 2018-03-26 22:18:09 --> Model Class Initialized
INFO - 2018-03-26 22:18:09 --> Model Class Initialized
INFO - 2018-03-26 22:18:09 --> Model Class Initialized
INFO - 2018-03-26 22:18:09 --> Model Class Initialized
INFO - 2018-03-26 22:18:09 --> Model Class Initialized
INFO - 2018-03-26 22:18:09 --> Model Class Initialized
INFO - 2018-03-26 22:18:09 --> Model Class Initialized
INFO - 2018-03-26 22:18:09 --> Model Class Initialized
INFO - 2018-03-26 22:18:09 --> Model Class Initialized
INFO - 2018-03-26 22:18:09 --> Model Class Initialized
INFO - 2018-03-26 22:18:09 --> Model Class Initialized
INFO - 2018-03-26 22:18:09 --> Model Class Initialized
INFO - 2018-03-26 22:18:09 --> Model Class Initialized
INFO - 2018-03-26 22:18:09 --> Model Class Initialized
INFO - 2018-03-26 22:18:09 --> Model Class Initialized
INFO - 2018-03-26 22:18:09 --> Helper loaded: date_helper
INFO - 2018-03-26 22:18:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:21:51 --> Config Class Initialized
INFO - 2018-03-26 22:21:51 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:21:51 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:21:51 --> Utf8 Class Initialized
INFO - 2018-03-26 22:21:51 --> URI Class Initialized
INFO - 2018-03-26 22:21:51 --> Router Class Initialized
INFO - 2018-03-26 22:21:51 --> Output Class Initialized
INFO - 2018-03-26 22:21:51 --> Security Class Initialized
DEBUG - 2018-03-26 22:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:21:51 --> Input Class Initialized
INFO - 2018-03-26 22:21:51 --> Language Class Initialized
INFO - 2018-03-26 22:21:51 --> Loader Class Initialized
INFO - 2018-03-26 22:21:51 --> Helper loaded: url_helper
INFO - 2018-03-26 22:21:51 --> Helper loaded: form_helper
INFO - 2018-03-26 22:21:51 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:21:51 --> Controller Class Initialized
INFO - 2018-03-26 22:21:51 --> Model Class Initialized
INFO - 2018-03-26 22:21:51 --> Model Class Initialized
INFO - 2018-03-26 22:21:51 --> Model Class Initialized
INFO - 2018-03-26 22:21:51 --> Model Class Initialized
INFO - 2018-03-26 22:21:51 --> Model Class Initialized
INFO - 2018-03-26 22:21:51 --> Model Class Initialized
INFO - 2018-03-26 22:21:51 --> Model Class Initialized
INFO - 2018-03-26 22:21:51 --> Model Class Initialized
INFO - 2018-03-26 22:21:51 --> Model Class Initialized
INFO - 2018-03-26 22:21:51 --> Model Class Initialized
INFO - 2018-03-26 22:21:51 --> Model Class Initialized
INFO - 2018-03-26 22:21:51 --> Model Class Initialized
INFO - 2018-03-26 22:21:51 --> Model Class Initialized
INFO - 2018-03-26 22:21:51 --> Model Class Initialized
INFO - 2018-03-26 22:21:51 --> Model Class Initialized
INFO - 2018-03-26 22:21:51 --> Helper loaded: date_helper
INFO - 2018-03-26 22:21:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:22:55 --> Config Class Initialized
INFO - 2018-03-26 22:22:55 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:22:55 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:22:55 --> Utf8 Class Initialized
INFO - 2018-03-26 22:22:55 --> URI Class Initialized
INFO - 2018-03-26 22:22:55 --> Router Class Initialized
INFO - 2018-03-26 22:22:55 --> Output Class Initialized
INFO - 2018-03-26 22:22:55 --> Security Class Initialized
DEBUG - 2018-03-26 22:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:22:55 --> Input Class Initialized
INFO - 2018-03-26 22:22:55 --> Language Class Initialized
INFO - 2018-03-26 22:22:55 --> Loader Class Initialized
INFO - 2018-03-26 22:22:55 --> Helper loaded: url_helper
INFO - 2018-03-26 22:22:55 --> Helper loaded: form_helper
INFO - 2018-03-26 22:22:55 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:22:55 --> Controller Class Initialized
INFO - 2018-03-26 22:22:55 --> Model Class Initialized
INFO - 2018-03-26 22:22:55 --> Model Class Initialized
INFO - 2018-03-26 22:22:55 --> Model Class Initialized
INFO - 2018-03-26 22:22:55 --> Model Class Initialized
INFO - 2018-03-26 22:22:55 --> Model Class Initialized
INFO - 2018-03-26 22:22:55 --> Model Class Initialized
INFO - 2018-03-26 22:22:55 --> Model Class Initialized
INFO - 2018-03-26 22:22:55 --> Model Class Initialized
INFO - 2018-03-26 22:22:55 --> Model Class Initialized
INFO - 2018-03-26 22:22:55 --> Model Class Initialized
INFO - 2018-03-26 22:22:55 --> Model Class Initialized
INFO - 2018-03-26 22:22:55 --> Model Class Initialized
INFO - 2018-03-26 22:22:55 --> Model Class Initialized
INFO - 2018-03-26 22:22:55 --> Model Class Initialized
INFO - 2018-03-26 22:22:55 --> Model Class Initialized
INFO - 2018-03-26 22:22:55 --> Helper loaded: date_helper
INFO - 2018-03-26 22:22:55 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:23:34 --> Config Class Initialized
INFO - 2018-03-26 22:23:34 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:23:34 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:23:34 --> Utf8 Class Initialized
INFO - 2018-03-26 22:23:34 --> URI Class Initialized
INFO - 2018-03-26 22:23:34 --> Router Class Initialized
INFO - 2018-03-26 22:23:34 --> Output Class Initialized
INFO - 2018-03-26 22:23:34 --> Security Class Initialized
DEBUG - 2018-03-26 22:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:23:34 --> Input Class Initialized
INFO - 2018-03-26 22:23:34 --> Language Class Initialized
INFO - 2018-03-26 22:23:34 --> Loader Class Initialized
INFO - 2018-03-26 22:23:34 --> Helper loaded: url_helper
INFO - 2018-03-26 22:23:34 --> Helper loaded: form_helper
INFO - 2018-03-26 22:23:34 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:23:34 --> Controller Class Initialized
INFO - 2018-03-26 22:23:34 --> Model Class Initialized
INFO - 2018-03-26 22:23:34 --> Model Class Initialized
INFO - 2018-03-26 22:23:34 --> Model Class Initialized
INFO - 2018-03-26 22:23:34 --> Model Class Initialized
INFO - 2018-03-26 22:23:34 --> Model Class Initialized
INFO - 2018-03-26 22:23:34 --> Model Class Initialized
INFO - 2018-03-26 22:23:34 --> Model Class Initialized
INFO - 2018-03-26 22:23:34 --> Model Class Initialized
INFO - 2018-03-26 22:23:34 --> Model Class Initialized
INFO - 2018-03-26 22:23:34 --> Model Class Initialized
INFO - 2018-03-26 22:23:34 --> Model Class Initialized
INFO - 2018-03-26 22:23:34 --> Model Class Initialized
INFO - 2018-03-26 22:23:34 --> Model Class Initialized
INFO - 2018-03-26 22:23:34 --> Model Class Initialized
INFO - 2018-03-26 22:23:34 --> Model Class Initialized
INFO - 2018-03-26 22:23:34 --> Helper loaded: date_helper
INFO - 2018-03-26 22:23:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:29:51 --> Config Class Initialized
INFO - 2018-03-26 22:29:51 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:29:51 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:29:51 --> Utf8 Class Initialized
INFO - 2018-03-26 22:29:51 --> URI Class Initialized
INFO - 2018-03-26 22:29:51 --> Router Class Initialized
INFO - 2018-03-26 22:29:51 --> Output Class Initialized
INFO - 2018-03-26 22:29:51 --> Security Class Initialized
DEBUG - 2018-03-26 22:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:29:51 --> Input Class Initialized
INFO - 2018-03-26 22:29:51 --> Language Class Initialized
INFO - 2018-03-26 22:29:51 --> Loader Class Initialized
INFO - 2018-03-26 22:29:51 --> Helper loaded: url_helper
INFO - 2018-03-26 22:29:51 --> Helper loaded: form_helper
INFO - 2018-03-26 22:29:51 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:29:51 --> Controller Class Initialized
INFO - 2018-03-26 22:29:51 --> Model Class Initialized
INFO - 2018-03-26 22:29:51 --> Model Class Initialized
INFO - 2018-03-26 22:29:51 --> Model Class Initialized
INFO - 2018-03-26 22:29:51 --> Model Class Initialized
INFO - 2018-03-26 22:29:51 --> Model Class Initialized
INFO - 2018-03-26 22:29:51 --> Model Class Initialized
INFO - 2018-03-26 22:29:51 --> Model Class Initialized
INFO - 2018-03-26 22:29:51 --> Model Class Initialized
INFO - 2018-03-26 22:29:51 --> Model Class Initialized
INFO - 2018-03-26 22:29:51 --> Model Class Initialized
INFO - 2018-03-26 22:29:51 --> Model Class Initialized
INFO - 2018-03-26 22:29:51 --> Model Class Initialized
INFO - 2018-03-26 22:29:51 --> Model Class Initialized
INFO - 2018-03-26 22:29:51 --> Model Class Initialized
INFO - 2018-03-26 22:29:51 --> Model Class Initialized
INFO - 2018-03-26 22:29:51 --> Helper loaded: date_helper
INFO - 2018-03-26 22:29:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:30:14 --> Config Class Initialized
INFO - 2018-03-26 22:30:14 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:30:14 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:30:14 --> Utf8 Class Initialized
INFO - 2018-03-26 22:30:14 --> URI Class Initialized
INFO - 2018-03-26 22:30:14 --> Router Class Initialized
INFO - 2018-03-26 22:30:14 --> Output Class Initialized
INFO - 2018-03-26 22:30:14 --> Security Class Initialized
DEBUG - 2018-03-26 22:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:30:14 --> Input Class Initialized
INFO - 2018-03-26 22:30:14 --> Language Class Initialized
INFO - 2018-03-26 22:30:14 --> Loader Class Initialized
INFO - 2018-03-26 22:30:14 --> Helper loaded: url_helper
INFO - 2018-03-26 22:30:14 --> Helper loaded: form_helper
INFO - 2018-03-26 22:30:14 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:30:14 --> Controller Class Initialized
INFO - 2018-03-26 22:30:14 --> Model Class Initialized
INFO - 2018-03-26 22:30:14 --> Model Class Initialized
INFO - 2018-03-26 22:30:14 --> Model Class Initialized
INFO - 2018-03-26 22:30:14 --> Model Class Initialized
INFO - 2018-03-26 22:30:14 --> Model Class Initialized
INFO - 2018-03-26 22:30:14 --> Model Class Initialized
INFO - 2018-03-26 22:30:14 --> Model Class Initialized
INFO - 2018-03-26 22:30:14 --> Model Class Initialized
INFO - 2018-03-26 22:30:14 --> Model Class Initialized
INFO - 2018-03-26 22:30:14 --> Model Class Initialized
INFO - 2018-03-26 22:30:14 --> Model Class Initialized
INFO - 2018-03-26 22:30:14 --> Model Class Initialized
INFO - 2018-03-26 22:30:14 --> Model Class Initialized
INFO - 2018-03-26 22:30:14 --> Model Class Initialized
INFO - 2018-03-26 22:30:14 --> Model Class Initialized
INFO - 2018-03-26 22:30:14 --> Helper loaded: date_helper
INFO - 2018-03-26 22:30:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:30:31 --> Config Class Initialized
INFO - 2018-03-26 22:30:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:30:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:30:31 --> Utf8 Class Initialized
INFO - 2018-03-26 22:30:31 --> URI Class Initialized
INFO - 2018-03-26 22:30:31 --> Router Class Initialized
INFO - 2018-03-26 22:30:31 --> Output Class Initialized
INFO - 2018-03-26 22:30:31 --> Security Class Initialized
DEBUG - 2018-03-26 22:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:30:31 --> Input Class Initialized
INFO - 2018-03-26 22:30:31 --> Language Class Initialized
INFO - 2018-03-26 22:30:31 --> Loader Class Initialized
INFO - 2018-03-26 22:30:31 --> Helper loaded: url_helper
INFO - 2018-03-26 22:30:31 --> Helper loaded: form_helper
INFO - 2018-03-26 22:30:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:30:31 --> Controller Class Initialized
INFO - 2018-03-26 22:30:31 --> Model Class Initialized
INFO - 2018-03-26 22:30:31 --> Model Class Initialized
INFO - 2018-03-26 22:30:31 --> Model Class Initialized
INFO - 2018-03-26 22:30:31 --> Model Class Initialized
INFO - 2018-03-26 22:30:31 --> Model Class Initialized
INFO - 2018-03-26 22:30:31 --> Model Class Initialized
INFO - 2018-03-26 22:30:31 --> Model Class Initialized
INFO - 2018-03-26 22:30:31 --> Model Class Initialized
INFO - 2018-03-26 22:30:31 --> Model Class Initialized
INFO - 2018-03-26 22:30:31 --> Model Class Initialized
INFO - 2018-03-26 22:30:31 --> Model Class Initialized
INFO - 2018-03-26 22:30:31 --> Model Class Initialized
INFO - 2018-03-26 22:30:31 --> Model Class Initialized
INFO - 2018-03-26 22:30:31 --> Model Class Initialized
INFO - 2018-03-26 22:30:31 --> Model Class Initialized
INFO - 2018-03-26 22:30:31 --> Helper loaded: date_helper
INFO - 2018-03-26 22:30:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:30:51 --> Config Class Initialized
INFO - 2018-03-26 22:30:51 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:30:51 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:30:51 --> Utf8 Class Initialized
INFO - 2018-03-26 22:30:51 --> URI Class Initialized
INFO - 2018-03-26 22:30:51 --> Router Class Initialized
INFO - 2018-03-26 22:30:51 --> Output Class Initialized
INFO - 2018-03-26 22:30:51 --> Security Class Initialized
DEBUG - 2018-03-26 22:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:30:51 --> Input Class Initialized
INFO - 2018-03-26 22:30:51 --> Language Class Initialized
INFO - 2018-03-26 22:30:51 --> Loader Class Initialized
INFO - 2018-03-26 22:30:51 --> Helper loaded: url_helper
INFO - 2018-03-26 22:30:51 --> Helper loaded: form_helper
INFO - 2018-03-26 22:30:51 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:30:51 --> Controller Class Initialized
INFO - 2018-03-26 22:30:51 --> Model Class Initialized
INFO - 2018-03-26 22:30:51 --> Model Class Initialized
INFO - 2018-03-26 22:30:51 --> Model Class Initialized
INFO - 2018-03-26 22:30:51 --> Model Class Initialized
INFO - 2018-03-26 22:30:51 --> Model Class Initialized
INFO - 2018-03-26 22:30:51 --> Model Class Initialized
INFO - 2018-03-26 22:30:51 --> Model Class Initialized
INFO - 2018-03-26 22:30:51 --> Model Class Initialized
INFO - 2018-03-26 22:30:51 --> Model Class Initialized
INFO - 2018-03-26 22:30:51 --> Model Class Initialized
INFO - 2018-03-26 22:30:51 --> Model Class Initialized
INFO - 2018-03-26 22:30:51 --> Model Class Initialized
INFO - 2018-03-26 22:30:51 --> Model Class Initialized
INFO - 2018-03-26 22:30:51 --> Model Class Initialized
INFO - 2018-03-26 22:30:51 --> Model Class Initialized
INFO - 2018-03-26 22:30:51 --> Helper loaded: date_helper
INFO - 2018-03-26 22:30:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:30:57 --> Config Class Initialized
INFO - 2018-03-26 22:30:57 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:30:57 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:30:57 --> Utf8 Class Initialized
INFO - 2018-03-26 22:30:57 --> URI Class Initialized
INFO - 2018-03-26 22:30:57 --> Router Class Initialized
INFO - 2018-03-26 22:30:57 --> Output Class Initialized
INFO - 2018-03-26 22:30:57 --> Security Class Initialized
DEBUG - 2018-03-26 22:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:30:57 --> Input Class Initialized
INFO - 2018-03-26 22:30:57 --> Language Class Initialized
INFO - 2018-03-26 22:30:57 --> Loader Class Initialized
INFO - 2018-03-26 22:30:57 --> Helper loaded: url_helper
INFO - 2018-03-26 22:30:57 --> Helper loaded: form_helper
INFO - 2018-03-26 22:30:57 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:30:57 --> Controller Class Initialized
INFO - 2018-03-26 22:30:57 --> Model Class Initialized
INFO - 2018-03-26 22:30:57 --> Model Class Initialized
INFO - 2018-03-26 22:30:57 --> Model Class Initialized
INFO - 2018-03-26 22:30:57 --> Model Class Initialized
INFO - 2018-03-26 22:30:57 --> Model Class Initialized
INFO - 2018-03-26 22:30:57 --> Model Class Initialized
INFO - 2018-03-26 22:30:57 --> Model Class Initialized
INFO - 2018-03-26 22:30:57 --> Model Class Initialized
INFO - 2018-03-26 22:30:57 --> Model Class Initialized
INFO - 2018-03-26 22:30:57 --> Model Class Initialized
INFO - 2018-03-26 22:30:57 --> Model Class Initialized
INFO - 2018-03-26 22:30:57 --> Model Class Initialized
INFO - 2018-03-26 22:30:57 --> Model Class Initialized
INFO - 2018-03-26 22:30:57 --> Model Class Initialized
INFO - 2018-03-26 22:30:57 --> Model Class Initialized
INFO - 2018-03-26 22:30:57 --> Helper loaded: date_helper
INFO - 2018-03-26 22:30:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:37:13 --> Config Class Initialized
INFO - 2018-03-26 22:37:13 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:37:13 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:37:13 --> Utf8 Class Initialized
INFO - 2018-03-26 22:37:13 --> URI Class Initialized
INFO - 2018-03-26 22:37:13 --> Router Class Initialized
INFO - 2018-03-26 22:37:13 --> Output Class Initialized
INFO - 2018-03-26 22:37:14 --> Security Class Initialized
DEBUG - 2018-03-26 22:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:37:14 --> Input Class Initialized
INFO - 2018-03-26 22:37:14 --> Language Class Initialized
INFO - 2018-03-26 22:37:14 --> Loader Class Initialized
INFO - 2018-03-26 22:37:14 --> Helper loaded: url_helper
INFO - 2018-03-26 22:37:14 --> Helper loaded: form_helper
INFO - 2018-03-26 22:37:14 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:37:14 --> Controller Class Initialized
INFO - 2018-03-26 22:37:14 --> Model Class Initialized
INFO - 2018-03-26 22:37:14 --> Model Class Initialized
INFO - 2018-03-26 22:37:14 --> Model Class Initialized
INFO - 2018-03-26 22:37:14 --> Model Class Initialized
INFO - 2018-03-26 22:37:14 --> Model Class Initialized
INFO - 2018-03-26 22:37:14 --> Model Class Initialized
INFO - 2018-03-26 22:37:14 --> Model Class Initialized
INFO - 2018-03-26 22:37:14 --> Model Class Initialized
INFO - 2018-03-26 22:37:14 --> Model Class Initialized
INFO - 2018-03-26 22:37:14 --> Model Class Initialized
INFO - 2018-03-26 22:37:14 --> Model Class Initialized
INFO - 2018-03-26 22:37:14 --> Model Class Initialized
INFO - 2018-03-26 22:37:14 --> Model Class Initialized
INFO - 2018-03-26 22:37:14 --> Model Class Initialized
INFO - 2018-03-26 22:37:14 --> Model Class Initialized
INFO - 2018-03-26 22:37:14 --> Helper loaded: date_helper
INFO - 2018-03-26 22:37:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:37:20 --> Config Class Initialized
INFO - 2018-03-26 22:37:20 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:37:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:37:20 --> Utf8 Class Initialized
INFO - 2018-03-26 22:37:20 --> URI Class Initialized
INFO - 2018-03-26 22:37:20 --> Router Class Initialized
INFO - 2018-03-26 22:37:20 --> Output Class Initialized
INFO - 2018-03-26 22:37:20 --> Security Class Initialized
DEBUG - 2018-03-26 22:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:37:20 --> Input Class Initialized
INFO - 2018-03-26 22:37:20 --> Language Class Initialized
INFO - 2018-03-26 22:37:20 --> Loader Class Initialized
INFO - 2018-03-26 22:37:20 --> Helper loaded: url_helper
INFO - 2018-03-26 22:37:20 --> Helper loaded: form_helper
INFO - 2018-03-26 22:37:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:37:21 --> Controller Class Initialized
INFO - 2018-03-26 22:37:21 --> Model Class Initialized
INFO - 2018-03-26 22:37:21 --> Model Class Initialized
INFO - 2018-03-26 22:37:21 --> Model Class Initialized
INFO - 2018-03-26 22:37:21 --> Model Class Initialized
INFO - 2018-03-26 22:37:21 --> Model Class Initialized
INFO - 2018-03-26 22:37:21 --> Model Class Initialized
INFO - 2018-03-26 22:37:21 --> Model Class Initialized
INFO - 2018-03-26 22:37:21 --> Model Class Initialized
INFO - 2018-03-26 22:37:21 --> Model Class Initialized
INFO - 2018-03-26 22:37:21 --> Model Class Initialized
INFO - 2018-03-26 22:37:21 --> Model Class Initialized
INFO - 2018-03-26 22:37:21 --> Model Class Initialized
INFO - 2018-03-26 22:37:21 --> Model Class Initialized
INFO - 2018-03-26 22:37:21 --> Model Class Initialized
INFO - 2018-03-26 22:37:21 --> Model Class Initialized
INFO - 2018-03-26 22:37:21 --> Helper loaded: date_helper
INFO - 2018-03-26 22:37:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:37:37 --> Config Class Initialized
INFO - 2018-03-26 22:37:37 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:37:37 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:37:37 --> Utf8 Class Initialized
INFO - 2018-03-26 22:37:37 --> URI Class Initialized
INFO - 2018-03-26 22:37:37 --> Router Class Initialized
INFO - 2018-03-26 22:37:37 --> Output Class Initialized
INFO - 2018-03-26 22:37:37 --> Security Class Initialized
DEBUG - 2018-03-26 22:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:37:37 --> Input Class Initialized
INFO - 2018-03-26 22:37:37 --> Language Class Initialized
INFO - 2018-03-26 22:37:37 --> Loader Class Initialized
INFO - 2018-03-26 22:37:37 --> Helper loaded: url_helper
INFO - 2018-03-26 22:37:37 --> Helper loaded: form_helper
INFO - 2018-03-26 22:37:37 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:37:37 --> Controller Class Initialized
INFO - 2018-03-26 22:37:37 --> Model Class Initialized
INFO - 2018-03-26 22:37:37 --> Model Class Initialized
INFO - 2018-03-26 22:37:37 --> Model Class Initialized
INFO - 2018-03-26 22:37:37 --> Model Class Initialized
INFO - 2018-03-26 22:37:37 --> Model Class Initialized
INFO - 2018-03-26 22:37:37 --> Model Class Initialized
INFO - 2018-03-26 22:37:37 --> Model Class Initialized
INFO - 2018-03-26 22:37:37 --> Model Class Initialized
INFO - 2018-03-26 22:37:37 --> Model Class Initialized
INFO - 2018-03-26 22:37:37 --> Model Class Initialized
INFO - 2018-03-26 22:37:37 --> Model Class Initialized
INFO - 2018-03-26 22:37:37 --> Model Class Initialized
INFO - 2018-03-26 22:37:37 --> Model Class Initialized
INFO - 2018-03-26 22:37:37 --> Model Class Initialized
INFO - 2018-03-26 22:37:37 --> Model Class Initialized
INFO - 2018-03-26 22:37:37 --> Helper loaded: date_helper
INFO - 2018-03-26 22:37:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:37:44 --> Config Class Initialized
INFO - 2018-03-26 22:37:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:37:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:37:44 --> Utf8 Class Initialized
INFO - 2018-03-26 22:37:44 --> URI Class Initialized
INFO - 2018-03-26 22:37:44 --> Router Class Initialized
INFO - 2018-03-26 22:37:44 --> Output Class Initialized
INFO - 2018-03-26 22:37:44 --> Security Class Initialized
DEBUG - 2018-03-26 22:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:37:44 --> Input Class Initialized
INFO - 2018-03-26 22:37:44 --> Language Class Initialized
INFO - 2018-03-26 22:37:44 --> Loader Class Initialized
INFO - 2018-03-26 22:37:44 --> Helper loaded: url_helper
INFO - 2018-03-26 22:37:44 --> Helper loaded: form_helper
INFO - 2018-03-26 22:37:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:37:44 --> Controller Class Initialized
INFO - 2018-03-26 22:37:44 --> Model Class Initialized
INFO - 2018-03-26 22:37:44 --> Model Class Initialized
INFO - 2018-03-26 22:37:44 --> Model Class Initialized
INFO - 2018-03-26 22:37:44 --> Model Class Initialized
INFO - 2018-03-26 22:37:44 --> Model Class Initialized
INFO - 2018-03-26 22:37:44 --> Model Class Initialized
INFO - 2018-03-26 22:37:44 --> Model Class Initialized
INFO - 2018-03-26 22:37:44 --> Model Class Initialized
INFO - 2018-03-26 22:37:44 --> Model Class Initialized
INFO - 2018-03-26 22:37:44 --> Model Class Initialized
INFO - 2018-03-26 22:37:44 --> Model Class Initialized
INFO - 2018-03-26 22:37:44 --> Model Class Initialized
INFO - 2018-03-26 22:37:44 --> Model Class Initialized
INFO - 2018-03-26 22:37:44 --> Model Class Initialized
INFO - 2018-03-26 22:37:44 --> Model Class Initialized
INFO - 2018-03-26 22:37:44 --> Helper loaded: date_helper
INFO - 2018-03-26 22:37:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:42:20 --> Config Class Initialized
INFO - 2018-03-26 22:42:20 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:42:20 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:42:20 --> Utf8 Class Initialized
INFO - 2018-03-26 22:42:20 --> URI Class Initialized
INFO - 2018-03-26 22:42:20 --> Router Class Initialized
INFO - 2018-03-26 22:42:20 --> Output Class Initialized
INFO - 2018-03-26 22:42:20 --> Security Class Initialized
DEBUG - 2018-03-26 22:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:42:20 --> Input Class Initialized
INFO - 2018-03-26 22:42:20 --> Language Class Initialized
INFO - 2018-03-26 22:42:20 --> Loader Class Initialized
INFO - 2018-03-26 22:42:20 --> Helper loaded: url_helper
INFO - 2018-03-26 22:42:20 --> Helper loaded: form_helper
INFO - 2018-03-26 22:42:20 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:42:20 --> Controller Class Initialized
INFO - 2018-03-26 22:42:20 --> Model Class Initialized
INFO - 2018-03-26 22:42:20 --> Model Class Initialized
INFO - 2018-03-26 22:42:20 --> Model Class Initialized
INFO - 2018-03-26 22:42:20 --> Model Class Initialized
INFO - 2018-03-26 22:42:20 --> Model Class Initialized
INFO - 2018-03-26 22:42:20 --> Model Class Initialized
INFO - 2018-03-26 22:42:20 --> Model Class Initialized
INFO - 2018-03-26 22:42:20 --> Model Class Initialized
INFO - 2018-03-26 22:42:20 --> Model Class Initialized
INFO - 2018-03-26 22:42:20 --> Model Class Initialized
INFO - 2018-03-26 22:42:20 --> Model Class Initialized
INFO - 2018-03-26 22:42:20 --> Model Class Initialized
INFO - 2018-03-26 22:42:20 --> Model Class Initialized
INFO - 2018-03-26 22:42:20 --> Model Class Initialized
INFO - 2018-03-26 22:42:20 --> Model Class Initialized
INFO - 2018-03-26 22:42:20 --> Helper loaded: date_helper
INFO - 2018-03-26 22:42:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:42:26 --> Config Class Initialized
INFO - 2018-03-26 22:42:26 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:42:26 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:42:26 --> Utf8 Class Initialized
INFO - 2018-03-26 22:42:26 --> URI Class Initialized
INFO - 2018-03-26 22:42:26 --> Router Class Initialized
INFO - 2018-03-26 22:42:26 --> Output Class Initialized
INFO - 2018-03-26 22:42:26 --> Security Class Initialized
DEBUG - 2018-03-26 22:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:42:26 --> Input Class Initialized
INFO - 2018-03-26 22:42:26 --> Language Class Initialized
INFO - 2018-03-26 22:42:26 --> Loader Class Initialized
INFO - 2018-03-26 22:42:26 --> Helper loaded: url_helper
INFO - 2018-03-26 22:42:26 --> Helper loaded: form_helper
INFO - 2018-03-26 22:42:26 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:42:26 --> Controller Class Initialized
INFO - 2018-03-26 22:42:26 --> Model Class Initialized
INFO - 2018-03-26 22:42:26 --> Model Class Initialized
INFO - 2018-03-26 22:42:26 --> Model Class Initialized
INFO - 2018-03-26 22:42:26 --> Model Class Initialized
INFO - 2018-03-26 22:42:26 --> Model Class Initialized
INFO - 2018-03-26 22:42:26 --> Model Class Initialized
INFO - 2018-03-26 22:42:26 --> Model Class Initialized
INFO - 2018-03-26 22:42:26 --> Model Class Initialized
INFO - 2018-03-26 22:42:26 --> Model Class Initialized
INFO - 2018-03-26 22:42:26 --> Model Class Initialized
INFO - 2018-03-26 22:42:26 --> Model Class Initialized
INFO - 2018-03-26 22:42:26 --> Model Class Initialized
INFO - 2018-03-26 22:42:26 --> Model Class Initialized
INFO - 2018-03-26 22:42:26 --> Model Class Initialized
INFO - 2018-03-26 22:42:26 --> Model Class Initialized
INFO - 2018-03-26 22:42:26 --> Helper loaded: date_helper
INFO - 2018-03-26 22:42:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:42:29 --> Config Class Initialized
INFO - 2018-03-26 22:42:29 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:42:29 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:42:29 --> Utf8 Class Initialized
INFO - 2018-03-26 22:42:29 --> URI Class Initialized
INFO - 2018-03-26 22:42:29 --> Router Class Initialized
INFO - 2018-03-26 22:42:29 --> Output Class Initialized
INFO - 2018-03-26 22:42:29 --> Security Class Initialized
DEBUG - 2018-03-26 22:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:42:29 --> Input Class Initialized
INFO - 2018-03-26 22:42:29 --> Language Class Initialized
INFO - 2018-03-26 22:42:29 --> Loader Class Initialized
INFO - 2018-03-26 22:42:29 --> Helper loaded: url_helper
INFO - 2018-03-26 22:42:29 --> Helper loaded: form_helper
INFO - 2018-03-26 22:42:29 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:42:29 --> Controller Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Helper loaded: date_helper
INFO - 2018-03-26 22:42:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:42:29 --> Config Class Initialized
INFO - 2018-03-26 22:42:29 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:42:29 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:42:29 --> Utf8 Class Initialized
INFO - 2018-03-26 22:42:29 --> URI Class Initialized
INFO - 2018-03-26 22:42:29 --> Router Class Initialized
INFO - 2018-03-26 22:42:29 --> Output Class Initialized
INFO - 2018-03-26 22:42:29 --> Security Class Initialized
DEBUG - 2018-03-26 22:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:42:29 --> Input Class Initialized
INFO - 2018-03-26 22:42:29 --> Language Class Initialized
INFO - 2018-03-26 22:42:29 --> Loader Class Initialized
INFO - 2018-03-26 22:42:29 --> Helper loaded: url_helper
INFO - 2018-03-26 22:42:29 --> Helper loaded: form_helper
INFO - 2018-03-26 22:42:29 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:42:29 --> Controller Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Model Class Initialized
INFO - 2018-03-26 22:42:29 --> Helper loaded: date_helper
INFO - 2018-03-26 22:42:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:42:29 --> Config Class Initialized
INFO - 2018-03-26 22:42:29 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:42:30 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:42:30 --> Utf8 Class Initialized
INFO - 2018-03-26 22:42:30 --> URI Class Initialized
INFO - 2018-03-26 22:42:30 --> Router Class Initialized
INFO - 2018-03-26 22:42:30 --> Output Class Initialized
INFO - 2018-03-26 22:42:30 --> Security Class Initialized
DEBUG - 2018-03-26 22:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:42:30 --> Input Class Initialized
INFO - 2018-03-26 22:42:30 --> Language Class Initialized
INFO - 2018-03-26 22:42:30 --> Loader Class Initialized
INFO - 2018-03-26 22:42:30 --> Helper loaded: url_helper
INFO - 2018-03-26 22:42:30 --> Helper loaded: form_helper
INFO - 2018-03-26 22:42:30 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:42:30 --> Controller Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Helper loaded: date_helper
INFO - 2018-03-26 22:42:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:42:30 --> Config Class Initialized
INFO - 2018-03-26 22:42:30 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:42:30 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:42:30 --> Utf8 Class Initialized
INFO - 2018-03-26 22:42:30 --> URI Class Initialized
INFO - 2018-03-26 22:42:30 --> Router Class Initialized
INFO - 2018-03-26 22:42:30 --> Output Class Initialized
INFO - 2018-03-26 22:42:30 --> Security Class Initialized
DEBUG - 2018-03-26 22:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:42:30 --> Input Class Initialized
INFO - 2018-03-26 22:42:30 --> Language Class Initialized
INFO - 2018-03-26 22:42:30 --> Loader Class Initialized
INFO - 2018-03-26 22:42:30 --> Helper loaded: url_helper
INFO - 2018-03-26 22:42:30 --> Helper loaded: form_helper
INFO - 2018-03-26 22:42:30 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:42:30 --> Controller Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Helper loaded: date_helper
INFO - 2018-03-26 22:42:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:42:30 --> Config Class Initialized
INFO - 2018-03-26 22:42:30 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:42:30 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:42:30 --> Utf8 Class Initialized
INFO - 2018-03-26 22:42:30 --> URI Class Initialized
INFO - 2018-03-26 22:42:30 --> Router Class Initialized
INFO - 2018-03-26 22:42:30 --> Output Class Initialized
INFO - 2018-03-26 22:42:30 --> Security Class Initialized
DEBUG - 2018-03-26 22:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:42:30 --> Input Class Initialized
INFO - 2018-03-26 22:42:30 --> Language Class Initialized
INFO - 2018-03-26 22:42:30 --> Loader Class Initialized
INFO - 2018-03-26 22:42:30 --> Helper loaded: url_helper
INFO - 2018-03-26 22:42:30 --> Helper loaded: form_helper
INFO - 2018-03-26 22:42:30 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:42:30 --> Controller Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Helper loaded: date_helper
INFO - 2018-03-26 22:42:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:42:30 --> Config Class Initialized
INFO - 2018-03-26 22:42:30 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:42:30 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:42:30 --> Utf8 Class Initialized
INFO - 2018-03-26 22:42:30 --> URI Class Initialized
INFO - 2018-03-26 22:42:30 --> Router Class Initialized
INFO - 2018-03-26 22:42:30 --> Output Class Initialized
INFO - 2018-03-26 22:42:30 --> Security Class Initialized
DEBUG - 2018-03-26 22:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:42:30 --> Input Class Initialized
INFO - 2018-03-26 22:42:30 --> Language Class Initialized
INFO - 2018-03-26 22:42:30 --> Loader Class Initialized
INFO - 2018-03-26 22:42:30 --> Helper loaded: url_helper
INFO - 2018-03-26 22:42:30 --> Helper loaded: form_helper
INFO - 2018-03-26 22:42:30 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:42:30 --> Controller Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Model Class Initialized
INFO - 2018-03-26 22:42:30 --> Helper loaded: date_helper
INFO - 2018-03-26 22:42:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:42:49 --> Config Class Initialized
INFO - 2018-03-26 22:42:49 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:42:50 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:42:50 --> Utf8 Class Initialized
INFO - 2018-03-26 22:42:50 --> URI Class Initialized
INFO - 2018-03-26 22:42:50 --> Router Class Initialized
INFO - 2018-03-26 22:42:50 --> Output Class Initialized
INFO - 2018-03-26 22:42:50 --> Security Class Initialized
DEBUG - 2018-03-26 22:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:42:50 --> Input Class Initialized
INFO - 2018-03-26 22:42:50 --> Language Class Initialized
INFO - 2018-03-26 22:42:50 --> Loader Class Initialized
INFO - 2018-03-26 22:42:50 --> Helper loaded: url_helper
INFO - 2018-03-26 22:42:50 --> Helper loaded: form_helper
INFO - 2018-03-26 22:42:50 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:42:50 --> Controller Class Initialized
INFO - 2018-03-26 22:42:50 --> Model Class Initialized
INFO - 2018-03-26 22:42:50 --> Model Class Initialized
INFO - 2018-03-26 22:42:50 --> Model Class Initialized
INFO - 2018-03-26 22:42:50 --> Model Class Initialized
INFO - 2018-03-26 22:42:50 --> Model Class Initialized
INFO - 2018-03-26 22:42:50 --> Model Class Initialized
INFO - 2018-03-26 22:42:50 --> Model Class Initialized
INFO - 2018-03-26 22:42:50 --> Model Class Initialized
INFO - 2018-03-26 22:42:50 --> Model Class Initialized
INFO - 2018-03-26 22:42:50 --> Model Class Initialized
INFO - 2018-03-26 22:42:50 --> Model Class Initialized
INFO - 2018-03-26 22:42:50 --> Model Class Initialized
INFO - 2018-03-26 22:42:50 --> Model Class Initialized
INFO - 2018-03-26 22:42:50 --> Model Class Initialized
INFO - 2018-03-26 22:42:50 --> Model Class Initialized
INFO - 2018-03-26 22:42:50 --> Helper loaded: date_helper
INFO - 2018-03-26 22:42:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:42:54 --> Config Class Initialized
INFO - 2018-03-26 22:42:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:42:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:42:54 --> Utf8 Class Initialized
INFO - 2018-03-26 22:42:54 --> URI Class Initialized
INFO - 2018-03-26 22:42:54 --> Router Class Initialized
INFO - 2018-03-26 22:42:54 --> Output Class Initialized
INFO - 2018-03-26 22:42:54 --> Security Class Initialized
DEBUG - 2018-03-26 22:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:42:54 --> Input Class Initialized
INFO - 2018-03-26 22:42:54 --> Language Class Initialized
INFO - 2018-03-26 22:42:54 --> Loader Class Initialized
INFO - 2018-03-26 22:42:54 --> Helper loaded: url_helper
INFO - 2018-03-26 22:42:54 --> Helper loaded: form_helper
INFO - 2018-03-26 22:42:54 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:42:54 --> Controller Class Initialized
INFO - 2018-03-26 22:42:54 --> Model Class Initialized
INFO - 2018-03-26 22:42:54 --> Model Class Initialized
INFO - 2018-03-26 22:42:54 --> Model Class Initialized
INFO - 2018-03-26 22:42:54 --> Model Class Initialized
INFO - 2018-03-26 22:42:54 --> Model Class Initialized
INFO - 2018-03-26 22:42:54 --> Model Class Initialized
INFO - 2018-03-26 22:42:54 --> Model Class Initialized
INFO - 2018-03-26 22:42:54 --> Model Class Initialized
INFO - 2018-03-26 22:42:54 --> Model Class Initialized
INFO - 2018-03-26 22:42:54 --> Model Class Initialized
INFO - 2018-03-26 22:42:54 --> Model Class Initialized
INFO - 2018-03-26 22:42:54 --> Model Class Initialized
INFO - 2018-03-26 22:42:54 --> Model Class Initialized
INFO - 2018-03-26 22:42:54 --> Model Class Initialized
INFO - 2018-03-26 22:42:54 --> Model Class Initialized
INFO - 2018-03-26 22:42:54 --> Helper loaded: date_helper
INFO - 2018-03-26 22:42:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:43:05 --> Config Class Initialized
INFO - 2018-03-26 22:43:05 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:43:05 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:43:05 --> Utf8 Class Initialized
INFO - 2018-03-26 22:43:05 --> URI Class Initialized
INFO - 2018-03-26 22:43:05 --> Router Class Initialized
INFO - 2018-03-26 22:43:05 --> Output Class Initialized
INFO - 2018-03-26 22:43:05 --> Security Class Initialized
DEBUG - 2018-03-26 22:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:43:05 --> Input Class Initialized
INFO - 2018-03-26 22:43:05 --> Language Class Initialized
INFO - 2018-03-26 22:43:05 --> Loader Class Initialized
INFO - 2018-03-26 22:43:05 --> Helper loaded: url_helper
INFO - 2018-03-26 22:43:05 --> Helper loaded: form_helper
INFO - 2018-03-26 22:43:05 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:43:05 --> Controller Class Initialized
INFO - 2018-03-26 22:43:05 --> Model Class Initialized
INFO - 2018-03-26 22:43:05 --> Model Class Initialized
INFO - 2018-03-26 22:43:05 --> Model Class Initialized
INFO - 2018-03-26 22:43:05 --> Model Class Initialized
INFO - 2018-03-26 22:43:05 --> Model Class Initialized
INFO - 2018-03-26 22:43:05 --> Model Class Initialized
INFO - 2018-03-26 22:43:05 --> Model Class Initialized
INFO - 2018-03-26 22:43:05 --> Model Class Initialized
INFO - 2018-03-26 22:43:05 --> Model Class Initialized
INFO - 2018-03-26 22:43:05 --> Model Class Initialized
INFO - 2018-03-26 22:43:05 --> Model Class Initialized
INFO - 2018-03-26 22:43:05 --> Model Class Initialized
INFO - 2018-03-26 22:43:05 --> Model Class Initialized
INFO - 2018-03-26 22:43:05 --> Model Class Initialized
INFO - 2018-03-26 22:43:05 --> Model Class Initialized
INFO - 2018-03-26 22:43:05 --> Helper loaded: date_helper
INFO - 2018-03-26 22:43:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:43:16 --> Config Class Initialized
INFO - 2018-03-26 22:43:16 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:43:16 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:43:16 --> Utf8 Class Initialized
INFO - 2018-03-26 22:43:16 --> URI Class Initialized
INFO - 2018-03-26 22:43:16 --> Router Class Initialized
INFO - 2018-03-26 22:43:16 --> Output Class Initialized
INFO - 2018-03-26 22:43:16 --> Security Class Initialized
DEBUG - 2018-03-26 22:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:43:16 --> Input Class Initialized
INFO - 2018-03-26 22:43:16 --> Language Class Initialized
INFO - 2018-03-26 22:43:16 --> Loader Class Initialized
INFO - 2018-03-26 22:43:16 --> Helper loaded: url_helper
INFO - 2018-03-26 22:43:16 --> Helper loaded: form_helper
INFO - 2018-03-26 22:43:16 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:43:16 --> Controller Class Initialized
INFO - 2018-03-26 22:43:16 --> Model Class Initialized
INFO - 2018-03-26 22:43:16 --> Model Class Initialized
INFO - 2018-03-26 22:43:16 --> Model Class Initialized
INFO - 2018-03-26 22:43:16 --> Model Class Initialized
INFO - 2018-03-26 22:43:16 --> Model Class Initialized
INFO - 2018-03-26 22:43:16 --> Model Class Initialized
INFO - 2018-03-26 22:43:16 --> Model Class Initialized
INFO - 2018-03-26 22:43:16 --> Model Class Initialized
INFO - 2018-03-26 22:43:16 --> Model Class Initialized
INFO - 2018-03-26 22:43:16 --> Model Class Initialized
INFO - 2018-03-26 22:43:16 --> Model Class Initialized
INFO - 2018-03-26 22:43:16 --> Model Class Initialized
INFO - 2018-03-26 22:43:16 --> Model Class Initialized
INFO - 2018-03-26 22:43:16 --> Model Class Initialized
INFO - 2018-03-26 22:43:16 --> Model Class Initialized
INFO - 2018-03-26 22:43:16 --> Helper loaded: date_helper
INFO - 2018-03-26 22:43:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:43:58 --> Config Class Initialized
INFO - 2018-03-26 22:43:58 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:43:58 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:43:58 --> Utf8 Class Initialized
INFO - 2018-03-26 22:43:58 --> URI Class Initialized
INFO - 2018-03-26 22:43:58 --> Router Class Initialized
INFO - 2018-03-26 22:43:58 --> Output Class Initialized
INFO - 2018-03-26 22:43:58 --> Security Class Initialized
DEBUG - 2018-03-26 22:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:43:58 --> Input Class Initialized
INFO - 2018-03-26 22:43:58 --> Language Class Initialized
INFO - 2018-03-26 22:43:58 --> Loader Class Initialized
INFO - 2018-03-26 22:43:58 --> Helper loaded: url_helper
INFO - 2018-03-26 22:43:58 --> Helper loaded: form_helper
INFO - 2018-03-26 22:43:58 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:43:59 --> Controller Class Initialized
INFO - 2018-03-26 22:43:59 --> Model Class Initialized
INFO - 2018-03-26 22:43:59 --> Model Class Initialized
INFO - 2018-03-26 22:43:59 --> Model Class Initialized
INFO - 2018-03-26 22:43:59 --> Model Class Initialized
INFO - 2018-03-26 22:43:59 --> Model Class Initialized
INFO - 2018-03-26 22:43:59 --> Model Class Initialized
INFO - 2018-03-26 22:43:59 --> Model Class Initialized
INFO - 2018-03-26 22:43:59 --> Model Class Initialized
INFO - 2018-03-26 22:43:59 --> Model Class Initialized
INFO - 2018-03-26 22:43:59 --> Model Class Initialized
INFO - 2018-03-26 22:43:59 --> Model Class Initialized
INFO - 2018-03-26 22:43:59 --> Model Class Initialized
INFO - 2018-03-26 22:43:59 --> Model Class Initialized
INFO - 2018-03-26 22:43:59 --> Model Class Initialized
INFO - 2018-03-26 22:43:59 --> Model Class Initialized
INFO - 2018-03-26 22:43:59 --> Helper loaded: date_helper
INFO - 2018-03-26 22:43:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:44:04 --> Config Class Initialized
INFO - 2018-03-26 22:44:04 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:44:04 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:44:04 --> Utf8 Class Initialized
INFO - 2018-03-26 22:44:04 --> URI Class Initialized
INFO - 2018-03-26 22:44:04 --> Router Class Initialized
INFO - 2018-03-26 22:44:04 --> Output Class Initialized
INFO - 2018-03-26 22:44:04 --> Security Class Initialized
DEBUG - 2018-03-26 22:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:44:04 --> Input Class Initialized
INFO - 2018-03-26 22:44:04 --> Language Class Initialized
INFO - 2018-03-26 22:44:04 --> Loader Class Initialized
INFO - 2018-03-26 22:44:04 --> Helper loaded: url_helper
INFO - 2018-03-26 22:44:04 --> Helper loaded: form_helper
INFO - 2018-03-26 22:44:04 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:44:04 --> Controller Class Initialized
INFO - 2018-03-26 22:44:04 --> Model Class Initialized
INFO - 2018-03-26 22:44:04 --> Model Class Initialized
INFO - 2018-03-26 22:44:04 --> Model Class Initialized
INFO - 2018-03-26 22:44:04 --> Model Class Initialized
INFO - 2018-03-26 22:44:04 --> Model Class Initialized
INFO - 2018-03-26 22:44:04 --> Model Class Initialized
INFO - 2018-03-26 22:44:04 --> Model Class Initialized
INFO - 2018-03-26 22:44:04 --> Model Class Initialized
INFO - 2018-03-26 22:44:04 --> Model Class Initialized
INFO - 2018-03-26 22:44:04 --> Model Class Initialized
INFO - 2018-03-26 22:44:04 --> Model Class Initialized
INFO - 2018-03-26 22:44:04 --> Model Class Initialized
INFO - 2018-03-26 22:44:04 --> Model Class Initialized
INFO - 2018-03-26 22:44:04 --> Model Class Initialized
INFO - 2018-03-26 22:44:04 --> Model Class Initialized
INFO - 2018-03-26 22:44:04 --> Helper loaded: date_helper
INFO - 2018-03-26 22:44:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:44:33 --> Config Class Initialized
INFO - 2018-03-26 22:44:33 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:44:33 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:44:33 --> Utf8 Class Initialized
INFO - 2018-03-26 22:44:33 --> URI Class Initialized
INFO - 2018-03-26 22:44:33 --> Router Class Initialized
INFO - 2018-03-26 22:44:33 --> Output Class Initialized
INFO - 2018-03-26 22:44:33 --> Security Class Initialized
DEBUG - 2018-03-26 22:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:44:33 --> Input Class Initialized
INFO - 2018-03-26 22:44:33 --> Language Class Initialized
INFO - 2018-03-26 22:44:33 --> Loader Class Initialized
INFO - 2018-03-26 22:44:33 --> Helper loaded: url_helper
INFO - 2018-03-26 22:44:33 --> Helper loaded: form_helper
INFO - 2018-03-26 22:44:33 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:44:33 --> Controller Class Initialized
INFO - 2018-03-26 22:44:33 --> Model Class Initialized
INFO - 2018-03-26 22:44:33 --> Model Class Initialized
INFO - 2018-03-26 22:44:33 --> Model Class Initialized
INFO - 2018-03-26 22:44:33 --> Model Class Initialized
INFO - 2018-03-26 22:44:33 --> Model Class Initialized
INFO - 2018-03-26 22:44:33 --> Model Class Initialized
INFO - 2018-03-26 22:44:33 --> Model Class Initialized
INFO - 2018-03-26 22:44:33 --> Model Class Initialized
INFO - 2018-03-26 22:44:33 --> Model Class Initialized
INFO - 2018-03-26 22:44:33 --> Model Class Initialized
INFO - 2018-03-26 22:44:33 --> Model Class Initialized
INFO - 2018-03-26 22:44:33 --> Model Class Initialized
INFO - 2018-03-26 22:44:33 --> Model Class Initialized
INFO - 2018-03-26 22:44:33 --> Model Class Initialized
INFO - 2018-03-26 22:44:33 --> Model Class Initialized
INFO - 2018-03-26 22:44:33 --> Helper loaded: date_helper
INFO - 2018-03-26 22:44:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:44:39 --> Config Class Initialized
INFO - 2018-03-26 22:44:39 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:44:39 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:44:39 --> Utf8 Class Initialized
INFO - 2018-03-26 22:44:39 --> URI Class Initialized
INFO - 2018-03-26 22:44:39 --> Router Class Initialized
INFO - 2018-03-26 22:44:39 --> Output Class Initialized
INFO - 2018-03-26 22:44:39 --> Security Class Initialized
DEBUG - 2018-03-26 22:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:44:39 --> Input Class Initialized
INFO - 2018-03-26 22:44:39 --> Language Class Initialized
INFO - 2018-03-26 22:44:39 --> Loader Class Initialized
INFO - 2018-03-26 22:44:39 --> Helper loaded: url_helper
INFO - 2018-03-26 22:44:39 --> Helper loaded: form_helper
INFO - 2018-03-26 22:44:39 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:44:39 --> Controller Class Initialized
INFO - 2018-03-26 22:44:39 --> Model Class Initialized
INFO - 2018-03-26 22:44:39 --> Model Class Initialized
INFO - 2018-03-26 22:44:39 --> Model Class Initialized
INFO - 2018-03-26 22:44:39 --> Model Class Initialized
INFO - 2018-03-26 22:44:39 --> Model Class Initialized
INFO - 2018-03-26 22:44:39 --> Model Class Initialized
INFO - 2018-03-26 22:44:39 --> Model Class Initialized
INFO - 2018-03-26 22:44:39 --> Model Class Initialized
INFO - 2018-03-26 22:44:39 --> Model Class Initialized
INFO - 2018-03-26 22:44:39 --> Model Class Initialized
INFO - 2018-03-26 22:44:39 --> Model Class Initialized
INFO - 2018-03-26 22:44:39 --> Model Class Initialized
INFO - 2018-03-26 22:44:39 --> Model Class Initialized
INFO - 2018-03-26 22:44:39 --> Model Class Initialized
INFO - 2018-03-26 22:44:39 --> Model Class Initialized
INFO - 2018-03-26 22:44:39 --> Helper loaded: date_helper
INFO - 2018-03-26 22:44:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:45:48 --> Config Class Initialized
INFO - 2018-03-26 22:45:48 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:45:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:45:48 --> Utf8 Class Initialized
INFO - 2018-03-26 22:45:48 --> URI Class Initialized
INFO - 2018-03-26 22:45:48 --> Router Class Initialized
INFO - 2018-03-26 22:45:48 --> Output Class Initialized
INFO - 2018-03-26 22:45:48 --> Security Class Initialized
DEBUG - 2018-03-26 22:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:45:48 --> Input Class Initialized
INFO - 2018-03-26 22:45:48 --> Language Class Initialized
INFO - 2018-03-26 22:45:48 --> Loader Class Initialized
INFO - 2018-03-26 22:45:48 --> Helper loaded: url_helper
INFO - 2018-03-26 22:45:48 --> Helper loaded: form_helper
INFO - 2018-03-26 22:45:48 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:45:48 --> Controller Class Initialized
INFO - 2018-03-26 22:45:48 --> Model Class Initialized
INFO - 2018-03-26 22:45:48 --> Model Class Initialized
INFO - 2018-03-26 22:45:48 --> Model Class Initialized
INFO - 2018-03-26 22:45:48 --> Model Class Initialized
INFO - 2018-03-26 22:45:48 --> Model Class Initialized
INFO - 2018-03-26 22:45:48 --> Model Class Initialized
INFO - 2018-03-26 22:45:48 --> Model Class Initialized
INFO - 2018-03-26 22:45:48 --> Model Class Initialized
INFO - 2018-03-26 22:45:48 --> Model Class Initialized
INFO - 2018-03-26 22:45:48 --> Model Class Initialized
INFO - 2018-03-26 22:45:48 --> Model Class Initialized
INFO - 2018-03-26 22:45:48 --> Model Class Initialized
INFO - 2018-03-26 22:45:48 --> Model Class Initialized
INFO - 2018-03-26 22:45:48 --> Model Class Initialized
INFO - 2018-03-26 22:45:48 --> Model Class Initialized
INFO - 2018-03-26 22:45:48 --> Helper loaded: date_helper
INFO - 2018-03-26 22:45:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:45:53 --> Config Class Initialized
INFO - 2018-03-26 22:45:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:45:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:45:53 --> Utf8 Class Initialized
INFO - 2018-03-26 22:45:53 --> URI Class Initialized
INFO - 2018-03-26 22:45:53 --> Router Class Initialized
INFO - 2018-03-26 22:45:53 --> Output Class Initialized
INFO - 2018-03-26 22:45:53 --> Security Class Initialized
DEBUG - 2018-03-26 22:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:45:53 --> Input Class Initialized
INFO - 2018-03-26 22:45:53 --> Language Class Initialized
INFO - 2018-03-26 22:45:53 --> Loader Class Initialized
INFO - 2018-03-26 22:45:53 --> Helper loaded: url_helper
INFO - 2018-03-26 22:45:53 --> Helper loaded: form_helper
INFO - 2018-03-26 22:45:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:45:53 --> Controller Class Initialized
INFO - 2018-03-26 22:45:53 --> Model Class Initialized
INFO - 2018-03-26 22:45:53 --> Model Class Initialized
INFO - 2018-03-26 22:45:53 --> Model Class Initialized
INFO - 2018-03-26 22:45:53 --> Model Class Initialized
INFO - 2018-03-26 22:45:53 --> Model Class Initialized
INFO - 2018-03-26 22:45:53 --> Model Class Initialized
INFO - 2018-03-26 22:45:53 --> Model Class Initialized
INFO - 2018-03-26 22:45:53 --> Model Class Initialized
INFO - 2018-03-26 22:45:53 --> Model Class Initialized
INFO - 2018-03-26 22:45:53 --> Model Class Initialized
INFO - 2018-03-26 22:45:53 --> Model Class Initialized
INFO - 2018-03-26 22:45:53 --> Model Class Initialized
INFO - 2018-03-26 22:45:53 --> Model Class Initialized
INFO - 2018-03-26 22:45:53 --> Model Class Initialized
INFO - 2018-03-26 22:45:53 --> Model Class Initialized
INFO - 2018-03-26 22:45:53 --> Helper loaded: date_helper
INFO - 2018-03-26 22:45:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:45:57 --> Config Class Initialized
INFO - 2018-03-26 22:45:57 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:45:57 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:45:57 --> Utf8 Class Initialized
INFO - 2018-03-26 22:45:57 --> URI Class Initialized
INFO - 2018-03-26 22:45:57 --> Router Class Initialized
INFO - 2018-03-26 22:45:57 --> Output Class Initialized
INFO - 2018-03-26 22:45:57 --> Security Class Initialized
DEBUG - 2018-03-26 22:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:45:57 --> Input Class Initialized
INFO - 2018-03-26 22:45:57 --> Language Class Initialized
INFO - 2018-03-26 22:45:57 --> Loader Class Initialized
INFO - 2018-03-26 22:45:57 --> Helper loaded: url_helper
INFO - 2018-03-26 22:45:57 --> Helper loaded: form_helper
INFO - 2018-03-26 22:45:57 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:45:57 --> Controller Class Initialized
INFO - 2018-03-26 22:45:57 --> Model Class Initialized
INFO - 2018-03-26 22:45:57 --> Model Class Initialized
INFO - 2018-03-26 22:45:57 --> Model Class Initialized
INFO - 2018-03-26 22:45:57 --> Model Class Initialized
INFO - 2018-03-26 22:45:57 --> Model Class Initialized
INFO - 2018-03-26 22:45:57 --> Model Class Initialized
INFO - 2018-03-26 22:45:57 --> Model Class Initialized
INFO - 2018-03-26 22:45:57 --> Model Class Initialized
INFO - 2018-03-26 22:45:57 --> Model Class Initialized
INFO - 2018-03-26 22:45:57 --> Model Class Initialized
INFO - 2018-03-26 22:45:57 --> Model Class Initialized
INFO - 2018-03-26 22:45:57 --> Model Class Initialized
INFO - 2018-03-26 22:45:57 --> Model Class Initialized
INFO - 2018-03-26 22:45:57 --> Model Class Initialized
INFO - 2018-03-26 22:45:57 --> Model Class Initialized
INFO - 2018-03-26 22:45:57 --> Helper loaded: date_helper
INFO - 2018-03-26 22:45:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:45:58 --> Config Class Initialized
INFO - 2018-03-26 22:45:58 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:45:58 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:45:58 --> Utf8 Class Initialized
INFO - 2018-03-26 22:45:58 --> URI Class Initialized
INFO - 2018-03-26 22:45:58 --> Router Class Initialized
INFO - 2018-03-26 22:45:58 --> Output Class Initialized
INFO - 2018-03-26 22:45:58 --> Security Class Initialized
DEBUG - 2018-03-26 22:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:45:58 --> Input Class Initialized
INFO - 2018-03-26 22:45:58 --> Language Class Initialized
INFO - 2018-03-26 22:45:58 --> Loader Class Initialized
INFO - 2018-03-26 22:45:58 --> Helper loaded: url_helper
INFO - 2018-03-26 22:45:58 --> Helper loaded: form_helper
INFO - 2018-03-26 22:45:58 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:45:58 --> Controller Class Initialized
INFO - 2018-03-26 22:45:58 --> Model Class Initialized
INFO - 2018-03-26 22:45:58 --> Model Class Initialized
INFO - 2018-03-26 22:45:58 --> Model Class Initialized
INFO - 2018-03-26 22:45:58 --> Model Class Initialized
INFO - 2018-03-26 22:45:58 --> Model Class Initialized
INFO - 2018-03-26 22:45:58 --> Model Class Initialized
INFO - 2018-03-26 22:45:58 --> Model Class Initialized
INFO - 2018-03-26 22:45:58 --> Model Class Initialized
INFO - 2018-03-26 22:45:58 --> Model Class Initialized
INFO - 2018-03-26 22:45:58 --> Model Class Initialized
INFO - 2018-03-26 22:45:58 --> Model Class Initialized
INFO - 2018-03-26 22:45:58 --> Model Class Initialized
INFO - 2018-03-26 22:45:58 --> Model Class Initialized
INFO - 2018-03-26 22:45:58 --> Model Class Initialized
INFO - 2018-03-26 22:45:58 --> Model Class Initialized
INFO - 2018-03-26 22:45:58 --> Helper loaded: date_helper
INFO - 2018-03-26 22:45:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:46:01 --> Config Class Initialized
INFO - 2018-03-26 22:46:01 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:46:01 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:46:01 --> Utf8 Class Initialized
INFO - 2018-03-26 22:46:01 --> URI Class Initialized
INFO - 2018-03-26 22:46:01 --> Router Class Initialized
INFO - 2018-03-26 22:46:01 --> Output Class Initialized
INFO - 2018-03-26 22:46:01 --> Security Class Initialized
DEBUG - 2018-03-26 22:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:46:01 --> Input Class Initialized
INFO - 2018-03-26 22:46:01 --> Language Class Initialized
INFO - 2018-03-26 22:46:01 --> Loader Class Initialized
INFO - 2018-03-26 22:46:01 --> Helper loaded: url_helper
INFO - 2018-03-26 22:46:01 --> Helper loaded: form_helper
INFO - 2018-03-26 22:46:01 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:46:01 --> Controller Class Initialized
INFO - 2018-03-26 22:46:01 --> Model Class Initialized
INFO - 2018-03-26 22:46:01 --> Model Class Initialized
INFO - 2018-03-26 22:46:01 --> Model Class Initialized
INFO - 2018-03-26 22:46:01 --> Model Class Initialized
INFO - 2018-03-26 22:46:01 --> Model Class Initialized
INFO - 2018-03-26 22:46:01 --> Model Class Initialized
INFO - 2018-03-26 22:46:01 --> Model Class Initialized
INFO - 2018-03-26 22:46:01 --> Model Class Initialized
INFO - 2018-03-26 22:46:01 --> Model Class Initialized
INFO - 2018-03-26 22:46:01 --> Model Class Initialized
INFO - 2018-03-26 22:46:01 --> Model Class Initialized
INFO - 2018-03-26 22:46:01 --> Model Class Initialized
INFO - 2018-03-26 22:46:01 --> Model Class Initialized
INFO - 2018-03-26 22:46:01 --> Model Class Initialized
INFO - 2018-03-26 22:46:01 --> Model Class Initialized
INFO - 2018-03-26 22:46:01 --> Helper loaded: date_helper
INFO - 2018-03-26 22:46:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:46:25 --> Config Class Initialized
INFO - 2018-03-26 22:46:25 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:46:25 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:46:25 --> Utf8 Class Initialized
INFO - 2018-03-26 22:46:25 --> URI Class Initialized
INFO - 2018-03-26 22:46:25 --> Router Class Initialized
INFO - 2018-03-26 22:46:25 --> Output Class Initialized
INFO - 2018-03-26 22:46:25 --> Security Class Initialized
DEBUG - 2018-03-26 22:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:46:25 --> Input Class Initialized
INFO - 2018-03-26 22:46:25 --> Language Class Initialized
INFO - 2018-03-26 22:46:25 --> Loader Class Initialized
INFO - 2018-03-26 22:46:25 --> Helper loaded: url_helper
INFO - 2018-03-26 22:46:25 --> Helper loaded: form_helper
INFO - 2018-03-26 22:46:25 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:46:25 --> Controller Class Initialized
INFO - 2018-03-26 22:46:25 --> Model Class Initialized
INFO - 2018-03-26 22:46:25 --> Model Class Initialized
INFO - 2018-03-26 22:46:25 --> Model Class Initialized
INFO - 2018-03-26 22:46:25 --> Model Class Initialized
INFO - 2018-03-26 22:46:25 --> Model Class Initialized
INFO - 2018-03-26 22:46:25 --> Model Class Initialized
INFO - 2018-03-26 22:46:25 --> Model Class Initialized
INFO - 2018-03-26 22:46:25 --> Model Class Initialized
INFO - 2018-03-26 22:46:25 --> Model Class Initialized
INFO - 2018-03-26 22:46:25 --> Model Class Initialized
INFO - 2018-03-26 22:46:25 --> Model Class Initialized
INFO - 2018-03-26 22:46:25 --> Model Class Initialized
INFO - 2018-03-26 22:46:25 --> Model Class Initialized
INFO - 2018-03-26 22:46:25 --> Model Class Initialized
INFO - 2018-03-26 22:46:25 --> Model Class Initialized
INFO - 2018-03-26 22:46:25 --> Helper loaded: date_helper
INFO - 2018-03-26 22:46:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:46:31 --> Config Class Initialized
INFO - 2018-03-26 22:46:31 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:46:31 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:46:31 --> Utf8 Class Initialized
INFO - 2018-03-26 22:46:31 --> URI Class Initialized
INFO - 2018-03-26 22:46:31 --> Router Class Initialized
INFO - 2018-03-26 22:46:31 --> Output Class Initialized
INFO - 2018-03-26 22:46:31 --> Security Class Initialized
DEBUG - 2018-03-26 22:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:46:31 --> Input Class Initialized
INFO - 2018-03-26 22:46:31 --> Language Class Initialized
INFO - 2018-03-26 22:46:31 --> Loader Class Initialized
INFO - 2018-03-26 22:46:31 --> Helper loaded: url_helper
INFO - 2018-03-26 22:46:31 --> Helper loaded: form_helper
INFO - 2018-03-26 22:46:31 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:46:31 --> Controller Class Initialized
INFO - 2018-03-26 22:46:31 --> Model Class Initialized
INFO - 2018-03-26 22:46:31 --> Model Class Initialized
INFO - 2018-03-26 22:46:31 --> Model Class Initialized
INFO - 2018-03-26 22:46:31 --> Model Class Initialized
INFO - 2018-03-26 22:46:31 --> Model Class Initialized
INFO - 2018-03-26 22:46:31 --> Model Class Initialized
INFO - 2018-03-26 22:46:31 --> Model Class Initialized
INFO - 2018-03-26 22:46:31 --> Model Class Initialized
INFO - 2018-03-26 22:46:31 --> Model Class Initialized
INFO - 2018-03-26 22:46:31 --> Model Class Initialized
INFO - 2018-03-26 22:46:31 --> Model Class Initialized
INFO - 2018-03-26 22:46:31 --> Model Class Initialized
INFO - 2018-03-26 22:46:31 --> Model Class Initialized
INFO - 2018-03-26 22:46:31 --> Model Class Initialized
INFO - 2018-03-26 22:46:31 --> Model Class Initialized
INFO - 2018-03-26 22:46:31 --> Helper loaded: date_helper
INFO - 2018-03-26 22:46:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:46:38 --> Config Class Initialized
INFO - 2018-03-26 22:46:38 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:46:38 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:46:38 --> Utf8 Class Initialized
INFO - 2018-03-26 22:46:38 --> URI Class Initialized
INFO - 2018-03-26 22:46:38 --> Router Class Initialized
INFO - 2018-03-26 22:46:38 --> Output Class Initialized
INFO - 2018-03-26 22:46:38 --> Security Class Initialized
DEBUG - 2018-03-26 22:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:46:38 --> Input Class Initialized
INFO - 2018-03-26 22:46:38 --> Language Class Initialized
INFO - 2018-03-26 22:46:38 --> Loader Class Initialized
INFO - 2018-03-26 22:46:38 --> Helper loaded: url_helper
INFO - 2018-03-26 22:46:38 --> Helper loaded: form_helper
INFO - 2018-03-26 22:46:38 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:46:38 --> Controller Class Initialized
INFO - 2018-03-26 22:46:38 --> Model Class Initialized
INFO - 2018-03-26 22:46:38 --> Model Class Initialized
INFO - 2018-03-26 22:46:38 --> Model Class Initialized
INFO - 2018-03-26 22:46:38 --> Model Class Initialized
INFO - 2018-03-26 22:46:38 --> Model Class Initialized
INFO - 2018-03-26 22:46:38 --> Model Class Initialized
INFO - 2018-03-26 22:46:38 --> Model Class Initialized
INFO - 2018-03-26 22:46:38 --> Model Class Initialized
INFO - 2018-03-26 22:46:38 --> Model Class Initialized
INFO - 2018-03-26 22:46:38 --> Model Class Initialized
INFO - 2018-03-26 22:46:38 --> Model Class Initialized
INFO - 2018-03-26 22:46:38 --> Model Class Initialized
INFO - 2018-03-26 22:46:38 --> Model Class Initialized
INFO - 2018-03-26 22:46:38 --> Model Class Initialized
INFO - 2018-03-26 22:46:38 --> Model Class Initialized
INFO - 2018-03-26 22:46:38 --> Helper loaded: date_helper
INFO - 2018-03-26 22:46:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:46:40 --> Config Class Initialized
INFO - 2018-03-26 22:46:40 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:46:40 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:46:40 --> Utf8 Class Initialized
INFO - 2018-03-26 22:46:40 --> URI Class Initialized
INFO - 2018-03-26 22:46:40 --> Router Class Initialized
INFO - 2018-03-26 22:46:40 --> Output Class Initialized
INFO - 2018-03-26 22:46:40 --> Security Class Initialized
DEBUG - 2018-03-26 22:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:46:40 --> Input Class Initialized
INFO - 2018-03-26 22:46:40 --> Language Class Initialized
INFO - 2018-03-26 22:46:40 --> Loader Class Initialized
INFO - 2018-03-26 22:46:40 --> Helper loaded: url_helper
INFO - 2018-03-26 22:46:40 --> Helper loaded: form_helper
INFO - 2018-03-26 22:46:40 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:46:40 --> Controller Class Initialized
INFO - 2018-03-26 22:46:40 --> Model Class Initialized
INFO - 2018-03-26 22:46:40 --> Model Class Initialized
INFO - 2018-03-26 22:46:40 --> Model Class Initialized
INFO - 2018-03-26 22:46:40 --> Model Class Initialized
INFO - 2018-03-26 22:46:40 --> Model Class Initialized
INFO - 2018-03-26 22:46:40 --> Model Class Initialized
INFO - 2018-03-26 22:46:40 --> Model Class Initialized
INFO - 2018-03-26 22:46:40 --> Model Class Initialized
INFO - 2018-03-26 22:46:40 --> Model Class Initialized
INFO - 2018-03-26 22:46:40 --> Model Class Initialized
INFO - 2018-03-26 22:46:40 --> Model Class Initialized
INFO - 2018-03-26 22:46:40 --> Model Class Initialized
INFO - 2018-03-26 22:46:40 --> Model Class Initialized
INFO - 2018-03-26 22:46:40 --> Model Class Initialized
INFO - 2018-03-26 22:46:40 --> Model Class Initialized
INFO - 2018-03-26 22:46:40 --> Helper loaded: date_helper
INFO - 2018-03-26 22:46:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:46:44 --> Config Class Initialized
INFO - 2018-03-26 22:46:44 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:46:44 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:46:44 --> Utf8 Class Initialized
INFO - 2018-03-26 22:46:44 --> URI Class Initialized
INFO - 2018-03-26 22:46:44 --> Router Class Initialized
INFO - 2018-03-26 22:46:44 --> Output Class Initialized
INFO - 2018-03-26 22:46:44 --> Security Class Initialized
DEBUG - 2018-03-26 22:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:46:44 --> Input Class Initialized
INFO - 2018-03-26 22:46:44 --> Language Class Initialized
INFO - 2018-03-26 22:46:44 --> Loader Class Initialized
INFO - 2018-03-26 22:46:44 --> Helper loaded: url_helper
INFO - 2018-03-26 22:46:44 --> Helper loaded: form_helper
INFO - 2018-03-26 22:46:44 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:46:44 --> Controller Class Initialized
INFO - 2018-03-26 22:46:44 --> Model Class Initialized
INFO - 2018-03-26 22:46:44 --> Model Class Initialized
INFO - 2018-03-26 22:46:44 --> Model Class Initialized
INFO - 2018-03-26 22:46:44 --> Model Class Initialized
INFO - 2018-03-26 22:46:44 --> Model Class Initialized
INFO - 2018-03-26 22:46:44 --> Model Class Initialized
INFO - 2018-03-26 22:46:44 --> Model Class Initialized
INFO - 2018-03-26 22:46:44 --> Model Class Initialized
INFO - 2018-03-26 22:46:44 --> Model Class Initialized
INFO - 2018-03-26 22:46:44 --> Model Class Initialized
INFO - 2018-03-26 22:46:44 --> Model Class Initialized
INFO - 2018-03-26 22:46:44 --> Model Class Initialized
INFO - 2018-03-26 22:46:44 --> Model Class Initialized
INFO - 2018-03-26 22:46:44 --> Model Class Initialized
INFO - 2018-03-26 22:46:44 --> Model Class Initialized
INFO - 2018-03-26 22:46:44 --> Helper loaded: date_helper
INFO - 2018-03-26 22:46:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:46:46 --> Config Class Initialized
INFO - 2018-03-26 22:46:46 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:46:46 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:46:46 --> Utf8 Class Initialized
INFO - 2018-03-26 22:46:46 --> URI Class Initialized
INFO - 2018-03-26 22:46:46 --> Router Class Initialized
INFO - 2018-03-26 22:46:46 --> Output Class Initialized
INFO - 2018-03-26 22:46:46 --> Security Class Initialized
DEBUG - 2018-03-26 22:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:46:46 --> Input Class Initialized
INFO - 2018-03-26 22:46:46 --> Language Class Initialized
INFO - 2018-03-26 22:46:46 --> Loader Class Initialized
INFO - 2018-03-26 22:46:46 --> Helper loaded: url_helper
INFO - 2018-03-26 22:46:46 --> Helper loaded: form_helper
INFO - 2018-03-26 22:46:46 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:46:46 --> Controller Class Initialized
INFO - 2018-03-26 22:46:46 --> Model Class Initialized
INFO - 2018-03-26 22:46:46 --> Model Class Initialized
INFO - 2018-03-26 22:46:46 --> Model Class Initialized
INFO - 2018-03-26 22:46:46 --> Model Class Initialized
INFO - 2018-03-26 22:46:46 --> Model Class Initialized
INFO - 2018-03-26 22:46:46 --> Model Class Initialized
INFO - 2018-03-26 22:46:46 --> Model Class Initialized
INFO - 2018-03-26 22:46:46 --> Model Class Initialized
INFO - 2018-03-26 22:46:46 --> Model Class Initialized
INFO - 2018-03-26 22:46:46 --> Model Class Initialized
INFO - 2018-03-26 22:46:46 --> Model Class Initialized
INFO - 2018-03-26 22:46:46 --> Model Class Initialized
INFO - 2018-03-26 22:46:46 --> Model Class Initialized
INFO - 2018-03-26 22:46:46 --> Model Class Initialized
INFO - 2018-03-26 22:46:46 --> Model Class Initialized
INFO - 2018-03-26 22:46:46 --> Helper loaded: date_helper
INFO - 2018-03-26 22:46:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:46:48 --> Config Class Initialized
INFO - 2018-03-26 22:46:48 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:46:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:46:48 --> Utf8 Class Initialized
INFO - 2018-03-26 22:46:48 --> URI Class Initialized
INFO - 2018-03-26 22:46:48 --> Router Class Initialized
INFO - 2018-03-26 22:46:48 --> Output Class Initialized
INFO - 2018-03-26 22:46:48 --> Security Class Initialized
DEBUG - 2018-03-26 22:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:46:48 --> Input Class Initialized
INFO - 2018-03-26 22:46:48 --> Language Class Initialized
INFO - 2018-03-26 22:46:48 --> Loader Class Initialized
INFO - 2018-03-26 22:46:48 --> Helper loaded: url_helper
INFO - 2018-03-26 22:46:48 --> Helper loaded: form_helper
INFO - 2018-03-26 22:46:48 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:46:48 --> Controller Class Initialized
INFO - 2018-03-26 22:46:48 --> Model Class Initialized
INFO - 2018-03-26 22:46:48 --> Model Class Initialized
INFO - 2018-03-26 22:46:48 --> Model Class Initialized
INFO - 2018-03-26 22:46:48 --> Model Class Initialized
INFO - 2018-03-26 22:46:48 --> Model Class Initialized
INFO - 2018-03-26 22:46:48 --> Model Class Initialized
INFO - 2018-03-26 22:46:48 --> Model Class Initialized
INFO - 2018-03-26 22:46:48 --> Model Class Initialized
INFO - 2018-03-26 22:46:48 --> Model Class Initialized
INFO - 2018-03-26 22:46:48 --> Model Class Initialized
INFO - 2018-03-26 22:46:48 --> Model Class Initialized
INFO - 2018-03-26 22:46:48 --> Model Class Initialized
INFO - 2018-03-26 22:46:48 --> Model Class Initialized
INFO - 2018-03-26 22:46:48 --> Model Class Initialized
INFO - 2018-03-26 22:46:48 --> Model Class Initialized
INFO - 2018-03-26 22:46:48 --> Helper loaded: date_helper
INFO - 2018-03-26 22:46:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:46:50 --> Config Class Initialized
INFO - 2018-03-26 22:46:50 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:46:50 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:46:50 --> Utf8 Class Initialized
INFO - 2018-03-26 22:46:50 --> URI Class Initialized
INFO - 2018-03-26 22:46:50 --> Router Class Initialized
INFO - 2018-03-26 22:46:50 --> Output Class Initialized
INFO - 2018-03-26 22:46:50 --> Security Class Initialized
DEBUG - 2018-03-26 22:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:46:50 --> Input Class Initialized
INFO - 2018-03-26 22:46:50 --> Language Class Initialized
INFO - 2018-03-26 22:46:50 --> Loader Class Initialized
INFO - 2018-03-26 22:46:50 --> Helper loaded: url_helper
INFO - 2018-03-26 22:46:50 --> Helper loaded: form_helper
INFO - 2018-03-26 22:46:50 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:46:50 --> Controller Class Initialized
INFO - 2018-03-26 22:46:50 --> Model Class Initialized
INFO - 2018-03-26 22:46:50 --> Model Class Initialized
INFO - 2018-03-26 22:46:50 --> Model Class Initialized
INFO - 2018-03-26 22:46:50 --> Model Class Initialized
INFO - 2018-03-26 22:46:50 --> Model Class Initialized
INFO - 2018-03-26 22:46:50 --> Model Class Initialized
INFO - 2018-03-26 22:46:50 --> Model Class Initialized
INFO - 2018-03-26 22:46:50 --> Model Class Initialized
INFO - 2018-03-26 22:46:50 --> Model Class Initialized
INFO - 2018-03-26 22:46:50 --> Model Class Initialized
INFO - 2018-03-26 22:46:50 --> Model Class Initialized
INFO - 2018-03-26 22:46:50 --> Model Class Initialized
INFO - 2018-03-26 22:46:50 --> Model Class Initialized
INFO - 2018-03-26 22:46:50 --> Model Class Initialized
INFO - 2018-03-26 22:46:50 --> Model Class Initialized
INFO - 2018-03-26 22:46:50 --> Helper loaded: date_helper
INFO - 2018-03-26 22:46:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:46:54 --> Config Class Initialized
INFO - 2018-03-26 22:46:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:46:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:46:54 --> Utf8 Class Initialized
INFO - 2018-03-26 22:46:54 --> URI Class Initialized
INFO - 2018-03-26 22:46:54 --> Router Class Initialized
INFO - 2018-03-26 22:46:54 --> Output Class Initialized
INFO - 2018-03-26 22:46:54 --> Security Class Initialized
DEBUG - 2018-03-26 22:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:46:54 --> Input Class Initialized
INFO - 2018-03-26 22:46:54 --> Language Class Initialized
INFO - 2018-03-26 22:46:54 --> Loader Class Initialized
INFO - 2018-03-26 22:46:54 --> Helper loaded: url_helper
INFO - 2018-03-26 22:46:54 --> Helper loaded: form_helper
INFO - 2018-03-26 22:46:54 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:46:54 --> Controller Class Initialized
INFO - 2018-03-26 22:46:54 --> Model Class Initialized
INFO - 2018-03-26 22:46:54 --> Model Class Initialized
INFO - 2018-03-26 22:46:54 --> Model Class Initialized
INFO - 2018-03-26 22:46:54 --> Model Class Initialized
INFO - 2018-03-26 22:46:54 --> Model Class Initialized
INFO - 2018-03-26 22:46:54 --> Model Class Initialized
INFO - 2018-03-26 22:46:54 --> Model Class Initialized
INFO - 2018-03-26 22:46:54 --> Model Class Initialized
INFO - 2018-03-26 22:46:54 --> Model Class Initialized
INFO - 2018-03-26 22:46:54 --> Model Class Initialized
INFO - 2018-03-26 22:46:54 --> Model Class Initialized
INFO - 2018-03-26 22:46:54 --> Model Class Initialized
INFO - 2018-03-26 22:46:54 --> Model Class Initialized
INFO - 2018-03-26 22:46:54 --> Model Class Initialized
INFO - 2018-03-26 22:46:54 --> Model Class Initialized
INFO - 2018-03-26 22:46:54 --> Helper loaded: date_helper
INFO - 2018-03-26 22:46:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:50:28 --> Config Class Initialized
INFO - 2018-03-26 22:50:28 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:50:28 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:50:28 --> Utf8 Class Initialized
INFO - 2018-03-26 22:50:28 --> URI Class Initialized
INFO - 2018-03-26 22:50:28 --> Router Class Initialized
INFO - 2018-03-26 22:50:28 --> Output Class Initialized
INFO - 2018-03-26 22:50:28 --> Security Class Initialized
DEBUG - 2018-03-26 22:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:50:28 --> Input Class Initialized
INFO - 2018-03-26 22:50:28 --> Language Class Initialized
INFO - 2018-03-26 22:50:28 --> Loader Class Initialized
INFO - 2018-03-26 22:50:28 --> Helper loaded: url_helper
INFO - 2018-03-26 22:50:28 --> Helper loaded: form_helper
INFO - 2018-03-26 22:50:28 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:50:28 --> Controller Class Initialized
INFO - 2018-03-26 22:50:28 --> Model Class Initialized
INFO - 2018-03-26 22:50:28 --> Model Class Initialized
INFO - 2018-03-26 22:50:28 --> Model Class Initialized
INFO - 2018-03-26 22:50:28 --> Model Class Initialized
INFO - 2018-03-26 22:50:28 --> Model Class Initialized
INFO - 2018-03-26 22:50:28 --> Model Class Initialized
INFO - 2018-03-26 22:50:28 --> Model Class Initialized
INFO - 2018-03-26 22:50:28 --> Model Class Initialized
INFO - 2018-03-26 22:50:28 --> Model Class Initialized
INFO - 2018-03-26 22:50:28 --> Model Class Initialized
INFO - 2018-03-26 22:50:28 --> Model Class Initialized
INFO - 2018-03-26 22:50:28 --> Model Class Initialized
INFO - 2018-03-26 22:50:28 --> Model Class Initialized
INFO - 2018-03-26 22:50:28 --> Model Class Initialized
INFO - 2018-03-26 22:50:28 --> Model Class Initialized
INFO - 2018-03-26 22:50:28 --> Helper loaded: date_helper
INFO - 2018-03-26 22:50:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:50:32 --> Config Class Initialized
INFO - 2018-03-26 22:50:32 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:50:32 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:50:32 --> Utf8 Class Initialized
INFO - 2018-03-26 22:50:32 --> URI Class Initialized
INFO - 2018-03-26 22:50:32 --> Router Class Initialized
INFO - 2018-03-26 22:50:32 --> Output Class Initialized
INFO - 2018-03-26 22:50:32 --> Security Class Initialized
DEBUG - 2018-03-26 22:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:50:32 --> Input Class Initialized
INFO - 2018-03-26 22:50:32 --> Language Class Initialized
INFO - 2018-03-26 22:50:32 --> Loader Class Initialized
INFO - 2018-03-26 22:50:32 --> Helper loaded: url_helper
INFO - 2018-03-26 22:50:32 --> Helper loaded: form_helper
INFO - 2018-03-26 22:50:32 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:50:32 --> Controller Class Initialized
INFO - 2018-03-26 22:50:32 --> Model Class Initialized
INFO - 2018-03-26 22:50:32 --> Model Class Initialized
INFO - 2018-03-26 22:50:32 --> Model Class Initialized
INFO - 2018-03-26 22:50:32 --> Model Class Initialized
INFO - 2018-03-26 22:50:32 --> Model Class Initialized
INFO - 2018-03-26 22:50:32 --> Model Class Initialized
INFO - 2018-03-26 22:50:32 --> Model Class Initialized
INFO - 2018-03-26 22:50:32 --> Model Class Initialized
INFO - 2018-03-26 22:50:32 --> Model Class Initialized
INFO - 2018-03-26 22:50:32 --> Model Class Initialized
INFO - 2018-03-26 22:50:32 --> Model Class Initialized
INFO - 2018-03-26 22:50:32 --> Model Class Initialized
INFO - 2018-03-26 22:50:32 --> Model Class Initialized
INFO - 2018-03-26 22:50:32 --> Model Class Initialized
INFO - 2018-03-26 22:50:32 --> Model Class Initialized
INFO - 2018-03-26 22:50:32 --> Helper loaded: date_helper
INFO - 2018-03-26 22:50:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:51:33 --> Config Class Initialized
INFO - 2018-03-26 22:51:33 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:51:33 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:51:33 --> Utf8 Class Initialized
INFO - 2018-03-26 22:51:33 --> URI Class Initialized
INFO - 2018-03-26 22:51:33 --> Router Class Initialized
INFO - 2018-03-26 22:51:33 --> Output Class Initialized
INFO - 2018-03-26 22:51:33 --> Security Class Initialized
DEBUG - 2018-03-26 22:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:51:33 --> Input Class Initialized
INFO - 2018-03-26 22:51:33 --> Language Class Initialized
INFO - 2018-03-26 22:51:33 --> Loader Class Initialized
INFO - 2018-03-26 22:51:33 --> Helper loaded: url_helper
INFO - 2018-03-26 22:51:33 --> Helper loaded: form_helper
INFO - 2018-03-26 22:51:33 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:51:33 --> Controller Class Initialized
INFO - 2018-03-26 22:51:33 --> Model Class Initialized
INFO - 2018-03-26 22:51:33 --> Model Class Initialized
INFO - 2018-03-26 22:51:33 --> Model Class Initialized
INFO - 2018-03-26 22:51:33 --> Model Class Initialized
INFO - 2018-03-26 22:51:33 --> Model Class Initialized
INFO - 2018-03-26 22:51:33 --> Model Class Initialized
INFO - 2018-03-26 22:51:33 --> Model Class Initialized
INFO - 2018-03-26 22:51:33 --> Model Class Initialized
INFO - 2018-03-26 22:51:33 --> Model Class Initialized
INFO - 2018-03-26 22:51:33 --> Model Class Initialized
INFO - 2018-03-26 22:51:33 --> Model Class Initialized
INFO - 2018-03-26 22:51:33 --> Model Class Initialized
INFO - 2018-03-26 22:51:33 --> Model Class Initialized
INFO - 2018-03-26 22:51:33 --> Model Class Initialized
INFO - 2018-03-26 22:51:33 --> Model Class Initialized
INFO - 2018-03-26 22:51:33 --> Helper loaded: date_helper
INFO - 2018-03-26 22:51:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:51:38 --> Config Class Initialized
INFO - 2018-03-26 22:51:38 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:51:38 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:51:38 --> Utf8 Class Initialized
INFO - 2018-03-26 22:51:38 --> URI Class Initialized
INFO - 2018-03-26 22:51:38 --> Router Class Initialized
INFO - 2018-03-26 22:51:38 --> Output Class Initialized
INFO - 2018-03-26 22:51:38 --> Security Class Initialized
DEBUG - 2018-03-26 22:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:51:38 --> Input Class Initialized
INFO - 2018-03-26 22:51:38 --> Language Class Initialized
INFO - 2018-03-26 22:51:38 --> Loader Class Initialized
INFO - 2018-03-26 22:51:38 --> Helper loaded: url_helper
INFO - 2018-03-26 22:51:38 --> Helper loaded: form_helper
INFO - 2018-03-26 22:51:38 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:51:38 --> Controller Class Initialized
INFO - 2018-03-26 22:51:38 --> Model Class Initialized
INFO - 2018-03-26 22:51:38 --> Model Class Initialized
INFO - 2018-03-26 22:51:38 --> Model Class Initialized
INFO - 2018-03-26 22:51:38 --> Model Class Initialized
INFO - 2018-03-26 22:51:38 --> Model Class Initialized
INFO - 2018-03-26 22:51:38 --> Model Class Initialized
INFO - 2018-03-26 22:51:38 --> Model Class Initialized
INFO - 2018-03-26 22:51:38 --> Model Class Initialized
INFO - 2018-03-26 22:51:38 --> Model Class Initialized
INFO - 2018-03-26 22:51:38 --> Model Class Initialized
INFO - 2018-03-26 22:51:38 --> Model Class Initialized
INFO - 2018-03-26 22:51:38 --> Model Class Initialized
INFO - 2018-03-26 22:51:38 --> Model Class Initialized
INFO - 2018-03-26 22:51:38 --> Model Class Initialized
INFO - 2018-03-26 22:51:38 --> Model Class Initialized
INFO - 2018-03-26 22:51:38 --> Helper loaded: date_helper
INFO - 2018-03-26 22:51:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:51:54 --> Config Class Initialized
INFO - 2018-03-26 22:51:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:51:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:51:54 --> Utf8 Class Initialized
INFO - 2018-03-26 22:51:54 --> URI Class Initialized
INFO - 2018-03-26 22:51:54 --> Router Class Initialized
INFO - 2018-03-26 22:51:54 --> Output Class Initialized
INFO - 2018-03-26 22:51:54 --> Security Class Initialized
DEBUG - 2018-03-26 22:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:51:54 --> Input Class Initialized
INFO - 2018-03-26 22:51:54 --> Language Class Initialized
INFO - 2018-03-26 22:51:54 --> Loader Class Initialized
INFO - 2018-03-26 22:51:54 --> Helper loaded: url_helper
INFO - 2018-03-26 22:51:54 --> Helper loaded: form_helper
INFO - 2018-03-26 22:51:54 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:51:54 --> Controller Class Initialized
INFO - 2018-03-26 22:51:54 --> Model Class Initialized
INFO - 2018-03-26 22:51:54 --> Model Class Initialized
INFO - 2018-03-26 22:51:54 --> Model Class Initialized
INFO - 2018-03-26 22:51:54 --> Model Class Initialized
INFO - 2018-03-26 22:51:54 --> Model Class Initialized
INFO - 2018-03-26 22:51:54 --> Model Class Initialized
INFO - 2018-03-26 22:51:54 --> Model Class Initialized
INFO - 2018-03-26 22:51:54 --> Model Class Initialized
INFO - 2018-03-26 22:51:54 --> Model Class Initialized
INFO - 2018-03-26 22:51:54 --> Model Class Initialized
INFO - 2018-03-26 22:51:54 --> Model Class Initialized
INFO - 2018-03-26 22:51:54 --> Model Class Initialized
INFO - 2018-03-26 22:51:54 --> Model Class Initialized
INFO - 2018-03-26 22:51:54 --> Model Class Initialized
INFO - 2018-03-26 22:51:54 --> Model Class Initialized
INFO - 2018-03-26 22:51:54 --> Helper loaded: date_helper
INFO - 2018-03-26 22:51:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:51:59 --> Config Class Initialized
INFO - 2018-03-26 22:51:59 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:51:59 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:51:59 --> Utf8 Class Initialized
INFO - 2018-03-26 22:51:59 --> URI Class Initialized
INFO - 2018-03-26 22:51:59 --> Router Class Initialized
INFO - 2018-03-26 22:51:59 --> Output Class Initialized
INFO - 2018-03-26 22:51:59 --> Security Class Initialized
DEBUG - 2018-03-26 22:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:51:59 --> Input Class Initialized
INFO - 2018-03-26 22:51:59 --> Language Class Initialized
INFO - 2018-03-26 22:51:59 --> Loader Class Initialized
INFO - 2018-03-26 22:51:59 --> Helper loaded: url_helper
INFO - 2018-03-26 22:51:59 --> Helper loaded: form_helper
INFO - 2018-03-26 22:51:59 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:51:59 --> Controller Class Initialized
INFO - 2018-03-26 22:51:59 --> Model Class Initialized
INFO - 2018-03-26 22:51:59 --> Model Class Initialized
INFO - 2018-03-26 22:51:59 --> Model Class Initialized
INFO - 2018-03-26 22:51:59 --> Model Class Initialized
INFO - 2018-03-26 22:51:59 --> Model Class Initialized
INFO - 2018-03-26 22:51:59 --> Model Class Initialized
INFO - 2018-03-26 22:51:59 --> Model Class Initialized
INFO - 2018-03-26 22:51:59 --> Model Class Initialized
INFO - 2018-03-26 22:51:59 --> Model Class Initialized
INFO - 2018-03-26 22:51:59 --> Model Class Initialized
INFO - 2018-03-26 22:51:59 --> Model Class Initialized
INFO - 2018-03-26 22:51:59 --> Model Class Initialized
INFO - 2018-03-26 22:51:59 --> Model Class Initialized
INFO - 2018-03-26 22:51:59 --> Model Class Initialized
INFO - 2018-03-26 22:51:59 --> Model Class Initialized
INFO - 2018-03-26 22:51:59 --> Helper loaded: date_helper
INFO - 2018-03-26 22:51:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:52:08 --> Config Class Initialized
INFO - 2018-03-26 22:52:08 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:52:08 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:52:08 --> Utf8 Class Initialized
INFO - 2018-03-26 22:52:08 --> URI Class Initialized
INFO - 2018-03-26 22:52:08 --> Router Class Initialized
INFO - 2018-03-26 22:52:08 --> Output Class Initialized
INFO - 2018-03-26 22:52:08 --> Security Class Initialized
DEBUG - 2018-03-26 22:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:52:08 --> Input Class Initialized
INFO - 2018-03-26 22:52:08 --> Language Class Initialized
INFO - 2018-03-26 22:52:08 --> Loader Class Initialized
INFO - 2018-03-26 22:52:08 --> Helper loaded: url_helper
INFO - 2018-03-26 22:52:08 --> Helper loaded: form_helper
INFO - 2018-03-26 22:52:08 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:52:08 --> Controller Class Initialized
INFO - 2018-03-26 22:52:08 --> Model Class Initialized
INFO - 2018-03-26 22:52:08 --> Model Class Initialized
INFO - 2018-03-26 22:52:08 --> Model Class Initialized
INFO - 2018-03-26 22:52:08 --> Model Class Initialized
INFO - 2018-03-26 22:52:08 --> Model Class Initialized
INFO - 2018-03-26 22:52:08 --> Model Class Initialized
INFO - 2018-03-26 22:52:08 --> Model Class Initialized
INFO - 2018-03-26 22:52:08 --> Model Class Initialized
INFO - 2018-03-26 22:52:08 --> Model Class Initialized
INFO - 2018-03-26 22:52:08 --> Model Class Initialized
INFO - 2018-03-26 22:52:08 --> Model Class Initialized
INFO - 2018-03-26 22:52:08 --> Model Class Initialized
INFO - 2018-03-26 22:52:08 --> Model Class Initialized
INFO - 2018-03-26 22:52:08 --> Model Class Initialized
INFO - 2018-03-26 22:52:08 --> Model Class Initialized
INFO - 2018-03-26 22:52:08 --> Helper loaded: date_helper
INFO - 2018-03-26 22:52:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:52:36 --> Config Class Initialized
INFO - 2018-03-26 22:52:36 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:52:36 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:52:36 --> Utf8 Class Initialized
INFO - 2018-03-26 22:52:36 --> URI Class Initialized
INFO - 2018-03-26 22:52:36 --> Router Class Initialized
INFO - 2018-03-26 22:52:36 --> Output Class Initialized
INFO - 2018-03-26 22:52:36 --> Security Class Initialized
DEBUG - 2018-03-26 22:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:52:36 --> Input Class Initialized
INFO - 2018-03-26 22:52:36 --> Language Class Initialized
INFO - 2018-03-26 22:52:36 --> Loader Class Initialized
INFO - 2018-03-26 22:52:36 --> Helper loaded: url_helper
INFO - 2018-03-26 22:52:36 --> Helper loaded: form_helper
INFO - 2018-03-26 22:52:36 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:52:36 --> Controller Class Initialized
INFO - 2018-03-26 22:52:36 --> Model Class Initialized
INFO - 2018-03-26 22:52:36 --> Model Class Initialized
INFO - 2018-03-26 22:52:36 --> Model Class Initialized
INFO - 2018-03-26 22:52:36 --> Model Class Initialized
INFO - 2018-03-26 22:52:36 --> Model Class Initialized
INFO - 2018-03-26 22:52:36 --> Model Class Initialized
INFO - 2018-03-26 22:52:36 --> Model Class Initialized
INFO - 2018-03-26 22:52:36 --> Model Class Initialized
INFO - 2018-03-26 22:52:36 --> Model Class Initialized
INFO - 2018-03-26 22:52:36 --> Model Class Initialized
INFO - 2018-03-26 22:52:36 --> Model Class Initialized
INFO - 2018-03-26 22:52:36 --> Model Class Initialized
INFO - 2018-03-26 22:52:36 --> Model Class Initialized
INFO - 2018-03-26 22:52:36 --> Model Class Initialized
INFO - 2018-03-26 22:52:36 --> Model Class Initialized
INFO - 2018-03-26 22:52:36 --> Helper loaded: date_helper
INFO - 2018-03-26 22:52:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:52:41 --> Config Class Initialized
INFO - 2018-03-26 22:52:41 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:52:41 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:52:41 --> Utf8 Class Initialized
INFO - 2018-03-26 22:52:41 --> URI Class Initialized
INFO - 2018-03-26 22:52:41 --> Router Class Initialized
INFO - 2018-03-26 22:52:41 --> Output Class Initialized
INFO - 2018-03-26 22:52:41 --> Security Class Initialized
DEBUG - 2018-03-26 22:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:52:41 --> Input Class Initialized
INFO - 2018-03-26 22:52:41 --> Language Class Initialized
INFO - 2018-03-26 22:52:41 --> Loader Class Initialized
INFO - 2018-03-26 22:52:41 --> Helper loaded: url_helper
INFO - 2018-03-26 22:52:41 --> Helper loaded: form_helper
INFO - 2018-03-26 22:52:41 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:52:41 --> Controller Class Initialized
INFO - 2018-03-26 22:52:41 --> Model Class Initialized
INFO - 2018-03-26 22:52:41 --> Model Class Initialized
INFO - 2018-03-26 22:52:41 --> Model Class Initialized
INFO - 2018-03-26 22:52:41 --> Model Class Initialized
INFO - 2018-03-26 22:52:41 --> Model Class Initialized
INFO - 2018-03-26 22:52:41 --> Model Class Initialized
INFO - 2018-03-26 22:52:41 --> Model Class Initialized
INFO - 2018-03-26 22:52:41 --> Model Class Initialized
INFO - 2018-03-26 22:52:41 --> Model Class Initialized
INFO - 2018-03-26 22:52:41 --> Model Class Initialized
INFO - 2018-03-26 22:52:41 --> Model Class Initialized
INFO - 2018-03-26 22:52:41 --> Model Class Initialized
INFO - 2018-03-26 22:52:41 --> Model Class Initialized
INFO - 2018-03-26 22:52:41 --> Model Class Initialized
INFO - 2018-03-26 22:52:41 --> Model Class Initialized
INFO - 2018-03-26 22:52:41 --> Helper loaded: date_helper
INFO - 2018-03-26 22:52:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:53:07 --> Config Class Initialized
INFO - 2018-03-26 22:53:07 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:53:07 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:53:07 --> Utf8 Class Initialized
INFO - 2018-03-26 22:53:07 --> URI Class Initialized
INFO - 2018-03-26 22:53:07 --> Router Class Initialized
INFO - 2018-03-26 22:53:07 --> Output Class Initialized
INFO - 2018-03-26 22:53:07 --> Security Class Initialized
DEBUG - 2018-03-26 22:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:53:07 --> Input Class Initialized
INFO - 2018-03-26 22:53:07 --> Language Class Initialized
INFO - 2018-03-26 22:53:07 --> Loader Class Initialized
INFO - 2018-03-26 22:53:07 --> Helper loaded: url_helper
INFO - 2018-03-26 22:53:07 --> Helper loaded: form_helper
INFO - 2018-03-26 22:53:07 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:53:07 --> Controller Class Initialized
INFO - 2018-03-26 22:53:07 --> Model Class Initialized
INFO - 2018-03-26 22:53:07 --> Model Class Initialized
INFO - 2018-03-26 22:53:07 --> Model Class Initialized
INFO - 2018-03-26 22:53:07 --> Model Class Initialized
INFO - 2018-03-26 22:53:07 --> Model Class Initialized
INFO - 2018-03-26 22:53:07 --> Model Class Initialized
INFO - 2018-03-26 22:53:07 --> Model Class Initialized
INFO - 2018-03-26 22:53:07 --> Model Class Initialized
INFO - 2018-03-26 22:53:07 --> Model Class Initialized
INFO - 2018-03-26 22:53:07 --> Model Class Initialized
INFO - 2018-03-26 22:53:07 --> Model Class Initialized
INFO - 2018-03-26 22:53:07 --> Model Class Initialized
INFO - 2018-03-26 22:53:07 --> Model Class Initialized
INFO - 2018-03-26 22:53:07 --> Model Class Initialized
INFO - 2018-03-26 22:53:07 --> Model Class Initialized
INFO - 2018-03-26 22:53:07 --> Helper loaded: date_helper
INFO - 2018-03-26 22:53:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:53:12 --> Config Class Initialized
INFO - 2018-03-26 22:53:12 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:53:12 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:53:12 --> Utf8 Class Initialized
INFO - 2018-03-26 22:53:12 --> URI Class Initialized
INFO - 2018-03-26 22:53:12 --> Router Class Initialized
INFO - 2018-03-26 22:53:12 --> Output Class Initialized
INFO - 2018-03-26 22:53:12 --> Security Class Initialized
DEBUG - 2018-03-26 22:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:53:12 --> Input Class Initialized
INFO - 2018-03-26 22:53:12 --> Language Class Initialized
INFO - 2018-03-26 22:53:12 --> Loader Class Initialized
INFO - 2018-03-26 22:53:12 --> Helper loaded: url_helper
INFO - 2018-03-26 22:53:12 --> Helper loaded: form_helper
INFO - 2018-03-26 22:53:12 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:53:12 --> Controller Class Initialized
INFO - 2018-03-26 22:53:12 --> Model Class Initialized
INFO - 2018-03-26 22:53:12 --> Model Class Initialized
INFO - 2018-03-26 22:53:12 --> Model Class Initialized
INFO - 2018-03-26 22:53:12 --> Model Class Initialized
INFO - 2018-03-26 22:53:12 --> Model Class Initialized
INFO - 2018-03-26 22:53:12 --> Model Class Initialized
INFO - 2018-03-26 22:53:12 --> Model Class Initialized
INFO - 2018-03-26 22:53:12 --> Model Class Initialized
INFO - 2018-03-26 22:53:12 --> Model Class Initialized
INFO - 2018-03-26 22:53:12 --> Model Class Initialized
INFO - 2018-03-26 22:53:12 --> Model Class Initialized
INFO - 2018-03-26 22:53:12 --> Model Class Initialized
INFO - 2018-03-26 22:53:12 --> Model Class Initialized
INFO - 2018-03-26 22:53:12 --> Model Class Initialized
INFO - 2018-03-26 22:53:12 --> Model Class Initialized
INFO - 2018-03-26 22:53:12 --> Helper loaded: date_helper
INFO - 2018-03-26 22:53:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:53:18 --> Config Class Initialized
INFO - 2018-03-26 22:53:18 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:53:18 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:53:18 --> Utf8 Class Initialized
INFO - 2018-03-26 22:53:18 --> URI Class Initialized
INFO - 2018-03-26 22:53:18 --> Router Class Initialized
INFO - 2018-03-26 22:53:18 --> Output Class Initialized
INFO - 2018-03-26 22:53:18 --> Security Class Initialized
DEBUG - 2018-03-26 22:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:53:18 --> Input Class Initialized
INFO - 2018-03-26 22:53:18 --> Language Class Initialized
ERROR - 2018-03-26 22:53:18 --> 404 Page Not Found: Laporan/Laporan/Laporan
INFO - 2018-03-26 22:53:48 --> Config Class Initialized
INFO - 2018-03-26 22:53:48 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:53:48 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:53:48 --> Utf8 Class Initialized
INFO - 2018-03-26 22:53:48 --> URI Class Initialized
INFO - 2018-03-26 22:53:48 --> Router Class Initialized
INFO - 2018-03-26 22:53:48 --> Output Class Initialized
INFO - 2018-03-26 22:53:48 --> Security Class Initialized
DEBUG - 2018-03-26 22:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:53:48 --> Input Class Initialized
INFO - 2018-03-26 22:53:48 --> Language Class Initialized
INFO - 2018-03-26 22:53:48 --> Loader Class Initialized
INFO - 2018-03-26 22:53:48 --> Helper loaded: url_helper
INFO - 2018-03-26 22:53:48 --> Helper loaded: form_helper
INFO - 2018-03-26 22:53:48 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:53:48 --> Controller Class Initialized
INFO - 2018-03-26 22:53:48 --> Model Class Initialized
INFO - 2018-03-26 22:53:48 --> Model Class Initialized
INFO - 2018-03-26 22:53:48 --> Model Class Initialized
INFO - 2018-03-26 22:53:48 --> Model Class Initialized
INFO - 2018-03-26 22:53:48 --> Model Class Initialized
INFO - 2018-03-26 22:53:48 --> Model Class Initialized
INFO - 2018-03-26 22:53:48 --> Model Class Initialized
INFO - 2018-03-26 22:53:48 --> Model Class Initialized
INFO - 2018-03-26 22:53:48 --> Model Class Initialized
INFO - 2018-03-26 22:53:48 --> Model Class Initialized
INFO - 2018-03-26 22:53:48 --> Model Class Initialized
INFO - 2018-03-26 22:53:48 --> Model Class Initialized
INFO - 2018-03-26 22:53:48 --> Model Class Initialized
INFO - 2018-03-26 22:53:48 --> Model Class Initialized
INFO - 2018-03-26 22:53:48 --> Model Class Initialized
INFO - 2018-03-26 22:53:48 --> Helper loaded: date_helper
INFO - 2018-03-26 22:53:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:53:53 --> Config Class Initialized
INFO - 2018-03-26 22:53:53 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:53:53 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:53:53 --> Utf8 Class Initialized
INFO - 2018-03-26 22:53:53 --> URI Class Initialized
INFO - 2018-03-26 22:53:53 --> Router Class Initialized
INFO - 2018-03-26 22:53:53 --> Output Class Initialized
INFO - 2018-03-26 22:53:53 --> Security Class Initialized
DEBUG - 2018-03-26 22:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:53:53 --> Input Class Initialized
INFO - 2018-03-26 22:53:53 --> Language Class Initialized
INFO - 2018-03-26 22:53:53 --> Loader Class Initialized
INFO - 2018-03-26 22:53:53 --> Helper loaded: url_helper
INFO - 2018-03-26 22:53:53 --> Helper loaded: form_helper
INFO - 2018-03-26 22:53:53 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:53:53 --> Controller Class Initialized
INFO - 2018-03-26 22:53:53 --> Model Class Initialized
INFO - 2018-03-26 22:53:53 --> Model Class Initialized
INFO - 2018-03-26 22:53:53 --> Model Class Initialized
INFO - 2018-03-26 22:53:53 --> Model Class Initialized
INFO - 2018-03-26 22:53:53 --> Model Class Initialized
INFO - 2018-03-26 22:53:53 --> Model Class Initialized
INFO - 2018-03-26 22:53:53 --> Model Class Initialized
INFO - 2018-03-26 22:53:53 --> Model Class Initialized
INFO - 2018-03-26 22:53:53 --> Model Class Initialized
INFO - 2018-03-26 22:53:53 --> Model Class Initialized
INFO - 2018-03-26 22:53:53 --> Model Class Initialized
INFO - 2018-03-26 22:53:53 --> Model Class Initialized
INFO - 2018-03-26 22:53:53 --> Model Class Initialized
INFO - 2018-03-26 22:53:53 --> Model Class Initialized
INFO - 2018-03-26 22:53:53 --> Model Class Initialized
INFO - 2018-03-26 22:53:53 --> Helper loaded: date_helper
INFO - 2018-03-26 22:53:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:53:54 --> Config Class Initialized
INFO - 2018-03-26 22:53:54 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:53:54 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:53:54 --> Utf8 Class Initialized
INFO - 2018-03-26 22:53:54 --> URI Class Initialized
INFO - 2018-03-26 22:53:54 --> Router Class Initialized
INFO - 2018-03-26 22:53:54 --> Output Class Initialized
INFO - 2018-03-26 22:53:54 --> Security Class Initialized
DEBUG - 2018-03-26 22:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:53:54 --> Input Class Initialized
INFO - 2018-03-26 22:53:54 --> Language Class Initialized
ERROR - 2018-03-26 22:53:54 --> 404 Page Not Found: Laporan/Laporan/listLaporanPenjualanPrint
INFO - 2018-03-26 22:54:01 --> Config Class Initialized
INFO - 2018-03-26 22:54:01 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:54:01 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:54:01 --> Utf8 Class Initialized
INFO - 2018-03-26 22:54:01 --> URI Class Initialized
INFO - 2018-03-26 22:54:01 --> Router Class Initialized
INFO - 2018-03-26 22:54:01 --> Output Class Initialized
INFO - 2018-03-26 22:54:01 --> Security Class Initialized
DEBUG - 2018-03-26 22:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:54:01 --> Input Class Initialized
INFO - 2018-03-26 22:54:01 --> Language Class Initialized
INFO - 2018-03-26 22:54:01 --> Loader Class Initialized
INFO - 2018-03-26 22:54:01 --> Helper loaded: url_helper
INFO - 2018-03-26 22:54:01 --> Helper loaded: form_helper
INFO - 2018-03-26 22:54:01 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:54:01 --> Controller Class Initialized
INFO - 2018-03-26 22:54:01 --> Model Class Initialized
INFO - 2018-03-26 22:54:01 --> Model Class Initialized
INFO - 2018-03-26 22:54:01 --> Model Class Initialized
INFO - 2018-03-26 22:54:01 --> Model Class Initialized
INFO - 2018-03-26 22:54:01 --> Model Class Initialized
INFO - 2018-03-26 22:54:01 --> Model Class Initialized
INFO - 2018-03-26 22:54:01 --> Model Class Initialized
INFO - 2018-03-26 22:54:01 --> Model Class Initialized
INFO - 2018-03-26 22:54:01 --> Model Class Initialized
INFO - 2018-03-26 22:54:01 --> Model Class Initialized
INFO - 2018-03-26 22:54:01 --> Model Class Initialized
INFO - 2018-03-26 22:54:01 --> Model Class Initialized
INFO - 2018-03-26 22:54:01 --> Model Class Initialized
INFO - 2018-03-26 22:54:01 --> Model Class Initialized
INFO - 2018-03-26 22:54:01 --> Model Class Initialized
INFO - 2018-03-26 22:54:01 --> Helper loaded: date_helper
INFO - 2018-03-26 22:54:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:54:58 --> Config Class Initialized
INFO - 2018-03-26 22:54:58 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:54:58 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:54:58 --> Utf8 Class Initialized
INFO - 2018-03-26 22:54:58 --> URI Class Initialized
INFO - 2018-03-26 22:54:58 --> Router Class Initialized
INFO - 2018-03-26 22:54:58 --> Output Class Initialized
INFO - 2018-03-26 22:54:58 --> Security Class Initialized
DEBUG - 2018-03-26 22:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:54:58 --> Input Class Initialized
INFO - 2018-03-26 22:54:58 --> Language Class Initialized
INFO - 2018-03-26 22:54:58 --> Loader Class Initialized
INFO - 2018-03-26 22:54:58 --> Helper loaded: url_helper
INFO - 2018-03-26 22:54:58 --> Helper loaded: form_helper
INFO - 2018-03-26 22:54:58 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:54:58 --> Controller Class Initialized
INFO - 2018-03-26 22:54:58 --> Model Class Initialized
INFO - 2018-03-26 22:54:58 --> Model Class Initialized
INFO - 2018-03-26 22:54:58 --> Model Class Initialized
INFO - 2018-03-26 22:54:58 --> Model Class Initialized
INFO - 2018-03-26 22:54:58 --> Model Class Initialized
INFO - 2018-03-26 22:54:58 --> Model Class Initialized
INFO - 2018-03-26 22:54:58 --> Model Class Initialized
INFO - 2018-03-26 22:54:58 --> Model Class Initialized
INFO - 2018-03-26 22:54:58 --> Model Class Initialized
INFO - 2018-03-26 22:54:58 --> Model Class Initialized
INFO - 2018-03-26 22:54:58 --> Model Class Initialized
INFO - 2018-03-26 22:54:58 --> Model Class Initialized
INFO - 2018-03-26 22:54:58 --> Model Class Initialized
INFO - 2018-03-26 22:54:58 --> Model Class Initialized
INFO - 2018-03-26 22:54:58 --> Model Class Initialized
INFO - 2018-03-26 22:54:58 --> Helper loaded: date_helper
INFO - 2018-03-26 22:54:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-26 22:55:03 --> Config Class Initialized
INFO - 2018-03-26 22:55:03 --> Hooks Class Initialized
DEBUG - 2018-03-26 22:55:03 --> UTF-8 Support Enabled
INFO - 2018-03-26 22:55:03 --> Utf8 Class Initialized
INFO - 2018-03-26 22:55:03 --> URI Class Initialized
INFO - 2018-03-26 22:55:03 --> Router Class Initialized
INFO - 2018-03-26 22:55:03 --> Output Class Initialized
INFO - 2018-03-26 22:55:03 --> Security Class Initialized
DEBUG - 2018-03-26 22:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-26 22:55:03 --> Input Class Initialized
INFO - 2018-03-26 22:55:03 --> Language Class Initialized
INFO - 2018-03-26 22:55:03 --> Loader Class Initialized
INFO - 2018-03-26 22:55:03 --> Helper loaded: url_helper
INFO - 2018-03-26 22:55:03 --> Helper loaded: form_helper
INFO - 2018-03-26 22:55:03 --> Database Driver Class Initialized
DEBUG - 2018-03-26 22:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-26 22:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-26 22:55:03 --> Controller Class Initialized
INFO - 2018-03-26 22:55:03 --> Model Class Initialized
INFO - 2018-03-26 22:55:03 --> Model Class Initialized
INFO - 2018-03-26 22:55:03 --> Model Class Initialized
INFO - 2018-03-26 22:55:03 --> Model Class Initialized
INFO - 2018-03-26 22:55:03 --> Model Class Initialized
INFO - 2018-03-26 22:55:03 --> Model Class Initialized
INFO - 2018-03-26 22:55:03 --> Model Class Initialized
INFO - 2018-03-26 22:55:03 --> Model Class Initialized
INFO - 2018-03-26 22:55:03 --> Model Class Initialized
INFO - 2018-03-26 22:55:03 --> Model Class Initialized
INFO - 2018-03-26 22:55:03 --> Model Class Initialized
INFO - 2018-03-26 22:55:03 --> Model Class Initialized
INFO - 2018-03-26 22:55:03 --> Model Class Initialized
INFO - 2018-03-26 22:55:03 --> Model Class Initialized
INFO - 2018-03-26 22:55:03 --> Model Class Initialized
INFO - 2018-03-26 22:55:03 --> Helper loaded: date_helper
INFO - 2018-03-26 22:55:03 --> Helper loaded: tanggal_helper
