<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-27 00:32:06 --> Model Class Initialized
INFO - 2018-03-27 00:32:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 00:32:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 00:32:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-27 00:32:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 00:32:06 --> Final output sent to browser
DEBUG - 2018-03-27 00:32:06 --> Total execution time: 0.2969
INFO - 2018-03-27 00:32:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/list.php
INFO - 2018-03-27 00:32:37 --> Final output sent to browser
DEBUG - 2018-03-27 00:32:37 --> Total execution time: 0.1092
INFO - 2018-03-27 00:32:39 --> Model Class Initialized
INFO - 2018-03-27 00:32:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 00:32:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 00:32:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 00:32:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 00:32:39 --> Final output sent to browser
DEBUG - 2018-03-27 00:32:39 --> Total execution time: 0.1514
INFO - 2018-03-27 01:06:41 --> Model Class Initialized
INFO - 2018-03-27 01:06:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:06:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:06:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:06:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:06:42 --> Final output sent to browser
DEBUG - 2018-03-27 01:06:42 --> Total execution time: 2.0226
INFO - 2018-03-27 01:06:52 --> Model Class Initialized
INFO - 2018-03-27 01:06:52 --> Model Class Initialized
INFO - 2018-03-27 01:06:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:06:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:06:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/table.php
INFO - 2018-03-27 01:06:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:06:52 --> Final output sent to browser
DEBUG - 2018-03-27 01:06:52 --> Total execution time: 0.3213
INFO - 2018-03-27 01:13:31 --> Model Class Initialized
INFO - 2018-03-27 01:13:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:13:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:13:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-27 01:13:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:13:31 --> Final output sent to browser
DEBUG - 2018-03-27 01:13:31 --> Total execution time: 0.1896
INFO - 2018-03-27 01:13:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/list.php
INFO - 2018-03-27 01:13:34 --> Final output sent to browser
DEBUG - 2018-03-27 01:13:34 --> Total execution time: 0.0843
INFO - 2018-03-27 01:13:35 --> Model Class Initialized
INFO - 2018-03-27 01:13:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:13:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:13:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:13:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:13:35 --> Final output sent to browser
DEBUG - 2018-03-27 01:13:35 --> Total execution time: 0.1022
INFO - 2018-03-27 01:14:22 --> Model Class Initialized
INFO - 2018-03-27 01:14:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:14:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:14:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-27 01:14:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:14:22 --> Final output sent to browser
DEBUG - 2018-03-27 01:14:22 --> Total execution time: 0.2304
INFO - 2018-03-27 01:14:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-27 01:14:26 --> Final output sent to browser
DEBUG - 2018-03-27 01:14:26 --> Total execution time: 0.1315
INFO - 2018-03-27 01:14:28 --> Model Class Initialized
INFO - 2018-03-27 01:14:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:14:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:14:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-27 01:14:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:14:28 --> Final output sent to browser
DEBUG - 2018-03-27 01:14:28 --> Total execution time: 0.3216
INFO - 2018-03-27 01:14:45 --> Model Class Initialized
INFO - 2018-03-27 01:14:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:14:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:14:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-27 01:14:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:14:45 --> Final output sent to browser
DEBUG - 2018-03-27 01:14:45 --> Total execution time: 0.0927
INFO - 2018-03-27 01:14:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/list.php
INFO - 2018-03-27 01:14:47 --> Final output sent to browser
DEBUG - 2018-03-27 01:14:47 --> Total execution time: 0.0848
INFO - 2018-03-27 01:14:49 --> Model Class Initialized
INFO - 2018-03-27 01:14:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:14:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:14:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:14:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:14:49 --> Final output sent to browser
DEBUG - 2018-03-27 01:14:49 --> Total execution time: 0.0931
INFO - 2018-03-27 01:16:27 --> Model Class Initialized
INFO - 2018-03-27 01:16:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:16:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:16:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-27 01:16:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:16:27 --> Final output sent to browser
DEBUG - 2018-03-27 01:16:27 --> Total execution time: 0.0946
INFO - 2018-03-27 01:16:30 --> Model Class Initialized
INFO - 2018-03-27 01:16:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:16:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:16:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/create.php
INFO - 2018-03-27 01:16:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:16:30 --> Final output sent to browser
DEBUG - 2018-03-27 01:16:30 --> Total execution time: 0.1365
INFO - 2018-03-27 01:17:02 --> Model Class Initialized
INFO - 2018-03-27 01:17:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:17:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:17:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-27 01:17:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:17:02 --> Final output sent to browser
DEBUG - 2018-03-27 01:17:02 --> Total execution time: 0.1005
INFO - 2018-03-27 01:17:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/list.php
INFO - 2018-03-27 01:17:06 --> Final output sent to browser
DEBUG - 2018-03-27 01:17:06 --> Total execution time: 0.0780
INFO - 2018-03-27 01:17:08 --> Model Class Initialized
INFO - 2018-03-27 01:17:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:17:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:17:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:17:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:17:08 --> Final output sent to browser
DEBUG - 2018-03-27 01:17:08 --> Total execution time: 0.0974
INFO - 2018-03-27 01:17:59 --> Model Class Initialized
INFO - 2018-03-27 01:17:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:17:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:17:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:17:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:17:59 --> Final output sent to browser
DEBUG - 2018-03-27 01:17:59 --> Total execution time: 0.0976
INFO - 2018-03-27 01:24:17 --> Model Class Initialized
INFO - 2018-03-27 01:24:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:24:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:24:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:24:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:24:17 --> Final output sent to browser
DEBUG - 2018-03-27 01:24:17 --> Total execution time: 0.0757
INFO - 2018-03-27 01:24:36 --> Model Class Initialized
INFO - 2018-03-27 01:24:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:24:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:24:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:24:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:24:36 --> Final output sent to browser
DEBUG - 2018-03-27 01:24:36 --> Total execution time: 0.0960
INFO - 2018-03-27 01:25:21 --> Model Class Initialized
INFO - 2018-03-27 01:25:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:25:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:25:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:25:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:25:21 --> Final output sent to browser
DEBUG - 2018-03-27 01:25:21 --> Total execution time: 0.0952
INFO - 2018-03-27 01:25:40 --> Model Class Initialized
INFO - 2018-03-27 01:25:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:25:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:25:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:25:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:25:40 --> Final output sent to browser
DEBUG - 2018-03-27 01:25:40 --> Total execution time: 0.1025
INFO - 2018-03-27 01:26:16 --> Model Class Initialized
INFO - 2018-03-27 01:26:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:26:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:26:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:26:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:26:16 --> Final output sent to browser
DEBUG - 2018-03-27 01:26:16 --> Total execution time: 0.0920
INFO - 2018-03-27 01:26:26 --> Model Class Initialized
INFO - 2018-03-27 01:26:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:26:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:26:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-27 01:26:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:26:26 --> Final output sent to browser
DEBUG - 2018-03-27 01:26:26 --> Total execution time: 0.1335
INFO - 2018-03-27 01:26:30 --> Model Class Initialized
INFO - 2018-03-27 01:26:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:26:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:26:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-27 01:26:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:26:30 --> Final output sent to browser
DEBUG - 2018-03-27 01:26:30 --> Total execution time: 0.0912
INFO - 2018-03-27 01:26:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/list.php
INFO - 2018-03-27 01:26:33 --> Final output sent to browser
DEBUG - 2018-03-27 01:26:33 --> Total execution time: 0.0695
INFO - 2018-03-27 01:26:40 --> Model Class Initialized
INFO - 2018-03-27 01:26:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:26:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:26:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-27 01:26:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:26:40 --> Final output sent to browser
DEBUG - 2018-03-27 01:26:40 --> Total execution time: 0.0901
INFO - 2018-03-27 01:26:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/list.php
INFO - 2018-03-27 01:26:44 --> Final output sent to browser
DEBUG - 2018-03-27 01:26:44 --> Total execution time: 0.0717
INFO - 2018-03-27 01:26:45 --> Model Class Initialized
INFO - 2018-03-27 01:26:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:26:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:26:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:26:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:26:45 --> Final output sent to browser
DEBUG - 2018-03-27 01:26:45 --> Total execution time: 0.1058
INFO - 2018-03-27 01:27:13 --> Model Class Initialized
INFO - 2018-03-27 01:27:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:27:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:27:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-27 01:27:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:27:13 --> Final output sent to browser
DEBUG - 2018-03-27 01:27:13 --> Total execution time: 0.2501
INFO - 2018-03-27 01:27:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-27 01:27:17 --> Final output sent to browser
DEBUG - 2018-03-27 01:27:17 --> Total execution time: 0.1102
INFO - 2018-03-27 01:27:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-27 01:27:20 --> Final output sent to browser
DEBUG - 2018-03-27 01:27:20 --> Total execution time: 0.0784
INFO - 2018-03-27 01:27:31 --> Model Class Initialized
INFO - 2018-03-27 01:27:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:27:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:27:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-27 01:27:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:27:31 --> Final output sent to browser
DEBUG - 2018-03-27 01:27:31 --> Total execution time: 0.1892
INFO - 2018-03-27 01:28:04 --> Model Class Initialized
INFO - 2018-03-27 01:28:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:28:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:28:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:28:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:28:04 --> Final output sent to browser
DEBUG - 2018-03-27 01:28:04 --> Total execution time: 0.0959
INFO - 2018-03-27 01:28:59 --> Model Class Initialized
INFO - 2018-03-27 01:28:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:28:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:28:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:28:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:28:59 --> Final output sent to browser
DEBUG - 2018-03-27 01:28:59 --> Total execution time: 0.0909
INFO - 2018-03-27 01:29:11 --> Model Class Initialized
INFO - 2018-03-27 01:29:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:29:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:29:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:29:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:29:11 --> Final output sent to browser
DEBUG - 2018-03-27 01:29:11 --> Total execution time: 0.0875
INFO - 2018-03-27 01:30:31 --> Model Class Initialized
INFO - 2018-03-27 01:30:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:30:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:30:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:30:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:30:31 --> Final output sent to browser
DEBUG - 2018-03-27 01:30:31 --> Total execution time: 0.0959
INFO - 2018-03-27 01:31:08 --> Model Class Initialized
INFO - 2018-03-27 01:31:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:31:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:31:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:31:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:31:08 --> Final output sent to browser
DEBUG - 2018-03-27 01:31:08 --> Total execution time: 0.0950
INFO - 2018-03-27 01:33:40 --> Model Class Initialized
INFO - 2018-03-27 01:33:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:33:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:33:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-27 01:33:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:33:40 --> Final output sent to browser
DEBUG - 2018-03-27 01:33:40 --> Total execution time: 0.1962
INFO - 2018-03-27 01:33:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/list.php
INFO - 2018-03-27 01:33:49 --> Final output sent to browser
DEBUG - 2018-03-27 01:33:49 --> Total execution time: 0.1924
INFO - 2018-03-27 01:33:50 --> Model Class Initialized
INFO - 2018-03-27 01:33:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:33:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:33:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/detail.php
INFO - 2018-03-27 01:33:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:33:50 --> Final output sent to browser
DEBUG - 2018-03-27 01:33:50 --> Total execution time: 0.1687
INFO - 2018-03-27 01:33:55 --> Model Class Initialized
INFO - 2018-03-27 01:33:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:33:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:33:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-27 01:33:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:33:55 --> Final output sent to browser
DEBUG - 2018-03-27 01:33:55 --> Total execution time: 0.0847
INFO - 2018-03-27 01:37:35 --> Model Class Initialized
INFO - 2018-03-27 01:37:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:37:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:37:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:37:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:37:35 --> Final output sent to browser
DEBUG - 2018-03-27 01:37:35 --> Total execution time: 0.1061
INFO - 2018-03-27 01:38:34 --> Model Class Initialized
INFO - 2018-03-27 01:38:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:38:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:38:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:38:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:38:34 --> Final output sent to browser
DEBUG - 2018-03-27 01:38:34 --> Total execution time: 0.1023
INFO - 2018-03-27 01:39:14 --> Model Class Initialized
INFO - 2018-03-27 01:39:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:39:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:39:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:39:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:39:14 --> Final output sent to browser
DEBUG - 2018-03-27 01:39:14 --> Total execution time: 0.0934
INFO - 2018-03-27 01:39:38 --> Model Class Initialized
INFO - 2018-03-27 01:39:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:39:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:39:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:39:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:39:38 --> Final output sent to browser
DEBUG - 2018-03-27 01:39:38 --> Total execution time: 0.0948
INFO - 2018-03-27 01:39:40 --> Model Class Initialized
INFO - 2018-03-27 01:39:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:39:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:39:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:39:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:39:40 --> Final output sent to browser
DEBUG - 2018-03-27 01:39:40 --> Total execution time: 0.1131
ERROR - 2018-03-27 01:40:19 --> Severity: error --> Exception: Call to a member function getByIdDetail() on null E:\xampp\htdocs\skin_care\application\controllers\Kasir\Tpenjualan.php 45
INFO - 2018-03-27 01:40:52 --> Model Class Initialized
INFO - 2018-03-27 01:40:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:40:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:40:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:40:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:40:52 --> Final output sent to browser
DEBUG - 2018-03-27 01:40:52 --> Total execution time: 0.1017
INFO - 2018-03-27 01:41:29 --> Model Class Initialized
INFO - 2018-03-27 01:41:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:41:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:41:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:41:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:41:29 --> Final output sent to browser
DEBUG - 2018-03-27 01:41:29 --> Total execution time: 0.1032
INFO - 2018-03-27 01:44:26 --> Model Class Initialized
INFO - 2018-03-27 01:44:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:44:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:44:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:44:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:44:26 --> Final output sent to browser
DEBUG - 2018-03-27 01:44:26 --> Total execution time: 0.1155
INFO - 2018-03-27 01:44:33 --> Model Class Initialized
INFO - 2018-03-27 01:44:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:44:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:44:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:44:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:44:33 --> Final output sent to browser
DEBUG - 2018-03-27 01:44:33 --> Total execution time: 0.0998
INFO - 2018-03-27 01:47:20 --> Model Class Initialized
INFO - 2018-03-27 01:47:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:47:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:47:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:47:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:47:20 --> Final output sent to browser
DEBUG - 2018-03-27 01:47:20 --> Total execution time: 0.0953
INFO - 2018-03-27 01:48:30 --> Model Class Initialized
INFO - 2018-03-27 01:48:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:48:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:48:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:48:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:48:30 --> Final output sent to browser
DEBUG - 2018-03-27 01:48:30 --> Total execution time: 0.1103
INFO - 2018-03-27 01:49:21 --> Model Class Initialized
INFO - 2018-03-27 01:49:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:49:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:49:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:49:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:49:21 --> Final output sent to browser
DEBUG - 2018-03-27 01:49:21 --> Total execution time: 0.1000
INFO - 2018-03-27 01:49:26 --> Model Class Initialized
INFO - 2018-03-27 01:49:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:49:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:49:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:49:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:49:26 --> Final output sent to browser
DEBUG - 2018-03-27 01:49:26 --> Total execution time: 0.0968
INFO - 2018-03-27 01:49:31 --> Model Class Initialized
INFO - 2018-03-27 01:49:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:49:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:49:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:49:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:49:31 --> Final output sent to browser
DEBUG - 2018-03-27 01:49:31 --> Total execution time: 0.1155
INFO - 2018-03-27 01:50:09 --> Model Class Initialized
INFO - 2018-03-27 01:50:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:50:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:50:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:50:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:50:09 --> Final output sent to browser
DEBUG - 2018-03-27 01:50:09 --> Total execution time: 0.1001
INFO - 2018-03-27 01:50:35 --> Model Class Initialized
INFO - 2018-03-27 01:50:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:50:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:50:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:50:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:50:35 --> Final output sent to browser
DEBUG - 2018-03-27 01:50:35 --> Total execution time: 0.0944
INFO - 2018-03-27 01:50:40 --> Model Class Initialized
INFO - 2018-03-27 01:50:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:50:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:50:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:50:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:50:40 --> Final output sent to browser
DEBUG - 2018-03-27 01:50:40 --> Total execution time: 0.0962
INFO - 2018-03-27 01:51:05 --> Model Class Initialized
INFO - 2018-03-27 01:51:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:51:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:51:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:51:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:51:05 --> Final output sent to browser
DEBUG - 2018-03-27 01:51:05 --> Total execution time: 0.0834
INFO - 2018-03-27 01:52:37 --> Model Class Initialized
INFO - 2018-03-27 01:52:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:52:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:52:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:52:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:52:37 --> Final output sent to browser
DEBUG - 2018-03-27 01:52:37 --> Total execution time: 0.0956
INFO - 2018-03-27 01:52:59 --> Model Class Initialized
INFO - 2018-03-27 01:52:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:52:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:52:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:52:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:52:59 --> Final output sent to browser
DEBUG - 2018-03-27 01:52:59 --> Total execution time: 0.0936
INFO - 2018-03-27 01:53:29 --> Model Class Initialized
INFO - 2018-03-27 01:53:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:53:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:53:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-27 01:53:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:53:29 --> Final output sent to browser
DEBUG - 2018-03-27 01:53:29 --> Total execution time: 0.0919
INFO - 2018-03-27 01:53:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/list.php
INFO - 2018-03-27 01:53:33 --> Final output sent to browser
DEBUG - 2018-03-27 01:53:33 --> Total execution time: 0.0702
INFO - 2018-03-27 01:53:34 --> Model Class Initialized
INFO - 2018-03-27 01:53:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:53:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:53:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:53:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:53:34 --> Final output sent to browser
DEBUG - 2018-03-27 01:53:34 --> Total execution time: 0.1008
INFO - 2018-03-27 01:55:24 --> Model Class Initialized
INFO - 2018-03-27 01:55:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:55:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:55:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:55:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:55:24 --> Final output sent to browser
DEBUG - 2018-03-27 01:55:24 --> Total execution time: 0.1051
INFO - 2018-03-27 01:55:44 --> Model Class Initialized
INFO - 2018-03-27 01:55:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:55:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:55:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:55:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:55:44 --> Final output sent to browser
DEBUG - 2018-03-27 01:55:44 --> Total execution time: 0.1412
INFO - 2018-03-27 01:56:04 --> Model Class Initialized
INFO - 2018-03-27 01:56:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:56:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:56:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:56:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:56:04 --> Final output sent to browser
DEBUG - 2018-03-27 01:56:04 --> Total execution time: 0.0941
INFO - 2018-03-27 01:56:59 --> Model Class Initialized
INFO - 2018-03-27 01:56:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:56:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:56:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-27 01:56:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:56:59 --> Final output sent to browser
DEBUG - 2018-03-27 01:56:59 --> Total execution time: 0.0927
INFO - 2018-03-27 01:57:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-27 01:57:02 --> Final output sent to browser
DEBUG - 2018-03-27 01:57:02 --> Total execution time: 0.0903
INFO - 2018-03-27 01:57:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/list.php
INFO - 2018-03-27 01:57:04 --> Final output sent to browser
DEBUG - 2018-03-27 01:57:04 --> Total execution time: 0.0876
INFO - 2018-03-27 01:57:07 --> Model Class Initialized
INFO - 2018-03-27 01:57:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:57:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:57:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-27 01:57:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:57:07 --> Final output sent to browser
DEBUG - 2018-03-27 01:57:07 --> Total execution time: 0.1039
INFO - 2018-03-27 01:58:50 --> Model Class Initialized
INFO - 2018-03-27 01:58:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:58:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:58:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:58:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:58:50 --> Final output sent to browser
DEBUG - 2018-03-27 01:58:50 --> Total execution time: 0.0971
INFO - 2018-03-27 01:58:54 --> Model Class Initialized
INFO - 2018-03-27 01:58:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 01:58:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 01:58:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 01:58:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 01:58:54 --> Final output sent to browser
DEBUG - 2018-03-27 01:58:54 --> Total execution time: 0.1096
INFO - 2018-03-27 02:06:33 --> Model Class Initialized
INFO - 2018-03-27 02:06:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:06:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:06:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 02:06:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:06:33 --> Final output sent to browser
DEBUG - 2018-03-27 02:06:33 --> Total execution time: 0.1127
INFO - 2018-03-27 02:06:51 --> Final output sent to browser
DEBUG - 2018-03-27 02:06:51 --> Total execution time: 0.2352
INFO - 2018-03-27 02:08:03 --> Model Class Initialized
INFO - 2018-03-27 02:08:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:08:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:08:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 02:08:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:08:03 --> Final output sent to browser
DEBUG - 2018-03-27 02:08:03 --> Total execution time: 0.1178
INFO - 2018-03-27 02:08:29 --> Model Class Initialized
INFO - 2018-03-27 02:08:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:08:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:08:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 02:08:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:08:29 --> Final output sent to browser
DEBUG - 2018-03-27 02:08:29 --> Total execution time: 0.1230
INFO - 2018-03-27 02:08:39 --> Model Class Initialized
INFO - 2018-03-27 02:08:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:08:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:08:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 02:08:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:08:39 --> Final output sent to browser
DEBUG - 2018-03-27 02:08:39 --> Total execution time: 0.1268
INFO - 2018-03-27 02:08:48 --> Final output sent to browser
DEBUG - 2018-03-27 02:08:48 --> Total execution time: 0.2082
INFO - 2018-03-27 02:09:24 --> Model Class Initialized
INFO - 2018-03-27 02:09:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:09:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:09:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 02:09:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:09:24 --> Final output sent to browser
DEBUG - 2018-03-27 02:09:24 --> Total execution time: 0.1204
INFO - 2018-03-27 02:11:19 --> Model Class Initialized
INFO - 2018-03-27 02:11:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:11:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:11:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/detail.php
INFO - 2018-03-27 02:11:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:11:19 --> Final output sent to browser
DEBUG - 2018-03-27 02:11:19 --> Total execution time: 0.1116
INFO - 2018-03-27 02:11:29 --> Model Class Initialized
INFO - 2018-03-27 02:11:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:11:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:11:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-27 02:11:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:11:29 --> Final output sent to browser
DEBUG - 2018-03-27 02:11:29 --> Total execution time: 0.1291
INFO - 2018-03-27 02:11:35 --> Model Class Initialized
INFO - 2018-03-27 02:11:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:11:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:11:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-27 02:11:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:11:35 --> Final output sent to browser
DEBUG - 2018-03-27 02:11:35 --> Total execution time: 0.0860
INFO - 2018-03-27 02:11:43 --> Model Class Initialized
INFO - 2018-03-27 02:11:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:11:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:11:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-27 02:11:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:11:43 --> Final output sent to browser
DEBUG - 2018-03-27 02:11:43 --> Total execution time: 0.0869
INFO - 2018-03-27 02:11:47 --> Model Class Initialized
INFO - 2018-03-27 02:11:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:11:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:11:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-27 02:11:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:11:47 --> Final output sent to browser
DEBUG - 2018-03-27 02:11:47 --> Total execution time: 0.0977
INFO - 2018-03-27 02:11:49 --> Model Class Initialized
INFO - 2018-03-27 02:11:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:11:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:11:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-27 02:11:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:11:49 --> Final output sent to browser
DEBUG - 2018-03-27 02:11:49 --> Total execution time: 0.0936
INFO - 2018-03-27 02:11:54 --> Model Class Initialized
INFO - 2018-03-27 02:11:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:11:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:11:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-27 02:11:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:11:54 --> Final output sent to browser
DEBUG - 2018-03-27 02:11:54 --> Total execution time: 0.0943
INFO - 2018-03-27 02:12:16 --> Model Class Initialized
INFO - 2018-03-27 02:12:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:12:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:12:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-27 02:12:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:12:16 --> Final output sent to browser
DEBUG - 2018-03-27 02:12:16 --> Total execution time: 0.0944
INFO - 2018-03-27 02:12:37 --> Model Class Initialized
INFO - 2018-03-27 02:12:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:12:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:12:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-27 02:12:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:12:37 --> Final output sent to browser
DEBUG - 2018-03-27 02:12:37 --> Total execution time: 0.0761
INFO - 2018-03-27 02:12:43 --> Model Class Initialized
INFO - 2018-03-27 02:12:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:12:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:12:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-27 02:12:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:12:43 --> Final output sent to browser
DEBUG - 2018-03-27 02:12:43 --> Total execution time: 0.1353
INFO - 2018-03-27 02:12:53 --> Model Class Initialized
INFO - 2018-03-27 02:12:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:12:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:12:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-27 02:12:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:12:53 --> Final output sent to browser
DEBUG - 2018-03-27 02:12:53 --> Total execution time: 0.0965
INFO - 2018-03-27 02:13:57 --> Model Class Initialized
INFO - 2018-03-27 02:13:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:13:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:13:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-27 02:13:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:13:57 --> Final output sent to browser
DEBUG - 2018-03-27 02:13:57 --> Total execution time: 0.1039
INFO - 2018-03-27 02:13:59 --> Model Class Initialized
INFO - 2018-03-27 02:13:59 --> Model Class Initialized
INFO - 2018-03-27 02:13:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:13:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:13:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/table.php
INFO - 2018-03-27 02:13:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:13:59 --> Final output sent to browser
DEBUG - 2018-03-27 02:13:59 --> Total execution time: 0.1530
INFO - 2018-03-27 02:14:01 --> Model Class Initialized
INFO - 2018-03-27 02:14:01 --> Model Class Initialized
INFO - 2018-03-27 02:14:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:14:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:14:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/update.php
INFO - 2018-03-27 02:14:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:14:01 --> Final output sent to browser
DEBUG - 2018-03-27 02:14:01 --> Total execution time: 0.2852
INFO - 2018-03-27 02:16:38 --> Model Class Initialized
INFO - 2018-03-27 02:16:38 --> Model Class Initialized
INFO - 2018-03-27 02:16:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:16:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:16:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/update.php
INFO - 2018-03-27 02:16:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:16:38 --> Final output sent to browser
DEBUG - 2018-03-27 02:16:38 --> Total execution time: 0.0828
INFO - 2018-03-27 02:16:40 --> Model Class Initialized
INFO - 2018-03-27 02:16:40 --> Model Class Initialized
INFO - 2018-03-27 02:16:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:16:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
ERROR - 2018-03-27 02:16:40 --> Severity: error --> Exception: Call to undefined function umur() E:\xampp\htdocs\skin_care\application\views\sdm\pegawai\profile.php 29
INFO - 2018-03-27 02:17:20 --> Model Class Initialized
INFO - 2018-03-27 02:17:20 --> Model Class Initialized
INFO - 2018-03-27 02:17:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:17:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:17:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:17:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:17:20 --> Final output sent to browser
DEBUG - 2018-03-27 02:17:20 --> Total execution time: 0.0926
INFO - 2018-03-27 02:20:09 --> Model Class Initialized
INFO - 2018-03-27 02:20:09 --> Model Class Initialized
INFO - 2018-03-27 02:20:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:20:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:20:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:20:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:20:09 --> Final output sent to browser
DEBUG - 2018-03-27 02:20:09 --> Total execution time: 0.0774
INFO - 2018-03-27 02:22:48 --> Model Class Initialized
INFO - 2018-03-27 02:22:48 --> Model Class Initialized
INFO - 2018-03-27 02:22:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:22:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:22:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:22:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:22:48 --> Final output sent to browser
DEBUG - 2018-03-27 02:22:48 --> Total execution time: 0.0853
INFO - 2018-03-27 02:24:33 --> Model Class Initialized
INFO - 2018-03-27 02:24:33 --> Model Class Initialized
INFO - 2018-03-27 02:24:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:24:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:24:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/table.php
INFO - 2018-03-27 02:24:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:24:33 --> Final output sent to browser
DEBUG - 2018-03-27 02:24:33 --> Total execution time: 0.1028
INFO - 2018-03-27 02:24:34 --> Model Class Initialized
INFO - 2018-03-27 02:24:34 --> Model Class Initialized
INFO - 2018-03-27 02:24:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:24:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:24:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/update.php
INFO - 2018-03-27 02:24:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:24:34 --> Final output sent to browser
DEBUG - 2018-03-27 02:24:34 --> Total execution time: 0.0758
INFO - 2018-03-27 02:24:36 --> Model Class Initialized
INFO - 2018-03-27 02:24:36 --> Model Class Initialized
INFO - 2018-03-27 02:24:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:24:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:24:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/table.php
INFO - 2018-03-27 02:24:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:24:36 --> Final output sent to browser
DEBUG - 2018-03-27 02:24:36 --> Total execution time: 0.0852
INFO - 2018-03-27 02:24:44 --> Model Class Initialized
INFO - 2018-03-27 02:24:44 --> Model Class Initialized
INFO - 2018-03-27 02:24:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:24:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:24:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/user/table.php
INFO - 2018-03-27 02:24:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:24:44 --> Final output sent to browser
DEBUG - 2018-03-27 02:24:44 --> Total execution time: 0.1260
INFO - 2018-03-27 02:25:03 --> Model Class Initialized
INFO - 2018-03-27 02:25:04 --> Model Class Initialized
INFO - 2018-03-27 02:25:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:25:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:25:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/user/update.php
INFO - 2018-03-27 02:25:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:25:04 --> Final output sent to browser
DEBUG - 2018-03-27 02:25:04 --> Total execution time: 0.2237
INFO - 2018-03-27 02:25:06 --> Model Class Initialized
INFO - 2018-03-27 02:25:06 --> Model Class Initialized
INFO - 2018-03-27 02:25:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:25:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:25:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/user/table.php
INFO - 2018-03-27 02:25:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:25:06 --> Final output sent to browser
DEBUG - 2018-03-27 02:25:06 --> Total execution time: 0.0834
INFO - 2018-03-27 02:27:25 --> Model Class Initialized
INFO - 2018-03-27 02:27:25 --> Model Class Initialized
INFO - 2018-03-27 02:27:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:27:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:27:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:27:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:27:25 --> Final output sent to browser
DEBUG - 2018-03-27 02:27:25 --> Total execution time: 0.0733
INFO - 2018-03-27 02:27:47 --> Model Class Initialized
INFO - 2018-03-27 02:27:47 --> Model Class Initialized
INFO - 2018-03-27 02:27:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:27:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:27:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:27:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:27:47 --> Final output sent to browser
DEBUG - 2018-03-27 02:27:47 --> Total execution time: 0.0814
INFO - 2018-03-27 02:31:28 --> Model Class Initialized
INFO - 2018-03-27 02:31:28 --> Model Class Initialized
INFO - 2018-03-27 02:31:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:31:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:31:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/user/update.php
INFO - 2018-03-27 02:31:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:31:28 --> Final output sent to browser
DEBUG - 2018-03-27 02:31:28 --> Total execution time: 0.0895
INFO - 2018-03-27 02:31:32 --> Model Class Initialized
INFO - 2018-03-27 02:31:32 --> Model Class Initialized
INFO - 2018-03-27 02:31:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:31:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:31:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/user/table.php
INFO - 2018-03-27 02:31:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:31:32 --> Final output sent to browser
DEBUG - 2018-03-27 02:31:32 --> Total execution time: 0.0728
INFO - 2018-03-27 02:31:34 --> Model Class Initialized
INFO - 2018-03-27 02:31:34 --> Model Class Initialized
INFO - 2018-03-27 02:31:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:31:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:31:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/user/update.php
INFO - 2018-03-27 02:31:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:31:34 --> Final output sent to browser
DEBUG - 2018-03-27 02:31:34 --> Total execution time: 0.0743
INFO - 2018-03-27 02:31:38 --> Model Class Initialized
INFO - 2018-03-27 02:31:38 --> Model Class Initialized
INFO - 2018-03-27 02:31:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:31:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:31:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/user/table.php
INFO - 2018-03-27 02:31:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:31:38 --> Final output sent to browser
DEBUG - 2018-03-27 02:31:38 --> Total execution time: 0.0796
INFO - 2018-03-27 02:37:08 --> Model Class Initialized
INFO - 2018-03-27 02:37:08 --> Model Class Initialized
INFO - 2018-03-27 02:37:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:37:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:37:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:37:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:37:08 --> Final output sent to browser
DEBUG - 2018-03-27 02:37:08 --> Total execution time: 0.0809
INFO - 2018-03-27 02:37:43 --> Model Class Initialized
INFO - 2018-03-27 02:37:43 --> Model Class Initialized
INFO - 2018-03-27 02:37:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:37:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:37:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:37:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:37:43 --> Final output sent to browser
DEBUG - 2018-03-27 02:37:43 --> Total execution time: 0.0771
INFO - 2018-03-27 02:39:08 --> Model Class Initialized
INFO - 2018-03-27 02:39:08 --> Model Class Initialized
INFO - 2018-03-27 02:39:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:39:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:39:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:39:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:39:08 --> Final output sent to browser
DEBUG - 2018-03-27 02:39:08 --> Total execution time: 0.0935
INFO - 2018-03-27 02:41:00 --> Model Class Initialized
INFO - 2018-03-27 02:41:01 --> Model Class Initialized
INFO - 2018-03-27 02:41:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:41:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:41:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:41:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:41:01 --> Final output sent to browser
DEBUG - 2018-03-27 02:41:01 --> Total execution time: 0.0895
INFO - 2018-03-27 02:41:17 --> Model Class Initialized
INFO - 2018-03-27 02:41:17 --> Model Class Initialized
INFO - 2018-03-27 02:41:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:41:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:41:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:41:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:41:17 --> Final output sent to browser
DEBUG - 2018-03-27 02:41:17 --> Total execution time: 0.1159
INFO - 2018-03-27 02:42:13 --> Model Class Initialized
INFO - 2018-03-27 02:42:13 --> Model Class Initialized
INFO - 2018-03-27 02:42:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:42:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:42:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:42:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:42:13 --> Final output sent to browser
DEBUG - 2018-03-27 02:42:13 --> Total execution time: 0.1062
INFO - 2018-03-27 02:42:32 --> Model Class Initialized
INFO - 2018-03-27 02:42:32 --> Model Class Initialized
INFO - 2018-03-27 02:42:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:42:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:42:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:42:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:42:32 --> Final output sent to browser
DEBUG - 2018-03-27 02:42:32 --> Total execution time: 0.1095
INFO - 2018-03-27 02:42:41 --> Model Class Initialized
INFO - 2018-03-27 02:42:41 --> Model Class Initialized
INFO - 2018-03-27 02:42:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:42:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:42:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:42:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:42:41 --> Final output sent to browser
DEBUG - 2018-03-27 02:42:41 --> Total execution time: 0.0818
INFO - 2018-03-27 02:43:04 --> Model Class Initialized
INFO - 2018-03-27 02:43:04 --> Model Class Initialized
INFO - 2018-03-27 02:43:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:43:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:43:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:43:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:43:04 --> Final output sent to browser
DEBUG - 2018-03-27 02:43:04 --> Total execution time: 0.0987
INFO - 2018-03-27 02:43:32 --> Model Class Initialized
INFO - 2018-03-27 02:43:32 --> Model Class Initialized
INFO - 2018-03-27 02:43:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:43:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:43:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:43:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:43:32 --> Final output sent to browser
DEBUG - 2018-03-27 02:43:32 --> Total execution time: 0.0888
ERROR - 2018-03-27 02:43:39 --> Query error: Unknown column 'to' in 'field list' - Invalid query: UPDATE `user_login` SET `id_user` = '1', `to` = 'profile/1', `password` = '$2y$10$iUeYh3e9dlGTZ0oBKVHqouqsV/944BrJysq7RUKvbQ12X7YhMWMcS'
WHERE `id_user` = '1'
DEBUG - 2018-03-27 02:43:39 --> DB Transaction Failure
INFO - 2018-03-27 02:43:40 --> Model Class Initialized
INFO - 2018-03-27 02:43:40 --> Model Class Initialized
INFO - 2018-03-27 02:43:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:43:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:43:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:43:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:43:40 --> Final output sent to browser
DEBUG - 2018-03-27 02:43:40 --> Total execution time: 0.0976
INFO - 2018-03-27 02:43:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-27 02:43:53 --> Final output sent to browser
DEBUG - 2018-03-27 02:43:53 --> Total execution time: 0.1108
INFO - 2018-03-27 02:43:56 --> Model Class Initialized
INFO - 2018-03-27 02:43:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:43:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:43:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-27 02:43:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:43:56 --> Final output sent to browser
DEBUG - 2018-03-27 02:43:56 --> Total execution time: 0.0926
INFO - 2018-03-27 02:44:07 --> Model Class Initialized
INFO - 2018-03-27 02:44:07 --> Model Class Initialized
INFO - 2018-03-27 02:44:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:44:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:44:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:44:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:44:07 --> Final output sent to browser
DEBUG - 2018-03-27 02:44:07 --> Total execution time: 0.1034
INFO - 2018-03-27 02:44:53 --> Model Class Initialized
INFO - 2018-03-27 02:44:53 --> Model Class Initialized
INFO - 2018-03-27 02:44:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:44:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:44:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:44:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:44:53 --> Final output sent to browser
DEBUG - 2018-03-27 02:44:53 --> Total execution time: 0.0963
ERROR - 2018-03-27 02:44:58 --> Query error: Unknown column 'to' in 'field list' - Invalid query: UPDATE `user_login` SET `id_user` = '1', `to` = 'profile/1', `password` = '$2y$10$MJzD9MfLhgC3xkKn..uMH.KR8Pu6kqT0lI5O2s1ZMGLcYI3WT5eFW'
WHERE `id_user` = '1'
DEBUG - 2018-03-27 02:44:58 --> DB Transaction Failure
INFO - 2018-03-27 02:44:58 --> Model Class Initialized
INFO - 2018-03-27 02:44:58 --> Model Class Initialized
INFO - 2018-03-27 02:44:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:44:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:44:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:44:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:44:58 --> Final output sent to browser
DEBUG - 2018-03-27 02:44:58 --> Total execution time: 0.1036
INFO - 2018-03-27 02:45:53 --> Model Class Initialized
INFO - 2018-03-27 02:45:53 --> Model Class Initialized
INFO - 2018-03-27 02:45:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:45:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:45:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:45:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:45:53 --> Final output sent to browser
DEBUG - 2018-03-27 02:45:53 --> Total execution time: 0.1002
INFO - 2018-03-27 02:45:58 --> Model Class Initialized
INFO - 2018-03-27 02:45:58 --> Model Class Initialized
INFO - 2018-03-27 02:45:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:45:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:45:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:45:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:45:58 --> Final output sent to browser
DEBUG - 2018-03-27 02:45:58 --> Total execution time: 0.1159
INFO - 2018-03-27 02:46:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-27 02:46:03 --> Final output sent to browser
DEBUG - 2018-03-27 02:46:03 --> Total execution time: 0.0856
INFO - 2018-03-27 02:46:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-27 02:46:06 --> Final output sent to browser
DEBUG - 2018-03-27 02:46:06 --> Total execution time: 0.1670
INFO - 2018-03-27 02:46:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-27 02:46:10 --> Final output sent to browser
DEBUG - 2018-03-27 02:46:10 --> Total execution time: 0.1472
INFO - 2018-03-27 02:46:16 --> Model Class Initialized
INFO - 2018-03-27 02:46:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:46:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:46:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-27 02:46:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:46:16 --> Final output sent to browser
DEBUG - 2018-03-27 02:46:16 --> Total execution time: 0.1214
INFO - 2018-03-27 02:46:22 --> Model Class Initialized
INFO - 2018-03-27 02:46:22 --> Model Class Initialized
INFO - 2018-03-27 02:46:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:46:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:46:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:46:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:46:22 --> Final output sent to browser
DEBUG - 2018-03-27 02:46:22 --> Total execution time: 0.0916
INFO - 2018-03-27 02:46:26 --> Model Class Initialized
INFO - 2018-03-27 02:46:26 --> Model Class Initialized
INFO - 2018-03-27 02:46:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:46:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:46:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:46:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:46:26 --> Final output sent to browser
DEBUG - 2018-03-27 02:46:26 --> Total execution time: 0.1376
INFO - 2018-03-27 02:46:49 --> Model Class Initialized
INFO - 2018-03-27 02:46:49 --> Model Class Initialized
INFO - 2018-03-27 02:46:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:46:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:46:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:46:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:46:49 --> Final output sent to browser
DEBUG - 2018-03-27 02:46:49 --> Total execution time: 0.1155
INFO - 2018-03-27 02:46:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-27 02:46:51 --> Final output sent to browser
DEBUG - 2018-03-27 02:46:51 --> Total execution time: 0.0935
INFO - 2018-03-27 02:46:54 --> Model Class Initialized
INFO - 2018-03-27 02:46:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:46:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:46:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-27 02:46:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:46:54 --> Final output sent to browser
DEBUG - 2018-03-27 02:46:54 --> Total execution time: 0.1028
INFO - 2018-03-27 02:46:56 --> Model Class Initialized
INFO - 2018-03-27 02:46:56 --> Model Class Initialized
INFO - 2018-03-27 02:46:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:46:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:46:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:46:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:46:56 --> Final output sent to browser
DEBUG - 2018-03-27 02:46:56 --> Total execution time: 0.0928
INFO - 2018-03-27 02:47:01 --> Model Class Initialized
INFO - 2018-03-27 02:47:01 --> Model Class Initialized
INFO - 2018-03-27 02:47:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:47:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:47:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:47:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:47:01 --> Final output sent to browser
DEBUG - 2018-03-27 02:47:01 --> Total execution time: 0.0938
INFO - 2018-03-27 02:47:16 --> Model Class Initialized
INFO - 2018-03-27 02:47:16 --> Model Class Initialized
INFO - 2018-03-27 02:47:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:47:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:47:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:47:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:47:16 --> Final output sent to browser
DEBUG - 2018-03-27 02:47:16 --> Total execution time: 0.0933
INFO - 2018-03-27 02:48:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:48:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:48:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-27 02:48:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:48:49 --> Final output sent to browser
DEBUG - 2018-03-27 02:48:49 --> Total execution time: 0.1569
INFO - 2018-03-27 02:48:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/list.php
INFO - 2018-03-27 02:48:56 --> Final output sent to browser
DEBUG - 2018-03-27 02:48:56 --> Total execution time: 0.0899
INFO - 2018-03-27 02:48:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/list.php
INFO - 2018-03-27 02:48:58 --> Final output sent to browser
DEBUG - 2018-03-27 02:48:58 --> Total execution time: 0.1092
INFO - 2018-03-27 02:49:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/list.php
INFO - 2018-03-27 02:49:01 --> Final output sent to browser
DEBUG - 2018-03-27 02:49:01 --> Total execution time: 0.0692
INFO - 2018-03-27 02:49:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/list.php
INFO - 2018-03-27 02:49:18 --> Final output sent to browser
DEBUG - 2018-03-27 02:49:18 --> Total execution time: 0.0756
INFO - 2018-03-27 02:52:39 --> Model Class Initialized
INFO - 2018-03-27 02:52:39 --> Model Class Initialized
INFO - 2018-03-27 02:52:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:52:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:52:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/group/table.php
INFO - 2018-03-27 02:52:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:52:39 --> Final output sent to browser
DEBUG - 2018-03-27 02:52:39 --> Total execution time: 0.1503
INFO - 2018-03-27 02:52:53 --> Model Class Initialized
INFO - 2018-03-27 02:52:53 --> Model Class Initialized
INFO - 2018-03-27 02:52:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:52:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:52:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:52:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:52:53 --> Final output sent to browser
DEBUG - 2018-03-27 02:52:53 --> Total execution time: 0.0896
INFO - 2018-03-27 02:53:11 --> Model Class Initialized
INFO - 2018-03-27 02:53:11 --> Model Class Initialized
INFO - 2018-03-27 02:53:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:53:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:53:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:53:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:53:11 --> Final output sent to browser
DEBUG - 2018-03-27 02:53:11 --> Total execution time: 0.1079
INFO - 2018-03-27 02:53:32 --> Model Class Initialized
INFO - 2018-03-27 02:53:32 --> Model Class Initialized
INFO - 2018-03-27 02:53:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:53:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:53:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:53:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:53:32 --> Final output sent to browser
DEBUG - 2018-03-27 02:53:32 --> Total execution time: 0.0783
INFO - 2018-03-27 02:53:40 --> Model Class Initialized
INFO - 2018-03-27 02:53:40 --> Model Class Initialized
INFO - 2018-03-27 02:53:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:53:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:53:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:53:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:53:40 --> Final output sent to browser
DEBUG - 2018-03-27 02:53:40 --> Total execution time: 0.0876
INFO - 2018-03-27 02:53:50 --> Model Class Initialized
INFO - 2018-03-27 02:53:50 --> Model Class Initialized
INFO - 2018-03-27 02:53:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:53:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:53:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 02:53:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:53:50 --> Final output sent to browser
DEBUG - 2018-03-27 02:53:50 --> Total execution time: 0.0870
INFO - 2018-03-27 02:54:05 --> Model Class Initialized
INFO - 2018-03-27 02:54:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:54:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:54:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-27 02:54:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:54:05 --> Final output sent to browser
DEBUG - 2018-03-27 02:54:05 --> Total execution time: 0.0820
INFO - 2018-03-27 02:54:11 --> Model Class Initialized
INFO - 2018-03-27 02:54:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:54:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:54:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/create.php
INFO - 2018-03-27 02:54:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:54:11 --> Final output sent to browser
DEBUG - 2018-03-27 02:54:11 --> Total execution time: 0.1162
INFO - 2018-03-27 02:54:15 --> Model Class Initialized
INFO - 2018-03-27 02:54:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:54:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:54:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-27 02:54:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:54:15 --> Final output sent to browser
DEBUG - 2018-03-27 02:54:15 --> Total execution time: 0.0982
INFO - 2018-03-27 02:57:05 --> Model Class Initialized
INFO - 2018-03-27 02:57:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 02:57:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 02:57:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-27 02:57:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 02:57:05 --> Final output sent to browser
DEBUG - 2018-03-27 02:57:05 --> Total execution time: 0.0798
INFO - 2018-03-27 03:00:02 --> Model Class Initialized
INFO - 2018-03-27 03:00:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:00:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:00:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-27 03:00:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:00:02 --> Final output sent to browser
DEBUG - 2018-03-27 03:00:02 --> Total execution time: 0.1070
INFO - 2018-03-27 03:00:39 --> Model Class Initialized
INFO - 2018-03-27 03:00:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:00:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:00:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-27 03:00:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:00:39 --> Final output sent to browser
DEBUG - 2018-03-27 03:00:39 --> Total execution time: 0.1468
INFO - 2018-03-27 03:00:41 --> Model Class Initialized
INFO - 2018-03-27 03:00:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:00:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:00:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/detail.php
INFO - 2018-03-27 03:00:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:00:41 --> Final output sent to browser
DEBUG - 2018-03-27 03:00:41 --> Total execution time: 0.1478
INFO - 2018-03-27 03:01:25 --> Model Class Initialized
INFO - 2018-03-27 03:01:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:01:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:01:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-27 03:01:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:01:25 --> Final output sent to browser
DEBUG - 2018-03-27 03:01:25 --> Total execution time: 0.1265
INFO - 2018-03-27 03:01:48 --> Model Class Initialized
INFO - 2018-03-27 03:01:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:01:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:01:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/detail.php
INFO - 2018-03-27 03:01:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:01:48 --> Final output sent to browser
DEBUG - 2018-03-27 03:01:48 --> Total execution time: 0.1042
INFO - 2018-03-27 03:02:09 --> Model Class Initialized
INFO - 2018-03-27 03:02:09 --> Model Class Initialized
INFO - 2018-03-27 03:02:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:02:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:02:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-27 03:02:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:02:09 --> Final output sent to browser
DEBUG - 2018-03-27 03:02:09 --> Total execution time: 0.1243
INFO - 2018-03-27 03:02:15 --> Model Class Initialized
INFO - 2018-03-27 03:02:15 --> Model Class Initialized
INFO - 2018-03-27 03:02:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:02:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:02:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/create.php
INFO - 2018-03-27 03:02:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:02:15 --> Final output sent to browser
DEBUG - 2018-03-27 03:02:15 --> Total execution time: 0.0948
INFO - 2018-03-27 03:02:31 --> Model Class Initialized
INFO - 2018-03-27 03:02:31 --> Model Class Initialized
INFO - 2018-03-27 03:02:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:02:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:02:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-27 03:02:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:02:31 --> Final output sent to browser
DEBUG - 2018-03-27 03:02:31 --> Total execution time: 0.1023
INFO - 2018-03-27 03:02:36 --> Model Class Initialized
INFO - 2018-03-27 03:02:36 --> Model Class Initialized
INFO - 2018-03-27 03:02:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:02:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:02:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/create.php
INFO - 2018-03-27 03:02:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:02:36 --> Final output sent to browser
DEBUG - 2018-03-27 03:02:36 --> Total execution time: 0.0790
INFO - 2018-03-27 03:03:12 --> Model Class Initialized
INFO - 2018-03-27 03:03:12 --> Model Class Initialized
INFO - 2018-03-27 03:03:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:03:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:03:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-27 03:03:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:03:12 --> Final output sent to browser
DEBUG - 2018-03-27 03:03:12 --> Total execution time: 0.0846
INFO - 2018-03-27 03:03:17 --> Model Class Initialized
INFO - 2018-03-27 03:03:17 --> Model Class Initialized
INFO - 2018-03-27 03:03:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:03:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:03:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-27 03:03:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:03:17 --> Final output sent to browser
DEBUG - 2018-03-27 03:03:17 --> Total execution time: 0.1474
INFO - 2018-03-27 03:03:19 --> Model Class Initialized
INFO - 2018-03-27 03:03:19 --> Model Class Initialized
INFO - 2018-03-27 03:03:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:03:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:03:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/create.php
INFO - 2018-03-27 03:03:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:03:19 --> Final output sent to browser
DEBUG - 2018-03-27 03:03:19 --> Total execution time: 0.0793
INFO - 2018-03-27 03:03:28 --> Model Class Initialized
INFO - 2018-03-27 03:03:28 --> Model Class Initialized
INFO - 2018-03-27 03:03:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:03:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:03:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-27 03:03:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:03:28 --> Final output sent to browser
DEBUG - 2018-03-27 03:03:28 --> Total execution time: 0.1093
INFO - 2018-03-27 03:03:29 --> Model Class Initialized
INFO - 2018-03-27 03:03:29 --> Model Class Initialized
INFO - 2018-03-27 03:03:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:03:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:03:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/create.php
INFO - 2018-03-27 03:03:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:03:29 --> Final output sent to browser
DEBUG - 2018-03-27 03:03:29 --> Total execution time: 0.0869
INFO - 2018-03-27 03:03:35 --> Model Class Initialized
INFO - 2018-03-27 03:03:35 --> Model Class Initialized
INFO - 2018-03-27 03:03:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:03:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:03:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-27 03:03:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:03:35 --> Final output sent to browser
DEBUG - 2018-03-27 03:03:35 --> Total execution time: 0.0971
INFO - 2018-03-27 03:03:41 --> Model Class Initialized
INFO - 2018-03-27 03:03:41 --> Model Class Initialized
INFO - 2018-03-27 03:03:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:03:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:03:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-27 03:03:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:03:41 --> Final output sent to browser
DEBUG - 2018-03-27 03:03:41 --> Total execution time: 0.0778
INFO - 2018-03-27 03:12:33 --> Model Class Initialized
INFO - 2018-03-27 03:12:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:12:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:12:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:12:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:12:33 --> Final output sent to browser
DEBUG - 2018-03-27 03:12:33 --> Total execution time: 0.1485
INFO - 2018-03-27 03:12:51 --> Model Class Initialized
INFO - 2018-03-27 03:12:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:12:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:12:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:12:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:12:51 --> Final output sent to browser
DEBUG - 2018-03-27 03:12:51 --> Total execution time: 0.1231
INFO - 2018-03-27 03:13:58 --> Model Class Initialized
INFO - 2018-03-27 03:13:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:13:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:13:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:13:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:13:58 --> Final output sent to browser
DEBUG - 2018-03-27 03:13:58 --> Total execution time: 0.0930
INFO - 2018-03-27 03:15:31 --> Model Class Initialized
INFO - 2018-03-27 03:15:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:15:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:15:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:15:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:15:31 --> Final output sent to browser
DEBUG - 2018-03-27 03:15:31 --> Total execution time: 0.1060
INFO - 2018-03-27 03:15:58 --> Model Class Initialized
INFO - 2018-03-27 03:15:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:15:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:15:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:15:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:15:58 --> Final output sent to browser
DEBUG - 2018-03-27 03:15:58 --> Total execution time: 0.1138
INFO - 2018-03-27 03:16:14 --> Model Class Initialized
INFO - 2018-03-27 03:16:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:16:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:16:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:16:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:16:14 --> Final output sent to browser
DEBUG - 2018-03-27 03:16:14 --> Total execution time: 0.1049
INFO - 2018-03-27 03:16:31 --> Model Class Initialized
INFO - 2018-03-27 03:16:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:16:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:16:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:16:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:16:31 --> Final output sent to browser
DEBUG - 2018-03-27 03:16:31 --> Total execution time: 0.0922
INFO - 2018-03-27 03:17:09 --> Model Class Initialized
INFO - 2018-03-27 03:17:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:17:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:17:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:17:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:17:09 --> Final output sent to browser
DEBUG - 2018-03-27 03:17:09 --> Total execution time: 0.1126
INFO - 2018-03-27 03:18:09 --> Model Class Initialized
INFO - 2018-03-27 03:18:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:18:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:18:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:18:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:18:09 --> Final output sent to browser
DEBUG - 2018-03-27 03:18:09 --> Total execution time: 0.1077
INFO - 2018-03-27 03:21:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/list.php
INFO - 2018-03-27 03:21:51 --> Final output sent to browser
DEBUG - 2018-03-27 03:21:51 --> Total execution time: 0.0808
INFO - 2018-03-27 03:22:55 --> Model Class Initialized
INFO - 2018-03-27 03:22:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:22:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:22:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:22:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:22:55 --> Final output sent to browser
DEBUG - 2018-03-27 03:22:55 --> Total execution time: 0.0987
INFO - 2018-03-27 03:23:34 --> Model Class Initialized
INFO - 2018-03-27 03:23:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:23:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:23:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:23:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:23:34 --> Final output sent to browser
DEBUG - 2018-03-27 03:23:34 --> Total execution time: 0.1077
INFO - 2018-03-27 03:29:51 --> Model Class Initialized
INFO - 2018-03-27 03:29:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:29:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:29:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:29:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:29:51 --> Final output sent to browser
DEBUG - 2018-03-27 03:29:51 --> Total execution time: 0.0869
INFO - 2018-03-27 03:30:14 --> Model Class Initialized
INFO - 2018-03-27 03:30:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:30:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:30:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:30:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:30:14 --> Final output sent to browser
DEBUG - 2018-03-27 03:30:14 --> Total execution time: 0.1173
INFO - 2018-03-27 03:30:31 --> Model Class Initialized
INFO - 2018-03-27 03:30:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:30:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:30:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:30:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:30:31 --> Final output sent to browser
DEBUG - 2018-03-27 03:30:31 --> Total execution time: 0.1150
INFO - 2018-03-27 03:30:51 --> Model Class Initialized
INFO - 2018-03-27 03:30:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:30:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:30:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:30:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:30:51 --> Final output sent to browser
DEBUG - 2018-03-27 03:30:51 --> Total execution time: 0.1274
INFO - 2018-03-27 03:30:57 --> Final output sent to browser
DEBUG - 2018-03-27 03:30:57 --> Total execution time: 0.0856
INFO - 2018-03-27 03:37:14 --> Model Class Initialized
INFO - 2018-03-27 03:37:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:37:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:37:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:37:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:37:14 --> Final output sent to browser
DEBUG - 2018-03-27 03:37:14 --> Total execution time: 0.1159
INFO - 2018-03-27 03:37:21 --> Final output sent to browser
DEBUG - 2018-03-27 03:37:21 --> Total execution time: 0.1222
INFO - 2018-03-27 03:37:38 --> Final output sent to browser
DEBUG - 2018-03-27 03:37:38 --> Total execution time: 0.0892
INFO - 2018-03-27 03:37:44 --> Final output sent to browser
DEBUG - 2018-03-27 03:37:44 --> Total execution time: 0.0799
INFO - 2018-03-27 03:42:20 --> Model Class Initialized
INFO - 2018-03-27 03:42:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:42:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:42:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:42:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:42:20 --> Final output sent to browser
DEBUG - 2018-03-27 03:42:20 --> Total execution time: 0.1082
ERROR - 2018-03-27 03:42:26 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp\htdocs\skin_care\application\views\Laporan\penjualan\list.php 1
ERROR - 2018-03-27 03:42:29 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp\htdocs\skin_care\application\views\Laporan\penjualan\list.php 1
ERROR - 2018-03-27 03:42:29 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp\htdocs\skin_care\application\views\Laporan\penjualan\list.php 1
ERROR - 2018-03-27 03:42:30 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp\htdocs\skin_care\application\views\Laporan\penjualan\list.php 1
ERROR - 2018-03-27 03:42:30 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp\htdocs\skin_care\application\views\Laporan\penjualan\list.php 1
ERROR - 2018-03-27 03:42:30 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp\htdocs\skin_care\application\views\Laporan\penjualan\list.php 1
ERROR - 2018-03-27 03:42:30 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp\htdocs\skin_care\application\views\Laporan\penjualan\list.php 1
INFO - 2018-03-27 03:42:50 --> Model Class Initialized
INFO - 2018-03-27 03:42:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:42:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:42:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:42:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:42:50 --> Final output sent to browser
DEBUG - 2018-03-27 03:42:50 --> Total execution time: 0.1138
INFO - 2018-03-27 03:42:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:42:54 --> Final output sent to browser
DEBUG - 2018-03-27 03:42:54 --> Total execution time: 0.0965
INFO - 2018-03-27 03:43:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:43:05 --> Final output sent to browser
DEBUG - 2018-03-27 03:43:05 --> Total execution time: 0.0763
INFO - 2018-03-27 03:43:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:43:16 --> Final output sent to browser
DEBUG - 2018-03-27 03:43:16 --> Total execution time: 0.0711
INFO - 2018-03-27 03:43:59 --> Model Class Initialized
INFO - 2018-03-27 03:43:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:43:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:43:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:43:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:43:59 --> Final output sent to browser
DEBUG - 2018-03-27 03:43:59 --> Total execution time: 0.1214
INFO - 2018-03-27 03:44:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:44:04 --> Final output sent to browser
DEBUG - 2018-03-27 03:44:04 --> Total execution time: 0.0850
INFO - 2018-03-27 03:44:33 --> Model Class Initialized
INFO - 2018-03-27 03:44:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:44:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:44:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:44:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:44:33 --> Final output sent to browser
DEBUG - 2018-03-27 03:44:33 --> Total execution time: 0.1156
INFO - 2018-03-27 03:44:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:44:39 --> Final output sent to browser
DEBUG - 2018-03-27 03:44:39 --> Total execution time: 0.0809
INFO - 2018-03-27 03:45:48 --> Model Class Initialized
INFO - 2018-03-27 03:45:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:45:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:45:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:45:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:45:48 --> Final output sent to browser
DEBUG - 2018-03-27 03:45:48 --> Total execution time: 0.1279
INFO - 2018-03-27 03:45:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:45:53 --> Final output sent to browser
DEBUG - 2018-03-27 03:45:53 --> Total execution time: 0.0861
INFO - 2018-03-27 03:45:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:45:57 --> Final output sent to browser
DEBUG - 2018-03-27 03:45:57 --> Total execution time: 0.0939
INFO - 2018-03-27 03:45:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:45:58 --> Final output sent to browser
DEBUG - 2018-03-27 03:45:58 --> Total execution time: 0.0871
INFO - 2018-03-27 03:46:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:46:01 --> Final output sent to browser
DEBUG - 2018-03-27 03:46:01 --> Total execution time: 0.0881
INFO - 2018-03-27 03:46:25 --> Model Class Initialized
INFO - 2018-03-27 03:46:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:46:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:46:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:46:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:46:25 --> Final output sent to browser
DEBUG - 2018-03-27 03:46:25 --> Total execution time: 0.1169
INFO - 2018-03-27 03:46:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:46:31 --> Final output sent to browser
DEBUG - 2018-03-27 03:46:31 --> Total execution time: 0.0942
INFO - 2018-03-27 03:46:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:46:38 --> Final output sent to browser
DEBUG - 2018-03-27 03:46:38 --> Total execution time: 0.0850
INFO - 2018-03-27 03:46:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:46:40 --> Final output sent to browser
DEBUG - 2018-03-27 03:46:40 --> Total execution time: 0.1099
INFO - 2018-03-27 03:46:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:46:44 --> Final output sent to browser
DEBUG - 2018-03-27 03:46:44 --> Total execution time: 0.1050
INFO - 2018-03-27 03:46:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:46:46 --> Final output sent to browser
DEBUG - 2018-03-27 03:46:46 --> Total execution time: 0.1250
INFO - 2018-03-27 03:46:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:46:48 --> Final output sent to browser
DEBUG - 2018-03-27 03:46:48 --> Total execution time: 0.0929
INFO - 2018-03-27 03:46:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:46:50 --> Final output sent to browser
DEBUG - 2018-03-27 03:46:50 --> Total execution time: 0.0891
INFO - 2018-03-27 03:46:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:46:54 --> Final output sent to browser
DEBUG - 2018-03-27 03:46:54 --> Total execution time: 0.0816
INFO - 2018-03-27 03:50:28 --> Model Class Initialized
INFO - 2018-03-27 03:50:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:50:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:50:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:50:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:50:28 --> Final output sent to browser
DEBUG - 2018-03-27 03:50:28 --> Total execution time: 0.1000
INFO - 2018-03-27 03:50:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:50:32 --> Final output sent to browser
DEBUG - 2018-03-27 03:50:32 --> Total execution time: 0.1027
INFO - 2018-03-27 03:51:33 --> Model Class Initialized
INFO - 2018-03-27 03:51:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:51:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:51:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:51:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:51:33 --> Final output sent to browser
DEBUG - 2018-03-27 03:51:33 --> Total execution time: 0.0991
INFO - 2018-03-27 03:51:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:51:38 --> Final output sent to browser
DEBUG - 2018-03-27 03:51:38 --> Total execution time: 0.0994
INFO - 2018-03-27 03:51:54 --> Model Class Initialized
INFO - 2018-03-27 03:51:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:51:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:51:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:51:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:51:54 --> Final output sent to browser
DEBUG - 2018-03-27 03:51:54 --> Total execution time: 0.1028
INFO - 2018-03-27 03:51:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:51:59 --> Final output sent to browser
DEBUG - 2018-03-27 03:51:59 --> Total execution time: 0.1244
INFO - 2018-03-27 03:52:08 --> Model Class Initialized
INFO - 2018-03-27 03:52:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:52:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:52:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:52:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:52:08 --> Final output sent to browser
DEBUG - 2018-03-27 03:52:08 --> Total execution time: 0.1164
INFO - 2018-03-27 03:52:36 --> Model Class Initialized
INFO - 2018-03-27 03:52:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:52:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:52:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:52:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:52:36 --> Final output sent to browser
DEBUG - 2018-03-27 03:52:36 --> Total execution time: 0.1199
INFO - 2018-03-27 03:52:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:52:41 --> Final output sent to browser
DEBUG - 2018-03-27 03:52:41 --> Total execution time: 0.1010
INFO - 2018-03-27 03:53:07 --> Model Class Initialized
INFO - 2018-03-27 03:53:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:53:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:53:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:53:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:53:07 --> Final output sent to browser
DEBUG - 2018-03-27 03:53:07 --> Total execution time: 0.1230
INFO - 2018-03-27 03:53:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:53:12 --> Final output sent to browser
DEBUG - 2018-03-27 03:53:12 --> Total execution time: 0.0969
INFO - 2018-03-27 03:53:48 --> Model Class Initialized
INFO - 2018-03-27 03:53:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:53:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:53:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:53:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:53:48 --> Final output sent to browser
DEBUG - 2018-03-27 03:53:48 --> Total execution time: 0.1373
INFO - 2018-03-27 03:53:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:53:53 --> Final output sent to browser
DEBUG - 2018-03-27 03:53:53 --> Total execution time: 0.0857
INFO - 2018-03-27 03:54:01 --> Model Class Initialized
INFO - 2018-03-27 03:54:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:54:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:54:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:54:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:54:01 --> Final output sent to browser
DEBUG - 2018-03-27 03:54:01 --> Total execution time: 0.1179
INFO - 2018-03-27 03:54:58 --> Model Class Initialized
INFO - 2018-03-27 03:54:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 03:54:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 03:54:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 03:54:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 03:54:58 --> Final output sent to browser
DEBUG - 2018-03-27 03:54:58 --> Total execution time: 0.1120
INFO - 2018-03-27 03:55:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 03:55:03 --> Final output sent to browser
DEBUG - 2018-03-27 03:55:03 --> Total execution time: 0.0763
INFO - 2018-03-27 14:48:06 --> Config Class Initialized
INFO - 2018-03-27 14:48:06 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:48:06 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:48:06 --> Utf8 Class Initialized
INFO - 2018-03-27 14:48:06 --> URI Class Initialized
INFO - 2018-03-27 14:48:06 --> Router Class Initialized
INFO - 2018-03-27 14:48:06 --> Output Class Initialized
INFO - 2018-03-27 14:48:06 --> Security Class Initialized
DEBUG - 2018-03-27 14:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:48:06 --> Input Class Initialized
INFO - 2018-03-27 14:48:06 --> Language Class Initialized
INFO - 2018-03-27 14:48:06 --> Loader Class Initialized
INFO - 2018-03-27 14:48:06 --> Helper loaded: url_helper
INFO - 2018-03-27 14:48:06 --> Helper loaded: form_helper
INFO - 2018-03-27 14:48:06 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:48:06 --> Controller Class Initialized
INFO - 2018-03-27 14:48:06 --> Config Class Initialized
INFO - 2018-03-27 14:48:06 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:48:06 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:48:06 --> Utf8 Class Initialized
INFO - 2018-03-27 14:48:06 --> URI Class Initialized
INFO - 2018-03-27 14:48:06 --> Router Class Initialized
INFO - 2018-03-27 14:48:06 --> Output Class Initialized
INFO - 2018-03-27 14:48:06 --> Security Class Initialized
DEBUG - 2018-03-27 14:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:48:06 --> Input Class Initialized
INFO - 2018-03-27 14:48:06 --> Language Class Initialized
INFO - 2018-03-27 14:48:06 --> Loader Class Initialized
INFO - 2018-03-27 14:48:06 --> Helper loaded: url_helper
INFO - 2018-03-27 14:48:06 --> Helper loaded: form_helper
INFO - 2018-03-27 14:48:06 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:48:06 --> Controller Class Initialized
INFO - 2018-03-27 14:48:06 --> Model Class Initialized
INFO - 2018-03-27 14:48:06 --> Model Class Initialized
INFO - 2018-03-27 14:48:06 --> Model Class Initialized
INFO - 2018-03-27 14:48:06 --> Helper loaded: date_helper
INFO - 2018-03-27 19:48:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-27 19:48:06 --> Final output sent to browser
DEBUG - 2018-03-27 19:48:06 --> Total execution time: 0.1245
INFO - 2018-03-27 14:48:15 --> Config Class Initialized
INFO - 2018-03-27 14:48:15 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:48:15 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:48:15 --> Utf8 Class Initialized
INFO - 2018-03-27 14:48:15 --> URI Class Initialized
INFO - 2018-03-27 14:48:15 --> Router Class Initialized
INFO - 2018-03-27 14:48:15 --> Output Class Initialized
INFO - 2018-03-27 14:48:15 --> Security Class Initialized
DEBUG - 2018-03-27 14:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:48:15 --> Input Class Initialized
INFO - 2018-03-27 14:48:15 --> Language Class Initialized
INFO - 2018-03-27 14:48:15 --> Loader Class Initialized
INFO - 2018-03-27 14:48:15 --> Helper loaded: url_helper
INFO - 2018-03-27 14:48:15 --> Helper loaded: form_helper
INFO - 2018-03-27 14:48:15 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:48:15 --> Controller Class Initialized
INFO - 2018-03-27 14:48:15 --> Model Class Initialized
INFO - 2018-03-27 14:48:15 --> Model Class Initialized
INFO - 2018-03-27 14:48:15 --> Model Class Initialized
INFO - 2018-03-27 14:48:15 --> Helper loaded: date_helper
INFO - 2018-03-27 14:48:16 --> Config Class Initialized
INFO - 2018-03-27 14:48:16 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:48:16 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:48:16 --> Utf8 Class Initialized
INFO - 2018-03-27 14:48:16 --> URI Class Initialized
INFO - 2018-03-27 14:48:16 --> Router Class Initialized
INFO - 2018-03-27 14:48:16 --> Output Class Initialized
INFO - 2018-03-27 14:48:16 --> Security Class Initialized
DEBUG - 2018-03-27 14:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:48:16 --> Input Class Initialized
INFO - 2018-03-27 14:48:16 --> Language Class Initialized
INFO - 2018-03-27 14:48:16 --> Loader Class Initialized
INFO - 2018-03-27 14:48:16 --> Helper loaded: url_helper
INFO - 2018-03-27 14:48:16 --> Helper loaded: form_helper
INFO - 2018-03-27 14:48:16 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:48:16 --> Controller Class Initialized
INFO - 2018-03-27 14:48:16 --> Model Class Initialized
INFO - 2018-03-27 14:48:16 --> Model Class Initialized
INFO - 2018-03-27 14:48:16 --> Model Class Initialized
INFO - 2018-03-27 14:48:16 --> Model Class Initialized
INFO - 2018-03-27 14:48:16 --> Model Class Initialized
INFO - 2018-03-27 14:48:16 --> Helper loaded: date_helper
INFO - 2018-03-27 19:48:16 --> Model Class Initialized
INFO - 2018-03-27 19:48:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 19:48:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 19:48:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-27 19:48:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 19:48:16 --> Final output sent to browser
DEBUG - 2018-03-27 19:48:16 --> Total execution time: 0.4908
INFO - 2018-03-27 14:48:21 --> Config Class Initialized
INFO - 2018-03-27 14:48:21 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:48:21 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:48:21 --> Utf8 Class Initialized
INFO - 2018-03-27 14:48:21 --> URI Class Initialized
INFO - 2018-03-27 14:48:21 --> Router Class Initialized
INFO - 2018-03-27 14:48:21 --> Output Class Initialized
INFO - 2018-03-27 14:48:21 --> Security Class Initialized
DEBUG - 2018-03-27 14:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:48:21 --> Input Class Initialized
INFO - 2018-03-27 14:48:21 --> Language Class Initialized
INFO - 2018-03-27 14:48:21 --> Loader Class Initialized
INFO - 2018-03-27 14:48:21 --> Helper loaded: url_helper
INFO - 2018-03-27 14:48:21 --> Helper loaded: form_helper
INFO - 2018-03-27 14:48:21 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:48:21 --> Controller Class Initialized
INFO - 2018-03-27 14:48:21 --> Model Class Initialized
INFO - 2018-03-27 14:48:21 --> Model Class Initialized
INFO - 2018-03-27 14:48:21 --> Model Class Initialized
INFO - 2018-03-27 14:48:21 --> Model Class Initialized
INFO - 2018-03-27 14:48:21 --> Model Class Initialized
INFO - 2018-03-27 14:48:21 --> Model Class Initialized
INFO - 2018-03-27 14:48:21 --> Model Class Initialized
INFO - 2018-03-27 14:48:21 --> Model Class Initialized
INFO - 2018-03-27 14:48:21 --> Model Class Initialized
INFO - 2018-03-27 14:48:21 --> Model Class Initialized
INFO - 2018-03-27 14:48:21 --> Model Class Initialized
INFO - 2018-03-27 14:48:21 --> Model Class Initialized
INFO - 2018-03-27 14:48:21 --> Model Class Initialized
INFO - 2018-03-27 14:48:21 --> Model Class Initialized
INFO - 2018-03-27 14:48:21 --> Model Class Initialized
INFO - 2018-03-27 14:48:21 --> Helper loaded: date_helper
INFO - 2018-03-27 14:48:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:48:21 --> Model Class Initialized
INFO - 2018-03-27 19:48:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 19:48:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 19:48:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 19:48:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 19:48:21 --> Final output sent to browser
DEBUG - 2018-03-27 19:48:21 --> Total execution time: 0.1679
INFO - 2018-03-27 14:48:27 --> Config Class Initialized
INFO - 2018-03-27 14:48:27 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:48:27 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:48:27 --> Utf8 Class Initialized
INFO - 2018-03-27 14:48:27 --> URI Class Initialized
INFO - 2018-03-27 14:48:27 --> Router Class Initialized
INFO - 2018-03-27 14:48:27 --> Output Class Initialized
INFO - 2018-03-27 14:48:27 --> Security Class Initialized
DEBUG - 2018-03-27 14:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:48:27 --> Input Class Initialized
INFO - 2018-03-27 14:48:27 --> Language Class Initialized
INFO - 2018-03-27 14:48:27 --> Loader Class Initialized
INFO - 2018-03-27 14:48:27 --> Helper loaded: url_helper
INFO - 2018-03-27 14:48:27 --> Helper loaded: form_helper
INFO - 2018-03-27 14:48:27 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:48:27 --> Controller Class Initialized
INFO - 2018-03-27 14:48:27 --> Model Class Initialized
INFO - 2018-03-27 14:48:27 --> Model Class Initialized
INFO - 2018-03-27 14:48:27 --> Model Class Initialized
INFO - 2018-03-27 14:48:27 --> Model Class Initialized
INFO - 2018-03-27 14:48:27 --> Model Class Initialized
INFO - 2018-03-27 14:48:27 --> Model Class Initialized
INFO - 2018-03-27 14:48:27 --> Model Class Initialized
INFO - 2018-03-27 14:48:27 --> Model Class Initialized
INFO - 2018-03-27 14:48:27 --> Model Class Initialized
INFO - 2018-03-27 14:48:27 --> Model Class Initialized
INFO - 2018-03-27 14:48:27 --> Model Class Initialized
INFO - 2018-03-27 14:48:27 --> Model Class Initialized
INFO - 2018-03-27 14:48:27 --> Model Class Initialized
INFO - 2018-03-27 14:48:27 --> Model Class Initialized
INFO - 2018-03-27 14:48:27 --> Model Class Initialized
INFO - 2018-03-27 14:48:27 --> Helper loaded: date_helper
INFO - 2018-03-27 14:48:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:48:27 --> Model Class Initialized
INFO - 2018-03-27 19:48:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 19:48:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 19:48:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 19:48:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 19:48:27 --> Final output sent to browser
DEBUG - 2018-03-27 19:48:27 --> Total execution time: 0.1792
INFO - 2018-03-27 14:48:31 --> Config Class Initialized
INFO - 2018-03-27 14:48:31 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:48:31 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:48:31 --> Utf8 Class Initialized
INFO - 2018-03-27 14:48:31 --> URI Class Initialized
INFO - 2018-03-27 14:48:31 --> Router Class Initialized
INFO - 2018-03-27 14:48:31 --> Output Class Initialized
INFO - 2018-03-27 14:48:31 --> Security Class Initialized
DEBUG - 2018-03-27 14:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:48:31 --> Input Class Initialized
INFO - 2018-03-27 14:48:31 --> Language Class Initialized
INFO - 2018-03-27 14:48:31 --> Loader Class Initialized
INFO - 2018-03-27 14:48:31 --> Helper loaded: url_helper
INFO - 2018-03-27 14:48:31 --> Helper loaded: form_helper
INFO - 2018-03-27 14:48:31 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:48:31 --> Controller Class Initialized
INFO - 2018-03-27 14:48:31 --> Model Class Initialized
INFO - 2018-03-27 14:48:31 --> Model Class Initialized
INFO - 2018-03-27 14:48:31 --> Model Class Initialized
INFO - 2018-03-27 14:48:31 --> Model Class Initialized
INFO - 2018-03-27 14:48:31 --> Model Class Initialized
INFO - 2018-03-27 14:48:31 --> Model Class Initialized
INFO - 2018-03-27 14:48:31 --> Model Class Initialized
INFO - 2018-03-27 14:48:31 --> Model Class Initialized
INFO - 2018-03-27 14:48:31 --> Model Class Initialized
INFO - 2018-03-27 14:48:31 --> Model Class Initialized
INFO - 2018-03-27 14:48:31 --> Model Class Initialized
INFO - 2018-03-27 14:48:31 --> Model Class Initialized
INFO - 2018-03-27 14:48:31 --> Model Class Initialized
INFO - 2018-03-27 14:48:31 --> Model Class Initialized
INFO - 2018-03-27 14:48:31 --> Model Class Initialized
INFO - 2018-03-27 14:48:31 --> Helper loaded: date_helper
INFO - 2018-03-27 14:48:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:48:31 --> Model Class Initialized
INFO - 2018-03-27 19:48:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 19:48:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 19:48:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 19:48:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 19:48:31 --> Final output sent to browser
DEBUG - 2018-03-27 19:48:31 --> Total execution time: 0.1720
INFO - 2018-03-27 14:48:36 --> Config Class Initialized
INFO - 2018-03-27 14:48:36 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:48:36 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:48:36 --> Utf8 Class Initialized
INFO - 2018-03-27 14:48:36 --> URI Class Initialized
INFO - 2018-03-27 14:48:36 --> Router Class Initialized
INFO - 2018-03-27 14:48:36 --> Output Class Initialized
INFO - 2018-03-27 14:48:36 --> Security Class Initialized
DEBUG - 2018-03-27 14:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:48:36 --> Input Class Initialized
INFO - 2018-03-27 14:48:36 --> Language Class Initialized
INFO - 2018-03-27 14:48:36 --> Loader Class Initialized
INFO - 2018-03-27 14:48:36 --> Helper loaded: url_helper
INFO - 2018-03-27 14:48:36 --> Helper loaded: form_helper
INFO - 2018-03-27 14:48:36 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:48:36 --> Controller Class Initialized
INFO - 2018-03-27 14:48:36 --> Model Class Initialized
INFO - 2018-03-27 14:48:36 --> Model Class Initialized
INFO - 2018-03-27 14:48:36 --> Model Class Initialized
INFO - 2018-03-27 14:48:36 --> Model Class Initialized
INFO - 2018-03-27 14:48:36 --> Model Class Initialized
INFO - 2018-03-27 14:48:36 --> Model Class Initialized
INFO - 2018-03-27 14:48:36 --> Model Class Initialized
INFO - 2018-03-27 14:48:36 --> Model Class Initialized
INFO - 2018-03-27 14:48:36 --> Model Class Initialized
INFO - 2018-03-27 14:48:36 --> Model Class Initialized
INFO - 2018-03-27 14:48:36 --> Model Class Initialized
INFO - 2018-03-27 14:48:36 --> Model Class Initialized
INFO - 2018-03-27 14:48:36 --> Model Class Initialized
INFO - 2018-03-27 14:48:36 --> Model Class Initialized
INFO - 2018-03-27 14:48:36 --> Model Class Initialized
INFO - 2018-03-27 14:48:36 --> Helper loaded: date_helper
INFO - 2018-03-27 14:48:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:48:36 --> Model Class Initialized
INFO - 2018-03-27 19:48:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 19:48:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 19:48:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 19:48:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 19:48:36 --> Final output sent to browser
DEBUG - 2018-03-27 19:48:36 --> Total execution time: 0.1345
INFO - 2018-03-27 14:48:45 --> Config Class Initialized
INFO - 2018-03-27 14:48:45 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:48:45 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:48:45 --> Utf8 Class Initialized
INFO - 2018-03-27 14:48:45 --> URI Class Initialized
INFO - 2018-03-27 14:48:45 --> Router Class Initialized
INFO - 2018-03-27 14:48:45 --> Output Class Initialized
INFO - 2018-03-27 14:48:45 --> Security Class Initialized
DEBUG - 2018-03-27 14:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:48:45 --> Input Class Initialized
INFO - 2018-03-27 14:48:45 --> Language Class Initialized
INFO - 2018-03-27 14:48:45 --> Loader Class Initialized
INFO - 2018-03-27 14:48:45 --> Helper loaded: url_helper
INFO - 2018-03-27 14:48:45 --> Helper loaded: form_helper
INFO - 2018-03-27 14:48:45 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:48:45 --> Controller Class Initialized
INFO - 2018-03-27 14:48:45 --> Model Class Initialized
INFO - 2018-03-27 14:48:45 --> Model Class Initialized
INFO - 2018-03-27 14:48:45 --> Model Class Initialized
INFO - 2018-03-27 14:48:45 --> Model Class Initialized
INFO - 2018-03-27 14:48:45 --> Model Class Initialized
INFO - 2018-03-27 14:48:45 --> Model Class Initialized
INFO - 2018-03-27 14:48:45 --> Model Class Initialized
INFO - 2018-03-27 14:48:45 --> Model Class Initialized
INFO - 2018-03-27 14:48:45 --> Model Class Initialized
INFO - 2018-03-27 14:48:45 --> Model Class Initialized
INFO - 2018-03-27 14:48:45 --> Model Class Initialized
INFO - 2018-03-27 14:48:45 --> Model Class Initialized
INFO - 2018-03-27 14:48:45 --> Model Class Initialized
INFO - 2018-03-27 14:48:45 --> Model Class Initialized
INFO - 2018-03-27 14:48:45 --> Model Class Initialized
INFO - 2018-03-27 14:48:45 --> Helper loaded: date_helper
INFO - 2018-03-27 14:48:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:48:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:48:45 --> Final output sent to browser
DEBUG - 2018-03-27 19:48:45 --> Total execution time: 0.2603
INFO - 2018-03-27 14:49:30 --> Config Class Initialized
INFO - 2018-03-27 14:49:30 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:49:30 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:49:30 --> Utf8 Class Initialized
INFO - 2018-03-27 14:49:30 --> URI Class Initialized
INFO - 2018-03-27 14:49:30 --> Router Class Initialized
INFO - 2018-03-27 14:49:30 --> Output Class Initialized
INFO - 2018-03-27 14:49:30 --> Security Class Initialized
DEBUG - 2018-03-27 14:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:49:30 --> Input Class Initialized
INFO - 2018-03-27 14:49:30 --> Language Class Initialized
INFO - 2018-03-27 14:49:30 --> Loader Class Initialized
INFO - 2018-03-27 14:49:30 --> Helper loaded: url_helper
INFO - 2018-03-27 14:49:30 --> Helper loaded: form_helper
INFO - 2018-03-27 14:49:30 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:49:30 --> Controller Class Initialized
INFO - 2018-03-27 14:49:30 --> Model Class Initialized
INFO - 2018-03-27 14:49:30 --> Model Class Initialized
INFO - 2018-03-27 14:49:30 --> Model Class Initialized
INFO - 2018-03-27 14:49:30 --> Model Class Initialized
INFO - 2018-03-27 14:49:30 --> Model Class Initialized
INFO - 2018-03-27 14:49:30 --> Model Class Initialized
INFO - 2018-03-27 14:49:30 --> Model Class Initialized
INFO - 2018-03-27 14:49:30 --> Helper loaded: date_helper
INFO - 2018-03-27 14:49:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:49:30 --> Model Class Initialized
INFO - 2018-03-27 19:49:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 19:49:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 19:49:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-27 19:49:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 19:49:30 --> Final output sent to browser
DEBUG - 2018-03-27 19:49:30 --> Total execution time: 0.1717
INFO - 2018-03-27 14:49:40 --> Config Class Initialized
INFO - 2018-03-27 14:49:40 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:49:40 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:49:40 --> Utf8 Class Initialized
INFO - 2018-03-27 14:49:40 --> URI Class Initialized
INFO - 2018-03-27 14:49:40 --> Router Class Initialized
INFO - 2018-03-27 14:49:40 --> Output Class Initialized
INFO - 2018-03-27 14:49:40 --> Security Class Initialized
DEBUG - 2018-03-27 14:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:49:40 --> Input Class Initialized
INFO - 2018-03-27 14:49:40 --> Language Class Initialized
INFO - 2018-03-27 14:49:40 --> Loader Class Initialized
INFO - 2018-03-27 14:49:40 --> Helper loaded: url_helper
INFO - 2018-03-27 14:49:40 --> Helper loaded: form_helper
INFO - 2018-03-27 14:49:40 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:49:40 --> Controller Class Initialized
INFO - 2018-03-27 14:49:40 --> Model Class Initialized
INFO - 2018-03-27 14:49:40 --> Model Class Initialized
INFO - 2018-03-27 14:49:40 --> Model Class Initialized
INFO - 2018-03-27 14:49:40 --> Model Class Initialized
INFO - 2018-03-27 14:49:40 --> Model Class Initialized
INFO - 2018-03-27 14:49:40 --> Model Class Initialized
INFO - 2018-03-27 14:49:40 --> Model Class Initialized
INFO - 2018-03-27 14:49:40 --> Model Class Initialized
INFO - 2018-03-27 14:49:40 --> Model Class Initialized
INFO - 2018-03-27 14:49:40 --> Model Class Initialized
INFO - 2018-03-27 14:49:40 --> Model Class Initialized
INFO - 2018-03-27 14:49:40 --> Model Class Initialized
INFO - 2018-03-27 14:49:40 --> Model Class Initialized
INFO - 2018-03-27 14:49:40 --> Model Class Initialized
INFO - 2018-03-27 14:49:40 --> Model Class Initialized
INFO - 2018-03-27 14:49:40 --> Helper loaded: date_helper
INFO - 2018-03-27 14:49:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:49:40 --> Model Class Initialized
INFO - 2018-03-27 19:49:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 19:49:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 19:49:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 19:49:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 19:49:40 --> Final output sent to browser
DEBUG - 2018-03-27 19:49:40 --> Total execution time: 0.1351
INFO - 2018-03-27 14:49:47 --> Config Class Initialized
INFO - 2018-03-27 14:49:47 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:49:47 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:49:47 --> Utf8 Class Initialized
INFO - 2018-03-27 14:49:47 --> URI Class Initialized
INFO - 2018-03-27 14:49:47 --> Router Class Initialized
INFO - 2018-03-27 14:49:47 --> Output Class Initialized
INFO - 2018-03-27 14:49:47 --> Security Class Initialized
DEBUG - 2018-03-27 14:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:49:47 --> Input Class Initialized
INFO - 2018-03-27 14:49:47 --> Language Class Initialized
INFO - 2018-03-27 14:49:47 --> Loader Class Initialized
INFO - 2018-03-27 14:49:47 --> Helper loaded: url_helper
INFO - 2018-03-27 14:49:47 --> Helper loaded: form_helper
INFO - 2018-03-27 14:49:47 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:49:47 --> Controller Class Initialized
INFO - 2018-03-27 14:49:47 --> Model Class Initialized
INFO - 2018-03-27 14:49:47 --> Model Class Initialized
INFO - 2018-03-27 14:49:47 --> Model Class Initialized
INFO - 2018-03-27 14:49:47 --> Model Class Initialized
INFO - 2018-03-27 14:49:47 --> Model Class Initialized
INFO - 2018-03-27 14:49:47 --> Model Class Initialized
INFO - 2018-03-27 14:49:47 --> Model Class Initialized
INFO - 2018-03-27 14:49:47 --> Model Class Initialized
INFO - 2018-03-27 14:49:47 --> Model Class Initialized
INFO - 2018-03-27 14:49:47 --> Model Class Initialized
INFO - 2018-03-27 14:49:47 --> Model Class Initialized
INFO - 2018-03-27 14:49:47 --> Model Class Initialized
INFO - 2018-03-27 14:49:47 --> Model Class Initialized
INFO - 2018-03-27 14:49:47 --> Model Class Initialized
INFO - 2018-03-27 14:49:47 --> Model Class Initialized
INFO - 2018-03-27 14:49:47 --> Helper loaded: date_helper
INFO - 2018-03-27 14:49:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:49:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:49:47 --> Final output sent to browser
DEBUG - 2018-03-27 19:49:47 --> Total execution time: 0.1599
INFO - 2018-03-27 14:49:50 --> Config Class Initialized
INFO - 2018-03-27 14:49:50 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:49:50 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:49:50 --> Utf8 Class Initialized
INFO - 2018-03-27 14:49:50 --> URI Class Initialized
INFO - 2018-03-27 14:49:50 --> Router Class Initialized
INFO - 2018-03-27 14:49:50 --> Output Class Initialized
INFO - 2018-03-27 14:49:50 --> Security Class Initialized
DEBUG - 2018-03-27 14:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:49:50 --> Input Class Initialized
INFO - 2018-03-27 14:49:50 --> Language Class Initialized
INFO - 2018-03-27 14:49:50 --> Loader Class Initialized
INFO - 2018-03-27 14:49:50 --> Helper loaded: url_helper
INFO - 2018-03-27 14:49:50 --> Helper loaded: form_helper
INFO - 2018-03-27 14:49:50 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:49:50 --> Controller Class Initialized
INFO - 2018-03-27 14:49:50 --> Model Class Initialized
INFO - 2018-03-27 14:49:50 --> Model Class Initialized
INFO - 2018-03-27 14:49:50 --> Model Class Initialized
INFO - 2018-03-27 14:49:50 --> Model Class Initialized
INFO - 2018-03-27 14:49:50 --> Model Class Initialized
INFO - 2018-03-27 14:49:50 --> Model Class Initialized
INFO - 2018-03-27 14:49:50 --> Model Class Initialized
INFO - 2018-03-27 14:49:50 --> Model Class Initialized
INFO - 2018-03-27 14:49:50 --> Model Class Initialized
INFO - 2018-03-27 14:49:50 --> Model Class Initialized
INFO - 2018-03-27 14:49:50 --> Model Class Initialized
INFO - 2018-03-27 14:49:50 --> Model Class Initialized
INFO - 2018-03-27 14:49:50 --> Model Class Initialized
INFO - 2018-03-27 14:49:50 --> Model Class Initialized
INFO - 2018-03-27 14:49:50 --> Model Class Initialized
INFO - 2018-03-27 14:49:50 --> Helper loaded: date_helper
INFO - 2018-03-27 14:49:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:49:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:49:50 --> Final output sent to browser
DEBUG - 2018-03-27 19:49:50 --> Total execution time: 0.1293
INFO - 2018-03-27 14:49:51 --> Config Class Initialized
INFO - 2018-03-27 14:49:51 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:49:51 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:49:51 --> Utf8 Class Initialized
INFO - 2018-03-27 14:49:51 --> URI Class Initialized
INFO - 2018-03-27 14:49:51 --> Router Class Initialized
INFO - 2018-03-27 14:49:51 --> Output Class Initialized
INFO - 2018-03-27 14:49:51 --> Security Class Initialized
DEBUG - 2018-03-27 14:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:49:51 --> Input Class Initialized
INFO - 2018-03-27 14:49:51 --> Language Class Initialized
INFO - 2018-03-27 14:49:51 --> Loader Class Initialized
INFO - 2018-03-27 14:49:51 --> Helper loaded: url_helper
INFO - 2018-03-27 14:49:51 --> Helper loaded: form_helper
INFO - 2018-03-27 14:49:51 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:49:51 --> Controller Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Helper loaded: date_helper
INFO - 2018-03-27 14:49:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:49:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:49:51 --> Final output sent to browser
DEBUG - 2018-03-27 19:49:51 --> Total execution time: 0.1395
INFO - 2018-03-27 14:49:51 --> Config Class Initialized
INFO - 2018-03-27 14:49:51 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:49:51 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:49:51 --> Utf8 Class Initialized
INFO - 2018-03-27 14:49:51 --> URI Class Initialized
INFO - 2018-03-27 14:49:51 --> Router Class Initialized
INFO - 2018-03-27 14:49:51 --> Output Class Initialized
INFO - 2018-03-27 14:49:51 --> Security Class Initialized
DEBUG - 2018-03-27 14:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:49:51 --> Input Class Initialized
INFO - 2018-03-27 14:49:51 --> Language Class Initialized
INFO - 2018-03-27 14:49:51 --> Loader Class Initialized
INFO - 2018-03-27 14:49:51 --> Helper loaded: url_helper
INFO - 2018-03-27 14:49:51 --> Helper loaded: form_helper
INFO - 2018-03-27 14:49:51 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:49:51 --> Controller Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Model Class Initialized
INFO - 2018-03-27 14:49:51 --> Helper loaded: date_helper
INFO - 2018-03-27 14:49:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:49:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:49:51 --> Final output sent to browser
DEBUG - 2018-03-27 19:49:51 --> Total execution time: 0.1016
INFO - 2018-03-27 14:50:03 --> Config Class Initialized
INFO - 2018-03-27 14:50:03 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:50:03 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:50:03 --> Utf8 Class Initialized
INFO - 2018-03-27 14:50:03 --> URI Class Initialized
INFO - 2018-03-27 14:50:03 --> Router Class Initialized
INFO - 2018-03-27 14:50:03 --> Output Class Initialized
INFO - 2018-03-27 14:50:03 --> Security Class Initialized
DEBUG - 2018-03-27 14:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:50:03 --> Input Class Initialized
INFO - 2018-03-27 14:50:03 --> Language Class Initialized
INFO - 2018-03-27 14:50:03 --> Loader Class Initialized
INFO - 2018-03-27 14:50:03 --> Helper loaded: url_helper
INFO - 2018-03-27 14:50:03 --> Helper loaded: form_helper
INFO - 2018-03-27 14:50:03 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:50:03 --> Controller Class Initialized
INFO - 2018-03-27 14:50:03 --> Model Class Initialized
INFO - 2018-03-27 14:50:03 --> Model Class Initialized
INFO - 2018-03-27 14:50:03 --> Model Class Initialized
INFO - 2018-03-27 14:50:03 --> Model Class Initialized
INFO - 2018-03-27 14:50:03 --> Model Class Initialized
INFO - 2018-03-27 14:50:03 --> Model Class Initialized
INFO - 2018-03-27 14:50:03 --> Model Class Initialized
INFO - 2018-03-27 14:50:03 --> Model Class Initialized
INFO - 2018-03-27 14:50:03 --> Model Class Initialized
INFO - 2018-03-27 14:50:03 --> Model Class Initialized
INFO - 2018-03-27 14:50:03 --> Model Class Initialized
INFO - 2018-03-27 14:50:03 --> Model Class Initialized
INFO - 2018-03-27 14:50:03 --> Model Class Initialized
INFO - 2018-03-27 14:50:03 --> Model Class Initialized
INFO - 2018-03-27 14:50:03 --> Model Class Initialized
INFO - 2018-03-27 14:50:03 --> Helper loaded: date_helper
INFO - 2018-03-27 14:50:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:50:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:50:03 --> Final output sent to browser
DEBUG - 2018-03-27 19:50:03 --> Total execution time: 0.1248
INFO - 2018-03-27 14:56:16 --> Config Class Initialized
INFO - 2018-03-27 14:56:16 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:56:16 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:56:16 --> Utf8 Class Initialized
INFO - 2018-03-27 14:56:16 --> URI Class Initialized
INFO - 2018-03-27 14:56:16 --> Router Class Initialized
INFO - 2018-03-27 14:56:16 --> Output Class Initialized
INFO - 2018-03-27 14:56:16 --> Security Class Initialized
DEBUG - 2018-03-27 14:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:56:16 --> Input Class Initialized
INFO - 2018-03-27 14:56:16 --> Language Class Initialized
INFO - 2018-03-27 14:56:16 --> Loader Class Initialized
INFO - 2018-03-27 14:56:16 --> Helper loaded: url_helper
INFO - 2018-03-27 14:56:16 --> Helper loaded: form_helper
INFO - 2018-03-27 14:56:16 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:56:16 --> Controller Class Initialized
INFO - 2018-03-27 14:56:16 --> Model Class Initialized
INFO - 2018-03-27 14:56:16 --> Model Class Initialized
INFO - 2018-03-27 14:56:16 --> Model Class Initialized
INFO - 2018-03-27 14:56:16 --> Model Class Initialized
INFO - 2018-03-27 14:56:16 --> Model Class Initialized
INFO - 2018-03-27 14:56:16 --> Model Class Initialized
INFO - 2018-03-27 14:56:16 --> Model Class Initialized
INFO - 2018-03-27 14:56:16 --> Model Class Initialized
INFO - 2018-03-27 14:56:16 --> Model Class Initialized
INFO - 2018-03-27 14:56:16 --> Model Class Initialized
INFO - 2018-03-27 14:56:16 --> Model Class Initialized
INFO - 2018-03-27 14:56:16 --> Model Class Initialized
INFO - 2018-03-27 14:56:16 --> Model Class Initialized
INFO - 2018-03-27 14:56:16 --> Model Class Initialized
INFO - 2018-03-27 14:56:16 --> Model Class Initialized
INFO - 2018-03-27 14:56:16 --> Helper loaded: date_helper
INFO - 2018-03-27 14:56:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:56:16 --> Model Class Initialized
INFO - 2018-03-27 19:56:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 19:56:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 19:56:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 19:56:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 19:56:16 --> Final output sent to browser
DEBUG - 2018-03-27 19:56:16 --> Total execution time: 0.1559
INFO - 2018-03-27 14:56:18 --> Config Class Initialized
INFO - 2018-03-27 14:56:18 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:56:18 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:56:18 --> Utf8 Class Initialized
INFO - 2018-03-27 14:56:18 --> URI Class Initialized
INFO - 2018-03-27 14:56:18 --> Router Class Initialized
INFO - 2018-03-27 14:56:18 --> Output Class Initialized
INFO - 2018-03-27 14:56:18 --> Security Class Initialized
DEBUG - 2018-03-27 14:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:56:18 --> Input Class Initialized
INFO - 2018-03-27 14:56:18 --> Language Class Initialized
INFO - 2018-03-27 14:56:18 --> Loader Class Initialized
INFO - 2018-03-27 14:56:18 --> Helper loaded: url_helper
INFO - 2018-03-27 14:56:18 --> Helper loaded: form_helper
INFO - 2018-03-27 14:56:18 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:56:18 --> Controller Class Initialized
INFO - 2018-03-27 14:56:18 --> Model Class Initialized
INFO - 2018-03-27 14:56:18 --> Model Class Initialized
INFO - 2018-03-27 14:56:18 --> Model Class Initialized
INFO - 2018-03-27 14:56:18 --> Model Class Initialized
INFO - 2018-03-27 14:56:18 --> Model Class Initialized
INFO - 2018-03-27 14:56:18 --> Model Class Initialized
INFO - 2018-03-27 14:56:18 --> Model Class Initialized
INFO - 2018-03-27 14:56:18 --> Model Class Initialized
INFO - 2018-03-27 14:56:18 --> Model Class Initialized
INFO - 2018-03-27 14:56:18 --> Model Class Initialized
INFO - 2018-03-27 14:56:18 --> Model Class Initialized
INFO - 2018-03-27 14:56:18 --> Model Class Initialized
INFO - 2018-03-27 14:56:18 --> Model Class Initialized
INFO - 2018-03-27 14:56:18 --> Model Class Initialized
INFO - 2018-03-27 14:56:18 --> Model Class Initialized
INFO - 2018-03-27 14:56:18 --> Helper loaded: date_helper
INFO - 2018-03-27 14:56:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:56:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:56:18 --> Final output sent to browser
DEBUG - 2018-03-27 19:56:18 --> Total execution time: 0.1809
INFO - 2018-03-27 14:56:19 --> Config Class Initialized
INFO - 2018-03-27 14:56:19 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:56:19 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:56:19 --> Utf8 Class Initialized
INFO - 2018-03-27 14:56:19 --> URI Class Initialized
INFO - 2018-03-27 14:56:19 --> Router Class Initialized
INFO - 2018-03-27 14:56:19 --> Output Class Initialized
INFO - 2018-03-27 14:56:19 --> Security Class Initialized
DEBUG - 2018-03-27 14:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:56:19 --> Input Class Initialized
INFO - 2018-03-27 14:56:19 --> Language Class Initialized
INFO - 2018-03-27 14:56:19 --> Loader Class Initialized
INFO - 2018-03-27 14:56:19 --> Helper loaded: url_helper
INFO - 2018-03-27 14:56:19 --> Helper loaded: form_helper
INFO - 2018-03-27 14:56:19 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:56:19 --> Controller Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Helper loaded: date_helper
INFO - 2018-03-27 14:56:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:56:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:56:19 --> Final output sent to browser
DEBUG - 2018-03-27 19:56:19 --> Total execution time: 0.1673
INFO - 2018-03-27 14:56:19 --> Config Class Initialized
INFO - 2018-03-27 14:56:19 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:56:19 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:56:19 --> Utf8 Class Initialized
INFO - 2018-03-27 14:56:19 --> URI Class Initialized
INFO - 2018-03-27 14:56:19 --> Router Class Initialized
INFO - 2018-03-27 14:56:19 --> Output Class Initialized
INFO - 2018-03-27 14:56:19 --> Security Class Initialized
DEBUG - 2018-03-27 14:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:56:19 --> Input Class Initialized
INFO - 2018-03-27 14:56:19 --> Language Class Initialized
INFO - 2018-03-27 14:56:19 --> Loader Class Initialized
INFO - 2018-03-27 14:56:19 --> Helper loaded: url_helper
INFO - 2018-03-27 14:56:19 --> Helper loaded: form_helper
INFO - 2018-03-27 14:56:19 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:56:19 --> Controller Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Model Class Initialized
INFO - 2018-03-27 14:56:19 --> Helper loaded: date_helper
INFO - 2018-03-27 14:56:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:56:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:56:19 --> Final output sent to browser
DEBUG - 2018-03-27 19:56:19 --> Total execution time: 0.1270
INFO - 2018-03-27 14:56:20 --> Config Class Initialized
INFO - 2018-03-27 14:56:20 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:56:20 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:56:20 --> Utf8 Class Initialized
INFO - 2018-03-27 14:56:20 --> URI Class Initialized
INFO - 2018-03-27 14:56:20 --> Router Class Initialized
INFO - 2018-03-27 14:56:20 --> Output Class Initialized
INFO - 2018-03-27 14:56:20 --> Security Class Initialized
DEBUG - 2018-03-27 14:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:56:20 --> Input Class Initialized
INFO - 2018-03-27 14:56:20 --> Language Class Initialized
INFO - 2018-03-27 14:56:20 --> Loader Class Initialized
INFO - 2018-03-27 14:56:20 --> Helper loaded: url_helper
INFO - 2018-03-27 14:56:20 --> Helper loaded: form_helper
INFO - 2018-03-27 14:56:20 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:56:20 --> Controller Class Initialized
INFO - 2018-03-27 14:56:20 --> Model Class Initialized
INFO - 2018-03-27 14:56:20 --> Model Class Initialized
INFO - 2018-03-27 14:56:20 --> Model Class Initialized
INFO - 2018-03-27 14:56:20 --> Model Class Initialized
INFO - 2018-03-27 14:56:20 --> Model Class Initialized
INFO - 2018-03-27 14:56:20 --> Model Class Initialized
INFO - 2018-03-27 14:56:20 --> Model Class Initialized
INFO - 2018-03-27 14:56:20 --> Model Class Initialized
INFO - 2018-03-27 14:56:20 --> Model Class Initialized
INFO - 2018-03-27 14:56:20 --> Model Class Initialized
INFO - 2018-03-27 14:56:20 --> Model Class Initialized
INFO - 2018-03-27 14:56:20 --> Model Class Initialized
INFO - 2018-03-27 14:56:20 --> Model Class Initialized
INFO - 2018-03-27 14:56:20 --> Model Class Initialized
INFO - 2018-03-27 14:56:20 --> Model Class Initialized
INFO - 2018-03-27 14:56:20 --> Helper loaded: date_helper
INFO - 2018-03-27 14:56:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:56:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:56:20 --> Final output sent to browser
DEBUG - 2018-03-27 19:56:20 --> Total execution time: 0.1124
INFO - 2018-03-27 14:56:28 --> Config Class Initialized
INFO - 2018-03-27 14:56:28 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:56:28 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:56:28 --> Utf8 Class Initialized
INFO - 2018-03-27 14:56:28 --> URI Class Initialized
INFO - 2018-03-27 14:56:28 --> Router Class Initialized
INFO - 2018-03-27 14:56:28 --> Output Class Initialized
INFO - 2018-03-27 14:56:28 --> Security Class Initialized
DEBUG - 2018-03-27 14:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:56:28 --> Input Class Initialized
INFO - 2018-03-27 14:56:28 --> Language Class Initialized
INFO - 2018-03-27 14:56:28 --> Loader Class Initialized
INFO - 2018-03-27 14:56:28 --> Helper loaded: url_helper
INFO - 2018-03-27 14:56:28 --> Helper loaded: form_helper
INFO - 2018-03-27 14:56:28 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:56:28 --> Controller Class Initialized
INFO - 2018-03-27 14:56:28 --> Model Class Initialized
INFO - 2018-03-27 14:56:28 --> Model Class Initialized
INFO - 2018-03-27 14:56:28 --> Model Class Initialized
INFO - 2018-03-27 14:56:28 --> Model Class Initialized
INFO - 2018-03-27 14:56:28 --> Model Class Initialized
INFO - 2018-03-27 14:56:28 --> Model Class Initialized
INFO - 2018-03-27 14:56:28 --> Model Class Initialized
INFO - 2018-03-27 14:56:28 --> Model Class Initialized
INFO - 2018-03-27 14:56:28 --> Model Class Initialized
INFO - 2018-03-27 14:56:28 --> Model Class Initialized
INFO - 2018-03-27 14:56:28 --> Model Class Initialized
INFO - 2018-03-27 14:56:28 --> Model Class Initialized
INFO - 2018-03-27 14:56:28 --> Model Class Initialized
INFO - 2018-03-27 14:56:28 --> Model Class Initialized
INFO - 2018-03-27 14:56:28 --> Model Class Initialized
INFO - 2018-03-27 14:56:28 --> Helper loaded: date_helper
INFO - 2018-03-27 14:56:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:56:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:56:28 --> Final output sent to browser
DEBUG - 2018-03-27 19:56:28 --> Total execution time: 0.1682
INFO - 2018-03-27 14:56:33 --> Config Class Initialized
INFO - 2018-03-27 14:56:33 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:56:33 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:56:33 --> Utf8 Class Initialized
INFO - 2018-03-27 14:56:33 --> URI Class Initialized
INFO - 2018-03-27 14:56:33 --> Router Class Initialized
INFO - 2018-03-27 14:56:33 --> Output Class Initialized
INFO - 2018-03-27 14:56:33 --> Security Class Initialized
DEBUG - 2018-03-27 14:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:56:33 --> Input Class Initialized
INFO - 2018-03-27 14:56:33 --> Language Class Initialized
INFO - 2018-03-27 14:56:33 --> Loader Class Initialized
INFO - 2018-03-27 14:56:33 --> Helper loaded: url_helper
INFO - 2018-03-27 14:56:33 --> Helper loaded: form_helper
INFO - 2018-03-27 14:56:33 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:56:33 --> Controller Class Initialized
INFO - 2018-03-27 14:56:33 --> Model Class Initialized
INFO - 2018-03-27 14:56:33 --> Model Class Initialized
INFO - 2018-03-27 14:56:33 --> Model Class Initialized
INFO - 2018-03-27 14:56:33 --> Model Class Initialized
INFO - 2018-03-27 14:56:33 --> Model Class Initialized
INFO - 2018-03-27 14:56:33 --> Model Class Initialized
INFO - 2018-03-27 14:56:33 --> Model Class Initialized
INFO - 2018-03-27 14:56:33 --> Model Class Initialized
INFO - 2018-03-27 14:56:33 --> Model Class Initialized
INFO - 2018-03-27 14:56:33 --> Model Class Initialized
INFO - 2018-03-27 14:56:33 --> Model Class Initialized
INFO - 2018-03-27 14:56:33 --> Model Class Initialized
INFO - 2018-03-27 14:56:33 --> Model Class Initialized
INFO - 2018-03-27 14:56:33 --> Model Class Initialized
INFO - 2018-03-27 14:56:33 --> Model Class Initialized
INFO - 2018-03-27 14:56:33 --> Helper loaded: date_helper
INFO - 2018-03-27 14:56:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:56:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:56:33 --> Final output sent to browser
DEBUG - 2018-03-27 19:56:33 --> Total execution time: 0.1605
INFO - 2018-03-27 14:56:36 --> Config Class Initialized
INFO - 2018-03-27 14:56:36 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:56:36 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:56:36 --> Utf8 Class Initialized
INFO - 2018-03-27 14:56:36 --> URI Class Initialized
INFO - 2018-03-27 14:56:36 --> Router Class Initialized
INFO - 2018-03-27 14:56:36 --> Output Class Initialized
INFO - 2018-03-27 14:56:36 --> Security Class Initialized
DEBUG - 2018-03-27 14:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:56:36 --> Input Class Initialized
INFO - 2018-03-27 14:56:36 --> Language Class Initialized
INFO - 2018-03-27 14:56:36 --> Loader Class Initialized
INFO - 2018-03-27 14:56:36 --> Helper loaded: url_helper
INFO - 2018-03-27 14:56:36 --> Helper loaded: form_helper
INFO - 2018-03-27 14:56:36 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:56:36 --> Controller Class Initialized
INFO - 2018-03-27 14:56:36 --> Model Class Initialized
INFO - 2018-03-27 14:56:36 --> Model Class Initialized
INFO - 2018-03-27 14:56:36 --> Model Class Initialized
INFO - 2018-03-27 14:56:36 --> Model Class Initialized
INFO - 2018-03-27 14:56:36 --> Model Class Initialized
INFO - 2018-03-27 14:56:36 --> Model Class Initialized
INFO - 2018-03-27 14:56:36 --> Model Class Initialized
INFO - 2018-03-27 14:56:36 --> Model Class Initialized
INFO - 2018-03-27 14:56:36 --> Model Class Initialized
INFO - 2018-03-27 14:56:36 --> Model Class Initialized
INFO - 2018-03-27 14:56:36 --> Model Class Initialized
INFO - 2018-03-27 14:56:36 --> Model Class Initialized
INFO - 2018-03-27 14:56:36 --> Model Class Initialized
INFO - 2018-03-27 14:56:36 --> Model Class Initialized
INFO - 2018-03-27 14:56:36 --> Model Class Initialized
INFO - 2018-03-27 14:56:36 --> Helper loaded: date_helper
INFO - 2018-03-27 14:56:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:56:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:56:36 --> Final output sent to browser
DEBUG - 2018-03-27 19:56:36 --> Total execution time: 0.1698
INFO - 2018-03-27 14:57:00 --> Config Class Initialized
INFO - 2018-03-27 14:57:00 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:57:00 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:57:00 --> Utf8 Class Initialized
INFO - 2018-03-27 14:57:00 --> URI Class Initialized
INFO - 2018-03-27 14:57:00 --> Router Class Initialized
INFO - 2018-03-27 14:57:00 --> Output Class Initialized
INFO - 2018-03-27 14:57:00 --> Security Class Initialized
DEBUG - 2018-03-27 14:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:57:00 --> Input Class Initialized
INFO - 2018-03-27 14:57:00 --> Language Class Initialized
INFO - 2018-03-27 14:57:00 --> Loader Class Initialized
INFO - 2018-03-27 14:57:00 --> Helper loaded: url_helper
INFO - 2018-03-27 14:57:00 --> Helper loaded: form_helper
INFO - 2018-03-27 14:57:00 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:57:00 --> Controller Class Initialized
INFO - 2018-03-27 14:57:00 --> Model Class Initialized
INFO - 2018-03-27 14:57:00 --> Model Class Initialized
INFO - 2018-03-27 14:57:00 --> Model Class Initialized
INFO - 2018-03-27 14:57:00 --> Model Class Initialized
INFO - 2018-03-27 14:57:00 --> Model Class Initialized
INFO - 2018-03-27 14:57:00 --> Model Class Initialized
INFO - 2018-03-27 14:57:00 --> Model Class Initialized
INFO - 2018-03-27 14:57:00 --> Model Class Initialized
INFO - 2018-03-27 14:57:00 --> Model Class Initialized
INFO - 2018-03-27 14:57:00 --> Model Class Initialized
INFO - 2018-03-27 14:57:00 --> Model Class Initialized
INFO - 2018-03-27 14:57:00 --> Model Class Initialized
INFO - 2018-03-27 14:57:00 --> Model Class Initialized
INFO - 2018-03-27 14:57:00 --> Model Class Initialized
INFO - 2018-03-27 14:57:00 --> Model Class Initialized
INFO - 2018-03-27 14:57:00 --> Helper loaded: date_helper
INFO - 2018-03-27 14:57:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:57:00 --> Model Class Initialized
INFO - 2018-03-27 19:57:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 19:57:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 19:57:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 19:57:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 19:57:00 --> Final output sent to browser
DEBUG - 2018-03-27 19:57:00 --> Total execution time: 0.1130
INFO - 2018-03-27 14:57:10 --> Config Class Initialized
INFO - 2018-03-27 14:57:10 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:57:10 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:57:10 --> Utf8 Class Initialized
INFO - 2018-03-27 14:57:10 --> URI Class Initialized
INFO - 2018-03-27 14:57:10 --> Router Class Initialized
INFO - 2018-03-27 14:57:10 --> Output Class Initialized
INFO - 2018-03-27 14:57:10 --> Security Class Initialized
DEBUG - 2018-03-27 14:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:57:10 --> Input Class Initialized
INFO - 2018-03-27 14:57:10 --> Language Class Initialized
INFO - 2018-03-27 14:57:10 --> Loader Class Initialized
INFO - 2018-03-27 14:57:10 --> Helper loaded: url_helper
INFO - 2018-03-27 14:57:10 --> Helper loaded: form_helper
INFO - 2018-03-27 14:57:10 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:57:10 --> Controller Class Initialized
INFO - 2018-03-27 14:57:10 --> Model Class Initialized
INFO - 2018-03-27 14:57:10 --> Model Class Initialized
INFO - 2018-03-27 14:57:10 --> Model Class Initialized
INFO - 2018-03-27 14:57:10 --> Model Class Initialized
INFO - 2018-03-27 14:57:10 --> Model Class Initialized
INFO - 2018-03-27 14:57:10 --> Model Class Initialized
INFO - 2018-03-27 14:57:10 --> Model Class Initialized
INFO - 2018-03-27 14:57:10 --> Model Class Initialized
INFO - 2018-03-27 14:57:10 --> Model Class Initialized
INFO - 2018-03-27 14:57:10 --> Model Class Initialized
INFO - 2018-03-27 14:57:10 --> Model Class Initialized
INFO - 2018-03-27 14:57:10 --> Model Class Initialized
INFO - 2018-03-27 14:57:10 --> Model Class Initialized
INFO - 2018-03-27 14:57:10 --> Model Class Initialized
INFO - 2018-03-27 14:57:10 --> Model Class Initialized
INFO - 2018-03-27 14:57:10 --> Helper loaded: date_helper
INFO - 2018-03-27 14:57:10 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:57:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:57:10 --> Final output sent to browser
DEBUG - 2018-03-27 19:57:10 --> Total execution time: 0.1179
INFO - 2018-03-27 14:57:16 --> Config Class Initialized
INFO - 2018-03-27 14:57:16 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:57:16 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:57:16 --> Utf8 Class Initialized
INFO - 2018-03-27 14:57:16 --> URI Class Initialized
INFO - 2018-03-27 14:57:16 --> Router Class Initialized
INFO - 2018-03-27 14:57:16 --> Output Class Initialized
INFO - 2018-03-27 14:57:16 --> Security Class Initialized
DEBUG - 2018-03-27 14:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:57:16 --> Input Class Initialized
INFO - 2018-03-27 14:57:16 --> Language Class Initialized
INFO - 2018-03-27 14:57:16 --> Loader Class Initialized
INFO - 2018-03-27 14:57:16 --> Helper loaded: url_helper
INFO - 2018-03-27 14:57:16 --> Helper loaded: form_helper
INFO - 2018-03-27 14:57:16 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:57:16 --> Controller Class Initialized
INFO - 2018-03-27 14:57:16 --> Model Class Initialized
INFO - 2018-03-27 14:57:16 --> Model Class Initialized
INFO - 2018-03-27 14:57:16 --> Model Class Initialized
INFO - 2018-03-27 14:57:16 --> Model Class Initialized
INFO - 2018-03-27 14:57:16 --> Model Class Initialized
INFO - 2018-03-27 14:57:16 --> Model Class Initialized
INFO - 2018-03-27 14:57:16 --> Model Class Initialized
INFO - 2018-03-27 14:57:16 --> Model Class Initialized
INFO - 2018-03-27 14:57:16 --> Model Class Initialized
INFO - 2018-03-27 14:57:16 --> Model Class Initialized
INFO - 2018-03-27 14:57:16 --> Model Class Initialized
INFO - 2018-03-27 14:57:16 --> Model Class Initialized
INFO - 2018-03-27 14:57:16 --> Model Class Initialized
INFO - 2018-03-27 14:57:16 --> Model Class Initialized
INFO - 2018-03-27 14:57:16 --> Model Class Initialized
INFO - 2018-03-27 14:57:16 --> Helper loaded: date_helper
INFO - 2018-03-27 14:57:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:57:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:57:16 --> Final output sent to browser
DEBUG - 2018-03-27 19:57:16 --> Total execution time: 0.1335
INFO - 2018-03-27 14:57:21 --> Config Class Initialized
INFO - 2018-03-27 14:57:21 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:57:21 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:57:21 --> Utf8 Class Initialized
INFO - 2018-03-27 14:57:21 --> URI Class Initialized
INFO - 2018-03-27 14:57:21 --> Router Class Initialized
INFO - 2018-03-27 14:57:21 --> Output Class Initialized
INFO - 2018-03-27 14:57:21 --> Security Class Initialized
DEBUG - 2018-03-27 14:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:57:21 --> Input Class Initialized
INFO - 2018-03-27 14:57:21 --> Language Class Initialized
INFO - 2018-03-27 14:57:21 --> Loader Class Initialized
INFO - 2018-03-27 14:57:21 --> Helper loaded: url_helper
INFO - 2018-03-27 14:57:21 --> Helper loaded: form_helper
INFO - 2018-03-27 14:57:21 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:57:21 --> Controller Class Initialized
INFO - 2018-03-27 14:57:21 --> Model Class Initialized
INFO - 2018-03-27 14:57:21 --> Model Class Initialized
INFO - 2018-03-27 14:57:21 --> Model Class Initialized
INFO - 2018-03-27 14:57:21 --> Model Class Initialized
INFO - 2018-03-27 14:57:21 --> Model Class Initialized
INFO - 2018-03-27 14:57:21 --> Model Class Initialized
INFO - 2018-03-27 14:57:21 --> Model Class Initialized
INFO - 2018-03-27 14:57:21 --> Model Class Initialized
INFO - 2018-03-27 14:57:21 --> Model Class Initialized
INFO - 2018-03-27 14:57:21 --> Model Class Initialized
INFO - 2018-03-27 14:57:21 --> Model Class Initialized
INFO - 2018-03-27 14:57:21 --> Model Class Initialized
INFO - 2018-03-27 14:57:21 --> Model Class Initialized
INFO - 2018-03-27 14:57:21 --> Model Class Initialized
INFO - 2018-03-27 14:57:21 --> Model Class Initialized
INFO - 2018-03-27 14:57:21 --> Helper loaded: date_helper
INFO - 2018-03-27 14:57:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:57:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:57:21 --> Final output sent to browser
DEBUG - 2018-03-27 19:57:21 --> Total execution time: 0.1324
INFO - 2018-03-27 14:57:24 --> Config Class Initialized
INFO - 2018-03-27 14:57:24 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:57:24 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:57:24 --> Utf8 Class Initialized
INFO - 2018-03-27 14:57:24 --> URI Class Initialized
INFO - 2018-03-27 14:57:24 --> Router Class Initialized
INFO - 2018-03-27 14:57:24 --> Output Class Initialized
INFO - 2018-03-27 14:57:24 --> Security Class Initialized
DEBUG - 2018-03-27 14:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:57:24 --> Input Class Initialized
INFO - 2018-03-27 14:57:24 --> Language Class Initialized
INFO - 2018-03-27 14:57:24 --> Loader Class Initialized
INFO - 2018-03-27 14:57:24 --> Helper loaded: url_helper
INFO - 2018-03-27 14:57:24 --> Helper loaded: form_helper
INFO - 2018-03-27 14:57:24 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:57:24 --> Controller Class Initialized
INFO - 2018-03-27 14:57:24 --> Model Class Initialized
INFO - 2018-03-27 14:57:24 --> Model Class Initialized
INFO - 2018-03-27 14:57:24 --> Model Class Initialized
INFO - 2018-03-27 14:57:24 --> Model Class Initialized
INFO - 2018-03-27 14:57:24 --> Model Class Initialized
INFO - 2018-03-27 14:57:24 --> Model Class Initialized
INFO - 2018-03-27 14:57:24 --> Model Class Initialized
INFO - 2018-03-27 14:57:24 --> Model Class Initialized
INFO - 2018-03-27 14:57:24 --> Model Class Initialized
INFO - 2018-03-27 14:57:24 --> Model Class Initialized
INFO - 2018-03-27 14:57:24 --> Model Class Initialized
INFO - 2018-03-27 14:57:24 --> Model Class Initialized
INFO - 2018-03-27 14:57:24 --> Model Class Initialized
INFO - 2018-03-27 14:57:24 --> Model Class Initialized
INFO - 2018-03-27 14:57:24 --> Model Class Initialized
INFO - 2018-03-27 14:57:24 --> Helper loaded: date_helper
INFO - 2018-03-27 14:57:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:57:24 --> Model Class Initialized
INFO - 2018-03-27 19:57:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 19:57:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 19:57:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 19:57:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 19:57:24 --> Final output sent to browser
DEBUG - 2018-03-27 19:57:24 --> Total execution time: 0.1359
INFO - 2018-03-27 14:57:32 --> Config Class Initialized
INFO - 2018-03-27 14:57:32 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:57:32 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:57:32 --> Utf8 Class Initialized
INFO - 2018-03-27 14:57:32 --> URI Class Initialized
INFO - 2018-03-27 14:57:32 --> Router Class Initialized
INFO - 2018-03-27 14:57:32 --> Output Class Initialized
INFO - 2018-03-27 14:57:32 --> Security Class Initialized
DEBUG - 2018-03-27 14:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:57:32 --> Input Class Initialized
INFO - 2018-03-27 14:57:32 --> Language Class Initialized
INFO - 2018-03-27 14:57:32 --> Loader Class Initialized
INFO - 2018-03-27 14:57:32 --> Helper loaded: url_helper
INFO - 2018-03-27 14:57:32 --> Helper loaded: form_helper
INFO - 2018-03-27 14:57:32 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:57:32 --> Controller Class Initialized
INFO - 2018-03-27 14:57:32 --> Model Class Initialized
INFO - 2018-03-27 14:57:32 --> Model Class Initialized
INFO - 2018-03-27 14:57:32 --> Model Class Initialized
INFO - 2018-03-27 14:57:32 --> Model Class Initialized
INFO - 2018-03-27 14:57:32 --> Model Class Initialized
INFO - 2018-03-27 14:57:32 --> Model Class Initialized
INFO - 2018-03-27 14:57:32 --> Model Class Initialized
INFO - 2018-03-27 14:57:32 --> Model Class Initialized
INFO - 2018-03-27 14:57:32 --> Model Class Initialized
INFO - 2018-03-27 14:57:32 --> Model Class Initialized
INFO - 2018-03-27 14:57:32 --> Model Class Initialized
INFO - 2018-03-27 14:57:32 --> Model Class Initialized
INFO - 2018-03-27 14:57:32 --> Model Class Initialized
INFO - 2018-03-27 14:57:32 --> Model Class Initialized
INFO - 2018-03-27 14:57:32 --> Model Class Initialized
INFO - 2018-03-27 14:57:32 --> Helper loaded: date_helper
INFO - 2018-03-27 14:57:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:57:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:57:32 --> Final output sent to browser
DEBUG - 2018-03-27 19:57:32 --> Total execution time: 0.1414
INFO - 2018-03-27 14:57:37 --> Config Class Initialized
INFO - 2018-03-27 14:57:37 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:57:37 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:57:37 --> Utf8 Class Initialized
INFO - 2018-03-27 14:57:37 --> URI Class Initialized
INFO - 2018-03-27 14:57:37 --> Router Class Initialized
INFO - 2018-03-27 14:57:37 --> Output Class Initialized
INFO - 2018-03-27 14:57:37 --> Security Class Initialized
DEBUG - 2018-03-27 14:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:57:37 --> Input Class Initialized
INFO - 2018-03-27 14:57:37 --> Language Class Initialized
INFO - 2018-03-27 14:57:37 --> Loader Class Initialized
INFO - 2018-03-27 14:57:37 --> Helper loaded: url_helper
INFO - 2018-03-27 14:57:37 --> Helper loaded: form_helper
INFO - 2018-03-27 14:57:37 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:57:37 --> Controller Class Initialized
INFO - 2018-03-27 14:57:37 --> Model Class Initialized
INFO - 2018-03-27 14:57:37 --> Model Class Initialized
INFO - 2018-03-27 14:57:37 --> Model Class Initialized
INFO - 2018-03-27 14:57:37 --> Model Class Initialized
INFO - 2018-03-27 14:57:37 --> Model Class Initialized
INFO - 2018-03-27 14:57:37 --> Model Class Initialized
INFO - 2018-03-27 14:57:37 --> Model Class Initialized
INFO - 2018-03-27 14:57:37 --> Model Class Initialized
INFO - 2018-03-27 14:57:37 --> Model Class Initialized
INFO - 2018-03-27 14:57:37 --> Model Class Initialized
INFO - 2018-03-27 14:57:37 --> Model Class Initialized
INFO - 2018-03-27 14:57:37 --> Model Class Initialized
INFO - 2018-03-27 14:57:37 --> Model Class Initialized
INFO - 2018-03-27 14:57:37 --> Model Class Initialized
INFO - 2018-03-27 14:57:37 --> Model Class Initialized
INFO - 2018-03-27 14:57:37 --> Helper loaded: date_helper
INFO - 2018-03-27 14:57:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:57:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:57:37 --> Final output sent to browser
DEBUG - 2018-03-27 19:57:37 --> Total execution time: 0.1139
INFO - 2018-03-27 14:57:43 --> Config Class Initialized
INFO - 2018-03-27 14:57:43 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:57:43 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:57:43 --> Utf8 Class Initialized
INFO - 2018-03-27 14:57:43 --> URI Class Initialized
INFO - 2018-03-27 14:57:43 --> Router Class Initialized
INFO - 2018-03-27 14:57:43 --> Output Class Initialized
INFO - 2018-03-27 14:57:43 --> Security Class Initialized
DEBUG - 2018-03-27 14:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:57:43 --> Input Class Initialized
INFO - 2018-03-27 14:57:43 --> Language Class Initialized
INFO - 2018-03-27 14:57:43 --> Loader Class Initialized
INFO - 2018-03-27 14:57:43 --> Helper loaded: url_helper
INFO - 2018-03-27 14:57:43 --> Helper loaded: form_helper
INFO - 2018-03-27 14:57:43 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:57:43 --> Controller Class Initialized
INFO - 2018-03-27 14:57:43 --> Model Class Initialized
INFO - 2018-03-27 14:57:43 --> Model Class Initialized
INFO - 2018-03-27 14:57:43 --> Model Class Initialized
INFO - 2018-03-27 14:57:43 --> Model Class Initialized
INFO - 2018-03-27 14:57:43 --> Model Class Initialized
INFO - 2018-03-27 14:57:43 --> Model Class Initialized
INFO - 2018-03-27 14:57:43 --> Model Class Initialized
INFO - 2018-03-27 14:57:43 --> Model Class Initialized
INFO - 2018-03-27 14:57:43 --> Model Class Initialized
INFO - 2018-03-27 14:57:43 --> Model Class Initialized
INFO - 2018-03-27 14:57:43 --> Model Class Initialized
INFO - 2018-03-27 14:57:43 --> Model Class Initialized
INFO - 2018-03-27 14:57:43 --> Model Class Initialized
INFO - 2018-03-27 14:57:43 --> Model Class Initialized
INFO - 2018-03-27 14:57:43 --> Model Class Initialized
INFO - 2018-03-27 14:57:43 --> Helper loaded: date_helper
INFO - 2018-03-27 14:57:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:57:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:57:43 --> Final output sent to browser
DEBUG - 2018-03-27 19:57:43 --> Total execution time: 0.1313
INFO - 2018-03-27 14:57:52 --> Config Class Initialized
INFO - 2018-03-27 14:57:52 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:57:52 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:57:52 --> Utf8 Class Initialized
INFO - 2018-03-27 14:57:52 --> URI Class Initialized
INFO - 2018-03-27 14:57:52 --> Router Class Initialized
INFO - 2018-03-27 14:57:52 --> Output Class Initialized
INFO - 2018-03-27 14:57:52 --> Security Class Initialized
DEBUG - 2018-03-27 14:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:57:52 --> Input Class Initialized
INFO - 2018-03-27 14:57:52 --> Language Class Initialized
INFO - 2018-03-27 14:57:52 --> Loader Class Initialized
INFO - 2018-03-27 14:57:52 --> Helper loaded: url_helper
INFO - 2018-03-27 14:57:52 --> Helper loaded: form_helper
INFO - 2018-03-27 14:57:52 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:57:52 --> Controller Class Initialized
INFO - 2018-03-27 14:57:52 --> Model Class Initialized
INFO - 2018-03-27 14:57:52 --> Model Class Initialized
INFO - 2018-03-27 14:57:52 --> Model Class Initialized
INFO - 2018-03-27 14:57:52 --> Model Class Initialized
INFO - 2018-03-27 14:57:52 --> Model Class Initialized
INFO - 2018-03-27 14:57:52 --> Model Class Initialized
INFO - 2018-03-27 14:57:52 --> Model Class Initialized
INFO - 2018-03-27 14:57:52 --> Model Class Initialized
INFO - 2018-03-27 14:57:52 --> Model Class Initialized
INFO - 2018-03-27 14:57:52 --> Model Class Initialized
INFO - 2018-03-27 14:57:52 --> Model Class Initialized
INFO - 2018-03-27 14:57:52 --> Model Class Initialized
INFO - 2018-03-27 14:57:52 --> Model Class Initialized
INFO - 2018-03-27 14:57:52 --> Model Class Initialized
INFO - 2018-03-27 14:57:52 --> Model Class Initialized
INFO - 2018-03-27 14:57:52 --> Helper loaded: date_helper
INFO - 2018-03-27 14:57:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:57:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:57:52 --> Final output sent to browser
DEBUG - 2018-03-27 19:57:52 --> Total execution time: 0.1364
INFO - 2018-03-27 14:57:57 --> Config Class Initialized
INFO - 2018-03-27 14:57:57 --> Hooks Class Initialized
DEBUG - 2018-03-27 14:57:57 --> UTF-8 Support Enabled
INFO - 2018-03-27 14:57:57 --> Utf8 Class Initialized
INFO - 2018-03-27 14:57:57 --> URI Class Initialized
INFO - 2018-03-27 14:57:57 --> Router Class Initialized
INFO - 2018-03-27 14:57:57 --> Output Class Initialized
INFO - 2018-03-27 14:57:57 --> Security Class Initialized
DEBUG - 2018-03-27 14:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 14:57:57 --> Input Class Initialized
INFO - 2018-03-27 14:57:57 --> Language Class Initialized
INFO - 2018-03-27 14:57:57 --> Loader Class Initialized
INFO - 2018-03-27 14:57:57 --> Helper loaded: url_helper
INFO - 2018-03-27 14:57:57 --> Helper loaded: form_helper
INFO - 2018-03-27 14:57:57 --> Database Driver Class Initialized
DEBUG - 2018-03-27 14:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 14:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 14:57:57 --> Controller Class Initialized
INFO - 2018-03-27 14:57:57 --> Model Class Initialized
INFO - 2018-03-27 14:57:57 --> Model Class Initialized
INFO - 2018-03-27 14:57:57 --> Model Class Initialized
INFO - 2018-03-27 14:57:57 --> Model Class Initialized
INFO - 2018-03-27 14:57:57 --> Model Class Initialized
INFO - 2018-03-27 14:57:57 --> Model Class Initialized
INFO - 2018-03-27 14:57:57 --> Model Class Initialized
INFO - 2018-03-27 14:57:57 --> Model Class Initialized
INFO - 2018-03-27 14:57:57 --> Model Class Initialized
INFO - 2018-03-27 14:57:57 --> Model Class Initialized
INFO - 2018-03-27 14:57:57 --> Model Class Initialized
INFO - 2018-03-27 14:57:57 --> Model Class Initialized
INFO - 2018-03-27 14:57:57 --> Model Class Initialized
INFO - 2018-03-27 14:57:57 --> Model Class Initialized
INFO - 2018-03-27 14:57:57 --> Model Class Initialized
INFO - 2018-03-27 14:57:57 --> Helper loaded: date_helper
INFO - 2018-03-27 14:57:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 19:57:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 19:57:57 --> Final output sent to browser
DEBUG - 2018-03-27 19:57:57 --> Total execution time: 0.1045
INFO - 2018-03-27 15:00:02 --> Config Class Initialized
INFO - 2018-03-27 15:00:02 --> Hooks Class Initialized
DEBUG - 2018-03-27 15:00:02 --> UTF-8 Support Enabled
INFO - 2018-03-27 15:00:02 --> Utf8 Class Initialized
INFO - 2018-03-27 15:00:02 --> URI Class Initialized
INFO - 2018-03-27 15:00:02 --> Router Class Initialized
INFO - 2018-03-27 15:00:02 --> Output Class Initialized
INFO - 2018-03-27 15:00:02 --> Security Class Initialized
DEBUG - 2018-03-27 15:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 15:00:02 --> Input Class Initialized
INFO - 2018-03-27 15:00:02 --> Language Class Initialized
INFO - 2018-03-27 15:00:02 --> Loader Class Initialized
INFO - 2018-03-27 15:00:02 --> Helper loaded: url_helper
INFO - 2018-03-27 15:00:02 --> Helper loaded: form_helper
INFO - 2018-03-27 15:00:02 --> Database Driver Class Initialized
DEBUG - 2018-03-27 15:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 15:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 15:00:02 --> Controller Class Initialized
INFO - 2018-03-27 15:00:02 --> Model Class Initialized
INFO - 2018-03-27 15:00:02 --> Model Class Initialized
INFO - 2018-03-27 15:00:02 --> Model Class Initialized
INFO - 2018-03-27 15:00:02 --> Model Class Initialized
INFO - 2018-03-27 15:00:02 --> Model Class Initialized
INFO - 2018-03-27 15:00:02 --> Model Class Initialized
INFO - 2018-03-27 15:00:02 --> Model Class Initialized
INFO - 2018-03-27 15:00:02 --> Model Class Initialized
INFO - 2018-03-27 15:00:02 --> Model Class Initialized
INFO - 2018-03-27 15:00:02 --> Model Class Initialized
INFO - 2018-03-27 15:00:02 --> Model Class Initialized
INFO - 2018-03-27 15:00:02 --> Model Class Initialized
INFO - 2018-03-27 15:00:02 --> Model Class Initialized
INFO - 2018-03-27 15:00:02 --> Model Class Initialized
INFO - 2018-03-27 15:00:02 --> Model Class Initialized
INFO - 2018-03-27 15:00:02 --> Helper loaded: date_helper
INFO - 2018-03-27 15:00:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 20:00:02 --> Model Class Initialized
INFO - 2018-03-27 20:00:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 20:00:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 20:00:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 20:00:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 20:00:02 --> Final output sent to browser
DEBUG - 2018-03-27 20:00:02 --> Total execution time: 0.1267
INFO - 2018-03-27 15:00:11 --> Config Class Initialized
INFO - 2018-03-27 15:00:11 --> Hooks Class Initialized
DEBUG - 2018-03-27 15:00:11 --> UTF-8 Support Enabled
INFO - 2018-03-27 15:00:11 --> Utf8 Class Initialized
INFO - 2018-03-27 15:00:11 --> URI Class Initialized
INFO - 2018-03-27 15:00:11 --> Router Class Initialized
INFO - 2018-03-27 15:00:11 --> Output Class Initialized
INFO - 2018-03-27 15:00:11 --> Security Class Initialized
DEBUG - 2018-03-27 15:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 15:00:11 --> Input Class Initialized
INFO - 2018-03-27 15:00:11 --> Language Class Initialized
INFO - 2018-03-27 15:00:11 --> Loader Class Initialized
INFO - 2018-03-27 15:00:11 --> Helper loaded: url_helper
INFO - 2018-03-27 15:00:11 --> Helper loaded: form_helper
INFO - 2018-03-27 15:00:11 --> Database Driver Class Initialized
DEBUG - 2018-03-27 15:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 15:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 15:00:11 --> Controller Class Initialized
INFO - 2018-03-27 15:00:11 --> Model Class Initialized
INFO - 2018-03-27 15:00:11 --> Model Class Initialized
INFO - 2018-03-27 15:00:11 --> Model Class Initialized
INFO - 2018-03-27 15:00:11 --> Model Class Initialized
INFO - 2018-03-27 15:00:11 --> Model Class Initialized
INFO - 2018-03-27 15:00:11 --> Model Class Initialized
INFO - 2018-03-27 15:00:11 --> Model Class Initialized
INFO - 2018-03-27 15:00:11 --> Model Class Initialized
INFO - 2018-03-27 15:00:11 --> Model Class Initialized
INFO - 2018-03-27 15:00:11 --> Model Class Initialized
INFO - 2018-03-27 15:00:11 --> Model Class Initialized
INFO - 2018-03-27 15:00:11 --> Model Class Initialized
INFO - 2018-03-27 15:00:12 --> Model Class Initialized
INFO - 2018-03-27 15:00:12 --> Model Class Initialized
INFO - 2018-03-27 15:00:12 --> Model Class Initialized
INFO - 2018-03-27 15:00:12 --> Helper loaded: date_helper
INFO - 2018-03-27 15:00:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 20:00:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 20:00:12 --> Final output sent to browser
DEBUG - 2018-03-27 20:00:12 --> Total execution time: 0.1381
INFO - 2018-03-27 15:00:18 --> Config Class Initialized
INFO - 2018-03-27 15:00:18 --> Hooks Class Initialized
DEBUG - 2018-03-27 15:00:18 --> UTF-8 Support Enabled
INFO - 2018-03-27 15:00:18 --> Utf8 Class Initialized
INFO - 2018-03-27 15:00:18 --> URI Class Initialized
INFO - 2018-03-27 15:00:18 --> Router Class Initialized
INFO - 2018-03-27 15:00:18 --> Output Class Initialized
INFO - 2018-03-27 15:00:18 --> Security Class Initialized
DEBUG - 2018-03-27 15:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 15:00:18 --> Input Class Initialized
INFO - 2018-03-27 15:00:18 --> Language Class Initialized
INFO - 2018-03-27 15:00:18 --> Loader Class Initialized
INFO - 2018-03-27 15:00:18 --> Helper loaded: url_helper
INFO - 2018-03-27 15:00:18 --> Helper loaded: form_helper
INFO - 2018-03-27 15:00:18 --> Database Driver Class Initialized
DEBUG - 2018-03-27 15:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 15:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 15:00:18 --> Controller Class Initialized
INFO - 2018-03-27 15:00:18 --> Model Class Initialized
INFO - 2018-03-27 15:00:18 --> Model Class Initialized
INFO - 2018-03-27 15:00:18 --> Model Class Initialized
INFO - 2018-03-27 15:00:18 --> Model Class Initialized
INFO - 2018-03-27 15:00:18 --> Model Class Initialized
INFO - 2018-03-27 15:00:18 --> Model Class Initialized
INFO - 2018-03-27 15:00:18 --> Model Class Initialized
INFO - 2018-03-27 15:00:18 --> Model Class Initialized
INFO - 2018-03-27 15:00:18 --> Model Class Initialized
INFO - 2018-03-27 15:00:18 --> Model Class Initialized
INFO - 2018-03-27 15:00:18 --> Model Class Initialized
INFO - 2018-03-27 15:00:18 --> Model Class Initialized
INFO - 2018-03-27 15:00:18 --> Model Class Initialized
INFO - 2018-03-27 15:00:18 --> Model Class Initialized
INFO - 2018-03-27 15:00:18 --> Model Class Initialized
INFO - 2018-03-27 15:00:18 --> Helper loaded: date_helper
INFO - 2018-03-27 15:00:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 20:00:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 20:00:18 --> Final output sent to browser
DEBUG - 2018-03-27 20:00:18 --> Total execution time: 0.1382
INFO - 2018-03-27 15:00:29 --> Config Class Initialized
INFO - 2018-03-27 15:00:29 --> Hooks Class Initialized
DEBUG - 2018-03-27 15:00:29 --> UTF-8 Support Enabled
INFO - 2018-03-27 15:00:29 --> Utf8 Class Initialized
INFO - 2018-03-27 15:00:29 --> URI Class Initialized
INFO - 2018-03-27 15:00:29 --> Router Class Initialized
INFO - 2018-03-27 15:00:29 --> Output Class Initialized
INFO - 2018-03-27 15:00:29 --> Security Class Initialized
DEBUG - 2018-03-27 15:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 15:00:29 --> Input Class Initialized
INFO - 2018-03-27 15:00:29 --> Language Class Initialized
INFO - 2018-03-27 15:00:29 --> Loader Class Initialized
INFO - 2018-03-27 15:00:29 --> Helper loaded: url_helper
INFO - 2018-03-27 15:00:29 --> Helper loaded: form_helper
INFO - 2018-03-27 15:00:29 --> Database Driver Class Initialized
DEBUG - 2018-03-27 15:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 15:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 15:00:29 --> Controller Class Initialized
INFO - 2018-03-27 15:00:29 --> Model Class Initialized
INFO - 2018-03-27 15:00:29 --> Model Class Initialized
INFO - 2018-03-27 15:00:29 --> Model Class Initialized
INFO - 2018-03-27 15:00:29 --> Model Class Initialized
INFO - 2018-03-27 15:00:29 --> Model Class Initialized
INFO - 2018-03-27 15:00:29 --> Model Class Initialized
INFO - 2018-03-27 15:00:29 --> Model Class Initialized
INFO - 2018-03-27 15:00:29 --> Model Class Initialized
INFO - 2018-03-27 15:00:29 --> Model Class Initialized
INFO - 2018-03-27 15:00:29 --> Model Class Initialized
INFO - 2018-03-27 15:00:29 --> Model Class Initialized
INFO - 2018-03-27 15:00:29 --> Model Class Initialized
INFO - 2018-03-27 15:00:29 --> Model Class Initialized
INFO - 2018-03-27 15:00:29 --> Model Class Initialized
INFO - 2018-03-27 15:00:29 --> Model Class Initialized
INFO - 2018-03-27 15:00:29 --> Helper loaded: date_helper
INFO - 2018-03-27 15:00:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 20:00:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 20:00:29 --> Final output sent to browser
DEBUG - 2018-03-27 20:00:29 --> Total execution time: 0.1259
INFO - 2018-03-27 15:00:42 --> Config Class Initialized
INFO - 2018-03-27 15:00:42 --> Hooks Class Initialized
DEBUG - 2018-03-27 15:00:42 --> UTF-8 Support Enabled
INFO - 2018-03-27 15:00:42 --> Utf8 Class Initialized
INFO - 2018-03-27 15:00:42 --> URI Class Initialized
INFO - 2018-03-27 15:00:42 --> Router Class Initialized
INFO - 2018-03-27 15:00:42 --> Output Class Initialized
INFO - 2018-03-27 15:00:42 --> Security Class Initialized
DEBUG - 2018-03-27 15:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 15:00:42 --> Input Class Initialized
INFO - 2018-03-27 15:00:42 --> Language Class Initialized
INFO - 2018-03-27 15:00:42 --> Loader Class Initialized
INFO - 2018-03-27 15:00:42 --> Helper loaded: url_helper
INFO - 2018-03-27 15:00:42 --> Helper loaded: form_helper
INFO - 2018-03-27 15:00:42 --> Database Driver Class Initialized
DEBUG - 2018-03-27 15:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 15:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 15:00:42 --> Controller Class Initialized
INFO - 2018-03-27 15:00:42 --> Model Class Initialized
INFO - 2018-03-27 15:00:42 --> Model Class Initialized
INFO - 2018-03-27 15:00:42 --> Model Class Initialized
INFO - 2018-03-27 15:00:42 --> Model Class Initialized
INFO - 2018-03-27 15:00:42 --> Model Class Initialized
INFO - 2018-03-27 15:00:42 --> Model Class Initialized
INFO - 2018-03-27 15:00:42 --> Model Class Initialized
INFO - 2018-03-27 15:00:42 --> Model Class Initialized
INFO - 2018-03-27 15:00:42 --> Model Class Initialized
INFO - 2018-03-27 15:00:42 --> Model Class Initialized
INFO - 2018-03-27 15:00:42 --> Model Class Initialized
INFO - 2018-03-27 15:00:42 --> Model Class Initialized
INFO - 2018-03-27 15:00:42 --> Model Class Initialized
INFO - 2018-03-27 15:00:42 --> Model Class Initialized
INFO - 2018-03-27 15:00:42 --> Model Class Initialized
INFO - 2018-03-27 15:00:42 --> Helper loaded: date_helper
INFO - 2018-03-27 15:00:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 20:00:42 --> Model Class Initialized
INFO - 2018-03-27 20:00:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 20:00:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 20:00:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 20:00:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 20:00:42 --> Final output sent to browser
DEBUG - 2018-03-27 20:00:42 --> Total execution time: 0.1378
INFO - 2018-03-27 15:00:49 --> Config Class Initialized
INFO - 2018-03-27 15:00:49 --> Hooks Class Initialized
DEBUG - 2018-03-27 15:00:49 --> UTF-8 Support Enabled
INFO - 2018-03-27 15:00:49 --> Utf8 Class Initialized
INFO - 2018-03-27 15:00:49 --> URI Class Initialized
INFO - 2018-03-27 15:00:49 --> Router Class Initialized
INFO - 2018-03-27 15:00:49 --> Output Class Initialized
INFO - 2018-03-27 15:00:49 --> Security Class Initialized
DEBUG - 2018-03-27 15:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 15:00:49 --> Input Class Initialized
INFO - 2018-03-27 15:00:49 --> Language Class Initialized
INFO - 2018-03-27 15:00:49 --> Loader Class Initialized
INFO - 2018-03-27 15:00:49 --> Helper loaded: url_helper
INFO - 2018-03-27 15:00:49 --> Helper loaded: form_helper
INFO - 2018-03-27 15:00:49 --> Database Driver Class Initialized
DEBUG - 2018-03-27 15:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 15:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 15:00:49 --> Controller Class Initialized
INFO - 2018-03-27 15:00:49 --> Model Class Initialized
INFO - 2018-03-27 15:00:49 --> Model Class Initialized
INFO - 2018-03-27 15:00:49 --> Model Class Initialized
INFO - 2018-03-27 15:00:49 --> Model Class Initialized
INFO - 2018-03-27 15:00:49 --> Model Class Initialized
INFO - 2018-03-27 15:00:49 --> Model Class Initialized
INFO - 2018-03-27 15:00:49 --> Model Class Initialized
INFO - 2018-03-27 15:00:49 --> Model Class Initialized
INFO - 2018-03-27 15:00:49 --> Model Class Initialized
INFO - 2018-03-27 15:00:49 --> Model Class Initialized
INFO - 2018-03-27 15:00:49 --> Model Class Initialized
INFO - 2018-03-27 15:00:49 --> Model Class Initialized
INFO - 2018-03-27 15:00:49 --> Model Class Initialized
INFO - 2018-03-27 15:00:49 --> Model Class Initialized
INFO - 2018-03-27 15:00:49 --> Model Class Initialized
INFO - 2018-03-27 15:00:49 --> Helper loaded: date_helper
INFO - 2018-03-27 15:00:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 20:00:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 20:00:49 --> Final output sent to browser
DEBUG - 2018-03-27 20:00:49 --> Total execution time: 0.1290
INFO - 2018-03-27 15:00:53 --> Config Class Initialized
INFO - 2018-03-27 15:00:53 --> Hooks Class Initialized
DEBUG - 2018-03-27 15:00:53 --> UTF-8 Support Enabled
INFO - 2018-03-27 15:00:53 --> Utf8 Class Initialized
INFO - 2018-03-27 15:00:53 --> URI Class Initialized
INFO - 2018-03-27 15:00:53 --> Router Class Initialized
INFO - 2018-03-27 15:00:53 --> Output Class Initialized
INFO - 2018-03-27 15:00:53 --> Security Class Initialized
DEBUG - 2018-03-27 15:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 15:00:53 --> Input Class Initialized
INFO - 2018-03-27 15:00:53 --> Language Class Initialized
INFO - 2018-03-27 15:00:53 --> Loader Class Initialized
INFO - 2018-03-27 15:00:53 --> Helper loaded: url_helper
INFO - 2018-03-27 15:00:53 --> Helper loaded: form_helper
INFO - 2018-03-27 15:00:53 --> Database Driver Class Initialized
DEBUG - 2018-03-27 15:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 15:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 15:00:53 --> Controller Class Initialized
INFO - 2018-03-27 15:00:53 --> Model Class Initialized
INFO - 2018-03-27 15:00:53 --> Model Class Initialized
INFO - 2018-03-27 15:00:53 --> Model Class Initialized
INFO - 2018-03-27 15:00:53 --> Model Class Initialized
INFO - 2018-03-27 15:00:53 --> Model Class Initialized
INFO - 2018-03-27 15:00:53 --> Model Class Initialized
INFO - 2018-03-27 15:00:53 --> Model Class Initialized
INFO - 2018-03-27 15:00:53 --> Model Class Initialized
INFO - 2018-03-27 15:00:53 --> Model Class Initialized
INFO - 2018-03-27 15:00:53 --> Model Class Initialized
INFO - 2018-03-27 15:00:53 --> Model Class Initialized
INFO - 2018-03-27 15:00:53 --> Model Class Initialized
INFO - 2018-03-27 15:00:53 --> Model Class Initialized
INFO - 2018-03-27 15:00:53 --> Model Class Initialized
INFO - 2018-03-27 15:00:53 --> Model Class Initialized
INFO - 2018-03-27 15:00:53 --> Helper loaded: date_helper
INFO - 2018-03-27 15:00:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 20:00:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 20:00:53 --> Final output sent to browser
DEBUG - 2018-03-27 20:00:53 --> Total execution time: 0.1349
INFO - 2018-03-27 15:00:57 --> Config Class Initialized
INFO - 2018-03-27 15:00:57 --> Hooks Class Initialized
DEBUG - 2018-03-27 15:00:57 --> UTF-8 Support Enabled
INFO - 2018-03-27 15:00:57 --> Utf8 Class Initialized
INFO - 2018-03-27 15:00:57 --> URI Class Initialized
INFO - 2018-03-27 15:00:57 --> Router Class Initialized
INFO - 2018-03-27 15:00:57 --> Output Class Initialized
INFO - 2018-03-27 15:00:57 --> Security Class Initialized
DEBUG - 2018-03-27 15:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 15:00:57 --> Input Class Initialized
INFO - 2018-03-27 15:00:57 --> Language Class Initialized
INFO - 2018-03-27 15:00:57 --> Loader Class Initialized
INFO - 2018-03-27 15:00:57 --> Helper loaded: url_helper
INFO - 2018-03-27 15:00:57 --> Helper loaded: form_helper
INFO - 2018-03-27 15:00:57 --> Database Driver Class Initialized
DEBUG - 2018-03-27 15:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 15:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 15:00:57 --> Controller Class Initialized
INFO - 2018-03-27 15:00:57 --> Model Class Initialized
INFO - 2018-03-27 15:00:57 --> Model Class Initialized
INFO - 2018-03-27 15:00:57 --> Model Class Initialized
INFO - 2018-03-27 15:00:57 --> Model Class Initialized
INFO - 2018-03-27 15:00:57 --> Model Class Initialized
INFO - 2018-03-27 15:00:57 --> Model Class Initialized
INFO - 2018-03-27 15:00:57 --> Model Class Initialized
INFO - 2018-03-27 15:00:57 --> Model Class Initialized
INFO - 2018-03-27 15:00:57 --> Model Class Initialized
INFO - 2018-03-27 15:00:57 --> Model Class Initialized
INFO - 2018-03-27 15:00:57 --> Model Class Initialized
INFO - 2018-03-27 15:00:57 --> Model Class Initialized
INFO - 2018-03-27 15:00:57 --> Model Class Initialized
INFO - 2018-03-27 15:00:57 --> Model Class Initialized
INFO - 2018-03-27 15:00:57 --> Model Class Initialized
INFO - 2018-03-27 15:00:57 --> Helper loaded: date_helper
INFO - 2018-03-27 15:00:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 20:00:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 20:00:57 --> Final output sent to browser
DEBUG - 2018-03-27 20:00:57 --> Total execution time: 0.1157
INFO - 2018-03-27 15:47:57 --> Config Class Initialized
INFO - 2018-03-27 15:47:57 --> Hooks Class Initialized
DEBUG - 2018-03-27 15:47:57 --> UTF-8 Support Enabled
INFO - 2018-03-27 15:47:57 --> Utf8 Class Initialized
INFO - 2018-03-27 15:47:57 --> URI Class Initialized
INFO - 2018-03-27 15:47:57 --> Router Class Initialized
INFO - 2018-03-27 15:47:57 --> Output Class Initialized
INFO - 2018-03-27 15:47:57 --> Security Class Initialized
DEBUG - 2018-03-27 15:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 15:47:57 --> Input Class Initialized
INFO - 2018-03-27 15:47:57 --> Language Class Initialized
INFO - 2018-03-27 15:47:57 --> Loader Class Initialized
INFO - 2018-03-27 15:47:57 --> Helper loaded: url_helper
INFO - 2018-03-27 15:47:57 --> Helper loaded: form_helper
INFO - 2018-03-27 15:47:57 --> Database Driver Class Initialized
DEBUG - 2018-03-27 15:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 15:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 15:47:57 --> Controller Class Initialized
INFO - 2018-03-27 15:47:57 --> Model Class Initialized
INFO - 2018-03-27 15:47:57 --> Model Class Initialized
INFO - 2018-03-27 15:47:57 --> Model Class Initialized
INFO - 2018-03-27 15:47:57 --> Model Class Initialized
INFO - 2018-03-27 15:47:57 --> Model Class Initialized
INFO - 2018-03-27 15:47:57 --> Model Class Initialized
INFO - 2018-03-27 15:47:57 --> Model Class Initialized
INFO - 2018-03-27 15:47:57 --> Model Class Initialized
INFO - 2018-03-27 15:47:57 --> Model Class Initialized
INFO - 2018-03-27 15:47:57 --> Model Class Initialized
INFO - 2018-03-27 15:47:57 --> Model Class Initialized
INFO - 2018-03-27 15:47:57 --> Model Class Initialized
INFO - 2018-03-27 15:47:57 --> Model Class Initialized
INFO - 2018-03-27 15:47:57 --> Model Class Initialized
INFO - 2018-03-27 15:47:57 --> Model Class Initialized
INFO - 2018-03-27 15:47:57 --> Helper loaded: date_helper
INFO - 2018-03-27 15:47:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 20:47:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 20:47:57 --> Final output sent to browser
DEBUG - 2018-03-27 20:47:57 --> Total execution time: 0.1107
INFO - 2018-03-27 17:04:11 --> Config Class Initialized
INFO - 2018-03-27 17:04:11 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:04:11 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:04:11 --> Utf8 Class Initialized
INFO - 2018-03-27 17:04:11 --> URI Class Initialized
INFO - 2018-03-27 17:04:11 --> Router Class Initialized
INFO - 2018-03-27 17:04:11 --> Output Class Initialized
INFO - 2018-03-27 17:04:11 --> Security Class Initialized
DEBUG - 2018-03-27 17:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:04:11 --> Input Class Initialized
INFO - 2018-03-27 17:04:11 --> Language Class Initialized
INFO - 2018-03-27 17:04:11 --> Loader Class Initialized
INFO - 2018-03-27 17:04:11 --> Helper loaded: url_helper
INFO - 2018-03-27 17:04:11 --> Helper loaded: form_helper
INFO - 2018-03-27 17:04:11 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:04:11 --> Controller Class Initialized
INFO - 2018-03-27 17:04:11 --> Model Class Initialized
INFO - 2018-03-27 17:04:11 --> Model Class Initialized
INFO - 2018-03-27 17:04:11 --> Model Class Initialized
INFO - 2018-03-27 17:04:11 --> Model Class Initialized
INFO - 2018-03-27 17:04:11 --> Model Class Initialized
INFO - 2018-03-27 17:04:11 --> Model Class Initialized
INFO - 2018-03-27 17:04:11 --> Model Class Initialized
INFO - 2018-03-27 17:04:11 --> Model Class Initialized
INFO - 2018-03-27 17:04:11 --> Model Class Initialized
INFO - 2018-03-27 17:04:11 --> Model Class Initialized
INFO - 2018-03-27 17:04:11 --> Model Class Initialized
INFO - 2018-03-27 17:04:11 --> Model Class Initialized
INFO - 2018-03-27 17:04:11 --> Model Class Initialized
INFO - 2018-03-27 17:04:11 --> Model Class Initialized
INFO - 2018-03-27 17:04:11 --> Model Class Initialized
INFO - 2018-03-27 17:04:11 --> Helper loaded: date_helper
INFO - 2018-03-27 17:04:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:04:11 --> Model Class Initialized
INFO - 2018-03-27 22:04:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 22:04:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 22:04:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 22:04:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 22:04:11 --> Final output sent to browser
DEBUG - 2018-03-27 22:04:11 --> Total execution time: 0.1426
INFO - 2018-03-27 17:04:28 --> Config Class Initialized
INFO - 2018-03-27 17:04:28 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:04:28 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:04:28 --> Utf8 Class Initialized
INFO - 2018-03-27 17:04:28 --> URI Class Initialized
INFO - 2018-03-27 17:04:28 --> Router Class Initialized
INFO - 2018-03-27 17:04:28 --> Output Class Initialized
INFO - 2018-03-27 17:04:28 --> Security Class Initialized
DEBUG - 2018-03-27 17:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:04:28 --> Input Class Initialized
INFO - 2018-03-27 17:04:28 --> Language Class Initialized
INFO - 2018-03-27 17:04:28 --> Loader Class Initialized
INFO - 2018-03-27 17:04:28 --> Helper loaded: url_helper
INFO - 2018-03-27 17:04:28 --> Helper loaded: form_helper
INFO - 2018-03-27 17:04:28 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:04:28 --> Controller Class Initialized
INFO - 2018-03-27 17:04:28 --> Model Class Initialized
INFO - 2018-03-27 17:04:28 --> Model Class Initialized
INFO - 2018-03-27 17:04:28 --> Model Class Initialized
INFO - 2018-03-27 17:04:28 --> Model Class Initialized
INFO - 2018-03-27 17:04:28 --> Model Class Initialized
INFO - 2018-03-27 17:04:28 --> Model Class Initialized
INFO - 2018-03-27 17:04:28 --> Model Class Initialized
INFO - 2018-03-27 17:04:28 --> Model Class Initialized
INFO - 2018-03-27 17:04:28 --> Model Class Initialized
INFO - 2018-03-27 17:04:28 --> Model Class Initialized
INFO - 2018-03-27 17:04:28 --> Model Class Initialized
INFO - 2018-03-27 17:04:28 --> Model Class Initialized
INFO - 2018-03-27 17:04:28 --> Model Class Initialized
INFO - 2018-03-27 17:04:28 --> Model Class Initialized
INFO - 2018-03-27 17:04:28 --> Model Class Initialized
INFO - 2018-03-27 17:04:28 --> Helper loaded: date_helper
INFO - 2018-03-27 17:04:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:04:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 22:04:28 --> Final output sent to browser
DEBUG - 2018-03-27 22:04:28 --> Total execution time: 0.1446
INFO - 2018-03-27 17:04:29 --> Config Class Initialized
INFO - 2018-03-27 17:04:29 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:04:29 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:04:29 --> Utf8 Class Initialized
INFO - 2018-03-27 17:04:29 --> URI Class Initialized
INFO - 2018-03-27 17:04:29 --> Router Class Initialized
INFO - 2018-03-27 17:04:29 --> Output Class Initialized
INFO - 2018-03-27 17:04:29 --> Security Class Initialized
DEBUG - 2018-03-27 17:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:04:29 --> Input Class Initialized
INFO - 2018-03-27 17:04:29 --> Language Class Initialized
INFO - 2018-03-27 17:04:29 --> Loader Class Initialized
INFO - 2018-03-27 17:04:29 --> Helper loaded: url_helper
INFO - 2018-03-27 17:04:29 --> Helper loaded: form_helper
INFO - 2018-03-27 17:04:29 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:04:29 --> Controller Class Initialized
INFO - 2018-03-27 17:04:29 --> Model Class Initialized
INFO - 2018-03-27 17:04:29 --> Model Class Initialized
INFO - 2018-03-27 17:04:29 --> Model Class Initialized
INFO - 2018-03-27 17:04:29 --> Model Class Initialized
INFO - 2018-03-27 17:04:29 --> Model Class Initialized
INFO - 2018-03-27 17:04:29 --> Model Class Initialized
INFO - 2018-03-27 17:04:29 --> Model Class Initialized
INFO - 2018-03-27 17:04:29 --> Model Class Initialized
INFO - 2018-03-27 17:04:29 --> Model Class Initialized
INFO - 2018-03-27 17:04:29 --> Model Class Initialized
INFO - 2018-03-27 17:04:29 --> Model Class Initialized
INFO - 2018-03-27 17:04:29 --> Model Class Initialized
INFO - 2018-03-27 17:04:29 --> Model Class Initialized
INFO - 2018-03-27 17:04:29 --> Model Class Initialized
INFO - 2018-03-27 17:04:29 --> Model Class Initialized
INFO - 2018-03-27 17:04:29 --> Helper loaded: date_helper
INFO - 2018-03-27 17:04:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:04:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/print.php
INFO - 2018-03-27 22:04:29 --> Final output sent to browser
DEBUG - 2018-03-27 22:04:29 --> Total execution time: 0.1138
INFO - 2018-03-27 17:13:56 --> Config Class Initialized
INFO - 2018-03-27 17:13:56 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:13:56 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:13:56 --> Utf8 Class Initialized
INFO - 2018-03-27 17:13:56 --> URI Class Initialized
INFO - 2018-03-27 17:13:56 --> Router Class Initialized
INFO - 2018-03-27 17:13:56 --> Output Class Initialized
INFO - 2018-03-27 17:13:56 --> Security Class Initialized
DEBUG - 2018-03-27 17:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:13:56 --> Input Class Initialized
INFO - 2018-03-27 17:13:56 --> Language Class Initialized
INFO - 2018-03-27 17:13:56 --> Loader Class Initialized
INFO - 2018-03-27 17:13:56 --> Helper loaded: url_helper
INFO - 2018-03-27 17:13:56 --> Helper loaded: form_helper
INFO - 2018-03-27 17:13:56 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:13:56 --> Controller Class Initialized
INFO - 2018-03-27 17:13:56 --> Model Class Initialized
INFO - 2018-03-27 17:13:56 --> Model Class Initialized
INFO - 2018-03-27 17:13:56 --> Model Class Initialized
INFO - 2018-03-27 17:13:56 --> Model Class Initialized
INFO - 2018-03-27 17:13:56 --> Model Class Initialized
INFO - 2018-03-27 17:13:56 --> Model Class Initialized
INFO - 2018-03-27 17:13:56 --> Model Class Initialized
INFO - 2018-03-27 17:13:56 --> Model Class Initialized
INFO - 2018-03-27 17:13:56 --> Model Class Initialized
INFO - 2018-03-27 17:13:56 --> Model Class Initialized
INFO - 2018-03-27 17:13:56 --> Model Class Initialized
INFO - 2018-03-27 17:13:56 --> Model Class Initialized
INFO - 2018-03-27 17:13:56 --> Model Class Initialized
INFO - 2018-03-27 17:13:56 --> Model Class Initialized
INFO - 2018-03-27 17:13:56 --> Model Class Initialized
INFO - 2018-03-27 17:13:56 --> Helper loaded: date_helper
INFO - 2018-03-27 17:13:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:13:56 --> Model Class Initialized
INFO - 2018-03-27 22:13:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 22:13:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 22:13:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 22:13:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 22:13:56 --> Final output sent to browser
DEBUG - 2018-03-27 22:13:56 --> Total execution time: 0.1218
INFO - 2018-03-27 17:14:04 --> Config Class Initialized
INFO - 2018-03-27 17:14:04 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:14:04 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:14:04 --> Utf8 Class Initialized
INFO - 2018-03-27 17:14:04 --> URI Class Initialized
INFO - 2018-03-27 17:14:04 --> Router Class Initialized
INFO - 2018-03-27 17:14:04 --> Output Class Initialized
INFO - 2018-03-27 17:14:04 --> Security Class Initialized
DEBUG - 2018-03-27 17:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:14:04 --> Input Class Initialized
INFO - 2018-03-27 17:14:04 --> Language Class Initialized
INFO - 2018-03-27 17:14:04 --> Loader Class Initialized
INFO - 2018-03-27 17:14:04 --> Helper loaded: url_helper
INFO - 2018-03-27 17:14:04 --> Helper loaded: form_helper
INFO - 2018-03-27 17:14:04 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:14:04 --> Controller Class Initialized
INFO - 2018-03-27 17:14:04 --> Model Class Initialized
INFO - 2018-03-27 17:14:04 --> Model Class Initialized
INFO - 2018-03-27 17:14:04 --> Model Class Initialized
INFO - 2018-03-27 17:14:04 --> Model Class Initialized
INFO - 2018-03-27 17:14:04 --> Model Class Initialized
INFO - 2018-03-27 17:14:04 --> Model Class Initialized
INFO - 2018-03-27 17:14:04 --> Model Class Initialized
INFO - 2018-03-27 17:14:04 --> Model Class Initialized
INFO - 2018-03-27 17:14:04 --> Model Class Initialized
INFO - 2018-03-27 17:14:04 --> Model Class Initialized
INFO - 2018-03-27 17:14:04 --> Model Class Initialized
INFO - 2018-03-27 17:14:04 --> Model Class Initialized
INFO - 2018-03-27 17:14:04 --> Model Class Initialized
INFO - 2018-03-27 17:14:04 --> Model Class Initialized
INFO - 2018-03-27 17:14:04 --> Model Class Initialized
INFO - 2018-03-27 17:14:04 --> Helper loaded: date_helper
INFO - 2018-03-27 17:14:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:14:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 22:14:04 --> Final output sent to browser
DEBUG - 2018-03-27 22:14:04 --> Total execution time: 0.1072
INFO - 2018-03-27 17:14:05 --> Config Class Initialized
INFO - 2018-03-27 17:14:05 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:14:05 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:14:05 --> Utf8 Class Initialized
INFO - 2018-03-27 17:14:05 --> URI Class Initialized
INFO - 2018-03-27 17:14:05 --> Router Class Initialized
INFO - 2018-03-27 17:14:05 --> Output Class Initialized
INFO - 2018-03-27 17:14:05 --> Security Class Initialized
DEBUG - 2018-03-27 17:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:14:05 --> Input Class Initialized
INFO - 2018-03-27 17:14:05 --> Language Class Initialized
INFO - 2018-03-27 17:14:05 --> Loader Class Initialized
INFO - 2018-03-27 17:14:05 --> Helper loaded: url_helper
INFO - 2018-03-27 17:14:05 --> Helper loaded: form_helper
INFO - 2018-03-27 17:14:05 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:14:05 --> Controller Class Initialized
INFO - 2018-03-27 17:14:05 --> Model Class Initialized
INFO - 2018-03-27 17:14:05 --> Model Class Initialized
INFO - 2018-03-27 17:14:05 --> Model Class Initialized
INFO - 2018-03-27 17:14:05 --> Model Class Initialized
INFO - 2018-03-27 17:14:05 --> Model Class Initialized
INFO - 2018-03-27 17:14:05 --> Model Class Initialized
INFO - 2018-03-27 17:14:05 --> Model Class Initialized
INFO - 2018-03-27 17:14:05 --> Model Class Initialized
INFO - 2018-03-27 17:14:05 --> Model Class Initialized
INFO - 2018-03-27 17:14:05 --> Model Class Initialized
INFO - 2018-03-27 17:14:05 --> Model Class Initialized
INFO - 2018-03-27 17:14:05 --> Model Class Initialized
INFO - 2018-03-27 17:14:05 --> Model Class Initialized
INFO - 2018-03-27 17:14:05 --> Model Class Initialized
INFO - 2018-03-27 17:14:05 --> Model Class Initialized
INFO - 2018-03-27 17:14:05 --> Helper loaded: date_helper
INFO - 2018-03-27 17:14:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:14:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/print.php
INFO - 2018-03-27 22:14:05 --> Final output sent to browser
DEBUG - 2018-03-27 22:14:05 --> Total execution time: 0.2313
INFO - 2018-03-27 17:21:32 --> Config Class Initialized
INFO - 2018-03-27 17:21:32 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:21:32 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:21:32 --> Utf8 Class Initialized
INFO - 2018-03-27 17:21:32 --> URI Class Initialized
INFO - 2018-03-27 17:21:32 --> Router Class Initialized
INFO - 2018-03-27 17:21:32 --> Output Class Initialized
INFO - 2018-03-27 17:21:32 --> Security Class Initialized
DEBUG - 2018-03-27 17:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:21:32 --> Input Class Initialized
INFO - 2018-03-27 17:21:32 --> Language Class Initialized
INFO - 2018-03-27 17:21:32 --> Loader Class Initialized
INFO - 2018-03-27 17:21:32 --> Helper loaded: url_helper
INFO - 2018-03-27 17:21:32 --> Helper loaded: form_helper
INFO - 2018-03-27 17:21:32 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:21:32 --> Controller Class Initialized
INFO - 2018-03-27 17:21:32 --> Model Class Initialized
INFO - 2018-03-27 17:21:32 --> Model Class Initialized
INFO - 2018-03-27 17:21:32 --> Model Class Initialized
INFO - 2018-03-27 17:21:32 --> Model Class Initialized
INFO - 2018-03-27 17:21:32 --> Model Class Initialized
INFO - 2018-03-27 17:21:32 --> Model Class Initialized
INFO - 2018-03-27 17:21:32 --> Model Class Initialized
INFO - 2018-03-27 17:21:32 --> Model Class Initialized
INFO - 2018-03-27 17:21:32 --> Model Class Initialized
INFO - 2018-03-27 17:21:32 --> Model Class Initialized
INFO - 2018-03-27 17:21:32 --> Model Class Initialized
INFO - 2018-03-27 17:21:32 --> Model Class Initialized
INFO - 2018-03-27 17:21:32 --> Model Class Initialized
INFO - 2018-03-27 17:21:32 --> Model Class Initialized
INFO - 2018-03-27 17:21:32 --> Model Class Initialized
INFO - 2018-03-27 17:21:32 --> Helper loaded: date_helper
INFO - 2018-03-27 17:21:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:21:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/print.php
INFO - 2018-03-27 22:21:32 --> Final output sent to browser
DEBUG - 2018-03-27 22:21:32 --> Total execution time: 0.1042
INFO - 2018-03-27 17:22:02 --> Config Class Initialized
INFO - 2018-03-27 17:22:02 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:22:02 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:22:02 --> Utf8 Class Initialized
INFO - 2018-03-27 17:22:02 --> URI Class Initialized
INFO - 2018-03-27 17:22:02 --> Router Class Initialized
INFO - 2018-03-27 17:22:02 --> Output Class Initialized
INFO - 2018-03-27 17:22:02 --> Security Class Initialized
DEBUG - 2018-03-27 17:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:22:02 --> Input Class Initialized
INFO - 2018-03-27 17:22:02 --> Language Class Initialized
INFO - 2018-03-27 17:22:02 --> Loader Class Initialized
INFO - 2018-03-27 17:22:02 --> Helper loaded: url_helper
INFO - 2018-03-27 17:22:02 --> Helper loaded: form_helper
INFO - 2018-03-27 17:22:02 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:22:02 --> Controller Class Initialized
INFO - 2018-03-27 17:22:02 --> Model Class Initialized
INFO - 2018-03-27 17:22:02 --> Model Class Initialized
INFO - 2018-03-27 17:22:02 --> Model Class Initialized
INFO - 2018-03-27 17:22:02 --> Model Class Initialized
INFO - 2018-03-27 17:22:02 --> Model Class Initialized
INFO - 2018-03-27 17:22:02 --> Model Class Initialized
INFO - 2018-03-27 17:22:02 --> Model Class Initialized
INFO - 2018-03-27 17:22:02 --> Model Class Initialized
INFO - 2018-03-27 17:22:02 --> Model Class Initialized
INFO - 2018-03-27 17:22:02 --> Model Class Initialized
INFO - 2018-03-27 17:22:02 --> Model Class Initialized
INFO - 2018-03-27 17:22:02 --> Model Class Initialized
INFO - 2018-03-27 17:22:02 --> Model Class Initialized
INFO - 2018-03-27 17:22:03 --> Model Class Initialized
INFO - 2018-03-27 17:22:03 --> Model Class Initialized
INFO - 2018-03-27 17:22:03 --> Helper loaded: date_helper
INFO - 2018-03-27 17:22:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:22:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/print.php
INFO - 2018-03-27 22:22:03 --> Final output sent to browser
DEBUG - 2018-03-27 22:22:03 --> Total execution time: 0.1753
INFO - 2018-03-27 17:23:26 --> Config Class Initialized
INFO - 2018-03-27 17:23:26 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:23:26 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:23:26 --> Utf8 Class Initialized
INFO - 2018-03-27 17:23:26 --> URI Class Initialized
INFO - 2018-03-27 17:23:26 --> Router Class Initialized
INFO - 2018-03-27 17:23:26 --> Output Class Initialized
INFO - 2018-03-27 17:23:26 --> Security Class Initialized
DEBUG - 2018-03-27 17:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:23:26 --> Input Class Initialized
INFO - 2018-03-27 17:23:26 --> Language Class Initialized
INFO - 2018-03-27 17:23:26 --> Loader Class Initialized
INFO - 2018-03-27 17:23:26 --> Helper loaded: url_helper
INFO - 2018-03-27 17:23:26 --> Helper loaded: form_helper
INFO - 2018-03-27 17:23:26 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:23:26 --> Controller Class Initialized
INFO - 2018-03-27 17:23:26 --> Model Class Initialized
INFO - 2018-03-27 17:23:26 --> Model Class Initialized
INFO - 2018-03-27 17:23:26 --> Model Class Initialized
INFO - 2018-03-27 17:23:26 --> Model Class Initialized
INFO - 2018-03-27 17:23:26 --> Model Class Initialized
INFO - 2018-03-27 17:23:26 --> Model Class Initialized
INFO - 2018-03-27 17:23:26 --> Model Class Initialized
INFO - 2018-03-27 17:23:26 --> Model Class Initialized
INFO - 2018-03-27 17:23:26 --> Model Class Initialized
INFO - 2018-03-27 17:23:26 --> Model Class Initialized
INFO - 2018-03-27 17:23:26 --> Model Class Initialized
INFO - 2018-03-27 17:23:26 --> Model Class Initialized
INFO - 2018-03-27 17:23:26 --> Model Class Initialized
INFO - 2018-03-27 17:23:26 --> Model Class Initialized
INFO - 2018-03-27 17:23:26 --> Model Class Initialized
INFO - 2018-03-27 17:23:26 --> Helper loaded: date_helper
INFO - 2018-03-27 17:23:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:23:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/print.php
INFO - 2018-03-27 22:23:26 --> Final output sent to browser
DEBUG - 2018-03-27 22:23:26 --> Total execution time: 0.1069
INFO - 2018-03-27 17:35:51 --> Config Class Initialized
INFO - 2018-03-27 17:35:51 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:35:51 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:35:51 --> Utf8 Class Initialized
INFO - 2018-03-27 17:35:51 --> URI Class Initialized
INFO - 2018-03-27 17:35:51 --> Router Class Initialized
INFO - 2018-03-27 17:35:51 --> Output Class Initialized
INFO - 2018-03-27 17:35:51 --> Security Class Initialized
DEBUG - 2018-03-27 17:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:35:51 --> Input Class Initialized
INFO - 2018-03-27 17:35:51 --> Language Class Initialized
INFO - 2018-03-27 17:35:51 --> Loader Class Initialized
INFO - 2018-03-27 17:35:51 --> Helper loaded: url_helper
INFO - 2018-03-27 17:35:51 --> Helper loaded: form_helper
INFO - 2018-03-27 17:35:51 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:35:51 --> Controller Class Initialized
INFO - 2018-03-27 17:35:51 --> Model Class Initialized
INFO - 2018-03-27 17:35:51 --> Model Class Initialized
INFO - 2018-03-27 17:35:51 --> Model Class Initialized
INFO - 2018-03-27 17:35:51 --> Model Class Initialized
INFO - 2018-03-27 17:35:51 --> Model Class Initialized
INFO - 2018-03-27 17:35:51 --> Model Class Initialized
INFO - 2018-03-27 17:35:51 --> Model Class Initialized
INFO - 2018-03-27 17:35:51 --> Model Class Initialized
INFO - 2018-03-27 17:35:51 --> Model Class Initialized
INFO - 2018-03-27 17:35:51 --> Model Class Initialized
INFO - 2018-03-27 17:35:51 --> Model Class Initialized
INFO - 2018-03-27 17:35:51 --> Model Class Initialized
INFO - 2018-03-27 17:35:51 --> Model Class Initialized
INFO - 2018-03-27 17:35:51 --> Model Class Initialized
INFO - 2018-03-27 17:35:51 --> Model Class Initialized
INFO - 2018-03-27 17:35:51 --> Helper loaded: date_helper
INFO - 2018-03-27 17:35:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:35:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/print.php
INFO - 2018-03-27 22:35:51 --> Final output sent to browser
DEBUG - 2018-03-27 22:35:51 --> Total execution time: 0.0964
INFO - 2018-03-27 17:35:59 --> Config Class Initialized
INFO - 2018-03-27 17:35:59 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:35:59 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:35:59 --> Utf8 Class Initialized
INFO - 2018-03-27 17:35:59 --> URI Class Initialized
INFO - 2018-03-27 17:35:59 --> Router Class Initialized
INFO - 2018-03-27 17:35:59 --> Output Class Initialized
INFO - 2018-03-27 17:35:59 --> Security Class Initialized
DEBUG - 2018-03-27 17:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:35:59 --> Input Class Initialized
INFO - 2018-03-27 17:35:59 --> Language Class Initialized
INFO - 2018-03-27 17:35:59 --> Loader Class Initialized
INFO - 2018-03-27 17:35:59 --> Helper loaded: url_helper
INFO - 2018-03-27 17:35:59 --> Helper loaded: form_helper
INFO - 2018-03-27 17:35:59 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:35:59 --> Controller Class Initialized
INFO - 2018-03-27 17:35:59 --> Model Class Initialized
INFO - 2018-03-27 17:35:59 --> Model Class Initialized
INFO - 2018-03-27 17:35:59 --> Model Class Initialized
INFO - 2018-03-27 17:35:59 --> Model Class Initialized
INFO - 2018-03-27 17:35:59 --> Model Class Initialized
INFO - 2018-03-27 17:35:59 --> Model Class Initialized
INFO - 2018-03-27 17:35:59 --> Model Class Initialized
INFO - 2018-03-27 17:35:59 --> Model Class Initialized
INFO - 2018-03-27 17:35:59 --> Model Class Initialized
INFO - 2018-03-27 17:35:59 --> Model Class Initialized
INFO - 2018-03-27 17:35:59 --> Model Class Initialized
INFO - 2018-03-27 17:35:59 --> Model Class Initialized
INFO - 2018-03-27 17:35:59 --> Model Class Initialized
INFO - 2018-03-27 17:35:59 --> Model Class Initialized
INFO - 2018-03-27 17:35:59 --> Model Class Initialized
INFO - 2018-03-27 17:35:59 --> Helper loaded: date_helper
INFO - 2018-03-27 17:35:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:35:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/print.php
INFO - 2018-03-27 22:35:59 --> Final output sent to browser
DEBUG - 2018-03-27 22:35:59 --> Total execution time: 0.1225
INFO - 2018-03-27 17:36:29 --> Config Class Initialized
INFO - 2018-03-27 17:36:29 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:36:29 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:36:29 --> Utf8 Class Initialized
INFO - 2018-03-27 17:36:29 --> URI Class Initialized
INFO - 2018-03-27 17:36:29 --> Router Class Initialized
INFO - 2018-03-27 17:36:29 --> Output Class Initialized
INFO - 2018-03-27 17:36:29 --> Security Class Initialized
DEBUG - 2018-03-27 17:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:36:29 --> Input Class Initialized
INFO - 2018-03-27 17:36:29 --> Language Class Initialized
INFO - 2018-03-27 17:36:29 --> Loader Class Initialized
INFO - 2018-03-27 17:36:29 --> Helper loaded: url_helper
INFO - 2018-03-27 17:36:29 --> Helper loaded: form_helper
INFO - 2018-03-27 17:36:29 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:36:29 --> Controller Class Initialized
INFO - 2018-03-27 17:36:29 --> Model Class Initialized
INFO - 2018-03-27 17:36:29 --> Model Class Initialized
INFO - 2018-03-27 17:36:29 --> Model Class Initialized
INFO - 2018-03-27 17:36:29 --> Model Class Initialized
INFO - 2018-03-27 17:36:29 --> Model Class Initialized
INFO - 2018-03-27 17:36:29 --> Model Class Initialized
INFO - 2018-03-27 17:36:29 --> Model Class Initialized
INFO - 2018-03-27 17:36:29 --> Model Class Initialized
INFO - 2018-03-27 17:36:29 --> Model Class Initialized
INFO - 2018-03-27 17:36:29 --> Model Class Initialized
INFO - 2018-03-27 17:36:29 --> Model Class Initialized
INFO - 2018-03-27 17:36:29 --> Model Class Initialized
INFO - 2018-03-27 17:36:29 --> Model Class Initialized
INFO - 2018-03-27 17:36:29 --> Model Class Initialized
INFO - 2018-03-27 17:36:29 --> Model Class Initialized
INFO - 2018-03-27 17:36:29 --> Helper loaded: date_helper
INFO - 2018-03-27 17:36:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:36:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/print.php
INFO - 2018-03-27 22:36:29 --> Final output sent to browser
DEBUG - 2018-03-27 22:36:29 --> Total execution time: 0.1147
INFO - 2018-03-27 17:36:48 --> Config Class Initialized
INFO - 2018-03-27 17:36:48 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:36:48 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:36:48 --> Utf8 Class Initialized
INFO - 2018-03-27 17:36:48 --> URI Class Initialized
INFO - 2018-03-27 17:36:48 --> Router Class Initialized
INFO - 2018-03-27 17:36:48 --> Output Class Initialized
INFO - 2018-03-27 17:36:48 --> Security Class Initialized
DEBUG - 2018-03-27 17:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:36:48 --> Input Class Initialized
INFO - 2018-03-27 17:36:48 --> Language Class Initialized
INFO - 2018-03-27 17:36:48 --> Loader Class Initialized
INFO - 2018-03-27 17:36:48 --> Helper loaded: url_helper
INFO - 2018-03-27 17:36:48 --> Helper loaded: form_helper
INFO - 2018-03-27 17:36:48 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:36:48 --> Controller Class Initialized
INFO - 2018-03-27 17:36:48 --> Model Class Initialized
INFO - 2018-03-27 17:36:48 --> Model Class Initialized
INFO - 2018-03-27 17:36:48 --> Model Class Initialized
INFO - 2018-03-27 17:36:48 --> Model Class Initialized
INFO - 2018-03-27 17:36:48 --> Model Class Initialized
INFO - 2018-03-27 17:36:48 --> Model Class Initialized
INFO - 2018-03-27 17:36:48 --> Model Class Initialized
INFO - 2018-03-27 17:36:48 --> Model Class Initialized
INFO - 2018-03-27 17:36:48 --> Model Class Initialized
INFO - 2018-03-27 17:36:48 --> Model Class Initialized
INFO - 2018-03-27 17:36:48 --> Model Class Initialized
INFO - 2018-03-27 17:36:48 --> Model Class Initialized
INFO - 2018-03-27 17:36:48 --> Model Class Initialized
INFO - 2018-03-27 17:36:48 --> Model Class Initialized
INFO - 2018-03-27 17:36:48 --> Model Class Initialized
INFO - 2018-03-27 17:36:48 --> Helper loaded: date_helper
INFO - 2018-03-27 17:36:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:36:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/print.php
INFO - 2018-03-27 22:36:48 --> Final output sent to browser
DEBUG - 2018-03-27 22:36:48 --> Total execution time: 0.1075
INFO - 2018-03-27 17:37:10 --> Config Class Initialized
INFO - 2018-03-27 17:37:10 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:37:10 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:37:10 --> Utf8 Class Initialized
INFO - 2018-03-27 17:37:10 --> URI Class Initialized
INFO - 2018-03-27 17:37:10 --> Router Class Initialized
INFO - 2018-03-27 17:37:10 --> Output Class Initialized
INFO - 2018-03-27 17:37:10 --> Security Class Initialized
DEBUG - 2018-03-27 17:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:37:10 --> Input Class Initialized
INFO - 2018-03-27 17:37:10 --> Language Class Initialized
INFO - 2018-03-27 17:37:10 --> Loader Class Initialized
INFO - 2018-03-27 17:37:10 --> Helper loaded: url_helper
INFO - 2018-03-27 17:37:10 --> Helper loaded: form_helper
INFO - 2018-03-27 17:37:10 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:37:10 --> Controller Class Initialized
INFO - 2018-03-27 17:37:10 --> Model Class Initialized
INFO - 2018-03-27 17:37:10 --> Model Class Initialized
INFO - 2018-03-27 17:37:10 --> Model Class Initialized
INFO - 2018-03-27 17:37:10 --> Model Class Initialized
INFO - 2018-03-27 17:37:10 --> Model Class Initialized
INFO - 2018-03-27 17:37:10 --> Model Class Initialized
INFO - 2018-03-27 17:37:10 --> Model Class Initialized
INFO - 2018-03-27 17:37:10 --> Model Class Initialized
INFO - 2018-03-27 17:37:10 --> Model Class Initialized
INFO - 2018-03-27 17:37:10 --> Model Class Initialized
INFO - 2018-03-27 17:37:10 --> Model Class Initialized
INFO - 2018-03-27 17:37:10 --> Model Class Initialized
INFO - 2018-03-27 17:37:10 --> Model Class Initialized
INFO - 2018-03-27 17:37:10 --> Model Class Initialized
INFO - 2018-03-27 17:37:10 --> Model Class Initialized
INFO - 2018-03-27 17:37:10 --> Helper loaded: date_helper
INFO - 2018-03-27 17:37:10 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:37:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/print.php
INFO - 2018-03-27 22:37:10 --> Final output sent to browser
DEBUG - 2018-03-27 22:37:10 --> Total execution time: 0.1176
INFO - 2018-03-27 17:37:59 --> Config Class Initialized
INFO - 2018-03-27 17:37:59 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:37:59 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:37:59 --> Utf8 Class Initialized
INFO - 2018-03-27 17:37:59 --> URI Class Initialized
INFO - 2018-03-27 17:37:59 --> Router Class Initialized
INFO - 2018-03-27 17:37:59 --> Output Class Initialized
INFO - 2018-03-27 17:37:59 --> Security Class Initialized
DEBUG - 2018-03-27 17:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:37:59 --> Input Class Initialized
INFO - 2018-03-27 17:37:59 --> Language Class Initialized
INFO - 2018-03-27 17:37:59 --> Loader Class Initialized
INFO - 2018-03-27 17:37:59 --> Helper loaded: url_helper
INFO - 2018-03-27 17:37:59 --> Helper loaded: form_helper
INFO - 2018-03-27 17:37:59 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:37:59 --> Controller Class Initialized
INFO - 2018-03-27 17:37:59 --> Model Class Initialized
INFO - 2018-03-27 17:37:59 --> Model Class Initialized
INFO - 2018-03-27 17:37:59 --> Model Class Initialized
INFO - 2018-03-27 17:37:59 --> Model Class Initialized
INFO - 2018-03-27 17:37:59 --> Model Class Initialized
INFO - 2018-03-27 17:37:59 --> Model Class Initialized
INFO - 2018-03-27 17:37:59 --> Model Class Initialized
INFO - 2018-03-27 17:37:59 --> Model Class Initialized
INFO - 2018-03-27 17:37:59 --> Model Class Initialized
INFO - 2018-03-27 17:37:59 --> Model Class Initialized
INFO - 2018-03-27 17:37:59 --> Model Class Initialized
INFO - 2018-03-27 17:37:59 --> Model Class Initialized
INFO - 2018-03-27 17:37:59 --> Model Class Initialized
INFO - 2018-03-27 17:37:59 --> Model Class Initialized
INFO - 2018-03-27 17:37:59 --> Model Class Initialized
INFO - 2018-03-27 17:37:59 --> Helper loaded: date_helper
INFO - 2018-03-27 17:37:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:37:59 --> Model Class Initialized
INFO - 2018-03-27 22:37:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 22:37:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 22:37:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 22:37:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 22:37:59 --> Final output sent to browser
DEBUG - 2018-03-27 22:37:59 --> Total execution time: 0.1112
INFO - 2018-03-27 17:38:06 --> Config Class Initialized
INFO - 2018-03-27 17:38:06 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:38:06 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:38:06 --> Utf8 Class Initialized
INFO - 2018-03-27 17:38:06 --> URI Class Initialized
INFO - 2018-03-27 17:38:06 --> Router Class Initialized
INFO - 2018-03-27 17:38:06 --> Output Class Initialized
INFO - 2018-03-27 17:38:06 --> Security Class Initialized
DEBUG - 2018-03-27 17:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:38:06 --> Input Class Initialized
INFO - 2018-03-27 17:38:06 --> Language Class Initialized
INFO - 2018-03-27 17:38:06 --> Loader Class Initialized
INFO - 2018-03-27 17:38:06 --> Helper loaded: url_helper
INFO - 2018-03-27 17:38:06 --> Helper loaded: form_helper
INFO - 2018-03-27 17:38:06 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:38:06 --> Controller Class Initialized
INFO - 2018-03-27 17:38:06 --> Model Class Initialized
INFO - 2018-03-27 17:38:06 --> Model Class Initialized
INFO - 2018-03-27 17:38:06 --> Model Class Initialized
INFO - 2018-03-27 17:38:06 --> Model Class Initialized
INFO - 2018-03-27 17:38:06 --> Model Class Initialized
INFO - 2018-03-27 17:38:06 --> Model Class Initialized
INFO - 2018-03-27 17:38:06 --> Model Class Initialized
INFO - 2018-03-27 17:38:06 --> Model Class Initialized
INFO - 2018-03-27 17:38:06 --> Model Class Initialized
INFO - 2018-03-27 17:38:06 --> Model Class Initialized
INFO - 2018-03-27 17:38:06 --> Model Class Initialized
INFO - 2018-03-27 17:38:06 --> Model Class Initialized
INFO - 2018-03-27 17:38:06 --> Model Class Initialized
INFO - 2018-03-27 17:38:06 --> Model Class Initialized
INFO - 2018-03-27 17:38:06 --> Model Class Initialized
INFO - 2018-03-27 17:38:06 --> Helper loaded: date_helper
INFO - 2018-03-27 17:38:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:38:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 22:38:06 --> Final output sent to browser
DEBUG - 2018-03-27 22:38:06 --> Total execution time: 0.1069
INFO - 2018-03-27 17:38:08 --> Config Class Initialized
INFO - 2018-03-27 17:38:08 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:38:08 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:38:08 --> Utf8 Class Initialized
INFO - 2018-03-27 17:38:08 --> URI Class Initialized
INFO - 2018-03-27 17:38:08 --> Router Class Initialized
INFO - 2018-03-27 17:38:08 --> Output Class Initialized
INFO - 2018-03-27 17:38:08 --> Security Class Initialized
DEBUG - 2018-03-27 17:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:38:08 --> Input Class Initialized
INFO - 2018-03-27 17:38:08 --> Language Class Initialized
INFO - 2018-03-27 17:38:08 --> Loader Class Initialized
INFO - 2018-03-27 17:38:08 --> Helper loaded: url_helper
INFO - 2018-03-27 17:38:08 --> Helper loaded: form_helper
INFO - 2018-03-27 17:38:08 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:38:08 --> Controller Class Initialized
INFO - 2018-03-27 17:38:08 --> Model Class Initialized
INFO - 2018-03-27 17:38:08 --> Model Class Initialized
INFO - 2018-03-27 17:38:08 --> Model Class Initialized
INFO - 2018-03-27 17:38:08 --> Model Class Initialized
INFO - 2018-03-27 17:38:08 --> Model Class Initialized
INFO - 2018-03-27 17:38:08 --> Model Class Initialized
INFO - 2018-03-27 17:38:08 --> Model Class Initialized
INFO - 2018-03-27 17:38:08 --> Model Class Initialized
INFO - 2018-03-27 17:38:08 --> Model Class Initialized
INFO - 2018-03-27 17:38:08 --> Model Class Initialized
INFO - 2018-03-27 17:38:08 --> Model Class Initialized
INFO - 2018-03-27 17:38:08 --> Model Class Initialized
INFO - 2018-03-27 17:38:08 --> Model Class Initialized
INFO - 2018-03-27 17:38:08 --> Model Class Initialized
INFO - 2018-03-27 17:38:08 --> Model Class Initialized
INFO - 2018-03-27 17:38:08 --> Helper loaded: date_helper
INFO - 2018-03-27 17:38:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:38:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/print.php
INFO - 2018-03-27 22:38:08 --> Final output sent to browser
DEBUG - 2018-03-27 22:38:08 --> Total execution time: 0.1052
INFO - 2018-03-27 17:39:05 --> Config Class Initialized
INFO - 2018-03-27 17:39:05 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:39:05 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:39:05 --> Utf8 Class Initialized
INFO - 2018-03-27 17:39:05 --> URI Class Initialized
INFO - 2018-03-27 17:39:05 --> Router Class Initialized
INFO - 2018-03-27 17:39:05 --> Output Class Initialized
INFO - 2018-03-27 17:39:05 --> Security Class Initialized
DEBUG - 2018-03-27 17:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:39:05 --> Input Class Initialized
INFO - 2018-03-27 17:39:05 --> Language Class Initialized
INFO - 2018-03-27 17:39:05 --> Loader Class Initialized
INFO - 2018-03-27 17:39:05 --> Helper loaded: url_helper
INFO - 2018-03-27 17:39:05 --> Helper loaded: form_helper
INFO - 2018-03-27 17:39:05 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:39:05 --> Controller Class Initialized
INFO - 2018-03-27 17:39:05 --> Model Class Initialized
INFO - 2018-03-27 17:39:05 --> Model Class Initialized
INFO - 2018-03-27 17:39:05 --> Model Class Initialized
INFO - 2018-03-27 17:39:05 --> Model Class Initialized
INFO - 2018-03-27 17:39:05 --> Model Class Initialized
INFO - 2018-03-27 17:39:05 --> Model Class Initialized
INFO - 2018-03-27 17:39:05 --> Model Class Initialized
INFO - 2018-03-27 17:39:05 --> Model Class Initialized
INFO - 2018-03-27 17:39:05 --> Model Class Initialized
INFO - 2018-03-27 17:39:05 --> Model Class Initialized
INFO - 2018-03-27 17:39:05 --> Model Class Initialized
INFO - 2018-03-27 17:39:05 --> Model Class Initialized
INFO - 2018-03-27 17:39:05 --> Model Class Initialized
INFO - 2018-03-27 17:39:05 --> Model Class Initialized
INFO - 2018-03-27 17:39:05 --> Model Class Initialized
INFO - 2018-03-27 17:39:05 --> Helper loaded: date_helper
INFO - 2018-03-27 17:39:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:39:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/print.php
INFO - 2018-03-27 22:39:05 --> Final output sent to browser
DEBUG - 2018-03-27 22:39:05 --> Total execution time: 0.1124
INFO - 2018-03-27 17:39:09 --> Config Class Initialized
INFO - 2018-03-27 17:39:09 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:39:09 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:39:09 --> Utf8 Class Initialized
INFO - 2018-03-27 17:39:09 --> URI Class Initialized
INFO - 2018-03-27 17:39:09 --> Router Class Initialized
INFO - 2018-03-27 17:39:09 --> Output Class Initialized
INFO - 2018-03-27 17:39:09 --> Security Class Initialized
DEBUG - 2018-03-27 17:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:39:09 --> Input Class Initialized
INFO - 2018-03-27 17:39:09 --> Language Class Initialized
INFO - 2018-03-27 17:39:09 --> Loader Class Initialized
INFO - 2018-03-27 17:39:09 --> Helper loaded: url_helper
INFO - 2018-03-27 17:39:09 --> Helper loaded: form_helper
INFO - 2018-03-27 17:39:09 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:39:09 --> Controller Class Initialized
INFO - 2018-03-27 17:39:09 --> Model Class Initialized
INFO - 2018-03-27 17:39:09 --> Model Class Initialized
INFO - 2018-03-27 17:39:09 --> Model Class Initialized
INFO - 2018-03-27 17:39:09 --> Model Class Initialized
INFO - 2018-03-27 17:39:09 --> Model Class Initialized
INFO - 2018-03-27 17:39:09 --> Model Class Initialized
INFO - 2018-03-27 17:39:09 --> Model Class Initialized
INFO - 2018-03-27 17:39:09 --> Model Class Initialized
INFO - 2018-03-27 17:39:09 --> Model Class Initialized
INFO - 2018-03-27 17:39:09 --> Model Class Initialized
INFO - 2018-03-27 17:39:09 --> Model Class Initialized
INFO - 2018-03-27 17:39:09 --> Model Class Initialized
INFO - 2018-03-27 17:39:09 --> Model Class Initialized
INFO - 2018-03-27 17:39:09 --> Model Class Initialized
INFO - 2018-03-27 17:39:09 --> Model Class Initialized
INFO - 2018-03-27 17:39:09 --> Helper loaded: date_helper
INFO - 2018-03-27 17:39:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:39:09 --> Model Class Initialized
INFO - 2018-03-27 22:39:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 22:39:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 22:39:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 22:39:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 22:39:09 --> Final output sent to browser
DEBUG - 2018-03-27 22:39:09 --> Total execution time: 0.0995
INFO - 2018-03-27 17:39:15 --> Config Class Initialized
INFO - 2018-03-27 17:39:15 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:39:15 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:39:15 --> Utf8 Class Initialized
INFO - 2018-03-27 17:39:15 --> URI Class Initialized
INFO - 2018-03-27 17:39:15 --> Router Class Initialized
INFO - 2018-03-27 17:39:15 --> Output Class Initialized
INFO - 2018-03-27 17:39:15 --> Security Class Initialized
DEBUG - 2018-03-27 17:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:39:15 --> Input Class Initialized
INFO - 2018-03-27 17:39:15 --> Language Class Initialized
INFO - 2018-03-27 17:39:15 --> Loader Class Initialized
INFO - 2018-03-27 17:39:15 --> Helper loaded: url_helper
INFO - 2018-03-27 17:39:15 --> Helper loaded: form_helper
INFO - 2018-03-27 17:39:15 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:39:15 --> Controller Class Initialized
INFO - 2018-03-27 17:39:15 --> Model Class Initialized
INFO - 2018-03-27 17:39:15 --> Model Class Initialized
INFO - 2018-03-27 17:39:15 --> Model Class Initialized
INFO - 2018-03-27 17:39:15 --> Model Class Initialized
INFO - 2018-03-27 17:39:15 --> Model Class Initialized
INFO - 2018-03-27 17:39:15 --> Model Class Initialized
INFO - 2018-03-27 17:39:15 --> Model Class Initialized
INFO - 2018-03-27 17:39:15 --> Model Class Initialized
INFO - 2018-03-27 17:39:15 --> Model Class Initialized
INFO - 2018-03-27 17:39:15 --> Model Class Initialized
INFO - 2018-03-27 17:39:15 --> Model Class Initialized
INFO - 2018-03-27 17:39:15 --> Model Class Initialized
INFO - 2018-03-27 17:39:15 --> Model Class Initialized
INFO - 2018-03-27 17:39:15 --> Model Class Initialized
INFO - 2018-03-27 17:39:15 --> Model Class Initialized
INFO - 2018-03-27 17:39:15 --> Helper loaded: date_helper
INFO - 2018-03-27 17:39:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:39:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-27 22:39:15 --> Final output sent to browser
DEBUG - 2018-03-27 22:39:15 --> Total execution time: 0.1006
INFO - 2018-03-27 17:39:16 --> Config Class Initialized
INFO - 2018-03-27 17:39:16 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:39:16 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:39:16 --> Utf8 Class Initialized
INFO - 2018-03-27 17:39:16 --> URI Class Initialized
INFO - 2018-03-27 17:39:16 --> Router Class Initialized
INFO - 2018-03-27 17:39:16 --> Output Class Initialized
INFO - 2018-03-27 17:39:16 --> Security Class Initialized
DEBUG - 2018-03-27 17:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:39:16 --> Input Class Initialized
INFO - 2018-03-27 17:39:16 --> Language Class Initialized
INFO - 2018-03-27 17:39:16 --> Loader Class Initialized
INFO - 2018-03-27 17:39:16 --> Helper loaded: url_helper
INFO - 2018-03-27 17:39:16 --> Helper loaded: form_helper
INFO - 2018-03-27 17:39:16 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:39:16 --> Controller Class Initialized
INFO - 2018-03-27 17:39:16 --> Model Class Initialized
INFO - 2018-03-27 17:39:16 --> Model Class Initialized
INFO - 2018-03-27 17:39:16 --> Model Class Initialized
INFO - 2018-03-27 17:39:16 --> Model Class Initialized
INFO - 2018-03-27 17:39:16 --> Model Class Initialized
INFO - 2018-03-27 17:39:16 --> Model Class Initialized
INFO - 2018-03-27 17:39:16 --> Model Class Initialized
INFO - 2018-03-27 17:39:16 --> Model Class Initialized
INFO - 2018-03-27 17:39:16 --> Model Class Initialized
INFO - 2018-03-27 17:39:16 --> Model Class Initialized
INFO - 2018-03-27 17:39:16 --> Model Class Initialized
INFO - 2018-03-27 17:39:16 --> Model Class Initialized
INFO - 2018-03-27 17:39:16 --> Model Class Initialized
INFO - 2018-03-27 17:39:16 --> Model Class Initialized
INFO - 2018-03-27 17:39:16 --> Model Class Initialized
INFO - 2018-03-27 17:39:16 --> Helper loaded: date_helper
INFO - 2018-03-27 17:39:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:39:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/print.php
INFO - 2018-03-27 22:39:16 --> Final output sent to browser
DEBUG - 2018-03-27 22:39:16 --> Total execution time: 0.1161
INFO - 2018-03-27 17:44:12 --> Config Class Initialized
INFO - 2018-03-27 17:44:12 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:44:12 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:44:12 --> Utf8 Class Initialized
INFO - 2018-03-27 17:44:12 --> URI Class Initialized
INFO - 2018-03-27 17:44:12 --> Router Class Initialized
INFO - 2018-03-27 17:44:12 --> Output Class Initialized
INFO - 2018-03-27 17:44:12 --> Security Class Initialized
DEBUG - 2018-03-27 17:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:44:12 --> Input Class Initialized
INFO - 2018-03-27 17:44:12 --> Language Class Initialized
INFO - 2018-03-27 17:44:12 --> Loader Class Initialized
INFO - 2018-03-27 17:44:12 --> Helper loaded: url_helper
INFO - 2018-03-27 17:44:12 --> Helper loaded: form_helper
INFO - 2018-03-27 17:44:12 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:44:12 --> Controller Class Initialized
INFO - 2018-03-27 17:44:12 --> Model Class Initialized
INFO - 2018-03-27 17:44:12 --> Model Class Initialized
INFO - 2018-03-27 17:44:12 --> Model Class Initialized
INFO - 2018-03-27 17:44:12 --> Model Class Initialized
INFO - 2018-03-27 17:44:12 --> Model Class Initialized
INFO - 2018-03-27 17:44:12 --> Helper loaded: date_helper
INFO - 2018-03-27 22:44:12 --> Model Class Initialized
INFO - 2018-03-27 22:44:12 --> Model Class Initialized
INFO - 2018-03-27 22:44:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 22:44:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 22:44:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-27 22:44:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 22:44:12 --> Final output sent to browser
DEBUG - 2018-03-27 22:44:12 --> Total execution time: 0.1847
INFO - 2018-03-27 17:44:21 --> Config Class Initialized
INFO - 2018-03-27 17:44:21 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:44:21 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:44:21 --> Utf8 Class Initialized
INFO - 2018-03-27 17:44:21 --> URI Class Initialized
INFO - 2018-03-27 17:44:21 --> Router Class Initialized
INFO - 2018-03-27 17:44:21 --> Output Class Initialized
INFO - 2018-03-27 17:44:21 --> Security Class Initialized
DEBUG - 2018-03-27 17:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:44:21 --> Input Class Initialized
INFO - 2018-03-27 17:44:21 --> Language Class Initialized
INFO - 2018-03-27 17:44:21 --> Loader Class Initialized
INFO - 2018-03-27 17:44:21 --> Helper loaded: url_helper
INFO - 2018-03-27 17:44:21 --> Helper loaded: form_helper
INFO - 2018-03-27 17:44:21 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:44:21 --> Controller Class Initialized
INFO - 2018-03-27 17:44:21 --> Model Class Initialized
INFO - 2018-03-27 17:44:21 --> Model Class Initialized
INFO - 2018-03-27 17:44:21 --> Model Class Initialized
INFO - 2018-03-27 17:44:21 --> Model Class Initialized
INFO - 2018-03-27 17:44:21 --> Model Class Initialized
INFO - 2018-03-27 17:44:21 --> Helper loaded: date_helper
INFO - 2018-03-27 22:44:21 --> Model Class Initialized
INFO - 2018-03-27 22:44:21 --> Model Class Initialized
INFO - 2018-03-27 22:44:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 22:44:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 22:44:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/create.php
INFO - 2018-03-27 22:44:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 22:44:21 --> Final output sent to browser
DEBUG - 2018-03-27 22:44:21 --> Total execution time: 0.0795
INFO - 2018-03-27 17:45:02 --> Config Class Initialized
INFO - 2018-03-27 17:45:02 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:45:02 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:45:02 --> Utf8 Class Initialized
INFO - 2018-03-27 17:45:02 --> URI Class Initialized
INFO - 2018-03-27 17:45:02 --> Router Class Initialized
INFO - 2018-03-27 17:45:02 --> Output Class Initialized
INFO - 2018-03-27 17:45:02 --> Security Class Initialized
DEBUG - 2018-03-27 17:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:45:02 --> Input Class Initialized
INFO - 2018-03-27 17:45:02 --> Language Class Initialized
INFO - 2018-03-27 17:45:02 --> Loader Class Initialized
INFO - 2018-03-27 17:45:02 --> Helper loaded: url_helper
INFO - 2018-03-27 17:45:02 --> Helper loaded: form_helper
INFO - 2018-03-27 17:45:02 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:45:02 --> Controller Class Initialized
INFO - 2018-03-27 17:45:02 --> Model Class Initialized
INFO - 2018-03-27 17:45:02 --> Model Class Initialized
INFO - 2018-03-27 17:45:02 --> Model Class Initialized
INFO - 2018-03-27 17:45:02 --> Model Class Initialized
INFO - 2018-03-27 17:45:02 --> Model Class Initialized
INFO - 2018-03-27 17:45:02 --> Helper loaded: date_helper
INFO - 2018-03-27 17:45:02 --> Config Class Initialized
INFO - 2018-03-27 17:45:02 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:45:02 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:45:02 --> Utf8 Class Initialized
INFO - 2018-03-27 17:45:02 --> URI Class Initialized
INFO - 2018-03-27 17:45:02 --> Router Class Initialized
INFO - 2018-03-27 17:45:02 --> Output Class Initialized
INFO - 2018-03-27 17:45:02 --> Security Class Initialized
DEBUG - 2018-03-27 17:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:45:02 --> Input Class Initialized
INFO - 2018-03-27 17:45:02 --> Language Class Initialized
INFO - 2018-03-27 17:45:02 --> Loader Class Initialized
INFO - 2018-03-27 17:45:02 --> Helper loaded: url_helper
INFO - 2018-03-27 17:45:02 --> Helper loaded: form_helper
INFO - 2018-03-27 17:45:02 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:45:02 --> Controller Class Initialized
INFO - 2018-03-27 17:45:02 --> Model Class Initialized
INFO - 2018-03-27 17:45:02 --> Model Class Initialized
INFO - 2018-03-27 17:45:02 --> Model Class Initialized
INFO - 2018-03-27 17:45:02 --> Model Class Initialized
INFO - 2018-03-27 17:45:02 --> Model Class Initialized
INFO - 2018-03-27 17:45:02 --> Helper loaded: date_helper
INFO - 2018-03-27 22:45:02 --> Model Class Initialized
INFO - 2018-03-27 22:45:02 --> Model Class Initialized
INFO - 2018-03-27 22:45:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 22:45:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 22:45:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-27 22:45:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 22:45:02 --> Final output sent to browser
DEBUG - 2018-03-27 22:45:02 --> Total execution time: 0.0892
INFO - 2018-03-27 17:45:17 --> Config Class Initialized
INFO - 2018-03-27 17:45:17 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:45:17 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:45:17 --> Utf8 Class Initialized
INFO - 2018-03-27 17:45:17 --> URI Class Initialized
INFO - 2018-03-27 17:45:17 --> Router Class Initialized
INFO - 2018-03-27 17:45:17 --> Output Class Initialized
INFO - 2018-03-27 17:45:17 --> Security Class Initialized
DEBUG - 2018-03-27 17:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:45:17 --> Input Class Initialized
INFO - 2018-03-27 17:45:17 --> Language Class Initialized
INFO - 2018-03-27 17:45:17 --> Loader Class Initialized
INFO - 2018-03-27 17:45:17 --> Helper loaded: url_helper
INFO - 2018-03-27 17:45:17 --> Helper loaded: form_helper
INFO - 2018-03-27 17:45:17 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:45:17 --> Controller Class Initialized
INFO - 2018-03-27 17:45:17 --> Model Class Initialized
INFO - 2018-03-27 17:45:17 --> Model Class Initialized
INFO - 2018-03-27 17:45:17 --> Model Class Initialized
INFO - 2018-03-27 17:45:17 --> Model Class Initialized
INFO - 2018-03-27 17:45:17 --> Model Class Initialized
INFO - 2018-03-27 17:45:17 --> Helper loaded: date_helper
INFO - 2018-03-27 22:45:17 --> Model Class Initialized
INFO - 2018-03-27 22:45:17 --> Model Class Initialized
INFO - 2018-03-27 22:45:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 22:45:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 22:45:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-27 22:45:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 22:45:17 --> Final output sent to browser
DEBUG - 2018-03-27 22:45:17 --> Total execution time: 0.1190
INFO - 2018-03-27 17:45:19 --> Config Class Initialized
INFO - 2018-03-27 17:45:19 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:45:19 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:45:19 --> Utf8 Class Initialized
INFO - 2018-03-27 17:45:19 --> URI Class Initialized
INFO - 2018-03-27 17:45:19 --> Router Class Initialized
INFO - 2018-03-27 17:45:19 --> Output Class Initialized
INFO - 2018-03-27 17:45:19 --> Security Class Initialized
DEBUG - 2018-03-27 17:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:45:19 --> Input Class Initialized
INFO - 2018-03-27 17:45:19 --> Language Class Initialized
INFO - 2018-03-27 17:45:19 --> Loader Class Initialized
INFO - 2018-03-27 17:45:19 --> Helper loaded: url_helper
INFO - 2018-03-27 17:45:19 --> Helper loaded: form_helper
INFO - 2018-03-27 17:45:19 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:45:19 --> Controller Class Initialized
INFO - 2018-03-27 17:45:19 --> Model Class Initialized
INFO - 2018-03-27 17:45:19 --> Model Class Initialized
INFO - 2018-03-27 17:45:19 --> Model Class Initialized
INFO - 2018-03-27 17:45:19 --> Model Class Initialized
INFO - 2018-03-27 17:45:19 --> Model Class Initialized
INFO - 2018-03-27 17:45:19 --> Helper loaded: date_helper
INFO - 2018-03-27 22:45:19 --> Model Class Initialized
INFO - 2018-03-27 22:45:19 --> Model Class Initialized
INFO - 2018-03-27 22:45:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 22:45:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 22:45:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/create.php
INFO - 2018-03-27 22:45:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 22:45:19 --> Final output sent to browser
DEBUG - 2018-03-27 22:45:19 --> Total execution time: 0.1098
INFO - 2018-03-27 17:45:29 --> Config Class Initialized
INFO - 2018-03-27 17:45:29 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:45:29 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:45:29 --> Utf8 Class Initialized
INFO - 2018-03-27 17:45:29 --> URI Class Initialized
INFO - 2018-03-27 17:45:29 --> Router Class Initialized
INFO - 2018-03-27 17:45:29 --> Output Class Initialized
INFO - 2018-03-27 17:45:29 --> Security Class Initialized
DEBUG - 2018-03-27 17:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:45:29 --> Input Class Initialized
INFO - 2018-03-27 17:45:29 --> Language Class Initialized
INFO - 2018-03-27 17:45:29 --> Loader Class Initialized
INFO - 2018-03-27 17:45:29 --> Helper loaded: url_helper
INFO - 2018-03-27 17:45:29 --> Helper loaded: form_helper
INFO - 2018-03-27 17:45:29 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:45:29 --> Controller Class Initialized
INFO - 2018-03-27 17:45:29 --> Model Class Initialized
INFO - 2018-03-27 17:45:29 --> Model Class Initialized
INFO - 2018-03-27 17:45:29 --> Model Class Initialized
INFO - 2018-03-27 17:45:29 --> Model Class Initialized
INFO - 2018-03-27 17:45:29 --> Model Class Initialized
INFO - 2018-03-27 17:45:29 --> Helper loaded: date_helper
INFO - 2018-03-27 17:45:30 --> Config Class Initialized
INFO - 2018-03-27 17:45:30 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:45:30 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:45:30 --> Utf8 Class Initialized
INFO - 2018-03-27 17:45:30 --> URI Class Initialized
INFO - 2018-03-27 17:45:30 --> Router Class Initialized
INFO - 2018-03-27 17:45:30 --> Output Class Initialized
INFO - 2018-03-27 17:45:30 --> Security Class Initialized
DEBUG - 2018-03-27 17:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:45:30 --> Input Class Initialized
INFO - 2018-03-27 17:45:30 --> Language Class Initialized
INFO - 2018-03-27 17:45:30 --> Loader Class Initialized
INFO - 2018-03-27 17:45:30 --> Helper loaded: url_helper
INFO - 2018-03-27 17:45:30 --> Helper loaded: form_helper
INFO - 2018-03-27 17:45:30 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:45:30 --> Controller Class Initialized
INFO - 2018-03-27 17:45:30 --> Model Class Initialized
INFO - 2018-03-27 17:45:30 --> Model Class Initialized
INFO - 2018-03-27 17:45:30 --> Model Class Initialized
INFO - 2018-03-27 17:45:30 --> Model Class Initialized
INFO - 2018-03-27 17:45:30 --> Model Class Initialized
INFO - 2018-03-27 17:45:30 --> Helper loaded: date_helper
INFO - 2018-03-27 22:45:30 --> Model Class Initialized
INFO - 2018-03-27 22:45:30 --> Model Class Initialized
INFO - 2018-03-27 22:45:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 22:45:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 22:45:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-27 22:45:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 22:45:30 --> Final output sent to browser
DEBUG - 2018-03-27 22:45:30 --> Total execution time: 0.1130
INFO - 2018-03-27 17:46:18 --> Config Class Initialized
INFO - 2018-03-27 17:46:18 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:46:18 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:46:18 --> Utf8 Class Initialized
INFO - 2018-03-27 17:46:18 --> URI Class Initialized
INFO - 2018-03-27 17:46:18 --> Router Class Initialized
INFO - 2018-03-27 17:46:18 --> Output Class Initialized
INFO - 2018-03-27 17:46:18 --> Security Class Initialized
DEBUG - 2018-03-27 17:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:46:18 --> Input Class Initialized
INFO - 2018-03-27 17:46:18 --> Language Class Initialized
INFO - 2018-03-27 17:46:18 --> Loader Class Initialized
INFO - 2018-03-27 17:46:18 --> Helper loaded: url_helper
INFO - 2018-03-27 17:46:18 --> Helper loaded: form_helper
INFO - 2018-03-27 17:46:18 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:46:18 --> Controller Class Initialized
INFO - 2018-03-27 17:46:18 --> Model Class Initialized
INFO - 2018-03-27 17:46:18 --> Model Class Initialized
INFO - 2018-03-27 17:46:18 --> Model Class Initialized
INFO - 2018-03-27 17:46:18 --> Model Class Initialized
INFO - 2018-03-27 17:46:18 --> Model Class Initialized
INFO - 2018-03-27 17:46:18 --> Model Class Initialized
INFO - 2018-03-27 17:46:18 --> Model Class Initialized
INFO - 2018-03-27 17:46:18 --> Model Class Initialized
INFO - 2018-03-27 17:46:18 --> Model Class Initialized
INFO - 2018-03-27 17:46:18 --> Model Class Initialized
INFO - 2018-03-27 17:46:18 --> Model Class Initialized
INFO - 2018-03-27 17:46:18 --> Model Class Initialized
INFO - 2018-03-27 17:46:18 --> Model Class Initialized
INFO - 2018-03-27 17:46:18 --> Model Class Initialized
INFO - 2018-03-27 17:46:18 --> Model Class Initialized
INFO - 2018-03-27 17:46:18 --> Helper loaded: date_helper
INFO - 2018-03-27 17:46:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:46:18 --> Model Class Initialized
INFO - 2018-03-27 22:46:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 22:46:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 22:46:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-27 22:46:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 22:46:18 --> Final output sent to browser
DEBUG - 2018-03-27 22:46:18 --> Total execution time: 0.1004
INFO - 2018-03-27 17:46:29 --> Config Class Initialized
INFO - 2018-03-27 17:46:29 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:46:29 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:46:29 --> Utf8 Class Initialized
INFO - 2018-03-27 17:46:29 --> URI Class Initialized
INFO - 2018-03-27 17:46:29 --> Router Class Initialized
INFO - 2018-03-27 17:46:29 --> Output Class Initialized
INFO - 2018-03-27 17:46:29 --> Security Class Initialized
DEBUG - 2018-03-27 17:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:46:29 --> Input Class Initialized
INFO - 2018-03-27 17:46:29 --> Language Class Initialized
INFO - 2018-03-27 17:46:29 --> Loader Class Initialized
INFO - 2018-03-27 17:46:29 --> Helper loaded: url_helper
INFO - 2018-03-27 17:46:29 --> Helper loaded: form_helper
INFO - 2018-03-27 17:46:29 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:46:29 --> Controller Class Initialized
INFO - 2018-03-27 17:46:29 --> Model Class Initialized
INFO - 2018-03-27 17:46:29 --> Model Class Initialized
INFO - 2018-03-27 17:46:29 --> Model Class Initialized
INFO - 2018-03-27 17:46:29 --> Model Class Initialized
INFO - 2018-03-27 17:46:29 --> Model Class Initialized
INFO - 2018-03-27 17:46:29 --> Helper loaded: date_helper
INFO - 2018-03-27 17:46:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:46:29 --> Model Class Initialized
INFO - 2018-03-27 22:46:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 22:46:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 22:46:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-27 22:46:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 22:46:29 --> Final output sent to browser
DEBUG - 2018-03-27 22:46:29 --> Total execution time: 0.2646
INFO - 2018-03-27 17:46:40 --> Config Class Initialized
INFO - 2018-03-27 17:46:40 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:46:40 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:46:40 --> Utf8 Class Initialized
INFO - 2018-03-27 17:46:40 --> URI Class Initialized
INFO - 2018-03-27 17:46:40 --> Router Class Initialized
INFO - 2018-03-27 17:46:40 --> Output Class Initialized
INFO - 2018-03-27 17:46:40 --> Security Class Initialized
DEBUG - 2018-03-27 17:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:46:40 --> Input Class Initialized
INFO - 2018-03-27 17:46:40 --> Language Class Initialized
INFO - 2018-03-27 17:46:40 --> Loader Class Initialized
INFO - 2018-03-27 17:46:40 --> Helper loaded: url_helper
INFO - 2018-03-27 17:46:40 --> Helper loaded: form_helper
INFO - 2018-03-27 17:46:40 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:46:40 --> Controller Class Initialized
INFO - 2018-03-27 17:46:40 --> Model Class Initialized
INFO - 2018-03-27 17:46:40 --> Model Class Initialized
INFO - 2018-03-27 17:46:40 --> Model Class Initialized
INFO - 2018-03-27 17:46:40 --> Model Class Initialized
INFO - 2018-03-27 17:46:40 --> Model Class Initialized
INFO - 2018-03-27 17:46:40 --> Helper loaded: date_helper
INFO - 2018-03-27 17:46:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:46:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/list.php
INFO - 2018-03-27 22:46:40 --> Final output sent to browser
DEBUG - 2018-03-27 22:46:40 --> Total execution time: 0.1302
INFO - 2018-03-27 17:47:47 --> Config Class Initialized
INFO - 2018-03-27 17:47:47 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:47:47 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:47:47 --> Utf8 Class Initialized
INFO - 2018-03-27 17:47:47 --> URI Class Initialized
INFO - 2018-03-27 17:47:47 --> Router Class Initialized
INFO - 2018-03-27 17:47:47 --> Output Class Initialized
INFO - 2018-03-27 17:47:47 --> Security Class Initialized
DEBUG - 2018-03-27 17:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:47:47 --> Input Class Initialized
INFO - 2018-03-27 17:47:47 --> Language Class Initialized
INFO - 2018-03-27 17:47:47 --> Loader Class Initialized
INFO - 2018-03-27 17:47:47 --> Helper loaded: url_helper
INFO - 2018-03-27 17:47:47 --> Helper loaded: form_helper
INFO - 2018-03-27 17:47:47 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:47:47 --> Controller Class Initialized
INFO - 2018-03-27 17:47:47 --> Model Class Initialized
INFO - 2018-03-27 17:47:47 --> Model Class Initialized
INFO - 2018-03-27 17:47:47 --> Model Class Initialized
INFO - 2018-03-27 17:47:47 --> Model Class Initialized
INFO - 2018-03-27 17:47:47 --> Model Class Initialized
INFO - 2018-03-27 17:47:47 --> Helper loaded: date_helper
INFO - 2018-03-27 17:47:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:47:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/list.php
INFO - 2018-03-27 22:47:47 --> Final output sent to browser
DEBUG - 2018-03-27 22:47:47 --> Total execution time: 0.0824
INFO - 2018-03-27 17:47:49 --> Config Class Initialized
INFO - 2018-03-27 17:47:49 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:47:49 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:47:49 --> Utf8 Class Initialized
INFO - 2018-03-27 17:47:49 --> URI Class Initialized
INFO - 2018-03-27 17:47:49 --> Router Class Initialized
INFO - 2018-03-27 17:47:49 --> Output Class Initialized
INFO - 2018-03-27 17:47:49 --> Security Class Initialized
DEBUG - 2018-03-27 17:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:47:49 --> Input Class Initialized
INFO - 2018-03-27 17:47:49 --> Language Class Initialized
INFO - 2018-03-27 17:47:49 --> Loader Class Initialized
INFO - 2018-03-27 17:47:49 --> Helper loaded: url_helper
INFO - 2018-03-27 17:47:49 --> Helper loaded: form_helper
INFO - 2018-03-27 17:47:49 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:47:49 --> Controller Class Initialized
INFO - 2018-03-27 17:47:49 --> Model Class Initialized
INFO - 2018-03-27 17:47:49 --> Model Class Initialized
INFO - 2018-03-27 17:47:49 --> Model Class Initialized
INFO - 2018-03-27 17:47:49 --> Model Class Initialized
INFO - 2018-03-27 17:47:49 --> Model Class Initialized
INFO - 2018-03-27 17:47:49 --> Helper loaded: date_helper
INFO - 2018-03-27 17:47:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:47:49 --> Model Class Initialized
INFO - 2018-03-27 22:47:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 22:47:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 22:47:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/detail.php
INFO - 2018-03-27 22:47:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 22:47:49 --> Final output sent to browser
DEBUG - 2018-03-27 22:47:49 --> Total execution time: 0.1418
INFO - 2018-03-27 17:48:52 --> Config Class Initialized
INFO - 2018-03-27 17:48:52 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:48:52 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:48:52 --> Utf8 Class Initialized
INFO - 2018-03-27 17:48:52 --> URI Class Initialized
INFO - 2018-03-27 17:48:52 --> Router Class Initialized
INFO - 2018-03-27 17:48:52 --> Output Class Initialized
INFO - 2018-03-27 17:48:52 --> Security Class Initialized
DEBUG - 2018-03-27 17:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:48:52 --> Input Class Initialized
INFO - 2018-03-27 17:48:52 --> Language Class Initialized
INFO - 2018-03-27 17:48:52 --> Loader Class Initialized
INFO - 2018-03-27 17:48:52 --> Helper loaded: url_helper
INFO - 2018-03-27 17:48:52 --> Helper loaded: form_helper
INFO - 2018-03-27 17:48:52 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:48:52 --> Controller Class Initialized
INFO - 2018-03-27 17:48:52 --> Model Class Initialized
INFO - 2018-03-27 17:48:52 --> Model Class Initialized
INFO - 2018-03-27 17:48:52 --> Helper loaded: date_helper
INFO - 2018-03-27 17:48:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 22:48:52 --> Model Class Initialized
INFO - 2018-03-27 22:48:52 --> Model Class Initialized
INFO - 2018-03-27 22:48:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 22:48:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 22:48:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-27 22:48:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 22:48:52 --> Final output sent to browser
DEBUG - 2018-03-27 22:48:52 --> Total execution time: 0.1938
INFO - 2018-03-27 17:49:02 --> Config Class Initialized
INFO - 2018-03-27 17:49:02 --> Hooks Class Initialized
DEBUG - 2018-03-27 17:49:02 --> UTF-8 Support Enabled
INFO - 2018-03-27 17:49:02 --> Utf8 Class Initialized
INFO - 2018-03-27 17:49:02 --> URI Class Initialized
INFO - 2018-03-27 17:49:02 --> Router Class Initialized
INFO - 2018-03-27 17:49:02 --> Output Class Initialized
INFO - 2018-03-27 17:49:02 --> Security Class Initialized
DEBUG - 2018-03-27 17:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 17:49:02 --> Input Class Initialized
INFO - 2018-03-27 17:49:02 --> Language Class Initialized
INFO - 2018-03-27 17:49:02 --> Loader Class Initialized
INFO - 2018-03-27 17:49:02 --> Helper loaded: url_helper
INFO - 2018-03-27 17:49:02 --> Helper loaded: form_helper
INFO - 2018-03-27 17:49:02 --> Database Driver Class Initialized
DEBUG - 2018-03-27 17:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 17:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 17:49:02 --> Controller Class Initialized
INFO - 2018-03-27 17:49:02 --> Model Class Initialized
INFO - 2018-03-27 17:49:02 --> Model Class Initialized
INFO - 2018-03-27 17:49:02 --> Model Class Initialized
INFO - 2018-03-27 17:49:02 --> Model Class Initialized
INFO - 2018-03-27 17:49:02 --> Model Class Initialized
INFO - 2018-03-27 17:49:02 --> Helper loaded: date_helper
INFO - 2018-03-27 22:49:02 --> Model Class Initialized
INFO - 2018-03-27 22:49:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 22:49:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-27 22:49:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-27 22:49:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-27 22:49:02 --> Final output sent to browser
DEBUG - 2018-03-27 22:49:02 --> Total execution time: 0.0883
INFO - 2018-03-27 18:46:22 --> Config Class Initialized
INFO - 2018-03-27 18:46:22 --> Hooks Class Initialized
DEBUG - 2018-03-27 18:46:22 --> UTF-8 Support Enabled
INFO - 2018-03-27 18:46:22 --> Utf8 Class Initialized
INFO - 2018-03-27 18:46:22 --> URI Class Initialized
INFO - 2018-03-27 18:46:22 --> Router Class Initialized
INFO - 2018-03-27 18:46:22 --> Output Class Initialized
INFO - 2018-03-27 18:46:22 --> Security Class Initialized
DEBUG - 2018-03-27 18:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 18:46:22 --> Input Class Initialized
INFO - 2018-03-27 18:46:22 --> Language Class Initialized
INFO - 2018-03-27 18:46:22 --> Loader Class Initialized
INFO - 2018-03-27 18:46:22 --> Helper loaded: url_helper
INFO - 2018-03-27 18:46:22 --> Helper loaded: form_helper
INFO - 2018-03-27 18:46:22 --> Database Driver Class Initialized
DEBUG - 2018-03-27 18:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 18:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 18:46:22 --> Controller Class Initialized
INFO - 2018-03-27 18:46:22 --> Model Class Initialized
INFO - 2018-03-27 18:46:22 --> Model Class Initialized
INFO - 2018-03-27 18:46:22 --> Model Class Initialized
INFO - 2018-03-27 18:46:22 --> Model Class Initialized
INFO - 2018-03-27 18:46:22 --> Model Class Initialized
INFO - 2018-03-27 18:46:22 --> Model Class Initialized
INFO - 2018-03-27 18:46:22 --> Model Class Initialized
INFO - 2018-03-27 18:46:22 --> Model Class Initialized
INFO - 2018-03-27 18:46:22 --> Model Class Initialized
INFO - 2018-03-27 18:46:22 --> Model Class Initialized
INFO - 2018-03-27 18:46:22 --> Model Class Initialized
INFO - 2018-03-27 18:46:22 --> Model Class Initialized
INFO - 2018-03-27 18:46:22 --> Model Class Initialized
INFO - 2018-03-27 18:46:22 --> Model Class Initialized
INFO - 2018-03-27 18:46:22 --> Model Class Initialized
INFO - 2018-03-27 18:46:22 --> Helper loaded: date_helper
INFO - 2018-03-27 18:46:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-27 23:46:22 --> Model Class Initialized
INFO - 2018-03-27 23:46:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-27 23:46:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
