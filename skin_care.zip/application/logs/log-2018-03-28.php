<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-28 14:47:05 --> Config Class Initialized
INFO - 2018-03-28 14:47:05 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:47:05 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:47:05 --> Utf8 Class Initialized
INFO - 2018-03-28 14:47:05 --> URI Class Initialized
DEBUG - 2018-03-28 14:47:05 --> No URI present. Default controller set.
INFO - 2018-03-28 14:47:05 --> Router Class Initialized
INFO - 2018-03-28 14:47:05 --> Output Class Initialized
INFO - 2018-03-28 14:47:05 --> Security Class Initialized
DEBUG - 2018-03-28 14:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:47:05 --> Input Class Initialized
INFO - 2018-03-28 14:47:05 --> Language Class Initialized
INFO - 2018-03-28 14:47:05 --> Loader Class Initialized
INFO - 2018-03-28 14:47:05 --> Helper loaded: url_helper
INFO - 2018-03-28 14:47:05 --> Helper loaded: form_helper
INFO - 2018-03-28 14:47:05 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:47:05 --> Controller Class Initialized
INFO - 2018-03-28 14:47:05 --> Model Class Initialized
INFO - 2018-03-28 14:47:05 --> Model Class Initialized
INFO - 2018-03-28 14:47:05 --> Model Class Initialized
INFO - 2018-03-28 14:47:05 --> Helper loaded: date_helper
INFO - 2018-03-28 19:47:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-28 19:47:05 --> Final output sent to browser
DEBUG - 2018-03-28 19:47:05 --> Total execution time: 0.1919
INFO - 2018-03-28 14:47:15 --> Config Class Initialized
INFO - 2018-03-28 14:47:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:47:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:47:15 --> Utf8 Class Initialized
INFO - 2018-03-28 14:47:15 --> URI Class Initialized
DEBUG - 2018-03-28 14:47:15 --> No URI present. Default controller set.
INFO - 2018-03-28 14:47:15 --> Router Class Initialized
INFO - 2018-03-28 14:47:15 --> Output Class Initialized
INFO - 2018-03-28 14:47:16 --> Security Class Initialized
DEBUG - 2018-03-28 14:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:47:16 --> Input Class Initialized
INFO - 2018-03-28 14:47:16 --> Language Class Initialized
INFO - 2018-03-28 14:47:16 --> Loader Class Initialized
INFO - 2018-03-28 14:47:16 --> Helper loaded: url_helper
INFO - 2018-03-28 14:47:16 --> Helper loaded: form_helper
INFO - 2018-03-28 14:47:16 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:47:16 --> Controller Class Initialized
INFO - 2018-03-28 14:47:16 --> Model Class Initialized
INFO - 2018-03-28 14:47:16 --> Model Class Initialized
INFO - 2018-03-28 14:47:16 --> Model Class Initialized
INFO - 2018-03-28 14:47:16 --> Helper loaded: date_helper
INFO - 2018-03-28 14:47:16 --> Config Class Initialized
INFO - 2018-03-28 14:47:16 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:47:16 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:47:16 --> Utf8 Class Initialized
INFO - 2018-03-28 14:47:16 --> URI Class Initialized
INFO - 2018-03-28 14:47:16 --> Router Class Initialized
INFO - 2018-03-28 14:47:16 --> Output Class Initialized
INFO - 2018-03-28 14:47:16 --> Security Class Initialized
DEBUG - 2018-03-28 14:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:47:16 --> Input Class Initialized
INFO - 2018-03-28 14:47:16 --> Language Class Initialized
INFO - 2018-03-28 14:47:16 --> Loader Class Initialized
INFO - 2018-03-28 14:47:16 --> Helper loaded: url_helper
INFO - 2018-03-28 14:47:16 --> Helper loaded: form_helper
INFO - 2018-03-28 14:47:16 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:47:16 --> Controller Class Initialized
INFO - 2018-03-28 14:47:16 --> Model Class Initialized
INFO - 2018-03-28 14:47:16 --> Model Class Initialized
INFO - 2018-03-28 14:47:16 --> Model Class Initialized
INFO - 2018-03-28 14:47:16 --> Model Class Initialized
INFO - 2018-03-28 14:47:16 --> Model Class Initialized
INFO - 2018-03-28 14:47:16 --> Helper loaded: date_helper
INFO - 2018-03-28 19:47:16 --> Model Class Initialized
INFO - 2018-03-28 19:47:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:47:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:47:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-28 19:47:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:47:16 --> Final output sent to browser
DEBUG - 2018-03-28 19:47:16 --> Total execution time: 0.2513
INFO - 2018-03-28 14:47:23 --> Config Class Initialized
INFO - 2018-03-28 14:47:23 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:47:23 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:47:23 --> Utf8 Class Initialized
INFO - 2018-03-28 14:47:23 --> URI Class Initialized
INFO - 2018-03-28 14:47:23 --> Router Class Initialized
INFO - 2018-03-28 14:47:23 --> Output Class Initialized
INFO - 2018-03-28 14:47:23 --> Security Class Initialized
DEBUG - 2018-03-28 14:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:47:23 --> Input Class Initialized
INFO - 2018-03-28 14:47:23 --> Language Class Initialized
INFO - 2018-03-28 14:47:23 --> Loader Class Initialized
INFO - 2018-03-28 14:47:23 --> Helper loaded: url_helper
INFO - 2018-03-28 14:47:23 --> Helper loaded: form_helper
INFO - 2018-03-28 14:47:23 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:47:23 --> Controller Class Initialized
INFO - 2018-03-28 14:47:23 --> Model Class Initialized
INFO - 2018-03-28 14:47:23 --> Model Class Initialized
INFO - 2018-03-28 14:47:23 --> Model Class Initialized
INFO - 2018-03-28 14:47:23 --> Model Class Initialized
INFO - 2018-03-28 14:47:23 --> Model Class Initialized
INFO - 2018-03-28 14:47:23 --> Model Class Initialized
INFO - 2018-03-28 14:47:23 --> Model Class Initialized
INFO - 2018-03-28 14:47:23 --> Model Class Initialized
INFO - 2018-03-28 14:47:23 --> Model Class Initialized
INFO - 2018-03-28 14:47:23 --> Model Class Initialized
INFO - 2018-03-28 14:47:23 --> Helper loaded: date_helper
INFO - 2018-03-28 14:47:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:47:23 --> Model Class Initialized
INFO - 2018-03-28 19:47:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:47:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:47:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-28 19:47:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:47:23 --> Final output sent to browser
DEBUG - 2018-03-28 19:47:23 --> Total execution time: 0.4190
INFO - 2018-03-28 14:47:33 --> Config Class Initialized
INFO - 2018-03-28 14:47:33 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:47:33 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:47:33 --> Utf8 Class Initialized
INFO - 2018-03-28 14:47:33 --> URI Class Initialized
INFO - 2018-03-28 14:47:33 --> Router Class Initialized
INFO - 2018-03-28 14:47:33 --> Output Class Initialized
INFO - 2018-03-28 14:47:33 --> Security Class Initialized
DEBUG - 2018-03-28 14:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:47:33 --> Input Class Initialized
INFO - 2018-03-28 14:47:33 --> Language Class Initialized
INFO - 2018-03-28 14:47:33 --> Loader Class Initialized
INFO - 2018-03-28 14:47:33 --> Helper loaded: url_helper
INFO - 2018-03-28 14:47:33 --> Helper loaded: form_helper
INFO - 2018-03-28 14:47:33 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:47:33 --> Controller Class Initialized
INFO - 2018-03-28 14:47:33 --> Model Class Initialized
INFO - 2018-03-28 14:47:33 --> Model Class Initialized
INFO - 2018-03-28 14:47:33 --> Model Class Initialized
INFO - 2018-03-28 14:47:33 --> Model Class Initialized
INFO - 2018-03-28 14:47:33 --> Model Class Initialized
INFO - 2018-03-28 14:47:33 --> Model Class Initialized
INFO - 2018-03-28 14:47:33 --> Model Class Initialized
INFO - 2018-03-28 14:47:33 --> Model Class Initialized
INFO - 2018-03-28 14:47:33 --> Model Class Initialized
INFO - 2018-03-28 14:47:33 --> Model Class Initialized
INFO - 2018-03-28 14:47:33 --> Helper loaded: date_helper
INFO - 2018-03-28 14:47:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:47:33 --> Model Class Initialized
INFO - 2018-03-28 19:47:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:47:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:47:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-28 19:47:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:47:33 --> Final output sent to browser
DEBUG - 2018-03-28 19:47:33 --> Total execution time: 0.1785
INFO - 2018-03-28 14:55:42 --> Config Class Initialized
INFO - 2018-03-28 14:55:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:55:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:55:42 --> Utf8 Class Initialized
INFO - 2018-03-28 14:55:42 --> URI Class Initialized
INFO - 2018-03-28 14:55:42 --> Router Class Initialized
INFO - 2018-03-28 14:55:42 --> Output Class Initialized
INFO - 2018-03-28 14:55:42 --> Security Class Initialized
DEBUG - 2018-03-28 14:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:55:42 --> Input Class Initialized
INFO - 2018-03-28 14:55:42 --> Language Class Initialized
INFO - 2018-03-28 14:55:42 --> Loader Class Initialized
INFO - 2018-03-28 14:55:42 --> Helper loaded: url_helper
INFO - 2018-03-28 14:55:42 --> Helper loaded: form_helper
INFO - 2018-03-28 14:55:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:55:42 --> Controller Class Initialized
INFO - 2018-03-28 14:55:42 --> Model Class Initialized
INFO - 2018-03-28 14:55:42 --> Model Class Initialized
INFO - 2018-03-28 14:55:42 --> Helper loaded: date_helper
INFO - 2018-03-28 14:55:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:55:42 --> Model Class Initialized
INFO - 2018-03-28 19:55:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:55:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:55:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 19:55:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:55:42 --> Final output sent to browser
DEBUG - 2018-03-28 19:55:42 --> Total execution time: 0.1603
INFO - 2018-03-28 14:55:59 --> Config Class Initialized
INFO - 2018-03-28 14:55:59 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:55:59 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:55:59 --> Utf8 Class Initialized
INFO - 2018-03-28 14:55:59 --> URI Class Initialized
INFO - 2018-03-28 14:55:59 --> Router Class Initialized
INFO - 2018-03-28 14:55:59 --> Output Class Initialized
INFO - 2018-03-28 14:55:59 --> Security Class Initialized
DEBUG - 2018-03-28 14:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:55:59 --> Input Class Initialized
INFO - 2018-03-28 14:55:59 --> Language Class Initialized
INFO - 2018-03-28 14:55:59 --> Loader Class Initialized
INFO - 2018-03-28 14:55:59 --> Helper loaded: url_helper
INFO - 2018-03-28 14:55:59 --> Helper loaded: form_helper
INFO - 2018-03-28 14:55:59 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:55:59 --> Controller Class Initialized
INFO - 2018-03-28 14:55:59 --> Model Class Initialized
INFO - 2018-03-28 14:55:59 --> Model Class Initialized
INFO - 2018-03-28 14:55:59 --> Helper loaded: date_helper
INFO - 2018-03-28 14:55:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:55:59 --> Model Class Initialized
INFO - 2018-03-28 19:55:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:55:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:55:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 19:55:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:55:59 --> Final output sent to browser
DEBUG - 2018-03-28 19:55:59 --> Total execution time: 0.1410
INFO - 2018-03-28 14:56:00 --> Config Class Initialized
INFO - 2018-03-28 14:56:00 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:56:00 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:56:00 --> Utf8 Class Initialized
INFO - 2018-03-28 14:56:00 --> URI Class Initialized
INFO - 2018-03-28 14:56:00 --> Router Class Initialized
INFO - 2018-03-28 14:56:00 --> Output Class Initialized
INFO - 2018-03-28 14:56:00 --> Security Class Initialized
DEBUG - 2018-03-28 14:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:56:00 --> Input Class Initialized
INFO - 2018-03-28 14:56:00 --> Language Class Initialized
INFO - 2018-03-28 14:56:00 --> Loader Class Initialized
INFO - 2018-03-28 14:56:00 --> Helper loaded: url_helper
INFO - 2018-03-28 14:56:00 --> Helper loaded: form_helper
INFO - 2018-03-28 14:56:00 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:56:00 --> Controller Class Initialized
INFO - 2018-03-28 14:56:00 --> Model Class Initialized
INFO - 2018-03-28 14:56:00 --> Model Class Initialized
INFO - 2018-03-28 14:56:00 --> Helper loaded: date_helper
INFO - 2018-03-28 14:56:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:56:00 --> Model Class Initialized
INFO - 2018-03-28 19:56:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:56:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:56:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 19:56:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:56:00 --> Final output sent to browser
DEBUG - 2018-03-28 19:56:00 --> Total execution time: 0.2886
INFO - 2018-03-28 14:56:25 --> Config Class Initialized
INFO - 2018-03-28 14:56:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:56:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:56:25 --> Utf8 Class Initialized
INFO - 2018-03-28 14:56:25 --> URI Class Initialized
INFO - 2018-03-28 14:56:25 --> Router Class Initialized
INFO - 2018-03-28 14:56:25 --> Output Class Initialized
INFO - 2018-03-28 14:56:25 --> Security Class Initialized
DEBUG - 2018-03-28 14:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:56:25 --> Input Class Initialized
INFO - 2018-03-28 14:56:25 --> Language Class Initialized
INFO - 2018-03-28 14:56:25 --> Loader Class Initialized
INFO - 2018-03-28 14:56:25 --> Helper loaded: url_helper
INFO - 2018-03-28 14:56:25 --> Helper loaded: form_helper
INFO - 2018-03-28 14:56:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:56:25 --> Controller Class Initialized
INFO - 2018-03-28 14:56:25 --> Model Class Initialized
INFO - 2018-03-28 14:56:25 --> Model Class Initialized
INFO - 2018-03-28 14:56:25 --> Helper loaded: date_helper
INFO - 2018-03-28 14:56:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 14:56:26 --> Config Class Initialized
INFO - 2018-03-28 14:56:26 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:56:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:56:26 --> Utf8 Class Initialized
INFO - 2018-03-28 14:56:26 --> URI Class Initialized
INFO - 2018-03-28 14:56:26 --> Router Class Initialized
INFO - 2018-03-28 14:56:26 --> Output Class Initialized
INFO - 2018-03-28 14:56:26 --> Security Class Initialized
DEBUG - 2018-03-28 14:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:56:26 --> Input Class Initialized
INFO - 2018-03-28 14:56:26 --> Language Class Initialized
INFO - 2018-03-28 14:56:26 --> Loader Class Initialized
INFO - 2018-03-28 14:56:26 --> Helper loaded: url_helper
INFO - 2018-03-28 14:56:26 --> Helper loaded: form_helper
INFO - 2018-03-28 14:56:26 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:56:26 --> Controller Class Initialized
INFO - 2018-03-28 14:56:26 --> Model Class Initialized
INFO - 2018-03-28 14:56:26 --> Model Class Initialized
INFO - 2018-03-28 14:56:26 --> Helper loaded: date_helper
INFO - 2018-03-28 14:56:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:56:26 --> Model Class Initialized
INFO - 2018-03-28 19:56:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:56:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:56:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 19:56:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:56:26 --> Final output sent to browser
DEBUG - 2018-03-28 19:56:26 --> Total execution time: 0.1079
INFO - 2018-03-28 14:56:41 --> Config Class Initialized
INFO - 2018-03-28 14:56:41 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:56:41 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:56:41 --> Utf8 Class Initialized
INFO - 2018-03-28 14:56:41 --> URI Class Initialized
INFO - 2018-03-28 14:56:41 --> Router Class Initialized
INFO - 2018-03-28 14:56:41 --> Output Class Initialized
INFO - 2018-03-28 14:56:41 --> Security Class Initialized
DEBUG - 2018-03-28 14:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:56:41 --> Input Class Initialized
INFO - 2018-03-28 14:56:41 --> Language Class Initialized
INFO - 2018-03-28 14:56:41 --> Loader Class Initialized
INFO - 2018-03-28 14:56:41 --> Helper loaded: url_helper
INFO - 2018-03-28 14:56:41 --> Helper loaded: form_helper
INFO - 2018-03-28 14:56:41 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:56:41 --> Controller Class Initialized
INFO - 2018-03-28 14:56:41 --> Model Class Initialized
INFO - 2018-03-28 14:56:41 --> Model Class Initialized
INFO - 2018-03-28 14:56:41 --> Helper loaded: date_helper
INFO - 2018-03-28 14:56:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:56:41 --> Model Class Initialized
INFO - 2018-03-28 19:56:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:56:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:56:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 19:56:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:56:41 --> Final output sent to browser
DEBUG - 2018-03-28 19:56:41 --> Total execution time: 0.0905
INFO - 2018-03-28 14:56:58 --> Config Class Initialized
INFO - 2018-03-28 14:56:58 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:56:58 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:56:58 --> Utf8 Class Initialized
INFO - 2018-03-28 14:56:58 --> URI Class Initialized
INFO - 2018-03-28 14:56:58 --> Router Class Initialized
INFO - 2018-03-28 14:56:58 --> Output Class Initialized
INFO - 2018-03-28 14:56:58 --> Security Class Initialized
DEBUG - 2018-03-28 14:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:56:58 --> Input Class Initialized
INFO - 2018-03-28 14:56:58 --> Language Class Initialized
INFO - 2018-03-28 14:56:58 --> Loader Class Initialized
INFO - 2018-03-28 14:56:58 --> Helper loaded: url_helper
INFO - 2018-03-28 14:56:58 --> Helper loaded: form_helper
INFO - 2018-03-28 14:56:58 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:56:58 --> Controller Class Initialized
INFO - 2018-03-28 14:56:58 --> Model Class Initialized
INFO - 2018-03-28 14:56:58 --> Model Class Initialized
INFO - 2018-03-28 14:56:58 --> Helper loaded: date_helper
INFO - 2018-03-28 14:56:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 14:56:58 --> Config Class Initialized
INFO - 2018-03-28 14:56:58 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:56:58 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:56:58 --> Utf8 Class Initialized
INFO - 2018-03-28 14:56:58 --> URI Class Initialized
INFO - 2018-03-28 14:56:58 --> Router Class Initialized
INFO - 2018-03-28 14:56:58 --> Output Class Initialized
INFO - 2018-03-28 14:56:58 --> Security Class Initialized
DEBUG - 2018-03-28 14:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:56:58 --> Input Class Initialized
INFO - 2018-03-28 14:56:58 --> Language Class Initialized
INFO - 2018-03-28 14:56:58 --> Loader Class Initialized
INFO - 2018-03-28 14:56:58 --> Helper loaded: url_helper
INFO - 2018-03-28 14:56:58 --> Helper loaded: form_helper
INFO - 2018-03-28 14:56:58 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:56:58 --> Controller Class Initialized
INFO - 2018-03-28 14:56:58 --> Model Class Initialized
INFO - 2018-03-28 14:56:58 --> Model Class Initialized
INFO - 2018-03-28 14:56:58 --> Helper loaded: date_helper
INFO - 2018-03-28 14:56:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:56:58 --> Model Class Initialized
INFO - 2018-03-28 19:56:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:56:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:56:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 19:56:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:56:58 --> Final output sent to browser
DEBUG - 2018-03-28 19:56:58 --> Total execution time: 0.1355
INFO - 2018-03-28 14:57:02 --> Config Class Initialized
INFO - 2018-03-28 14:57:02 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:57:02 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:57:02 --> Utf8 Class Initialized
INFO - 2018-03-28 14:57:02 --> URI Class Initialized
INFO - 2018-03-28 14:57:02 --> Router Class Initialized
INFO - 2018-03-28 14:57:02 --> Output Class Initialized
INFO - 2018-03-28 14:57:02 --> Security Class Initialized
DEBUG - 2018-03-28 14:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:57:02 --> Input Class Initialized
INFO - 2018-03-28 14:57:02 --> Language Class Initialized
INFO - 2018-03-28 14:57:02 --> Loader Class Initialized
INFO - 2018-03-28 14:57:02 --> Helper loaded: url_helper
INFO - 2018-03-28 14:57:02 --> Helper loaded: form_helper
INFO - 2018-03-28 14:57:02 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:57:02 --> Controller Class Initialized
INFO - 2018-03-28 14:57:02 --> Model Class Initialized
INFO - 2018-03-28 14:57:02 --> Model Class Initialized
INFO - 2018-03-28 14:57:02 --> Helper loaded: date_helper
INFO - 2018-03-28 14:57:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:57:02 --> Model Class Initialized
INFO - 2018-03-28 19:57:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:57:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:57:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 19:57:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:57:02 --> Final output sent to browser
DEBUG - 2018-03-28 19:57:02 --> Total execution time: 0.0781
INFO - 2018-03-28 14:57:22 --> Config Class Initialized
INFO - 2018-03-28 14:57:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:57:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:57:22 --> Utf8 Class Initialized
INFO - 2018-03-28 14:57:22 --> URI Class Initialized
INFO - 2018-03-28 14:57:22 --> Router Class Initialized
INFO - 2018-03-28 14:57:22 --> Output Class Initialized
INFO - 2018-03-28 14:57:22 --> Security Class Initialized
DEBUG - 2018-03-28 14:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:57:22 --> Input Class Initialized
INFO - 2018-03-28 14:57:22 --> Language Class Initialized
INFO - 2018-03-28 14:57:22 --> Loader Class Initialized
INFO - 2018-03-28 14:57:22 --> Helper loaded: url_helper
INFO - 2018-03-28 14:57:22 --> Helper loaded: form_helper
INFO - 2018-03-28 14:57:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:57:22 --> Controller Class Initialized
INFO - 2018-03-28 14:57:22 --> Model Class Initialized
INFO - 2018-03-28 14:57:22 --> Model Class Initialized
INFO - 2018-03-28 14:57:22 --> Helper loaded: date_helper
INFO - 2018-03-28 14:57:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 14:57:22 --> Config Class Initialized
INFO - 2018-03-28 14:57:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:57:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:57:22 --> Utf8 Class Initialized
INFO - 2018-03-28 14:57:22 --> URI Class Initialized
INFO - 2018-03-28 14:57:22 --> Router Class Initialized
INFO - 2018-03-28 14:57:22 --> Output Class Initialized
INFO - 2018-03-28 14:57:22 --> Security Class Initialized
DEBUG - 2018-03-28 14:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:57:22 --> Input Class Initialized
INFO - 2018-03-28 14:57:22 --> Language Class Initialized
INFO - 2018-03-28 14:57:22 --> Loader Class Initialized
INFO - 2018-03-28 14:57:22 --> Helper loaded: url_helper
INFO - 2018-03-28 14:57:22 --> Helper loaded: form_helper
INFO - 2018-03-28 14:57:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:57:23 --> Controller Class Initialized
INFO - 2018-03-28 14:57:23 --> Model Class Initialized
INFO - 2018-03-28 14:57:23 --> Model Class Initialized
INFO - 2018-03-28 14:57:23 --> Helper loaded: date_helper
INFO - 2018-03-28 14:57:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:57:23 --> Model Class Initialized
INFO - 2018-03-28 19:57:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:57:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:57:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 19:57:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:57:23 --> Final output sent to browser
DEBUG - 2018-03-28 19:57:23 --> Total execution time: 0.1301
INFO - 2018-03-28 14:57:26 --> Config Class Initialized
INFO - 2018-03-28 14:57:26 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:57:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:57:26 --> Utf8 Class Initialized
INFO - 2018-03-28 14:57:26 --> URI Class Initialized
INFO - 2018-03-28 14:57:26 --> Router Class Initialized
INFO - 2018-03-28 14:57:26 --> Output Class Initialized
INFO - 2018-03-28 14:57:26 --> Security Class Initialized
DEBUG - 2018-03-28 14:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:57:26 --> Input Class Initialized
INFO - 2018-03-28 14:57:26 --> Language Class Initialized
INFO - 2018-03-28 14:57:26 --> Loader Class Initialized
INFO - 2018-03-28 14:57:26 --> Helper loaded: url_helper
INFO - 2018-03-28 14:57:26 --> Helper loaded: form_helper
INFO - 2018-03-28 14:57:26 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:57:26 --> Controller Class Initialized
INFO - 2018-03-28 14:57:26 --> Model Class Initialized
INFO - 2018-03-28 14:57:26 --> Model Class Initialized
INFO - 2018-03-28 14:57:26 --> Helper loaded: date_helper
INFO - 2018-03-28 14:57:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:57:26 --> Model Class Initialized
INFO - 2018-03-28 19:57:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:57:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:57:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 19:57:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:57:26 --> Final output sent to browser
DEBUG - 2018-03-28 19:57:26 --> Total execution time: 0.1182
INFO - 2018-03-28 14:57:44 --> Config Class Initialized
INFO - 2018-03-28 14:57:44 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:57:44 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:57:44 --> Utf8 Class Initialized
INFO - 2018-03-28 14:57:44 --> URI Class Initialized
INFO - 2018-03-28 14:57:44 --> Router Class Initialized
INFO - 2018-03-28 14:57:44 --> Output Class Initialized
INFO - 2018-03-28 14:57:44 --> Security Class Initialized
DEBUG - 2018-03-28 14:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:57:44 --> Input Class Initialized
INFO - 2018-03-28 14:57:44 --> Language Class Initialized
INFO - 2018-03-28 14:57:44 --> Loader Class Initialized
INFO - 2018-03-28 14:57:44 --> Helper loaded: url_helper
INFO - 2018-03-28 14:57:44 --> Helper loaded: form_helper
INFO - 2018-03-28 14:57:44 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:57:44 --> Controller Class Initialized
INFO - 2018-03-28 14:57:44 --> Model Class Initialized
INFO - 2018-03-28 14:57:44 --> Model Class Initialized
INFO - 2018-03-28 14:57:44 --> Helper loaded: date_helper
INFO - 2018-03-28 14:57:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 14:57:44 --> Config Class Initialized
INFO - 2018-03-28 14:57:44 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:57:44 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:57:44 --> Utf8 Class Initialized
INFO - 2018-03-28 14:57:44 --> URI Class Initialized
INFO - 2018-03-28 14:57:44 --> Router Class Initialized
INFO - 2018-03-28 14:57:44 --> Output Class Initialized
INFO - 2018-03-28 14:57:44 --> Security Class Initialized
DEBUG - 2018-03-28 14:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:57:44 --> Input Class Initialized
INFO - 2018-03-28 14:57:44 --> Language Class Initialized
INFO - 2018-03-28 14:57:44 --> Loader Class Initialized
INFO - 2018-03-28 14:57:44 --> Helper loaded: url_helper
INFO - 2018-03-28 14:57:44 --> Helper loaded: form_helper
INFO - 2018-03-28 14:57:44 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:57:44 --> Controller Class Initialized
INFO - 2018-03-28 14:57:44 --> Model Class Initialized
INFO - 2018-03-28 14:57:44 --> Model Class Initialized
INFO - 2018-03-28 14:57:44 --> Helper loaded: date_helper
INFO - 2018-03-28 14:57:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:57:44 --> Model Class Initialized
INFO - 2018-03-28 19:57:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:57:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:57:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 19:57:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:57:44 --> Final output sent to browser
DEBUG - 2018-03-28 19:57:44 --> Total execution time: 0.1385
INFO - 2018-03-28 14:57:46 --> Config Class Initialized
INFO - 2018-03-28 14:57:46 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:57:46 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:57:46 --> Utf8 Class Initialized
INFO - 2018-03-28 14:57:46 --> URI Class Initialized
INFO - 2018-03-28 14:57:46 --> Router Class Initialized
INFO - 2018-03-28 14:57:46 --> Output Class Initialized
INFO - 2018-03-28 14:57:46 --> Security Class Initialized
DEBUG - 2018-03-28 14:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:57:46 --> Input Class Initialized
INFO - 2018-03-28 14:57:46 --> Language Class Initialized
INFO - 2018-03-28 14:57:46 --> Loader Class Initialized
INFO - 2018-03-28 14:57:46 --> Helper loaded: url_helper
INFO - 2018-03-28 14:57:46 --> Helper loaded: form_helper
INFO - 2018-03-28 14:57:46 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:57:46 --> Controller Class Initialized
INFO - 2018-03-28 14:57:46 --> Model Class Initialized
INFO - 2018-03-28 14:57:46 --> Model Class Initialized
INFO - 2018-03-28 14:57:46 --> Helper loaded: date_helper
INFO - 2018-03-28 14:57:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:57:46 --> Model Class Initialized
INFO - 2018-03-28 19:57:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:57:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:57:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 19:57:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:57:46 --> Final output sent to browser
DEBUG - 2018-03-28 19:57:46 --> Total execution time: 0.1395
INFO - 2018-03-28 14:58:14 --> Config Class Initialized
INFO - 2018-03-28 14:58:14 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:58:14 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:58:14 --> Utf8 Class Initialized
INFO - 2018-03-28 14:58:14 --> URI Class Initialized
INFO - 2018-03-28 14:58:14 --> Router Class Initialized
INFO - 2018-03-28 14:58:14 --> Output Class Initialized
INFO - 2018-03-28 14:58:14 --> Security Class Initialized
DEBUG - 2018-03-28 14:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:58:14 --> Input Class Initialized
INFO - 2018-03-28 14:58:14 --> Language Class Initialized
INFO - 2018-03-28 14:58:14 --> Loader Class Initialized
INFO - 2018-03-28 14:58:14 --> Helper loaded: url_helper
INFO - 2018-03-28 14:58:14 --> Helper loaded: form_helper
INFO - 2018-03-28 14:58:14 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:58:14 --> Controller Class Initialized
INFO - 2018-03-28 14:58:14 --> Model Class Initialized
INFO - 2018-03-28 14:58:14 --> Model Class Initialized
INFO - 2018-03-28 14:58:14 --> Helper loaded: date_helper
INFO - 2018-03-28 14:58:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 14:58:15 --> Config Class Initialized
INFO - 2018-03-28 14:58:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:58:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:58:15 --> Utf8 Class Initialized
INFO - 2018-03-28 14:58:15 --> URI Class Initialized
INFO - 2018-03-28 14:58:15 --> Router Class Initialized
INFO - 2018-03-28 14:58:15 --> Output Class Initialized
INFO - 2018-03-28 14:58:15 --> Security Class Initialized
DEBUG - 2018-03-28 14:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:58:15 --> Input Class Initialized
INFO - 2018-03-28 14:58:15 --> Language Class Initialized
INFO - 2018-03-28 14:58:15 --> Loader Class Initialized
INFO - 2018-03-28 14:58:15 --> Helper loaded: url_helper
INFO - 2018-03-28 14:58:15 --> Helper loaded: form_helper
INFO - 2018-03-28 14:58:15 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:58:15 --> Controller Class Initialized
INFO - 2018-03-28 14:58:15 --> Model Class Initialized
INFO - 2018-03-28 14:58:15 --> Model Class Initialized
INFO - 2018-03-28 14:58:15 --> Helper loaded: date_helper
INFO - 2018-03-28 14:58:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:58:15 --> Model Class Initialized
INFO - 2018-03-28 19:58:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:58:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:58:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 19:58:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:58:15 --> Final output sent to browser
DEBUG - 2018-03-28 19:58:15 --> Total execution time: 0.1070
INFO - 2018-03-28 14:58:20 --> Config Class Initialized
INFO - 2018-03-28 14:58:20 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:58:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:58:20 --> Utf8 Class Initialized
INFO - 2018-03-28 14:58:20 --> URI Class Initialized
INFO - 2018-03-28 14:58:20 --> Router Class Initialized
INFO - 2018-03-28 14:58:20 --> Output Class Initialized
INFO - 2018-03-28 14:58:20 --> Security Class Initialized
DEBUG - 2018-03-28 14:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:58:20 --> Input Class Initialized
INFO - 2018-03-28 14:58:20 --> Language Class Initialized
INFO - 2018-03-28 14:58:20 --> Loader Class Initialized
INFO - 2018-03-28 14:58:20 --> Helper loaded: url_helper
INFO - 2018-03-28 14:58:20 --> Helper loaded: form_helper
INFO - 2018-03-28 14:58:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:58:20 --> Controller Class Initialized
INFO - 2018-03-28 14:58:20 --> Model Class Initialized
INFO - 2018-03-28 14:58:20 --> Model Class Initialized
INFO - 2018-03-28 14:58:20 --> Helper loaded: date_helper
INFO - 2018-03-28 14:58:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:58:20 --> Model Class Initialized
INFO - 2018-03-28 19:58:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:58:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:58:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 19:58:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:58:20 --> Final output sent to browser
DEBUG - 2018-03-28 19:58:20 --> Total execution time: 0.1098
INFO - 2018-03-28 14:58:39 --> Config Class Initialized
INFO - 2018-03-28 14:58:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:58:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:58:39 --> Utf8 Class Initialized
INFO - 2018-03-28 14:58:39 --> URI Class Initialized
INFO - 2018-03-28 14:58:39 --> Router Class Initialized
INFO - 2018-03-28 14:58:39 --> Output Class Initialized
INFO - 2018-03-28 14:58:39 --> Security Class Initialized
DEBUG - 2018-03-28 14:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:58:39 --> Input Class Initialized
INFO - 2018-03-28 14:58:39 --> Language Class Initialized
INFO - 2018-03-28 14:58:39 --> Loader Class Initialized
INFO - 2018-03-28 14:58:39 --> Helper loaded: url_helper
INFO - 2018-03-28 14:58:39 --> Helper loaded: form_helper
INFO - 2018-03-28 14:58:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:58:39 --> Controller Class Initialized
INFO - 2018-03-28 14:58:39 --> Model Class Initialized
INFO - 2018-03-28 14:58:39 --> Model Class Initialized
INFO - 2018-03-28 14:58:39 --> Helper loaded: date_helper
INFO - 2018-03-28 14:58:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 14:58:39 --> Config Class Initialized
INFO - 2018-03-28 14:58:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:58:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:58:39 --> Utf8 Class Initialized
INFO - 2018-03-28 14:58:39 --> URI Class Initialized
INFO - 2018-03-28 14:58:39 --> Router Class Initialized
INFO - 2018-03-28 14:58:39 --> Output Class Initialized
INFO - 2018-03-28 14:58:39 --> Security Class Initialized
DEBUG - 2018-03-28 14:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:58:39 --> Input Class Initialized
INFO - 2018-03-28 14:58:39 --> Language Class Initialized
INFO - 2018-03-28 14:58:39 --> Loader Class Initialized
INFO - 2018-03-28 14:58:39 --> Helper loaded: url_helper
INFO - 2018-03-28 14:58:39 --> Helper loaded: form_helper
INFO - 2018-03-28 14:58:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:58:39 --> Controller Class Initialized
INFO - 2018-03-28 14:58:39 --> Model Class Initialized
INFO - 2018-03-28 14:58:39 --> Model Class Initialized
INFO - 2018-03-28 14:58:39 --> Helper loaded: date_helper
INFO - 2018-03-28 14:58:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:58:39 --> Model Class Initialized
INFO - 2018-03-28 19:58:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:58:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:58:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 19:58:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:58:39 --> Final output sent to browser
DEBUG - 2018-03-28 19:58:39 --> Total execution time: 0.1422
INFO - 2018-03-28 14:58:41 --> Config Class Initialized
INFO - 2018-03-28 14:58:41 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:58:41 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:58:41 --> Utf8 Class Initialized
INFO - 2018-03-28 14:58:41 --> URI Class Initialized
INFO - 2018-03-28 14:58:41 --> Router Class Initialized
INFO - 2018-03-28 14:58:41 --> Output Class Initialized
INFO - 2018-03-28 14:58:41 --> Security Class Initialized
DEBUG - 2018-03-28 14:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:58:41 --> Input Class Initialized
INFO - 2018-03-28 14:58:41 --> Language Class Initialized
INFO - 2018-03-28 14:58:41 --> Loader Class Initialized
INFO - 2018-03-28 14:58:41 --> Helper loaded: url_helper
INFO - 2018-03-28 14:58:41 --> Helper loaded: form_helper
INFO - 2018-03-28 14:58:41 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:58:41 --> Controller Class Initialized
INFO - 2018-03-28 14:58:41 --> Model Class Initialized
INFO - 2018-03-28 14:58:41 --> Model Class Initialized
INFO - 2018-03-28 14:58:41 --> Helper loaded: date_helper
INFO - 2018-03-28 14:58:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:58:41 --> Model Class Initialized
INFO - 2018-03-28 19:58:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:58:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:58:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 19:58:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:58:41 --> Final output sent to browser
DEBUG - 2018-03-28 19:58:41 --> Total execution time: 0.1003
INFO - 2018-03-28 14:59:01 --> Config Class Initialized
INFO - 2018-03-28 14:59:01 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:59:01 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:59:01 --> Utf8 Class Initialized
INFO - 2018-03-28 14:59:01 --> URI Class Initialized
INFO - 2018-03-28 14:59:01 --> Router Class Initialized
INFO - 2018-03-28 14:59:01 --> Output Class Initialized
INFO - 2018-03-28 14:59:01 --> Security Class Initialized
DEBUG - 2018-03-28 14:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:59:01 --> Input Class Initialized
INFO - 2018-03-28 14:59:01 --> Language Class Initialized
INFO - 2018-03-28 14:59:01 --> Loader Class Initialized
INFO - 2018-03-28 14:59:01 --> Helper loaded: url_helper
INFO - 2018-03-28 14:59:01 --> Helper loaded: form_helper
INFO - 2018-03-28 14:59:01 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:59:01 --> Controller Class Initialized
INFO - 2018-03-28 14:59:01 --> Model Class Initialized
INFO - 2018-03-28 14:59:01 --> Model Class Initialized
INFO - 2018-03-28 14:59:01 --> Helper loaded: date_helper
INFO - 2018-03-28 14:59:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 14:59:01 --> Config Class Initialized
INFO - 2018-03-28 14:59:01 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:59:01 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:59:01 --> Utf8 Class Initialized
INFO - 2018-03-28 14:59:01 --> URI Class Initialized
INFO - 2018-03-28 14:59:01 --> Router Class Initialized
INFO - 2018-03-28 14:59:01 --> Output Class Initialized
INFO - 2018-03-28 14:59:01 --> Security Class Initialized
DEBUG - 2018-03-28 14:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:59:01 --> Input Class Initialized
INFO - 2018-03-28 14:59:01 --> Language Class Initialized
INFO - 2018-03-28 14:59:01 --> Loader Class Initialized
INFO - 2018-03-28 14:59:01 --> Helper loaded: url_helper
INFO - 2018-03-28 14:59:01 --> Helper loaded: form_helper
INFO - 2018-03-28 14:59:01 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:59:01 --> Controller Class Initialized
INFO - 2018-03-28 14:59:01 --> Model Class Initialized
INFO - 2018-03-28 14:59:01 --> Model Class Initialized
INFO - 2018-03-28 14:59:01 --> Helper loaded: date_helper
INFO - 2018-03-28 14:59:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:59:01 --> Model Class Initialized
INFO - 2018-03-28 19:59:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:59:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:59:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 19:59:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:59:02 --> Final output sent to browser
DEBUG - 2018-03-28 19:59:02 --> Total execution time: 0.1230
INFO - 2018-03-28 14:59:03 --> Config Class Initialized
INFO - 2018-03-28 14:59:03 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:59:03 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:59:03 --> Utf8 Class Initialized
INFO - 2018-03-28 14:59:03 --> URI Class Initialized
INFO - 2018-03-28 14:59:03 --> Router Class Initialized
INFO - 2018-03-28 14:59:03 --> Output Class Initialized
INFO - 2018-03-28 14:59:03 --> Security Class Initialized
DEBUG - 2018-03-28 14:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:59:03 --> Input Class Initialized
INFO - 2018-03-28 14:59:03 --> Language Class Initialized
INFO - 2018-03-28 14:59:03 --> Loader Class Initialized
INFO - 2018-03-28 14:59:03 --> Helper loaded: url_helper
INFO - 2018-03-28 14:59:03 --> Helper loaded: form_helper
INFO - 2018-03-28 14:59:03 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:59:03 --> Controller Class Initialized
INFO - 2018-03-28 14:59:03 --> Model Class Initialized
INFO - 2018-03-28 14:59:03 --> Model Class Initialized
INFO - 2018-03-28 14:59:03 --> Helper loaded: date_helper
INFO - 2018-03-28 14:59:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:59:03 --> Model Class Initialized
INFO - 2018-03-28 19:59:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:59:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:59:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 19:59:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:59:03 --> Final output sent to browser
DEBUG - 2018-03-28 19:59:03 --> Total execution time: 0.1411
INFO - 2018-03-28 14:59:18 --> Config Class Initialized
INFO - 2018-03-28 14:59:18 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:59:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:59:18 --> Utf8 Class Initialized
INFO - 2018-03-28 14:59:18 --> URI Class Initialized
INFO - 2018-03-28 14:59:18 --> Router Class Initialized
INFO - 2018-03-28 14:59:18 --> Output Class Initialized
INFO - 2018-03-28 14:59:18 --> Security Class Initialized
DEBUG - 2018-03-28 14:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:59:18 --> Input Class Initialized
INFO - 2018-03-28 14:59:18 --> Language Class Initialized
INFO - 2018-03-28 14:59:18 --> Loader Class Initialized
INFO - 2018-03-28 14:59:18 --> Helper loaded: url_helper
INFO - 2018-03-28 14:59:18 --> Helper loaded: form_helper
INFO - 2018-03-28 14:59:18 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:59:18 --> Controller Class Initialized
INFO - 2018-03-28 14:59:18 --> Model Class Initialized
INFO - 2018-03-28 14:59:18 --> Model Class Initialized
INFO - 2018-03-28 14:59:18 --> Helper loaded: date_helper
INFO - 2018-03-28 14:59:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 14:59:18 --> Config Class Initialized
INFO - 2018-03-28 14:59:18 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:59:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:59:18 --> Utf8 Class Initialized
INFO - 2018-03-28 14:59:18 --> URI Class Initialized
INFO - 2018-03-28 14:59:18 --> Router Class Initialized
INFO - 2018-03-28 14:59:18 --> Output Class Initialized
INFO - 2018-03-28 14:59:18 --> Security Class Initialized
DEBUG - 2018-03-28 14:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:59:18 --> Input Class Initialized
INFO - 2018-03-28 14:59:18 --> Language Class Initialized
INFO - 2018-03-28 14:59:18 --> Loader Class Initialized
INFO - 2018-03-28 14:59:18 --> Helper loaded: url_helper
INFO - 2018-03-28 14:59:18 --> Helper loaded: form_helper
INFO - 2018-03-28 14:59:18 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:59:18 --> Controller Class Initialized
INFO - 2018-03-28 14:59:18 --> Model Class Initialized
INFO - 2018-03-28 14:59:18 --> Model Class Initialized
INFO - 2018-03-28 14:59:18 --> Helper loaded: date_helper
INFO - 2018-03-28 14:59:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:59:18 --> Model Class Initialized
INFO - 2018-03-28 19:59:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:59:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:59:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 19:59:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:59:18 --> Final output sent to browser
DEBUG - 2018-03-28 19:59:18 --> Total execution time: 0.1372
INFO - 2018-03-28 14:59:20 --> Config Class Initialized
INFO - 2018-03-28 14:59:20 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:59:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:59:20 --> Utf8 Class Initialized
INFO - 2018-03-28 14:59:20 --> URI Class Initialized
INFO - 2018-03-28 14:59:20 --> Router Class Initialized
INFO - 2018-03-28 14:59:20 --> Output Class Initialized
INFO - 2018-03-28 14:59:20 --> Security Class Initialized
DEBUG - 2018-03-28 14:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:59:20 --> Input Class Initialized
INFO - 2018-03-28 14:59:20 --> Language Class Initialized
INFO - 2018-03-28 14:59:20 --> Loader Class Initialized
INFO - 2018-03-28 14:59:20 --> Helper loaded: url_helper
INFO - 2018-03-28 14:59:20 --> Helper loaded: form_helper
INFO - 2018-03-28 14:59:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:59:20 --> Controller Class Initialized
INFO - 2018-03-28 14:59:20 --> Model Class Initialized
INFO - 2018-03-28 14:59:20 --> Model Class Initialized
INFO - 2018-03-28 14:59:20 --> Helper loaded: date_helper
INFO - 2018-03-28 14:59:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:59:20 --> Model Class Initialized
INFO - 2018-03-28 19:59:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:59:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:59:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 19:59:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:59:20 --> Final output sent to browser
DEBUG - 2018-03-28 19:59:20 --> Total execution time: 0.1072
INFO - 2018-03-28 14:59:29 --> Config Class Initialized
INFO - 2018-03-28 14:59:29 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:59:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:59:29 --> Utf8 Class Initialized
INFO - 2018-03-28 14:59:29 --> URI Class Initialized
INFO - 2018-03-28 14:59:29 --> Router Class Initialized
INFO - 2018-03-28 14:59:29 --> Output Class Initialized
INFO - 2018-03-28 14:59:29 --> Security Class Initialized
DEBUG - 2018-03-28 14:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:59:29 --> Input Class Initialized
INFO - 2018-03-28 14:59:29 --> Language Class Initialized
INFO - 2018-03-28 14:59:29 --> Loader Class Initialized
INFO - 2018-03-28 14:59:29 --> Helper loaded: url_helper
INFO - 2018-03-28 14:59:29 --> Helper loaded: form_helper
INFO - 2018-03-28 14:59:29 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:59:29 --> Controller Class Initialized
INFO - 2018-03-28 14:59:29 --> Model Class Initialized
INFO - 2018-03-28 14:59:29 --> Model Class Initialized
INFO - 2018-03-28 14:59:29 --> Helper loaded: date_helper
INFO - 2018-03-28 14:59:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:59:29 --> Model Class Initialized
INFO - 2018-03-28 19:59:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:59:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:59:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 19:59:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:59:29 --> Final output sent to browser
DEBUG - 2018-03-28 19:59:29 --> Total execution time: 0.1051
INFO - 2018-03-28 14:59:32 --> Config Class Initialized
INFO - 2018-03-28 14:59:32 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:59:32 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:59:32 --> Utf8 Class Initialized
INFO - 2018-03-28 14:59:32 --> URI Class Initialized
INFO - 2018-03-28 14:59:32 --> Router Class Initialized
INFO - 2018-03-28 14:59:32 --> Output Class Initialized
INFO - 2018-03-28 14:59:32 --> Security Class Initialized
DEBUG - 2018-03-28 14:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:59:32 --> Input Class Initialized
INFO - 2018-03-28 14:59:32 --> Language Class Initialized
INFO - 2018-03-28 14:59:32 --> Loader Class Initialized
INFO - 2018-03-28 14:59:32 --> Helper loaded: url_helper
INFO - 2018-03-28 14:59:32 --> Helper loaded: form_helper
INFO - 2018-03-28 14:59:32 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:59:32 --> Controller Class Initialized
INFO - 2018-03-28 14:59:32 --> Model Class Initialized
INFO - 2018-03-28 14:59:32 --> Model Class Initialized
INFO - 2018-03-28 14:59:32 --> Helper loaded: date_helper
INFO - 2018-03-28 14:59:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:59:32 --> Model Class Initialized
INFO - 2018-03-28 19:59:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:59:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:59:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/edit.php
INFO - 2018-03-28 19:59:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:59:32 --> Final output sent to browser
DEBUG - 2018-03-28 19:59:32 --> Total execution time: 0.1551
INFO - 2018-03-28 14:59:37 --> Config Class Initialized
INFO - 2018-03-28 14:59:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:59:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:59:37 --> Utf8 Class Initialized
INFO - 2018-03-28 14:59:37 --> URI Class Initialized
INFO - 2018-03-28 14:59:37 --> Router Class Initialized
INFO - 2018-03-28 14:59:37 --> Output Class Initialized
INFO - 2018-03-28 14:59:37 --> Security Class Initialized
DEBUG - 2018-03-28 14:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:59:37 --> Input Class Initialized
INFO - 2018-03-28 14:59:37 --> Language Class Initialized
INFO - 2018-03-28 14:59:37 --> Loader Class Initialized
INFO - 2018-03-28 14:59:37 --> Helper loaded: url_helper
INFO - 2018-03-28 14:59:37 --> Helper loaded: form_helper
INFO - 2018-03-28 14:59:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:59:37 --> Controller Class Initialized
INFO - 2018-03-28 14:59:37 --> Model Class Initialized
INFO - 2018-03-28 14:59:37 --> Model Class Initialized
INFO - 2018-03-28 14:59:37 --> Helper loaded: date_helper
INFO - 2018-03-28 14:59:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 14:59:37 --> Config Class Initialized
INFO - 2018-03-28 14:59:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:59:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:59:37 --> Utf8 Class Initialized
INFO - 2018-03-28 14:59:37 --> URI Class Initialized
INFO - 2018-03-28 14:59:37 --> Router Class Initialized
INFO - 2018-03-28 14:59:37 --> Output Class Initialized
INFO - 2018-03-28 14:59:37 --> Security Class Initialized
DEBUG - 2018-03-28 14:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:59:37 --> Input Class Initialized
INFO - 2018-03-28 14:59:37 --> Language Class Initialized
INFO - 2018-03-28 14:59:37 --> Loader Class Initialized
INFO - 2018-03-28 14:59:37 --> Helper loaded: url_helper
INFO - 2018-03-28 14:59:37 --> Helper loaded: form_helper
INFO - 2018-03-28 14:59:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:59:37 --> Controller Class Initialized
INFO - 2018-03-28 14:59:37 --> Model Class Initialized
INFO - 2018-03-28 14:59:37 --> Model Class Initialized
INFO - 2018-03-28 14:59:37 --> Helper loaded: date_helper
INFO - 2018-03-28 14:59:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:59:37 --> Model Class Initialized
INFO - 2018-03-28 19:59:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:59:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:59:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 19:59:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:59:37 --> Final output sent to browser
DEBUG - 2018-03-28 19:59:37 --> Total execution time: 0.1338
INFO - 2018-03-28 14:59:40 --> Config Class Initialized
INFO - 2018-03-28 14:59:40 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:59:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:59:40 --> Utf8 Class Initialized
INFO - 2018-03-28 14:59:40 --> URI Class Initialized
INFO - 2018-03-28 14:59:40 --> Router Class Initialized
INFO - 2018-03-28 14:59:40 --> Output Class Initialized
INFO - 2018-03-28 14:59:40 --> Security Class Initialized
DEBUG - 2018-03-28 14:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:59:40 --> Input Class Initialized
INFO - 2018-03-28 14:59:40 --> Language Class Initialized
INFO - 2018-03-28 14:59:40 --> Loader Class Initialized
INFO - 2018-03-28 14:59:40 --> Helper loaded: url_helper
INFO - 2018-03-28 14:59:40 --> Helper loaded: form_helper
INFO - 2018-03-28 14:59:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:59:40 --> Controller Class Initialized
INFO - 2018-03-28 14:59:40 --> Model Class Initialized
INFO - 2018-03-28 14:59:40 --> Model Class Initialized
INFO - 2018-03-28 14:59:40 --> Helper loaded: date_helper
INFO - 2018-03-28 14:59:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:59:40 --> Model Class Initialized
INFO - 2018-03-28 19:59:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:59:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:59:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 19:59:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:59:40 --> Final output sent to browser
DEBUG - 2018-03-28 19:59:40 --> Total execution time: 0.1055
INFO - 2018-03-28 14:59:45 --> Config Class Initialized
INFO - 2018-03-28 14:59:45 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:59:45 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:59:45 --> Utf8 Class Initialized
INFO - 2018-03-28 14:59:45 --> URI Class Initialized
INFO - 2018-03-28 14:59:45 --> Router Class Initialized
INFO - 2018-03-28 14:59:45 --> Output Class Initialized
INFO - 2018-03-28 14:59:45 --> Security Class Initialized
DEBUG - 2018-03-28 14:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:59:45 --> Input Class Initialized
INFO - 2018-03-28 14:59:45 --> Language Class Initialized
INFO - 2018-03-28 14:59:45 --> Loader Class Initialized
INFO - 2018-03-28 14:59:45 --> Helper loaded: url_helper
INFO - 2018-03-28 14:59:45 --> Helper loaded: form_helper
INFO - 2018-03-28 14:59:45 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:59:45 --> Controller Class Initialized
INFO - 2018-03-28 14:59:45 --> Model Class Initialized
INFO - 2018-03-28 14:59:45 --> Model Class Initialized
INFO - 2018-03-28 14:59:45 --> Helper loaded: date_helper
INFO - 2018-03-28 14:59:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 14:59:45 --> Config Class Initialized
INFO - 2018-03-28 14:59:45 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:59:45 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:59:45 --> Utf8 Class Initialized
INFO - 2018-03-28 14:59:45 --> URI Class Initialized
INFO - 2018-03-28 14:59:45 --> Router Class Initialized
INFO - 2018-03-28 14:59:45 --> Output Class Initialized
INFO - 2018-03-28 14:59:45 --> Security Class Initialized
DEBUG - 2018-03-28 14:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:59:45 --> Input Class Initialized
INFO - 2018-03-28 14:59:45 --> Language Class Initialized
INFO - 2018-03-28 14:59:45 --> Loader Class Initialized
INFO - 2018-03-28 14:59:45 --> Helper loaded: url_helper
INFO - 2018-03-28 14:59:45 --> Helper loaded: form_helper
INFO - 2018-03-28 14:59:45 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:59:45 --> Controller Class Initialized
INFO - 2018-03-28 14:59:45 --> Model Class Initialized
INFO - 2018-03-28 14:59:45 --> Model Class Initialized
INFO - 2018-03-28 14:59:45 --> Helper loaded: date_helper
INFO - 2018-03-28 14:59:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:59:45 --> Model Class Initialized
INFO - 2018-03-28 19:59:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:59:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:59:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 19:59:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:59:45 --> Final output sent to browser
DEBUG - 2018-03-28 19:59:45 --> Total execution time: 0.1186
INFO - 2018-03-28 14:59:47 --> Config Class Initialized
INFO - 2018-03-28 14:59:47 --> Hooks Class Initialized
DEBUG - 2018-03-28 14:59:47 --> UTF-8 Support Enabled
INFO - 2018-03-28 14:59:47 --> Utf8 Class Initialized
INFO - 2018-03-28 14:59:47 --> URI Class Initialized
INFO - 2018-03-28 14:59:47 --> Router Class Initialized
INFO - 2018-03-28 14:59:47 --> Output Class Initialized
INFO - 2018-03-28 14:59:47 --> Security Class Initialized
DEBUG - 2018-03-28 14:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 14:59:47 --> Input Class Initialized
INFO - 2018-03-28 14:59:47 --> Language Class Initialized
INFO - 2018-03-28 14:59:47 --> Loader Class Initialized
INFO - 2018-03-28 14:59:47 --> Helper loaded: url_helper
INFO - 2018-03-28 14:59:47 --> Helper loaded: form_helper
INFO - 2018-03-28 14:59:47 --> Database Driver Class Initialized
DEBUG - 2018-03-28 14:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 14:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 14:59:47 --> Controller Class Initialized
INFO - 2018-03-28 14:59:47 --> Model Class Initialized
INFO - 2018-03-28 14:59:47 --> Model Class Initialized
INFO - 2018-03-28 14:59:47 --> Helper loaded: date_helper
INFO - 2018-03-28 14:59:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 19:59:47 --> Model Class Initialized
INFO - 2018-03-28 19:59:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 19:59:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 19:59:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 19:59:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 19:59:47 --> Final output sent to browser
DEBUG - 2018-03-28 19:59:47 --> Total execution time: 0.1136
INFO - 2018-03-28 15:00:09 --> Config Class Initialized
INFO - 2018-03-28 15:00:09 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:00:09 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:00:09 --> Utf8 Class Initialized
INFO - 2018-03-28 15:00:09 --> URI Class Initialized
INFO - 2018-03-28 15:00:09 --> Router Class Initialized
INFO - 2018-03-28 15:00:09 --> Output Class Initialized
INFO - 2018-03-28 15:00:09 --> Security Class Initialized
DEBUG - 2018-03-28 15:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:00:09 --> Input Class Initialized
INFO - 2018-03-28 15:00:09 --> Language Class Initialized
INFO - 2018-03-28 15:00:09 --> Loader Class Initialized
INFO - 2018-03-28 15:00:09 --> Helper loaded: url_helper
INFO - 2018-03-28 15:00:09 --> Helper loaded: form_helper
INFO - 2018-03-28 15:00:09 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:00:09 --> Controller Class Initialized
INFO - 2018-03-28 15:00:09 --> Model Class Initialized
INFO - 2018-03-28 15:00:09 --> Model Class Initialized
INFO - 2018-03-28 15:00:09 --> Helper loaded: date_helper
INFO - 2018-03-28 15:00:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:00:09 --> Config Class Initialized
INFO - 2018-03-28 15:00:09 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:00:09 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:00:09 --> Utf8 Class Initialized
INFO - 2018-03-28 15:00:09 --> URI Class Initialized
INFO - 2018-03-28 15:00:09 --> Router Class Initialized
INFO - 2018-03-28 15:00:09 --> Output Class Initialized
INFO - 2018-03-28 15:00:09 --> Security Class Initialized
DEBUG - 2018-03-28 15:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:00:09 --> Input Class Initialized
INFO - 2018-03-28 15:00:09 --> Language Class Initialized
INFO - 2018-03-28 15:00:09 --> Loader Class Initialized
INFO - 2018-03-28 15:00:09 --> Helper loaded: url_helper
INFO - 2018-03-28 15:00:09 --> Helper loaded: form_helper
INFO - 2018-03-28 15:00:09 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:00:09 --> Controller Class Initialized
INFO - 2018-03-28 15:00:09 --> Model Class Initialized
INFO - 2018-03-28 15:00:09 --> Model Class Initialized
INFO - 2018-03-28 15:00:09 --> Helper loaded: date_helper
INFO - 2018-03-28 15:00:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:00:09 --> Model Class Initialized
INFO - 2018-03-28 20:00:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:00:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:00:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:00:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:00:09 --> Final output sent to browser
DEBUG - 2018-03-28 20:00:09 --> Total execution time: 0.1144
INFO - 2018-03-28 15:00:11 --> Config Class Initialized
INFO - 2018-03-28 15:00:11 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:00:11 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:00:11 --> Utf8 Class Initialized
INFO - 2018-03-28 15:00:11 --> URI Class Initialized
INFO - 2018-03-28 15:00:11 --> Router Class Initialized
INFO - 2018-03-28 15:00:11 --> Output Class Initialized
INFO - 2018-03-28 15:00:11 --> Security Class Initialized
DEBUG - 2018-03-28 15:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:00:11 --> Input Class Initialized
INFO - 2018-03-28 15:00:11 --> Language Class Initialized
INFO - 2018-03-28 15:00:11 --> Loader Class Initialized
INFO - 2018-03-28 15:00:11 --> Helper loaded: url_helper
INFO - 2018-03-28 15:00:11 --> Helper loaded: form_helper
INFO - 2018-03-28 15:00:12 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:00:12 --> Controller Class Initialized
INFO - 2018-03-28 15:00:12 --> Model Class Initialized
INFO - 2018-03-28 15:00:12 --> Model Class Initialized
INFO - 2018-03-28 15:00:12 --> Helper loaded: date_helper
INFO - 2018-03-28 15:00:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:00:12 --> Model Class Initialized
INFO - 2018-03-28 20:00:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:00:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:00:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:00:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:00:12 --> Final output sent to browser
DEBUG - 2018-03-28 20:00:12 --> Total execution time: 0.2796
INFO - 2018-03-28 15:00:37 --> Config Class Initialized
INFO - 2018-03-28 15:00:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:00:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:00:37 --> Utf8 Class Initialized
INFO - 2018-03-28 15:00:37 --> URI Class Initialized
INFO - 2018-03-28 15:00:37 --> Router Class Initialized
INFO - 2018-03-28 15:00:37 --> Output Class Initialized
INFO - 2018-03-28 15:00:37 --> Security Class Initialized
DEBUG - 2018-03-28 15:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:00:37 --> Input Class Initialized
INFO - 2018-03-28 15:00:37 --> Language Class Initialized
INFO - 2018-03-28 15:00:37 --> Loader Class Initialized
INFO - 2018-03-28 15:00:37 --> Helper loaded: url_helper
INFO - 2018-03-28 15:00:37 --> Helper loaded: form_helper
INFO - 2018-03-28 15:00:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:00:37 --> Controller Class Initialized
INFO - 2018-03-28 15:00:37 --> Model Class Initialized
INFO - 2018-03-28 15:00:37 --> Model Class Initialized
INFO - 2018-03-28 15:00:37 --> Helper loaded: date_helper
INFO - 2018-03-28 15:00:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:00:37 --> Config Class Initialized
INFO - 2018-03-28 15:00:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:00:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:00:37 --> Utf8 Class Initialized
INFO - 2018-03-28 15:00:37 --> URI Class Initialized
INFO - 2018-03-28 15:00:37 --> Router Class Initialized
INFO - 2018-03-28 15:00:37 --> Output Class Initialized
INFO - 2018-03-28 15:00:37 --> Security Class Initialized
DEBUG - 2018-03-28 15:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:00:37 --> Input Class Initialized
INFO - 2018-03-28 15:00:37 --> Language Class Initialized
INFO - 2018-03-28 15:00:37 --> Loader Class Initialized
INFO - 2018-03-28 15:00:37 --> Helper loaded: url_helper
INFO - 2018-03-28 15:00:37 --> Helper loaded: form_helper
INFO - 2018-03-28 15:00:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:00:37 --> Controller Class Initialized
INFO - 2018-03-28 15:00:37 --> Model Class Initialized
INFO - 2018-03-28 15:00:37 --> Model Class Initialized
INFO - 2018-03-28 15:00:37 --> Helper loaded: date_helper
INFO - 2018-03-28 15:00:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:00:37 --> Model Class Initialized
INFO - 2018-03-28 20:00:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:00:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:00:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:00:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:00:37 --> Final output sent to browser
DEBUG - 2018-03-28 20:00:37 --> Total execution time: 0.1205
INFO - 2018-03-28 15:00:39 --> Config Class Initialized
INFO - 2018-03-28 15:00:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:00:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:00:39 --> Utf8 Class Initialized
INFO - 2018-03-28 15:00:39 --> URI Class Initialized
INFO - 2018-03-28 15:00:39 --> Router Class Initialized
INFO - 2018-03-28 15:00:39 --> Output Class Initialized
INFO - 2018-03-28 15:00:39 --> Security Class Initialized
DEBUG - 2018-03-28 15:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:00:39 --> Input Class Initialized
INFO - 2018-03-28 15:00:39 --> Language Class Initialized
INFO - 2018-03-28 15:00:39 --> Loader Class Initialized
INFO - 2018-03-28 15:00:39 --> Helper loaded: url_helper
INFO - 2018-03-28 15:00:39 --> Helper loaded: form_helper
INFO - 2018-03-28 15:00:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:00:39 --> Controller Class Initialized
INFO - 2018-03-28 15:00:39 --> Model Class Initialized
INFO - 2018-03-28 15:00:39 --> Model Class Initialized
INFO - 2018-03-28 15:00:39 --> Helper loaded: date_helper
INFO - 2018-03-28 15:00:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:00:39 --> Model Class Initialized
INFO - 2018-03-28 20:00:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:00:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:00:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:00:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:00:39 --> Final output sent to browser
DEBUG - 2018-03-28 20:00:39 --> Total execution time: 0.1745
INFO - 2018-03-28 15:01:06 --> Config Class Initialized
INFO - 2018-03-28 15:01:06 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:01:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:01:06 --> Utf8 Class Initialized
INFO - 2018-03-28 15:01:06 --> URI Class Initialized
INFO - 2018-03-28 15:01:06 --> Router Class Initialized
INFO - 2018-03-28 15:01:06 --> Output Class Initialized
INFO - 2018-03-28 15:01:06 --> Security Class Initialized
DEBUG - 2018-03-28 15:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:01:06 --> Input Class Initialized
INFO - 2018-03-28 15:01:06 --> Language Class Initialized
INFO - 2018-03-28 15:01:06 --> Loader Class Initialized
INFO - 2018-03-28 15:01:06 --> Helper loaded: url_helper
INFO - 2018-03-28 15:01:06 --> Helper loaded: form_helper
INFO - 2018-03-28 15:01:06 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:01:06 --> Controller Class Initialized
INFO - 2018-03-28 15:01:06 --> Model Class Initialized
INFO - 2018-03-28 15:01:06 --> Model Class Initialized
INFO - 2018-03-28 15:01:06 --> Helper loaded: date_helper
INFO - 2018-03-28 15:01:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:01:06 --> Config Class Initialized
INFO - 2018-03-28 15:01:06 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:01:07 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:01:07 --> Utf8 Class Initialized
INFO - 2018-03-28 15:01:07 --> URI Class Initialized
INFO - 2018-03-28 15:01:07 --> Router Class Initialized
INFO - 2018-03-28 15:01:07 --> Output Class Initialized
INFO - 2018-03-28 15:01:07 --> Security Class Initialized
DEBUG - 2018-03-28 15:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:01:07 --> Input Class Initialized
INFO - 2018-03-28 15:01:07 --> Language Class Initialized
INFO - 2018-03-28 15:01:07 --> Loader Class Initialized
INFO - 2018-03-28 15:01:07 --> Helper loaded: url_helper
INFO - 2018-03-28 15:01:07 --> Helper loaded: form_helper
INFO - 2018-03-28 15:01:07 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:01:07 --> Controller Class Initialized
INFO - 2018-03-28 15:01:07 --> Model Class Initialized
INFO - 2018-03-28 15:01:07 --> Model Class Initialized
INFO - 2018-03-28 15:01:07 --> Helper loaded: date_helper
INFO - 2018-03-28 15:01:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:01:07 --> Model Class Initialized
INFO - 2018-03-28 20:01:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:01:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:01:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:01:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:01:07 --> Final output sent to browser
DEBUG - 2018-03-28 20:01:07 --> Total execution time: 0.1364
INFO - 2018-03-28 15:01:08 --> Config Class Initialized
INFO - 2018-03-28 15:01:08 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:01:08 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:01:08 --> Utf8 Class Initialized
INFO - 2018-03-28 15:01:08 --> URI Class Initialized
INFO - 2018-03-28 15:01:08 --> Router Class Initialized
INFO - 2018-03-28 15:01:08 --> Output Class Initialized
INFO - 2018-03-28 15:01:08 --> Security Class Initialized
DEBUG - 2018-03-28 15:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:01:08 --> Input Class Initialized
INFO - 2018-03-28 15:01:08 --> Language Class Initialized
INFO - 2018-03-28 15:01:08 --> Loader Class Initialized
INFO - 2018-03-28 15:01:08 --> Helper loaded: url_helper
INFO - 2018-03-28 15:01:08 --> Helper loaded: form_helper
INFO - 2018-03-28 15:01:08 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:01:08 --> Controller Class Initialized
INFO - 2018-03-28 15:01:08 --> Model Class Initialized
INFO - 2018-03-28 15:01:08 --> Model Class Initialized
INFO - 2018-03-28 15:01:08 --> Helper loaded: date_helper
INFO - 2018-03-28 15:01:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:01:08 --> Model Class Initialized
INFO - 2018-03-28 20:01:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:01:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:01:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:01:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:01:08 --> Final output sent to browser
DEBUG - 2018-03-28 20:01:08 --> Total execution time: 0.1232
INFO - 2018-03-28 15:01:27 --> Config Class Initialized
INFO - 2018-03-28 15:01:27 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:01:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:01:27 --> Utf8 Class Initialized
INFO - 2018-03-28 15:01:27 --> URI Class Initialized
INFO - 2018-03-28 15:01:27 --> Router Class Initialized
INFO - 2018-03-28 15:01:27 --> Output Class Initialized
INFO - 2018-03-28 15:01:27 --> Security Class Initialized
DEBUG - 2018-03-28 15:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:01:27 --> Input Class Initialized
INFO - 2018-03-28 15:01:27 --> Language Class Initialized
INFO - 2018-03-28 15:01:27 --> Loader Class Initialized
INFO - 2018-03-28 15:01:27 --> Helper loaded: url_helper
INFO - 2018-03-28 15:01:27 --> Helper loaded: form_helper
INFO - 2018-03-28 15:01:27 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:01:28 --> Controller Class Initialized
INFO - 2018-03-28 15:01:28 --> Model Class Initialized
INFO - 2018-03-28 15:01:28 --> Model Class Initialized
INFO - 2018-03-28 15:01:28 --> Helper loaded: date_helper
INFO - 2018-03-28 15:01:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:01:28 --> Config Class Initialized
INFO - 2018-03-28 15:01:28 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:01:28 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:01:28 --> Utf8 Class Initialized
INFO - 2018-03-28 15:01:28 --> URI Class Initialized
INFO - 2018-03-28 15:01:28 --> Router Class Initialized
INFO - 2018-03-28 15:01:28 --> Output Class Initialized
INFO - 2018-03-28 15:01:28 --> Security Class Initialized
DEBUG - 2018-03-28 15:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:01:28 --> Input Class Initialized
INFO - 2018-03-28 15:01:28 --> Language Class Initialized
INFO - 2018-03-28 15:01:28 --> Loader Class Initialized
INFO - 2018-03-28 15:01:28 --> Helper loaded: url_helper
INFO - 2018-03-28 15:01:28 --> Helper loaded: form_helper
INFO - 2018-03-28 15:01:28 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:01:28 --> Controller Class Initialized
INFO - 2018-03-28 15:01:28 --> Model Class Initialized
INFO - 2018-03-28 15:01:28 --> Model Class Initialized
INFO - 2018-03-28 15:01:28 --> Helper loaded: date_helper
INFO - 2018-03-28 15:01:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:01:28 --> Model Class Initialized
INFO - 2018-03-28 20:01:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:01:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:01:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:01:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:01:28 --> Final output sent to browser
DEBUG - 2018-03-28 20:01:28 --> Total execution time: 0.1202
INFO - 2018-03-28 15:01:29 --> Config Class Initialized
INFO - 2018-03-28 15:01:29 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:01:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:01:29 --> Utf8 Class Initialized
INFO - 2018-03-28 15:01:29 --> URI Class Initialized
INFO - 2018-03-28 15:01:29 --> Router Class Initialized
INFO - 2018-03-28 15:01:29 --> Output Class Initialized
INFO - 2018-03-28 15:01:29 --> Security Class Initialized
DEBUG - 2018-03-28 15:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:01:29 --> Input Class Initialized
INFO - 2018-03-28 15:01:29 --> Language Class Initialized
INFO - 2018-03-28 15:01:29 --> Loader Class Initialized
INFO - 2018-03-28 15:01:29 --> Helper loaded: url_helper
INFO - 2018-03-28 15:01:29 --> Helper loaded: form_helper
INFO - 2018-03-28 15:01:29 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:01:29 --> Controller Class Initialized
INFO - 2018-03-28 15:01:29 --> Model Class Initialized
INFO - 2018-03-28 15:01:29 --> Model Class Initialized
INFO - 2018-03-28 15:01:29 --> Helper loaded: date_helper
INFO - 2018-03-28 15:01:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:01:29 --> Model Class Initialized
INFO - 2018-03-28 20:01:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:01:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:01:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:01:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:01:30 --> Final output sent to browser
DEBUG - 2018-03-28 20:01:30 --> Total execution time: 0.1693
INFO - 2018-03-28 15:01:50 --> Config Class Initialized
INFO - 2018-03-28 15:01:50 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:01:50 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:01:50 --> Utf8 Class Initialized
INFO - 2018-03-28 15:01:50 --> URI Class Initialized
INFO - 2018-03-28 15:01:50 --> Router Class Initialized
INFO - 2018-03-28 15:01:50 --> Output Class Initialized
INFO - 2018-03-28 15:01:50 --> Security Class Initialized
DEBUG - 2018-03-28 15:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:01:50 --> Input Class Initialized
INFO - 2018-03-28 15:01:50 --> Language Class Initialized
INFO - 2018-03-28 15:01:50 --> Loader Class Initialized
INFO - 2018-03-28 15:01:50 --> Helper loaded: url_helper
INFO - 2018-03-28 15:01:50 --> Helper loaded: form_helper
INFO - 2018-03-28 15:01:50 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:01:50 --> Controller Class Initialized
INFO - 2018-03-28 15:01:50 --> Model Class Initialized
INFO - 2018-03-28 15:01:50 --> Model Class Initialized
INFO - 2018-03-28 15:01:50 --> Helper loaded: date_helper
INFO - 2018-03-28 15:01:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:01:50 --> Config Class Initialized
INFO - 2018-03-28 15:01:50 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:01:50 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:01:50 --> Utf8 Class Initialized
INFO - 2018-03-28 15:01:50 --> URI Class Initialized
INFO - 2018-03-28 15:01:50 --> Router Class Initialized
INFO - 2018-03-28 15:01:50 --> Output Class Initialized
INFO - 2018-03-28 15:01:50 --> Security Class Initialized
DEBUG - 2018-03-28 15:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:01:50 --> Input Class Initialized
INFO - 2018-03-28 15:01:50 --> Language Class Initialized
INFO - 2018-03-28 15:01:50 --> Loader Class Initialized
INFO - 2018-03-28 15:01:50 --> Helper loaded: url_helper
INFO - 2018-03-28 15:01:50 --> Helper loaded: form_helper
INFO - 2018-03-28 15:01:50 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:01:50 --> Controller Class Initialized
INFO - 2018-03-28 15:01:50 --> Model Class Initialized
INFO - 2018-03-28 15:01:50 --> Model Class Initialized
INFO - 2018-03-28 15:01:50 --> Helper loaded: date_helper
INFO - 2018-03-28 15:01:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:01:50 --> Model Class Initialized
INFO - 2018-03-28 20:01:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:01:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:01:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:01:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:01:50 --> Final output sent to browser
DEBUG - 2018-03-28 20:01:50 --> Total execution time: 0.1446
INFO - 2018-03-28 15:01:52 --> Config Class Initialized
INFO - 2018-03-28 15:01:52 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:01:52 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:01:52 --> Utf8 Class Initialized
INFO - 2018-03-28 15:01:52 --> URI Class Initialized
INFO - 2018-03-28 15:01:52 --> Router Class Initialized
INFO - 2018-03-28 15:01:52 --> Output Class Initialized
INFO - 2018-03-28 15:01:52 --> Security Class Initialized
DEBUG - 2018-03-28 15:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:01:52 --> Input Class Initialized
INFO - 2018-03-28 15:01:52 --> Language Class Initialized
INFO - 2018-03-28 15:01:52 --> Loader Class Initialized
INFO - 2018-03-28 15:01:52 --> Helper loaded: url_helper
INFO - 2018-03-28 15:01:52 --> Helper loaded: form_helper
INFO - 2018-03-28 15:01:52 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:01:52 --> Controller Class Initialized
INFO - 2018-03-28 15:01:52 --> Model Class Initialized
INFO - 2018-03-28 15:01:52 --> Model Class Initialized
INFO - 2018-03-28 15:01:52 --> Helper loaded: date_helper
INFO - 2018-03-28 15:01:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:01:52 --> Model Class Initialized
INFO - 2018-03-28 20:01:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:01:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:01:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:01:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:01:52 --> Final output sent to browser
DEBUG - 2018-03-28 20:01:52 --> Total execution time: 0.1261
INFO - 2018-03-28 15:02:09 --> Config Class Initialized
INFO - 2018-03-28 15:02:09 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:02:09 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:02:09 --> Utf8 Class Initialized
INFO - 2018-03-28 15:02:09 --> URI Class Initialized
INFO - 2018-03-28 15:02:09 --> Router Class Initialized
INFO - 2018-03-28 15:02:09 --> Output Class Initialized
INFO - 2018-03-28 15:02:09 --> Security Class Initialized
DEBUG - 2018-03-28 15:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:02:09 --> Input Class Initialized
INFO - 2018-03-28 15:02:09 --> Language Class Initialized
INFO - 2018-03-28 15:02:09 --> Loader Class Initialized
INFO - 2018-03-28 15:02:09 --> Helper loaded: url_helper
INFO - 2018-03-28 15:02:09 --> Helper loaded: form_helper
INFO - 2018-03-28 15:02:09 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:02:09 --> Controller Class Initialized
INFO - 2018-03-28 15:02:09 --> Model Class Initialized
INFO - 2018-03-28 15:02:09 --> Model Class Initialized
INFO - 2018-03-28 15:02:09 --> Helper loaded: date_helper
INFO - 2018-03-28 15:02:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:02:09 --> Config Class Initialized
INFO - 2018-03-28 15:02:09 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:02:09 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:02:09 --> Utf8 Class Initialized
INFO - 2018-03-28 15:02:09 --> URI Class Initialized
INFO - 2018-03-28 15:02:09 --> Router Class Initialized
INFO - 2018-03-28 15:02:09 --> Output Class Initialized
INFO - 2018-03-28 15:02:09 --> Security Class Initialized
DEBUG - 2018-03-28 15:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:02:09 --> Input Class Initialized
INFO - 2018-03-28 15:02:09 --> Language Class Initialized
INFO - 2018-03-28 15:02:09 --> Loader Class Initialized
INFO - 2018-03-28 15:02:09 --> Helper loaded: url_helper
INFO - 2018-03-28 15:02:09 --> Helper loaded: form_helper
INFO - 2018-03-28 15:02:09 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:02:09 --> Controller Class Initialized
INFO - 2018-03-28 15:02:09 --> Model Class Initialized
INFO - 2018-03-28 15:02:09 --> Model Class Initialized
INFO - 2018-03-28 15:02:09 --> Helper loaded: date_helper
INFO - 2018-03-28 15:02:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:02:09 --> Model Class Initialized
INFO - 2018-03-28 20:02:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:02:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:02:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:02:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:02:09 --> Final output sent to browser
DEBUG - 2018-03-28 20:02:09 --> Total execution time: 0.1181
INFO - 2018-03-28 15:03:09 --> Config Class Initialized
INFO - 2018-03-28 15:03:09 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:03:09 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:03:09 --> Utf8 Class Initialized
INFO - 2018-03-28 15:03:09 --> URI Class Initialized
INFO - 2018-03-28 15:03:09 --> Router Class Initialized
INFO - 2018-03-28 15:03:09 --> Output Class Initialized
INFO - 2018-03-28 15:03:09 --> Security Class Initialized
DEBUG - 2018-03-28 15:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:03:09 --> Input Class Initialized
INFO - 2018-03-28 15:03:09 --> Language Class Initialized
INFO - 2018-03-28 15:03:09 --> Loader Class Initialized
INFO - 2018-03-28 15:03:09 --> Helper loaded: url_helper
INFO - 2018-03-28 15:03:09 --> Helper loaded: form_helper
INFO - 2018-03-28 15:03:09 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:03:09 --> Controller Class Initialized
INFO - 2018-03-28 15:03:09 --> Model Class Initialized
INFO - 2018-03-28 15:03:09 --> Model Class Initialized
INFO - 2018-03-28 15:03:09 --> Helper loaded: date_helper
INFO - 2018-03-28 15:03:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:03:09 --> Model Class Initialized
INFO - 2018-03-28 20:03:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:03:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:03:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:03:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:03:09 --> Final output sent to browser
DEBUG - 2018-03-28 20:03:09 --> Total execution time: 0.1194
INFO - 2018-03-28 15:03:39 --> Config Class Initialized
INFO - 2018-03-28 15:03:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:03:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:03:39 --> Utf8 Class Initialized
INFO - 2018-03-28 15:03:39 --> URI Class Initialized
INFO - 2018-03-28 15:03:39 --> Router Class Initialized
INFO - 2018-03-28 15:03:39 --> Output Class Initialized
INFO - 2018-03-28 15:03:39 --> Security Class Initialized
DEBUG - 2018-03-28 15:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:03:39 --> Input Class Initialized
INFO - 2018-03-28 15:03:39 --> Language Class Initialized
INFO - 2018-03-28 15:03:39 --> Loader Class Initialized
INFO - 2018-03-28 15:03:39 --> Helper loaded: url_helper
INFO - 2018-03-28 15:03:39 --> Helper loaded: form_helper
INFO - 2018-03-28 15:03:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:03:39 --> Controller Class Initialized
INFO - 2018-03-28 15:03:39 --> Model Class Initialized
INFO - 2018-03-28 15:03:39 --> Model Class Initialized
INFO - 2018-03-28 15:03:39 --> Helper loaded: date_helper
INFO - 2018-03-28 15:03:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:03:39 --> Config Class Initialized
INFO - 2018-03-28 15:03:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:03:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:03:39 --> Utf8 Class Initialized
INFO - 2018-03-28 15:03:39 --> URI Class Initialized
INFO - 2018-03-28 15:03:39 --> Router Class Initialized
INFO - 2018-03-28 15:03:39 --> Output Class Initialized
INFO - 2018-03-28 15:03:39 --> Security Class Initialized
DEBUG - 2018-03-28 15:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:03:39 --> Input Class Initialized
INFO - 2018-03-28 15:03:39 --> Language Class Initialized
INFO - 2018-03-28 15:03:39 --> Loader Class Initialized
INFO - 2018-03-28 15:03:39 --> Helper loaded: url_helper
INFO - 2018-03-28 15:03:39 --> Helper loaded: form_helper
INFO - 2018-03-28 15:03:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:03:39 --> Controller Class Initialized
INFO - 2018-03-28 15:03:39 --> Model Class Initialized
INFO - 2018-03-28 15:03:39 --> Model Class Initialized
INFO - 2018-03-28 15:03:39 --> Helper loaded: date_helper
INFO - 2018-03-28 15:03:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:03:39 --> Model Class Initialized
INFO - 2018-03-28 20:03:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:03:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:03:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:03:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:03:39 --> Final output sent to browser
DEBUG - 2018-03-28 20:03:39 --> Total execution time: 0.1314
INFO - 2018-03-28 15:03:41 --> Config Class Initialized
INFO - 2018-03-28 15:03:41 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:03:41 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:03:41 --> Utf8 Class Initialized
INFO - 2018-03-28 15:03:41 --> URI Class Initialized
INFO - 2018-03-28 15:03:41 --> Router Class Initialized
INFO - 2018-03-28 15:03:41 --> Output Class Initialized
INFO - 2018-03-28 15:03:41 --> Security Class Initialized
DEBUG - 2018-03-28 15:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:03:41 --> Input Class Initialized
INFO - 2018-03-28 15:03:41 --> Language Class Initialized
INFO - 2018-03-28 15:03:41 --> Loader Class Initialized
INFO - 2018-03-28 15:03:41 --> Helper loaded: url_helper
INFO - 2018-03-28 15:03:41 --> Helper loaded: form_helper
INFO - 2018-03-28 15:03:41 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:03:41 --> Controller Class Initialized
INFO - 2018-03-28 15:03:41 --> Model Class Initialized
INFO - 2018-03-28 15:03:41 --> Model Class Initialized
INFO - 2018-03-28 15:03:41 --> Helper loaded: date_helper
INFO - 2018-03-28 15:03:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:03:41 --> Model Class Initialized
INFO - 2018-03-28 20:03:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:03:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:03:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:03:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:03:41 --> Final output sent to browser
DEBUG - 2018-03-28 20:03:41 --> Total execution time: 0.1032
INFO - 2018-03-28 15:03:58 --> Config Class Initialized
INFO - 2018-03-28 15:03:58 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:03:58 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:03:58 --> Utf8 Class Initialized
INFO - 2018-03-28 15:03:58 --> URI Class Initialized
INFO - 2018-03-28 15:03:58 --> Router Class Initialized
INFO - 2018-03-28 15:03:58 --> Output Class Initialized
INFO - 2018-03-28 15:03:58 --> Security Class Initialized
DEBUG - 2018-03-28 15:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:03:58 --> Input Class Initialized
INFO - 2018-03-28 15:03:58 --> Language Class Initialized
INFO - 2018-03-28 15:03:58 --> Loader Class Initialized
INFO - 2018-03-28 15:03:58 --> Helper loaded: url_helper
INFO - 2018-03-28 15:03:58 --> Helper loaded: form_helper
INFO - 2018-03-28 15:03:58 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:03:58 --> Controller Class Initialized
INFO - 2018-03-28 15:03:58 --> Model Class Initialized
INFO - 2018-03-28 15:03:58 --> Model Class Initialized
INFO - 2018-03-28 15:03:58 --> Helper loaded: date_helper
INFO - 2018-03-28 15:03:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:03:58 --> Config Class Initialized
INFO - 2018-03-28 15:03:58 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:03:58 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:03:58 --> Utf8 Class Initialized
INFO - 2018-03-28 15:03:58 --> URI Class Initialized
INFO - 2018-03-28 15:03:58 --> Router Class Initialized
INFO - 2018-03-28 15:03:58 --> Output Class Initialized
INFO - 2018-03-28 15:03:58 --> Security Class Initialized
DEBUG - 2018-03-28 15:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:03:58 --> Input Class Initialized
INFO - 2018-03-28 15:03:58 --> Language Class Initialized
INFO - 2018-03-28 15:03:58 --> Loader Class Initialized
INFO - 2018-03-28 15:03:58 --> Helper loaded: url_helper
INFO - 2018-03-28 15:03:58 --> Helper loaded: form_helper
INFO - 2018-03-28 15:03:58 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:03:58 --> Controller Class Initialized
INFO - 2018-03-28 15:03:58 --> Model Class Initialized
INFO - 2018-03-28 15:03:58 --> Model Class Initialized
INFO - 2018-03-28 15:03:58 --> Helper loaded: date_helper
INFO - 2018-03-28 15:03:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:03:58 --> Model Class Initialized
INFO - 2018-03-28 20:03:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:03:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:03:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:03:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:03:58 --> Final output sent to browser
DEBUG - 2018-03-28 20:03:58 --> Total execution time: 0.1516
INFO - 2018-03-28 15:04:00 --> Config Class Initialized
INFO - 2018-03-28 15:04:00 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:04:00 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:04:00 --> Utf8 Class Initialized
INFO - 2018-03-28 15:04:00 --> URI Class Initialized
INFO - 2018-03-28 15:04:00 --> Router Class Initialized
INFO - 2018-03-28 15:04:00 --> Output Class Initialized
INFO - 2018-03-28 15:04:00 --> Security Class Initialized
DEBUG - 2018-03-28 15:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:04:00 --> Input Class Initialized
INFO - 2018-03-28 15:04:00 --> Language Class Initialized
INFO - 2018-03-28 15:04:00 --> Loader Class Initialized
INFO - 2018-03-28 15:04:00 --> Helper loaded: url_helper
INFO - 2018-03-28 15:04:00 --> Helper loaded: form_helper
INFO - 2018-03-28 15:04:00 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:04:00 --> Controller Class Initialized
INFO - 2018-03-28 15:04:00 --> Model Class Initialized
INFO - 2018-03-28 15:04:00 --> Model Class Initialized
INFO - 2018-03-28 15:04:00 --> Helper loaded: date_helper
INFO - 2018-03-28 15:04:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:04:00 --> Model Class Initialized
INFO - 2018-03-28 20:04:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:04:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:04:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:04:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:04:00 --> Final output sent to browser
DEBUG - 2018-03-28 20:04:00 --> Total execution time: 0.1567
INFO - 2018-03-28 15:04:08 --> Config Class Initialized
INFO - 2018-03-28 15:04:08 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:04:08 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:04:08 --> Utf8 Class Initialized
INFO - 2018-03-28 15:04:08 --> URI Class Initialized
INFO - 2018-03-28 15:04:08 --> Router Class Initialized
INFO - 2018-03-28 15:04:08 --> Output Class Initialized
INFO - 2018-03-28 15:04:08 --> Security Class Initialized
DEBUG - 2018-03-28 15:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:04:08 --> Input Class Initialized
INFO - 2018-03-28 15:04:08 --> Language Class Initialized
INFO - 2018-03-28 15:04:08 --> Loader Class Initialized
INFO - 2018-03-28 15:04:08 --> Helper loaded: url_helper
INFO - 2018-03-28 15:04:08 --> Helper loaded: form_helper
INFO - 2018-03-28 15:04:08 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:04:08 --> Controller Class Initialized
INFO - 2018-03-28 15:04:08 --> Model Class Initialized
INFO - 2018-03-28 15:04:08 --> Model Class Initialized
INFO - 2018-03-28 15:04:08 --> Helper loaded: date_helper
INFO - 2018-03-28 15:04:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:04:09 --> Config Class Initialized
INFO - 2018-03-28 15:04:09 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:04:09 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:04:09 --> Utf8 Class Initialized
INFO - 2018-03-28 15:04:09 --> URI Class Initialized
INFO - 2018-03-28 15:04:09 --> Router Class Initialized
INFO - 2018-03-28 15:04:09 --> Output Class Initialized
INFO - 2018-03-28 15:04:09 --> Security Class Initialized
DEBUG - 2018-03-28 15:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:04:09 --> Input Class Initialized
INFO - 2018-03-28 15:04:09 --> Language Class Initialized
INFO - 2018-03-28 15:04:09 --> Loader Class Initialized
INFO - 2018-03-28 15:04:09 --> Helper loaded: url_helper
INFO - 2018-03-28 15:04:09 --> Helper loaded: form_helper
INFO - 2018-03-28 15:04:09 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:04:09 --> Controller Class Initialized
INFO - 2018-03-28 15:04:09 --> Model Class Initialized
INFO - 2018-03-28 15:04:09 --> Model Class Initialized
INFO - 2018-03-28 15:04:09 --> Helper loaded: date_helper
INFO - 2018-03-28 15:04:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:04:09 --> Model Class Initialized
INFO - 2018-03-28 20:04:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:04:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:04:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:04:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:04:09 --> Final output sent to browser
DEBUG - 2018-03-28 20:04:09 --> Total execution time: 0.1465
INFO - 2018-03-28 15:04:10 --> Config Class Initialized
INFO - 2018-03-28 15:04:10 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:04:10 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:04:10 --> Utf8 Class Initialized
INFO - 2018-03-28 15:04:10 --> URI Class Initialized
INFO - 2018-03-28 15:04:10 --> Router Class Initialized
INFO - 2018-03-28 15:04:10 --> Output Class Initialized
INFO - 2018-03-28 15:04:10 --> Security Class Initialized
DEBUG - 2018-03-28 15:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:04:10 --> Input Class Initialized
INFO - 2018-03-28 15:04:10 --> Language Class Initialized
INFO - 2018-03-28 15:04:10 --> Loader Class Initialized
INFO - 2018-03-28 15:04:10 --> Helper loaded: url_helper
INFO - 2018-03-28 15:04:10 --> Helper loaded: form_helper
INFO - 2018-03-28 15:04:10 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:04:10 --> Controller Class Initialized
INFO - 2018-03-28 15:04:10 --> Model Class Initialized
INFO - 2018-03-28 15:04:10 --> Model Class Initialized
INFO - 2018-03-28 15:04:10 --> Helper loaded: date_helper
INFO - 2018-03-28 15:04:10 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:04:10 --> Model Class Initialized
INFO - 2018-03-28 20:04:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:04:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:04:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:04:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:04:10 --> Final output sent to browser
DEBUG - 2018-03-28 20:04:10 --> Total execution time: 0.1075
INFO - 2018-03-28 15:04:23 --> Config Class Initialized
INFO - 2018-03-28 15:04:23 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:04:23 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:04:23 --> Utf8 Class Initialized
INFO - 2018-03-28 15:04:23 --> URI Class Initialized
INFO - 2018-03-28 15:04:23 --> Router Class Initialized
INFO - 2018-03-28 15:04:23 --> Output Class Initialized
INFO - 2018-03-28 15:04:23 --> Security Class Initialized
DEBUG - 2018-03-28 15:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:04:23 --> Input Class Initialized
INFO - 2018-03-28 15:04:23 --> Language Class Initialized
INFO - 2018-03-28 15:04:23 --> Loader Class Initialized
INFO - 2018-03-28 15:04:23 --> Helper loaded: url_helper
INFO - 2018-03-28 15:04:23 --> Helper loaded: form_helper
INFO - 2018-03-28 15:04:23 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:04:23 --> Controller Class Initialized
INFO - 2018-03-28 15:04:23 --> Model Class Initialized
INFO - 2018-03-28 15:04:23 --> Model Class Initialized
INFO - 2018-03-28 15:04:23 --> Helper loaded: date_helper
INFO - 2018-03-28 15:04:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:04:23 --> Config Class Initialized
INFO - 2018-03-28 15:04:23 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:04:23 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:04:23 --> Utf8 Class Initialized
INFO - 2018-03-28 15:04:23 --> URI Class Initialized
INFO - 2018-03-28 15:04:23 --> Router Class Initialized
INFO - 2018-03-28 15:04:23 --> Output Class Initialized
INFO - 2018-03-28 15:04:23 --> Security Class Initialized
DEBUG - 2018-03-28 15:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:04:23 --> Input Class Initialized
INFO - 2018-03-28 15:04:23 --> Language Class Initialized
INFO - 2018-03-28 15:04:23 --> Loader Class Initialized
INFO - 2018-03-28 15:04:23 --> Helper loaded: url_helper
INFO - 2018-03-28 15:04:23 --> Helper loaded: form_helper
INFO - 2018-03-28 15:04:23 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:04:23 --> Controller Class Initialized
INFO - 2018-03-28 15:04:23 --> Model Class Initialized
INFO - 2018-03-28 15:04:23 --> Model Class Initialized
INFO - 2018-03-28 15:04:23 --> Helper loaded: date_helper
INFO - 2018-03-28 15:04:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:04:23 --> Model Class Initialized
INFO - 2018-03-28 20:04:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:04:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:04:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:04:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:04:23 --> Final output sent to browser
DEBUG - 2018-03-28 20:04:23 --> Total execution time: 0.1338
INFO - 2018-03-28 15:04:25 --> Config Class Initialized
INFO - 2018-03-28 15:04:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:04:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:04:25 --> Utf8 Class Initialized
INFO - 2018-03-28 15:04:25 --> URI Class Initialized
INFO - 2018-03-28 15:04:25 --> Router Class Initialized
INFO - 2018-03-28 15:04:25 --> Output Class Initialized
INFO - 2018-03-28 15:04:25 --> Security Class Initialized
DEBUG - 2018-03-28 15:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:04:25 --> Input Class Initialized
INFO - 2018-03-28 15:04:25 --> Language Class Initialized
INFO - 2018-03-28 15:04:25 --> Loader Class Initialized
INFO - 2018-03-28 15:04:25 --> Helper loaded: url_helper
INFO - 2018-03-28 15:04:25 --> Helper loaded: form_helper
INFO - 2018-03-28 15:04:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:04:25 --> Controller Class Initialized
INFO - 2018-03-28 15:04:25 --> Model Class Initialized
INFO - 2018-03-28 15:04:25 --> Model Class Initialized
INFO - 2018-03-28 15:04:25 --> Helper loaded: date_helper
INFO - 2018-03-28 15:04:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:04:25 --> Model Class Initialized
INFO - 2018-03-28 20:04:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:04:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:04:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:04:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:04:25 --> Final output sent to browser
DEBUG - 2018-03-28 20:04:25 --> Total execution time: 0.1496
INFO - 2018-03-28 15:04:43 --> Config Class Initialized
INFO - 2018-03-28 15:04:43 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:04:43 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:04:43 --> Utf8 Class Initialized
INFO - 2018-03-28 15:04:43 --> URI Class Initialized
INFO - 2018-03-28 15:04:43 --> Router Class Initialized
INFO - 2018-03-28 15:04:43 --> Output Class Initialized
INFO - 2018-03-28 15:04:43 --> Security Class Initialized
DEBUG - 2018-03-28 15:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:04:43 --> Input Class Initialized
INFO - 2018-03-28 15:04:43 --> Language Class Initialized
INFO - 2018-03-28 15:04:43 --> Loader Class Initialized
INFO - 2018-03-28 15:04:43 --> Helper loaded: url_helper
INFO - 2018-03-28 15:04:43 --> Helper loaded: form_helper
INFO - 2018-03-28 15:04:43 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:04:43 --> Controller Class Initialized
INFO - 2018-03-28 15:04:43 --> Model Class Initialized
INFO - 2018-03-28 15:04:43 --> Model Class Initialized
INFO - 2018-03-28 15:04:43 --> Helper loaded: date_helper
INFO - 2018-03-28 15:04:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:04:43 --> Config Class Initialized
INFO - 2018-03-28 15:04:43 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:04:43 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:04:43 --> Utf8 Class Initialized
INFO - 2018-03-28 15:04:43 --> URI Class Initialized
INFO - 2018-03-28 15:04:43 --> Router Class Initialized
INFO - 2018-03-28 15:04:43 --> Output Class Initialized
INFO - 2018-03-28 15:04:43 --> Security Class Initialized
DEBUG - 2018-03-28 15:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:04:43 --> Input Class Initialized
INFO - 2018-03-28 15:04:43 --> Language Class Initialized
INFO - 2018-03-28 15:04:43 --> Loader Class Initialized
INFO - 2018-03-28 15:04:43 --> Helper loaded: url_helper
INFO - 2018-03-28 15:04:43 --> Helper loaded: form_helper
INFO - 2018-03-28 15:04:43 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:04:43 --> Controller Class Initialized
INFO - 2018-03-28 15:04:43 --> Model Class Initialized
INFO - 2018-03-28 15:04:43 --> Model Class Initialized
INFO - 2018-03-28 15:04:43 --> Helper loaded: date_helper
INFO - 2018-03-28 15:04:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:04:43 --> Model Class Initialized
INFO - 2018-03-28 20:04:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:04:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:04:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:04:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:04:43 --> Final output sent to browser
DEBUG - 2018-03-28 20:04:43 --> Total execution time: 0.1168
INFO - 2018-03-28 15:04:45 --> Config Class Initialized
INFO - 2018-03-28 15:04:45 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:04:45 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:04:45 --> Utf8 Class Initialized
INFO - 2018-03-28 15:04:45 --> URI Class Initialized
INFO - 2018-03-28 15:04:45 --> Router Class Initialized
INFO - 2018-03-28 15:04:45 --> Output Class Initialized
INFO - 2018-03-28 15:04:45 --> Security Class Initialized
DEBUG - 2018-03-28 15:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:04:45 --> Input Class Initialized
INFO - 2018-03-28 15:04:45 --> Language Class Initialized
INFO - 2018-03-28 15:04:45 --> Loader Class Initialized
INFO - 2018-03-28 15:04:45 --> Helper loaded: url_helper
INFO - 2018-03-28 15:04:45 --> Helper loaded: form_helper
INFO - 2018-03-28 15:04:45 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:04:45 --> Controller Class Initialized
INFO - 2018-03-28 15:04:45 --> Model Class Initialized
INFO - 2018-03-28 15:04:45 --> Model Class Initialized
INFO - 2018-03-28 15:04:45 --> Helper loaded: date_helper
INFO - 2018-03-28 15:04:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:04:45 --> Model Class Initialized
INFO - 2018-03-28 20:04:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:04:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:04:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:04:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:04:45 --> Final output sent to browser
DEBUG - 2018-03-28 20:04:45 --> Total execution time: 0.1990
INFO - 2018-03-28 15:05:10 --> Config Class Initialized
INFO - 2018-03-28 15:05:10 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:05:10 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:05:10 --> Utf8 Class Initialized
INFO - 2018-03-28 15:05:10 --> URI Class Initialized
INFO - 2018-03-28 15:05:10 --> Router Class Initialized
INFO - 2018-03-28 15:05:10 --> Output Class Initialized
INFO - 2018-03-28 15:05:10 --> Security Class Initialized
DEBUG - 2018-03-28 15:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:05:10 --> Input Class Initialized
INFO - 2018-03-28 15:05:10 --> Language Class Initialized
INFO - 2018-03-28 15:05:10 --> Loader Class Initialized
INFO - 2018-03-28 15:05:10 --> Helper loaded: url_helper
INFO - 2018-03-28 15:05:10 --> Helper loaded: form_helper
INFO - 2018-03-28 15:05:10 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:05:10 --> Controller Class Initialized
INFO - 2018-03-28 15:05:10 --> Model Class Initialized
INFO - 2018-03-28 15:05:10 --> Model Class Initialized
INFO - 2018-03-28 15:05:10 --> Helper loaded: date_helper
INFO - 2018-03-28 15:05:10 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:05:10 --> Config Class Initialized
INFO - 2018-03-28 15:05:10 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:05:10 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:05:10 --> Utf8 Class Initialized
INFO - 2018-03-28 15:05:10 --> URI Class Initialized
INFO - 2018-03-28 15:05:10 --> Router Class Initialized
INFO - 2018-03-28 15:05:10 --> Output Class Initialized
INFO - 2018-03-28 15:05:10 --> Security Class Initialized
DEBUG - 2018-03-28 15:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:05:10 --> Input Class Initialized
INFO - 2018-03-28 15:05:10 --> Language Class Initialized
INFO - 2018-03-28 15:05:10 --> Loader Class Initialized
INFO - 2018-03-28 15:05:10 --> Helper loaded: url_helper
INFO - 2018-03-28 15:05:10 --> Helper loaded: form_helper
INFO - 2018-03-28 15:05:10 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:05:10 --> Controller Class Initialized
INFO - 2018-03-28 15:05:10 --> Model Class Initialized
INFO - 2018-03-28 15:05:10 --> Model Class Initialized
INFO - 2018-03-28 15:05:10 --> Helper loaded: date_helper
INFO - 2018-03-28 15:05:10 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:05:10 --> Model Class Initialized
INFO - 2018-03-28 20:05:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:05:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:05:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:05:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:05:10 --> Final output sent to browser
DEBUG - 2018-03-28 20:05:10 --> Total execution time: 0.1657
INFO - 2018-03-28 15:05:12 --> Config Class Initialized
INFO - 2018-03-28 15:05:12 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:05:12 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:05:12 --> Utf8 Class Initialized
INFO - 2018-03-28 15:05:12 --> URI Class Initialized
INFO - 2018-03-28 15:05:12 --> Router Class Initialized
INFO - 2018-03-28 15:05:12 --> Output Class Initialized
INFO - 2018-03-28 15:05:12 --> Security Class Initialized
DEBUG - 2018-03-28 15:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:05:12 --> Input Class Initialized
INFO - 2018-03-28 15:05:12 --> Language Class Initialized
INFO - 2018-03-28 15:05:12 --> Loader Class Initialized
INFO - 2018-03-28 15:05:12 --> Helper loaded: url_helper
INFO - 2018-03-28 15:05:12 --> Helper loaded: form_helper
INFO - 2018-03-28 15:05:12 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:05:12 --> Controller Class Initialized
INFO - 2018-03-28 15:05:13 --> Model Class Initialized
INFO - 2018-03-28 15:05:13 --> Model Class Initialized
INFO - 2018-03-28 15:05:13 --> Helper loaded: date_helper
INFO - 2018-03-28 15:05:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:05:13 --> Model Class Initialized
INFO - 2018-03-28 20:05:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:05:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:05:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:05:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:05:13 --> Final output sent to browser
DEBUG - 2018-03-28 20:05:13 --> Total execution time: 0.1094
INFO - 2018-03-28 15:05:25 --> Config Class Initialized
INFO - 2018-03-28 15:05:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:05:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:05:25 --> Utf8 Class Initialized
INFO - 2018-03-28 15:05:25 --> URI Class Initialized
INFO - 2018-03-28 15:05:25 --> Router Class Initialized
INFO - 2018-03-28 15:05:25 --> Output Class Initialized
INFO - 2018-03-28 15:05:25 --> Security Class Initialized
DEBUG - 2018-03-28 15:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:05:25 --> Input Class Initialized
INFO - 2018-03-28 15:05:25 --> Language Class Initialized
INFO - 2018-03-28 15:05:25 --> Loader Class Initialized
INFO - 2018-03-28 15:05:25 --> Helper loaded: url_helper
INFO - 2018-03-28 15:05:25 --> Helper loaded: form_helper
INFO - 2018-03-28 15:05:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:05:25 --> Controller Class Initialized
INFO - 2018-03-28 15:05:25 --> Model Class Initialized
INFO - 2018-03-28 15:05:25 --> Model Class Initialized
INFO - 2018-03-28 15:05:25 --> Helper loaded: date_helper
INFO - 2018-03-28 15:05:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:05:26 --> Config Class Initialized
INFO - 2018-03-28 15:05:26 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:05:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:05:26 --> Utf8 Class Initialized
INFO - 2018-03-28 15:05:26 --> URI Class Initialized
INFO - 2018-03-28 15:05:26 --> Router Class Initialized
INFO - 2018-03-28 15:05:26 --> Output Class Initialized
INFO - 2018-03-28 15:05:26 --> Security Class Initialized
DEBUG - 2018-03-28 15:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:05:26 --> Input Class Initialized
INFO - 2018-03-28 15:05:26 --> Language Class Initialized
INFO - 2018-03-28 15:05:26 --> Loader Class Initialized
INFO - 2018-03-28 15:05:26 --> Helper loaded: url_helper
INFO - 2018-03-28 15:05:26 --> Helper loaded: form_helper
INFO - 2018-03-28 15:05:26 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:05:26 --> Controller Class Initialized
INFO - 2018-03-28 15:05:26 --> Model Class Initialized
INFO - 2018-03-28 15:05:26 --> Model Class Initialized
INFO - 2018-03-28 15:05:26 --> Helper loaded: date_helper
INFO - 2018-03-28 15:05:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:05:26 --> Model Class Initialized
INFO - 2018-03-28 20:05:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:05:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:05:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:05:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:05:26 --> Final output sent to browser
DEBUG - 2018-03-28 20:05:26 --> Total execution time: 0.1495
INFO - 2018-03-28 15:05:27 --> Config Class Initialized
INFO - 2018-03-28 15:05:27 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:05:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:05:27 --> Utf8 Class Initialized
INFO - 2018-03-28 15:05:27 --> URI Class Initialized
INFO - 2018-03-28 15:05:27 --> Router Class Initialized
INFO - 2018-03-28 15:05:27 --> Output Class Initialized
INFO - 2018-03-28 15:05:27 --> Security Class Initialized
DEBUG - 2018-03-28 15:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:05:27 --> Input Class Initialized
INFO - 2018-03-28 15:05:27 --> Language Class Initialized
INFO - 2018-03-28 15:05:27 --> Loader Class Initialized
INFO - 2018-03-28 15:05:27 --> Helper loaded: url_helper
INFO - 2018-03-28 15:05:27 --> Helper loaded: form_helper
INFO - 2018-03-28 15:05:27 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:05:27 --> Controller Class Initialized
INFO - 2018-03-28 15:05:27 --> Model Class Initialized
INFO - 2018-03-28 15:05:27 --> Model Class Initialized
INFO - 2018-03-28 15:05:27 --> Helper loaded: date_helper
INFO - 2018-03-28 15:05:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:05:27 --> Model Class Initialized
INFO - 2018-03-28 20:05:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:05:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:05:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:05:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:05:27 --> Final output sent to browser
DEBUG - 2018-03-28 20:05:27 --> Total execution time: 0.1054
INFO - 2018-03-28 15:05:39 --> Config Class Initialized
INFO - 2018-03-28 15:05:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:05:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:05:39 --> Utf8 Class Initialized
INFO - 2018-03-28 15:05:39 --> URI Class Initialized
INFO - 2018-03-28 15:05:39 --> Router Class Initialized
INFO - 2018-03-28 15:05:39 --> Output Class Initialized
INFO - 2018-03-28 15:05:39 --> Security Class Initialized
DEBUG - 2018-03-28 15:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:05:39 --> Input Class Initialized
INFO - 2018-03-28 15:05:39 --> Language Class Initialized
INFO - 2018-03-28 15:05:39 --> Loader Class Initialized
INFO - 2018-03-28 15:05:39 --> Helper loaded: url_helper
INFO - 2018-03-28 15:05:39 --> Helper loaded: form_helper
INFO - 2018-03-28 15:05:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:05:39 --> Controller Class Initialized
INFO - 2018-03-28 15:05:39 --> Model Class Initialized
INFO - 2018-03-28 15:05:39 --> Model Class Initialized
INFO - 2018-03-28 15:05:39 --> Helper loaded: date_helper
INFO - 2018-03-28 15:05:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:05:39 --> Config Class Initialized
INFO - 2018-03-28 15:05:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:05:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:05:39 --> Utf8 Class Initialized
INFO - 2018-03-28 15:05:39 --> URI Class Initialized
INFO - 2018-03-28 15:05:39 --> Router Class Initialized
INFO - 2018-03-28 15:05:39 --> Output Class Initialized
INFO - 2018-03-28 15:05:39 --> Security Class Initialized
DEBUG - 2018-03-28 15:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:05:39 --> Input Class Initialized
INFO - 2018-03-28 15:05:39 --> Language Class Initialized
INFO - 2018-03-28 15:05:39 --> Loader Class Initialized
INFO - 2018-03-28 15:05:39 --> Helper loaded: url_helper
INFO - 2018-03-28 15:05:39 --> Helper loaded: form_helper
INFO - 2018-03-28 15:05:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:05:39 --> Controller Class Initialized
INFO - 2018-03-28 15:05:39 --> Model Class Initialized
INFO - 2018-03-28 15:05:39 --> Model Class Initialized
INFO - 2018-03-28 15:05:39 --> Helper loaded: date_helper
INFO - 2018-03-28 15:05:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:05:39 --> Model Class Initialized
INFO - 2018-03-28 20:05:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:05:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:05:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:05:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:05:39 --> Final output sent to browser
DEBUG - 2018-03-28 20:05:39 --> Total execution time: 0.1331
INFO - 2018-03-28 15:05:41 --> Config Class Initialized
INFO - 2018-03-28 15:05:41 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:05:41 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:05:41 --> Utf8 Class Initialized
INFO - 2018-03-28 15:05:41 --> URI Class Initialized
INFO - 2018-03-28 15:05:41 --> Router Class Initialized
INFO - 2018-03-28 15:05:41 --> Output Class Initialized
INFO - 2018-03-28 15:05:41 --> Security Class Initialized
DEBUG - 2018-03-28 15:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:05:41 --> Input Class Initialized
INFO - 2018-03-28 15:05:41 --> Language Class Initialized
INFO - 2018-03-28 15:05:41 --> Loader Class Initialized
INFO - 2018-03-28 15:05:41 --> Helper loaded: url_helper
INFO - 2018-03-28 15:05:41 --> Helper loaded: form_helper
INFO - 2018-03-28 15:05:41 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:05:41 --> Controller Class Initialized
INFO - 2018-03-28 15:05:41 --> Model Class Initialized
INFO - 2018-03-28 15:05:41 --> Model Class Initialized
INFO - 2018-03-28 15:05:41 --> Helper loaded: date_helper
INFO - 2018-03-28 15:05:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:05:41 --> Model Class Initialized
INFO - 2018-03-28 20:05:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:05:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:05:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:05:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:05:41 --> Final output sent to browser
DEBUG - 2018-03-28 20:05:41 --> Total execution time: 0.0882
INFO - 2018-03-28 15:05:56 --> Config Class Initialized
INFO - 2018-03-28 15:05:56 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:05:56 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:05:56 --> Utf8 Class Initialized
INFO - 2018-03-28 15:05:57 --> URI Class Initialized
INFO - 2018-03-28 15:05:57 --> Router Class Initialized
INFO - 2018-03-28 15:05:57 --> Output Class Initialized
INFO - 2018-03-28 15:05:57 --> Security Class Initialized
DEBUG - 2018-03-28 15:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:05:57 --> Input Class Initialized
INFO - 2018-03-28 15:05:57 --> Language Class Initialized
INFO - 2018-03-28 15:05:57 --> Loader Class Initialized
INFO - 2018-03-28 15:05:57 --> Helper loaded: url_helper
INFO - 2018-03-28 15:05:57 --> Helper loaded: form_helper
INFO - 2018-03-28 15:05:57 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:05:57 --> Controller Class Initialized
INFO - 2018-03-28 15:05:57 --> Model Class Initialized
INFO - 2018-03-28 15:05:57 --> Model Class Initialized
INFO - 2018-03-28 15:05:57 --> Helper loaded: date_helper
INFO - 2018-03-28 15:05:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:05:57 --> Config Class Initialized
INFO - 2018-03-28 15:05:57 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:05:57 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:05:57 --> Utf8 Class Initialized
INFO - 2018-03-28 15:05:57 --> URI Class Initialized
INFO - 2018-03-28 15:05:57 --> Router Class Initialized
INFO - 2018-03-28 15:05:57 --> Output Class Initialized
INFO - 2018-03-28 15:05:57 --> Security Class Initialized
DEBUG - 2018-03-28 15:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:05:57 --> Input Class Initialized
INFO - 2018-03-28 15:05:57 --> Language Class Initialized
INFO - 2018-03-28 15:05:57 --> Loader Class Initialized
INFO - 2018-03-28 15:05:57 --> Helper loaded: url_helper
INFO - 2018-03-28 15:05:57 --> Helper loaded: form_helper
INFO - 2018-03-28 15:05:57 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:05:57 --> Controller Class Initialized
INFO - 2018-03-28 15:05:57 --> Model Class Initialized
INFO - 2018-03-28 15:05:57 --> Model Class Initialized
INFO - 2018-03-28 15:05:57 --> Helper loaded: date_helper
INFO - 2018-03-28 15:05:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:05:57 --> Model Class Initialized
INFO - 2018-03-28 20:05:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:05:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:05:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:05:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:05:57 --> Final output sent to browser
DEBUG - 2018-03-28 20:05:57 --> Total execution time: 0.1388
INFO - 2018-03-28 15:05:58 --> Config Class Initialized
INFO - 2018-03-28 15:05:58 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:05:58 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:05:58 --> Utf8 Class Initialized
INFO - 2018-03-28 15:05:58 --> URI Class Initialized
INFO - 2018-03-28 15:05:58 --> Router Class Initialized
INFO - 2018-03-28 15:05:58 --> Output Class Initialized
INFO - 2018-03-28 15:05:58 --> Security Class Initialized
DEBUG - 2018-03-28 15:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:05:58 --> Input Class Initialized
INFO - 2018-03-28 15:05:58 --> Language Class Initialized
INFO - 2018-03-28 15:05:58 --> Loader Class Initialized
INFO - 2018-03-28 15:05:58 --> Helper loaded: url_helper
INFO - 2018-03-28 15:05:58 --> Helper loaded: form_helper
INFO - 2018-03-28 15:05:58 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:05:58 --> Controller Class Initialized
INFO - 2018-03-28 15:05:58 --> Model Class Initialized
INFO - 2018-03-28 15:05:58 --> Model Class Initialized
INFO - 2018-03-28 15:05:58 --> Helper loaded: date_helper
INFO - 2018-03-28 15:05:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:05:58 --> Model Class Initialized
INFO - 2018-03-28 20:05:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:05:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:05:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:05:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:05:58 --> Final output sent to browser
DEBUG - 2018-03-28 20:05:58 --> Total execution time: 0.1823
INFO - 2018-03-28 15:06:37 --> Config Class Initialized
INFO - 2018-03-28 15:06:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:06:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:06:37 --> Utf8 Class Initialized
INFO - 2018-03-28 15:06:37 --> URI Class Initialized
INFO - 2018-03-28 15:06:37 --> Router Class Initialized
INFO - 2018-03-28 15:06:37 --> Output Class Initialized
INFO - 2018-03-28 15:06:37 --> Security Class Initialized
DEBUG - 2018-03-28 15:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:06:37 --> Input Class Initialized
INFO - 2018-03-28 15:06:37 --> Language Class Initialized
INFO - 2018-03-28 15:06:37 --> Loader Class Initialized
INFO - 2018-03-28 15:06:37 --> Helper loaded: url_helper
INFO - 2018-03-28 15:06:37 --> Helper loaded: form_helper
INFO - 2018-03-28 15:06:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:06:37 --> Controller Class Initialized
INFO - 2018-03-28 15:06:37 --> Model Class Initialized
INFO - 2018-03-28 15:06:37 --> Model Class Initialized
INFO - 2018-03-28 15:06:37 --> Helper loaded: date_helper
INFO - 2018-03-28 15:06:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:06:37 --> Config Class Initialized
INFO - 2018-03-28 15:06:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:06:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:06:37 --> Utf8 Class Initialized
INFO - 2018-03-28 15:06:37 --> URI Class Initialized
INFO - 2018-03-28 15:06:37 --> Router Class Initialized
INFO - 2018-03-28 15:06:37 --> Output Class Initialized
INFO - 2018-03-28 15:06:37 --> Security Class Initialized
DEBUG - 2018-03-28 15:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:06:37 --> Input Class Initialized
INFO - 2018-03-28 15:06:37 --> Language Class Initialized
INFO - 2018-03-28 15:06:37 --> Loader Class Initialized
INFO - 2018-03-28 15:06:37 --> Helper loaded: url_helper
INFO - 2018-03-28 15:06:37 --> Helper loaded: form_helper
INFO - 2018-03-28 15:06:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:06:37 --> Controller Class Initialized
INFO - 2018-03-28 15:06:37 --> Model Class Initialized
INFO - 2018-03-28 15:06:37 --> Model Class Initialized
INFO - 2018-03-28 15:06:37 --> Helper loaded: date_helper
INFO - 2018-03-28 15:06:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:06:37 --> Model Class Initialized
INFO - 2018-03-28 20:06:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:06:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:06:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:06:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:06:37 --> Final output sent to browser
DEBUG - 2018-03-28 20:06:37 --> Total execution time: 0.1253
INFO - 2018-03-28 15:06:40 --> Config Class Initialized
INFO - 2018-03-28 15:06:40 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:06:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:06:40 --> Utf8 Class Initialized
INFO - 2018-03-28 15:06:40 --> URI Class Initialized
INFO - 2018-03-28 15:06:40 --> Router Class Initialized
INFO - 2018-03-28 15:06:40 --> Output Class Initialized
INFO - 2018-03-28 15:06:40 --> Security Class Initialized
DEBUG - 2018-03-28 15:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:06:40 --> Input Class Initialized
INFO - 2018-03-28 15:06:40 --> Language Class Initialized
INFO - 2018-03-28 15:06:40 --> Loader Class Initialized
INFO - 2018-03-28 15:06:40 --> Helper loaded: url_helper
INFO - 2018-03-28 15:06:40 --> Helper loaded: form_helper
INFO - 2018-03-28 15:06:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:06:40 --> Controller Class Initialized
INFO - 2018-03-28 15:06:40 --> Model Class Initialized
INFO - 2018-03-28 15:06:40 --> Model Class Initialized
INFO - 2018-03-28 15:06:40 --> Helper loaded: date_helper
INFO - 2018-03-28 15:06:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:06:40 --> Model Class Initialized
INFO - 2018-03-28 20:06:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:06:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:06:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:06:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:06:40 --> Final output sent to browser
DEBUG - 2018-03-28 20:06:40 --> Total execution time: 0.0957
INFO - 2018-03-28 15:07:03 --> Config Class Initialized
INFO - 2018-03-28 15:07:03 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:07:03 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:07:03 --> Utf8 Class Initialized
INFO - 2018-03-28 15:07:03 --> URI Class Initialized
INFO - 2018-03-28 15:07:03 --> Router Class Initialized
INFO - 2018-03-28 15:07:03 --> Output Class Initialized
INFO - 2018-03-28 15:07:03 --> Security Class Initialized
DEBUG - 2018-03-28 15:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:07:03 --> Input Class Initialized
INFO - 2018-03-28 15:07:03 --> Language Class Initialized
INFO - 2018-03-28 15:07:03 --> Loader Class Initialized
INFO - 2018-03-28 15:07:03 --> Helper loaded: url_helper
INFO - 2018-03-28 15:07:03 --> Helper loaded: form_helper
INFO - 2018-03-28 15:07:03 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:07:03 --> Controller Class Initialized
INFO - 2018-03-28 15:07:03 --> Model Class Initialized
INFO - 2018-03-28 15:07:03 --> Model Class Initialized
INFO - 2018-03-28 15:07:03 --> Helper loaded: date_helper
INFO - 2018-03-28 15:07:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:07:04 --> Config Class Initialized
INFO - 2018-03-28 15:07:04 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:07:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:07:04 --> Utf8 Class Initialized
INFO - 2018-03-28 15:07:04 --> URI Class Initialized
INFO - 2018-03-28 15:07:04 --> Router Class Initialized
INFO - 2018-03-28 15:07:04 --> Output Class Initialized
INFO - 2018-03-28 15:07:04 --> Security Class Initialized
DEBUG - 2018-03-28 15:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:07:04 --> Input Class Initialized
INFO - 2018-03-28 15:07:04 --> Language Class Initialized
INFO - 2018-03-28 15:07:04 --> Loader Class Initialized
INFO - 2018-03-28 15:07:04 --> Helper loaded: url_helper
INFO - 2018-03-28 15:07:04 --> Helper loaded: form_helper
INFO - 2018-03-28 15:07:04 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:07:04 --> Controller Class Initialized
INFO - 2018-03-28 15:07:04 --> Model Class Initialized
INFO - 2018-03-28 15:07:04 --> Model Class Initialized
INFO - 2018-03-28 15:07:04 --> Helper loaded: date_helper
INFO - 2018-03-28 15:07:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:07:04 --> Model Class Initialized
INFO - 2018-03-28 20:07:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:07:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:07:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:07:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:07:04 --> Final output sent to browser
DEBUG - 2018-03-28 20:07:04 --> Total execution time: 0.1388
INFO - 2018-03-28 15:07:06 --> Config Class Initialized
INFO - 2018-03-28 15:07:06 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:07:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:07:06 --> Utf8 Class Initialized
INFO - 2018-03-28 15:07:06 --> URI Class Initialized
INFO - 2018-03-28 15:07:06 --> Router Class Initialized
INFO - 2018-03-28 15:07:06 --> Output Class Initialized
INFO - 2018-03-28 15:07:06 --> Security Class Initialized
DEBUG - 2018-03-28 15:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:07:06 --> Input Class Initialized
INFO - 2018-03-28 15:07:06 --> Language Class Initialized
INFO - 2018-03-28 15:07:06 --> Loader Class Initialized
INFO - 2018-03-28 15:07:06 --> Helper loaded: url_helper
INFO - 2018-03-28 15:07:06 --> Helper loaded: form_helper
INFO - 2018-03-28 15:07:06 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:07:06 --> Controller Class Initialized
INFO - 2018-03-28 15:07:06 --> Model Class Initialized
INFO - 2018-03-28 15:07:06 --> Model Class Initialized
INFO - 2018-03-28 15:07:06 --> Helper loaded: date_helper
INFO - 2018-03-28 15:07:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:07:06 --> Model Class Initialized
INFO - 2018-03-28 20:07:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:07:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:07:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:07:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:07:06 --> Final output sent to browser
DEBUG - 2018-03-28 20:07:06 --> Total execution time: 0.1323
INFO - 2018-03-28 15:07:20 --> Config Class Initialized
INFO - 2018-03-28 15:07:20 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:07:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:07:20 --> Utf8 Class Initialized
INFO - 2018-03-28 15:07:20 --> URI Class Initialized
INFO - 2018-03-28 15:07:20 --> Router Class Initialized
INFO - 2018-03-28 15:07:20 --> Output Class Initialized
INFO - 2018-03-28 15:07:20 --> Security Class Initialized
DEBUG - 2018-03-28 15:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:07:21 --> Input Class Initialized
INFO - 2018-03-28 15:07:21 --> Language Class Initialized
INFO - 2018-03-28 15:07:21 --> Loader Class Initialized
INFO - 2018-03-28 15:07:21 --> Helper loaded: url_helper
INFO - 2018-03-28 15:07:21 --> Helper loaded: form_helper
INFO - 2018-03-28 15:07:21 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:07:21 --> Controller Class Initialized
INFO - 2018-03-28 15:07:21 --> Model Class Initialized
INFO - 2018-03-28 15:07:21 --> Model Class Initialized
INFO - 2018-03-28 15:07:21 --> Helper loaded: date_helper
INFO - 2018-03-28 15:07:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:07:21 --> Config Class Initialized
INFO - 2018-03-28 15:07:21 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:07:21 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:07:21 --> Utf8 Class Initialized
INFO - 2018-03-28 15:07:21 --> URI Class Initialized
INFO - 2018-03-28 15:07:21 --> Router Class Initialized
INFO - 2018-03-28 15:07:21 --> Output Class Initialized
INFO - 2018-03-28 15:07:21 --> Security Class Initialized
DEBUG - 2018-03-28 15:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:07:21 --> Input Class Initialized
INFO - 2018-03-28 15:07:21 --> Language Class Initialized
INFO - 2018-03-28 15:07:21 --> Loader Class Initialized
INFO - 2018-03-28 15:07:21 --> Helper loaded: url_helper
INFO - 2018-03-28 15:07:21 --> Helper loaded: form_helper
INFO - 2018-03-28 15:07:21 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:07:21 --> Controller Class Initialized
INFO - 2018-03-28 15:07:21 --> Model Class Initialized
INFO - 2018-03-28 15:07:21 --> Model Class Initialized
INFO - 2018-03-28 15:07:21 --> Helper loaded: date_helper
INFO - 2018-03-28 15:07:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:07:21 --> Model Class Initialized
INFO - 2018-03-28 20:07:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:07:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:07:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:07:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:07:21 --> Final output sent to browser
DEBUG - 2018-03-28 20:07:21 --> Total execution time: 0.1318
INFO - 2018-03-28 15:07:23 --> Config Class Initialized
INFO - 2018-03-28 15:07:23 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:07:23 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:07:23 --> Utf8 Class Initialized
INFO - 2018-03-28 15:07:23 --> URI Class Initialized
INFO - 2018-03-28 15:07:23 --> Router Class Initialized
INFO - 2018-03-28 15:07:23 --> Output Class Initialized
INFO - 2018-03-28 15:07:23 --> Security Class Initialized
DEBUG - 2018-03-28 15:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:07:23 --> Input Class Initialized
INFO - 2018-03-28 15:07:23 --> Language Class Initialized
INFO - 2018-03-28 15:07:23 --> Loader Class Initialized
INFO - 2018-03-28 15:07:23 --> Helper loaded: url_helper
INFO - 2018-03-28 15:07:23 --> Helper loaded: form_helper
INFO - 2018-03-28 15:07:23 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:07:23 --> Controller Class Initialized
INFO - 2018-03-28 15:07:23 --> Model Class Initialized
INFO - 2018-03-28 15:07:23 --> Model Class Initialized
INFO - 2018-03-28 15:07:23 --> Helper loaded: date_helper
INFO - 2018-03-28 15:07:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:07:23 --> Model Class Initialized
INFO - 2018-03-28 20:07:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:07:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:07:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:07:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:07:23 --> Final output sent to browser
DEBUG - 2018-03-28 20:07:23 --> Total execution time: 0.1241
INFO - 2018-03-28 15:07:33 --> Config Class Initialized
INFO - 2018-03-28 15:07:33 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:07:33 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:07:33 --> Utf8 Class Initialized
INFO - 2018-03-28 15:07:33 --> URI Class Initialized
INFO - 2018-03-28 15:07:33 --> Router Class Initialized
INFO - 2018-03-28 15:07:33 --> Output Class Initialized
INFO - 2018-03-28 15:07:33 --> Security Class Initialized
DEBUG - 2018-03-28 15:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:07:33 --> Input Class Initialized
INFO - 2018-03-28 15:07:33 --> Language Class Initialized
INFO - 2018-03-28 15:07:33 --> Loader Class Initialized
INFO - 2018-03-28 15:07:33 --> Helper loaded: url_helper
INFO - 2018-03-28 15:07:33 --> Helper loaded: form_helper
INFO - 2018-03-28 15:07:33 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:07:33 --> Controller Class Initialized
INFO - 2018-03-28 15:07:33 --> Model Class Initialized
INFO - 2018-03-28 15:07:33 --> Model Class Initialized
INFO - 2018-03-28 15:07:33 --> Helper loaded: date_helper
INFO - 2018-03-28 15:07:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:07:33 --> Config Class Initialized
INFO - 2018-03-28 15:07:33 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:07:33 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:07:33 --> Utf8 Class Initialized
INFO - 2018-03-28 15:07:33 --> URI Class Initialized
INFO - 2018-03-28 15:07:33 --> Router Class Initialized
INFO - 2018-03-28 15:07:33 --> Output Class Initialized
INFO - 2018-03-28 15:07:33 --> Security Class Initialized
DEBUG - 2018-03-28 15:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:07:33 --> Input Class Initialized
INFO - 2018-03-28 15:07:33 --> Language Class Initialized
INFO - 2018-03-28 15:07:33 --> Loader Class Initialized
INFO - 2018-03-28 15:07:33 --> Helper loaded: url_helper
INFO - 2018-03-28 15:07:33 --> Helper loaded: form_helper
INFO - 2018-03-28 15:07:33 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:07:33 --> Controller Class Initialized
INFO - 2018-03-28 15:07:33 --> Model Class Initialized
INFO - 2018-03-28 15:07:33 --> Model Class Initialized
INFO - 2018-03-28 15:07:33 --> Helper loaded: date_helper
INFO - 2018-03-28 15:07:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:07:33 --> Model Class Initialized
INFO - 2018-03-28 20:07:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:07:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:07:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:07:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:07:33 --> Final output sent to browser
DEBUG - 2018-03-28 20:07:33 --> Total execution time: 0.1300
INFO - 2018-03-28 15:07:38 --> Config Class Initialized
INFO - 2018-03-28 15:07:38 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:07:38 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:07:38 --> Utf8 Class Initialized
INFO - 2018-03-28 15:07:38 --> URI Class Initialized
INFO - 2018-03-28 15:07:38 --> Router Class Initialized
INFO - 2018-03-28 15:07:38 --> Output Class Initialized
INFO - 2018-03-28 15:07:38 --> Security Class Initialized
DEBUG - 2018-03-28 15:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:07:38 --> Input Class Initialized
INFO - 2018-03-28 15:07:38 --> Language Class Initialized
INFO - 2018-03-28 15:07:38 --> Loader Class Initialized
INFO - 2018-03-28 15:07:38 --> Helper loaded: url_helper
INFO - 2018-03-28 15:07:38 --> Helper loaded: form_helper
INFO - 2018-03-28 15:07:38 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:07:38 --> Controller Class Initialized
INFO - 2018-03-28 15:07:38 --> Model Class Initialized
INFO - 2018-03-28 15:07:38 --> Model Class Initialized
INFO - 2018-03-28 15:07:38 --> Helper loaded: date_helper
INFO - 2018-03-28 15:07:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:07:38 --> Model Class Initialized
INFO - 2018-03-28 20:07:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:07:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:07:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:07:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:07:38 --> Final output sent to browser
DEBUG - 2018-03-28 20:07:38 --> Total execution time: 0.1060
INFO - 2018-03-28 15:08:23 --> Config Class Initialized
INFO - 2018-03-28 15:08:23 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:08:23 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:08:23 --> Utf8 Class Initialized
INFO - 2018-03-28 15:08:23 --> URI Class Initialized
INFO - 2018-03-28 15:08:23 --> Router Class Initialized
INFO - 2018-03-28 15:08:23 --> Output Class Initialized
INFO - 2018-03-28 15:08:23 --> Security Class Initialized
DEBUG - 2018-03-28 15:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:08:23 --> Input Class Initialized
INFO - 2018-03-28 15:08:23 --> Language Class Initialized
INFO - 2018-03-28 15:08:23 --> Loader Class Initialized
INFO - 2018-03-28 15:08:23 --> Helper loaded: url_helper
INFO - 2018-03-28 15:08:23 --> Helper loaded: form_helper
INFO - 2018-03-28 15:08:23 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:08:23 --> Controller Class Initialized
INFO - 2018-03-28 15:08:23 --> Model Class Initialized
INFO - 2018-03-28 15:08:23 --> Model Class Initialized
INFO - 2018-03-28 15:08:23 --> Helper loaded: date_helper
INFO - 2018-03-28 15:08:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:08:23 --> Config Class Initialized
INFO - 2018-03-28 15:08:23 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:08:23 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:08:23 --> Utf8 Class Initialized
INFO - 2018-03-28 15:08:23 --> URI Class Initialized
INFO - 2018-03-28 15:08:23 --> Router Class Initialized
INFO - 2018-03-28 15:08:23 --> Output Class Initialized
INFO - 2018-03-28 15:08:23 --> Security Class Initialized
DEBUG - 2018-03-28 15:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:08:23 --> Input Class Initialized
INFO - 2018-03-28 15:08:23 --> Language Class Initialized
INFO - 2018-03-28 15:08:23 --> Loader Class Initialized
INFO - 2018-03-28 15:08:23 --> Helper loaded: url_helper
INFO - 2018-03-28 15:08:23 --> Helper loaded: form_helper
INFO - 2018-03-28 15:08:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:08:24 --> Controller Class Initialized
INFO - 2018-03-28 15:08:24 --> Model Class Initialized
INFO - 2018-03-28 15:08:24 --> Model Class Initialized
INFO - 2018-03-28 15:08:24 --> Helper loaded: date_helper
INFO - 2018-03-28 15:08:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:08:24 --> Model Class Initialized
INFO - 2018-03-28 20:08:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:08:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:08:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:08:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:08:24 --> Final output sent to browser
DEBUG - 2018-03-28 20:08:24 --> Total execution time: 0.1196
INFO - 2018-03-28 15:08:25 --> Config Class Initialized
INFO - 2018-03-28 15:08:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:08:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:08:25 --> Utf8 Class Initialized
INFO - 2018-03-28 15:08:25 --> URI Class Initialized
INFO - 2018-03-28 15:08:25 --> Router Class Initialized
INFO - 2018-03-28 15:08:25 --> Output Class Initialized
INFO - 2018-03-28 15:08:25 --> Security Class Initialized
DEBUG - 2018-03-28 15:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:08:25 --> Input Class Initialized
INFO - 2018-03-28 15:08:25 --> Language Class Initialized
INFO - 2018-03-28 15:08:25 --> Loader Class Initialized
INFO - 2018-03-28 15:08:25 --> Helper loaded: url_helper
INFO - 2018-03-28 15:08:25 --> Helper loaded: form_helper
INFO - 2018-03-28 15:08:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:08:25 --> Controller Class Initialized
INFO - 2018-03-28 15:08:25 --> Model Class Initialized
INFO - 2018-03-28 15:08:25 --> Model Class Initialized
INFO - 2018-03-28 15:08:25 --> Helper loaded: date_helper
INFO - 2018-03-28 15:08:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:08:25 --> Model Class Initialized
INFO - 2018-03-28 20:08:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:08:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:08:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:08:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:08:25 --> Final output sent to browser
DEBUG - 2018-03-28 20:08:25 --> Total execution time: 0.1449
INFO - 2018-03-28 15:08:47 --> Config Class Initialized
INFO - 2018-03-28 15:08:47 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:08:47 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:08:47 --> Utf8 Class Initialized
INFO - 2018-03-28 15:08:47 --> URI Class Initialized
INFO - 2018-03-28 15:08:47 --> Router Class Initialized
INFO - 2018-03-28 15:08:47 --> Output Class Initialized
INFO - 2018-03-28 15:08:47 --> Security Class Initialized
DEBUG - 2018-03-28 15:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:08:47 --> Input Class Initialized
INFO - 2018-03-28 15:08:47 --> Language Class Initialized
INFO - 2018-03-28 15:08:47 --> Loader Class Initialized
INFO - 2018-03-28 15:08:47 --> Helper loaded: url_helper
INFO - 2018-03-28 15:08:47 --> Helper loaded: form_helper
INFO - 2018-03-28 15:08:47 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:08:47 --> Controller Class Initialized
INFO - 2018-03-28 15:08:47 --> Model Class Initialized
INFO - 2018-03-28 15:08:47 --> Model Class Initialized
INFO - 2018-03-28 15:08:47 --> Helper loaded: date_helper
INFO - 2018-03-28 15:08:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:08:48 --> Config Class Initialized
INFO - 2018-03-28 15:08:48 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:08:48 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:08:48 --> Utf8 Class Initialized
INFO - 2018-03-28 15:08:48 --> URI Class Initialized
INFO - 2018-03-28 15:08:48 --> Router Class Initialized
INFO - 2018-03-28 15:08:48 --> Output Class Initialized
INFO - 2018-03-28 15:08:48 --> Security Class Initialized
DEBUG - 2018-03-28 15:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:08:48 --> Input Class Initialized
INFO - 2018-03-28 15:08:48 --> Language Class Initialized
INFO - 2018-03-28 15:08:48 --> Loader Class Initialized
INFO - 2018-03-28 15:08:48 --> Helper loaded: url_helper
INFO - 2018-03-28 15:08:48 --> Helper loaded: form_helper
INFO - 2018-03-28 15:08:48 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:08:48 --> Controller Class Initialized
INFO - 2018-03-28 15:08:48 --> Model Class Initialized
INFO - 2018-03-28 15:08:48 --> Model Class Initialized
INFO - 2018-03-28 15:08:48 --> Helper loaded: date_helper
INFO - 2018-03-28 15:08:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:08:48 --> Model Class Initialized
INFO - 2018-03-28 20:08:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:08:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:08:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:08:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:08:48 --> Final output sent to browser
DEBUG - 2018-03-28 20:08:48 --> Total execution time: 0.1383
INFO - 2018-03-28 15:08:49 --> Config Class Initialized
INFO - 2018-03-28 15:08:49 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:08:49 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:08:49 --> Utf8 Class Initialized
INFO - 2018-03-28 15:08:49 --> URI Class Initialized
INFO - 2018-03-28 15:08:49 --> Router Class Initialized
INFO - 2018-03-28 15:08:49 --> Output Class Initialized
INFO - 2018-03-28 15:08:49 --> Security Class Initialized
DEBUG - 2018-03-28 15:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:08:49 --> Input Class Initialized
INFO - 2018-03-28 15:08:49 --> Language Class Initialized
INFO - 2018-03-28 15:08:49 --> Loader Class Initialized
INFO - 2018-03-28 15:08:49 --> Helper loaded: url_helper
INFO - 2018-03-28 15:08:49 --> Helper loaded: form_helper
INFO - 2018-03-28 15:08:49 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:08:49 --> Controller Class Initialized
INFO - 2018-03-28 15:08:49 --> Model Class Initialized
INFO - 2018-03-28 15:08:49 --> Model Class Initialized
INFO - 2018-03-28 15:08:49 --> Helper loaded: date_helper
INFO - 2018-03-28 15:08:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:08:49 --> Model Class Initialized
INFO - 2018-03-28 20:08:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:08:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:08:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:08:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:08:49 --> Final output sent to browser
DEBUG - 2018-03-28 20:08:49 --> Total execution time: 0.2066
INFO - 2018-03-28 15:09:19 --> Config Class Initialized
INFO - 2018-03-28 15:09:19 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:09:19 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:09:19 --> Utf8 Class Initialized
INFO - 2018-03-28 15:09:19 --> URI Class Initialized
INFO - 2018-03-28 15:09:19 --> Router Class Initialized
INFO - 2018-03-28 15:09:19 --> Output Class Initialized
INFO - 2018-03-28 15:09:19 --> Security Class Initialized
DEBUG - 2018-03-28 15:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:09:19 --> Input Class Initialized
INFO - 2018-03-28 15:09:19 --> Language Class Initialized
INFO - 2018-03-28 15:09:19 --> Loader Class Initialized
INFO - 2018-03-28 15:09:19 --> Helper loaded: url_helper
INFO - 2018-03-28 15:09:19 --> Helper loaded: form_helper
INFO - 2018-03-28 15:09:19 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:09:19 --> Controller Class Initialized
INFO - 2018-03-28 15:09:19 --> Model Class Initialized
INFO - 2018-03-28 15:09:19 --> Model Class Initialized
INFO - 2018-03-28 15:09:19 --> Helper loaded: date_helper
INFO - 2018-03-28 15:09:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:09:20 --> Config Class Initialized
INFO - 2018-03-28 15:09:20 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:09:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:09:20 --> Utf8 Class Initialized
INFO - 2018-03-28 15:09:20 --> URI Class Initialized
INFO - 2018-03-28 15:09:20 --> Router Class Initialized
INFO - 2018-03-28 15:09:20 --> Output Class Initialized
INFO - 2018-03-28 15:09:20 --> Security Class Initialized
DEBUG - 2018-03-28 15:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:09:20 --> Input Class Initialized
INFO - 2018-03-28 15:09:20 --> Language Class Initialized
INFO - 2018-03-28 15:09:20 --> Loader Class Initialized
INFO - 2018-03-28 15:09:20 --> Helper loaded: url_helper
INFO - 2018-03-28 15:09:20 --> Helper loaded: form_helper
INFO - 2018-03-28 15:09:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:09:20 --> Controller Class Initialized
INFO - 2018-03-28 15:09:20 --> Model Class Initialized
INFO - 2018-03-28 15:09:20 --> Model Class Initialized
INFO - 2018-03-28 15:09:20 --> Helper loaded: date_helper
INFO - 2018-03-28 15:09:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:09:20 --> Model Class Initialized
INFO - 2018-03-28 20:09:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:09:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:09:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:09:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:09:20 --> Final output sent to browser
DEBUG - 2018-03-28 20:09:20 --> Total execution time: 0.1240
INFO - 2018-03-28 15:09:23 --> Config Class Initialized
INFO - 2018-03-28 15:09:23 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:09:23 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:09:23 --> Utf8 Class Initialized
INFO - 2018-03-28 15:09:23 --> URI Class Initialized
INFO - 2018-03-28 15:09:23 --> Router Class Initialized
INFO - 2018-03-28 15:09:23 --> Output Class Initialized
INFO - 2018-03-28 15:09:23 --> Security Class Initialized
DEBUG - 2018-03-28 15:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:09:23 --> Input Class Initialized
INFO - 2018-03-28 15:09:23 --> Language Class Initialized
INFO - 2018-03-28 15:09:23 --> Loader Class Initialized
INFO - 2018-03-28 15:09:23 --> Helper loaded: url_helper
INFO - 2018-03-28 15:09:23 --> Helper loaded: form_helper
INFO - 2018-03-28 15:09:23 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:09:23 --> Controller Class Initialized
INFO - 2018-03-28 15:09:23 --> Model Class Initialized
INFO - 2018-03-28 15:09:23 --> Model Class Initialized
INFO - 2018-03-28 15:09:23 --> Helper loaded: date_helper
INFO - 2018-03-28 15:09:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:09:23 --> Model Class Initialized
INFO - 2018-03-28 20:09:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:09:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:09:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:09:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:09:23 --> Final output sent to browser
DEBUG - 2018-03-28 20:09:23 --> Total execution time: 0.1048
INFO - 2018-03-28 15:09:52 --> Config Class Initialized
INFO - 2018-03-28 15:09:52 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:09:52 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:09:52 --> Utf8 Class Initialized
INFO - 2018-03-28 15:09:52 --> URI Class Initialized
INFO - 2018-03-28 15:09:52 --> Router Class Initialized
INFO - 2018-03-28 15:09:52 --> Output Class Initialized
INFO - 2018-03-28 15:09:52 --> Security Class Initialized
DEBUG - 2018-03-28 15:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:09:52 --> Input Class Initialized
INFO - 2018-03-28 15:09:52 --> Language Class Initialized
INFO - 2018-03-28 15:09:52 --> Loader Class Initialized
INFO - 2018-03-28 15:09:52 --> Helper loaded: url_helper
INFO - 2018-03-28 15:09:52 --> Helper loaded: form_helper
INFO - 2018-03-28 15:09:52 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:09:52 --> Controller Class Initialized
INFO - 2018-03-28 15:09:52 --> Model Class Initialized
INFO - 2018-03-28 15:09:52 --> Model Class Initialized
INFO - 2018-03-28 15:09:52 --> Helper loaded: date_helper
INFO - 2018-03-28 15:09:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:09:52 --> Config Class Initialized
INFO - 2018-03-28 15:09:52 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:09:52 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:09:52 --> Utf8 Class Initialized
INFO - 2018-03-28 15:09:52 --> URI Class Initialized
INFO - 2018-03-28 15:09:52 --> Router Class Initialized
INFO - 2018-03-28 15:09:52 --> Output Class Initialized
INFO - 2018-03-28 15:09:52 --> Security Class Initialized
DEBUG - 2018-03-28 15:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:09:52 --> Input Class Initialized
INFO - 2018-03-28 15:09:52 --> Language Class Initialized
INFO - 2018-03-28 15:09:52 --> Loader Class Initialized
INFO - 2018-03-28 15:09:52 --> Helper loaded: url_helper
INFO - 2018-03-28 15:09:52 --> Helper loaded: form_helper
INFO - 2018-03-28 15:09:52 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:09:52 --> Controller Class Initialized
INFO - 2018-03-28 15:09:52 --> Model Class Initialized
INFO - 2018-03-28 15:09:52 --> Model Class Initialized
INFO - 2018-03-28 15:09:52 --> Helper loaded: date_helper
INFO - 2018-03-28 15:09:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:09:52 --> Model Class Initialized
INFO - 2018-03-28 20:09:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:09:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:09:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:09:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:09:52 --> Final output sent to browser
DEBUG - 2018-03-28 20:09:52 --> Total execution time: 0.1203
INFO - 2018-03-28 15:09:54 --> Config Class Initialized
INFO - 2018-03-28 15:09:54 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:09:54 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:09:54 --> Utf8 Class Initialized
INFO - 2018-03-28 15:09:54 --> URI Class Initialized
INFO - 2018-03-28 15:09:54 --> Router Class Initialized
INFO - 2018-03-28 15:09:54 --> Output Class Initialized
INFO - 2018-03-28 15:09:54 --> Security Class Initialized
DEBUG - 2018-03-28 15:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:09:54 --> Input Class Initialized
INFO - 2018-03-28 15:09:54 --> Language Class Initialized
INFO - 2018-03-28 15:09:54 --> Loader Class Initialized
INFO - 2018-03-28 15:09:54 --> Helper loaded: url_helper
INFO - 2018-03-28 15:09:54 --> Helper loaded: form_helper
INFO - 2018-03-28 15:09:54 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:09:54 --> Controller Class Initialized
INFO - 2018-03-28 15:09:54 --> Model Class Initialized
INFO - 2018-03-28 15:09:54 --> Model Class Initialized
INFO - 2018-03-28 15:09:54 --> Helper loaded: date_helper
INFO - 2018-03-28 15:09:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:09:54 --> Model Class Initialized
INFO - 2018-03-28 20:09:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:09:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:09:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:09:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:09:54 --> Final output sent to browser
DEBUG - 2018-03-28 20:09:54 --> Total execution time: 0.0849
INFO - 2018-03-28 15:10:12 --> Config Class Initialized
INFO - 2018-03-28 15:10:12 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:10:12 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:10:12 --> Utf8 Class Initialized
INFO - 2018-03-28 15:10:12 --> URI Class Initialized
INFO - 2018-03-28 15:10:12 --> Router Class Initialized
INFO - 2018-03-28 15:10:12 --> Output Class Initialized
INFO - 2018-03-28 15:10:12 --> Security Class Initialized
DEBUG - 2018-03-28 15:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:10:12 --> Input Class Initialized
INFO - 2018-03-28 15:10:12 --> Language Class Initialized
INFO - 2018-03-28 15:10:12 --> Loader Class Initialized
INFO - 2018-03-28 15:10:12 --> Helper loaded: url_helper
INFO - 2018-03-28 15:10:12 --> Helper loaded: form_helper
INFO - 2018-03-28 15:10:12 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:10:12 --> Controller Class Initialized
INFO - 2018-03-28 15:10:12 --> Model Class Initialized
INFO - 2018-03-28 15:10:12 --> Model Class Initialized
INFO - 2018-03-28 15:10:12 --> Helper loaded: date_helper
INFO - 2018-03-28 15:10:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:10:12 --> Config Class Initialized
INFO - 2018-03-28 15:10:12 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:10:12 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:10:12 --> Utf8 Class Initialized
INFO - 2018-03-28 15:10:12 --> URI Class Initialized
INFO - 2018-03-28 15:10:12 --> Router Class Initialized
INFO - 2018-03-28 15:10:12 --> Output Class Initialized
INFO - 2018-03-28 15:10:12 --> Security Class Initialized
DEBUG - 2018-03-28 15:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:10:12 --> Input Class Initialized
INFO - 2018-03-28 15:10:12 --> Language Class Initialized
INFO - 2018-03-28 15:10:12 --> Loader Class Initialized
INFO - 2018-03-28 15:10:12 --> Helper loaded: url_helper
INFO - 2018-03-28 15:10:12 --> Helper loaded: form_helper
INFO - 2018-03-28 15:10:12 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:10:12 --> Controller Class Initialized
INFO - 2018-03-28 15:10:12 --> Model Class Initialized
INFO - 2018-03-28 15:10:12 --> Model Class Initialized
INFO - 2018-03-28 15:10:12 --> Helper loaded: date_helper
INFO - 2018-03-28 15:10:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:10:12 --> Model Class Initialized
INFO - 2018-03-28 20:10:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:10:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:10:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:10:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:10:12 --> Final output sent to browser
DEBUG - 2018-03-28 20:10:12 --> Total execution time: 0.1449
INFO - 2018-03-28 15:10:14 --> Config Class Initialized
INFO - 2018-03-28 15:10:14 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:10:14 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:10:14 --> Utf8 Class Initialized
INFO - 2018-03-28 15:10:14 --> URI Class Initialized
INFO - 2018-03-28 15:10:14 --> Router Class Initialized
INFO - 2018-03-28 15:10:14 --> Output Class Initialized
INFO - 2018-03-28 15:10:14 --> Security Class Initialized
DEBUG - 2018-03-28 15:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:10:14 --> Input Class Initialized
INFO - 2018-03-28 15:10:14 --> Language Class Initialized
INFO - 2018-03-28 15:10:14 --> Loader Class Initialized
INFO - 2018-03-28 15:10:14 --> Helper loaded: url_helper
INFO - 2018-03-28 15:10:14 --> Helper loaded: form_helper
INFO - 2018-03-28 15:10:14 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:10:14 --> Controller Class Initialized
INFO - 2018-03-28 15:10:14 --> Model Class Initialized
INFO - 2018-03-28 15:10:14 --> Model Class Initialized
INFO - 2018-03-28 15:10:14 --> Helper loaded: date_helper
INFO - 2018-03-28 15:10:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:10:14 --> Model Class Initialized
INFO - 2018-03-28 20:10:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:10:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:10:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:10:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:10:14 --> Final output sent to browser
DEBUG - 2018-03-28 20:10:14 --> Total execution time: 0.1430
INFO - 2018-03-28 15:10:29 --> Config Class Initialized
INFO - 2018-03-28 15:10:29 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:10:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:10:29 --> Utf8 Class Initialized
INFO - 2018-03-28 15:10:29 --> URI Class Initialized
INFO - 2018-03-28 15:10:29 --> Router Class Initialized
INFO - 2018-03-28 15:10:29 --> Output Class Initialized
INFO - 2018-03-28 15:10:29 --> Security Class Initialized
DEBUG - 2018-03-28 15:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:10:29 --> Input Class Initialized
INFO - 2018-03-28 15:10:29 --> Language Class Initialized
INFO - 2018-03-28 15:10:29 --> Loader Class Initialized
INFO - 2018-03-28 15:10:29 --> Helper loaded: url_helper
INFO - 2018-03-28 15:10:29 --> Helper loaded: form_helper
INFO - 2018-03-28 15:10:29 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:10:29 --> Controller Class Initialized
INFO - 2018-03-28 15:10:29 --> Model Class Initialized
INFO - 2018-03-28 15:10:29 --> Model Class Initialized
INFO - 2018-03-28 15:10:29 --> Helper loaded: date_helper
INFO - 2018-03-28 15:10:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:10:30 --> Config Class Initialized
INFO - 2018-03-28 15:10:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:10:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:10:30 --> Utf8 Class Initialized
INFO - 2018-03-28 15:10:30 --> URI Class Initialized
INFO - 2018-03-28 15:10:30 --> Router Class Initialized
INFO - 2018-03-28 15:10:30 --> Output Class Initialized
INFO - 2018-03-28 15:10:30 --> Security Class Initialized
DEBUG - 2018-03-28 15:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:10:30 --> Input Class Initialized
INFO - 2018-03-28 15:10:30 --> Language Class Initialized
INFO - 2018-03-28 15:10:30 --> Loader Class Initialized
INFO - 2018-03-28 15:10:30 --> Helper loaded: url_helper
INFO - 2018-03-28 15:10:30 --> Helper loaded: form_helper
INFO - 2018-03-28 15:10:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:10:30 --> Controller Class Initialized
INFO - 2018-03-28 15:10:30 --> Model Class Initialized
INFO - 2018-03-28 15:10:30 --> Model Class Initialized
INFO - 2018-03-28 15:10:30 --> Helper loaded: date_helper
INFO - 2018-03-28 15:10:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:10:30 --> Model Class Initialized
INFO - 2018-03-28 20:10:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:10:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:10:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:10:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:10:30 --> Final output sent to browser
DEBUG - 2018-03-28 20:10:30 --> Total execution time: 0.1307
INFO - 2018-03-28 15:10:31 --> Config Class Initialized
INFO - 2018-03-28 15:10:31 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:10:31 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:10:31 --> Utf8 Class Initialized
INFO - 2018-03-28 15:10:31 --> URI Class Initialized
INFO - 2018-03-28 15:10:31 --> Router Class Initialized
INFO - 2018-03-28 15:10:31 --> Output Class Initialized
INFO - 2018-03-28 15:10:31 --> Security Class Initialized
DEBUG - 2018-03-28 15:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:10:31 --> Input Class Initialized
INFO - 2018-03-28 15:10:31 --> Language Class Initialized
INFO - 2018-03-28 15:10:31 --> Loader Class Initialized
INFO - 2018-03-28 15:10:31 --> Helper loaded: url_helper
INFO - 2018-03-28 15:10:31 --> Helper loaded: form_helper
INFO - 2018-03-28 15:10:31 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:10:31 --> Controller Class Initialized
INFO - 2018-03-28 15:10:31 --> Model Class Initialized
INFO - 2018-03-28 15:10:31 --> Model Class Initialized
INFO - 2018-03-28 15:10:31 --> Helper loaded: date_helper
INFO - 2018-03-28 15:10:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:10:31 --> Model Class Initialized
INFO - 2018-03-28 20:10:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:10:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:10:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:10:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:10:31 --> Final output sent to browser
DEBUG - 2018-03-28 20:10:31 --> Total execution time: 0.2060
INFO - 2018-03-28 15:10:43 --> Config Class Initialized
INFO - 2018-03-28 15:10:43 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:10:43 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:10:43 --> Utf8 Class Initialized
INFO - 2018-03-28 15:10:43 --> URI Class Initialized
INFO - 2018-03-28 15:10:43 --> Router Class Initialized
INFO - 2018-03-28 15:10:43 --> Output Class Initialized
INFO - 2018-03-28 15:10:43 --> Security Class Initialized
DEBUG - 2018-03-28 15:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:10:43 --> Input Class Initialized
INFO - 2018-03-28 15:10:43 --> Language Class Initialized
INFO - 2018-03-28 15:10:43 --> Loader Class Initialized
INFO - 2018-03-28 15:10:43 --> Helper loaded: url_helper
INFO - 2018-03-28 15:10:43 --> Helper loaded: form_helper
INFO - 2018-03-28 15:10:43 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:10:43 --> Controller Class Initialized
INFO - 2018-03-28 15:10:43 --> Model Class Initialized
INFO - 2018-03-28 15:10:43 --> Model Class Initialized
INFO - 2018-03-28 15:10:43 --> Helper loaded: date_helper
INFO - 2018-03-28 15:10:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:10:43 --> Config Class Initialized
INFO - 2018-03-28 15:10:43 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:10:43 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:10:43 --> Utf8 Class Initialized
INFO - 2018-03-28 15:10:43 --> URI Class Initialized
INFO - 2018-03-28 15:10:43 --> Router Class Initialized
INFO - 2018-03-28 15:10:43 --> Output Class Initialized
INFO - 2018-03-28 15:10:43 --> Security Class Initialized
DEBUG - 2018-03-28 15:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:10:43 --> Input Class Initialized
INFO - 2018-03-28 15:10:43 --> Language Class Initialized
INFO - 2018-03-28 15:10:43 --> Loader Class Initialized
INFO - 2018-03-28 15:10:43 --> Helper loaded: url_helper
INFO - 2018-03-28 15:10:43 --> Helper loaded: form_helper
INFO - 2018-03-28 15:10:43 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:10:43 --> Controller Class Initialized
INFO - 2018-03-28 15:10:43 --> Model Class Initialized
INFO - 2018-03-28 15:10:43 --> Model Class Initialized
INFO - 2018-03-28 15:10:43 --> Helper loaded: date_helper
INFO - 2018-03-28 15:10:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:10:43 --> Model Class Initialized
INFO - 2018-03-28 20:10:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:10:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:10:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:10:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:10:43 --> Final output sent to browser
DEBUG - 2018-03-28 20:10:43 --> Total execution time: 0.1593
INFO - 2018-03-28 15:10:45 --> Config Class Initialized
INFO - 2018-03-28 15:10:45 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:10:45 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:10:45 --> Utf8 Class Initialized
INFO - 2018-03-28 15:10:45 --> URI Class Initialized
INFO - 2018-03-28 15:10:45 --> Router Class Initialized
INFO - 2018-03-28 15:10:45 --> Output Class Initialized
INFO - 2018-03-28 15:10:45 --> Security Class Initialized
DEBUG - 2018-03-28 15:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:10:45 --> Input Class Initialized
INFO - 2018-03-28 15:10:45 --> Language Class Initialized
INFO - 2018-03-28 15:10:45 --> Loader Class Initialized
INFO - 2018-03-28 15:10:45 --> Helper loaded: url_helper
INFO - 2018-03-28 15:10:45 --> Helper loaded: form_helper
INFO - 2018-03-28 15:10:45 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:10:45 --> Controller Class Initialized
INFO - 2018-03-28 15:10:45 --> Model Class Initialized
INFO - 2018-03-28 15:10:45 --> Model Class Initialized
INFO - 2018-03-28 15:10:45 --> Helper loaded: date_helper
INFO - 2018-03-28 15:10:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:10:45 --> Model Class Initialized
INFO - 2018-03-28 20:10:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:10:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:10:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:10:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:10:45 --> Final output sent to browser
DEBUG - 2018-03-28 20:10:45 --> Total execution time: 0.0899
INFO - 2018-03-28 15:11:10 --> Config Class Initialized
INFO - 2018-03-28 15:11:10 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:11:10 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:11:10 --> Utf8 Class Initialized
INFO - 2018-03-28 15:11:11 --> URI Class Initialized
INFO - 2018-03-28 15:11:11 --> Router Class Initialized
INFO - 2018-03-28 15:11:11 --> Output Class Initialized
INFO - 2018-03-28 15:11:11 --> Security Class Initialized
DEBUG - 2018-03-28 15:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:11:11 --> Input Class Initialized
INFO - 2018-03-28 15:11:11 --> Language Class Initialized
INFO - 2018-03-28 15:11:11 --> Loader Class Initialized
INFO - 2018-03-28 15:11:11 --> Helper loaded: url_helper
INFO - 2018-03-28 15:11:11 --> Helper loaded: form_helper
INFO - 2018-03-28 15:11:11 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:11:11 --> Controller Class Initialized
INFO - 2018-03-28 15:11:11 --> Model Class Initialized
INFO - 2018-03-28 15:11:11 --> Model Class Initialized
INFO - 2018-03-28 15:11:11 --> Helper loaded: date_helper
INFO - 2018-03-28 15:11:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:11:11 --> Config Class Initialized
INFO - 2018-03-28 15:11:11 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:11:11 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:11:11 --> Utf8 Class Initialized
INFO - 2018-03-28 15:11:11 --> URI Class Initialized
INFO - 2018-03-28 15:11:11 --> Router Class Initialized
INFO - 2018-03-28 15:11:11 --> Output Class Initialized
INFO - 2018-03-28 15:11:11 --> Security Class Initialized
DEBUG - 2018-03-28 15:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:11:11 --> Input Class Initialized
INFO - 2018-03-28 15:11:11 --> Language Class Initialized
INFO - 2018-03-28 15:11:11 --> Loader Class Initialized
INFO - 2018-03-28 15:11:11 --> Helper loaded: url_helper
INFO - 2018-03-28 15:11:11 --> Helper loaded: form_helper
INFO - 2018-03-28 15:11:11 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:11:11 --> Controller Class Initialized
INFO - 2018-03-28 15:11:11 --> Model Class Initialized
INFO - 2018-03-28 15:11:11 --> Model Class Initialized
INFO - 2018-03-28 15:11:11 --> Helper loaded: date_helper
INFO - 2018-03-28 15:11:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:11:11 --> Model Class Initialized
INFO - 2018-03-28 20:11:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:11:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:11:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:11:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:11:11 --> Final output sent to browser
DEBUG - 2018-03-28 20:11:11 --> Total execution time: 0.1099
INFO - 2018-03-28 15:11:12 --> Config Class Initialized
INFO - 2018-03-28 15:11:12 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:11:12 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:11:12 --> Utf8 Class Initialized
INFO - 2018-03-28 15:11:12 --> URI Class Initialized
INFO - 2018-03-28 15:11:12 --> Router Class Initialized
INFO - 2018-03-28 15:11:12 --> Output Class Initialized
INFO - 2018-03-28 15:11:12 --> Security Class Initialized
DEBUG - 2018-03-28 15:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:11:12 --> Input Class Initialized
INFO - 2018-03-28 15:11:12 --> Language Class Initialized
INFO - 2018-03-28 15:11:12 --> Loader Class Initialized
INFO - 2018-03-28 15:11:12 --> Helper loaded: url_helper
INFO - 2018-03-28 15:11:12 --> Helper loaded: form_helper
INFO - 2018-03-28 15:11:12 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:11:12 --> Controller Class Initialized
INFO - 2018-03-28 15:11:12 --> Model Class Initialized
INFO - 2018-03-28 15:11:12 --> Model Class Initialized
INFO - 2018-03-28 15:11:12 --> Helper loaded: date_helper
INFO - 2018-03-28 15:11:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:11:12 --> Model Class Initialized
INFO - 2018-03-28 20:11:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:11:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:11:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:11:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:11:13 --> Final output sent to browser
DEBUG - 2018-03-28 20:11:13 --> Total execution time: 0.2098
INFO - 2018-03-28 15:11:27 --> Config Class Initialized
INFO - 2018-03-28 15:11:27 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:11:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:11:27 --> Utf8 Class Initialized
INFO - 2018-03-28 15:11:27 --> URI Class Initialized
INFO - 2018-03-28 15:11:27 --> Router Class Initialized
INFO - 2018-03-28 15:11:27 --> Output Class Initialized
INFO - 2018-03-28 15:11:27 --> Security Class Initialized
DEBUG - 2018-03-28 15:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:11:27 --> Input Class Initialized
INFO - 2018-03-28 15:11:27 --> Language Class Initialized
INFO - 2018-03-28 15:11:27 --> Loader Class Initialized
INFO - 2018-03-28 15:11:27 --> Helper loaded: url_helper
INFO - 2018-03-28 15:11:27 --> Helper loaded: form_helper
INFO - 2018-03-28 15:11:27 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:11:27 --> Controller Class Initialized
INFO - 2018-03-28 15:11:27 --> Model Class Initialized
INFO - 2018-03-28 15:11:27 --> Model Class Initialized
INFO - 2018-03-28 15:11:27 --> Helper loaded: date_helper
INFO - 2018-03-28 15:11:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:11:27 --> Config Class Initialized
INFO - 2018-03-28 15:11:27 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:11:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:11:27 --> Utf8 Class Initialized
INFO - 2018-03-28 15:11:27 --> URI Class Initialized
INFO - 2018-03-28 15:11:27 --> Router Class Initialized
INFO - 2018-03-28 15:11:27 --> Output Class Initialized
INFO - 2018-03-28 15:11:27 --> Security Class Initialized
DEBUG - 2018-03-28 15:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:11:27 --> Input Class Initialized
INFO - 2018-03-28 15:11:27 --> Language Class Initialized
INFO - 2018-03-28 15:11:27 --> Loader Class Initialized
INFO - 2018-03-28 15:11:27 --> Helper loaded: url_helper
INFO - 2018-03-28 15:11:27 --> Helper loaded: form_helper
INFO - 2018-03-28 15:11:27 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:11:27 --> Controller Class Initialized
INFO - 2018-03-28 15:11:27 --> Model Class Initialized
INFO - 2018-03-28 15:11:27 --> Model Class Initialized
INFO - 2018-03-28 15:11:27 --> Helper loaded: date_helper
INFO - 2018-03-28 15:11:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:11:27 --> Model Class Initialized
INFO - 2018-03-28 20:11:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:11:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:11:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:11:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:11:27 --> Final output sent to browser
DEBUG - 2018-03-28 20:11:27 --> Total execution time: 0.1417
INFO - 2018-03-28 15:11:29 --> Config Class Initialized
INFO - 2018-03-28 15:11:29 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:11:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:11:29 --> Utf8 Class Initialized
INFO - 2018-03-28 15:11:29 --> URI Class Initialized
INFO - 2018-03-28 15:11:29 --> Router Class Initialized
INFO - 2018-03-28 15:11:29 --> Output Class Initialized
INFO - 2018-03-28 15:11:29 --> Security Class Initialized
DEBUG - 2018-03-28 15:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:11:29 --> Input Class Initialized
INFO - 2018-03-28 15:11:29 --> Language Class Initialized
INFO - 2018-03-28 15:11:29 --> Loader Class Initialized
INFO - 2018-03-28 15:11:29 --> Helper loaded: url_helper
INFO - 2018-03-28 15:11:29 --> Helper loaded: form_helper
INFO - 2018-03-28 15:11:29 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:11:29 --> Controller Class Initialized
INFO - 2018-03-28 15:11:29 --> Model Class Initialized
INFO - 2018-03-28 15:11:29 --> Model Class Initialized
INFO - 2018-03-28 15:11:29 --> Helper loaded: date_helper
INFO - 2018-03-28 15:11:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:11:29 --> Model Class Initialized
INFO - 2018-03-28 20:11:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:11:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:11:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:11:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:11:29 --> Final output sent to browser
DEBUG - 2018-03-28 20:11:29 --> Total execution time: 0.1976
INFO - 2018-03-28 15:11:48 --> Config Class Initialized
INFO - 2018-03-28 15:11:48 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:11:48 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:11:48 --> Utf8 Class Initialized
INFO - 2018-03-28 15:11:48 --> URI Class Initialized
INFO - 2018-03-28 15:11:48 --> Router Class Initialized
INFO - 2018-03-28 15:11:48 --> Output Class Initialized
INFO - 2018-03-28 15:11:48 --> Security Class Initialized
DEBUG - 2018-03-28 15:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:11:48 --> Input Class Initialized
INFO - 2018-03-28 15:11:48 --> Language Class Initialized
INFO - 2018-03-28 15:11:48 --> Loader Class Initialized
INFO - 2018-03-28 15:11:48 --> Helper loaded: url_helper
INFO - 2018-03-28 15:11:48 --> Helper loaded: form_helper
INFO - 2018-03-28 15:11:48 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:11:48 --> Controller Class Initialized
INFO - 2018-03-28 15:11:48 --> Model Class Initialized
INFO - 2018-03-28 15:11:48 --> Model Class Initialized
INFO - 2018-03-28 15:11:48 --> Helper loaded: date_helper
INFO - 2018-03-28 15:11:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:11:49 --> Config Class Initialized
INFO - 2018-03-28 15:11:49 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:11:49 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:11:49 --> Utf8 Class Initialized
INFO - 2018-03-28 15:11:49 --> URI Class Initialized
INFO - 2018-03-28 15:11:49 --> Router Class Initialized
INFO - 2018-03-28 15:11:49 --> Output Class Initialized
INFO - 2018-03-28 15:11:49 --> Security Class Initialized
DEBUG - 2018-03-28 15:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:11:49 --> Input Class Initialized
INFO - 2018-03-28 15:11:49 --> Language Class Initialized
INFO - 2018-03-28 15:11:49 --> Loader Class Initialized
INFO - 2018-03-28 15:11:49 --> Helper loaded: url_helper
INFO - 2018-03-28 15:11:49 --> Helper loaded: form_helper
INFO - 2018-03-28 15:11:49 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:11:49 --> Controller Class Initialized
INFO - 2018-03-28 15:11:49 --> Model Class Initialized
INFO - 2018-03-28 15:11:49 --> Model Class Initialized
INFO - 2018-03-28 15:11:49 --> Helper loaded: date_helper
INFO - 2018-03-28 15:11:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:11:49 --> Model Class Initialized
INFO - 2018-03-28 20:11:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:11:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:11:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:11:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:11:49 --> Final output sent to browser
DEBUG - 2018-03-28 20:11:49 --> Total execution time: 0.1376
INFO - 2018-03-28 15:11:50 --> Config Class Initialized
INFO - 2018-03-28 15:11:50 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:11:50 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:11:50 --> Utf8 Class Initialized
INFO - 2018-03-28 15:11:50 --> URI Class Initialized
INFO - 2018-03-28 15:11:50 --> Router Class Initialized
INFO - 2018-03-28 15:11:50 --> Output Class Initialized
INFO - 2018-03-28 15:11:50 --> Security Class Initialized
DEBUG - 2018-03-28 15:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:11:50 --> Input Class Initialized
INFO - 2018-03-28 15:11:50 --> Language Class Initialized
INFO - 2018-03-28 15:11:50 --> Loader Class Initialized
INFO - 2018-03-28 15:11:50 --> Helper loaded: url_helper
INFO - 2018-03-28 15:11:50 --> Helper loaded: form_helper
INFO - 2018-03-28 15:11:50 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:11:50 --> Controller Class Initialized
INFO - 2018-03-28 15:11:50 --> Model Class Initialized
INFO - 2018-03-28 15:11:50 --> Model Class Initialized
INFO - 2018-03-28 15:11:50 --> Helper loaded: date_helper
INFO - 2018-03-28 15:11:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:11:50 --> Model Class Initialized
INFO - 2018-03-28 20:11:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:11:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:11:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:11:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:11:51 --> Final output sent to browser
DEBUG - 2018-03-28 20:11:51 --> Total execution time: 0.2212
INFO - 2018-03-28 15:12:06 --> Config Class Initialized
INFO - 2018-03-28 15:12:06 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:12:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:12:06 --> Utf8 Class Initialized
INFO - 2018-03-28 15:12:06 --> URI Class Initialized
INFO - 2018-03-28 15:12:06 --> Router Class Initialized
INFO - 2018-03-28 15:12:06 --> Output Class Initialized
INFO - 2018-03-28 15:12:06 --> Security Class Initialized
DEBUG - 2018-03-28 15:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:12:06 --> Input Class Initialized
INFO - 2018-03-28 15:12:06 --> Language Class Initialized
INFO - 2018-03-28 15:12:06 --> Loader Class Initialized
INFO - 2018-03-28 15:12:06 --> Helper loaded: url_helper
INFO - 2018-03-28 15:12:06 --> Helper loaded: form_helper
INFO - 2018-03-28 15:12:06 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:12:06 --> Controller Class Initialized
INFO - 2018-03-28 15:12:06 --> Model Class Initialized
INFO - 2018-03-28 15:12:06 --> Model Class Initialized
INFO - 2018-03-28 15:12:06 --> Helper loaded: date_helper
INFO - 2018-03-28 15:12:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:12:06 --> Config Class Initialized
INFO - 2018-03-28 15:12:06 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:12:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:12:06 --> Utf8 Class Initialized
INFO - 2018-03-28 15:12:06 --> URI Class Initialized
INFO - 2018-03-28 15:12:06 --> Router Class Initialized
INFO - 2018-03-28 15:12:06 --> Output Class Initialized
INFO - 2018-03-28 15:12:06 --> Security Class Initialized
DEBUG - 2018-03-28 15:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:12:06 --> Input Class Initialized
INFO - 2018-03-28 15:12:06 --> Language Class Initialized
INFO - 2018-03-28 15:12:06 --> Loader Class Initialized
INFO - 2018-03-28 15:12:06 --> Helper loaded: url_helper
INFO - 2018-03-28 15:12:06 --> Helper loaded: form_helper
INFO - 2018-03-28 15:12:06 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:12:06 --> Controller Class Initialized
INFO - 2018-03-28 15:12:06 --> Model Class Initialized
INFO - 2018-03-28 15:12:06 --> Model Class Initialized
INFO - 2018-03-28 15:12:06 --> Helper loaded: date_helper
INFO - 2018-03-28 15:12:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:12:06 --> Model Class Initialized
INFO - 2018-03-28 20:12:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:12:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:12:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:12:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:12:06 --> Final output sent to browser
DEBUG - 2018-03-28 20:12:06 --> Total execution time: 0.1108
INFO - 2018-03-28 15:12:34 --> Config Class Initialized
INFO - 2018-03-28 15:12:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:12:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:12:34 --> Utf8 Class Initialized
INFO - 2018-03-28 15:12:34 --> URI Class Initialized
INFO - 2018-03-28 15:12:34 --> Router Class Initialized
INFO - 2018-03-28 15:12:34 --> Output Class Initialized
INFO - 2018-03-28 15:12:34 --> Security Class Initialized
DEBUG - 2018-03-28 15:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:12:34 --> Input Class Initialized
INFO - 2018-03-28 15:12:34 --> Language Class Initialized
INFO - 2018-03-28 15:12:34 --> Loader Class Initialized
INFO - 2018-03-28 15:12:34 --> Helper loaded: url_helper
INFO - 2018-03-28 15:12:34 --> Helper loaded: form_helper
INFO - 2018-03-28 15:12:34 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:12:34 --> Controller Class Initialized
INFO - 2018-03-28 15:12:34 --> Model Class Initialized
INFO - 2018-03-28 15:12:34 --> Model Class Initialized
INFO - 2018-03-28 15:12:34 --> Helper loaded: date_helper
INFO - 2018-03-28 15:12:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:12:34 --> Model Class Initialized
INFO - 2018-03-28 20:12:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:12:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:12:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:12:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:12:34 --> Final output sent to browser
DEBUG - 2018-03-28 20:12:34 --> Total execution time: 0.0917
INFO - 2018-03-28 15:12:43 --> Config Class Initialized
INFO - 2018-03-28 15:12:43 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:12:44 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:12:44 --> Utf8 Class Initialized
INFO - 2018-03-28 15:12:44 --> URI Class Initialized
INFO - 2018-03-28 15:12:44 --> Router Class Initialized
INFO - 2018-03-28 15:12:44 --> Output Class Initialized
INFO - 2018-03-28 15:12:44 --> Security Class Initialized
DEBUG - 2018-03-28 15:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:12:44 --> Input Class Initialized
INFO - 2018-03-28 15:12:44 --> Language Class Initialized
INFO - 2018-03-28 15:12:44 --> Loader Class Initialized
INFO - 2018-03-28 15:12:44 --> Helper loaded: url_helper
INFO - 2018-03-28 15:12:44 --> Helper loaded: form_helper
INFO - 2018-03-28 15:12:44 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:12:44 --> Controller Class Initialized
INFO - 2018-03-28 15:12:44 --> Model Class Initialized
INFO - 2018-03-28 15:12:44 --> Model Class Initialized
INFO - 2018-03-28 15:12:44 --> Helper loaded: date_helper
INFO - 2018-03-28 15:12:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:12:44 --> Config Class Initialized
INFO - 2018-03-28 15:12:44 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:12:44 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:12:44 --> Utf8 Class Initialized
INFO - 2018-03-28 15:12:44 --> URI Class Initialized
INFO - 2018-03-28 15:12:44 --> Router Class Initialized
INFO - 2018-03-28 15:12:44 --> Output Class Initialized
INFO - 2018-03-28 15:12:44 --> Security Class Initialized
DEBUG - 2018-03-28 15:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:12:44 --> Input Class Initialized
INFO - 2018-03-28 15:12:44 --> Language Class Initialized
INFO - 2018-03-28 15:12:44 --> Loader Class Initialized
INFO - 2018-03-28 15:12:44 --> Helper loaded: url_helper
INFO - 2018-03-28 15:12:44 --> Helper loaded: form_helper
INFO - 2018-03-28 15:12:44 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:12:44 --> Controller Class Initialized
INFO - 2018-03-28 15:12:44 --> Model Class Initialized
INFO - 2018-03-28 15:12:44 --> Model Class Initialized
INFO - 2018-03-28 15:12:44 --> Helper loaded: date_helper
INFO - 2018-03-28 15:12:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:12:44 --> Model Class Initialized
INFO - 2018-03-28 20:12:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:12:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:12:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:12:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:12:44 --> Final output sent to browser
DEBUG - 2018-03-28 20:12:44 --> Total execution time: 0.1046
INFO - 2018-03-28 15:12:45 --> Config Class Initialized
INFO - 2018-03-28 15:12:45 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:12:45 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:12:45 --> Utf8 Class Initialized
INFO - 2018-03-28 15:12:45 --> URI Class Initialized
INFO - 2018-03-28 15:12:45 --> Router Class Initialized
INFO - 2018-03-28 15:12:45 --> Output Class Initialized
INFO - 2018-03-28 15:12:45 --> Security Class Initialized
DEBUG - 2018-03-28 15:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:12:45 --> Input Class Initialized
INFO - 2018-03-28 15:12:45 --> Language Class Initialized
INFO - 2018-03-28 15:12:45 --> Loader Class Initialized
INFO - 2018-03-28 15:12:45 --> Helper loaded: url_helper
INFO - 2018-03-28 15:12:45 --> Helper loaded: form_helper
INFO - 2018-03-28 15:12:45 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:12:45 --> Controller Class Initialized
INFO - 2018-03-28 15:12:45 --> Model Class Initialized
INFO - 2018-03-28 15:12:45 --> Model Class Initialized
INFO - 2018-03-28 15:12:45 --> Helper loaded: date_helper
INFO - 2018-03-28 15:12:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:12:45 --> Model Class Initialized
INFO - 2018-03-28 20:12:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:12:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:12:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:12:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:12:45 --> Final output sent to browser
DEBUG - 2018-03-28 20:12:45 --> Total execution time: 0.2190
INFO - 2018-03-28 15:13:05 --> Config Class Initialized
INFO - 2018-03-28 15:13:05 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:13:05 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:13:05 --> Utf8 Class Initialized
INFO - 2018-03-28 15:13:05 --> URI Class Initialized
INFO - 2018-03-28 15:13:05 --> Router Class Initialized
INFO - 2018-03-28 15:13:05 --> Output Class Initialized
INFO - 2018-03-28 15:13:05 --> Security Class Initialized
DEBUG - 2018-03-28 15:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:13:05 --> Input Class Initialized
INFO - 2018-03-28 15:13:05 --> Language Class Initialized
INFO - 2018-03-28 15:13:05 --> Loader Class Initialized
INFO - 2018-03-28 15:13:05 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:05 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:05 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:05 --> Controller Class Initialized
INFO - 2018-03-28 15:13:05 --> Model Class Initialized
INFO - 2018-03-28 15:13:05 --> Model Class Initialized
INFO - 2018-03-28 15:13:05 --> Helper loaded: date_helper
INFO - 2018-03-28 15:13:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:13:05 --> Config Class Initialized
INFO - 2018-03-28 15:13:05 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:13:05 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:13:05 --> Utf8 Class Initialized
INFO - 2018-03-28 15:13:05 --> URI Class Initialized
INFO - 2018-03-28 15:13:05 --> Router Class Initialized
INFO - 2018-03-28 15:13:05 --> Output Class Initialized
INFO - 2018-03-28 15:13:05 --> Security Class Initialized
DEBUG - 2018-03-28 15:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:13:05 --> Input Class Initialized
INFO - 2018-03-28 15:13:05 --> Language Class Initialized
INFO - 2018-03-28 15:13:05 --> Loader Class Initialized
INFO - 2018-03-28 15:13:05 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:05 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:05 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:05 --> Controller Class Initialized
INFO - 2018-03-28 15:13:05 --> Model Class Initialized
INFO - 2018-03-28 15:13:05 --> Model Class Initialized
INFO - 2018-03-28 15:13:05 --> Helper loaded: date_helper
INFO - 2018-03-28 15:13:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:13:05 --> Model Class Initialized
INFO - 2018-03-28 20:13:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:13:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:13:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:13:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:13:05 --> Final output sent to browser
DEBUG - 2018-03-28 20:13:05 --> Total execution time: 0.1243
INFO - 2018-03-28 15:13:07 --> Config Class Initialized
INFO - 2018-03-28 15:13:07 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:13:07 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:13:07 --> Utf8 Class Initialized
INFO - 2018-03-28 15:13:07 --> URI Class Initialized
INFO - 2018-03-28 15:13:07 --> Router Class Initialized
INFO - 2018-03-28 15:13:07 --> Output Class Initialized
INFO - 2018-03-28 15:13:07 --> Security Class Initialized
DEBUG - 2018-03-28 15:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:13:07 --> Input Class Initialized
INFO - 2018-03-28 15:13:07 --> Language Class Initialized
INFO - 2018-03-28 15:13:07 --> Loader Class Initialized
INFO - 2018-03-28 15:13:07 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:07 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:07 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:07 --> Controller Class Initialized
INFO - 2018-03-28 15:13:07 --> Model Class Initialized
INFO - 2018-03-28 15:13:07 --> Model Class Initialized
INFO - 2018-03-28 15:13:07 --> Helper loaded: date_helper
INFO - 2018-03-28 15:13:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:13:07 --> Model Class Initialized
INFO - 2018-03-28 20:13:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:13:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:13:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:13:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:13:07 --> Final output sent to browser
DEBUG - 2018-03-28 20:13:07 --> Total execution time: 0.2208
INFO - 2018-03-28 15:13:20 --> Config Class Initialized
INFO - 2018-03-28 15:13:20 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:13:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:13:20 --> Utf8 Class Initialized
INFO - 2018-03-28 15:13:20 --> URI Class Initialized
INFO - 2018-03-28 15:13:20 --> Router Class Initialized
INFO - 2018-03-28 15:13:20 --> Output Class Initialized
INFO - 2018-03-28 15:13:20 --> Security Class Initialized
DEBUG - 2018-03-28 15:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:13:20 --> Input Class Initialized
INFO - 2018-03-28 15:13:20 --> Language Class Initialized
INFO - 2018-03-28 15:13:20 --> Loader Class Initialized
INFO - 2018-03-28 15:13:20 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:20 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:20 --> Controller Class Initialized
INFO - 2018-03-28 15:13:20 --> Model Class Initialized
INFO - 2018-03-28 15:13:20 --> Model Class Initialized
INFO - 2018-03-28 15:13:20 --> Helper loaded: date_helper
INFO - 2018-03-28 15:13:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:13:20 --> Config Class Initialized
INFO - 2018-03-28 15:13:20 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:13:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:13:20 --> Utf8 Class Initialized
INFO - 2018-03-28 15:13:20 --> URI Class Initialized
INFO - 2018-03-28 15:13:20 --> Router Class Initialized
INFO - 2018-03-28 15:13:20 --> Output Class Initialized
INFO - 2018-03-28 15:13:20 --> Security Class Initialized
DEBUG - 2018-03-28 15:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:13:20 --> Input Class Initialized
INFO - 2018-03-28 15:13:20 --> Language Class Initialized
INFO - 2018-03-28 15:13:20 --> Loader Class Initialized
INFO - 2018-03-28 15:13:20 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:20 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:20 --> Controller Class Initialized
INFO - 2018-03-28 15:13:20 --> Model Class Initialized
INFO - 2018-03-28 15:13:20 --> Model Class Initialized
INFO - 2018-03-28 15:13:20 --> Helper loaded: date_helper
INFO - 2018-03-28 15:13:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:13:20 --> Model Class Initialized
INFO - 2018-03-28 20:13:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:13:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:13:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:13:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:13:20 --> Final output sent to browser
DEBUG - 2018-03-28 20:13:20 --> Total execution time: 0.1142
INFO - 2018-03-28 15:13:21 --> Config Class Initialized
INFO - 2018-03-28 15:13:21 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:13:21 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:13:21 --> Utf8 Class Initialized
INFO - 2018-03-28 15:13:21 --> URI Class Initialized
INFO - 2018-03-28 15:13:21 --> Router Class Initialized
INFO - 2018-03-28 15:13:22 --> Output Class Initialized
INFO - 2018-03-28 15:13:22 --> Security Class Initialized
DEBUG - 2018-03-28 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:13:22 --> Input Class Initialized
INFO - 2018-03-28 15:13:22 --> Language Class Initialized
INFO - 2018-03-28 15:13:22 --> Loader Class Initialized
INFO - 2018-03-28 15:13:22 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:22 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:22 --> Controller Class Initialized
INFO - 2018-03-28 15:13:22 --> Model Class Initialized
INFO - 2018-03-28 15:13:22 --> Model Class Initialized
INFO - 2018-03-28 15:13:22 --> Helper loaded: date_helper
INFO - 2018-03-28 15:13:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:13:22 --> Model Class Initialized
INFO - 2018-03-28 20:13:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:13:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:13:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:13:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:13:22 --> Final output sent to browser
DEBUG - 2018-03-28 20:13:22 --> Total execution time: 0.2170
INFO - 2018-03-28 15:13:37 --> Config Class Initialized
INFO - 2018-03-28 15:13:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:13:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:13:37 --> Utf8 Class Initialized
INFO - 2018-03-28 15:13:37 --> URI Class Initialized
INFO - 2018-03-28 15:13:37 --> Router Class Initialized
INFO - 2018-03-28 15:13:37 --> Output Class Initialized
INFO - 2018-03-28 15:13:37 --> Security Class Initialized
DEBUG - 2018-03-28 15:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:13:37 --> Input Class Initialized
INFO - 2018-03-28 15:13:37 --> Language Class Initialized
INFO - 2018-03-28 15:13:37 --> Loader Class Initialized
INFO - 2018-03-28 15:13:37 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:37 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:37 --> Controller Class Initialized
INFO - 2018-03-28 15:13:37 --> Model Class Initialized
INFO - 2018-03-28 15:13:37 --> Model Class Initialized
INFO - 2018-03-28 15:13:37 --> Helper loaded: date_helper
INFO - 2018-03-28 15:13:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:13:38 --> Config Class Initialized
INFO - 2018-03-28 15:13:38 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:13:38 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:13:38 --> Utf8 Class Initialized
INFO - 2018-03-28 15:13:38 --> URI Class Initialized
INFO - 2018-03-28 15:13:38 --> Router Class Initialized
INFO - 2018-03-28 15:13:38 --> Output Class Initialized
INFO - 2018-03-28 15:13:38 --> Security Class Initialized
DEBUG - 2018-03-28 15:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:13:38 --> Input Class Initialized
INFO - 2018-03-28 15:13:38 --> Language Class Initialized
INFO - 2018-03-28 15:13:38 --> Loader Class Initialized
INFO - 2018-03-28 15:13:38 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:38 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:38 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:38 --> Controller Class Initialized
INFO - 2018-03-28 15:13:38 --> Model Class Initialized
INFO - 2018-03-28 15:13:38 --> Model Class Initialized
INFO - 2018-03-28 15:13:38 --> Helper loaded: date_helper
INFO - 2018-03-28 15:13:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:13:38 --> Model Class Initialized
INFO - 2018-03-28 20:13:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:13:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:13:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:13:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:13:38 --> Final output sent to browser
DEBUG - 2018-03-28 20:13:38 --> Total execution time: 0.1295
INFO - 2018-03-28 15:13:39 --> Config Class Initialized
INFO - 2018-03-28 15:13:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:13:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:13:39 --> Utf8 Class Initialized
INFO - 2018-03-28 15:13:39 --> URI Class Initialized
INFO - 2018-03-28 15:13:39 --> Router Class Initialized
INFO - 2018-03-28 15:13:39 --> Output Class Initialized
INFO - 2018-03-28 15:13:39 --> Security Class Initialized
DEBUG - 2018-03-28 15:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:13:39 --> Input Class Initialized
INFO - 2018-03-28 15:13:39 --> Language Class Initialized
INFO - 2018-03-28 15:13:39 --> Loader Class Initialized
INFO - 2018-03-28 15:13:39 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:39 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:39 --> Controller Class Initialized
INFO - 2018-03-28 15:13:39 --> Model Class Initialized
INFO - 2018-03-28 15:13:39 --> Model Class Initialized
INFO - 2018-03-28 15:13:39 --> Helper loaded: date_helper
INFO - 2018-03-28 15:13:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:13:39 --> Model Class Initialized
INFO - 2018-03-28 20:13:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:13:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:13:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:13:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:13:39 --> Final output sent to browser
DEBUG - 2018-03-28 20:13:39 --> Total execution time: 0.1968
INFO - 2018-03-28 15:13:58 --> Config Class Initialized
INFO - 2018-03-28 15:13:58 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:13:58 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:13:58 --> Utf8 Class Initialized
INFO - 2018-03-28 15:13:58 --> URI Class Initialized
INFO - 2018-03-28 15:13:58 --> Router Class Initialized
INFO - 2018-03-28 15:13:58 --> Output Class Initialized
INFO - 2018-03-28 15:13:58 --> Security Class Initialized
DEBUG - 2018-03-28 15:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:13:58 --> Input Class Initialized
INFO - 2018-03-28 15:13:58 --> Language Class Initialized
INFO - 2018-03-28 15:13:58 --> Loader Class Initialized
INFO - 2018-03-28 15:13:58 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:58 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:58 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:58 --> Controller Class Initialized
INFO - 2018-03-28 15:13:58 --> Model Class Initialized
INFO - 2018-03-28 15:13:58 --> Model Class Initialized
INFO - 2018-03-28 15:13:58 --> Helper loaded: date_helper
INFO - 2018-03-28 15:13:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:13:58 --> Config Class Initialized
INFO - 2018-03-28 15:13:58 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:13:58 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:13:58 --> Utf8 Class Initialized
INFO - 2018-03-28 15:13:58 --> URI Class Initialized
INFO - 2018-03-28 15:13:58 --> Router Class Initialized
INFO - 2018-03-28 15:13:58 --> Output Class Initialized
INFO - 2018-03-28 15:13:58 --> Security Class Initialized
DEBUG - 2018-03-28 15:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:13:58 --> Input Class Initialized
INFO - 2018-03-28 15:13:58 --> Language Class Initialized
INFO - 2018-03-28 15:13:58 --> Loader Class Initialized
INFO - 2018-03-28 15:13:58 --> Helper loaded: url_helper
INFO - 2018-03-28 15:13:58 --> Helper loaded: form_helper
INFO - 2018-03-28 15:13:58 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:13:58 --> Controller Class Initialized
INFO - 2018-03-28 15:13:58 --> Model Class Initialized
INFO - 2018-03-28 15:13:58 --> Model Class Initialized
INFO - 2018-03-28 15:13:58 --> Helper loaded: date_helper
INFO - 2018-03-28 15:13:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:13:58 --> Model Class Initialized
INFO - 2018-03-28 20:13:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:13:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:13:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:13:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:13:58 --> Final output sent to browser
DEBUG - 2018-03-28 20:13:58 --> Total execution time: 0.1133
INFO - 2018-03-28 15:14:00 --> Config Class Initialized
INFO - 2018-03-28 15:14:00 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:14:00 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:14:00 --> Utf8 Class Initialized
INFO - 2018-03-28 15:14:00 --> URI Class Initialized
INFO - 2018-03-28 15:14:00 --> Router Class Initialized
INFO - 2018-03-28 15:14:00 --> Output Class Initialized
INFO - 2018-03-28 15:14:00 --> Security Class Initialized
DEBUG - 2018-03-28 15:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:14:00 --> Input Class Initialized
INFO - 2018-03-28 15:14:00 --> Language Class Initialized
INFO - 2018-03-28 15:14:00 --> Loader Class Initialized
INFO - 2018-03-28 15:14:00 --> Helper loaded: url_helper
INFO - 2018-03-28 15:14:00 --> Helper loaded: form_helper
INFO - 2018-03-28 15:14:00 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:14:00 --> Controller Class Initialized
INFO - 2018-03-28 15:14:00 --> Model Class Initialized
INFO - 2018-03-28 15:14:00 --> Model Class Initialized
INFO - 2018-03-28 15:14:00 --> Helper loaded: date_helper
INFO - 2018-03-28 15:14:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:14:00 --> Model Class Initialized
INFO - 2018-03-28 20:14:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:14:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:14:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:14:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:14:00 --> Final output sent to browser
DEBUG - 2018-03-28 20:14:00 --> Total execution time: 0.1965
INFO - 2018-03-28 15:14:15 --> Config Class Initialized
INFO - 2018-03-28 15:14:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:14:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:14:15 --> Utf8 Class Initialized
INFO - 2018-03-28 15:14:15 --> URI Class Initialized
INFO - 2018-03-28 15:14:15 --> Router Class Initialized
INFO - 2018-03-28 15:14:15 --> Output Class Initialized
INFO - 2018-03-28 15:14:15 --> Security Class Initialized
DEBUG - 2018-03-28 15:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:14:15 --> Input Class Initialized
INFO - 2018-03-28 15:14:15 --> Language Class Initialized
INFO - 2018-03-28 15:14:15 --> Loader Class Initialized
INFO - 2018-03-28 15:14:15 --> Helper loaded: url_helper
INFO - 2018-03-28 15:14:15 --> Helper loaded: form_helper
INFO - 2018-03-28 15:14:15 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:14:15 --> Controller Class Initialized
INFO - 2018-03-28 15:14:15 --> Model Class Initialized
INFO - 2018-03-28 15:14:15 --> Model Class Initialized
INFO - 2018-03-28 15:14:15 --> Helper loaded: date_helper
INFO - 2018-03-28 15:14:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:14:15 --> Config Class Initialized
INFO - 2018-03-28 15:14:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:14:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:14:15 --> Utf8 Class Initialized
INFO - 2018-03-28 15:14:15 --> URI Class Initialized
INFO - 2018-03-28 15:14:15 --> Router Class Initialized
INFO - 2018-03-28 15:14:15 --> Output Class Initialized
INFO - 2018-03-28 15:14:15 --> Security Class Initialized
DEBUG - 2018-03-28 15:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:14:15 --> Input Class Initialized
INFO - 2018-03-28 15:14:15 --> Language Class Initialized
INFO - 2018-03-28 15:14:15 --> Loader Class Initialized
INFO - 2018-03-28 15:14:15 --> Helper loaded: url_helper
INFO - 2018-03-28 15:14:15 --> Helper loaded: form_helper
INFO - 2018-03-28 15:14:15 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:14:16 --> Controller Class Initialized
INFO - 2018-03-28 15:14:16 --> Model Class Initialized
INFO - 2018-03-28 15:14:16 --> Model Class Initialized
INFO - 2018-03-28 15:14:16 --> Helper loaded: date_helper
INFO - 2018-03-28 15:14:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:14:16 --> Model Class Initialized
INFO - 2018-03-28 20:14:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:14:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:14:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:14:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:14:16 --> Final output sent to browser
DEBUG - 2018-03-28 20:14:16 --> Total execution time: 0.1171
INFO - 2018-03-28 15:14:18 --> Config Class Initialized
INFO - 2018-03-28 15:14:18 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:14:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:14:18 --> Utf8 Class Initialized
INFO - 2018-03-28 15:14:18 --> URI Class Initialized
INFO - 2018-03-28 15:14:18 --> Router Class Initialized
INFO - 2018-03-28 15:14:18 --> Output Class Initialized
INFO - 2018-03-28 15:14:18 --> Security Class Initialized
DEBUG - 2018-03-28 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:14:18 --> Input Class Initialized
INFO - 2018-03-28 15:14:18 --> Language Class Initialized
INFO - 2018-03-28 15:14:18 --> Loader Class Initialized
INFO - 2018-03-28 15:14:18 --> Helper loaded: url_helper
INFO - 2018-03-28 15:14:18 --> Helper loaded: form_helper
INFO - 2018-03-28 15:14:18 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:14:18 --> Controller Class Initialized
INFO - 2018-03-28 15:14:18 --> Model Class Initialized
INFO - 2018-03-28 15:14:18 --> Model Class Initialized
INFO - 2018-03-28 15:14:18 --> Helper loaded: date_helper
INFO - 2018-03-28 15:14:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:14:18 --> Model Class Initialized
INFO - 2018-03-28 20:14:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:14:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:14:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:14:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:14:18 --> Final output sent to browser
DEBUG - 2018-03-28 20:14:18 --> Total execution time: 0.1178
INFO - 2018-03-28 15:14:40 --> Config Class Initialized
INFO - 2018-03-28 15:14:40 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:14:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:14:40 --> Utf8 Class Initialized
INFO - 2018-03-28 15:14:40 --> URI Class Initialized
INFO - 2018-03-28 15:14:40 --> Router Class Initialized
INFO - 2018-03-28 15:14:40 --> Output Class Initialized
INFO - 2018-03-28 15:14:40 --> Security Class Initialized
DEBUG - 2018-03-28 15:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:14:40 --> Input Class Initialized
INFO - 2018-03-28 15:14:40 --> Language Class Initialized
INFO - 2018-03-28 15:14:40 --> Loader Class Initialized
INFO - 2018-03-28 15:14:40 --> Helper loaded: url_helper
INFO - 2018-03-28 15:14:40 --> Helper loaded: form_helper
INFO - 2018-03-28 15:14:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:14:40 --> Controller Class Initialized
INFO - 2018-03-28 15:14:40 --> Model Class Initialized
INFO - 2018-03-28 15:14:40 --> Model Class Initialized
INFO - 2018-03-28 15:14:40 --> Helper loaded: date_helper
INFO - 2018-03-28 15:14:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:14:40 --> Config Class Initialized
INFO - 2018-03-28 15:14:40 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:14:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:14:40 --> Utf8 Class Initialized
INFO - 2018-03-28 15:14:40 --> URI Class Initialized
INFO - 2018-03-28 15:14:40 --> Router Class Initialized
INFO - 2018-03-28 15:14:40 --> Output Class Initialized
INFO - 2018-03-28 15:14:40 --> Security Class Initialized
DEBUG - 2018-03-28 15:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:14:40 --> Input Class Initialized
INFO - 2018-03-28 15:14:40 --> Language Class Initialized
INFO - 2018-03-28 15:14:40 --> Loader Class Initialized
INFO - 2018-03-28 15:14:40 --> Helper loaded: url_helper
INFO - 2018-03-28 15:14:40 --> Helper loaded: form_helper
INFO - 2018-03-28 15:14:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:14:40 --> Controller Class Initialized
INFO - 2018-03-28 15:14:40 --> Model Class Initialized
INFO - 2018-03-28 15:14:40 --> Model Class Initialized
INFO - 2018-03-28 15:14:40 --> Helper loaded: date_helper
INFO - 2018-03-28 15:14:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:14:40 --> Model Class Initialized
INFO - 2018-03-28 20:14:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:14:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:14:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:14:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:14:40 --> Final output sent to browser
DEBUG - 2018-03-28 20:14:40 --> Total execution time: 0.1347
INFO - 2018-03-28 15:14:42 --> Config Class Initialized
INFO - 2018-03-28 15:14:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:14:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:14:42 --> Utf8 Class Initialized
INFO - 2018-03-28 15:14:42 --> URI Class Initialized
INFO - 2018-03-28 15:14:42 --> Router Class Initialized
INFO - 2018-03-28 15:14:42 --> Output Class Initialized
INFO - 2018-03-28 15:14:42 --> Security Class Initialized
DEBUG - 2018-03-28 15:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:14:42 --> Input Class Initialized
INFO - 2018-03-28 15:14:42 --> Language Class Initialized
INFO - 2018-03-28 15:14:42 --> Loader Class Initialized
INFO - 2018-03-28 15:14:42 --> Helper loaded: url_helper
INFO - 2018-03-28 15:14:42 --> Helper loaded: form_helper
INFO - 2018-03-28 15:14:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:14:42 --> Controller Class Initialized
INFO - 2018-03-28 15:14:42 --> Model Class Initialized
INFO - 2018-03-28 15:14:42 --> Model Class Initialized
INFO - 2018-03-28 15:14:42 --> Helper loaded: date_helper
INFO - 2018-03-28 15:14:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:14:42 --> Model Class Initialized
INFO - 2018-03-28 20:14:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:14:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:14:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/create.php
INFO - 2018-03-28 20:14:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:14:42 --> Final output sent to browser
DEBUG - 2018-03-28 20:14:42 --> Total execution time: 0.1473
INFO - 2018-03-28 15:15:02 --> Config Class Initialized
INFO - 2018-03-28 15:15:02 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:02 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:02 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:02 --> URI Class Initialized
INFO - 2018-03-28 15:15:02 --> Router Class Initialized
INFO - 2018-03-28 15:15:02 --> Output Class Initialized
INFO - 2018-03-28 15:15:02 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:02 --> Input Class Initialized
INFO - 2018-03-28 15:15:02 --> Language Class Initialized
INFO - 2018-03-28 15:15:02 --> Loader Class Initialized
INFO - 2018-03-28 15:15:02 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:02 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:02 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:02 --> Controller Class Initialized
INFO - 2018-03-28 15:15:02 --> Model Class Initialized
INFO - 2018-03-28 15:15:02 --> Model Class Initialized
INFO - 2018-03-28 15:15:02 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:15:02 --> Config Class Initialized
INFO - 2018-03-28 15:15:02 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:02 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:02 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:02 --> URI Class Initialized
INFO - 2018-03-28 15:15:02 --> Router Class Initialized
INFO - 2018-03-28 15:15:02 --> Output Class Initialized
INFO - 2018-03-28 15:15:02 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:02 --> Input Class Initialized
INFO - 2018-03-28 15:15:02 --> Language Class Initialized
INFO - 2018-03-28 15:15:02 --> Loader Class Initialized
INFO - 2018-03-28 15:15:02 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:02 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:02 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:02 --> Controller Class Initialized
INFO - 2018-03-28 15:15:02 --> Model Class Initialized
INFO - 2018-03-28 15:15:02 --> Model Class Initialized
INFO - 2018-03-28 15:15:02 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:15:02 --> Model Class Initialized
INFO - 2018-03-28 20:15:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:15:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:15:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:15:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:15:02 --> Final output sent to browser
DEBUG - 2018-03-28 20:15:02 --> Total execution time: 0.1351
INFO - 2018-03-28 15:15:10 --> Config Class Initialized
INFO - 2018-03-28 15:15:10 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:10 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:10 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:10 --> URI Class Initialized
INFO - 2018-03-28 15:15:10 --> Router Class Initialized
INFO - 2018-03-28 15:15:10 --> Output Class Initialized
INFO - 2018-03-28 15:15:10 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:10 --> Input Class Initialized
INFO - 2018-03-28 15:15:10 --> Language Class Initialized
INFO - 2018-03-28 15:15:10 --> Loader Class Initialized
INFO - 2018-03-28 15:15:10 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:10 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:10 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:10 --> Controller Class Initialized
INFO - 2018-03-28 15:15:10 --> Model Class Initialized
INFO - 2018-03-28 15:15:10 --> Model Class Initialized
INFO - 2018-03-28 15:15:10 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:10 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:15:11 --> Config Class Initialized
INFO - 2018-03-28 15:15:11 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:11 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:11 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:11 --> URI Class Initialized
INFO - 2018-03-28 15:15:11 --> Router Class Initialized
INFO - 2018-03-28 15:15:11 --> Output Class Initialized
INFO - 2018-03-28 15:15:11 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:11 --> Input Class Initialized
INFO - 2018-03-28 15:15:11 --> Language Class Initialized
INFO - 2018-03-28 15:15:11 --> Loader Class Initialized
INFO - 2018-03-28 15:15:11 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:11 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:11 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:11 --> Controller Class Initialized
INFO - 2018-03-28 15:15:11 --> Model Class Initialized
INFO - 2018-03-28 15:15:11 --> Model Class Initialized
INFO - 2018-03-28 15:15:11 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:15:11 --> Model Class Initialized
INFO - 2018-03-28 20:15:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:15:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:15:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:15:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:15:11 --> Final output sent to browser
DEBUG - 2018-03-28 20:15:11 --> Total execution time: 0.1049
INFO - 2018-03-28 15:15:14 --> Config Class Initialized
INFO - 2018-03-28 15:15:14 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:14 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:14 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:14 --> URI Class Initialized
INFO - 2018-03-28 15:15:14 --> Router Class Initialized
INFO - 2018-03-28 15:15:14 --> Output Class Initialized
INFO - 2018-03-28 15:15:14 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:14 --> Input Class Initialized
INFO - 2018-03-28 15:15:14 --> Language Class Initialized
INFO - 2018-03-28 15:15:14 --> Loader Class Initialized
INFO - 2018-03-28 15:15:14 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:14 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:14 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:14 --> Controller Class Initialized
INFO - 2018-03-28 15:15:14 --> Model Class Initialized
INFO - 2018-03-28 15:15:14 --> Model Class Initialized
INFO - 2018-03-28 15:15:15 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:15:15 --> Config Class Initialized
INFO - 2018-03-28 15:15:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:15 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:15 --> URI Class Initialized
INFO - 2018-03-28 15:15:15 --> Router Class Initialized
INFO - 2018-03-28 15:15:15 --> Output Class Initialized
INFO - 2018-03-28 15:15:15 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:15 --> Input Class Initialized
INFO - 2018-03-28 15:15:15 --> Language Class Initialized
INFO - 2018-03-28 15:15:15 --> Loader Class Initialized
INFO - 2018-03-28 15:15:15 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:15 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:15 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:15 --> Controller Class Initialized
INFO - 2018-03-28 15:15:15 --> Model Class Initialized
INFO - 2018-03-28 15:15:15 --> Model Class Initialized
INFO - 2018-03-28 15:15:15 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:15:15 --> Model Class Initialized
INFO - 2018-03-28 20:15:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:15:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:15:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:15:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:15:15 --> Final output sent to browser
DEBUG - 2018-03-28 20:15:15 --> Total execution time: 0.1262
INFO - 2018-03-28 15:15:18 --> Config Class Initialized
INFO - 2018-03-28 15:15:18 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:18 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:18 --> URI Class Initialized
INFO - 2018-03-28 15:15:18 --> Router Class Initialized
INFO - 2018-03-28 15:15:18 --> Output Class Initialized
INFO - 2018-03-28 15:15:18 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:18 --> Input Class Initialized
INFO - 2018-03-28 15:15:18 --> Language Class Initialized
INFO - 2018-03-28 15:15:18 --> Loader Class Initialized
INFO - 2018-03-28 15:15:18 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:18 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:18 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:18 --> Controller Class Initialized
INFO - 2018-03-28 15:15:18 --> Model Class Initialized
INFO - 2018-03-28 15:15:18 --> Model Class Initialized
INFO - 2018-03-28 15:15:18 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:15:18 --> Config Class Initialized
INFO - 2018-03-28 15:15:18 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:18 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:18 --> URI Class Initialized
INFO - 2018-03-28 15:15:18 --> Router Class Initialized
INFO - 2018-03-28 15:15:18 --> Output Class Initialized
INFO - 2018-03-28 15:15:18 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:18 --> Input Class Initialized
INFO - 2018-03-28 15:15:18 --> Language Class Initialized
INFO - 2018-03-28 15:15:18 --> Loader Class Initialized
INFO - 2018-03-28 15:15:18 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:18 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:18 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:18 --> Controller Class Initialized
INFO - 2018-03-28 15:15:18 --> Model Class Initialized
INFO - 2018-03-28 15:15:18 --> Model Class Initialized
INFO - 2018-03-28 15:15:18 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:15:18 --> Model Class Initialized
INFO - 2018-03-28 20:15:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:15:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:15:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:15:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:15:18 --> Final output sent to browser
DEBUG - 2018-03-28 20:15:18 --> Total execution time: 0.1093
INFO - 2018-03-28 15:15:21 --> Config Class Initialized
INFO - 2018-03-28 15:15:21 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:21 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:21 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:21 --> URI Class Initialized
INFO - 2018-03-28 15:15:21 --> Router Class Initialized
INFO - 2018-03-28 15:15:21 --> Output Class Initialized
INFO - 2018-03-28 15:15:21 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:21 --> Input Class Initialized
INFO - 2018-03-28 15:15:21 --> Language Class Initialized
INFO - 2018-03-28 15:15:21 --> Loader Class Initialized
INFO - 2018-03-28 15:15:21 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:21 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:21 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:21 --> Controller Class Initialized
INFO - 2018-03-28 15:15:21 --> Model Class Initialized
INFO - 2018-03-28 15:15:21 --> Model Class Initialized
INFO - 2018-03-28 15:15:21 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:15:21 --> Config Class Initialized
INFO - 2018-03-28 15:15:21 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:21 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:21 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:21 --> URI Class Initialized
INFO - 2018-03-28 15:15:21 --> Router Class Initialized
INFO - 2018-03-28 15:15:21 --> Output Class Initialized
INFO - 2018-03-28 15:15:21 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:21 --> Input Class Initialized
INFO - 2018-03-28 15:15:21 --> Language Class Initialized
INFO - 2018-03-28 15:15:21 --> Loader Class Initialized
INFO - 2018-03-28 15:15:21 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:21 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:21 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:21 --> Controller Class Initialized
INFO - 2018-03-28 15:15:21 --> Model Class Initialized
INFO - 2018-03-28 15:15:21 --> Model Class Initialized
INFO - 2018-03-28 15:15:21 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:15:21 --> Model Class Initialized
INFO - 2018-03-28 20:15:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:15:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:15:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:15:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:15:21 --> Final output sent to browser
DEBUG - 2018-03-28 20:15:21 --> Total execution time: 0.1276
INFO - 2018-03-28 15:15:24 --> Config Class Initialized
INFO - 2018-03-28 15:15:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:24 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:24 --> URI Class Initialized
INFO - 2018-03-28 15:15:24 --> Router Class Initialized
INFO - 2018-03-28 15:15:24 --> Output Class Initialized
INFO - 2018-03-28 15:15:24 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:24 --> Input Class Initialized
INFO - 2018-03-28 15:15:24 --> Language Class Initialized
INFO - 2018-03-28 15:15:24 --> Loader Class Initialized
INFO - 2018-03-28 15:15:24 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:24 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:24 --> Controller Class Initialized
INFO - 2018-03-28 15:15:24 --> Model Class Initialized
INFO - 2018-03-28 15:15:24 --> Model Class Initialized
INFO - 2018-03-28 15:15:24 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:15:24 --> Config Class Initialized
INFO - 2018-03-28 15:15:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:24 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:24 --> URI Class Initialized
INFO - 2018-03-28 15:15:24 --> Router Class Initialized
INFO - 2018-03-28 15:15:24 --> Output Class Initialized
INFO - 2018-03-28 15:15:24 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:24 --> Input Class Initialized
INFO - 2018-03-28 15:15:24 --> Language Class Initialized
INFO - 2018-03-28 15:15:24 --> Loader Class Initialized
INFO - 2018-03-28 15:15:24 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:24 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:24 --> Controller Class Initialized
INFO - 2018-03-28 15:15:24 --> Model Class Initialized
INFO - 2018-03-28 15:15:24 --> Model Class Initialized
INFO - 2018-03-28 15:15:24 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:15:24 --> Model Class Initialized
INFO - 2018-03-28 20:15:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:15:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:15:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:15:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:15:24 --> Final output sent to browser
DEBUG - 2018-03-28 20:15:24 --> Total execution time: 0.1007
INFO - 2018-03-28 15:15:27 --> Config Class Initialized
INFO - 2018-03-28 15:15:27 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:27 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:27 --> URI Class Initialized
INFO - 2018-03-28 15:15:27 --> Router Class Initialized
INFO - 2018-03-28 15:15:27 --> Output Class Initialized
INFO - 2018-03-28 15:15:27 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:27 --> Input Class Initialized
INFO - 2018-03-28 15:15:27 --> Language Class Initialized
INFO - 2018-03-28 15:15:27 --> Loader Class Initialized
INFO - 2018-03-28 15:15:27 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:27 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:27 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:27 --> Controller Class Initialized
INFO - 2018-03-28 15:15:27 --> Model Class Initialized
INFO - 2018-03-28 15:15:27 --> Model Class Initialized
INFO - 2018-03-28 15:15:27 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:15:27 --> Config Class Initialized
INFO - 2018-03-28 15:15:27 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:27 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:27 --> URI Class Initialized
INFO - 2018-03-28 15:15:27 --> Router Class Initialized
INFO - 2018-03-28 15:15:27 --> Output Class Initialized
INFO - 2018-03-28 15:15:27 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:27 --> Input Class Initialized
INFO - 2018-03-28 15:15:27 --> Language Class Initialized
INFO - 2018-03-28 15:15:27 --> Loader Class Initialized
INFO - 2018-03-28 15:15:27 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:27 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:27 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:27 --> Controller Class Initialized
INFO - 2018-03-28 15:15:27 --> Model Class Initialized
INFO - 2018-03-28 15:15:27 --> Model Class Initialized
INFO - 2018-03-28 15:15:27 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:15:27 --> Model Class Initialized
INFO - 2018-03-28 20:15:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:15:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:15:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:15:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:15:27 --> Final output sent to browser
DEBUG - 2018-03-28 20:15:27 --> Total execution time: 0.1327
INFO - 2018-03-28 15:15:30 --> Config Class Initialized
INFO - 2018-03-28 15:15:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:30 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:30 --> URI Class Initialized
INFO - 2018-03-28 15:15:30 --> Router Class Initialized
INFO - 2018-03-28 15:15:30 --> Output Class Initialized
INFO - 2018-03-28 15:15:30 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:30 --> Input Class Initialized
INFO - 2018-03-28 15:15:30 --> Language Class Initialized
INFO - 2018-03-28 15:15:30 --> Loader Class Initialized
INFO - 2018-03-28 15:15:30 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:30 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:30 --> Controller Class Initialized
INFO - 2018-03-28 15:15:30 --> Model Class Initialized
INFO - 2018-03-28 15:15:30 --> Model Class Initialized
INFO - 2018-03-28 15:15:30 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:15:30 --> Config Class Initialized
INFO - 2018-03-28 15:15:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:30 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:30 --> URI Class Initialized
INFO - 2018-03-28 15:15:30 --> Router Class Initialized
INFO - 2018-03-28 15:15:30 --> Output Class Initialized
INFO - 2018-03-28 15:15:30 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:30 --> Input Class Initialized
INFO - 2018-03-28 15:15:30 --> Language Class Initialized
INFO - 2018-03-28 15:15:30 --> Loader Class Initialized
INFO - 2018-03-28 15:15:30 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:30 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:30 --> Controller Class Initialized
INFO - 2018-03-28 15:15:30 --> Model Class Initialized
INFO - 2018-03-28 15:15:30 --> Model Class Initialized
INFO - 2018-03-28 15:15:30 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:15:30 --> Model Class Initialized
INFO - 2018-03-28 20:15:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:15:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:15:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:15:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:15:30 --> Final output sent to browser
DEBUG - 2018-03-28 20:15:30 --> Total execution time: 0.1392
INFO - 2018-03-28 15:15:33 --> Config Class Initialized
INFO - 2018-03-28 15:15:33 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:33 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:33 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:33 --> URI Class Initialized
INFO - 2018-03-28 15:15:33 --> Router Class Initialized
INFO - 2018-03-28 15:15:33 --> Output Class Initialized
INFO - 2018-03-28 15:15:33 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:33 --> Input Class Initialized
INFO - 2018-03-28 15:15:33 --> Language Class Initialized
INFO - 2018-03-28 15:15:33 --> Loader Class Initialized
INFO - 2018-03-28 15:15:33 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:33 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:33 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:33 --> Controller Class Initialized
INFO - 2018-03-28 15:15:33 --> Model Class Initialized
INFO - 2018-03-28 15:15:33 --> Model Class Initialized
INFO - 2018-03-28 15:15:33 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:15:33 --> Config Class Initialized
INFO - 2018-03-28 15:15:33 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:33 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:33 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:33 --> URI Class Initialized
INFO - 2018-03-28 15:15:33 --> Router Class Initialized
INFO - 2018-03-28 15:15:33 --> Output Class Initialized
INFO - 2018-03-28 15:15:33 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:33 --> Input Class Initialized
INFO - 2018-03-28 15:15:33 --> Language Class Initialized
INFO - 2018-03-28 15:15:33 --> Loader Class Initialized
INFO - 2018-03-28 15:15:33 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:33 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:33 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:33 --> Controller Class Initialized
INFO - 2018-03-28 15:15:33 --> Model Class Initialized
INFO - 2018-03-28 15:15:33 --> Model Class Initialized
INFO - 2018-03-28 15:15:33 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:15:33 --> Model Class Initialized
INFO - 2018-03-28 20:15:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:15:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:15:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:15:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:15:33 --> Final output sent to browser
DEBUG - 2018-03-28 20:15:33 --> Total execution time: 0.1364
INFO - 2018-03-28 15:15:36 --> Config Class Initialized
INFO - 2018-03-28 15:15:36 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:36 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:36 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:36 --> URI Class Initialized
INFO - 2018-03-28 15:15:36 --> Router Class Initialized
INFO - 2018-03-28 15:15:36 --> Output Class Initialized
INFO - 2018-03-28 15:15:36 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:36 --> Input Class Initialized
INFO - 2018-03-28 15:15:36 --> Language Class Initialized
INFO - 2018-03-28 15:15:36 --> Loader Class Initialized
INFO - 2018-03-28 15:15:36 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:36 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:36 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:36 --> Controller Class Initialized
INFO - 2018-03-28 15:15:36 --> Model Class Initialized
INFO - 2018-03-28 15:15:36 --> Model Class Initialized
INFO - 2018-03-28 15:15:36 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:15:37 --> Config Class Initialized
INFO - 2018-03-28 15:15:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:37 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:37 --> URI Class Initialized
INFO - 2018-03-28 15:15:37 --> Router Class Initialized
INFO - 2018-03-28 15:15:37 --> Output Class Initialized
INFO - 2018-03-28 15:15:37 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:37 --> Input Class Initialized
INFO - 2018-03-28 15:15:37 --> Language Class Initialized
INFO - 2018-03-28 15:15:37 --> Loader Class Initialized
INFO - 2018-03-28 15:15:37 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:37 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:37 --> Controller Class Initialized
INFO - 2018-03-28 15:15:37 --> Model Class Initialized
INFO - 2018-03-28 15:15:37 --> Model Class Initialized
INFO - 2018-03-28 15:15:37 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:15:37 --> Model Class Initialized
INFO - 2018-03-28 20:15:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:15:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:15:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:15:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:15:37 --> Final output sent to browser
DEBUG - 2018-03-28 20:15:37 --> Total execution time: 0.0916
INFO - 2018-03-28 15:15:39 --> Config Class Initialized
INFO - 2018-03-28 15:15:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:39 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:39 --> URI Class Initialized
INFO - 2018-03-28 15:15:39 --> Router Class Initialized
INFO - 2018-03-28 15:15:39 --> Output Class Initialized
INFO - 2018-03-28 15:15:39 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:39 --> Input Class Initialized
INFO - 2018-03-28 15:15:39 --> Language Class Initialized
INFO - 2018-03-28 15:15:39 --> Loader Class Initialized
INFO - 2018-03-28 15:15:39 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:39 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:39 --> Controller Class Initialized
INFO - 2018-03-28 15:15:39 --> Model Class Initialized
INFO - 2018-03-28 15:15:39 --> Model Class Initialized
INFO - 2018-03-28 15:15:39 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:15:40 --> Config Class Initialized
INFO - 2018-03-28 15:15:40 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:40 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:40 --> URI Class Initialized
INFO - 2018-03-28 15:15:40 --> Router Class Initialized
INFO - 2018-03-28 15:15:40 --> Output Class Initialized
INFO - 2018-03-28 15:15:40 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:40 --> Input Class Initialized
INFO - 2018-03-28 15:15:40 --> Language Class Initialized
INFO - 2018-03-28 15:15:40 --> Loader Class Initialized
INFO - 2018-03-28 15:15:40 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:40 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:40 --> Controller Class Initialized
INFO - 2018-03-28 15:15:40 --> Model Class Initialized
INFO - 2018-03-28 15:15:40 --> Model Class Initialized
INFO - 2018-03-28 15:15:40 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:15:40 --> Model Class Initialized
INFO - 2018-03-28 20:15:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:15:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:15:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:15:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:15:40 --> Final output sent to browser
DEBUG - 2018-03-28 20:15:40 --> Total execution time: 0.1202
INFO - 2018-03-28 15:15:45 --> Config Class Initialized
INFO - 2018-03-28 15:15:45 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:45 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:45 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:45 --> URI Class Initialized
INFO - 2018-03-28 15:15:45 --> Router Class Initialized
INFO - 2018-03-28 15:15:45 --> Output Class Initialized
INFO - 2018-03-28 15:15:45 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:45 --> Input Class Initialized
INFO - 2018-03-28 15:15:45 --> Language Class Initialized
INFO - 2018-03-28 15:15:45 --> Loader Class Initialized
INFO - 2018-03-28 15:15:45 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:45 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:45 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:45 --> Controller Class Initialized
INFO - 2018-03-28 15:15:45 --> Model Class Initialized
INFO - 2018-03-28 15:15:45 --> Model Class Initialized
INFO - 2018-03-28 15:15:45 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:15:45 --> Config Class Initialized
INFO - 2018-03-28 15:15:45 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:45 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:45 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:45 --> URI Class Initialized
INFO - 2018-03-28 15:15:45 --> Router Class Initialized
INFO - 2018-03-28 15:15:45 --> Output Class Initialized
INFO - 2018-03-28 15:15:45 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:45 --> Input Class Initialized
INFO - 2018-03-28 15:15:45 --> Language Class Initialized
INFO - 2018-03-28 15:15:45 --> Loader Class Initialized
INFO - 2018-03-28 15:15:45 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:45 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:45 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:45 --> Controller Class Initialized
INFO - 2018-03-28 15:15:45 --> Model Class Initialized
INFO - 2018-03-28 15:15:45 --> Model Class Initialized
INFO - 2018-03-28 15:15:45 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:15:45 --> Model Class Initialized
INFO - 2018-03-28 20:15:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:15:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:15:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:15:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:15:45 --> Final output sent to browser
DEBUG - 2018-03-28 20:15:45 --> Total execution time: 0.1254
INFO - 2018-03-28 15:15:50 --> Config Class Initialized
INFO - 2018-03-28 15:15:50 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:50 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:50 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:50 --> URI Class Initialized
INFO - 2018-03-28 15:15:50 --> Router Class Initialized
INFO - 2018-03-28 15:15:50 --> Output Class Initialized
INFO - 2018-03-28 15:15:50 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:50 --> Input Class Initialized
INFO - 2018-03-28 15:15:50 --> Language Class Initialized
INFO - 2018-03-28 15:15:50 --> Loader Class Initialized
INFO - 2018-03-28 15:15:50 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:50 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:50 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:50 --> Controller Class Initialized
INFO - 2018-03-28 15:15:50 --> Model Class Initialized
INFO - 2018-03-28 15:15:50 --> Model Class Initialized
INFO - 2018-03-28 15:15:50 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:15:50 --> Config Class Initialized
INFO - 2018-03-28 15:15:50 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:50 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:50 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:50 --> URI Class Initialized
INFO - 2018-03-28 15:15:50 --> Router Class Initialized
INFO - 2018-03-28 15:15:50 --> Output Class Initialized
INFO - 2018-03-28 15:15:50 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:50 --> Input Class Initialized
INFO - 2018-03-28 15:15:50 --> Language Class Initialized
INFO - 2018-03-28 15:15:50 --> Loader Class Initialized
INFO - 2018-03-28 15:15:50 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:50 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:50 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:50 --> Controller Class Initialized
INFO - 2018-03-28 15:15:50 --> Model Class Initialized
INFO - 2018-03-28 15:15:50 --> Model Class Initialized
INFO - 2018-03-28 15:15:50 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:15:50 --> Model Class Initialized
INFO - 2018-03-28 20:15:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:15:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:15:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:15:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:15:50 --> Final output sent to browser
DEBUG - 2018-03-28 20:15:50 --> Total execution time: 0.1441
INFO - 2018-03-28 15:15:54 --> Config Class Initialized
INFO - 2018-03-28 15:15:54 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:54 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:54 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:54 --> URI Class Initialized
INFO - 2018-03-28 15:15:54 --> Router Class Initialized
INFO - 2018-03-28 15:15:54 --> Output Class Initialized
INFO - 2018-03-28 15:15:54 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:54 --> Input Class Initialized
INFO - 2018-03-28 15:15:54 --> Language Class Initialized
INFO - 2018-03-28 15:15:54 --> Loader Class Initialized
INFO - 2018-03-28 15:15:54 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:54 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:54 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:54 --> Controller Class Initialized
INFO - 2018-03-28 15:15:54 --> Model Class Initialized
INFO - 2018-03-28 15:15:54 --> Model Class Initialized
INFO - 2018-03-28 15:15:54 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:15:54 --> Config Class Initialized
INFO - 2018-03-28 15:15:54 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:54 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:54 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:54 --> URI Class Initialized
INFO - 2018-03-28 15:15:54 --> Router Class Initialized
INFO - 2018-03-28 15:15:54 --> Output Class Initialized
INFO - 2018-03-28 15:15:54 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:54 --> Input Class Initialized
INFO - 2018-03-28 15:15:54 --> Language Class Initialized
INFO - 2018-03-28 15:15:54 --> Loader Class Initialized
INFO - 2018-03-28 15:15:54 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:54 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:54 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:54 --> Controller Class Initialized
INFO - 2018-03-28 15:15:54 --> Model Class Initialized
INFO - 2018-03-28 15:15:54 --> Model Class Initialized
INFO - 2018-03-28 15:15:54 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:15:54 --> Model Class Initialized
INFO - 2018-03-28 20:15:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:15:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:15:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:15:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:15:54 --> Final output sent to browser
DEBUG - 2018-03-28 20:15:54 --> Total execution time: 0.1763
INFO - 2018-03-28 15:15:59 --> Config Class Initialized
INFO - 2018-03-28 15:15:59 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:59 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:59 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:59 --> URI Class Initialized
INFO - 2018-03-28 15:15:59 --> Router Class Initialized
INFO - 2018-03-28 15:15:59 --> Output Class Initialized
INFO - 2018-03-28 15:15:59 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:59 --> Input Class Initialized
INFO - 2018-03-28 15:15:59 --> Language Class Initialized
INFO - 2018-03-28 15:15:59 --> Loader Class Initialized
INFO - 2018-03-28 15:15:59 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:59 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:59 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:59 --> Controller Class Initialized
INFO - 2018-03-28 15:15:59 --> Model Class Initialized
INFO - 2018-03-28 15:15:59 --> Model Class Initialized
INFO - 2018-03-28 15:15:59 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:15:59 --> Config Class Initialized
INFO - 2018-03-28 15:15:59 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:15:59 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:15:59 --> Utf8 Class Initialized
INFO - 2018-03-28 15:15:59 --> URI Class Initialized
INFO - 2018-03-28 15:15:59 --> Router Class Initialized
INFO - 2018-03-28 15:15:59 --> Output Class Initialized
INFO - 2018-03-28 15:15:59 --> Security Class Initialized
DEBUG - 2018-03-28 15:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:15:59 --> Input Class Initialized
INFO - 2018-03-28 15:15:59 --> Language Class Initialized
INFO - 2018-03-28 15:15:59 --> Loader Class Initialized
INFO - 2018-03-28 15:15:59 --> Helper loaded: url_helper
INFO - 2018-03-28 15:15:59 --> Helper loaded: form_helper
INFO - 2018-03-28 15:15:59 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:15:59 --> Controller Class Initialized
INFO - 2018-03-28 15:15:59 --> Model Class Initialized
INFO - 2018-03-28 15:15:59 --> Model Class Initialized
INFO - 2018-03-28 15:15:59 --> Helper loaded: date_helper
INFO - 2018-03-28 15:15:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:15:59 --> Model Class Initialized
INFO - 2018-03-28 20:15:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:15:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:15:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:15:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:15:59 --> Final output sent to browser
DEBUG - 2018-03-28 20:15:59 --> Total execution time: 0.1522
INFO - 2018-03-28 15:16:03 --> Config Class Initialized
INFO - 2018-03-28 15:16:03 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:03 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:03 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:03 --> URI Class Initialized
INFO - 2018-03-28 15:16:03 --> Router Class Initialized
INFO - 2018-03-28 15:16:03 --> Output Class Initialized
INFO - 2018-03-28 15:16:03 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:03 --> Input Class Initialized
INFO - 2018-03-28 15:16:03 --> Language Class Initialized
INFO - 2018-03-28 15:16:03 --> Loader Class Initialized
INFO - 2018-03-28 15:16:03 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:03 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:03 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:03 --> Controller Class Initialized
INFO - 2018-03-28 15:16:03 --> Model Class Initialized
INFO - 2018-03-28 15:16:03 --> Model Class Initialized
INFO - 2018-03-28 15:16:03 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:16:03 --> Config Class Initialized
INFO - 2018-03-28 15:16:03 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:03 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:03 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:03 --> URI Class Initialized
INFO - 2018-03-28 15:16:03 --> Router Class Initialized
INFO - 2018-03-28 15:16:03 --> Output Class Initialized
INFO - 2018-03-28 15:16:03 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:03 --> Input Class Initialized
INFO - 2018-03-28 15:16:03 --> Language Class Initialized
INFO - 2018-03-28 15:16:03 --> Loader Class Initialized
INFO - 2018-03-28 15:16:03 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:03 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:03 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:03 --> Controller Class Initialized
INFO - 2018-03-28 15:16:03 --> Model Class Initialized
INFO - 2018-03-28 15:16:03 --> Model Class Initialized
INFO - 2018-03-28 15:16:03 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:16:03 --> Model Class Initialized
INFO - 2018-03-28 20:16:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:16:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:16:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:16:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:16:04 --> Final output sent to browser
DEBUG - 2018-03-28 20:16:04 --> Total execution time: 0.1214
INFO - 2018-03-28 15:16:11 --> Config Class Initialized
INFO - 2018-03-28 15:16:11 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:11 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:11 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:11 --> URI Class Initialized
INFO - 2018-03-28 15:16:11 --> Router Class Initialized
INFO - 2018-03-28 15:16:11 --> Output Class Initialized
INFO - 2018-03-28 15:16:11 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:11 --> Input Class Initialized
INFO - 2018-03-28 15:16:11 --> Language Class Initialized
INFO - 2018-03-28 15:16:11 --> Loader Class Initialized
INFO - 2018-03-28 15:16:11 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:11 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:11 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:11 --> Controller Class Initialized
INFO - 2018-03-28 15:16:11 --> Model Class Initialized
INFO - 2018-03-28 15:16:11 --> Model Class Initialized
INFO - 2018-03-28 15:16:11 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:16:11 --> Config Class Initialized
INFO - 2018-03-28 15:16:11 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:11 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:11 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:11 --> URI Class Initialized
INFO - 2018-03-28 15:16:11 --> Router Class Initialized
INFO - 2018-03-28 15:16:11 --> Output Class Initialized
INFO - 2018-03-28 15:16:11 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:11 --> Input Class Initialized
INFO - 2018-03-28 15:16:11 --> Language Class Initialized
INFO - 2018-03-28 15:16:11 --> Loader Class Initialized
INFO - 2018-03-28 15:16:11 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:11 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:11 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:11 --> Controller Class Initialized
INFO - 2018-03-28 15:16:11 --> Model Class Initialized
INFO - 2018-03-28 15:16:11 --> Model Class Initialized
INFO - 2018-03-28 15:16:11 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:16:11 --> Model Class Initialized
INFO - 2018-03-28 20:16:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:16:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:16:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:16:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:16:11 --> Final output sent to browser
DEBUG - 2018-03-28 20:16:11 --> Total execution time: 0.1419
INFO - 2018-03-28 15:16:20 --> Config Class Initialized
INFO - 2018-03-28 15:16:20 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:20 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:20 --> URI Class Initialized
INFO - 2018-03-28 15:16:20 --> Router Class Initialized
INFO - 2018-03-28 15:16:20 --> Output Class Initialized
INFO - 2018-03-28 15:16:20 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:20 --> Input Class Initialized
INFO - 2018-03-28 15:16:20 --> Language Class Initialized
INFO - 2018-03-28 15:16:20 --> Loader Class Initialized
INFO - 2018-03-28 15:16:20 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:20 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:20 --> Controller Class Initialized
INFO - 2018-03-28 15:16:20 --> Model Class Initialized
INFO - 2018-03-28 15:16:20 --> Model Class Initialized
INFO - 2018-03-28 15:16:20 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:16:20 --> Config Class Initialized
INFO - 2018-03-28 15:16:20 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:20 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:20 --> URI Class Initialized
INFO - 2018-03-28 15:16:20 --> Router Class Initialized
INFO - 2018-03-28 15:16:20 --> Output Class Initialized
INFO - 2018-03-28 15:16:20 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:20 --> Input Class Initialized
INFO - 2018-03-28 15:16:20 --> Language Class Initialized
INFO - 2018-03-28 15:16:20 --> Loader Class Initialized
INFO - 2018-03-28 15:16:20 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:20 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:20 --> Controller Class Initialized
INFO - 2018-03-28 15:16:20 --> Model Class Initialized
INFO - 2018-03-28 15:16:20 --> Model Class Initialized
INFO - 2018-03-28 15:16:20 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:16:20 --> Model Class Initialized
INFO - 2018-03-28 20:16:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:16:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:16:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:16:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:16:20 --> Final output sent to browser
DEBUG - 2018-03-28 20:16:20 --> Total execution time: 0.1148
INFO - 2018-03-28 15:16:29 --> Config Class Initialized
INFO - 2018-03-28 15:16:29 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:29 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:29 --> URI Class Initialized
INFO - 2018-03-28 15:16:29 --> Router Class Initialized
INFO - 2018-03-28 15:16:29 --> Output Class Initialized
INFO - 2018-03-28 15:16:29 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:29 --> Input Class Initialized
INFO - 2018-03-28 15:16:29 --> Language Class Initialized
INFO - 2018-03-28 15:16:29 --> Loader Class Initialized
INFO - 2018-03-28 15:16:29 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:29 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:29 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:29 --> Controller Class Initialized
INFO - 2018-03-28 15:16:29 --> Model Class Initialized
INFO - 2018-03-28 15:16:29 --> Model Class Initialized
INFO - 2018-03-28 15:16:29 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:16:29 --> Config Class Initialized
INFO - 2018-03-28 15:16:29 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:29 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:29 --> URI Class Initialized
INFO - 2018-03-28 15:16:29 --> Router Class Initialized
INFO - 2018-03-28 15:16:29 --> Output Class Initialized
INFO - 2018-03-28 15:16:29 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:29 --> Input Class Initialized
INFO - 2018-03-28 15:16:29 --> Language Class Initialized
INFO - 2018-03-28 15:16:29 --> Loader Class Initialized
INFO - 2018-03-28 15:16:29 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:29 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:29 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:29 --> Controller Class Initialized
INFO - 2018-03-28 15:16:29 --> Model Class Initialized
INFO - 2018-03-28 15:16:29 --> Model Class Initialized
INFO - 2018-03-28 15:16:29 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:16:29 --> Model Class Initialized
INFO - 2018-03-28 20:16:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:16:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:16:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:16:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:16:29 --> Final output sent to browser
DEBUG - 2018-03-28 20:16:29 --> Total execution time: 0.1357
INFO - 2018-03-28 15:16:35 --> Config Class Initialized
INFO - 2018-03-28 15:16:35 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:35 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:35 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:35 --> URI Class Initialized
INFO - 2018-03-28 15:16:35 --> Router Class Initialized
INFO - 2018-03-28 15:16:35 --> Output Class Initialized
INFO - 2018-03-28 15:16:35 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:35 --> Input Class Initialized
INFO - 2018-03-28 15:16:35 --> Language Class Initialized
INFO - 2018-03-28 15:16:35 --> Loader Class Initialized
INFO - 2018-03-28 15:16:35 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:35 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:35 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:35 --> Controller Class Initialized
INFO - 2018-03-28 15:16:35 --> Model Class Initialized
INFO - 2018-03-28 15:16:35 --> Model Class Initialized
INFO - 2018-03-28 15:16:35 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:16:35 --> Config Class Initialized
INFO - 2018-03-28 15:16:35 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:35 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:35 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:35 --> URI Class Initialized
INFO - 2018-03-28 15:16:35 --> Router Class Initialized
INFO - 2018-03-28 15:16:35 --> Output Class Initialized
INFO - 2018-03-28 15:16:35 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:35 --> Input Class Initialized
INFO - 2018-03-28 15:16:35 --> Language Class Initialized
INFO - 2018-03-28 15:16:35 --> Loader Class Initialized
INFO - 2018-03-28 15:16:35 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:35 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:35 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:35 --> Controller Class Initialized
INFO - 2018-03-28 15:16:35 --> Model Class Initialized
INFO - 2018-03-28 15:16:35 --> Model Class Initialized
INFO - 2018-03-28 15:16:35 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:16:35 --> Model Class Initialized
INFO - 2018-03-28 20:16:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:16:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:16:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:16:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:16:35 --> Final output sent to browser
DEBUG - 2018-03-28 20:16:35 --> Total execution time: 0.1403
INFO - 2018-03-28 15:16:36 --> Config Class Initialized
INFO - 2018-03-28 15:16:36 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:36 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:36 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:36 --> URI Class Initialized
INFO - 2018-03-28 15:16:36 --> Router Class Initialized
INFO - 2018-03-28 15:16:37 --> Output Class Initialized
INFO - 2018-03-28 15:16:37 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:37 --> Input Class Initialized
INFO - 2018-03-28 15:16:37 --> Language Class Initialized
INFO - 2018-03-28 15:16:37 --> Loader Class Initialized
INFO - 2018-03-28 15:16:37 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:37 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:37 --> Controller Class Initialized
INFO - 2018-03-28 15:16:37 --> Model Class Initialized
INFO - 2018-03-28 15:16:37 --> Model Class Initialized
INFO - 2018-03-28 15:16:37 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:16:37 --> Config Class Initialized
INFO - 2018-03-28 15:16:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:37 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:37 --> URI Class Initialized
INFO - 2018-03-28 15:16:37 --> Router Class Initialized
INFO - 2018-03-28 15:16:37 --> Output Class Initialized
INFO - 2018-03-28 15:16:37 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:37 --> Input Class Initialized
INFO - 2018-03-28 15:16:37 --> Language Class Initialized
INFO - 2018-03-28 15:16:37 --> Loader Class Initialized
INFO - 2018-03-28 15:16:37 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:37 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:37 --> Controller Class Initialized
INFO - 2018-03-28 15:16:37 --> Model Class Initialized
INFO - 2018-03-28 15:16:37 --> Model Class Initialized
INFO - 2018-03-28 15:16:37 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:16:37 --> Model Class Initialized
INFO - 2018-03-28 20:16:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:16:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:16:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:16:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:16:37 --> Final output sent to browser
DEBUG - 2018-03-28 20:16:37 --> Total execution time: 0.1358
INFO - 2018-03-28 15:16:38 --> Config Class Initialized
INFO - 2018-03-28 15:16:38 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:38 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:38 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:38 --> URI Class Initialized
INFO - 2018-03-28 15:16:38 --> Router Class Initialized
INFO - 2018-03-28 15:16:38 --> Output Class Initialized
INFO - 2018-03-28 15:16:38 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:38 --> Input Class Initialized
INFO - 2018-03-28 15:16:38 --> Language Class Initialized
INFO - 2018-03-28 15:16:38 --> Loader Class Initialized
INFO - 2018-03-28 15:16:38 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:38 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:38 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:38 --> Controller Class Initialized
INFO - 2018-03-28 15:16:38 --> Model Class Initialized
INFO - 2018-03-28 15:16:38 --> Model Class Initialized
INFO - 2018-03-28 15:16:38 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:16:38 --> Config Class Initialized
INFO - 2018-03-28 15:16:38 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:38 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:38 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:38 --> URI Class Initialized
INFO - 2018-03-28 15:16:38 --> Router Class Initialized
INFO - 2018-03-28 15:16:38 --> Output Class Initialized
INFO - 2018-03-28 15:16:38 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:38 --> Input Class Initialized
INFO - 2018-03-28 15:16:38 --> Language Class Initialized
INFO - 2018-03-28 15:16:38 --> Loader Class Initialized
INFO - 2018-03-28 15:16:38 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:38 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:38 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:38 --> Controller Class Initialized
INFO - 2018-03-28 15:16:38 --> Model Class Initialized
INFO - 2018-03-28 15:16:38 --> Model Class Initialized
INFO - 2018-03-28 15:16:38 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:16:38 --> Model Class Initialized
INFO - 2018-03-28 20:16:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:16:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:16:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:16:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:16:39 --> Final output sent to browser
DEBUG - 2018-03-28 20:16:39 --> Total execution time: 0.1505
INFO - 2018-03-28 15:16:39 --> Config Class Initialized
INFO - 2018-03-28 15:16:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:39 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:39 --> URI Class Initialized
INFO - 2018-03-28 15:16:39 --> Router Class Initialized
INFO - 2018-03-28 15:16:39 --> Output Class Initialized
INFO - 2018-03-28 15:16:39 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:39 --> Input Class Initialized
INFO - 2018-03-28 15:16:40 --> Language Class Initialized
INFO - 2018-03-28 15:16:40 --> Loader Class Initialized
INFO - 2018-03-28 15:16:40 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:40 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:40 --> Controller Class Initialized
INFO - 2018-03-28 15:16:40 --> Model Class Initialized
INFO - 2018-03-28 15:16:40 --> Model Class Initialized
INFO - 2018-03-28 15:16:40 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:16:40 --> Config Class Initialized
INFO - 2018-03-28 15:16:40 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:40 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:40 --> URI Class Initialized
INFO - 2018-03-28 15:16:40 --> Router Class Initialized
INFO - 2018-03-28 15:16:40 --> Output Class Initialized
INFO - 2018-03-28 15:16:40 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:40 --> Input Class Initialized
INFO - 2018-03-28 15:16:40 --> Language Class Initialized
INFO - 2018-03-28 15:16:40 --> Loader Class Initialized
INFO - 2018-03-28 15:16:40 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:40 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:40 --> Controller Class Initialized
INFO - 2018-03-28 15:16:40 --> Model Class Initialized
INFO - 2018-03-28 15:16:40 --> Model Class Initialized
INFO - 2018-03-28 15:16:40 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:16:40 --> Model Class Initialized
INFO - 2018-03-28 20:16:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:16:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:16:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:16:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:16:40 --> Final output sent to browser
DEBUG - 2018-03-28 20:16:40 --> Total execution time: 0.1567
INFO - 2018-03-28 15:16:41 --> Config Class Initialized
INFO - 2018-03-28 15:16:41 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:41 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:41 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:41 --> URI Class Initialized
INFO - 2018-03-28 15:16:41 --> Router Class Initialized
INFO - 2018-03-28 15:16:41 --> Output Class Initialized
INFO - 2018-03-28 15:16:41 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:41 --> Input Class Initialized
INFO - 2018-03-28 15:16:41 --> Language Class Initialized
INFO - 2018-03-28 15:16:41 --> Loader Class Initialized
INFO - 2018-03-28 15:16:41 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:41 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:41 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:41 --> Controller Class Initialized
INFO - 2018-03-28 15:16:41 --> Model Class Initialized
INFO - 2018-03-28 15:16:41 --> Model Class Initialized
INFO - 2018-03-28 15:16:41 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:16:41 --> Config Class Initialized
INFO - 2018-03-28 15:16:41 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:41 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:41 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:41 --> URI Class Initialized
INFO - 2018-03-28 15:16:41 --> Router Class Initialized
INFO - 2018-03-28 15:16:41 --> Output Class Initialized
INFO - 2018-03-28 15:16:41 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:41 --> Input Class Initialized
INFO - 2018-03-28 15:16:41 --> Language Class Initialized
INFO - 2018-03-28 15:16:41 --> Loader Class Initialized
INFO - 2018-03-28 15:16:41 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:41 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:41 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:41 --> Controller Class Initialized
INFO - 2018-03-28 15:16:41 --> Model Class Initialized
INFO - 2018-03-28 15:16:41 --> Model Class Initialized
INFO - 2018-03-28 15:16:41 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:16:41 --> Model Class Initialized
INFO - 2018-03-28 20:16:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:16:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:16:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:16:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:16:41 --> Final output sent to browser
DEBUG - 2018-03-28 20:16:41 --> Total execution time: 0.1329
INFO - 2018-03-28 15:16:42 --> Config Class Initialized
INFO - 2018-03-28 15:16:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:42 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:42 --> URI Class Initialized
INFO - 2018-03-28 15:16:42 --> Router Class Initialized
INFO - 2018-03-28 15:16:42 --> Output Class Initialized
INFO - 2018-03-28 15:16:42 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:42 --> Input Class Initialized
INFO - 2018-03-28 15:16:42 --> Language Class Initialized
INFO - 2018-03-28 15:16:42 --> Loader Class Initialized
INFO - 2018-03-28 15:16:42 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:42 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:42 --> Controller Class Initialized
INFO - 2018-03-28 15:16:42 --> Model Class Initialized
INFO - 2018-03-28 15:16:42 --> Model Class Initialized
INFO - 2018-03-28 15:16:42 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:16:43 --> Config Class Initialized
INFO - 2018-03-28 15:16:43 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:43 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:43 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:43 --> URI Class Initialized
INFO - 2018-03-28 15:16:43 --> Router Class Initialized
INFO - 2018-03-28 15:16:43 --> Output Class Initialized
INFO - 2018-03-28 15:16:43 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:43 --> Input Class Initialized
INFO - 2018-03-28 15:16:43 --> Language Class Initialized
INFO - 2018-03-28 15:16:43 --> Loader Class Initialized
INFO - 2018-03-28 15:16:43 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:43 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:43 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:43 --> Controller Class Initialized
INFO - 2018-03-28 15:16:43 --> Model Class Initialized
INFO - 2018-03-28 15:16:43 --> Model Class Initialized
INFO - 2018-03-28 15:16:43 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:16:43 --> Model Class Initialized
INFO - 2018-03-28 20:16:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:16:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:16:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:16:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:16:43 --> Final output sent to browser
DEBUG - 2018-03-28 20:16:43 --> Total execution time: 0.1826
INFO - 2018-03-28 15:16:44 --> Config Class Initialized
INFO - 2018-03-28 15:16:44 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:44 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:44 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:44 --> URI Class Initialized
INFO - 2018-03-28 15:16:44 --> Router Class Initialized
INFO - 2018-03-28 15:16:44 --> Output Class Initialized
INFO - 2018-03-28 15:16:44 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:44 --> Input Class Initialized
INFO - 2018-03-28 15:16:44 --> Language Class Initialized
INFO - 2018-03-28 15:16:44 --> Loader Class Initialized
INFO - 2018-03-28 15:16:44 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:44 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:44 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:44 --> Controller Class Initialized
INFO - 2018-03-28 15:16:44 --> Model Class Initialized
INFO - 2018-03-28 15:16:44 --> Model Class Initialized
INFO - 2018-03-28 15:16:44 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:16:44 --> Config Class Initialized
INFO - 2018-03-28 15:16:44 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:44 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:44 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:44 --> URI Class Initialized
INFO - 2018-03-28 15:16:44 --> Router Class Initialized
INFO - 2018-03-28 15:16:44 --> Output Class Initialized
INFO - 2018-03-28 15:16:44 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:44 --> Input Class Initialized
INFO - 2018-03-28 15:16:44 --> Language Class Initialized
INFO - 2018-03-28 15:16:44 --> Loader Class Initialized
INFO - 2018-03-28 15:16:44 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:44 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:44 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:44 --> Controller Class Initialized
INFO - 2018-03-28 15:16:44 --> Model Class Initialized
INFO - 2018-03-28 15:16:44 --> Model Class Initialized
INFO - 2018-03-28 15:16:44 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:16:44 --> Model Class Initialized
INFO - 2018-03-28 20:16:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:16:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:16:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:16:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:16:44 --> Final output sent to browser
DEBUG - 2018-03-28 20:16:44 --> Total execution time: 0.1091
INFO - 2018-03-28 15:16:46 --> Config Class Initialized
INFO - 2018-03-28 15:16:46 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:46 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:46 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:46 --> URI Class Initialized
INFO - 2018-03-28 15:16:46 --> Router Class Initialized
INFO - 2018-03-28 15:16:46 --> Output Class Initialized
INFO - 2018-03-28 15:16:46 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:46 --> Input Class Initialized
INFO - 2018-03-28 15:16:46 --> Language Class Initialized
INFO - 2018-03-28 15:16:46 --> Loader Class Initialized
INFO - 2018-03-28 15:16:46 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:46 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:46 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:46 --> Controller Class Initialized
INFO - 2018-03-28 15:16:46 --> Model Class Initialized
INFO - 2018-03-28 15:16:46 --> Model Class Initialized
INFO - 2018-03-28 15:16:46 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:16:46 --> Config Class Initialized
INFO - 2018-03-28 15:16:46 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:46 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:46 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:46 --> URI Class Initialized
INFO - 2018-03-28 15:16:46 --> Router Class Initialized
INFO - 2018-03-28 15:16:46 --> Output Class Initialized
INFO - 2018-03-28 15:16:46 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:46 --> Input Class Initialized
INFO - 2018-03-28 15:16:46 --> Language Class Initialized
INFO - 2018-03-28 15:16:46 --> Loader Class Initialized
INFO - 2018-03-28 15:16:46 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:46 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:46 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:46 --> Controller Class Initialized
INFO - 2018-03-28 15:16:46 --> Model Class Initialized
INFO - 2018-03-28 15:16:46 --> Model Class Initialized
INFO - 2018-03-28 15:16:46 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:16:46 --> Model Class Initialized
INFO - 2018-03-28 20:16:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:16:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:16:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:16:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:16:46 --> Final output sent to browser
DEBUG - 2018-03-28 20:16:46 --> Total execution time: 0.1126
INFO - 2018-03-28 15:16:48 --> Config Class Initialized
INFO - 2018-03-28 15:16:48 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:48 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:48 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:48 --> URI Class Initialized
INFO - 2018-03-28 15:16:48 --> Router Class Initialized
INFO - 2018-03-28 15:16:48 --> Output Class Initialized
INFO - 2018-03-28 15:16:48 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:48 --> Input Class Initialized
INFO - 2018-03-28 15:16:48 --> Language Class Initialized
INFO - 2018-03-28 15:16:48 --> Loader Class Initialized
INFO - 2018-03-28 15:16:48 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:48 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:48 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:48 --> Controller Class Initialized
INFO - 2018-03-28 15:16:48 --> Model Class Initialized
INFO - 2018-03-28 15:16:48 --> Model Class Initialized
INFO - 2018-03-28 15:16:48 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:16:48 --> Config Class Initialized
INFO - 2018-03-28 15:16:48 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:48 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:48 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:48 --> URI Class Initialized
INFO - 2018-03-28 15:16:48 --> Router Class Initialized
INFO - 2018-03-28 15:16:48 --> Output Class Initialized
INFO - 2018-03-28 15:16:48 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:48 --> Input Class Initialized
INFO - 2018-03-28 15:16:48 --> Language Class Initialized
INFO - 2018-03-28 15:16:48 --> Loader Class Initialized
INFO - 2018-03-28 15:16:48 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:48 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:48 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:48 --> Controller Class Initialized
INFO - 2018-03-28 15:16:48 --> Model Class Initialized
INFO - 2018-03-28 15:16:48 --> Model Class Initialized
INFO - 2018-03-28 15:16:48 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:16:48 --> Model Class Initialized
INFO - 2018-03-28 20:16:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:16:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:16:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:16:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:16:48 --> Final output sent to browser
DEBUG - 2018-03-28 20:16:48 --> Total execution time: 0.1380
INFO - 2018-03-28 15:16:51 --> Config Class Initialized
INFO - 2018-03-28 15:16:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:51 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:51 --> URI Class Initialized
INFO - 2018-03-28 15:16:51 --> Router Class Initialized
INFO - 2018-03-28 15:16:51 --> Output Class Initialized
INFO - 2018-03-28 15:16:51 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:51 --> Input Class Initialized
INFO - 2018-03-28 15:16:51 --> Language Class Initialized
INFO - 2018-03-28 15:16:51 --> Loader Class Initialized
INFO - 2018-03-28 15:16:51 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:51 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:51 --> Controller Class Initialized
INFO - 2018-03-28 15:16:51 --> Model Class Initialized
INFO - 2018-03-28 15:16:51 --> Model Class Initialized
INFO - 2018-03-28 15:16:51 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:16:51 --> Config Class Initialized
INFO - 2018-03-28 15:16:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:51 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:51 --> URI Class Initialized
INFO - 2018-03-28 15:16:51 --> Router Class Initialized
INFO - 2018-03-28 15:16:51 --> Output Class Initialized
INFO - 2018-03-28 15:16:51 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:51 --> Input Class Initialized
INFO - 2018-03-28 15:16:51 --> Language Class Initialized
INFO - 2018-03-28 15:16:51 --> Loader Class Initialized
INFO - 2018-03-28 15:16:51 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:51 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:51 --> Controller Class Initialized
INFO - 2018-03-28 15:16:51 --> Model Class Initialized
INFO - 2018-03-28 15:16:51 --> Model Class Initialized
INFO - 2018-03-28 15:16:51 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:16:51 --> Model Class Initialized
INFO - 2018-03-28 20:16:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:16:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:16:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:16:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:16:51 --> Final output sent to browser
DEBUG - 2018-03-28 20:16:51 --> Total execution time: 0.1254
INFO - 2018-03-28 15:16:59 --> Config Class Initialized
INFO - 2018-03-28 15:16:59 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:16:59 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:16:59 --> Utf8 Class Initialized
INFO - 2018-03-28 15:16:59 --> URI Class Initialized
INFO - 2018-03-28 15:16:59 --> Router Class Initialized
INFO - 2018-03-28 15:16:59 --> Output Class Initialized
INFO - 2018-03-28 15:16:59 --> Security Class Initialized
DEBUG - 2018-03-28 15:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:16:59 --> Input Class Initialized
INFO - 2018-03-28 15:16:59 --> Language Class Initialized
INFO - 2018-03-28 15:16:59 --> Loader Class Initialized
INFO - 2018-03-28 15:16:59 --> Helper loaded: url_helper
INFO - 2018-03-28 15:16:59 --> Helper loaded: form_helper
INFO - 2018-03-28 15:16:59 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:16:59 --> Controller Class Initialized
INFO - 2018-03-28 15:16:59 --> Model Class Initialized
INFO - 2018-03-28 15:16:59 --> Model Class Initialized
INFO - 2018-03-28 15:16:59 --> Helper loaded: date_helper
INFO - 2018-03-28 15:16:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:16:59 --> Model Class Initialized
INFO - 2018-03-28 20:16:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:16:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:16:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:16:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:16:59 --> Final output sent to browser
DEBUG - 2018-03-28 20:16:59 --> Total execution time: 0.1230
INFO - 2018-03-28 15:17:06 --> Config Class Initialized
INFO - 2018-03-28 15:17:06 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:06 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:06 --> URI Class Initialized
INFO - 2018-03-28 15:17:06 --> Router Class Initialized
INFO - 2018-03-28 15:17:06 --> Output Class Initialized
INFO - 2018-03-28 15:17:06 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:06 --> Input Class Initialized
INFO - 2018-03-28 15:17:06 --> Language Class Initialized
INFO - 2018-03-28 15:17:06 --> Loader Class Initialized
INFO - 2018-03-28 15:17:06 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:06 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:06 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:06 --> Controller Class Initialized
INFO - 2018-03-28 15:17:06 --> Model Class Initialized
INFO - 2018-03-28 15:17:06 --> Model Class Initialized
INFO - 2018-03-28 15:17:06 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:06 --> Config Class Initialized
INFO - 2018-03-28 15:17:06 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:06 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:06 --> URI Class Initialized
INFO - 2018-03-28 15:17:06 --> Router Class Initialized
INFO - 2018-03-28 15:17:06 --> Output Class Initialized
INFO - 2018-03-28 15:17:07 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:07 --> Input Class Initialized
INFO - 2018-03-28 15:17:07 --> Language Class Initialized
INFO - 2018-03-28 15:17:07 --> Loader Class Initialized
INFO - 2018-03-28 15:17:07 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:07 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:07 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:07 --> Controller Class Initialized
INFO - 2018-03-28 15:17:07 --> Model Class Initialized
INFO - 2018-03-28 15:17:07 --> Model Class Initialized
INFO - 2018-03-28 15:17:07 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:07 --> Model Class Initialized
INFO - 2018-03-28 20:17:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:07 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:07 --> Total execution time: 0.1655
INFO - 2018-03-28 15:17:08 --> Config Class Initialized
INFO - 2018-03-28 15:17:08 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:08 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:08 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:08 --> URI Class Initialized
INFO - 2018-03-28 15:17:08 --> Router Class Initialized
INFO - 2018-03-28 15:17:08 --> Output Class Initialized
INFO - 2018-03-28 15:17:08 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:08 --> Input Class Initialized
INFO - 2018-03-28 15:17:08 --> Language Class Initialized
INFO - 2018-03-28 15:17:08 --> Loader Class Initialized
INFO - 2018-03-28 15:17:08 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:08 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:08 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:08 --> Controller Class Initialized
INFO - 2018-03-28 15:17:08 --> Model Class Initialized
INFO - 2018-03-28 15:17:08 --> Model Class Initialized
INFO - 2018-03-28 15:17:08 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:08 --> Config Class Initialized
INFO - 2018-03-28 15:17:08 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:08 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:08 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:08 --> URI Class Initialized
INFO - 2018-03-28 15:17:08 --> Router Class Initialized
INFO - 2018-03-28 15:17:08 --> Output Class Initialized
INFO - 2018-03-28 15:17:08 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:08 --> Input Class Initialized
INFO - 2018-03-28 15:17:08 --> Language Class Initialized
INFO - 2018-03-28 15:17:08 --> Loader Class Initialized
INFO - 2018-03-28 15:17:08 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:08 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:08 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:08 --> Controller Class Initialized
INFO - 2018-03-28 15:17:08 --> Model Class Initialized
INFO - 2018-03-28 15:17:08 --> Model Class Initialized
INFO - 2018-03-28 15:17:08 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:08 --> Model Class Initialized
INFO - 2018-03-28 20:17:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:08 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:08 --> Total execution time: 0.1436
INFO - 2018-03-28 15:17:09 --> Config Class Initialized
INFO - 2018-03-28 15:17:09 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:09 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:09 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:09 --> URI Class Initialized
INFO - 2018-03-28 15:17:09 --> Router Class Initialized
INFO - 2018-03-28 15:17:09 --> Output Class Initialized
INFO - 2018-03-28 15:17:09 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:09 --> Input Class Initialized
INFO - 2018-03-28 15:17:09 --> Language Class Initialized
INFO - 2018-03-28 15:17:09 --> Loader Class Initialized
INFO - 2018-03-28 15:17:09 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:09 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:09 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:09 --> Controller Class Initialized
INFO - 2018-03-28 15:17:09 --> Model Class Initialized
INFO - 2018-03-28 15:17:09 --> Model Class Initialized
INFO - 2018-03-28 15:17:09 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:09 --> Config Class Initialized
INFO - 2018-03-28 15:17:09 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:09 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:09 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:09 --> URI Class Initialized
INFO - 2018-03-28 15:17:09 --> Router Class Initialized
INFO - 2018-03-28 15:17:09 --> Output Class Initialized
INFO - 2018-03-28 15:17:09 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:09 --> Input Class Initialized
INFO - 2018-03-28 15:17:09 --> Language Class Initialized
INFO - 2018-03-28 15:17:09 --> Loader Class Initialized
INFO - 2018-03-28 15:17:09 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:09 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:09 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:09 --> Controller Class Initialized
INFO - 2018-03-28 15:17:09 --> Model Class Initialized
INFO - 2018-03-28 15:17:09 --> Model Class Initialized
INFO - 2018-03-28 15:17:09 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:09 --> Model Class Initialized
INFO - 2018-03-28 20:17:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:09 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:09 --> Total execution time: 0.1345
INFO - 2018-03-28 15:17:10 --> Config Class Initialized
INFO - 2018-03-28 15:17:10 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:10 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:10 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:10 --> URI Class Initialized
INFO - 2018-03-28 15:17:10 --> Router Class Initialized
INFO - 2018-03-28 15:17:10 --> Output Class Initialized
INFO - 2018-03-28 15:17:10 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:10 --> Input Class Initialized
INFO - 2018-03-28 15:17:10 --> Language Class Initialized
INFO - 2018-03-28 15:17:10 --> Loader Class Initialized
INFO - 2018-03-28 15:17:10 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:10 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:10 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:10 --> Controller Class Initialized
INFO - 2018-03-28 15:17:11 --> Model Class Initialized
INFO - 2018-03-28 15:17:11 --> Model Class Initialized
INFO - 2018-03-28 15:17:11 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:11 --> Config Class Initialized
INFO - 2018-03-28 15:17:11 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:11 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:11 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:11 --> URI Class Initialized
INFO - 2018-03-28 15:17:11 --> Router Class Initialized
INFO - 2018-03-28 15:17:11 --> Output Class Initialized
INFO - 2018-03-28 15:17:11 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:11 --> Input Class Initialized
INFO - 2018-03-28 15:17:11 --> Language Class Initialized
INFO - 2018-03-28 15:17:11 --> Loader Class Initialized
INFO - 2018-03-28 15:17:11 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:11 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:11 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:11 --> Controller Class Initialized
INFO - 2018-03-28 15:17:11 --> Model Class Initialized
INFO - 2018-03-28 15:17:11 --> Model Class Initialized
INFO - 2018-03-28 15:17:11 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:11 --> Model Class Initialized
INFO - 2018-03-28 20:17:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:11 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:11 --> Total execution time: 0.1422
INFO - 2018-03-28 15:17:12 --> Config Class Initialized
INFO - 2018-03-28 15:17:12 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:12 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:12 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:12 --> URI Class Initialized
INFO - 2018-03-28 15:17:12 --> Router Class Initialized
INFO - 2018-03-28 15:17:12 --> Output Class Initialized
INFO - 2018-03-28 15:17:12 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:12 --> Input Class Initialized
INFO - 2018-03-28 15:17:12 --> Language Class Initialized
INFO - 2018-03-28 15:17:12 --> Loader Class Initialized
INFO - 2018-03-28 15:17:12 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:12 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:12 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:12 --> Controller Class Initialized
INFO - 2018-03-28 15:17:12 --> Model Class Initialized
INFO - 2018-03-28 15:17:12 --> Model Class Initialized
INFO - 2018-03-28 15:17:12 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:12 --> Config Class Initialized
INFO - 2018-03-28 15:17:12 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:12 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:12 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:12 --> URI Class Initialized
INFO - 2018-03-28 15:17:12 --> Router Class Initialized
INFO - 2018-03-28 15:17:12 --> Output Class Initialized
INFO - 2018-03-28 15:17:12 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:12 --> Input Class Initialized
INFO - 2018-03-28 15:17:12 --> Language Class Initialized
INFO - 2018-03-28 15:17:12 --> Loader Class Initialized
INFO - 2018-03-28 15:17:12 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:12 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:12 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:12 --> Controller Class Initialized
INFO - 2018-03-28 15:17:12 --> Model Class Initialized
INFO - 2018-03-28 15:17:12 --> Model Class Initialized
INFO - 2018-03-28 15:17:12 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:12 --> Model Class Initialized
INFO - 2018-03-28 20:17:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:12 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:12 --> Total execution time: 0.1040
INFO - 2018-03-28 15:17:13 --> Config Class Initialized
INFO - 2018-03-28 15:17:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:13 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:13 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:13 --> URI Class Initialized
INFO - 2018-03-28 15:17:13 --> Router Class Initialized
INFO - 2018-03-28 15:17:13 --> Output Class Initialized
INFO - 2018-03-28 15:17:13 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:13 --> Input Class Initialized
INFO - 2018-03-28 15:17:13 --> Language Class Initialized
INFO - 2018-03-28 15:17:13 --> Loader Class Initialized
INFO - 2018-03-28 15:17:13 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:13 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:13 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:13 --> Controller Class Initialized
INFO - 2018-03-28 15:17:13 --> Model Class Initialized
INFO - 2018-03-28 15:17:13 --> Model Class Initialized
INFO - 2018-03-28 15:17:13 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:13 --> Config Class Initialized
INFO - 2018-03-28 15:17:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:13 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:13 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:13 --> URI Class Initialized
INFO - 2018-03-28 15:17:13 --> Router Class Initialized
INFO - 2018-03-28 15:17:13 --> Output Class Initialized
INFO - 2018-03-28 15:17:13 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:13 --> Input Class Initialized
INFO - 2018-03-28 15:17:13 --> Language Class Initialized
INFO - 2018-03-28 15:17:13 --> Loader Class Initialized
INFO - 2018-03-28 15:17:13 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:14 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:14 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:14 --> Controller Class Initialized
INFO - 2018-03-28 15:17:14 --> Model Class Initialized
INFO - 2018-03-28 15:17:14 --> Model Class Initialized
INFO - 2018-03-28 15:17:14 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:14 --> Model Class Initialized
INFO - 2018-03-28 20:17:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:14 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:14 --> Total execution time: 0.1286
INFO - 2018-03-28 15:17:15 --> Config Class Initialized
INFO - 2018-03-28 15:17:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:15 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:15 --> URI Class Initialized
INFO - 2018-03-28 15:17:15 --> Router Class Initialized
INFO - 2018-03-28 15:17:15 --> Output Class Initialized
INFO - 2018-03-28 15:17:15 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:15 --> Input Class Initialized
INFO - 2018-03-28 15:17:15 --> Language Class Initialized
INFO - 2018-03-28 15:17:15 --> Loader Class Initialized
INFO - 2018-03-28 15:17:15 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:15 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:15 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:15 --> Controller Class Initialized
INFO - 2018-03-28 15:17:15 --> Model Class Initialized
INFO - 2018-03-28 15:17:15 --> Model Class Initialized
INFO - 2018-03-28 15:17:15 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:16 --> Config Class Initialized
INFO - 2018-03-28 15:17:16 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:16 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:16 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:16 --> URI Class Initialized
INFO - 2018-03-28 15:17:16 --> Router Class Initialized
INFO - 2018-03-28 15:17:16 --> Output Class Initialized
INFO - 2018-03-28 15:17:16 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:16 --> Input Class Initialized
INFO - 2018-03-28 15:17:16 --> Language Class Initialized
INFO - 2018-03-28 15:17:16 --> Loader Class Initialized
INFO - 2018-03-28 15:17:16 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:16 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:16 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:16 --> Controller Class Initialized
INFO - 2018-03-28 15:17:16 --> Model Class Initialized
INFO - 2018-03-28 15:17:16 --> Model Class Initialized
INFO - 2018-03-28 15:17:16 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:16 --> Model Class Initialized
INFO - 2018-03-28 20:17:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:16 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:16 --> Total execution time: 0.1218
INFO - 2018-03-28 15:17:17 --> Config Class Initialized
INFO - 2018-03-28 15:17:17 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:17 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:17 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:17 --> URI Class Initialized
INFO - 2018-03-28 15:17:17 --> Router Class Initialized
INFO - 2018-03-28 15:17:17 --> Output Class Initialized
INFO - 2018-03-28 15:17:17 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:17 --> Input Class Initialized
INFO - 2018-03-28 15:17:17 --> Language Class Initialized
INFO - 2018-03-28 15:17:17 --> Loader Class Initialized
INFO - 2018-03-28 15:17:17 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:17 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:17 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:17 --> Controller Class Initialized
INFO - 2018-03-28 15:17:17 --> Model Class Initialized
INFO - 2018-03-28 15:17:17 --> Model Class Initialized
INFO - 2018-03-28 15:17:17 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:17 --> Config Class Initialized
INFO - 2018-03-28 15:17:17 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:17 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:17 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:17 --> URI Class Initialized
INFO - 2018-03-28 15:17:17 --> Router Class Initialized
INFO - 2018-03-28 15:17:17 --> Output Class Initialized
INFO - 2018-03-28 15:17:17 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:17 --> Input Class Initialized
INFO - 2018-03-28 15:17:17 --> Language Class Initialized
INFO - 2018-03-28 15:17:17 --> Loader Class Initialized
INFO - 2018-03-28 15:17:17 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:17 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:17 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:17 --> Controller Class Initialized
INFO - 2018-03-28 15:17:17 --> Model Class Initialized
INFO - 2018-03-28 15:17:17 --> Model Class Initialized
INFO - 2018-03-28 15:17:17 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:17 --> Model Class Initialized
INFO - 2018-03-28 20:17:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:17 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:17 --> Total execution time: 0.1423
INFO - 2018-03-28 15:17:18 --> Config Class Initialized
INFO - 2018-03-28 15:17:18 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:18 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:18 --> URI Class Initialized
INFO - 2018-03-28 15:17:18 --> Router Class Initialized
INFO - 2018-03-28 15:17:18 --> Output Class Initialized
INFO - 2018-03-28 15:17:18 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:18 --> Input Class Initialized
INFO - 2018-03-28 15:17:18 --> Language Class Initialized
INFO - 2018-03-28 15:17:18 --> Loader Class Initialized
INFO - 2018-03-28 15:17:18 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:18 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:18 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:18 --> Controller Class Initialized
INFO - 2018-03-28 15:17:18 --> Model Class Initialized
INFO - 2018-03-28 15:17:18 --> Model Class Initialized
INFO - 2018-03-28 15:17:18 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:18 --> Config Class Initialized
INFO - 2018-03-28 15:17:18 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:18 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:18 --> URI Class Initialized
INFO - 2018-03-28 15:17:18 --> Router Class Initialized
INFO - 2018-03-28 15:17:18 --> Output Class Initialized
INFO - 2018-03-28 15:17:18 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:18 --> Input Class Initialized
INFO - 2018-03-28 15:17:18 --> Language Class Initialized
INFO - 2018-03-28 15:17:18 --> Loader Class Initialized
INFO - 2018-03-28 15:17:18 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:18 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:19 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:19 --> Controller Class Initialized
INFO - 2018-03-28 15:17:19 --> Model Class Initialized
INFO - 2018-03-28 15:17:19 --> Model Class Initialized
INFO - 2018-03-28 15:17:19 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:19 --> Model Class Initialized
INFO - 2018-03-28 20:17:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:19 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:19 --> Total execution time: 0.1259
INFO - 2018-03-28 15:17:20 --> Config Class Initialized
INFO - 2018-03-28 15:17:20 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:20 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:20 --> URI Class Initialized
INFO - 2018-03-28 15:17:20 --> Router Class Initialized
INFO - 2018-03-28 15:17:20 --> Output Class Initialized
INFO - 2018-03-28 15:17:20 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:20 --> Input Class Initialized
INFO - 2018-03-28 15:17:20 --> Language Class Initialized
INFO - 2018-03-28 15:17:20 --> Loader Class Initialized
INFO - 2018-03-28 15:17:20 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:20 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:20 --> Controller Class Initialized
INFO - 2018-03-28 15:17:20 --> Model Class Initialized
INFO - 2018-03-28 15:17:20 --> Model Class Initialized
INFO - 2018-03-28 15:17:20 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:20 --> Config Class Initialized
INFO - 2018-03-28 15:17:20 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:20 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:20 --> URI Class Initialized
INFO - 2018-03-28 15:17:20 --> Router Class Initialized
INFO - 2018-03-28 15:17:20 --> Output Class Initialized
INFO - 2018-03-28 15:17:20 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:20 --> Input Class Initialized
INFO - 2018-03-28 15:17:20 --> Language Class Initialized
INFO - 2018-03-28 15:17:20 --> Loader Class Initialized
INFO - 2018-03-28 15:17:20 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:20 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:20 --> Controller Class Initialized
INFO - 2018-03-28 15:17:20 --> Model Class Initialized
INFO - 2018-03-28 15:17:20 --> Model Class Initialized
INFO - 2018-03-28 15:17:20 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:20 --> Model Class Initialized
INFO - 2018-03-28 20:17:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:20 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:20 --> Total execution time: 0.1813
INFO - 2018-03-28 15:17:22 --> Config Class Initialized
INFO - 2018-03-28 15:17:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:22 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:22 --> URI Class Initialized
INFO - 2018-03-28 15:17:22 --> Router Class Initialized
INFO - 2018-03-28 15:17:22 --> Output Class Initialized
INFO - 2018-03-28 15:17:22 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:22 --> Input Class Initialized
INFO - 2018-03-28 15:17:22 --> Language Class Initialized
INFO - 2018-03-28 15:17:22 --> Loader Class Initialized
INFO - 2018-03-28 15:17:22 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:22 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:22 --> Controller Class Initialized
INFO - 2018-03-28 15:17:22 --> Model Class Initialized
INFO - 2018-03-28 15:17:22 --> Model Class Initialized
INFO - 2018-03-28 15:17:22 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:22 --> Config Class Initialized
INFO - 2018-03-28 15:17:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:22 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:22 --> URI Class Initialized
INFO - 2018-03-28 15:17:22 --> Router Class Initialized
INFO - 2018-03-28 15:17:22 --> Output Class Initialized
INFO - 2018-03-28 15:17:22 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:22 --> Input Class Initialized
INFO - 2018-03-28 15:17:22 --> Language Class Initialized
INFO - 2018-03-28 15:17:22 --> Loader Class Initialized
INFO - 2018-03-28 15:17:22 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:22 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:22 --> Controller Class Initialized
INFO - 2018-03-28 15:17:22 --> Model Class Initialized
INFO - 2018-03-28 15:17:22 --> Model Class Initialized
INFO - 2018-03-28 15:17:22 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:22 --> Model Class Initialized
INFO - 2018-03-28 20:17:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:22 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:22 --> Total execution time: 0.1868
INFO - 2018-03-28 15:17:24 --> Config Class Initialized
INFO - 2018-03-28 15:17:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:24 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:24 --> URI Class Initialized
INFO - 2018-03-28 15:17:24 --> Router Class Initialized
INFO - 2018-03-28 15:17:24 --> Output Class Initialized
INFO - 2018-03-28 15:17:24 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:24 --> Input Class Initialized
INFO - 2018-03-28 15:17:24 --> Language Class Initialized
INFO - 2018-03-28 15:17:24 --> Loader Class Initialized
INFO - 2018-03-28 15:17:24 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:24 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:24 --> Controller Class Initialized
INFO - 2018-03-28 15:17:24 --> Model Class Initialized
INFO - 2018-03-28 15:17:24 --> Model Class Initialized
INFO - 2018-03-28 15:17:24 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:24 --> Config Class Initialized
INFO - 2018-03-28 15:17:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:24 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:24 --> URI Class Initialized
INFO - 2018-03-28 15:17:24 --> Router Class Initialized
INFO - 2018-03-28 15:17:24 --> Output Class Initialized
INFO - 2018-03-28 15:17:24 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:24 --> Input Class Initialized
INFO - 2018-03-28 15:17:24 --> Language Class Initialized
INFO - 2018-03-28 15:17:24 --> Loader Class Initialized
INFO - 2018-03-28 15:17:24 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:24 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:24 --> Controller Class Initialized
INFO - 2018-03-28 15:17:24 --> Model Class Initialized
INFO - 2018-03-28 15:17:24 --> Model Class Initialized
INFO - 2018-03-28 15:17:24 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:24 --> Model Class Initialized
INFO - 2018-03-28 20:17:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:24 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:24 --> Total execution time: 0.1205
INFO - 2018-03-28 15:17:27 --> Config Class Initialized
INFO - 2018-03-28 15:17:27 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:27 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:27 --> URI Class Initialized
INFO - 2018-03-28 15:17:27 --> Router Class Initialized
INFO - 2018-03-28 15:17:27 --> Output Class Initialized
INFO - 2018-03-28 15:17:27 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:27 --> Input Class Initialized
INFO - 2018-03-28 15:17:27 --> Language Class Initialized
INFO - 2018-03-28 15:17:27 --> Loader Class Initialized
INFO - 2018-03-28 15:17:27 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:27 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:27 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:27 --> Controller Class Initialized
INFO - 2018-03-28 15:17:27 --> Model Class Initialized
INFO - 2018-03-28 15:17:27 --> Model Class Initialized
INFO - 2018-03-28 15:17:27 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:27 --> Config Class Initialized
INFO - 2018-03-28 15:17:27 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:27 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:27 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:27 --> URI Class Initialized
INFO - 2018-03-28 15:17:27 --> Router Class Initialized
INFO - 2018-03-28 15:17:27 --> Output Class Initialized
INFO - 2018-03-28 15:17:27 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:27 --> Input Class Initialized
INFO - 2018-03-28 15:17:27 --> Language Class Initialized
INFO - 2018-03-28 15:17:27 --> Loader Class Initialized
INFO - 2018-03-28 15:17:27 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:27 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:27 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:27 --> Controller Class Initialized
INFO - 2018-03-28 15:17:27 --> Model Class Initialized
INFO - 2018-03-28 15:17:27 --> Model Class Initialized
INFO - 2018-03-28 15:17:27 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:27 --> Model Class Initialized
INFO - 2018-03-28 20:17:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:27 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:27 --> Total execution time: 0.1148
INFO - 2018-03-28 15:17:29 --> Config Class Initialized
INFO - 2018-03-28 15:17:29 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:29 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:29 --> URI Class Initialized
INFO - 2018-03-28 15:17:29 --> Router Class Initialized
INFO - 2018-03-28 15:17:29 --> Output Class Initialized
INFO - 2018-03-28 15:17:29 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:29 --> Input Class Initialized
INFO - 2018-03-28 15:17:29 --> Language Class Initialized
INFO - 2018-03-28 15:17:29 --> Loader Class Initialized
INFO - 2018-03-28 15:17:29 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:29 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:29 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:29 --> Controller Class Initialized
INFO - 2018-03-28 15:17:29 --> Model Class Initialized
INFO - 2018-03-28 15:17:29 --> Model Class Initialized
INFO - 2018-03-28 15:17:29 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:30 --> Config Class Initialized
INFO - 2018-03-28 15:17:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:30 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:30 --> URI Class Initialized
INFO - 2018-03-28 15:17:30 --> Router Class Initialized
INFO - 2018-03-28 15:17:30 --> Output Class Initialized
INFO - 2018-03-28 15:17:30 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:30 --> Input Class Initialized
INFO - 2018-03-28 15:17:30 --> Language Class Initialized
INFO - 2018-03-28 15:17:30 --> Loader Class Initialized
INFO - 2018-03-28 15:17:30 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:30 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:30 --> Controller Class Initialized
INFO - 2018-03-28 15:17:30 --> Model Class Initialized
INFO - 2018-03-28 15:17:30 --> Model Class Initialized
INFO - 2018-03-28 15:17:30 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:30 --> Model Class Initialized
INFO - 2018-03-28 20:17:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:30 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:30 --> Total execution time: 0.1217
INFO - 2018-03-28 15:17:32 --> Config Class Initialized
INFO - 2018-03-28 15:17:32 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:32 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:32 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:32 --> URI Class Initialized
INFO - 2018-03-28 15:17:32 --> Router Class Initialized
INFO - 2018-03-28 15:17:32 --> Output Class Initialized
INFO - 2018-03-28 15:17:32 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:32 --> Input Class Initialized
INFO - 2018-03-28 15:17:32 --> Language Class Initialized
INFO - 2018-03-28 15:17:32 --> Loader Class Initialized
INFO - 2018-03-28 15:17:32 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:32 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:32 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:32 --> Controller Class Initialized
INFO - 2018-03-28 15:17:32 --> Model Class Initialized
INFO - 2018-03-28 15:17:32 --> Model Class Initialized
INFO - 2018-03-28 15:17:32 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:32 --> Config Class Initialized
INFO - 2018-03-28 15:17:32 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:32 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:32 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:32 --> URI Class Initialized
INFO - 2018-03-28 15:17:32 --> Router Class Initialized
INFO - 2018-03-28 15:17:32 --> Output Class Initialized
INFO - 2018-03-28 15:17:32 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:32 --> Input Class Initialized
INFO - 2018-03-28 15:17:32 --> Language Class Initialized
INFO - 2018-03-28 15:17:32 --> Loader Class Initialized
INFO - 2018-03-28 15:17:32 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:32 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:32 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:32 --> Controller Class Initialized
INFO - 2018-03-28 15:17:32 --> Model Class Initialized
INFO - 2018-03-28 15:17:32 --> Model Class Initialized
INFO - 2018-03-28 15:17:32 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:32 --> Model Class Initialized
INFO - 2018-03-28 20:17:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:32 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:32 --> Total execution time: 0.1433
INFO - 2018-03-28 15:17:35 --> Config Class Initialized
INFO - 2018-03-28 15:17:35 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:35 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:35 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:36 --> URI Class Initialized
INFO - 2018-03-28 15:17:36 --> Router Class Initialized
INFO - 2018-03-28 15:17:36 --> Output Class Initialized
INFO - 2018-03-28 15:17:36 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:36 --> Input Class Initialized
INFO - 2018-03-28 15:17:36 --> Language Class Initialized
INFO - 2018-03-28 15:17:36 --> Loader Class Initialized
INFO - 2018-03-28 15:17:36 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:36 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:36 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:36 --> Controller Class Initialized
INFO - 2018-03-28 15:17:36 --> Model Class Initialized
INFO - 2018-03-28 15:17:36 --> Model Class Initialized
INFO - 2018-03-28 15:17:36 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:36 --> Config Class Initialized
INFO - 2018-03-28 15:17:36 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:36 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:36 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:36 --> URI Class Initialized
INFO - 2018-03-28 15:17:36 --> Router Class Initialized
INFO - 2018-03-28 15:17:36 --> Output Class Initialized
INFO - 2018-03-28 15:17:36 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:36 --> Input Class Initialized
INFO - 2018-03-28 15:17:36 --> Language Class Initialized
INFO - 2018-03-28 15:17:36 --> Loader Class Initialized
INFO - 2018-03-28 15:17:36 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:36 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:36 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:36 --> Controller Class Initialized
INFO - 2018-03-28 15:17:36 --> Model Class Initialized
INFO - 2018-03-28 15:17:36 --> Model Class Initialized
INFO - 2018-03-28 15:17:36 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:36 --> Model Class Initialized
INFO - 2018-03-28 20:17:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:36 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:36 --> Total execution time: 0.1182
INFO - 2018-03-28 15:17:37 --> Config Class Initialized
INFO - 2018-03-28 15:17:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:37 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:37 --> URI Class Initialized
INFO - 2018-03-28 15:17:37 --> Router Class Initialized
INFO - 2018-03-28 15:17:37 --> Output Class Initialized
INFO - 2018-03-28 15:17:37 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:37 --> Input Class Initialized
INFO - 2018-03-28 15:17:37 --> Language Class Initialized
INFO - 2018-03-28 15:17:37 --> Loader Class Initialized
INFO - 2018-03-28 15:17:37 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:37 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:37 --> Controller Class Initialized
INFO - 2018-03-28 15:17:37 --> Model Class Initialized
INFO - 2018-03-28 15:17:37 --> Model Class Initialized
INFO - 2018-03-28 15:17:37 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:37 --> Config Class Initialized
INFO - 2018-03-28 15:17:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:37 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:37 --> URI Class Initialized
INFO - 2018-03-28 15:17:37 --> Router Class Initialized
INFO - 2018-03-28 15:17:37 --> Output Class Initialized
INFO - 2018-03-28 15:17:37 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:37 --> Input Class Initialized
INFO - 2018-03-28 15:17:37 --> Language Class Initialized
INFO - 2018-03-28 15:17:37 --> Loader Class Initialized
INFO - 2018-03-28 15:17:37 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:37 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:37 --> Controller Class Initialized
INFO - 2018-03-28 15:17:37 --> Model Class Initialized
INFO - 2018-03-28 15:17:37 --> Model Class Initialized
INFO - 2018-03-28 15:17:37 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:37 --> Model Class Initialized
INFO - 2018-03-28 20:17:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:37 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:37 --> Total execution time: 0.1646
INFO - 2018-03-28 15:17:39 --> Config Class Initialized
INFO - 2018-03-28 15:17:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:39 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:39 --> URI Class Initialized
INFO - 2018-03-28 15:17:39 --> Router Class Initialized
INFO - 2018-03-28 15:17:39 --> Output Class Initialized
INFO - 2018-03-28 15:17:39 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:39 --> Input Class Initialized
INFO - 2018-03-28 15:17:39 --> Language Class Initialized
INFO - 2018-03-28 15:17:39 --> Loader Class Initialized
INFO - 2018-03-28 15:17:39 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:39 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:39 --> Controller Class Initialized
INFO - 2018-03-28 15:17:39 --> Model Class Initialized
INFO - 2018-03-28 15:17:39 --> Model Class Initialized
INFO - 2018-03-28 15:17:39 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:39 --> Config Class Initialized
INFO - 2018-03-28 15:17:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:39 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:39 --> URI Class Initialized
INFO - 2018-03-28 15:17:39 --> Router Class Initialized
INFO - 2018-03-28 15:17:39 --> Output Class Initialized
INFO - 2018-03-28 15:17:39 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:39 --> Input Class Initialized
INFO - 2018-03-28 15:17:39 --> Language Class Initialized
INFO - 2018-03-28 15:17:39 --> Loader Class Initialized
INFO - 2018-03-28 15:17:39 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:39 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:39 --> Controller Class Initialized
INFO - 2018-03-28 15:17:39 --> Model Class Initialized
INFO - 2018-03-28 15:17:39 --> Model Class Initialized
INFO - 2018-03-28 15:17:39 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:39 --> Model Class Initialized
INFO - 2018-03-28 20:17:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:39 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:39 --> Total execution time: 0.1047
INFO - 2018-03-28 15:17:41 --> Config Class Initialized
INFO - 2018-03-28 15:17:41 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:41 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:41 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:41 --> URI Class Initialized
INFO - 2018-03-28 15:17:41 --> Router Class Initialized
INFO - 2018-03-28 15:17:41 --> Output Class Initialized
INFO - 2018-03-28 15:17:41 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:41 --> Input Class Initialized
INFO - 2018-03-28 15:17:41 --> Language Class Initialized
INFO - 2018-03-28 15:17:41 --> Loader Class Initialized
INFO - 2018-03-28 15:17:41 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:41 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:41 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:41 --> Controller Class Initialized
INFO - 2018-03-28 15:17:41 --> Model Class Initialized
INFO - 2018-03-28 15:17:41 --> Model Class Initialized
INFO - 2018-03-28 15:17:41 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:17:42 --> Config Class Initialized
INFO - 2018-03-28 15:17:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:42 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:42 --> URI Class Initialized
INFO - 2018-03-28 15:17:42 --> Router Class Initialized
INFO - 2018-03-28 15:17:42 --> Output Class Initialized
INFO - 2018-03-28 15:17:42 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:42 --> Input Class Initialized
INFO - 2018-03-28 15:17:42 --> Language Class Initialized
INFO - 2018-03-28 15:17:42 --> Loader Class Initialized
INFO - 2018-03-28 15:17:42 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:42 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:42 --> Controller Class Initialized
INFO - 2018-03-28 15:17:42 --> Model Class Initialized
INFO - 2018-03-28 15:17:42 --> Model Class Initialized
INFO - 2018-03-28 15:17:42 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:42 --> Model Class Initialized
INFO - 2018-03-28 20:17:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:42 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:42 --> Total execution time: 0.1493
INFO - 2018-03-28 15:17:52 --> Config Class Initialized
INFO - 2018-03-28 15:17:52 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:17:52 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:17:52 --> Utf8 Class Initialized
INFO - 2018-03-28 15:17:52 --> URI Class Initialized
INFO - 2018-03-28 15:17:52 --> Router Class Initialized
INFO - 2018-03-28 15:17:52 --> Output Class Initialized
INFO - 2018-03-28 15:17:52 --> Security Class Initialized
DEBUG - 2018-03-28 15:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:17:52 --> Input Class Initialized
INFO - 2018-03-28 15:17:52 --> Language Class Initialized
INFO - 2018-03-28 15:17:52 --> Loader Class Initialized
INFO - 2018-03-28 15:17:52 --> Helper loaded: url_helper
INFO - 2018-03-28 15:17:52 --> Helper loaded: form_helper
INFO - 2018-03-28 15:17:52 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:17:52 --> Controller Class Initialized
INFO - 2018-03-28 15:17:52 --> Model Class Initialized
INFO - 2018-03-28 15:17:52 --> Model Class Initialized
INFO - 2018-03-28 15:17:52 --> Helper loaded: date_helper
INFO - 2018-03-28 15:17:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:17:52 --> Model Class Initialized
INFO - 2018-03-28 20:17:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:17:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:17:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:17:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:17:52 --> Final output sent to browser
DEBUG - 2018-03-28 20:17:52 --> Total execution time: 0.1010
INFO - 2018-03-28 15:18:22 --> Config Class Initialized
INFO - 2018-03-28 15:18:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:18:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:18:22 --> Utf8 Class Initialized
INFO - 2018-03-28 15:18:22 --> URI Class Initialized
INFO - 2018-03-28 15:18:22 --> Router Class Initialized
INFO - 2018-03-28 15:18:22 --> Output Class Initialized
INFO - 2018-03-28 15:18:22 --> Security Class Initialized
DEBUG - 2018-03-28 15:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:18:22 --> Input Class Initialized
INFO - 2018-03-28 15:18:22 --> Language Class Initialized
INFO - 2018-03-28 15:18:22 --> Loader Class Initialized
INFO - 2018-03-28 15:18:22 --> Helper loaded: url_helper
INFO - 2018-03-28 15:18:22 --> Helper loaded: form_helper
INFO - 2018-03-28 15:18:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:18:22 --> Controller Class Initialized
INFO - 2018-03-28 15:18:22 --> Model Class Initialized
INFO - 2018-03-28 15:18:22 --> Model Class Initialized
INFO - 2018-03-28 15:18:22 --> Helper loaded: date_helper
INFO - 2018-03-28 15:18:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:18:23 --> Model Class Initialized
INFO - 2018-03-28 20:18:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:18:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:18:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 20:18:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:18:23 --> Final output sent to browser
DEBUG - 2018-03-28 20:18:23 --> Total execution time: 0.1454
INFO - 2018-03-28 15:21:40 --> Config Class Initialized
INFO - 2018-03-28 15:21:40 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:21:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:21:40 --> Utf8 Class Initialized
INFO - 2018-03-28 15:21:40 --> URI Class Initialized
INFO - 2018-03-28 15:21:40 --> Router Class Initialized
INFO - 2018-03-28 15:21:40 --> Output Class Initialized
INFO - 2018-03-28 15:21:40 --> Security Class Initialized
DEBUG - 2018-03-28 15:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:21:40 --> Input Class Initialized
INFO - 2018-03-28 15:21:40 --> Language Class Initialized
INFO - 2018-03-28 15:21:40 --> Loader Class Initialized
INFO - 2018-03-28 15:21:40 --> Helper loaded: url_helper
INFO - 2018-03-28 15:21:40 --> Helper loaded: form_helper
INFO - 2018-03-28 15:21:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:21:40 --> Controller Class Initialized
INFO - 2018-03-28 15:21:40 --> Model Class Initialized
INFO - 2018-03-28 15:21:40 --> Model Class Initialized
INFO - 2018-03-28 15:21:40 --> Model Class Initialized
INFO - 2018-03-28 15:21:40 --> Model Class Initialized
INFO - 2018-03-28 15:21:40 --> Model Class Initialized
INFO - 2018-03-28 15:21:40 --> Helper loaded: date_helper
INFO - 2018-03-28 20:21:40 --> Model Class Initialized
INFO - 2018-03-28 20:21:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:21:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:21:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-28 20:21:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:21:40 --> Final output sent to browser
DEBUG - 2018-03-28 20:21:40 --> Total execution time: 0.0837
INFO - 2018-03-28 15:21:43 --> Config Class Initialized
INFO - 2018-03-28 15:21:43 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:21:43 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:21:43 --> Utf8 Class Initialized
INFO - 2018-03-28 15:21:43 --> URI Class Initialized
INFO - 2018-03-28 15:21:43 --> Router Class Initialized
INFO - 2018-03-28 15:21:43 --> Output Class Initialized
INFO - 2018-03-28 15:21:43 --> Security Class Initialized
DEBUG - 2018-03-28 15:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:21:43 --> Input Class Initialized
INFO - 2018-03-28 15:21:43 --> Language Class Initialized
INFO - 2018-03-28 15:21:43 --> Loader Class Initialized
INFO - 2018-03-28 15:21:43 --> Helper loaded: url_helper
INFO - 2018-03-28 15:21:43 --> Helper loaded: form_helper
INFO - 2018-03-28 15:21:43 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:21:43 --> Controller Class Initialized
INFO - 2018-03-28 15:21:43 --> Model Class Initialized
INFO - 2018-03-28 15:21:43 --> Model Class Initialized
INFO - 2018-03-28 15:21:43 --> Model Class Initialized
INFO - 2018-03-28 15:21:43 --> Model Class Initialized
INFO - 2018-03-28 15:21:43 --> Model Class Initialized
INFO - 2018-03-28 15:21:43 --> Model Class Initialized
INFO - 2018-03-28 15:21:43 --> Model Class Initialized
INFO - 2018-03-28 15:21:43 --> Model Class Initialized
INFO - 2018-03-28 15:21:43 --> Model Class Initialized
INFO - 2018-03-28 15:21:43 --> Model Class Initialized
INFO - 2018-03-28 15:21:43 --> Model Class Initialized
INFO - 2018-03-28 15:21:43 --> Model Class Initialized
INFO - 2018-03-28 15:21:43 --> Model Class Initialized
INFO - 2018-03-28 15:21:43 --> Model Class Initialized
INFO - 2018-03-28 15:21:43 --> Helper loaded: date_helper
INFO - 2018-03-28 15:21:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:21:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:21:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:21:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/create.php
INFO - 2018-03-28 20:21:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:21:43 --> Final output sent to browser
DEBUG - 2018-03-28 20:21:43 --> Total execution time: 0.3498
INFO - 2018-03-28 15:21:51 --> Config Class Initialized
INFO - 2018-03-28 15:21:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:21:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:21:51 --> Utf8 Class Initialized
INFO - 2018-03-28 15:21:51 --> URI Class Initialized
INFO - 2018-03-28 15:21:51 --> Router Class Initialized
INFO - 2018-03-28 15:21:51 --> Output Class Initialized
INFO - 2018-03-28 15:21:51 --> Security Class Initialized
DEBUG - 2018-03-28 15:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:21:51 --> Input Class Initialized
INFO - 2018-03-28 15:21:51 --> Language Class Initialized
INFO - 2018-03-28 15:21:51 --> Loader Class Initialized
INFO - 2018-03-28 15:21:51 --> Helper loaded: url_helper
INFO - 2018-03-28 15:21:51 --> Helper loaded: form_helper
INFO - 2018-03-28 15:21:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:21:51 --> Controller Class Initialized
INFO - 2018-03-28 15:21:51 --> Model Class Initialized
INFO - 2018-03-28 15:21:51 --> Model Class Initialized
INFO - 2018-03-28 15:21:51 --> Model Class Initialized
INFO - 2018-03-28 15:21:51 --> Model Class Initialized
INFO - 2018-03-28 15:21:51 --> Model Class Initialized
INFO - 2018-03-28 15:21:51 --> Model Class Initialized
INFO - 2018-03-28 15:21:51 --> Model Class Initialized
INFO - 2018-03-28 15:21:51 --> Model Class Initialized
INFO - 2018-03-28 15:21:51 --> Model Class Initialized
INFO - 2018-03-28 15:21:51 --> Model Class Initialized
INFO - 2018-03-28 15:21:51 --> Model Class Initialized
INFO - 2018-03-28 15:21:51 --> Model Class Initialized
INFO - 2018-03-28 15:21:51 --> Model Class Initialized
INFO - 2018-03-28 15:21:51 --> Model Class Initialized
INFO - 2018-03-28 15:21:51 --> Helper loaded: date_helper
INFO - 2018-03-28 15:21:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:21:52 --> Final output sent to browser
DEBUG - 2018-03-28 20:21:52 --> Total execution time: 0.3663
INFO - 2018-03-28 15:21:53 --> Config Class Initialized
INFO - 2018-03-28 15:21:53 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:21:53 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:21:53 --> Utf8 Class Initialized
INFO - 2018-03-28 15:21:53 --> URI Class Initialized
INFO - 2018-03-28 15:21:53 --> Router Class Initialized
INFO - 2018-03-28 15:21:53 --> Output Class Initialized
INFO - 2018-03-28 15:21:53 --> Security Class Initialized
DEBUG - 2018-03-28 15:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:21:53 --> Input Class Initialized
INFO - 2018-03-28 15:21:53 --> Language Class Initialized
INFO - 2018-03-28 15:21:53 --> Loader Class Initialized
INFO - 2018-03-28 15:21:53 --> Helper loaded: url_helper
INFO - 2018-03-28 15:21:53 --> Helper loaded: form_helper
INFO - 2018-03-28 15:21:53 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:21:53 --> Controller Class Initialized
INFO - 2018-03-28 15:21:53 --> Model Class Initialized
INFO - 2018-03-28 15:21:53 --> Model Class Initialized
INFO - 2018-03-28 15:21:53 --> Model Class Initialized
INFO - 2018-03-28 15:21:53 --> Model Class Initialized
INFO - 2018-03-28 15:21:53 --> Model Class Initialized
INFO - 2018-03-28 15:21:53 --> Model Class Initialized
INFO - 2018-03-28 15:21:53 --> Model Class Initialized
INFO - 2018-03-28 15:21:53 --> Model Class Initialized
INFO - 2018-03-28 15:21:53 --> Model Class Initialized
INFO - 2018-03-28 15:21:53 --> Model Class Initialized
INFO - 2018-03-28 15:21:53 --> Model Class Initialized
INFO - 2018-03-28 15:21:53 --> Model Class Initialized
INFO - 2018-03-28 15:21:53 --> Model Class Initialized
INFO - 2018-03-28 15:21:53 --> Model Class Initialized
INFO - 2018-03-28 15:21:53 --> Helper loaded: date_helper
INFO - 2018-03-28 15:21:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:21:53 --> Final output sent to browser
DEBUG - 2018-03-28 20:21:53 --> Total execution time: 0.1658
INFO - 2018-03-28 15:21:54 --> Config Class Initialized
INFO - 2018-03-28 15:21:54 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:21:54 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:21:54 --> Utf8 Class Initialized
INFO - 2018-03-28 15:21:54 --> URI Class Initialized
INFO - 2018-03-28 15:21:54 --> Router Class Initialized
INFO - 2018-03-28 15:21:54 --> Output Class Initialized
INFO - 2018-03-28 15:21:54 --> Security Class Initialized
DEBUG - 2018-03-28 15:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:21:54 --> Input Class Initialized
INFO - 2018-03-28 15:21:54 --> Language Class Initialized
INFO - 2018-03-28 15:21:54 --> Loader Class Initialized
INFO - 2018-03-28 15:21:54 --> Helper loaded: url_helper
INFO - 2018-03-28 15:21:54 --> Helper loaded: form_helper
INFO - 2018-03-28 15:21:54 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:21:54 --> Controller Class Initialized
INFO - 2018-03-28 15:21:54 --> Model Class Initialized
INFO - 2018-03-28 15:21:54 --> Model Class Initialized
INFO - 2018-03-28 15:21:54 --> Model Class Initialized
INFO - 2018-03-28 15:21:54 --> Model Class Initialized
INFO - 2018-03-28 15:21:54 --> Model Class Initialized
INFO - 2018-03-28 15:21:54 --> Model Class Initialized
INFO - 2018-03-28 15:21:54 --> Model Class Initialized
INFO - 2018-03-28 15:21:54 --> Model Class Initialized
INFO - 2018-03-28 15:21:54 --> Model Class Initialized
INFO - 2018-03-28 15:21:54 --> Model Class Initialized
INFO - 2018-03-28 15:21:54 --> Model Class Initialized
INFO - 2018-03-28 15:21:54 --> Model Class Initialized
INFO - 2018-03-28 15:21:54 --> Model Class Initialized
INFO - 2018-03-28 15:21:54 --> Model Class Initialized
INFO - 2018-03-28 15:21:54 --> Helper loaded: date_helper
INFO - 2018-03-28 15:21:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:21:54 --> Final output sent to browser
DEBUG - 2018-03-28 20:21:54 --> Total execution time: 0.1391
INFO - 2018-03-28 15:21:55 --> Config Class Initialized
INFO - 2018-03-28 15:21:55 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:21:55 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:21:55 --> Utf8 Class Initialized
INFO - 2018-03-28 15:21:55 --> URI Class Initialized
INFO - 2018-03-28 15:21:55 --> Router Class Initialized
INFO - 2018-03-28 15:21:55 --> Output Class Initialized
INFO - 2018-03-28 15:21:55 --> Security Class Initialized
DEBUG - 2018-03-28 15:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:21:55 --> Input Class Initialized
INFO - 2018-03-28 15:21:55 --> Language Class Initialized
INFO - 2018-03-28 15:21:55 --> Loader Class Initialized
INFO - 2018-03-28 15:21:55 --> Helper loaded: url_helper
INFO - 2018-03-28 15:21:55 --> Helper loaded: form_helper
INFO - 2018-03-28 15:21:55 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:21:55 --> Controller Class Initialized
INFO - 2018-03-28 15:21:55 --> Model Class Initialized
INFO - 2018-03-28 15:21:55 --> Model Class Initialized
INFO - 2018-03-28 15:21:55 --> Model Class Initialized
INFO - 2018-03-28 15:21:55 --> Model Class Initialized
INFO - 2018-03-28 15:21:55 --> Model Class Initialized
INFO - 2018-03-28 15:21:55 --> Model Class Initialized
INFO - 2018-03-28 15:21:55 --> Model Class Initialized
INFO - 2018-03-28 15:21:55 --> Model Class Initialized
INFO - 2018-03-28 15:21:55 --> Model Class Initialized
INFO - 2018-03-28 15:21:55 --> Model Class Initialized
INFO - 2018-03-28 15:21:55 --> Model Class Initialized
INFO - 2018-03-28 15:21:55 --> Model Class Initialized
INFO - 2018-03-28 15:21:55 --> Model Class Initialized
INFO - 2018-03-28 15:21:55 --> Model Class Initialized
INFO - 2018-03-28 15:21:55 --> Helper loaded: date_helper
INFO - 2018-03-28 15:21:55 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:21:55 --> Final output sent to browser
DEBUG - 2018-03-28 20:21:55 --> Total execution time: 0.1246
INFO - 2018-03-28 15:21:56 --> Config Class Initialized
INFO - 2018-03-28 15:21:56 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:21:56 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:21:56 --> Utf8 Class Initialized
INFO - 2018-03-28 15:21:56 --> URI Class Initialized
INFO - 2018-03-28 15:21:56 --> Router Class Initialized
INFO - 2018-03-28 15:21:56 --> Output Class Initialized
INFO - 2018-03-28 15:21:56 --> Security Class Initialized
DEBUG - 2018-03-28 15:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:21:56 --> Input Class Initialized
INFO - 2018-03-28 15:21:56 --> Language Class Initialized
INFO - 2018-03-28 15:21:56 --> Loader Class Initialized
INFO - 2018-03-28 15:21:56 --> Helper loaded: url_helper
INFO - 2018-03-28 15:21:56 --> Helper loaded: form_helper
INFO - 2018-03-28 15:21:56 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:21:56 --> Controller Class Initialized
INFO - 2018-03-28 15:21:56 --> Model Class Initialized
INFO - 2018-03-28 15:21:56 --> Model Class Initialized
INFO - 2018-03-28 15:21:56 --> Model Class Initialized
INFO - 2018-03-28 15:21:56 --> Model Class Initialized
INFO - 2018-03-28 15:21:56 --> Model Class Initialized
INFO - 2018-03-28 15:21:56 --> Model Class Initialized
INFO - 2018-03-28 15:21:56 --> Model Class Initialized
INFO - 2018-03-28 15:21:56 --> Model Class Initialized
INFO - 2018-03-28 15:21:56 --> Model Class Initialized
INFO - 2018-03-28 15:21:56 --> Model Class Initialized
INFO - 2018-03-28 15:21:56 --> Model Class Initialized
INFO - 2018-03-28 15:21:56 --> Model Class Initialized
INFO - 2018-03-28 15:21:56 --> Model Class Initialized
INFO - 2018-03-28 15:21:56 --> Model Class Initialized
INFO - 2018-03-28 15:21:56 --> Helper loaded: date_helper
INFO - 2018-03-28 15:21:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:21:56 --> Final output sent to browser
DEBUG - 2018-03-28 20:21:56 --> Total execution time: 0.1598
INFO - 2018-03-28 15:22:04 --> Config Class Initialized
INFO - 2018-03-28 15:22:04 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:22:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:22:04 --> Utf8 Class Initialized
INFO - 2018-03-28 15:22:04 --> URI Class Initialized
INFO - 2018-03-28 15:22:04 --> Router Class Initialized
INFO - 2018-03-28 15:22:04 --> Output Class Initialized
INFO - 2018-03-28 15:22:04 --> Security Class Initialized
DEBUG - 2018-03-28 15:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:22:04 --> Input Class Initialized
INFO - 2018-03-28 15:22:04 --> Language Class Initialized
INFO - 2018-03-28 15:22:04 --> Loader Class Initialized
INFO - 2018-03-28 15:22:04 --> Helper loaded: url_helper
INFO - 2018-03-28 15:22:04 --> Helper loaded: form_helper
INFO - 2018-03-28 15:22:04 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:22:04 --> Controller Class Initialized
INFO - 2018-03-28 15:22:04 --> Model Class Initialized
INFO - 2018-03-28 15:22:04 --> Model Class Initialized
INFO - 2018-03-28 15:22:04 --> Model Class Initialized
INFO - 2018-03-28 15:22:04 --> Model Class Initialized
INFO - 2018-03-28 15:22:04 --> Model Class Initialized
INFO - 2018-03-28 15:22:04 --> Model Class Initialized
INFO - 2018-03-28 15:22:04 --> Model Class Initialized
INFO - 2018-03-28 15:22:04 --> Model Class Initialized
INFO - 2018-03-28 15:22:04 --> Model Class Initialized
INFO - 2018-03-28 15:22:04 --> Model Class Initialized
INFO - 2018-03-28 15:22:04 --> Model Class Initialized
INFO - 2018-03-28 15:22:04 --> Model Class Initialized
INFO - 2018-03-28 15:22:04 --> Model Class Initialized
INFO - 2018-03-28 15:22:04 --> Model Class Initialized
INFO - 2018-03-28 15:22:04 --> Helper loaded: date_helper
INFO - 2018-03-28 15:22:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:22:04 --> Final output sent to browser
DEBUG - 2018-03-28 20:22:04 --> Total execution time: 0.1839
INFO - 2018-03-28 15:22:08 --> Config Class Initialized
INFO - 2018-03-28 15:22:08 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:22:08 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:22:08 --> Utf8 Class Initialized
INFO - 2018-03-28 15:22:08 --> URI Class Initialized
INFO - 2018-03-28 15:22:08 --> Router Class Initialized
INFO - 2018-03-28 15:22:08 --> Output Class Initialized
INFO - 2018-03-28 15:22:08 --> Security Class Initialized
DEBUG - 2018-03-28 15:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:22:09 --> Input Class Initialized
INFO - 2018-03-28 15:22:09 --> Language Class Initialized
INFO - 2018-03-28 15:22:09 --> Loader Class Initialized
INFO - 2018-03-28 15:22:09 --> Helper loaded: url_helper
INFO - 2018-03-28 15:22:09 --> Helper loaded: form_helper
INFO - 2018-03-28 15:22:09 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:22:09 --> Controller Class Initialized
INFO - 2018-03-28 15:22:09 --> Model Class Initialized
INFO - 2018-03-28 15:22:09 --> Model Class Initialized
INFO - 2018-03-28 15:22:09 --> Model Class Initialized
INFO - 2018-03-28 15:22:09 --> Model Class Initialized
INFO - 2018-03-28 15:22:09 --> Model Class Initialized
INFO - 2018-03-28 15:22:09 --> Model Class Initialized
INFO - 2018-03-28 15:22:09 --> Model Class Initialized
INFO - 2018-03-28 15:22:09 --> Model Class Initialized
INFO - 2018-03-28 15:22:09 --> Model Class Initialized
INFO - 2018-03-28 15:22:09 --> Model Class Initialized
INFO - 2018-03-28 15:22:09 --> Model Class Initialized
INFO - 2018-03-28 15:22:09 --> Model Class Initialized
INFO - 2018-03-28 15:22:09 --> Model Class Initialized
INFO - 2018-03-28 15:22:09 --> Model Class Initialized
INFO - 2018-03-28 15:22:09 --> Helper loaded: date_helper
INFO - 2018-03-28 15:22:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:22:09 --> Final output sent to browser
DEBUG - 2018-03-28 20:22:09 --> Total execution time: 0.1559
INFO - 2018-03-28 15:22:10 --> Config Class Initialized
INFO - 2018-03-28 15:22:10 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:22:10 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:22:10 --> Utf8 Class Initialized
INFO - 2018-03-28 15:22:10 --> URI Class Initialized
INFO - 2018-03-28 15:22:10 --> Router Class Initialized
INFO - 2018-03-28 15:22:10 --> Output Class Initialized
INFO - 2018-03-28 15:22:10 --> Security Class Initialized
DEBUG - 2018-03-28 15:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:22:10 --> Input Class Initialized
INFO - 2018-03-28 15:22:10 --> Language Class Initialized
INFO - 2018-03-28 15:22:10 --> Loader Class Initialized
INFO - 2018-03-28 15:22:10 --> Helper loaded: url_helper
INFO - 2018-03-28 15:22:10 --> Helper loaded: form_helper
INFO - 2018-03-28 15:22:10 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:22:10 --> Controller Class Initialized
INFO - 2018-03-28 15:22:10 --> Model Class Initialized
INFO - 2018-03-28 15:22:10 --> Model Class Initialized
INFO - 2018-03-28 15:22:10 --> Model Class Initialized
INFO - 2018-03-28 15:22:10 --> Model Class Initialized
INFO - 2018-03-28 15:22:10 --> Model Class Initialized
INFO - 2018-03-28 15:22:10 --> Model Class Initialized
INFO - 2018-03-28 15:22:10 --> Model Class Initialized
INFO - 2018-03-28 15:22:10 --> Model Class Initialized
INFO - 2018-03-28 15:22:10 --> Model Class Initialized
INFO - 2018-03-28 15:22:10 --> Model Class Initialized
INFO - 2018-03-28 15:22:10 --> Model Class Initialized
INFO - 2018-03-28 15:22:10 --> Model Class Initialized
INFO - 2018-03-28 15:22:10 --> Model Class Initialized
INFO - 2018-03-28 15:22:10 --> Model Class Initialized
INFO - 2018-03-28 15:22:10 --> Helper loaded: date_helper
INFO - 2018-03-28 15:22:10 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:22:10 --> Final output sent to browser
DEBUG - 2018-03-28 20:22:10 --> Total execution time: 0.2109
INFO - 2018-03-28 15:22:13 --> Config Class Initialized
INFO - 2018-03-28 15:22:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:22:13 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:22:13 --> Utf8 Class Initialized
INFO - 2018-03-28 15:22:13 --> URI Class Initialized
INFO - 2018-03-28 15:22:13 --> Router Class Initialized
INFO - 2018-03-28 15:22:13 --> Output Class Initialized
INFO - 2018-03-28 15:22:13 --> Security Class Initialized
DEBUG - 2018-03-28 15:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:22:13 --> Input Class Initialized
INFO - 2018-03-28 15:22:13 --> Language Class Initialized
INFO - 2018-03-28 15:22:13 --> Loader Class Initialized
INFO - 2018-03-28 15:22:13 --> Helper loaded: url_helper
INFO - 2018-03-28 15:22:13 --> Helper loaded: form_helper
INFO - 2018-03-28 15:22:13 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:22:13 --> Controller Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Helper loaded: date_helper
INFO - 2018-03-28 15:22:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:22:13 --> Final output sent to browser
DEBUG - 2018-03-28 20:22:13 --> Total execution time: 0.1611
INFO - 2018-03-28 15:22:13 --> Config Class Initialized
INFO - 2018-03-28 15:22:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:22:13 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:22:13 --> Utf8 Class Initialized
INFO - 2018-03-28 15:22:13 --> URI Class Initialized
INFO - 2018-03-28 15:22:13 --> Router Class Initialized
INFO - 2018-03-28 15:22:13 --> Output Class Initialized
INFO - 2018-03-28 15:22:13 --> Security Class Initialized
DEBUG - 2018-03-28 15:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:22:13 --> Input Class Initialized
INFO - 2018-03-28 15:22:13 --> Language Class Initialized
INFO - 2018-03-28 15:22:13 --> Loader Class Initialized
INFO - 2018-03-28 15:22:13 --> Helper loaded: url_helper
INFO - 2018-03-28 15:22:13 --> Helper loaded: form_helper
INFO - 2018-03-28 15:22:13 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:22:13 --> Controller Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Model Class Initialized
INFO - 2018-03-28 15:22:13 --> Helper loaded: date_helper
INFO - 2018-03-28 15:22:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:22:13 --> Final output sent to browser
DEBUG - 2018-03-28 20:22:13 --> Total execution time: 0.1648
INFO - 2018-03-28 15:22:15 --> Config Class Initialized
INFO - 2018-03-28 15:22:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:22:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:22:15 --> Utf8 Class Initialized
INFO - 2018-03-28 15:22:15 --> URI Class Initialized
INFO - 2018-03-28 15:22:15 --> Router Class Initialized
INFO - 2018-03-28 15:22:15 --> Output Class Initialized
INFO - 2018-03-28 15:22:15 --> Security Class Initialized
DEBUG - 2018-03-28 15:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:22:15 --> Input Class Initialized
INFO - 2018-03-28 15:22:15 --> Language Class Initialized
INFO - 2018-03-28 15:22:15 --> Loader Class Initialized
INFO - 2018-03-28 15:22:15 --> Helper loaded: url_helper
INFO - 2018-03-28 15:22:15 --> Helper loaded: form_helper
INFO - 2018-03-28 15:22:15 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:22:15 --> Controller Class Initialized
INFO - 2018-03-28 15:22:15 --> Model Class Initialized
INFO - 2018-03-28 15:22:15 --> Model Class Initialized
INFO - 2018-03-28 15:22:15 --> Model Class Initialized
INFO - 2018-03-28 15:22:15 --> Model Class Initialized
INFO - 2018-03-28 15:22:15 --> Model Class Initialized
INFO - 2018-03-28 15:22:15 --> Model Class Initialized
INFO - 2018-03-28 15:22:15 --> Model Class Initialized
INFO - 2018-03-28 15:22:15 --> Model Class Initialized
INFO - 2018-03-28 15:22:15 --> Model Class Initialized
INFO - 2018-03-28 15:22:15 --> Model Class Initialized
INFO - 2018-03-28 15:22:15 --> Model Class Initialized
INFO - 2018-03-28 15:22:15 --> Model Class Initialized
INFO - 2018-03-28 15:22:15 --> Model Class Initialized
INFO - 2018-03-28 15:22:15 --> Model Class Initialized
INFO - 2018-03-28 15:22:15 --> Helper loaded: date_helper
INFO - 2018-03-28 15:22:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:22:15 --> Final output sent to browser
DEBUG - 2018-03-28 20:22:15 --> Total execution time: 0.1666
INFO - 2018-03-28 15:22:20 --> Config Class Initialized
INFO - 2018-03-28 15:22:20 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:22:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:22:20 --> Utf8 Class Initialized
INFO - 2018-03-28 15:22:20 --> URI Class Initialized
INFO - 2018-03-28 15:22:20 --> Router Class Initialized
INFO - 2018-03-28 15:22:20 --> Output Class Initialized
INFO - 2018-03-28 15:22:20 --> Security Class Initialized
DEBUG - 2018-03-28 15:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:22:20 --> Input Class Initialized
INFO - 2018-03-28 15:22:20 --> Language Class Initialized
INFO - 2018-03-28 15:22:20 --> Loader Class Initialized
INFO - 2018-03-28 15:22:20 --> Helper loaded: url_helper
INFO - 2018-03-28 15:22:20 --> Helper loaded: form_helper
INFO - 2018-03-28 15:22:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:22:20 --> Controller Class Initialized
INFO - 2018-03-28 15:22:20 --> Model Class Initialized
INFO - 2018-03-28 15:22:20 --> Model Class Initialized
INFO - 2018-03-28 15:22:20 --> Model Class Initialized
INFO - 2018-03-28 15:22:20 --> Model Class Initialized
INFO - 2018-03-28 15:22:20 --> Model Class Initialized
INFO - 2018-03-28 15:22:20 --> Model Class Initialized
INFO - 2018-03-28 15:22:20 --> Model Class Initialized
INFO - 2018-03-28 15:22:20 --> Model Class Initialized
INFO - 2018-03-28 15:22:20 --> Model Class Initialized
INFO - 2018-03-28 15:22:20 --> Model Class Initialized
INFO - 2018-03-28 15:22:20 --> Model Class Initialized
INFO - 2018-03-28 15:22:20 --> Model Class Initialized
INFO - 2018-03-28 15:22:20 --> Model Class Initialized
INFO - 2018-03-28 15:22:20 --> Model Class Initialized
INFO - 2018-03-28 15:22:20 --> Helper loaded: date_helper
INFO - 2018-03-28 15:22:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:22:20 --> Final output sent to browser
DEBUG - 2018-03-28 20:22:20 --> Total execution time: 0.1562
INFO - 2018-03-28 15:22:22 --> Config Class Initialized
INFO - 2018-03-28 15:22:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:22:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:22:22 --> Utf8 Class Initialized
INFO - 2018-03-28 15:22:22 --> URI Class Initialized
INFO - 2018-03-28 15:22:22 --> Router Class Initialized
INFO - 2018-03-28 15:22:22 --> Output Class Initialized
INFO - 2018-03-28 15:22:22 --> Security Class Initialized
DEBUG - 2018-03-28 15:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:22:22 --> Input Class Initialized
INFO - 2018-03-28 15:22:22 --> Language Class Initialized
INFO - 2018-03-28 15:22:22 --> Loader Class Initialized
INFO - 2018-03-28 15:22:22 --> Helper loaded: url_helper
INFO - 2018-03-28 15:22:22 --> Helper loaded: form_helper
INFO - 2018-03-28 15:22:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:22:22 --> Controller Class Initialized
INFO - 2018-03-28 15:22:22 --> Model Class Initialized
INFO - 2018-03-28 15:22:22 --> Model Class Initialized
INFO - 2018-03-28 15:22:22 --> Model Class Initialized
INFO - 2018-03-28 15:22:22 --> Model Class Initialized
INFO - 2018-03-28 15:22:22 --> Model Class Initialized
INFO - 2018-03-28 15:22:22 --> Model Class Initialized
INFO - 2018-03-28 15:22:22 --> Model Class Initialized
INFO - 2018-03-28 15:22:22 --> Model Class Initialized
INFO - 2018-03-28 15:22:22 --> Model Class Initialized
INFO - 2018-03-28 15:22:22 --> Model Class Initialized
INFO - 2018-03-28 15:22:22 --> Model Class Initialized
INFO - 2018-03-28 15:22:22 --> Model Class Initialized
INFO - 2018-03-28 15:22:22 --> Model Class Initialized
INFO - 2018-03-28 15:22:22 --> Model Class Initialized
INFO - 2018-03-28 15:22:22 --> Helper loaded: date_helper
INFO - 2018-03-28 15:22:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:22:22 --> Final output sent to browser
DEBUG - 2018-03-28 20:22:22 --> Total execution time: 0.1327
INFO - 2018-03-28 15:22:55 --> Config Class Initialized
INFO - 2018-03-28 15:22:55 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:22:55 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:22:55 --> Utf8 Class Initialized
INFO - 2018-03-28 15:22:55 --> URI Class Initialized
INFO - 2018-03-28 15:22:55 --> Router Class Initialized
INFO - 2018-03-28 15:22:55 --> Output Class Initialized
INFO - 2018-03-28 15:22:55 --> Security Class Initialized
DEBUG - 2018-03-28 15:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:22:55 --> Input Class Initialized
INFO - 2018-03-28 15:22:55 --> Language Class Initialized
INFO - 2018-03-28 15:22:55 --> Loader Class Initialized
INFO - 2018-03-28 15:22:55 --> Helper loaded: url_helper
INFO - 2018-03-28 15:22:55 --> Helper loaded: form_helper
INFO - 2018-03-28 15:22:55 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:22:55 --> Controller Class Initialized
INFO - 2018-03-28 15:22:55 --> Model Class Initialized
INFO - 2018-03-28 15:22:55 --> Model Class Initialized
INFO - 2018-03-28 15:22:55 --> Model Class Initialized
INFO - 2018-03-28 15:22:55 --> Model Class Initialized
INFO - 2018-03-28 15:22:55 --> Model Class Initialized
INFO - 2018-03-28 15:22:55 --> Model Class Initialized
INFO - 2018-03-28 15:22:55 --> Model Class Initialized
INFO - 2018-03-28 15:22:55 --> Model Class Initialized
INFO - 2018-03-28 15:22:55 --> Model Class Initialized
INFO - 2018-03-28 15:22:55 --> Model Class Initialized
INFO - 2018-03-28 15:22:55 --> Model Class Initialized
INFO - 2018-03-28 15:22:55 --> Model Class Initialized
INFO - 2018-03-28 15:22:55 --> Model Class Initialized
INFO - 2018-03-28 15:22:55 --> Model Class Initialized
INFO - 2018-03-28 15:22:55 --> Helper loaded: date_helper
INFO - 2018-03-28 15:22:55 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:22:55 --> Final output sent to browser
DEBUG - 2018-03-28 20:22:55 --> Total execution time: 0.1657
INFO - 2018-03-28 15:22:56 --> Config Class Initialized
INFO - 2018-03-28 15:22:56 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:22:56 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:22:56 --> Utf8 Class Initialized
INFO - 2018-03-28 15:22:56 --> URI Class Initialized
INFO - 2018-03-28 15:22:56 --> Router Class Initialized
INFO - 2018-03-28 15:22:56 --> Output Class Initialized
INFO - 2018-03-28 15:22:56 --> Security Class Initialized
DEBUG - 2018-03-28 15:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:22:56 --> Input Class Initialized
INFO - 2018-03-28 15:22:56 --> Language Class Initialized
INFO - 2018-03-28 15:22:56 --> Loader Class Initialized
INFO - 2018-03-28 15:22:56 --> Helper loaded: url_helper
INFO - 2018-03-28 15:22:56 --> Helper loaded: form_helper
INFO - 2018-03-28 15:22:56 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:22:56 --> Controller Class Initialized
INFO - 2018-03-28 15:22:56 --> Model Class Initialized
INFO - 2018-03-28 15:22:56 --> Model Class Initialized
INFO - 2018-03-28 15:22:56 --> Model Class Initialized
INFO - 2018-03-28 15:22:56 --> Model Class Initialized
INFO - 2018-03-28 15:22:56 --> Model Class Initialized
INFO - 2018-03-28 15:22:56 --> Model Class Initialized
INFO - 2018-03-28 15:22:56 --> Model Class Initialized
INFO - 2018-03-28 15:22:56 --> Model Class Initialized
INFO - 2018-03-28 15:22:56 --> Model Class Initialized
INFO - 2018-03-28 15:22:56 --> Model Class Initialized
INFO - 2018-03-28 15:22:56 --> Model Class Initialized
INFO - 2018-03-28 15:22:56 --> Model Class Initialized
INFO - 2018-03-28 15:22:56 --> Model Class Initialized
INFO - 2018-03-28 15:22:56 --> Model Class Initialized
INFO - 2018-03-28 15:22:56 --> Helper loaded: date_helper
INFO - 2018-03-28 15:22:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:22:56 --> Final output sent to browser
DEBUG - 2018-03-28 20:22:56 --> Total execution time: 0.2137
INFO - 2018-03-28 15:22:56 --> Config Class Initialized
INFO - 2018-03-28 15:22:56 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:22:56 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:22:56 --> Utf8 Class Initialized
INFO - 2018-03-28 15:22:56 --> URI Class Initialized
INFO - 2018-03-28 15:22:56 --> Router Class Initialized
INFO - 2018-03-28 15:22:56 --> Output Class Initialized
INFO - 2018-03-28 15:22:56 --> Security Class Initialized
DEBUG - 2018-03-28 15:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:22:56 --> Input Class Initialized
INFO - 2018-03-28 15:22:56 --> Language Class Initialized
INFO - 2018-03-28 15:22:57 --> Loader Class Initialized
INFO - 2018-03-28 15:22:57 --> Helper loaded: url_helper
INFO - 2018-03-28 15:22:57 --> Helper loaded: form_helper
INFO - 2018-03-28 15:22:57 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:22:57 --> Controller Class Initialized
INFO - 2018-03-28 15:22:57 --> Model Class Initialized
INFO - 2018-03-28 15:22:57 --> Model Class Initialized
INFO - 2018-03-28 15:22:57 --> Model Class Initialized
INFO - 2018-03-28 15:22:57 --> Model Class Initialized
INFO - 2018-03-28 15:22:57 --> Model Class Initialized
INFO - 2018-03-28 15:22:57 --> Model Class Initialized
INFO - 2018-03-28 15:22:57 --> Model Class Initialized
INFO - 2018-03-28 15:22:57 --> Model Class Initialized
INFO - 2018-03-28 15:22:57 --> Model Class Initialized
INFO - 2018-03-28 15:22:57 --> Model Class Initialized
INFO - 2018-03-28 15:22:57 --> Model Class Initialized
INFO - 2018-03-28 15:22:57 --> Model Class Initialized
INFO - 2018-03-28 15:22:57 --> Model Class Initialized
INFO - 2018-03-28 15:22:57 --> Model Class Initialized
INFO - 2018-03-28 15:22:57 --> Helper loaded: date_helper
INFO - 2018-03-28 15:22:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:22:57 --> Final output sent to browser
DEBUG - 2018-03-28 20:22:57 --> Total execution time: 0.1496
INFO - 2018-03-28 15:23:31 --> Config Class Initialized
INFO - 2018-03-28 15:23:31 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:23:31 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:23:31 --> Utf8 Class Initialized
INFO - 2018-03-28 15:23:31 --> URI Class Initialized
INFO - 2018-03-28 15:23:31 --> Router Class Initialized
INFO - 2018-03-28 15:23:31 --> Output Class Initialized
INFO - 2018-03-28 15:23:31 --> Security Class Initialized
DEBUG - 2018-03-28 15:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:23:31 --> Input Class Initialized
INFO - 2018-03-28 15:23:31 --> Language Class Initialized
INFO - 2018-03-28 15:23:31 --> Loader Class Initialized
INFO - 2018-03-28 15:23:31 --> Helper loaded: url_helper
INFO - 2018-03-28 15:23:31 --> Helper loaded: form_helper
INFO - 2018-03-28 15:23:31 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:23:31 --> Controller Class Initialized
INFO - 2018-03-28 15:23:31 --> Model Class Initialized
INFO - 2018-03-28 15:23:31 --> Model Class Initialized
INFO - 2018-03-28 15:23:31 --> Model Class Initialized
INFO - 2018-03-28 15:23:31 --> Model Class Initialized
INFO - 2018-03-28 15:23:31 --> Model Class Initialized
INFO - 2018-03-28 15:23:31 --> Model Class Initialized
INFO - 2018-03-28 15:23:31 --> Model Class Initialized
INFO - 2018-03-28 15:23:31 --> Model Class Initialized
INFO - 2018-03-28 15:23:31 --> Model Class Initialized
INFO - 2018-03-28 15:23:31 --> Model Class Initialized
INFO - 2018-03-28 15:23:31 --> Model Class Initialized
INFO - 2018-03-28 15:23:31 --> Model Class Initialized
INFO - 2018-03-28 15:23:31 --> Model Class Initialized
INFO - 2018-03-28 15:23:31 --> Model Class Initialized
INFO - 2018-03-28 15:23:31 --> Helper loaded: date_helper
INFO - 2018-03-28 15:23:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:23:31 --> Final output sent to browser
DEBUG - 2018-03-28 20:23:31 --> Total execution time: 0.1816
INFO - 2018-03-28 15:23:33 --> Config Class Initialized
INFO - 2018-03-28 15:23:33 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:23:33 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:23:33 --> Utf8 Class Initialized
INFO - 2018-03-28 15:23:33 --> URI Class Initialized
INFO - 2018-03-28 15:23:33 --> Router Class Initialized
INFO - 2018-03-28 15:23:33 --> Output Class Initialized
INFO - 2018-03-28 15:23:33 --> Security Class Initialized
DEBUG - 2018-03-28 15:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:23:33 --> Input Class Initialized
INFO - 2018-03-28 15:23:33 --> Language Class Initialized
INFO - 2018-03-28 15:23:33 --> Loader Class Initialized
INFO - 2018-03-28 15:23:33 --> Helper loaded: url_helper
INFO - 2018-03-28 15:23:33 --> Helper loaded: form_helper
INFO - 2018-03-28 15:23:33 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:23:33 --> Controller Class Initialized
INFO - 2018-03-28 15:23:33 --> Model Class Initialized
INFO - 2018-03-28 15:23:33 --> Model Class Initialized
INFO - 2018-03-28 15:23:33 --> Model Class Initialized
INFO - 2018-03-28 15:23:33 --> Model Class Initialized
INFO - 2018-03-28 15:23:33 --> Model Class Initialized
INFO - 2018-03-28 15:23:33 --> Model Class Initialized
INFO - 2018-03-28 15:23:33 --> Model Class Initialized
INFO - 2018-03-28 15:23:33 --> Model Class Initialized
INFO - 2018-03-28 15:23:33 --> Model Class Initialized
INFO - 2018-03-28 15:23:33 --> Model Class Initialized
INFO - 2018-03-28 15:23:33 --> Model Class Initialized
INFO - 2018-03-28 15:23:33 --> Model Class Initialized
INFO - 2018-03-28 15:23:33 --> Model Class Initialized
INFO - 2018-03-28 15:23:33 --> Model Class Initialized
INFO - 2018-03-28 15:23:33 --> Helper loaded: date_helper
INFO - 2018-03-28 15:23:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:23:33 --> Final output sent to browser
DEBUG - 2018-03-28 20:23:33 --> Total execution time: 0.1768
INFO - 2018-03-28 15:23:40 --> Config Class Initialized
INFO - 2018-03-28 15:23:40 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:23:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:23:40 --> Utf8 Class Initialized
INFO - 2018-03-28 15:23:40 --> URI Class Initialized
INFO - 2018-03-28 15:23:40 --> Router Class Initialized
INFO - 2018-03-28 15:23:40 --> Output Class Initialized
INFO - 2018-03-28 15:23:40 --> Security Class Initialized
DEBUG - 2018-03-28 15:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:23:40 --> Input Class Initialized
INFO - 2018-03-28 15:23:40 --> Language Class Initialized
INFO - 2018-03-28 15:23:40 --> Loader Class Initialized
INFO - 2018-03-28 15:23:40 --> Helper loaded: url_helper
INFO - 2018-03-28 15:23:40 --> Helper loaded: form_helper
INFO - 2018-03-28 15:23:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:23:40 --> Controller Class Initialized
INFO - 2018-03-28 15:23:40 --> Model Class Initialized
INFO - 2018-03-28 15:23:40 --> Model Class Initialized
INFO - 2018-03-28 15:23:40 --> Model Class Initialized
INFO - 2018-03-28 15:23:40 --> Model Class Initialized
INFO - 2018-03-28 15:23:40 --> Model Class Initialized
INFO - 2018-03-28 15:23:40 --> Model Class Initialized
INFO - 2018-03-28 15:23:40 --> Model Class Initialized
INFO - 2018-03-28 15:23:40 --> Model Class Initialized
INFO - 2018-03-28 15:23:40 --> Model Class Initialized
INFO - 2018-03-28 15:23:40 --> Model Class Initialized
INFO - 2018-03-28 15:23:40 --> Model Class Initialized
INFO - 2018-03-28 15:23:40 --> Model Class Initialized
INFO - 2018-03-28 15:23:40 --> Model Class Initialized
INFO - 2018-03-28 15:23:40 --> Model Class Initialized
INFO - 2018-03-28 15:23:40 --> Helper loaded: date_helper
INFO - 2018-03-28 15:23:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:23:40 --> Final output sent to browser
DEBUG - 2018-03-28 20:23:40 --> Total execution time: 0.1303
INFO - 2018-03-28 15:23:43 --> Config Class Initialized
INFO - 2018-03-28 15:23:43 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:23:43 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:23:43 --> Utf8 Class Initialized
INFO - 2018-03-28 15:23:43 --> URI Class Initialized
INFO - 2018-03-28 15:23:43 --> Router Class Initialized
INFO - 2018-03-28 15:23:43 --> Output Class Initialized
INFO - 2018-03-28 15:23:43 --> Security Class Initialized
DEBUG - 2018-03-28 15:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:23:43 --> Input Class Initialized
INFO - 2018-03-28 15:23:43 --> Language Class Initialized
INFO - 2018-03-28 15:23:43 --> Loader Class Initialized
INFO - 2018-03-28 15:23:43 --> Helper loaded: url_helper
INFO - 2018-03-28 15:23:43 --> Helper loaded: form_helper
INFO - 2018-03-28 15:23:43 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:23:43 --> Controller Class Initialized
INFO - 2018-03-28 15:23:43 --> Model Class Initialized
INFO - 2018-03-28 15:23:43 --> Model Class Initialized
INFO - 2018-03-28 15:23:43 --> Model Class Initialized
INFO - 2018-03-28 15:23:43 --> Model Class Initialized
INFO - 2018-03-28 15:23:43 --> Model Class Initialized
INFO - 2018-03-28 15:23:43 --> Model Class Initialized
INFO - 2018-03-28 15:23:43 --> Model Class Initialized
INFO - 2018-03-28 15:23:43 --> Model Class Initialized
INFO - 2018-03-28 15:23:43 --> Model Class Initialized
INFO - 2018-03-28 15:23:43 --> Model Class Initialized
INFO - 2018-03-28 15:23:43 --> Model Class Initialized
INFO - 2018-03-28 15:23:43 --> Model Class Initialized
INFO - 2018-03-28 15:23:43 --> Model Class Initialized
INFO - 2018-03-28 15:23:43 --> Model Class Initialized
INFO - 2018-03-28 15:23:43 --> Helper loaded: date_helper
INFO - 2018-03-28 15:23:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:23:43 --> Final output sent to browser
DEBUG - 2018-03-28 20:23:43 --> Total execution time: 0.1822
INFO - 2018-03-28 15:23:49 --> Config Class Initialized
INFO - 2018-03-28 15:23:49 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:23:49 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:23:49 --> Utf8 Class Initialized
INFO - 2018-03-28 15:23:49 --> URI Class Initialized
INFO - 2018-03-28 15:23:49 --> Router Class Initialized
INFO - 2018-03-28 15:23:49 --> Output Class Initialized
INFO - 2018-03-28 15:23:49 --> Security Class Initialized
DEBUG - 2018-03-28 15:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:23:49 --> Input Class Initialized
INFO - 2018-03-28 15:23:49 --> Language Class Initialized
INFO - 2018-03-28 15:23:49 --> Loader Class Initialized
INFO - 2018-03-28 15:23:49 --> Helper loaded: url_helper
INFO - 2018-03-28 15:23:49 --> Helper loaded: form_helper
INFO - 2018-03-28 15:23:49 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:23:50 --> Controller Class Initialized
INFO - 2018-03-28 15:23:50 --> Model Class Initialized
INFO - 2018-03-28 15:23:50 --> Model Class Initialized
INFO - 2018-03-28 15:23:50 --> Model Class Initialized
INFO - 2018-03-28 15:23:50 --> Model Class Initialized
INFO - 2018-03-28 15:23:50 --> Model Class Initialized
INFO - 2018-03-28 15:23:50 --> Model Class Initialized
INFO - 2018-03-28 15:23:50 --> Model Class Initialized
INFO - 2018-03-28 15:23:50 --> Model Class Initialized
INFO - 2018-03-28 15:23:50 --> Model Class Initialized
INFO - 2018-03-28 15:23:50 --> Model Class Initialized
INFO - 2018-03-28 15:23:50 --> Model Class Initialized
INFO - 2018-03-28 15:23:50 --> Model Class Initialized
INFO - 2018-03-28 15:23:50 --> Model Class Initialized
INFO - 2018-03-28 15:23:50 --> Model Class Initialized
INFO - 2018-03-28 15:23:50 --> Helper loaded: date_helper
INFO - 2018-03-28 15:23:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:23:50 --> Final output sent to browser
DEBUG - 2018-03-28 20:23:50 --> Total execution time: 0.1740
INFO - 2018-03-28 15:23:51 --> Config Class Initialized
INFO - 2018-03-28 15:23:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:23:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:23:51 --> Utf8 Class Initialized
INFO - 2018-03-28 15:23:51 --> URI Class Initialized
INFO - 2018-03-28 15:23:51 --> Router Class Initialized
INFO - 2018-03-28 15:23:51 --> Output Class Initialized
INFO - 2018-03-28 15:23:51 --> Security Class Initialized
DEBUG - 2018-03-28 15:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:23:51 --> Input Class Initialized
INFO - 2018-03-28 15:23:51 --> Language Class Initialized
INFO - 2018-03-28 15:23:51 --> Loader Class Initialized
INFO - 2018-03-28 15:23:51 --> Helper loaded: url_helper
INFO - 2018-03-28 15:23:51 --> Helper loaded: form_helper
INFO - 2018-03-28 15:23:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:23:51 --> Controller Class Initialized
INFO - 2018-03-28 15:23:51 --> Model Class Initialized
INFO - 2018-03-28 15:23:51 --> Model Class Initialized
INFO - 2018-03-28 15:23:51 --> Model Class Initialized
INFO - 2018-03-28 15:23:51 --> Model Class Initialized
INFO - 2018-03-28 15:23:51 --> Model Class Initialized
INFO - 2018-03-28 15:23:51 --> Model Class Initialized
INFO - 2018-03-28 15:23:51 --> Model Class Initialized
INFO - 2018-03-28 15:23:51 --> Model Class Initialized
INFO - 2018-03-28 15:23:51 --> Model Class Initialized
INFO - 2018-03-28 15:23:51 --> Model Class Initialized
INFO - 2018-03-28 15:23:51 --> Model Class Initialized
INFO - 2018-03-28 15:23:51 --> Model Class Initialized
INFO - 2018-03-28 15:23:51 --> Model Class Initialized
INFO - 2018-03-28 15:23:51 --> Model Class Initialized
INFO - 2018-03-28 15:23:51 --> Helper loaded: date_helper
INFO - 2018-03-28 15:23:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:23:51 --> Final output sent to browser
DEBUG - 2018-03-28 20:23:51 --> Total execution time: 0.1869
INFO - 2018-03-28 15:23:52 --> Config Class Initialized
INFO - 2018-03-28 15:23:52 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:23:52 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:23:52 --> Utf8 Class Initialized
INFO - 2018-03-28 15:23:52 --> URI Class Initialized
INFO - 2018-03-28 15:23:52 --> Router Class Initialized
INFO - 2018-03-28 15:23:52 --> Output Class Initialized
INFO - 2018-03-28 15:23:52 --> Security Class Initialized
DEBUG - 2018-03-28 15:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:23:52 --> Input Class Initialized
INFO - 2018-03-28 15:23:52 --> Language Class Initialized
INFO - 2018-03-28 15:23:52 --> Loader Class Initialized
INFO - 2018-03-28 15:23:52 --> Helper loaded: url_helper
INFO - 2018-03-28 15:23:52 --> Helper loaded: form_helper
INFO - 2018-03-28 15:23:52 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:23:52 --> Controller Class Initialized
INFO - 2018-03-28 15:23:52 --> Model Class Initialized
INFO - 2018-03-28 15:23:52 --> Model Class Initialized
INFO - 2018-03-28 15:23:52 --> Model Class Initialized
INFO - 2018-03-28 15:23:52 --> Model Class Initialized
INFO - 2018-03-28 15:23:52 --> Model Class Initialized
INFO - 2018-03-28 15:23:52 --> Model Class Initialized
INFO - 2018-03-28 15:23:52 --> Model Class Initialized
INFO - 2018-03-28 15:23:52 --> Model Class Initialized
INFO - 2018-03-28 15:23:52 --> Model Class Initialized
INFO - 2018-03-28 15:23:52 --> Model Class Initialized
INFO - 2018-03-28 15:23:52 --> Model Class Initialized
INFO - 2018-03-28 15:23:52 --> Model Class Initialized
INFO - 2018-03-28 15:23:52 --> Model Class Initialized
INFO - 2018-03-28 15:23:52 --> Model Class Initialized
INFO - 2018-03-28 15:23:52 --> Helper loaded: date_helper
INFO - 2018-03-28 15:23:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:23:52 --> Final output sent to browser
DEBUG - 2018-03-28 20:23:52 --> Total execution time: 0.1881
INFO - 2018-03-28 15:24:15 --> Config Class Initialized
INFO - 2018-03-28 15:24:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:24:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:24:15 --> Utf8 Class Initialized
INFO - 2018-03-28 15:24:15 --> URI Class Initialized
INFO - 2018-03-28 15:24:15 --> Router Class Initialized
INFO - 2018-03-28 15:24:15 --> Output Class Initialized
INFO - 2018-03-28 15:24:15 --> Security Class Initialized
DEBUG - 2018-03-28 15:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:24:15 --> Input Class Initialized
INFO - 2018-03-28 15:24:15 --> Language Class Initialized
INFO - 2018-03-28 15:24:15 --> Loader Class Initialized
INFO - 2018-03-28 15:24:15 --> Helper loaded: url_helper
INFO - 2018-03-28 15:24:15 --> Helper loaded: form_helper
INFO - 2018-03-28 15:24:15 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:24:15 --> Controller Class Initialized
INFO - 2018-03-28 15:24:15 --> Model Class Initialized
INFO - 2018-03-28 15:24:15 --> Model Class Initialized
INFO - 2018-03-28 15:24:15 --> Model Class Initialized
INFO - 2018-03-28 15:24:15 --> Model Class Initialized
INFO - 2018-03-28 15:24:15 --> Model Class Initialized
INFO - 2018-03-28 15:24:15 --> Model Class Initialized
INFO - 2018-03-28 15:24:15 --> Model Class Initialized
INFO - 2018-03-28 15:24:15 --> Model Class Initialized
INFO - 2018-03-28 15:24:15 --> Model Class Initialized
INFO - 2018-03-28 15:24:15 --> Model Class Initialized
INFO - 2018-03-28 15:24:15 --> Model Class Initialized
INFO - 2018-03-28 15:24:15 --> Model Class Initialized
INFO - 2018-03-28 15:24:15 --> Model Class Initialized
INFO - 2018-03-28 15:24:15 --> Model Class Initialized
INFO - 2018-03-28 15:24:15 --> Helper loaded: date_helper
INFO - 2018-03-28 15:24:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:24:15 --> Final output sent to browser
DEBUG - 2018-03-28 20:24:15 --> Total execution time: 0.1116
INFO - 2018-03-28 15:24:19 --> Config Class Initialized
INFO - 2018-03-28 15:24:19 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:24:19 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:24:19 --> Utf8 Class Initialized
INFO - 2018-03-28 15:24:19 --> URI Class Initialized
INFO - 2018-03-28 15:24:19 --> Router Class Initialized
INFO - 2018-03-28 15:24:19 --> Output Class Initialized
INFO - 2018-03-28 15:24:20 --> Security Class Initialized
DEBUG - 2018-03-28 15:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:24:20 --> Input Class Initialized
INFO - 2018-03-28 15:24:20 --> Language Class Initialized
INFO - 2018-03-28 15:24:20 --> Loader Class Initialized
INFO - 2018-03-28 15:24:20 --> Helper loaded: url_helper
INFO - 2018-03-28 15:24:20 --> Helper loaded: form_helper
INFO - 2018-03-28 15:24:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:24:20 --> Controller Class Initialized
INFO - 2018-03-28 15:24:20 --> Model Class Initialized
INFO - 2018-03-28 15:24:20 --> Model Class Initialized
INFO - 2018-03-28 15:24:20 --> Model Class Initialized
INFO - 2018-03-28 15:24:20 --> Model Class Initialized
INFO - 2018-03-28 15:24:20 --> Model Class Initialized
INFO - 2018-03-28 15:24:20 --> Model Class Initialized
INFO - 2018-03-28 15:24:20 --> Model Class Initialized
INFO - 2018-03-28 15:24:20 --> Model Class Initialized
INFO - 2018-03-28 15:24:20 --> Model Class Initialized
INFO - 2018-03-28 15:24:20 --> Model Class Initialized
INFO - 2018-03-28 15:24:20 --> Model Class Initialized
INFO - 2018-03-28 15:24:20 --> Model Class Initialized
INFO - 2018-03-28 15:24:20 --> Model Class Initialized
INFO - 2018-03-28 15:24:20 --> Model Class Initialized
INFO - 2018-03-28 15:24:20 --> Helper loaded: date_helper
INFO - 2018-03-28 15:24:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:24:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:24:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:24:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/create.php
INFO - 2018-03-28 20:24:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:24:20 --> Final output sent to browser
DEBUG - 2018-03-28 20:24:20 --> Total execution time: 0.1299
INFO - 2018-03-28 15:24:29 --> Config Class Initialized
INFO - 2018-03-28 15:24:29 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:24:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:24:29 --> Utf8 Class Initialized
INFO - 2018-03-28 15:24:29 --> URI Class Initialized
INFO - 2018-03-28 15:24:29 --> Router Class Initialized
INFO - 2018-03-28 15:24:29 --> Output Class Initialized
INFO - 2018-03-28 15:24:29 --> Security Class Initialized
DEBUG - 2018-03-28 15:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:24:29 --> Input Class Initialized
INFO - 2018-03-28 15:24:29 --> Language Class Initialized
INFO - 2018-03-28 15:24:29 --> Loader Class Initialized
INFO - 2018-03-28 15:24:29 --> Helper loaded: url_helper
INFO - 2018-03-28 15:24:29 --> Helper loaded: form_helper
INFO - 2018-03-28 15:24:29 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:24:29 --> Controller Class Initialized
INFO - 2018-03-28 15:24:29 --> Model Class Initialized
INFO - 2018-03-28 15:24:29 --> Model Class Initialized
INFO - 2018-03-28 15:24:29 --> Model Class Initialized
INFO - 2018-03-28 15:24:29 --> Model Class Initialized
INFO - 2018-03-28 15:24:29 --> Model Class Initialized
INFO - 2018-03-28 15:24:29 --> Model Class Initialized
INFO - 2018-03-28 15:24:29 --> Model Class Initialized
INFO - 2018-03-28 15:24:29 --> Model Class Initialized
INFO - 2018-03-28 15:24:29 --> Model Class Initialized
INFO - 2018-03-28 15:24:29 --> Model Class Initialized
INFO - 2018-03-28 15:24:29 --> Model Class Initialized
INFO - 2018-03-28 15:24:29 --> Model Class Initialized
INFO - 2018-03-28 15:24:29 --> Model Class Initialized
INFO - 2018-03-28 15:24:29 --> Model Class Initialized
INFO - 2018-03-28 15:24:29 --> Helper loaded: date_helper
INFO - 2018-03-28 15:24:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:24:29 --> Final output sent to browser
DEBUG - 2018-03-28 20:24:29 --> Total execution time: 0.1706
INFO - 2018-03-28 15:24:30 --> Config Class Initialized
INFO - 2018-03-28 15:24:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:24:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:24:30 --> Utf8 Class Initialized
INFO - 2018-03-28 15:24:30 --> URI Class Initialized
INFO - 2018-03-28 15:24:30 --> Router Class Initialized
INFO - 2018-03-28 15:24:30 --> Output Class Initialized
INFO - 2018-03-28 15:24:30 --> Security Class Initialized
DEBUG - 2018-03-28 15:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:24:30 --> Input Class Initialized
INFO - 2018-03-28 15:24:30 --> Language Class Initialized
INFO - 2018-03-28 15:24:30 --> Loader Class Initialized
INFO - 2018-03-28 15:24:30 --> Helper loaded: url_helper
INFO - 2018-03-28 15:24:30 --> Helper loaded: form_helper
INFO - 2018-03-28 15:24:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:24:30 --> Controller Class Initialized
INFO - 2018-03-28 15:24:30 --> Model Class Initialized
INFO - 2018-03-28 15:24:30 --> Model Class Initialized
INFO - 2018-03-28 15:24:30 --> Model Class Initialized
INFO - 2018-03-28 15:24:30 --> Model Class Initialized
INFO - 2018-03-28 15:24:30 --> Model Class Initialized
INFO - 2018-03-28 15:24:30 --> Model Class Initialized
INFO - 2018-03-28 15:24:30 --> Model Class Initialized
INFO - 2018-03-28 15:24:30 --> Model Class Initialized
INFO - 2018-03-28 15:24:30 --> Model Class Initialized
INFO - 2018-03-28 15:24:30 --> Model Class Initialized
INFO - 2018-03-28 15:24:30 --> Model Class Initialized
INFO - 2018-03-28 15:24:30 --> Model Class Initialized
INFO - 2018-03-28 15:24:30 --> Model Class Initialized
INFO - 2018-03-28 15:24:30 --> Model Class Initialized
INFO - 2018-03-28 15:24:30 --> Helper loaded: date_helper
INFO - 2018-03-28 15:24:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:24:30 --> Final output sent to browser
DEBUG - 2018-03-28 20:24:30 --> Total execution time: 0.1164
INFO - 2018-03-28 15:24:31 --> Config Class Initialized
INFO - 2018-03-28 15:24:31 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:24:31 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:24:31 --> Utf8 Class Initialized
INFO - 2018-03-28 15:24:31 --> URI Class Initialized
INFO - 2018-03-28 15:24:31 --> Router Class Initialized
INFO - 2018-03-28 15:24:31 --> Output Class Initialized
INFO - 2018-03-28 15:24:31 --> Security Class Initialized
DEBUG - 2018-03-28 15:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:24:31 --> Input Class Initialized
INFO - 2018-03-28 15:24:31 --> Language Class Initialized
INFO - 2018-03-28 15:24:31 --> Loader Class Initialized
INFO - 2018-03-28 15:24:31 --> Helper loaded: url_helper
INFO - 2018-03-28 15:24:31 --> Helper loaded: form_helper
INFO - 2018-03-28 15:24:31 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:24:31 --> Controller Class Initialized
INFO - 2018-03-28 15:24:31 --> Model Class Initialized
INFO - 2018-03-28 15:24:31 --> Model Class Initialized
INFO - 2018-03-28 15:24:31 --> Model Class Initialized
INFO - 2018-03-28 15:24:31 --> Model Class Initialized
INFO - 2018-03-28 15:24:31 --> Model Class Initialized
INFO - 2018-03-28 15:24:31 --> Model Class Initialized
INFO - 2018-03-28 15:24:31 --> Model Class Initialized
INFO - 2018-03-28 15:24:31 --> Model Class Initialized
INFO - 2018-03-28 15:24:31 --> Model Class Initialized
INFO - 2018-03-28 15:24:31 --> Model Class Initialized
INFO - 2018-03-28 15:24:31 --> Model Class Initialized
INFO - 2018-03-28 15:24:31 --> Model Class Initialized
INFO - 2018-03-28 15:24:31 --> Model Class Initialized
INFO - 2018-03-28 15:24:31 --> Model Class Initialized
INFO - 2018-03-28 15:24:31 --> Helper loaded: date_helper
INFO - 2018-03-28 15:24:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:24:31 --> Final output sent to browser
DEBUG - 2018-03-28 20:24:31 --> Total execution time: 0.1686
INFO - 2018-03-28 15:24:32 --> Config Class Initialized
INFO - 2018-03-28 15:24:32 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:24:32 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:24:32 --> Utf8 Class Initialized
INFO - 2018-03-28 15:24:32 --> URI Class Initialized
INFO - 2018-03-28 15:24:32 --> Router Class Initialized
INFO - 2018-03-28 15:24:32 --> Output Class Initialized
INFO - 2018-03-28 15:24:32 --> Security Class Initialized
DEBUG - 2018-03-28 15:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:24:32 --> Input Class Initialized
INFO - 2018-03-28 15:24:32 --> Language Class Initialized
INFO - 2018-03-28 15:24:32 --> Loader Class Initialized
INFO - 2018-03-28 15:24:32 --> Helper loaded: url_helper
INFO - 2018-03-28 15:24:32 --> Helper loaded: form_helper
INFO - 2018-03-28 15:24:32 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:24:32 --> Controller Class Initialized
INFO - 2018-03-28 15:24:32 --> Model Class Initialized
INFO - 2018-03-28 15:24:32 --> Model Class Initialized
INFO - 2018-03-28 15:24:32 --> Model Class Initialized
INFO - 2018-03-28 15:24:32 --> Model Class Initialized
INFO - 2018-03-28 15:24:32 --> Model Class Initialized
INFO - 2018-03-28 15:24:32 --> Model Class Initialized
INFO - 2018-03-28 15:24:32 --> Model Class Initialized
INFO - 2018-03-28 15:24:32 --> Model Class Initialized
INFO - 2018-03-28 15:24:32 --> Model Class Initialized
INFO - 2018-03-28 15:24:32 --> Model Class Initialized
INFO - 2018-03-28 15:24:32 --> Model Class Initialized
INFO - 2018-03-28 15:24:32 --> Model Class Initialized
INFO - 2018-03-28 15:24:32 --> Model Class Initialized
INFO - 2018-03-28 15:24:32 --> Model Class Initialized
INFO - 2018-03-28 15:24:32 --> Helper loaded: date_helper
INFO - 2018-03-28 15:24:32 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:24:32 --> Final output sent to browser
DEBUG - 2018-03-28 20:24:32 --> Total execution time: 0.1374
INFO - 2018-03-28 15:24:42 --> Config Class Initialized
INFO - 2018-03-28 15:24:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:24:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:24:42 --> Utf8 Class Initialized
INFO - 2018-03-28 15:24:42 --> URI Class Initialized
INFO - 2018-03-28 15:24:42 --> Router Class Initialized
INFO - 2018-03-28 15:24:42 --> Output Class Initialized
INFO - 2018-03-28 15:24:42 --> Security Class Initialized
DEBUG - 2018-03-28 15:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:24:42 --> Input Class Initialized
INFO - 2018-03-28 15:24:42 --> Language Class Initialized
INFO - 2018-03-28 15:24:42 --> Loader Class Initialized
INFO - 2018-03-28 15:24:42 --> Helper loaded: url_helper
INFO - 2018-03-28 15:24:42 --> Helper loaded: form_helper
INFO - 2018-03-28 15:24:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:24:42 --> Controller Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Helper loaded: date_helper
INFO - 2018-03-28 15:24:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:24:42 --> Final output sent to browser
DEBUG - 2018-03-28 20:24:42 --> Total execution time: 0.1498
INFO - 2018-03-28 15:24:42 --> Config Class Initialized
INFO - 2018-03-28 15:24:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:24:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:24:42 --> Utf8 Class Initialized
INFO - 2018-03-28 15:24:42 --> URI Class Initialized
INFO - 2018-03-28 15:24:42 --> Router Class Initialized
INFO - 2018-03-28 15:24:42 --> Output Class Initialized
INFO - 2018-03-28 15:24:42 --> Security Class Initialized
DEBUG - 2018-03-28 15:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:24:42 --> Input Class Initialized
INFO - 2018-03-28 15:24:42 --> Language Class Initialized
INFO - 2018-03-28 15:24:42 --> Loader Class Initialized
INFO - 2018-03-28 15:24:42 --> Helper loaded: url_helper
INFO - 2018-03-28 15:24:42 --> Helper loaded: form_helper
INFO - 2018-03-28 15:24:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:24:42 --> Controller Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Model Class Initialized
INFO - 2018-03-28 15:24:42 --> Helper loaded: date_helper
INFO - 2018-03-28 15:24:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:24:43 --> Final output sent to browser
DEBUG - 2018-03-28 20:24:43 --> Total execution time: 0.1446
INFO - 2018-03-28 15:24:43 --> Config Class Initialized
INFO - 2018-03-28 15:24:43 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:24:43 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:24:43 --> Utf8 Class Initialized
INFO - 2018-03-28 15:24:43 --> URI Class Initialized
INFO - 2018-03-28 15:24:43 --> Router Class Initialized
INFO - 2018-03-28 15:24:43 --> Output Class Initialized
INFO - 2018-03-28 15:24:43 --> Security Class Initialized
DEBUG - 2018-03-28 15:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:24:43 --> Input Class Initialized
INFO - 2018-03-28 15:24:43 --> Language Class Initialized
INFO - 2018-03-28 15:24:43 --> Loader Class Initialized
INFO - 2018-03-28 15:24:43 --> Helper loaded: url_helper
INFO - 2018-03-28 15:24:43 --> Helper loaded: form_helper
INFO - 2018-03-28 15:24:43 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:24:43 --> Controller Class Initialized
INFO - 2018-03-28 15:24:43 --> Model Class Initialized
INFO - 2018-03-28 15:24:43 --> Model Class Initialized
INFO - 2018-03-28 15:24:43 --> Model Class Initialized
INFO - 2018-03-28 15:24:43 --> Model Class Initialized
INFO - 2018-03-28 15:24:43 --> Model Class Initialized
INFO - 2018-03-28 15:24:43 --> Model Class Initialized
INFO - 2018-03-28 15:24:43 --> Model Class Initialized
INFO - 2018-03-28 15:24:43 --> Model Class Initialized
INFO - 2018-03-28 15:24:43 --> Model Class Initialized
INFO - 2018-03-28 15:24:43 --> Model Class Initialized
INFO - 2018-03-28 15:24:43 --> Model Class Initialized
INFO - 2018-03-28 15:24:43 --> Model Class Initialized
INFO - 2018-03-28 15:24:43 --> Model Class Initialized
INFO - 2018-03-28 15:24:43 --> Model Class Initialized
INFO - 2018-03-28 15:24:43 --> Helper loaded: date_helper
INFO - 2018-03-28 15:24:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:24:43 --> Final output sent to browser
DEBUG - 2018-03-28 20:24:43 --> Total execution time: 0.1399
INFO - 2018-03-28 15:24:44 --> Config Class Initialized
INFO - 2018-03-28 15:24:44 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:24:44 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:24:44 --> Utf8 Class Initialized
INFO - 2018-03-28 15:24:44 --> URI Class Initialized
INFO - 2018-03-28 15:24:44 --> Router Class Initialized
INFO - 2018-03-28 15:24:44 --> Output Class Initialized
INFO - 2018-03-28 15:24:44 --> Security Class Initialized
DEBUG - 2018-03-28 15:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:24:44 --> Input Class Initialized
INFO - 2018-03-28 15:24:44 --> Language Class Initialized
INFO - 2018-03-28 15:24:44 --> Loader Class Initialized
INFO - 2018-03-28 15:24:44 --> Helper loaded: url_helper
INFO - 2018-03-28 15:24:44 --> Helper loaded: form_helper
INFO - 2018-03-28 15:24:44 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:24:44 --> Controller Class Initialized
INFO - 2018-03-28 15:24:44 --> Model Class Initialized
INFO - 2018-03-28 15:24:44 --> Model Class Initialized
INFO - 2018-03-28 15:24:44 --> Model Class Initialized
INFO - 2018-03-28 15:24:44 --> Model Class Initialized
INFO - 2018-03-28 15:24:44 --> Model Class Initialized
INFO - 2018-03-28 15:24:44 --> Model Class Initialized
INFO - 2018-03-28 15:24:44 --> Model Class Initialized
INFO - 2018-03-28 15:24:44 --> Model Class Initialized
INFO - 2018-03-28 15:24:44 --> Model Class Initialized
INFO - 2018-03-28 15:24:44 --> Model Class Initialized
INFO - 2018-03-28 15:24:44 --> Model Class Initialized
INFO - 2018-03-28 15:24:44 --> Model Class Initialized
INFO - 2018-03-28 15:24:44 --> Model Class Initialized
INFO - 2018-03-28 15:24:44 --> Model Class Initialized
INFO - 2018-03-28 15:24:44 --> Helper loaded: date_helper
INFO - 2018-03-28 15:24:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:24:44 --> Final output sent to browser
DEBUG - 2018-03-28 20:24:44 --> Total execution time: 0.1948
INFO - 2018-03-28 15:24:44 --> Config Class Initialized
INFO - 2018-03-28 15:24:44 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:24:44 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:24:44 --> Utf8 Class Initialized
INFO - 2018-03-28 15:24:44 --> URI Class Initialized
INFO - 2018-03-28 15:24:44 --> Router Class Initialized
INFO - 2018-03-28 15:24:44 --> Output Class Initialized
INFO - 2018-03-28 15:24:44 --> Security Class Initialized
DEBUG - 2018-03-28 15:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:24:44 --> Input Class Initialized
INFO - 2018-03-28 15:24:44 --> Language Class Initialized
INFO - 2018-03-28 15:24:44 --> Loader Class Initialized
INFO - 2018-03-28 15:24:44 --> Helper loaded: url_helper
INFO - 2018-03-28 15:24:44 --> Helper loaded: form_helper
INFO - 2018-03-28 15:24:44 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:24:44 --> Controller Class Initialized
INFO - 2018-03-28 15:24:44 --> Model Class Initialized
INFO - 2018-03-28 15:24:44 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Helper loaded: date_helper
INFO - 2018-03-28 15:24:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:24:45 --> Final output sent to browser
DEBUG - 2018-03-28 20:24:45 --> Total execution time: 0.1503
INFO - 2018-03-28 15:24:45 --> Config Class Initialized
INFO - 2018-03-28 15:24:45 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:24:45 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:24:45 --> Utf8 Class Initialized
INFO - 2018-03-28 15:24:45 --> URI Class Initialized
INFO - 2018-03-28 15:24:45 --> Router Class Initialized
INFO - 2018-03-28 15:24:45 --> Output Class Initialized
INFO - 2018-03-28 15:24:45 --> Security Class Initialized
DEBUG - 2018-03-28 15:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:24:45 --> Input Class Initialized
INFO - 2018-03-28 15:24:45 --> Language Class Initialized
INFO - 2018-03-28 15:24:45 --> Loader Class Initialized
INFO - 2018-03-28 15:24:45 --> Helper loaded: url_helper
INFO - 2018-03-28 15:24:45 --> Helper loaded: form_helper
INFO - 2018-03-28 15:24:45 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:24:45 --> Controller Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Model Class Initialized
INFO - 2018-03-28 15:24:45 --> Helper loaded: date_helper
INFO - 2018-03-28 15:24:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:24:45 --> Final output sent to browser
DEBUG - 2018-03-28 20:24:45 --> Total execution time: 0.1456
INFO - 2018-03-28 15:24:46 --> Config Class Initialized
INFO - 2018-03-28 15:24:46 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:24:46 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:24:46 --> Utf8 Class Initialized
INFO - 2018-03-28 15:24:46 --> URI Class Initialized
INFO - 2018-03-28 15:24:46 --> Router Class Initialized
INFO - 2018-03-28 15:24:46 --> Output Class Initialized
INFO - 2018-03-28 15:24:46 --> Security Class Initialized
DEBUG - 2018-03-28 15:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:24:46 --> Input Class Initialized
INFO - 2018-03-28 15:24:46 --> Language Class Initialized
INFO - 2018-03-28 15:24:46 --> Loader Class Initialized
INFO - 2018-03-28 15:24:46 --> Helper loaded: url_helper
INFO - 2018-03-28 15:24:46 --> Helper loaded: form_helper
INFO - 2018-03-28 15:24:46 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:24:46 --> Controller Class Initialized
INFO - 2018-03-28 15:24:46 --> Model Class Initialized
INFO - 2018-03-28 15:24:46 --> Model Class Initialized
INFO - 2018-03-28 15:24:46 --> Model Class Initialized
INFO - 2018-03-28 15:24:46 --> Model Class Initialized
INFO - 2018-03-28 15:24:46 --> Model Class Initialized
INFO - 2018-03-28 15:24:46 --> Model Class Initialized
INFO - 2018-03-28 15:24:46 --> Model Class Initialized
INFO - 2018-03-28 15:24:46 --> Model Class Initialized
INFO - 2018-03-28 15:24:46 --> Model Class Initialized
INFO - 2018-03-28 15:24:46 --> Model Class Initialized
INFO - 2018-03-28 15:24:46 --> Model Class Initialized
INFO - 2018-03-28 15:24:46 --> Model Class Initialized
INFO - 2018-03-28 15:24:46 --> Model Class Initialized
INFO - 2018-03-28 15:24:46 --> Model Class Initialized
INFO - 2018-03-28 15:24:46 --> Helper loaded: date_helper
INFO - 2018-03-28 15:24:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:24:46 --> Final output sent to browser
DEBUG - 2018-03-28 20:24:46 --> Total execution time: 0.1548
INFO - 2018-03-28 15:25:00 --> Config Class Initialized
INFO - 2018-03-28 15:25:00 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:25:00 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:25:00 --> Utf8 Class Initialized
INFO - 2018-03-28 15:25:00 --> URI Class Initialized
INFO - 2018-03-28 15:25:00 --> Router Class Initialized
INFO - 2018-03-28 15:25:00 --> Output Class Initialized
INFO - 2018-03-28 15:25:00 --> Security Class Initialized
DEBUG - 2018-03-28 15:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:25:00 --> Input Class Initialized
INFO - 2018-03-28 15:25:00 --> Language Class Initialized
INFO - 2018-03-28 15:25:00 --> Loader Class Initialized
INFO - 2018-03-28 15:25:00 --> Helper loaded: url_helper
INFO - 2018-03-28 15:25:00 --> Helper loaded: form_helper
INFO - 2018-03-28 15:25:00 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:25:00 --> Controller Class Initialized
INFO - 2018-03-28 15:25:00 --> Model Class Initialized
INFO - 2018-03-28 15:25:00 --> Model Class Initialized
INFO - 2018-03-28 15:25:00 --> Model Class Initialized
INFO - 2018-03-28 15:25:00 --> Model Class Initialized
INFO - 2018-03-28 15:25:00 --> Model Class Initialized
INFO - 2018-03-28 15:25:00 --> Model Class Initialized
INFO - 2018-03-28 15:25:00 --> Model Class Initialized
INFO - 2018-03-28 15:25:00 --> Model Class Initialized
INFO - 2018-03-28 15:25:00 --> Model Class Initialized
INFO - 2018-03-28 15:25:00 --> Model Class Initialized
INFO - 2018-03-28 15:25:00 --> Model Class Initialized
INFO - 2018-03-28 15:25:00 --> Model Class Initialized
INFO - 2018-03-28 15:25:00 --> Model Class Initialized
INFO - 2018-03-28 15:25:00 --> Model Class Initialized
INFO - 2018-03-28 15:25:00 --> Helper loaded: date_helper
INFO - 2018-03-28 15:25:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:25:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:25:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:25:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/create.php
INFO - 2018-03-28 20:25:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:25:00 --> Final output sent to browser
DEBUG - 2018-03-28 20:25:00 --> Total execution time: 0.1189
INFO - 2018-03-28 15:25:03 --> Config Class Initialized
INFO - 2018-03-28 15:25:03 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:25:03 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:25:03 --> Utf8 Class Initialized
INFO - 2018-03-28 15:25:03 --> URI Class Initialized
INFO - 2018-03-28 15:25:03 --> Router Class Initialized
INFO - 2018-03-28 15:25:03 --> Output Class Initialized
INFO - 2018-03-28 15:25:03 --> Security Class Initialized
DEBUG - 2018-03-28 15:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:25:03 --> Input Class Initialized
INFO - 2018-03-28 15:25:03 --> Language Class Initialized
INFO - 2018-03-28 15:25:03 --> Loader Class Initialized
INFO - 2018-03-28 15:25:03 --> Helper loaded: url_helper
INFO - 2018-03-28 15:25:03 --> Helper loaded: form_helper
INFO - 2018-03-28 15:25:03 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:25:03 --> Controller Class Initialized
INFO - 2018-03-28 15:25:03 --> Model Class Initialized
INFO - 2018-03-28 15:25:03 --> Model Class Initialized
INFO - 2018-03-28 15:25:03 --> Model Class Initialized
INFO - 2018-03-28 15:25:03 --> Model Class Initialized
INFO - 2018-03-28 15:25:03 --> Model Class Initialized
INFO - 2018-03-28 15:25:03 --> Model Class Initialized
INFO - 2018-03-28 15:25:03 --> Model Class Initialized
INFO - 2018-03-28 15:25:03 --> Model Class Initialized
INFO - 2018-03-28 15:25:03 --> Model Class Initialized
INFO - 2018-03-28 15:25:03 --> Model Class Initialized
INFO - 2018-03-28 15:25:03 --> Model Class Initialized
INFO - 2018-03-28 15:25:03 --> Model Class Initialized
INFO - 2018-03-28 15:25:03 --> Model Class Initialized
INFO - 2018-03-28 15:25:03 --> Model Class Initialized
INFO - 2018-03-28 15:25:03 --> Helper loaded: date_helper
INFO - 2018-03-28 15:25:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:25:04 --> Final output sent to browser
DEBUG - 2018-03-28 20:25:04 --> Total execution time: 0.1453
INFO - 2018-03-28 15:25:04 --> Config Class Initialized
INFO - 2018-03-28 15:25:04 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:25:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:25:04 --> Utf8 Class Initialized
INFO - 2018-03-28 15:25:04 --> URI Class Initialized
INFO - 2018-03-28 15:25:04 --> Router Class Initialized
INFO - 2018-03-28 15:25:04 --> Output Class Initialized
INFO - 2018-03-28 15:25:04 --> Security Class Initialized
DEBUG - 2018-03-28 15:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:25:04 --> Input Class Initialized
INFO - 2018-03-28 15:25:04 --> Language Class Initialized
INFO - 2018-03-28 15:25:04 --> Loader Class Initialized
INFO - 2018-03-28 15:25:04 --> Helper loaded: url_helper
INFO - 2018-03-28 15:25:04 --> Helper loaded: form_helper
INFO - 2018-03-28 15:25:04 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:25:04 --> Controller Class Initialized
INFO - 2018-03-28 15:25:04 --> Model Class Initialized
INFO - 2018-03-28 15:25:04 --> Model Class Initialized
INFO - 2018-03-28 15:25:04 --> Model Class Initialized
INFO - 2018-03-28 15:25:04 --> Model Class Initialized
INFO - 2018-03-28 15:25:04 --> Model Class Initialized
INFO - 2018-03-28 15:25:04 --> Model Class Initialized
INFO - 2018-03-28 15:25:04 --> Model Class Initialized
INFO - 2018-03-28 15:25:04 --> Model Class Initialized
INFO - 2018-03-28 15:25:04 --> Model Class Initialized
INFO - 2018-03-28 15:25:04 --> Model Class Initialized
INFO - 2018-03-28 15:25:04 --> Model Class Initialized
INFO - 2018-03-28 15:25:04 --> Model Class Initialized
INFO - 2018-03-28 15:25:04 --> Model Class Initialized
INFO - 2018-03-28 15:25:04 --> Model Class Initialized
INFO - 2018-03-28 15:25:04 --> Helper loaded: date_helper
INFO - 2018-03-28 15:25:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:25:04 --> Final output sent to browser
DEBUG - 2018-03-28 20:25:04 --> Total execution time: 0.1887
INFO - 2018-03-28 15:25:05 --> Config Class Initialized
INFO - 2018-03-28 15:25:05 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:25:05 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:25:05 --> Utf8 Class Initialized
INFO - 2018-03-28 15:25:05 --> URI Class Initialized
INFO - 2018-03-28 15:25:05 --> Router Class Initialized
INFO - 2018-03-28 15:25:05 --> Output Class Initialized
INFO - 2018-03-28 15:25:05 --> Security Class Initialized
DEBUG - 2018-03-28 15:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:25:05 --> Input Class Initialized
INFO - 2018-03-28 15:25:05 --> Language Class Initialized
INFO - 2018-03-28 15:25:05 --> Loader Class Initialized
INFO - 2018-03-28 15:25:05 --> Helper loaded: url_helper
INFO - 2018-03-28 15:25:05 --> Helper loaded: form_helper
INFO - 2018-03-28 15:25:05 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:25:05 --> Controller Class Initialized
INFO - 2018-03-28 15:25:05 --> Model Class Initialized
INFO - 2018-03-28 15:25:05 --> Model Class Initialized
INFO - 2018-03-28 15:25:05 --> Model Class Initialized
INFO - 2018-03-28 15:25:05 --> Model Class Initialized
INFO - 2018-03-28 15:25:05 --> Model Class Initialized
INFO - 2018-03-28 15:25:05 --> Model Class Initialized
INFO - 2018-03-28 15:25:05 --> Model Class Initialized
INFO - 2018-03-28 15:25:05 --> Model Class Initialized
INFO - 2018-03-28 15:25:05 --> Model Class Initialized
INFO - 2018-03-28 15:25:05 --> Model Class Initialized
INFO - 2018-03-28 15:25:05 --> Model Class Initialized
INFO - 2018-03-28 15:25:05 --> Model Class Initialized
INFO - 2018-03-28 15:25:05 --> Model Class Initialized
INFO - 2018-03-28 15:25:05 --> Model Class Initialized
INFO - 2018-03-28 15:25:05 --> Helper loaded: date_helper
INFO - 2018-03-28 15:25:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:25:05 --> Final output sent to browser
DEBUG - 2018-03-28 20:25:05 --> Total execution time: 0.1200
INFO - 2018-03-28 15:26:36 --> Config Class Initialized
INFO - 2018-03-28 15:26:36 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:26:36 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:26:36 --> Utf8 Class Initialized
INFO - 2018-03-28 15:26:36 --> URI Class Initialized
INFO - 2018-03-28 15:26:36 --> Router Class Initialized
INFO - 2018-03-28 15:26:36 --> Output Class Initialized
INFO - 2018-03-28 15:26:36 --> Security Class Initialized
DEBUG - 2018-03-28 15:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:26:36 --> Input Class Initialized
INFO - 2018-03-28 15:26:36 --> Language Class Initialized
INFO - 2018-03-28 15:26:36 --> Loader Class Initialized
INFO - 2018-03-28 15:26:36 --> Helper loaded: url_helper
INFO - 2018-03-28 15:26:36 --> Helper loaded: form_helper
INFO - 2018-03-28 15:26:36 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:26:36 --> Controller Class Initialized
INFO - 2018-03-28 15:26:36 --> Model Class Initialized
INFO - 2018-03-28 15:26:36 --> Model Class Initialized
INFO - 2018-03-28 15:26:36 --> Model Class Initialized
INFO - 2018-03-28 15:26:36 --> Model Class Initialized
INFO - 2018-03-28 15:26:36 --> Model Class Initialized
INFO - 2018-03-28 15:26:36 --> Model Class Initialized
INFO - 2018-03-28 15:26:36 --> Model Class Initialized
INFO - 2018-03-28 15:26:36 --> Model Class Initialized
INFO - 2018-03-28 15:26:36 --> Model Class Initialized
INFO - 2018-03-28 15:26:36 --> Model Class Initialized
INFO - 2018-03-28 15:26:36 --> Model Class Initialized
INFO - 2018-03-28 15:26:36 --> Model Class Initialized
INFO - 2018-03-28 15:26:36 --> Model Class Initialized
INFO - 2018-03-28 15:26:36 --> Model Class Initialized
INFO - 2018-03-28 15:26:36 --> Helper loaded: date_helper
INFO - 2018-03-28 15:26:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 15:26:37 --> Config Class Initialized
INFO - 2018-03-28 15:26:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:26:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:26:37 --> Utf8 Class Initialized
INFO - 2018-03-28 15:26:37 --> URI Class Initialized
INFO - 2018-03-28 15:26:37 --> Router Class Initialized
INFO - 2018-03-28 15:26:37 --> Output Class Initialized
INFO - 2018-03-28 15:26:37 --> Security Class Initialized
DEBUG - 2018-03-28 15:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:26:37 --> Input Class Initialized
INFO - 2018-03-28 15:26:37 --> Language Class Initialized
INFO - 2018-03-28 15:26:37 --> Loader Class Initialized
INFO - 2018-03-28 15:26:37 --> Helper loaded: url_helper
INFO - 2018-03-28 15:26:37 --> Helper loaded: form_helper
INFO - 2018-03-28 15:26:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:26:37 --> Controller Class Initialized
INFO - 2018-03-28 15:26:37 --> Model Class Initialized
INFO - 2018-03-28 15:26:37 --> Model Class Initialized
INFO - 2018-03-28 15:26:37 --> Model Class Initialized
INFO - 2018-03-28 15:26:37 --> Model Class Initialized
INFO - 2018-03-28 15:26:37 --> Model Class Initialized
INFO - 2018-03-28 15:26:37 --> Model Class Initialized
INFO - 2018-03-28 15:26:37 --> Model Class Initialized
INFO - 2018-03-28 15:26:37 --> Model Class Initialized
INFO - 2018-03-28 15:26:37 --> Model Class Initialized
INFO - 2018-03-28 15:26:37 --> Model Class Initialized
INFO - 2018-03-28 15:26:37 --> Model Class Initialized
INFO - 2018-03-28 15:26:37 --> Model Class Initialized
INFO - 2018-03-28 15:26:37 --> Model Class Initialized
INFO - 2018-03-28 15:26:37 --> Model Class Initialized
INFO - 2018-03-28 15:26:37 --> Helper loaded: date_helper
INFO - 2018-03-28 15:26:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:26:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:26:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:26:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-28 20:26:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:26:37 --> Final output sent to browser
DEBUG - 2018-03-28 20:26:37 --> Total execution time: 0.1968
INFO - 2018-03-28 15:26:41 --> Config Class Initialized
INFO - 2018-03-28 15:26:41 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:26:41 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:26:41 --> Utf8 Class Initialized
INFO - 2018-03-28 15:26:41 --> URI Class Initialized
INFO - 2018-03-28 15:26:41 --> Router Class Initialized
INFO - 2018-03-28 15:26:41 --> Output Class Initialized
INFO - 2018-03-28 15:26:41 --> Security Class Initialized
DEBUG - 2018-03-28 15:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:26:41 --> Input Class Initialized
INFO - 2018-03-28 15:26:41 --> Language Class Initialized
INFO - 2018-03-28 15:26:41 --> Loader Class Initialized
INFO - 2018-03-28 15:26:41 --> Helper loaded: url_helper
INFO - 2018-03-28 15:26:41 --> Helper loaded: form_helper
INFO - 2018-03-28 15:26:41 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:26:41 --> Controller Class Initialized
INFO - 2018-03-28 15:26:41 --> Model Class Initialized
INFO - 2018-03-28 15:26:41 --> Model Class Initialized
INFO - 2018-03-28 15:26:41 --> Model Class Initialized
INFO - 2018-03-28 15:26:41 --> Model Class Initialized
INFO - 2018-03-28 15:26:41 --> Model Class Initialized
INFO - 2018-03-28 15:26:41 --> Model Class Initialized
INFO - 2018-03-28 15:26:41 --> Model Class Initialized
INFO - 2018-03-28 15:26:41 --> Model Class Initialized
INFO - 2018-03-28 15:26:41 --> Model Class Initialized
INFO - 2018-03-28 15:26:41 --> Model Class Initialized
INFO - 2018-03-28 15:26:41 --> Model Class Initialized
INFO - 2018-03-28 15:26:41 --> Model Class Initialized
INFO - 2018-03-28 15:26:41 --> Model Class Initialized
INFO - 2018-03-28 15:26:41 --> Model Class Initialized
INFO - 2018-03-28 15:26:41 --> Helper loaded: date_helper
INFO - 2018-03-28 15:26:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:26:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 20:26:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 20:26:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-28 20:26:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 20:26:41 --> Final output sent to browser
DEBUG - 2018-03-28 20:26:41 --> Total execution time: 0.3051
INFO - 2018-03-28 15:26:47 --> Config Class Initialized
INFO - 2018-03-28 15:26:47 --> Hooks Class Initialized
DEBUG - 2018-03-28 15:26:47 --> UTF-8 Support Enabled
INFO - 2018-03-28 15:26:47 --> Utf8 Class Initialized
INFO - 2018-03-28 15:26:47 --> URI Class Initialized
INFO - 2018-03-28 15:26:47 --> Router Class Initialized
INFO - 2018-03-28 15:26:47 --> Output Class Initialized
INFO - 2018-03-28 15:26:47 --> Security Class Initialized
DEBUG - 2018-03-28 15:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 15:26:47 --> Input Class Initialized
INFO - 2018-03-28 15:26:47 --> Language Class Initialized
INFO - 2018-03-28 15:26:47 --> Loader Class Initialized
INFO - 2018-03-28 15:26:47 --> Helper loaded: url_helper
INFO - 2018-03-28 15:26:47 --> Helper loaded: form_helper
INFO - 2018-03-28 15:26:47 --> Database Driver Class Initialized
DEBUG - 2018-03-28 15:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 15:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 15:26:47 --> Controller Class Initialized
INFO - 2018-03-28 15:26:47 --> Model Class Initialized
INFO - 2018-03-28 15:26:47 --> Model Class Initialized
INFO - 2018-03-28 15:26:47 --> Model Class Initialized
INFO - 2018-03-28 15:26:47 --> Model Class Initialized
INFO - 2018-03-28 15:26:47 --> Model Class Initialized
INFO - 2018-03-28 15:26:47 --> Model Class Initialized
INFO - 2018-03-28 15:26:47 --> Model Class Initialized
INFO - 2018-03-28 15:26:47 --> Model Class Initialized
INFO - 2018-03-28 15:26:47 --> Model Class Initialized
INFO - 2018-03-28 15:26:47 --> Model Class Initialized
INFO - 2018-03-28 15:26:47 --> Model Class Initialized
INFO - 2018-03-28 15:26:47 --> Model Class Initialized
INFO - 2018-03-28 15:26:47 --> Model Class Initialized
INFO - 2018-03-28 15:26:47 --> Model Class Initialized
INFO - 2018-03-28 15:26:47 --> Helper loaded: date_helper
INFO - 2018-03-28 15:26:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 20:26:47 --> Final output sent to browser
DEBUG - 2018-03-28 20:26:47 --> Total execution time: 0.1209
INFO - 2018-03-28 17:02:42 --> Config Class Initialized
INFO - 2018-03-28 17:02:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:02:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:02:42 --> Utf8 Class Initialized
INFO - 2018-03-28 17:02:42 --> URI Class Initialized
INFO - 2018-03-28 17:02:42 --> Router Class Initialized
INFO - 2018-03-28 17:02:42 --> Output Class Initialized
INFO - 2018-03-28 17:02:42 --> Security Class Initialized
DEBUG - 2018-03-28 17:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:02:42 --> Input Class Initialized
INFO - 2018-03-28 17:02:42 --> Language Class Initialized
INFO - 2018-03-28 17:02:42 --> Loader Class Initialized
INFO - 2018-03-28 17:02:42 --> Helper loaded: url_helper
INFO - 2018-03-28 17:02:42 --> Helper loaded: form_helper
INFO - 2018-03-28 17:02:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:02:42 --> Controller Class Initialized
INFO - 2018-03-28 17:02:42 --> Model Class Initialized
INFO - 2018-03-28 17:02:42 --> Model Class Initialized
INFO - 2018-03-28 17:02:42 --> Model Class Initialized
INFO - 2018-03-28 17:02:42 --> Model Class Initialized
INFO - 2018-03-28 17:02:42 --> Model Class Initialized
INFO - 2018-03-28 17:02:42 --> Model Class Initialized
INFO - 2018-03-28 17:02:42 --> Model Class Initialized
INFO - 2018-03-28 17:02:42 --> Model Class Initialized
INFO - 2018-03-28 17:02:42 --> Model Class Initialized
INFO - 2018-03-28 17:02:42 --> Model Class Initialized
INFO - 2018-03-28 17:02:42 --> Model Class Initialized
INFO - 2018-03-28 17:02:42 --> Model Class Initialized
INFO - 2018-03-28 17:02:42 --> Helper loaded: date_helper
INFO - 2018-03-28 17:02:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:02:43 --> Model Class Initialized
INFO - 2018-03-28 22:02:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:02:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:02:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-28 22:02:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:02:43 --> Final output sent to browser
DEBUG - 2018-03-28 22:02:43 --> Total execution time: 1.5944
INFO - 2018-03-28 17:02:49 --> Config Class Initialized
INFO - 2018-03-28 17:02:49 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:02:49 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:02:49 --> Utf8 Class Initialized
INFO - 2018-03-28 17:02:49 --> URI Class Initialized
INFO - 2018-03-28 17:02:49 --> Router Class Initialized
INFO - 2018-03-28 17:02:49 --> Output Class Initialized
INFO - 2018-03-28 17:02:49 --> Security Class Initialized
DEBUG - 2018-03-28 17:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:02:49 --> Input Class Initialized
INFO - 2018-03-28 17:02:49 --> Language Class Initialized
INFO - 2018-03-28 17:02:49 --> Loader Class Initialized
INFO - 2018-03-28 17:02:49 --> Helper loaded: url_helper
INFO - 2018-03-28 17:02:49 --> Helper loaded: form_helper
INFO - 2018-03-28 17:02:49 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:02:49 --> Controller Class Initialized
INFO - 2018-03-28 17:02:49 --> Model Class Initialized
INFO - 2018-03-28 17:02:49 --> Model Class Initialized
INFO - 2018-03-28 17:02:49 --> Model Class Initialized
INFO - 2018-03-28 17:02:49 --> Model Class Initialized
INFO - 2018-03-28 17:02:49 --> Model Class Initialized
INFO - 2018-03-28 17:02:49 --> Helper loaded: date_helper
INFO - 2018-03-28 22:02:49 --> Model Class Initialized
INFO - 2018-03-28 22:02:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:02:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:02:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-28 22:02:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:02:49 --> Final output sent to browser
DEBUG - 2018-03-28 22:02:49 --> Total execution time: 0.1214
INFO - 2018-03-28 17:04:41 --> Config Class Initialized
INFO - 2018-03-28 17:04:41 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:04:41 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:04:41 --> Utf8 Class Initialized
INFO - 2018-03-28 17:04:41 --> URI Class Initialized
INFO - 2018-03-28 17:04:41 --> Router Class Initialized
INFO - 2018-03-28 17:04:41 --> Output Class Initialized
INFO - 2018-03-28 17:04:41 --> Security Class Initialized
DEBUG - 2018-03-28 17:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:04:41 --> Input Class Initialized
INFO - 2018-03-28 17:04:41 --> Language Class Initialized
INFO - 2018-03-28 17:04:41 --> Loader Class Initialized
INFO - 2018-03-28 17:04:41 --> Helper loaded: url_helper
INFO - 2018-03-28 17:04:41 --> Helper loaded: form_helper
INFO - 2018-03-28 17:04:41 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:04:41 --> Controller Class Initialized
INFO - 2018-03-28 17:04:41 --> Model Class Initialized
INFO - 2018-03-28 17:04:41 --> Model Class Initialized
INFO - 2018-03-28 17:04:41 --> Model Class Initialized
INFO - 2018-03-28 17:04:41 --> Model Class Initialized
INFO - 2018-03-28 17:04:41 --> Model Class Initialized
INFO - 2018-03-28 17:04:41 --> Model Class Initialized
INFO - 2018-03-28 17:04:41 --> Model Class Initialized
INFO - 2018-03-28 17:04:41 --> Model Class Initialized
INFO - 2018-03-28 17:04:41 --> Model Class Initialized
INFO - 2018-03-28 17:04:41 --> Model Class Initialized
INFO - 2018-03-28 17:04:41 --> Model Class Initialized
INFO - 2018-03-28 17:04:41 --> Model Class Initialized
INFO - 2018-03-28 17:04:41 --> Model Class Initialized
INFO - 2018-03-28 17:04:41 --> Model Class Initialized
INFO - 2018-03-28 17:04:41 --> Model Class Initialized
INFO - 2018-03-28 17:04:41 --> Helper loaded: date_helper
INFO - 2018-03-28 17:04:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:04:41 --> Model Class Initialized
INFO - 2018-03-28 22:04:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:04:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:04:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-28 22:04:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:04:41 --> Final output sent to browser
DEBUG - 2018-03-28 22:04:41 --> Total execution time: 0.2588
INFO - 2018-03-28 17:06:34 --> Config Class Initialized
INFO - 2018-03-28 17:06:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:06:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:06:34 --> Utf8 Class Initialized
INFO - 2018-03-28 17:06:34 --> URI Class Initialized
INFO - 2018-03-28 17:06:34 --> Router Class Initialized
INFO - 2018-03-28 17:06:34 --> Output Class Initialized
INFO - 2018-03-28 17:06:34 --> Security Class Initialized
DEBUG - 2018-03-28 17:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:06:34 --> Input Class Initialized
INFO - 2018-03-28 17:06:34 --> Language Class Initialized
INFO - 2018-03-28 17:06:34 --> Loader Class Initialized
INFO - 2018-03-28 17:06:34 --> Helper loaded: url_helper
INFO - 2018-03-28 17:06:34 --> Helper loaded: form_helper
INFO - 2018-03-28 17:06:34 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:06:34 --> Controller Class Initialized
INFO - 2018-03-28 17:06:34 --> Model Class Initialized
INFO - 2018-03-28 17:06:34 --> Model Class Initialized
INFO - 2018-03-28 17:06:34 --> Model Class Initialized
INFO - 2018-03-28 17:06:34 --> Model Class Initialized
INFO - 2018-03-28 17:06:34 --> Model Class Initialized
INFO - 2018-03-28 17:06:34 --> Model Class Initialized
INFO - 2018-03-28 17:06:34 --> Model Class Initialized
INFO - 2018-03-28 17:06:34 --> Helper loaded: date_helper
INFO - 2018-03-28 17:06:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:06:34 --> Model Class Initialized
INFO - 2018-03-28 22:06:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:06:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:06:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-28 22:06:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:06:34 --> Final output sent to browser
DEBUG - 2018-03-28 22:06:34 --> Total execution time: 0.3580
INFO - 2018-03-28 17:06:50 --> Config Class Initialized
INFO - 2018-03-28 17:06:50 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:06:50 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:06:50 --> Utf8 Class Initialized
INFO - 2018-03-28 17:06:50 --> URI Class Initialized
INFO - 2018-03-28 17:06:50 --> Router Class Initialized
INFO - 2018-03-28 17:06:50 --> Output Class Initialized
INFO - 2018-03-28 17:06:50 --> Security Class Initialized
DEBUG - 2018-03-28 17:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:06:50 --> Input Class Initialized
INFO - 2018-03-28 17:06:50 --> Language Class Initialized
INFO - 2018-03-28 17:06:50 --> Loader Class Initialized
INFO - 2018-03-28 17:06:50 --> Helper loaded: url_helper
INFO - 2018-03-28 17:06:50 --> Helper loaded: form_helper
INFO - 2018-03-28 17:06:50 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:06:50 --> Controller Class Initialized
INFO - 2018-03-28 17:06:50 --> Model Class Initialized
INFO - 2018-03-28 17:06:50 --> Model Class Initialized
INFO - 2018-03-28 17:06:50 --> Model Class Initialized
INFO - 2018-03-28 17:06:50 --> Model Class Initialized
INFO - 2018-03-28 17:06:50 --> Model Class Initialized
INFO - 2018-03-28 17:06:50 --> Helper loaded: date_helper
INFO - 2018-03-28 22:06:50 --> Model Class Initialized
INFO - 2018-03-28 22:06:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:06:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:06:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-28 22:06:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:06:50 --> Final output sent to browser
DEBUG - 2018-03-28 22:06:50 --> Total execution time: 0.1096
INFO - 2018-03-28 17:22:54 --> Config Class Initialized
INFO - 2018-03-28 17:22:54 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:22:54 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:22:54 --> Utf8 Class Initialized
INFO - 2018-03-28 17:22:54 --> URI Class Initialized
INFO - 2018-03-28 17:22:54 --> Router Class Initialized
INFO - 2018-03-28 17:22:54 --> Output Class Initialized
INFO - 2018-03-28 17:22:54 --> Security Class Initialized
DEBUG - 2018-03-28 17:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:22:54 --> Input Class Initialized
INFO - 2018-03-28 17:22:54 --> Language Class Initialized
INFO - 2018-03-28 17:22:54 --> Loader Class Initialized
INFO - 2018-03-28 17:22:54 --> Helper loaded: url_helper
INFO - 2018-03-28 17:22:54 --> Helper loaded: form_helper
INFO - 2018-03-28 17:22:54 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:22:54 --> Controller Class Initialized
INFO - 2018-03-28 17:22:54 --> Model Class Initialized
INFO - 2018-03-28 17:22:54 --> Model Class Initialized
INFO - 2018-03-28 17:22:54 --> Model Class Initialized
INFO - 2018-03-28 17:22:54 --> Model Class Initialized
INFO - 2018-03-28 17:22:54 --> Model Class Initialized
INFO - 2018-03-28 17:22:54 --> Helper loaded: date_helper
INFO - 2018-03-28 22:22:54 --> Model Class Initialized
INFO - 2018-03-28 22:22:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:22:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:22:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-28 22:22:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:22:54 --> Final output sent to browser
DEBUG - 2018-03-28 22:22:54 --> Total execution time: 0.1864
INFO - 2018-03-28 17:23:04 --> Config Class Initialized
INFO - 2018-03-28 17:23:04 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:23:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:23:04 --> Utf8 Class Initialized
INFO - 2018-03-28 17:23:04 --> URI Class Initialized
INFO - 2018-03-28 17:23:04 --> Router Class Initialized
INFO - 2018-03-28 17:23:04 --> Output Class Initialized
INFO - 2018-03-28 17:23:04 --> Security Class Initialized
DEBUG - 2018-03-28 17:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:23:04 --> Input Class Initialized
INFO - 2018-03-28 17:23:04 --> Language Class Initialized
INFO - 2018-03-28 17:23:04 --> Loader Class Initialized
INFO - 2018-03-28 17:23:04 --> Helper loaded: url_helper
INFO - 2018-03-28 17:23:04 --> Helper loaded: form_helper
INFO - 2018-03-28 17:23:04 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:23:04 --> Controller Class Initialized
INFO - 2018-03-28 17:23:04 --> Model Class Initialized
INFO - 2018-03-28 17:23:04 --> Model Class Initialized
INFO - 2018-03-28 17:23:04 --> Model Class Initialized
INFO - 2018-03-28 17:23:04 --> Model Class Initialized
INFO - 2018-03-28 17:23:04 --> Model Class Initialized
INFO - 2018-03-28 17:23:04 --> Model Class Initialized
INFO - 2018-03-28 17:23:04 --> Model Class Initialized
INFO - 2018-03-28 17:23:04 --> Model Class Initialized
INFO - 2018-03-28 17:23:04 --> Model Class Initialized
INFO - 2018-03-28 17:23:04 --> Model Class Initialized
INFO - 2018-03-28 17:23:04 --> Helper loaded: date_helper
INFO - 2018-03-28 17:23:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:23:04 --> Model Class Initialized
INFO - 2018-03-28 22:23:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:23:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:23:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-28 22:23:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:23:04 --> Final output sent to browser
DEBUG - 2018-03-28 22:23:04 --> Total execution time: 0.5505
INFO - 2018-03-28 17:23:22 --> Config Class Initialized
INFO - 2018-03-28 17:23:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:23:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:23:22 --> Utf8 Class Initialized
INFO - 2018-03-28 17:23:22 --> URI Class Initialized
INFO - 2018-03-28 17:23:22 --> Router Class Initialized
INFO - 2018-03-28 17:23:22 --> Output Class Initialized
INFO - 2018-03-28 17:23:22 --> Security Class Initialized
DEBUG - 2018-03-28 17:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:23:22 --> Input Class Initialized
INFO - 2018-03-28 17:23:22 --> Language Class Initialized
INFO - 2018-03-28 17:23:22 --> Loader Class Initialized
INFO - 2018-03-28 17:23:22 --> Helper loaded: url_helper
INFO - 2018-03-28 17:23:22 --> Helper loaded: form_helper
INFO - 2018-03-28 17:23:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:23:22 --> Controller Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Helper loaded: date_helper
INFO - 2018-03-28 17:23:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 17:23:22 --> Config Class Initialized
INFO - 2018-03-28 17:23:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:23:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:23:22 --> Utf8 Class Initialized
INFO - 2018-03-28 17:23:22 --> URI Class Initialized
INFO - 2018-03-28 17:23:22 --> Router Class Initialized
INFO - 2018-03-28 17:23:22 --> Output Class Initialized
INFO - 2018-03-28 17:23:22 --> Security Class Initialized
DEBUG - 2018-03-28 17:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:23:22 --> Input Class Initialized
INFO - 2018-03-28 17:23:22 --> Language Class Initialized
INFO - 2018-03-28 17:23:22 --> Loader Class Initialized
INFO - 2018-03-28 17:23:22 --> Helper loaded: url_helper
INFO - 2018-03-28 17:23:22 --> Helper loaded: form_helper
INFO - 2018-03-28 17:23:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:23:22 --> Controller Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Model Class Initialized
INFO - 2018-03-28 17:23:22 --> Helper loaded: date_helper
INFO - 2018-03-28 17:23:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:23:22 --> Model Class Initialized
INFO - 2018-03-28 22:23:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:23:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:23:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-28 22:23:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:23:22 --> Final output sent to browser
DEBUG - 2018-03-28 22:23:22 --> Total execution time: 0.1096
INFO - 2018-03-28 17:23:38 --> Config Class Initialized
INFO - 2018-03-28 17:23:38 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:23:38 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:23:38 --> Utf8 Class Initialized
INFO - 2018-03-28 17:23:38 --> URI Class Initialized
INFO - 2018-03-28 17:23:38 --> Router Class Initialized
INFO - 2018-03-28 17:23:38 --> Output Class Initialized
INFO - 2018-03-28 17:23:38 --> Security Class Initialized
DEBUG - 2018-03-28 17:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:23:38 --> Input Class Initialized
INFO - 2018-03-28 17:23:38 --> Language Class Initialized
INFO - 2018-03-28 17:23:38 --> Loader Class Initialized
INFO - 2018-03-28 17:23:38 --> Helper loaded: url_helper
INFO - 2018-03-28 17:23:38 --> Helper loaded: form_helper
INFO - 2018-03-28 17:23:38 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:23:38 --> Controller Class Initialized
INFO - 2018-03-28 17:23:38 --> Model Class Initialized
INFO - 2018-03-28 17:23:38 --> Model Class Initialized
INFO - 2018-03-28 17:23:38 --> Model Class Initialized
INFO - 2018-03-28 17:23:38 --> Model Class Initialized
INFO - 2018-03-28 17:23:38 --> Model Class Initialized
INFO - 2018-03-28 17:23:38 --> Model Class Initialized
INFO - 2018-03-28 17:23:38 --> Model Class Initialized
INFO - 2018-03-28 17:23:38 --> Model Class Initialized
INFO - 2018-03-28 17:23:38 --> Model Class Initialized
INFO - 2018-03-28 17:23:38 --> Model Class Initialized
INFO - 2018-03-28 17:23:38 --> Model Class Initialized
INFO - 2018-03-28 17:23:38 --> Model Class Initialized
INFO - 2018-03-28 17:23:38 --> Model Class Initialized
INFO - 2018-03-28 17:23:38 --> Model Class Initialized
INFO - 2018-03-28 17:23:38 --> Helper loaded: date_helper
INFO - 2018-03-28 17:23:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:23:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:23:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:23:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-28 22:23:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:23:38 --> Final output sent to browser
DEBUG - 2018-03-28 22:23:38 --> Total execution time: 0.2724
INFO - 2018-03-28 17:23:52 --> Config Class Initialized
INFO - 2018-03-28 17:23:52 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:23:52 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:23:52 --> Utf8 Class Initialized
INFO - 2018-03-28 17:23:52 --> URI Class Initialized
INFO - 2018-03-28 17:23:52 --> Router Class Initialized
INFO - 2018-03-28 17:23:52 --> Output Class Initialized
INFO - 2018-03-28 17:23:52 --> Security Class Initialized
DEBUG - 2018-03-28 17:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:23:52 --> Input Class Initialized
INFO - 2018-03-28 17:23:52 --> Language Class Initialized
INFO - 2018-03-28 17:23:52 --> Loader Class Initialized
INFO - 2018-03-28 17:23:52 --> Helper loaded: url_helper
INFO - 2018-03-28 17:23:52 --> Helper loaded: form_helper
INFO - 2018-03-28 17:23:52 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:23:52 --> Controller Class Initialized
INFO - 2018-03-28 17:23:52 --> Model Class Initialized
INFO - 2018-03-28 17:23:52 --> Model Class Initialized
INFO - 2018-03-28 17:23:52 --> Model Class Initialized
INFO - 2018-03-28 17:23:52 --> Model Class Initialized
INFO - 2018-03-28 17:23:52 --> Model Class Initialized
INFO - 2018-03-28 17:23:52 --> Model Class Initialized
INFO - 2018-03-28 17:23:52 --> Model Class Initialized
INFO - 2018-03-28 17:23:52 --> Model Class Initialized
INFO - 2018-03-28 17:23:52 --> Model Class Initialized
INFO - 2018-03-28 17:23:52 --> Model Class Initialized
INFO - 2018-03-28 17:23:52 --> Model Class Initialized
INFO - 2018-03-28 17:23:52 --> Model Class Initialized
INFO - 2018-03-28 17:23:52 --> Model Class Initialized
INFO - 2018-03-28 17:23:52 --> Model Class Initialized
INFO - 2018-03-28 17:23:52 --> Helper loaded: date_helper
INFO - 2018-03-28 17:23:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:23:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:23:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:23:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/create.php
INFO - 2018-03-28 22:23:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:23:52 --> Final output sent to browser
DEBUG - 2018-03-28 22:23:52 --> Total execution time: 0.1737
INFO - 2018-03-28 17:24:44 --> Config Class Initialized
INFO - 2018-03-28 17:24:44 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:24:44 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:24:44 --> Utf8 Class Initialized
INFO - 2018-03-28 17:24:44 --> URI Class Initialized
INFO - 2018-03-28 17:24:44 --> Router Class Initialized
INFO - 2018-03-28 17:24:44 --> Output Class Initialized
INFO - 2018-03-28 17:24:44 --> Security Class Initialized
DEBUG - 2018-03-28 17:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:24:44 --> Input Class Initialized
INFO - 2018-03-28 17:24:44 --> Language Class Initialized
INFO - 2018-03-28 17:24:44 --> Loader Class Initialized
INFO - 2018-03-28 17:24:44 --> Helper loaded: url_helper
INFO - 2018-03-28 17:24:44 --> Helper loaded: form_helper
INFO - 2018-03-28 17:24:44 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:24:44 --> Controller Class Initialized
INFO - 2018-03-28 17:24:44 --> Model Class Initialized
INFO - 2018-03-28 17:24:44 --> Model Class Initialized
INFO - 2018-03-28 17:24:44 --> Model Class Initialized
INFO - 2018-03-28 17:24:44 --> Model Class Initialized
INFO - 2018-03-28 17:24:44 --> Model Class Initialized
INFO - 2018-03-28 17:24:44 --> Model Class Initialized
INFO - 2018-03-28 17:24:44 --> Model Class Initialized
INFO - 2018-03-28 17:24:44 --> Model Class Initialized
INFO - 2018-03-28 17:24:44 --> Model Class Initialized
INFO - 2018-03-28 17:24:44 --> Model Class Initialized
INFO - 2018-03-28 17:24:44 --> Helper loaded: date_helper
INFO - 2018-03-28 17:24:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:24:44 --> Model Class Initialized
INFO - 2018-03-28 22:24:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:24:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:24:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-28 22:24:44 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:24:44 --> Final output sent to browser
DEBUG - 2018-03-28 22:24:44 --> Total execution time: 0.1682
INFO - 2018-03-28 17:24:50 --> Config Class Initialized
INFO - 2018-03-28 17:24:50 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:24:50 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:24:50 --> Utf8 Class Initialized
INFO - 2018-03-28 17:24:50 --> URI Class Initialized
INFO - 2018-03-28 17:24:50 --> Router Class Initialized
INFO - 2018-03-28 17:24:50 --> Output Class Initialized
INFO - 2018-03-28 17:24:50 --> Security Class Initialized
DEBUG - 2018-03-28 17:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:24:50 --> Input Class Initialized
INFO - 2018-03-28 17:24:50 --> Language Class Initialized
INFO - 2018-03-28 17:24:50 --> Loader Class Initialized
INFO - 2018-03-28 17:24:50 --> Helper loaded: url_helper
INFO - 2018-03-28 17:24:50 --> Helper loaded: form_helper
INFO - 2018-03-28 17:24:50 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:24:50 --> Controller Class Initialized
INFO - 2018-03-28 17:24:50 --> Model Class Initialized
INFO - 2018-03-28 17:24:50 --> Model Class Initialized
INFO - 2018-03-28 17:24:50 --> Model Class Initialized
INFO - 2018-03-28 17:24:50 --> Model Class Initialized
INFO - 2018-03-28 17:24:50 --> Model Class Initialized
INFO - 2018-03-28 17:24:50 --> Model Class Initialized
INFO - 2018-03-28 17:24:50 --> Model Class Initialized
INFO - 2018-03-28 17:24:50 --> Model Class Initialized
INFO - 2018-03-28 17:24:50 --> Model Class Initialized
INFO - 2018-03-28 17:24:50 --> Model Class Initialized
INFO - 2018-03-28 17:24:50 --> Helper loaded: date_helper
INFO - 2018-03-28 17:24:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:24:50 --> Model Class Initialized
INFO - 2018-03-28 22:24:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:24:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:24:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/create.php
INFO - 2018-03-28 22:24:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:24:50 --> Final output sent to browser
DEBUG - 2018-03-28 22:24:50 --> Total execution time: 0.2392
INFO - 2018-03-28 17:24:58 --> Config Class Initialized
INFO - 2018-03-28 17:24:59 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:24:59 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:24:59 --> Utf8 Class Initialized
INFO - 2018-03-28 17:24:59 --> URI Class Initialized
INFO - 2018-03-28 17:24:59 --> Router Class Initialized
INFO - 2018-03-28 17:24:59 --> Output Class Initialized
INFO - 2018-03-28 17:24:59 --> Security Class Initialized
DEBUG - 2018-03-28 17:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:24:59 --> Input Class Initialized
INFO - 2018-03-28 17:24:59 --> Language Class Initialized
INFO - 2018-03-28 17:24:59 --> Loader Class Initialized
INFO - 2018-03-28 17:24:59 --> Helper loaded: url_helper
INFO - 2018-03-28 17:24:59 --> Helper loaded: form_helper
INFO - 2018-03-28 17:24:59 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:24:59 --> Controller Class Initialized
INFO - 2018-03-28 17:24:59 --> Model Class Initialized
INFO - 2018-03-28 17:24:59 --> Model Class Initialized
INFO - 2018-03-28 17:24:59 --> Model Class Initialized
INFO - 2018-03-28 17:24:59 --> Model Class Initialized
INFO - 2018-03-28 17:24:59 --> Model Class Initialized
INFO - 2018-03-28 17:24:59 --> Model Class Initialized
INFO - 2018-03-28 17:24:59 --> Model Class Initialized
INFO - 2018-03-28 17:24:59 --> Model Class Initialized
INFO - 2018-03-28 17:24:59 --> Model Class Initialized
INFO - 2018-03-28 17:24:59 --> Model Class Initialized
INFO - 2018-03-28 17:24:59 --> Model Class Initialized
INFO - 2018-03-28 17:24:59 --> Model Class Initialized
INFO - 2018-03-28 17:24:59 --> Model Class Initialized
INFO - 2018-03-28 17:24:59 --> Model Class Initialized
INFO - 2018-03-28 17:24:59 --> Helper loaded: date_helper
INFO - 2018-03-28 17:24:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:24:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:24:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:24:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/create.php
INFO - 2018-03-28 22:24:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:24:59 --> Final output sent to browser
DEBUG - 2018-03-28 22:24:59 --> Total execution time: 0.1534
INFO - 2018-03-28 17:25:03 --> Config Class Initialized
INFO - 2018-03-28 17:25:03 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:25:03 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:25:03 --> Utf8 Class Initialized
INFO - 2018-03-28 17:25:03 --> URI Class Initialized
INFO - 2018-03-28 17:25:03 --> Router Class Initialized
INFO - 2018-03-28 17:25:03 --> Output Class Initialized
INFO - 2018-03-28 17:25:03 --> Security Class Initialized
DEBUG - 2018-03-28 17:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:25:03 --> Input Class Initialized
INFO - 2018-03-28 17:25:03 --> Language Class Initialized
INFO - 2018-03-28 17:25:03 --> Loader Class Initialized
INFO - 2018-03-28 17:25:03 --> Helper loaded: url_helper
INFO - 2018-03-28 17:25:03 --> Helper loaded: form_helper
INFO - 2018-03-28 17:25:03 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:25:03 --> Controller Class Initialized
INFO - 2018-03-28 17:25:03 --> Model Class Initialized
INFO - 2018-03-28 17:25:03 --> Model Class Initialized
INFO - 2018-03-28 17:25:03 --> Model Class Initialized
INFO - 2018-03-28 17:25:03 --> Model Class Initialized
INFO - 2018-03-28 17:25:03 --> Model Class Initialized
INFO - 2018-03-28 17:25:03 --> Model Class Initialized
INFO - 2018-03-28 17:25:03 --> Model Class Initialized
INFO - 2018-03-28 17:25:03 --> Model Class Initialized
INFO - 2018-03-28 17:25:03 --> Model Class Initialized
INFO - 2018-03-28 17:25:03 --> Model Class Initialized
INFO - 2018-03-28 17:25:03 --> Model Class Initialized
INFO - 2018-03-28 17:25:03 --> Model Class Initialized
INFO - 2018-03-28 17:25:03 --> Model Class Initialized
INFO - 2018-03-28 17:25:03 --> Model Class Initialized
INFO - 2018-03-28 17:25:03 --> Helper loaded: date_helper
INFO - 2018-03-28 17:25:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:25:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:25:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:25:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-28 22:25:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:25:03 --> Final output sent to browser
DEBUG - 2018-03-28 22:25:03 --> Total execution time: 0.1554
INFO - 2018-03-28 17:25:13 --> Config Class Initialized
INFO - 2018-03-28 17:25:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:25:13 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:25:13 --> Utf8 Class Initialized
INFO - 2018-03-28 17:25:13 --> URI Class Initialized
INFO - 2018-03-28 17:25:13 --> Router Class Initialized
INFO - 2018-03-28 17:25:13 --> Output Class Initialized
INFO - 2018-03-28 17:25:13 --> Security Class Initialized
DEBUG - 2018-03-28 17:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:25:13 --> Input Class Initialized
INFO - 2018-03-28 17:25:13 --> Language Class Initialized
INFO - 2018-03-28 17:25:13 --> Loader Class Initialized
INFO - 2018-03-28 17:25:13 --> Helper loaded: url_helper
INFO - 2018-03-28 17:25:13 --> Helper loaded: form_helper
INFO - 2018-03-28 17:25:13 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:25:13 --> Controller Class Initialized
INFO - 2018-03-28 17:25:13 --> Model Class Initialized
INFO - 2018-03-28 17:25:13 --> Model Class Initialized
INFO - 2018-03-28 17:25:13 --> Model Class Initialized
INFO - 2018-03-28 17:25:13 --> Model Class Initialized
INFO - 2018-03-28 17:25:13 --> Model Class Initialized
INFO - 2018-03-28 17:25:13 --> Model Class Initialized
INFO - 2018-03-28 17:25:13 --> Model Class Initialized
INFO - 2018-03-28 17:25:13 --> Model Class Initialized
INFO - 2018-03-28 17:25:13 --> Model Class Initialized
INFO - 2018-03-28 17:25:13 --> Model Class Initialized
INFO - 2018-03-28 17:25:13 --> Model Class Initialized
INFO - 2018-03-28 17:25:13 --> Model Class Initialized
INFO - 2018-03-28 17:25:13 --> Model Class Initialized
INFO - 2018-03-28 17:25:13 --> Model Class Initialized
INFO - 2018-03-28 17:25:13 --> Helper loaded: date_helper
INFO - 2018-03-28 17:25:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:25:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:25:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:25:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/create.php
INFO - 2018-03-28 22:25:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:25:13 --> Final output sent to browser
DEBUG - 2018-03-28 22:25:13 --> Total execution time: 0.1554
INFO - 2018-03-28 17:25:18 --> Config Class Initialized
INFO - 2018-03-28 17:25:18 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:25:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:25:18 --> Utf8 Class Initialized
INFO - 2018-03-28 17:25:18 --> URI Class Initialized
INFO - 2018-03-28 17:25:18 --> Router Class Initialized
INFO - 2018-03-28 17:25:18 --> Output Class Initialized
INFO - 2018-03-28 17:25:18 --> Security Class Initialized
DEBUG - 2018-03-28 17:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:25:18 --> Input Class Initialized
INFO - 2018-03-28 17:25:18 --> Language Class Initialized
INFO - 2018-03-28 17:25:18 --> Loader Class Initialized
INFO - 2018-03-28 17:25:18 --> Helper loaded: url_helper
INFO - 2018-03-28 17:25:18 --> Helper loaded: form_helper
INFO - 2018-03-28 17:25:18 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:25:18 --> Controller Class Initialized
INFO - 2018-03-28 17:25:18 --> Model Class Initialized
INFO - 2018-03-28 17:25:18 --> Model Class Initialized
INFO - 2018-03-28 17:25:18 --> Model Class Initialized
INFO - 2018-03-28 17:25:18 --> Model Class Initialized
INFO - 2018-03-28 17:25:18 --> Model Class Initialized
INFO - 2018-03-28 17:25:18 --> Model Class Initialized
INFO - 2018-03-28 17:25:18 --> Model Class Initialized
INFO - 2018-03-28 17:25:18 --> Model Class Initialized
INFO - 2018-03-28 17:25:18 --> Model Class Initialized
INFO - 2018-03-28 17:25:18 --> Model Class Initialized
INFO - 2018-03-28 17:25:18 --> Model Class Initialized
INFO - 2018-03-28 17:25:18 --> Model Class Initialized
INFO - 2018-03-28 17:25:18 --> Model Class Initialized
INFO - 2018-03-28 17:25:18 --> Model Class Initialized
INFO - 2018-03-28 17:25:18 --> Helper loaded: date_helper
INFO - 2018-03-28 17:25:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:25:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:25:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:25:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/create.php
INFO - 2018-03-28 22:25:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:25:18 --> Final output sent to browser
DEBUG - 2018-03-28 22:25:18 --> Total execution time: 0.1364
INFO - 2018-03-28 17:25:24 --> Config Class Initialized
INFO - 2018-03-28 17:25:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:25:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:25:24 --> Utf8 Class Initialized
INFO - 2018-03-28 17:25:24 --> URI Class Initialized
INFO - 2018-03-28 17:25:24 --> Router Class Initialized
INFO - 2018-03-28 17:25:24 --> Output Class Initialized
INFO - 2018-03-28 17:25:24 --> Security Class Initialized
DEBUG - 2018-03-28 17:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:25:24 --> Input Class Initialized
INFO - 2018-03-28 17:25:24 --> Language Class Initialized
INFO - 2018-03-28 17:25:24 --> Loader Class Initialized
INFO - 2018-03-28 17:25:24 --> Helper loaded: url_helper
INFO - 2018-03-28 17:25:24 --> Helper loaded: form_helper
INFO - 2018-03-28 17:25:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:25:24 --> Controller Class Initialized
INFO - 2018-03-28 17:25:24 --> Model Class Initialized
INFO - 2018-03-28 17:25:24 --> Model Class Initialized
INFO - 2018-03-28 17:25:24 --> Model Class Initialized
INFO - 2018-03-28 17:25:24 --> Model Class Initialized
INFO - 2018-03-28 17:25:24 --> Model Class Initialized
INFO - 2018-03-28 17:25:24 --> Model Class Initialized
INFO - 2018-03-28 17:25:24 --> Model Class Initialized
INFO - 2018-03-28 17:25:24 --> Model Class Initialized
INFO - 2018-03-28 17:25:24 --> Model Class Initialized
INFO - 2018-03-28 17:25:24 --> Model Class Initialized
INFO - 2018-03-28 17:25:24 --> Helper loaded: date_helper
INFO - 2018-03-28 17:25:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:25:24 --> Model Class Initialized
INFO - 2018-03-28 22:25:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:25:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:25:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/create.php
INFO - 2018-03-28 22:25:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:25:24 --> Final output sent to browser
DEBUG - 2018-03-28 22:25:24 --> Total execution time: 0.1566
INFO - 2018-03-28 17:25:34 --> Config Class Initialized
INFO - 2018-03-28 17:25:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:25:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:25:34 --> Utf8 Class Initialized
INFO - 2018-03-28 17:25:34 --> URI Class Initialized
INFO - 2018-03-28 17:25:34 --> Router Class Initialized
INFO - 2018-03-28 17:25:34 --> Output Class Initialized
INFO - 2018-03-28 17:25:34 --> Security Class Initialized
DEBUG - 2018-03-28 17:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:25:34 --> Input Class Initialized
INFO - 2018-03-28 17:25:34 --> Language Class Initialized
INFO - 2018-03-28 17:25:34 --> Loader Class Initialized
INFO - 2018-03-28 17:25:34 --> Helper loaded: url_helper
INFO - 2018-03-28 17:25:34 --> Helper loaded: form_helper
INFO - 2018-03-28 17:25:34 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:25:34 --> Controller Class Initialized
INFO - 2018-03-28 17:25:34 --> Model Class Initialized
INFO - 2018-03-28 17:25:34 --> Model Class Initialized
INFO - 2018-03-28 17:25:34 --> Model Class Initialized
INFO - 2018-03-28 17:25:34 --> Model Class Initialized
INFO - 2018-03-28 17:25:34 --> Model Class Initialized
INFO - 2018-03-28 17:25:34 --> Model Class Initialized
INFO - 2018-03-28 17:25:34 --> Model Class Initialized
INFO - 2018-03-28 17:25:34 --> Model Class Initialized
INFO - 2018-03-28 17:25:34 --> Model Class Initialized
INFO - 2018-03-28 17:25:34 --> Model Class Initialized
INFO - 2018-03-28 17:25:34 --> Helper loaded: date_helper
INFO - 2018-03-28 17:25:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:25:34 --> Model Class Initialized
INFO - 2018-03-28 22:25:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:25:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:25:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-28 22:25:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:25:34 --> Final output sent to browser
DEBUG - 2018-03-28 22:25:34 --> Total execution time: 0.1807
INFO - 2018-03-28 17:25:37 --> Config Class Initialized
INFO - 2018-03-28 17:25:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:25:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:25:37 --> Utf8 Class Initialized
INFO - 2018-03-28 17:25:37 --> URI Class Initialized
INFO - 2018-03-28 17:25:37 --> Router Class Initialized
INFO - 2018-03-28 17:25:37 --> Output Class Initialized
INFO - 2018-03-28 17:25:37 --> Security Class Initialized
DEBUG - 2018-03-28 17:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:25:37 --> Input Class Initialized
INFO - 2018-03-28 17:25:37 --> Language Class Initialized
INFO - 2018-03-28 17:25:37 --> Loader Class Initialized
INFO - 2018-03-28 17:25:37 --> Helper loaded: url_helper
INFO - 2018-03-28 17:25:37 --> Helper loaded: form_helper
INFO - 2018-03-28 17:25:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:25:37 --> Controller Class Initialized
INFO - 2018-03-28 17:25:37 --> Model Class Initialized
INFO - 2018-03-28 17:25:37 --> Model Class Initialized
INFO - 2018-03-28 17:25:37 --> Model Class Initialized
INFO - 2018-03-28 17:25:37 --> Model Class Initialized
INFO - 2018-03-28 17:25:37 --> Model Class Initialized
INFO - 2018-03-28 17:25:37 --> Model Class Initialized
INFO - 2018-03-28 17:25:37 --> Model Class Initialized
INFO - 2018-03-28 17:25:37 --> Model Class Initialized
INFO - 2018-03-28 17:25:37 --> Model Class Initialized
INFO - 2018-03-28 17:25:37 --> Model Class Initialized
INFO - 2018-03-28 17:25:37 --> Helper loaded: date_helper
INFO - 2018-03-28 17:25:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:25:37 --> Model Class Initialized
INFO - 2018-03-28 22:25:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:25:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:25:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/create.php
INFO - 2018-03-28 22:25:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:25:37 --> Final output sent to browser
DEBUG - 2018-03-28 22:25:37 --> Total execution time: 0.1426
INFO - 2018-03-28 17:25:45 --> Config Class Initialized
INFO - 2018-03-28 17:25:45 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:25:45 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:25:45 --> Utf8 Class Initialized
INFO - 2018-03-28 17:25:45 --> URI Class Initialized
INFO - 2018-03-28 17:25:45 --> Router Class Initialized
INFO - 2018-03-28 17:25:45 --> Output Class Initialized
INFO - 2018-03-28 17:25:45 --> Security Class Initialized
DEBUG - 2018-03-28 17:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:25:45 --> Input Class Initialized
INFO - 2018-03-28 17:25:45 --> Language Class Initialized
INFO - 2018-03-28 17:25:45 --> Loader Class Initialized
INFO - 2018-03-28 17:25:45 --> Helper loaded: url_helper
INFO - 2018-03-28 17:25:45 --> Helper loaded: form_helper
INFO - 2018-03-28 17:25:45 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:25:46 --> Controller Class Initialized
INFO - 2018-03-28 17:25:46 --> Model Class Initialized
INFO - 2018-03-28 17:25:46 --> Model Class Initialized
INFO - 2018-03-28 17:25:46 --> Model Class Initialized
INFO - 2018-03-28 17:25:46 --> Model Class Initialized
INFO - 2018-03-28 17:25:46 --> Model Class Initialized
INFO - 2018-03-28 17:25:46 --> Model Class Initialized
INFO - 2018-03-28 17:25:46 --> Model Class Initialized
INFO - 2018-03-28 17:25:46 --> Model Class Initialized
INFO - 2018-03-28 17:25:46 --> Model Class Initialized
INFO - 2018-03-28 17:25:46 --> Model Class Initialized
INFO - 2018-03-28 17:25:46 --> Model Class Initialized
INFO - 2018-03-28 17:25:46 --> Model Class Initialized
INFO - 2018-03-28 17:25:46 --> Model Class Initialized
INFO - 2018-03-28 17:25:46 --> Model Class Initialized
INFO - 2018-03-28 17:25:46 --> Helper loaded: date_helper
INFO - 2018-03-28 17:25:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:25:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:25:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:25:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-28 22:25:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:25:46 --> Final output sent to browser
DEBUG - 2018-03-28 22:25:46 --> Total execution time: 0.1306
INFO - 2018-03-28 17:25:49 --> Config Class Initialized
INFO - 2018-03-28 17:25:49 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:25:49 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:25:49 --> Utf8 Class Initialized
INFO - 2018-03-28 17:25:49 --> URI Class Initialized
INFO - 2018-03-28 17:25:49 --> Router Class Initialized
INFO - 2018-03-28 17:25:49 --> Output Class Initialized
INFO - 2018-03-28 17:25:49 --> Security Class Initialized
DEBUG - 2018-03-28 17:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:25:49 --> Input Class Initialized
INFO - 2018-03-28 17:25:49 --> Language Class Initialized
INFO - 2018-03-28 17:25:49 --> Loader Class Initialized
INFO - 2018-03-28 17:25:49 --> Helper loaded: url_helper
INFO - 2018-03-28 17:25:49 --> Helper loaded: form_helper
INFO - 2018-03-28 17:25:49 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:25:49 --> Controller Class Initialized
INFO - 2018-03-28 17:25:49 --> Model Class Initialized
INFO - 2018-03-28 17:25:49 --> Model Class Initialized
INFO - 2018-03-28 17:25:49 --> Model Class Initialized
INFO - 2018-03-28 17:25:49 --> Model Class Initialized
INFO - 2018-03-28 17:25:49 --> Model Class Initialized
INFO - 2018-03-28 17:25:49 --> Model Class Initialized
INFO - 2018-03-28 17:25:49 --> Model Class Initialized
INFO - 2018-03-28 17:25:49 --> Model Class Initialized
INFO - 2018-03-28 17:25:49 --> Model Class Initialized
INFO - 2018-03-28 17:25:49 --> Model Class Initialized
INFO - 2018-03-28 17:25:49 --> Model Class Initialized
INFO - 2018-03-28 17:25:49 --> Model Class Initialized
INFO - 2018-03-28 17:25:49 --> Model Class Initialized
INFO - 2018-03-28 17:25:49 --> Model Class Initialized
INFO - 2018-03-28 17:25:49 --> Helper loaded: date_helper
INFO - 2018-03-28 17:25:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:25:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:25:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:25:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/create.php
INFO - 2018-03-28 22:25:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:25:49 --> Final output sent to browser
DEBUG - 2018-03-28 22:25:49 --> Total execution time: 0.1508
INFO - 2018-03-28 17:26:09 --> Config Class Initialized
INFO - 2018-03-28 17:26:09 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:26:09 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:26:09 --> Utf8 Class Initialized
INFO - 2018-03-28 17:26:09 --> URI Class Initialized
INFO - 2018-03-28 17:26:09 --> Router Class Initialized
INFO - 2018-03-28 17:26:09 --> Output Class Initialized
INFO - 2018-03-28 17:26:09 --> Security Class Initialized
DEBUG - 2018-03-28 17:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:26:09 --> Input Class Initialized
INFO - 2018-03-28 17:26:09 --> Language Class Initialized
INFO - 2018-03-28 17:26:09 --> Loader Class Initialized
INFO - 2018-03-28 17:26:09 --> Helper loaded: url_helper
INFO - 2018-03-28 17:26:09 --> Helper loaded: form_helper
INFO - 2018-03-28 17:26:09 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:26:09 --> Controller Class Initialized
INFO - 2018-03-28 17:26:09 --> Model Class Initialized
INFO - 2018-03-28 17:26:09 --> Model Class Initialized
INFO - 2018-03-28 17:26:09 --> Helper loaded: date_helper
INFO - 2018-03-28 17:26:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:26:09 --> Model Class Initialized
INFO - 2018-03-28 22:26:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:26:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:26:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 22:26:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:26:09 --> Final output sent to browser
DEBUG - 2018-03-28 22:26:09 --> Total execution time: 0.1306
INFO - 2018-03-28 17:26:25 --> Config Class Initialized
INFO - 2018-03-28 17:26:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:26:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:26:25 --> Utf8 Class Initialized
INFO - 2018-03-28 17:26:25 --> URI Class Initialized
INFO - 2018-03-28 17:26:25 --> Router Class Initialized
INFO - 2018-03-28 17:26:25 --> Output Class Initialized
INFO - 2018-03-28 17:26:25 --> Security Class Initialized
DEBUG - 2018-03-28 17:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:26:25 --> Input Class Initialized
INFO - 2018-03-28 17:26:25 --> Language Class Initialized
INFO - 2018-03-28 17:26:25 --> Loader Class Initialized
INFO - 2018-03-28 17:26:25 --> Helper loaded: url_helper
INFO - 2018-03-28 17:26:25 --> Helper loaded: form_helper
INFO - 2018-03-28 17:26:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:26:25 --> Controller Class Initialized
INFO - 2018-03-28 17:26:25 --> Model Class Initialized
INFO - 2018-03-28 17:26:25 --> Model Class Initialized
INFO - 2018-03-28 17:26:25 --> Helper loaded: date_helper
INFO - 2018-03-28 17:26:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:26:25 --> Model Class Initialized
INFO - 2018-03-28 22:26:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:26:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:26:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/edit.php
INFO - 2018-03-28 22:26:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:26:25 --> Final output sent to browser
DEBUG - 2018-03-28 22:26:25 --> Total execution time: 0.1824
INFO - 2018-03-28 17:26:31 --> Config Class Initialized
INFO - 2018-03-28 17:26:31 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:26:31 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:26:31 --> Utf8 Class Initialized
INFO - 2018-03-28 17:26:31 --> URI Class Initialized
INFO - 2018-03-28 17:26:31 --> Router Class Initialized
INFO - 2018-03-28 17:26:31 --> Output Class Initialized
INFO - 2018-03-28 17:26:31 --> Security Class Initialized
DEBUG - 2018-03-28 17:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:26:31 --> Input Class Initialized
INFO - 2018-03-28 17:26:31 --> Language Class Initialized
INFO - 2018-03-28 17:26:31 --> Loader Class Initialized
INFO - 2018-03-28 17:26:31 --> Helper loaded: url_helper
INFO - 2018-03-28 17:26:31 --> Helper loaded: form_helper
INFO - 2018-03-28 17:26:31 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:26:31 --> Controller Class Initialized
INFO - 2018-03-28 17:26:31 --> Model Class Initialized
INFO - 2018-03-28 17:26:31 --> Model Class Initialized
INFO - 2018-03-28 17:26:31 --> Helper loaded: date_helper
INFO - 2018-03-28 17:26:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:26:31 --> Model Class Initialized
INFO - 2018-03-28 22:26:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:26:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:26:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 22:26:32 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:26:32 --> Final output sent to browser
DEBUG - 2018-03-28 22:26:32 --> Total execution time: 0.1302
INFO - 2018-03-28 17:26:42 --> Config Class Initialized
INFO - 2018-03-28 17:26:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:26:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:26:42 --> Utf8 Class Initialized
INFO - 2018-03-28 17:26:42 --> URI Class Initialized
INFO - 2018-03-28 17:26:42 --> Router Class Initialized
INFO - 2018-03-28 17:26:42 --> Output Class Initialized
INFO - 2018-03-28 17:26:42 --> Security Class Initialized
DEBUG - 2018-03-28 17:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:26:42 --> Input Class Initialized
INFO - 2018-03-28 17:26:42 --> Language Class Initialized
INFO - 2018-03-28 17:26:42 --> Loader Class Initialized
INFO - 2018-03-28 17:26:42 --> Helper loaded: url_helper
INFO - 2018-03-28 17:26:42 --> Helper loaded: form_helper
INFO - 2018-03-28 17:26:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:26:42 --> Controller Class Initialized
INFO - 2018-03-28 17:26:42 --> Model Class Initialized
INFO - 2018-03-28 17:26:42 --> Model Class Initialized
INFO - 2018-03-28 17:26:42 --> Model Class Initialized
INFO - 2018-03-28 17:26:42 --> Model Class Initialized
INFO - 2018-03-28 17:26:42 --> Model Class Initialized
INFO - 2018-03-28 17:26:42 --> Helper loaded: date_helper
INFO - 2018-03-28 17:26:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:26:42 --> Model Class Initialized
INFO - 2018-03-28 22:26:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:26:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:26:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-28 22:26:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:26:42 --> Final output sent to browser
DEBUG - 2018-03-28 22:26:42 --> Total execution time: 0.3140
INFO - 2018-03-28 17:26:48 --> Config Class Initialized
INFO - 2018-03-28 17:26:48 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:26:48 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:26:48 --> Utf8 Class Initialized
INFO - 2018-03-28 17:26:48 --> URI Class Initialized
INFO - 2018-03-28 17:26:48 --> Router Class Initialized
INFO - 2018-03-28 17:26:48 --> Output Class Initialized
INFO - 2018-03-28 17:26:48 --> Security Class Initialized
DEBUG - 2018-03-28 17:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:26:48 --> Input Class Initialized
INFO - 2018-03-28 17:26:48 --> Language Class Initialized
INFO - 2018-03-28 17:26:48 --> Loader Class Initialized
INFO - 2018-03-28 17:26:48 --> Helper loaded: url_helper
INFO - 2018-03-28 17:26:48 --> Helper loaded: form_helper
INFO - 2018-03-28 17:26:48 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:26:48 --> Controller Class Initialized
INFO - 2018-03-28 17:26:48 --> Model Class Initialized
INFO - 2018-03-28 17:26:48 --> Model Class Initialized
INFO - 2018-03-28 17:26:48 --> Model Class Initialized
INFO - 2018-03-28 17:26:48 --> Model Class Initialized
INFO - 2018-03-28 17:26:48 --> Model Class Initialized
INFO - 2018-03-28 17:26:48 --> Helper loaded: date_helper
INFO - 2018-03-28 17:26:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:26:48 --> Model Class Initialized
INFO - 2018-03-28 22:26:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:26:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:26:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/create.php
INFO - 2018-03-28 22:26:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:26:48 --> Final output sent to browser
DEBUG - 2018-03-28 22:26:48 --> Total execution time: 0.1613
INFO - 2018-03-28 17:28:03 --> Config Class Initialized
INFO - 2018-03-28 17:28:03 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:28:03 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:28:03 --> Utf8 Class Initialized
INFO - 2018-03-28 17:28:03 --> URI Class Initialized
INFO - 2018-03-28 17:28:03 --> Router Class Initialized
INFO - 2018-03-28 17:28:03 --> Output Class Initialized
INFO - 2018-03-28 17:28:03 --> Security Class Initialized
DEBUG - 2018-03-28 17:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:28:03 --> Input Class Initialized
INFO - 2018-03-28 17:28:03 --> Language Class Initialized
INFO - 2018-03-28 17:28:03 --> Loader Class Initialized
INFO - 2018-03-28 17:28:03 --> Helper loaded: url_helper
INFO - 2018-03-28 17:28:03 --> Helper loaded: form_helper
INFO - 2018-03-28 17:28:03 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:28:04 --> Controller Class Initialized
INFO - 2018-03-28 17:28:04 --> Model Class Initialized
INFO - 2018-03-28 17:28:04 --> Model Class Initialized
INFO - 2018-03-28 17:28:04 --> Helper loaded: date_helper
INFO - 2018-03-28 17:28:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:28:04 --> Final output sent to browser
DEBUG - 2018-03-28 22:28:04 --> Total execution time: 0.1199
INFO - 2018-03-28 17:29:15 --> Config Class Initialized
INFO - 2018-03-28 17:29:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:29:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:29:15 --> Utf8 Class Initialized
INFO - 2018-03-28 17:29:15 --> URI Class Initialized
INFO - 2018-03-28 17:29:15 --> Router Class Initialized
INFO - 2018-03-28 17:29:15 --> Output Class Initialized
INFO - 2018-03-28 17:29:15 --> Security Class Initialized
DEBUG - 2018-03-28 17:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:29:15 --> Input Class Initialized
INFO - 2018-03-28 17:29:15 --> Language Class Initialized
INFO - 2018-03-28 17:29:15 --> Loader Class Initialized
INFO - 2018-03-28 17:29:15 --> Helper loaded: url_helper
INFO - 2018-03-28 17:29:15 --> Helper loaded: form_helper
INFO - 2018-03-28 17:29:15 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:29:15 --> Controller Class Initialized
INFO - 2018-03-28 17:29:15 --> Model Class Initialized
INFO - 2018-03-28 17:29:15 --> Model Class Initialized
INFO - 2018-03-28 17:29:15 --> Model Class Initialized
INFO - 2018-03-28 17:29:15 --> Model Class Initialized
INFO - 2018-03-28 17:29:15 --> Model Class Initialized
INFO - 2018-03-28 17:29:15 --> Model Class Initialized
INFO - 2018-03-28 17:29:15 --> Model Class Initialized
INFO - 2018-03-28 17:29:15 --> Model Class Initialized
INFO - 2018-03-28 17:29:15 --> Model Class Initialized
INFO - 2018-03-28 17:29:15 --> Model Class Initialized
INFO - 2018-03-28 17:29:15 --> Model Class Initialized
INFO - 2018-03-28 17:29:15 --> Model Class Initialized
INFO - 2018-03-28 17:29:15 --> Helper loaded: date_helper
INFO - 2018-03-28 17:29:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:29:15 --> Model Class Initialized
INFO - 2018-03-28 22:29:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:29:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:29:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-28 22:29:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:29:15 --> Final output sent to browser
DEBUG - 2018-03-28 22:29:15 --> Total execution time: 0.1796
INFO - 2018-03-28 17:29:23 --> Config Class Initialized
INFO - 2018-03-28 17:29:23 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:29:23 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:29:23 --> Utf8 Class Initialized
INFO - 2018-03-28 17:29:23 --> URI Class Initialized
INFO - 2018-03-28 17:29:23 --> Router Class Initialized
INFO - 2018-03-28 17:29:23 --> Output Class Initialized
INFO - 2018-03-28 17:29:23 --> Security Class Initialized
DEBUG - 2018-03-28 17:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:29:23 --> Input Class Initialized
INFO - 2018-03-28 17:29:23 --> Language Class Initialized
INFO - 2018-03-28 17:29:23 --> Loader Class Initialized
INFO - 2018-03-28 17:29:23 --> Helper loaded: url_helper
INFO - 2018-03-28 17:29:23 --> Helper loaded: form_helper
INFO - 2018-03-28 17:29:23 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:29:23 --> Controller Class Initialized
INFO - 2018-03-28 17:29:23 --> Model Class Initialized
INFO - 2018-03-28 17:29:23 --> Model Class Initialized
INFO - 2018-03-28 17:29:23 --> Model Class Initialized
INFO - 2018-03-28 17:29:23 --> Model Class Initialized
INFO - 2018-03-28 17:29:23 --> Model Class Initialized
INFO - 2018-03-28 17:29:23 --> Model Class Initialized
INFO - 2018-03-28 17:29:23 --> Model Class Initialized
INFO - 2018-03-28 17:29:23 --> Model Class Initialized
INFO - 2018-03-28 17:29:23 --> Model Class Initialized
INFO - 2018-03-28 17:29:23 --> Model Class Initialized
INFO - 2018-03-28 17:29:23 --> Model Class Initialized
INFO - 2018-03-28 17:29:23 --> Model Class Initialized
INFO - 2018-03-28 17:29:23 --> Model Class Initialized
INFO - 2018-03-28 17:29:23 --> Model Class Initialized
INFO - 2018-03-28 17:29:23 --> Helper loaded: date_helper
INFO - 2018-03-28 17:29:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:29:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:29:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:29:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-28 22:29:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:29:23 --> Final output sent to browser
DEBUG - 2018-03-28 22:29:23 --> Total execution time: 0.1725
INFO - 2018-03-28 17:29:26 --> Config Class Initialized
INFO - 2018-03-28 17:29:26 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:29:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:29:26 --> Utf8 Class Initialized
INFO - 2018-03-28 17:29:26 --> URI Class Initialized
INFO - 2018-03-28 17:29:26 --> Router Class Initialized
INFO - 2018-03-28 17:29:26 --> Output Class Initialized
INFO - 2018-03-28 17:29:26 --> Security Class Initialized
DEBUG - 2018-03-28 17:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:29:26 --> Input Class Initialized
INFO - 2018-03-28 17:29:26 --> Language Class Initialized
INFO - 2018-03-28 17:29:26 --> Loader Class Initialized
INFO - 2018-03-28 17:29:26 --> Helper loaded: url_helper
INFO - 2018-03-28 17:29:26 --> Helper loaded: form_helper
INFO - 2018-03-28 17:29:26 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:29:26 --> Controller Class Initialized
INFO - 2018-03-28 17:29:26 --> Model Class Initialized
INFO - 2018-03-28 17:29:26 --> Model Class Initialized
INFO - 2018-03-28 17:29:26 --> Model Class Initialized
INFO - 2018-03-28 17:29:26 --> Model Class Initialized
INFO - 2018-03-28 17:29:26 --> Model Class Initialized
INFO - 2018-03-28 17:29:26 --> Model Class Initialized
INFO - 2018-03-28 17:29:26 --> Model Class Initialized
INFO - 2018-03-28 17:29:26 --> Model Class Initialized
INFO - 2018-03-28 17:29:26 --> Model Class Initialized
INFO - 2018-03-28 17:29:26 --> Model Class Initialized
INFO - 2018-03-28 17:29:26 --> Model Class Initialized
INFO - 2018-03-28 17:29:26 --> Model Class Initialized
INFO - 2018-03-28 17:29:26 --> Model Class Initialized
INFO - 2018-03-28 17:29:26 --> Model Class Initialized
INFO - 2018-03-28 17:29:26 --> Helper loaded: date_helper
INFO - 2018-03-28 17:29:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:29:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:29:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:29:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/create.php
INFO - 2018-03-28 22:29:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:29:26 --> Final output sent to browser
DEBUG - 2018-03-28 22:29:26 --> Total execution time: 0.1344
INFO - 2018-03-28 17:29:34 --> Config Class Initialized
INFO - 2018-03-28 17:29:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:29:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:29:34 --> Utf8 Class Initialized
INFO - 2018-03-28 17:29:34 --> URI Class Initialized
INFO - 2018-03-28 17:29:34 --> Router Class Initialized
INFO - 2018-03-28 17:29:34 --> Output Class Initialized
INFO - 2018-03-28 17:29:34 --> Security Class Initialized
DEBUG - 2018-03-28 17:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:29:34 --> Input Class Initialized
INFO - 2018-03-28 17:29:34 --> Language Class Initialized
INFO - 2018-03-28 17:29:34 --> Loader Class Initialized
INFO - 2018-03-28 17:29:34 --> Helper loaded: url_helper
INFO - 2018-03-28 17:29:34 --> Helper loaded: form_helper
INFO - 2018-03-28 17:29:34 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:29:34 --> Controller Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Helper loaded: date_helper
INFO - 2018-03-28 17:29:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:29:34 --> Final output sent to browser
DEBUG - 2018-03-28 22:29:34 --> Total execution time: 0.1704
INFO - 2018-03-28 17:29:34 --> Config Class Initialized
INFO - 2018-03-28 17:29:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:29:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:29:34 --> Utf8 Class Initialized
INFO - 2018-03-28 17:29:34 --> URI Class Initialized
INFO - 2018-03-28 17:29:34 --> Router Class Initialized
INFO - 2018-03-28 17:29:34 --> Output Class Initialized
INFO - 2018-03-28 17:29:34 --> Security Class Initialized
DEBUG - 2018-03-28 17:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:29:34 --> Input Class Initialized
INFO - 2018-03-28 17:29:34 --> Language Class Initialized
INFO - 2018-03-28 17:29:34 --> Loader Class Initialized
INFO - 2018-03-28 17:29:34 --> Helper loaded: url_helper
INFO - 2018-03-28 17:29:34 --> Helper loaded: form_helper
INFO - 2018-03-28 17:29:34 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:29:34 --> Controller Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Helper loaded: date_helper
INFO - 2018-03-28 17:29:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:29:34 --> Final output sent to browser
DEBUG - 2018-03-28 22:29:34 --> Total execution time: 0.1828
INFO - 2018-03-28 17:29:34 --> Config Class Initialized
INFO - 2018-03-28 17:29:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:29:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:29:34 --> Utf8 Class Initialized
INFO - 2018-03-28 17:29:34 --> URI Class Initialized
INFO - 2018-03-28 17:29:34 --> Router Class Initialized
INFO - 2018-03-28 17:29:34 --> Output Class Initialized
INFO - 2018-03-28 17:29:34 --> Security Class Initialized
DEBUG - 2018-03-28 17:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:29:34 --> Input Class Initialized
INFO - 2018-03-28 17:29:34 --> Language Class Initialized
INFO - 2018-03-28 17:29:34 --> Loader Class Initialized
INFO - 2018-03-28 17:29:34 --> Helper loaded: url_helper
INFO - 2018-03-28 17:29:34 --> Helper loaded: form_helper
INFO - 2018-03-28 17:29:34 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:29:34 --> Controller Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Model Class Initialized
INFO - 2018-03-28 17:29:34 --> Helper loaded: date_helper
INFO - 2018-03-28 17:29:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:29:34 --> Final output sent to browser
DEBUG - 2018-03-28 22:29:34 --> Total execution time: 0.1494
INFO - 2018-03-28 17:29:45 --> Config Class Initialized
INFO - 2018-03-28 17:29:45 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:29:45 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:29:45 --> Utf8 Class Initialized
INFO - 2018-03-28 17:29:45 --> URI Class Initialized
INFO - 2018-03-28 17:29:45 --> Router Class Initialized
INFO - 2018-03-28 17:29:45 --> Output Class Initialized
INFO - 2018-03-28 17:29:45 --> Security Class Initialized
DEBUG - 2018-03-28 17:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:29:45 --> Input Class Initialized
INFO - 2018-03-28 17:29:45 --> Language Class Initialized
INFO - 2018-03-28 17:29:45 --> Loader Class Initialized
INFO - 2018-03-28 17:29:45 --> Helper loaded: url_helper
INFO - 2018-03-28 17:29:45 --> Helper loaded: form_helper
INFO - 2018-03-28 17:29:45 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:29:45 --> Controller Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Helper loaded: date_helper
INFO - 2018-03-28 17:29:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 17:29:45 --> Config Class Initialized
INFO - 2018-03-28 17:29:45 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:29:45 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:29:45 --> Utf8 Class Initialized
INFO - 2018-03-28 17:29:45 --> URI Class Initialized
INFO - 2018-03-28 17:29:45 --> Router Class Initialized
INFO - 2018-03-28 17:29:45 --> Output Class Initialized
INFO - 2018-03-28 17:29:45 --> Security Class Initialized
DEBUG - 2018-03-28 17:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:29:45 --> Input Class Initialized
INFO - 2018-03-28 17:29:45 --> Language Class Initialized
INFO - 2018-03-28 17:29:45 --> Loader Class Initialized
INFO - 2018-03-28 17:29:45 --> Helper loaded: url_helper
INFO - 2018-03-28 17:29:45 --> Helper loaded: form_helper
INFO - 2018-03-28 17:29:45 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:29:45 --> Controller Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Model Class Initialized
INFO - 2018-03-28 17:29:45 --> Helper loaded: date_helper
INFO - 2018-03-28 17:29:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:29:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:29:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:29:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-28 22:29:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:29:45 --> Final output sent to browser
DEBUG - 2018-03-28 22:29:45 --> Total execution time: 0.1329
INFO - 2018-03-28 17:29:56 --> Config Class Initialized
INFO - 2018-03-28 17:29:56 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:29:56 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:29:56 --> Utf8 Class Initialized
INFO - 2018-03-28 17:29:56 --> URI Class Initialized
INFO - 2018-03-28 17:29:56 --> Router Class Initialized
INFO - 2018-03-28 17:29:56 --> Output Class Initialized
INFO - 2018-03-28 17:29:56 --> Security Class Initialized
DEBUG - 2018-03-28 17:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:29:56 --> Input Class Initialized
INFO - 2018-03-28 17:29:56 --> Language Class Initialized
INFO - 2018-03-28 17:29:56 --> Loader Class Initialized
INFO - 2018-03-28 17:29:56 --> Helper loaded: url_helper
INFO - 2018-03-28 17:29:56 --> Helper loaded: form_helper
INFO - 2018-03-28 17:29:56 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:29:56 --> Controller Class Initialized
INFO - 2018-03-28 17:29:56 --> Model Class Initialized
INFO - 2018-03-28 17:29:56 --> Model Class Initialized
INFO - 2018-03-28 17:29:56 --> Model Class Initialized
INFO - 2018-03-28 17:29:56 --> Model Class Initialized
INFO - 2018-03-28 17:29:56 --> Model Class Initialized
INFO - 2018-03-28 17:29:56 --> Model Class Initialized
INFO - 2018-03-28 17:29:56 --> Model Class Initialized
INFO - 2018-03-28 17:29:56 --> Model Class Initialized
INFO - 2018-03-28 17:29:56 --> Model Class Initialized
INFO - 2018-03-28 17:29:56 --> Model Class Initialized
INFO - 2018-03-28 17:29:56 --> Model Class Initialized
INFO - 2018-03-28 17:29:56 --> Model Class Initialized
INFO - 2018-03-28 17:29:56 --> Model Class Initialized
INFO - 2018-03-28 17:29:56 --> Model Class Initialized
INFO - 2018-03-28 17:29:56 --> Helper loaded: date_helper
INFO - 2018-03-28 17:29:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:29:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:29:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:29:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-28 22:29:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:29:56 --> Final output sent to browser
DEBUG - 2018-03-28 22:29:56 --> Total execution time: 0.2500
INFO - 2018-03-28 17:30:15 --> Config Class Initialized
INFO - 2018-03-28 17:30:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:30:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:30:15 --> Utf8 Class Initialized
INFO - 2018-03-28 17:30:15 --> URI Class Initialized
INFO - 2018-03-28 17:30:15 --> Router Class Initialized
INFO - 2018-03-28 17:30:15 --> Output Class Initialized
INFO - 2018-03-28 17:30:15 --> Security Class Initialized
DEBUG - 2018-03-28 17:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:30:15 --> Input Class Initialized
INFO - 2018-03-28 17:30:15 --> Language Class Initialized
INFO - 2018-03-28 17:30:15 --> Loader Class Initialized
INFO - 2018-03-28 17:30:15 --> Helper loaded: url_helper
INFO - 2018-03-28 17:30:15 --> Helper loaded: form_helper
INFO - 2018-03-28 17:30:15 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:30:15 --> Controller Class Initialized
INFO - 2018-03-28 17:30:15 --> Model Class Initialized
INFO - 2018-03-28 17:30:15 --> Model Class Initialized
INFO - 2018-03-28 17:30:15 --> Model Class Initialized
INFO - 2018-03-28 17:30:15 --> Model Class Initialized
INFO - 2018-03-28 17:30:15 --> Model Class Initialized
INFO - 2018-03-28 17:30:15 --> Model Class Initialized
INFO - 2018-03-28 17:30:15 --> Model Class Initialized
INFO - 2018-03-28 17:30:15 --> Model Class Initialized
INFO - 2018-03-28 17:30:15 --> Model Class Initialized
INFO - 2018-03-28 17:30:15 --> Model Class Initialized
INFO - 2018-03-28 17:30:15 --> Model Class Initialized
INFO - 2018-03-28 17:30:15 --> Model Class Initialized
INFO - 2018-03-28 17:30:15 --> Model Class Initialized
INFO - 2018-03-28 17:30:15 --> Model Class Initialized
INFO - 2018-03-28 17:30:15 --> Helper loaded: date_helper
INFO - 2018-03-28 17:30:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:30:15 --> Final output sent to browser
DEBUG - 2018-03-28 22:30:15 --> Total execution time: 0.1485
INFO - 2018-03-28 17:30:22 --> Config Class Initialized
INFO - 2018-03-28 17:30:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:30:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:30:22 --> Utf8 Class Initialized
INFO - 2018-03-28 17:30:22 --> URI Class Initialized
INFO - 2018-03-28 17:30:22 --> Router Class Initialized
INFO - 2018-03-28 17:30:22 --> Output Class Initialized
INFO - 2018-03-28 17:30:22 --> Security Class Initialized
DEBUG - 2018-03-28 17:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:30:22 --> Input Class Initialized
INFO - 2018-03-28 17:30:22 --> Language Class Initialized
INFO - 2018-03-28 17:30:22 --> Loader Class Initialized
INFO - 2018-03-28 17:30:22 --> Helper loaded: url_helper
INFO - 2018-03-28 17:30:22 --> Helper loaded: form_helper
INFO - 2018-03-28 17:30:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:30:22 --> Controller Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Helper loaded: date_helper
INFO - 2018-03-28 17:30:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 17:30:22 --> Config Class Initialized
INFO - 2018-03-28 17:30:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:30:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:30:22 --> Utf8 Class Initialized
INFO - 2018-03-28 17:30:22 --> URI Class Initialized
INFO - 2018-03-28 17:30:22 --> Router Class Initialized
INFO - 2018-03-28 17:30:22 --> Output Class Initialized
INFO - 2018-03-28 17:30:22 --> Security Class Initialized
DEBUG - 2018-03-28 17:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:30:22 --> Input Class Initialized
INFO - 2018-03-28 17:30:22 --> Language Class Initialized
INFO - 2018-03-28 17:30:22 --> Loader Class Initialized
INFO - 2018-03-28 17:30:22 --> Helper loaded: url_helper
INFO - 2018-03-28 17:30:22 --> Helper loaded: form_helper
INFO - 2018-03-28 17:30:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:30:22 --> Controller Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Model Class Initialized
INFO - 2018-03-28 17:30:22 --> Helper loaded: date_helper
INFO - 2018-03-28 17:30:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:30:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:30:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:30:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-28 22:30:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:30:22 --> Final output sent to browser
DEBUG - 2018-03-28 22:30:22 --> Total execution time: 0.2696
INFO - 2018-03-28 17:30:37 --> Config Class Initialized
INFO - 2018-03-28 17:30:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:30:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:30:37 --> Utf8 Class Initialized
INFO - 2018-03-28 17:30:37 --> URI Class Initialized
INFO - 2018-03-28 17:30:37 --> Router Class Initialized
INFO - 2018-03-28 17:30:37 --> Output Class Initialized
INFO - 2018-03-28 17:30:37 --> Security Class Initialized
DEBUG - 2018-03-28 17:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:30:37 --> Input Class Initialized
INFO - 2018-03-28 17:30:37 --> Language Class Initialized
INFO - 2018-03-28 17:30:37 --> Loader Class Initialized
INFO - 2018-03-28 17:30:37 --> Helper loaded: url_helper
INFO - 2018-03-28 17:30:37 --> Helper loaded: form_helper
INFO - 2018-03-28 17:30:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:30:37 --> Controller Class Initialized
INFO - 2018-03-28 17:30:37 --> Model Class Initialized
INFO - 2018-03-28 17:30:37 --> Model Class Initialized
INFO - 2018-03-28 17:30:37 --> Helper loaded: date_helper
INFO - 2018-03-28 17:30:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:30:37 --> Final output sent to browser
DEBUG - 2018-03-28 22:30:37 --> Total execution time: 0.1288
INFO - 2018-03-28 17:30:38 --> Config Class Initialized
INFO - 2018-03-28 17:30:38 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:30:38 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:30:38 --> Utf8 Class Initialized
INFO - 2018-03-28 17:30:38 --> URI Class Initialized
INFO - 2018-03-28 17:30:38 --> Router Class Initialized
INFO - 2018-03-28 17:30:38 --> Output Class Initialized
INFO - 2018-03-28 17:30:38 --> Security Class Initialized
DEBUG - 2018-03-28 17:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:30:38 --> Input Class Initialized
INFO - 2018-03-28 17:30:38 --> Language Class Initialized
INFO - 2018-03-28 17:30:38 --> Loader Class Initialized
INFO - 2018-03-28 17:30:38 --> Helper loaded: url_helper
INFO - 2018-03-28 17:30:38 --> Helper loaded: form_helper
INFO - 2018-03-28 17:30:38 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:30:38 --> Controller Class Initialized
INFO - 2018-03-28 17:30:38 --> Model Class Initialized
INFO - 2018-03-28 17:30:38 --> Model Class Initialized
INFO - 2018-03-28 17:30:38 --> Helper loaded: date_helper
INFO - 2018-03-28 17:30:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:30:38 --> Final output sent to browser
DEBUG - 2018-03-28 22:30:38 --> Total execution time: 0.1152
INFO - 2018-03-28 17:30:42 --> Config Class Initialized
INFO - 2018-03-28 17:30:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:30:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:30:42 --> Utf8 Class Initialized
INFO - 2018-03-28 17:30:42 --> URI Class Initialized
INFO - 2018-03-28 17:30:42 --> Router Class Initialized
INFO - 2018-03-28 17:30:42 --> Output Class Initialized
INFO - 2018-03-28 17:30:42 --> Security Class Initialized
DEBUG - 2018-03-28 17:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:30:42 --> Input Class Initialized
INFO - 2018-03-28 17:30:42 --> Language Class Initialized
INFO - 2018-03-28 17:30:42 --> Loader Class Initialized
INFO - 2018-03-28 17:30:42 --> Helper loaded: url_helper
INFO - 2018-03-28 17:30:42 --> Helper loaded: form_helper
INFO - 2018-03-28 17:30:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:30:42 --> Controller Class Initialized
INFO - 2018-03-28 17:30:42 --> Model Class Initialized
INFO - 2018-03-28 17:30:42 --> Model Class Initialized
INFO - 2018-03-28 17:30:42 --> Helper loaded: date_helper
INFO - 2018-03-28 17:30:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:30:42 --> Final output sent to browser
DEBUG - 2018-03-28 22:30:42 --> Total execution time: 0.1102
INFO - 2018-03-28 17:30:42 --> Config Class Initialized
INFO - 2018-03-28 17:30:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:30:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:30:42 --> Utf8 Class Initialized
INFO - 2018-03-28 17:30:42 --> URI Class Initialized
INFO - 2018-03-28 17:30:42 --> Router Class Initialized
INFO - 2018-03-28 17:30:42 --> Output Class Initialized
INFO - 2018-03-28 17:30:42 --> Security Class Initialized
DEBUG - 2018-03-28 17:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:30:42 --> Input Class Initialized
INFO - 2018-03-28 17:30:42 --> Language Class Initialized
INFO - 2018-03-28 17:30:42 --> Loader Class Initialized
INFO - 2018-03-28 17:30:42 --> Helper loaded: url_helper
INFO - 2018-03-28 17:30:42 --> Helper loaded: form_helper
INFO - 2018-03-28 17:30:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:30:42 --> Controller Class Initialized
INFO - 2018-03-28 17:30:42 --> Model Class Initialized
INFO - 2018-03-28 17:30:42 --> Model Class Initialized
INFO - 2018-03-28 17:30:42 --> Helper loaded: date_helper
INFO - 2018-03-28 17:30:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:30:42 --> Final output sent to browser
DEBUG - 2018-03-28 22:30:42 --> Total execution time: 0.1339
INFO - 2018-03-28 17:30:46 --> Config Class Initialized
INFO - 2018-03-28 17:30:46 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:30:46 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:30:46 --> Utf8 Class Initialized
INFO - 2018-03-28 17:30:46 --> URI Class Initialized
INFO - 2018-03-28 17:30:46 --> Router Class Initialized
INFO - 2018-03-28 17:30:46 --> Output Class Initialized
INFO - 2018-03-28 17:30:46 --> Security Class Initialized
DEBUG - 2018-03-28 17:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:30:46 --> Input Class Initialized
INFO - 2018-03-28 17:30:46 --> Language Class Initialized
INFO - 2018-03-28 17:30:46 --> Loader Class Initialized
INFO - 2018-03-28 17:30:46 --> Helper loaded: url_helper
INFO - 2018-03-28 17:30:46 --> Helper loaded: form_helper
INFO - 2018-03-28 17:30:46 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:30:46 --> Controller Class Initialized
INFO - 2018-03-28 17:30:46 --> Model Class Initialized
INFO - 2018-03-28 17:30:46 --> Model Class Initialized
INFO - 2018-03-28 17:30:46 --> Helper loaded: date_helper
INFO - 2018-03-28 17:30:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:30:46 --> Final output sent to browser
DEBUG - 2018-03-28 22:30:46 --> Total execution time: 0.1188
INFO - 2018-03-28 17:30:59 --> Config Class Initialized
INFO - 2018-03-28 17:30:59 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:30:59 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:30:59 --> Utf8 Class Initialized
INFO - 2018-03-28 17:30:59 --> URI Class Initialized
INFO - 2018-03-28 17:30:59 --> Router Class Initialized
INFO - 2018-03-28 17:30:59 --> Output Class Initialized
INFO - 2018-03-28 17:30:59 --> Security Class Initialized
DEBUG - 2018-03-28 17:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:30:59 --> Input Class Initialized
INFO - 2018-03-28 17:30:59 --> Language Class Initialized
INFO - 2018-03-28 17:30:59 --> Loader Class Initialized
INFO - 2018-03-28 17:30:59 --> Helper loaded: url_helper
INFO - 2018-03-28 17:30:59 --> Helper loaded: form_helper
INFO - 2018-03-28 17:30:59 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:30:59 --> Controller Class Initialized
INFO - 2018-03-28 17:30:59 --> Model Class Initialized
INFO - 2018-03-28 17:30:59 --> Model Class Initialized
INFO - 2018-03-28 17:30:59 --> Model Class Initialized
INFO - 2018-03-28 17:30:59 --> Model Class Initialized
INFO - 2018-03-28 17:30:59 --> Model Class Initialized
INFO - 2018-03-28 17:30:59 --> Helper loaded: date_helper
INFO - 2018-03-28 17:30:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:30:59 --> Model Class Initialized
INFO - 2018-03-28 22:30:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:30:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:30:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-28 22:30:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:30:59 --> Final output sent to browser
DEBUG - 2018-03-28 22:30:59 --> Total execution time: 0.1218
INFO - 2018-03-28 17:31:03 --> Config Class Initialized
INFO - 2018-03-28 17:31:03 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:31:03 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:31:03 --> Utf8 Class Initialized
INFO - 2018-03-28 17:31:03 --> URI Class Initialized
INFO - 2018-03-28 17:31:03 --> Router Class Initialized
INFO - 2018-03-28 17:31:03 --> Output Class Initialized
INFO - 2018-03-28 17:31:03 --> Security Class Initialized
DEBUG - 2018-03-28 17:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:31:03 --> Input Class Initialized
INFO - 2018-03-28 17:31:03 --> Language Class Initialized
INFO - 2018-03-28 17:31:03 --> Loader Class Initialized
INFO - 2018-03-28 17:31:03 --> Helper loaded: url_helper
INFO - 2018-03-28 17:31:03 --> Helper loaded: form_helper
INFO - 2018-03-28 17:31:03 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:31:03 --> Controller Class Initialized
INFO - 2018-03-28 17:31:03 --> Model Class Initialized
INFO - 2018-03-28 17:31:03 --> Model Class Initialized
INFO - 2018-03-28 17:31:03 --> Model Class Initialized
INFO - 2018-03-28 17:31:03 --> Model Class Initialized
INFO - 2018-03-28 17:31:03 --> Model Class Initialized
INFO - 2018-03-28 17:31:03 --> Helper loaded: date_helper
INFO - 2018-03-28 17:31:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:31:03 --> Model Class Initialized
INFO - 2018-03-28 22:31:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:31:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:31:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/create.php
INFO - 2018-03-28 22:31:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:31:04 --> Final output sent to browser
DEBUG - 2018-03-28 22:31:04 --> Total execution time: 0.1312
INFO - 2018-03-28 17:32:12 --> Config Class Initialized
INFO - 2018-03-28 17:32:12 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:32:12 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:32:12 --> Utf8 Class Initialized
INFO - 2018-03-28 17:32:12 --> URI Class Initialized
INFO - 2018-03-28 17:32:12 --> Router Class Initialized
INFO - 2018-03-28 17:32:12 --> Output Class Initialized
INFO - 2018-03-28 17:32:12 --> Security Class Initialized
DEBUG - 2018-03-28 17:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:32:12 --> Input Class Initialized
INFO - 2018-03-28 17:32:12 --> Language Class Initialized
INFO - 2018-03-28 17:32:12 --> Loader Class Initialized
INFO - 2018-03-28 17:32:12 --> Helper loaded: url_helper
INFO - 2018-03-28 17:32:12 --> Helper loaded: form_helper
INFO - 2018-03-28 17:32:12 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:32:12 --> Controller Class Initialized
INFO - 2018-03-28 17:32:12 --> Model Class Initialized
INFO - 2018-03-28 17:32:12 --> Model Class Initialized
INFO - 2018-03-28 17:32:12 --> Helper loaded: date_helper
INFO - 2018-03-28 17:32:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:32:12 --> Final output sent to browser
DEBUG - 2018-03-28 22:32:12 --> Total execution time: 0.1455
INFO - 2018-03-28 17:33:26 --> Config Class Initialized
INFO - 2018-03-28 17:33:26 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:33:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:33:26 --> Utf8 Class Initialized
INFO - 2018-03-28 17:33:26 --> URI Class Initialized
INFO - 2018-03-28 17:33:26 --> Router Class Initialized
INFO - 2018-03-28 17:33:26 --> Output Class Initialized
INFO - 2018-03-28 17:33:26 --> Security Class Initialized
DEBUG - 2018-03-28 17:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:33:26 --> Input Class Initialized
INFO - 2018-03-28 17:33:26 --> Language Class Initialized
INFO - 2018-03-28 17:33:26 --> Loader Class Initialized
INFO - 2018-03-28 17:33:26 --> Helper loaded: url_helper
INFO - 2018-03-28 17:33:26 --> Helper loaded: form_helper
INFO - 2018-03-28 17:33:26 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:33:26 --> Controller Class Initialized
INFO - 2018-03-28 17:33:26 --> Model Class Initialized
INFO - 2018-03-28 17:33:26 --> Model Class Initialized
INFO - 2018-03-28 17:33:26 --> Helper loaded: date_helper
INFO - 2018-03-28 17:33:26 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:33:26 --> Final output sent to browser
DEBUG - 2018-03-28 22:33:26 --> Total execution time: 0.1248
INFO - 2018-03-28 17:33:28 --> Config Class Initialized
INFO - 2018-03-28 17:33:28 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:33:28 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:33:28 --> Utf8 Class Initialized
INFO - 2018-03-28 17:33:28 --> URI Class Initialized
INFO - 2018-03-28 17:33:28 --> Router Class Initialized
INFO - 2018-03-28 17:33:28 --> Output Class Initialized
INFO - 2018-03-28 17:33:28 --> Security Class Initialized
DEBUG - 2018-03-28 17:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:33:28 --> Input Class Initialized
INFO - 2018-03-28 17:33:28 --> Language Class Initialized
INFO - 2018-03-28 17:33:28 --> Loader Class Initialized
INFO - 2018-03-28 17:33:28 --> Helper loaded: url_helper
INFO - 2018-03-28 17:33:28 --> Helper loaded: form_helper
INFO - 2018-03-28 17:33:28 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:33:28 --> Controller Class Initialized
INFO - 2018-03-28 17:33:28 --> Model Class Initialized
INFO - 2018-03-28 17:33:28 --> Model Class Initialized
INFO - 2018-03-28 17:33:28 --> Helper loaded: date_helper
INFO - 2018-03-28 17:33:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:33:28 --> Final output sent to browser
DEBUG - 2018-03-28 22:33:28 --> Total execution time: 0.1185
INFO - 2018-03-28 17:34:14 --> Config Class Initialized
INFO - 2018-03-28 17:34:14 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:34:14 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:34:14 --> Utf8 Class Initialized
INFO - 2018-03-28 17:34:14 --> URI Class Initialized
INFO - 2018-03-28 17:34:14 --> Router Class Initialized
INFO - 2018-03-28 17:34:14 --> Output Class Initialized
INFO - 2018-03-28 17:34:14 --> Security Class Initialized
DEBUG - 2018-03-28 17:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:34:14 --> Input Class Initialized
INFO - 2018-03-28 17:34:14 --> Language Class Initialized
INFO - 2018-03-28 17:34:14 --> Loader Class Initialized
INFO - 2018-03-28 17:34:14 --> Helper loaded: url_helper
INFO - 2018-03-28 17:34:14 --> Helper loaded: form_helper
INFO - 2018-03-28 17:34:14 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:34:14 --> Controller Class Initialized
INFO - 2018-03-28 17:34:14 --> Model Class Initialized
INFO - 2018-03-28 17:34:14 --> Model Class Initialized
INFO - 2018-03-28 17:34:14 --> Model Class Initialized
INFO - 2018-03-28 17:34:14 --> Model Class Initialized
INFO - 2018-03-28 17:34:14 --> Model Class Initialized
INFO - 2018-03-28 17:34:14 --> Helper loaded: date_helper
INFO - 2018-03-28 17:34:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 17:34:14 --> Config Class Initialized
INFO - 2018-03-28 17:34:14 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:34:14 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:34:14 --> Utf8 Class Initialized
INFO - 2018-03-28 17:34:14 --> URI Class Initialized
INFO - 2018-03-28 17:34:14 --> Router Class Initialized
INFO - 2018-03-28 17:34:14 --> Output Class Initialized
INFO - 2018-03-28 17:34:14 --> Security Class Initialized
DEBUG - 2018-03-28 17:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:34:14 --> Input Class Initialized
INFO - 2018-03-28 17:34:14 --> Language Class Initialized
INFO - 2018-03-28 17:34:14 --> Loader Class Initialized
INFO - 2018-03-28 17:34:14 --> Helper loaded: url_helper
INFO - 2018-03-28 17:34:14 --> Helper loaded: form_helper
INFO - 2018-03-28 17:34:14 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:34:14 --> Controller Class Initialized
INFO - 2018-03-28 17:34:14 --> Model Class Initialized
INFO - 2018-03-28 17:34:14 --> Model Class Initialized
INFO - 2018-03-28 17:34:14 --> Model Class Initialized
INFO - 2018-03-28 17:34:14 --> Model Class Initialized
INFO - 2018-03-28 17:34:14 --> Model Class Initialized
INFO - 2018-03-28 17:34:14 --> Helper loaded: date_helper
INFO - 2018-03-28 17:34:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:34:14 --> Model Class Initialized
INFO - 2018-03-28 22:34:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:34:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:34:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/detail.php
INFO - 2018-03-28 22:34:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:34:14 --> Final output sent to browser
DEBUG - 2018-03-28 22:34:14 --> Total execution time: 0.1358
INFO - 2018-03-28 17:34:31 --> Config Class Initialized
INFO - 2018-03-28 17:34:31 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:34:31 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:34:31 --> Utf8 Class Initialized
INFO - 2018-03-28 17:34:31 --> URI Class Initialized
INFO - 2018-03-28 17:34:31 --> Router Class Initialized
INFO - 2018-03-28 17:34:31 --> Output Class Initialized
INFO - 2018-03-28 17:34:31 --> Security Class Initialized
DEBUG - 2018-03-28 17:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:34:31 --> Input Class Initialized
INFO - 2018-03-28 17:34:31 --> Language Class Initialized
INFO - 2018-03-28 17:34:31 --> Loader Class Initialized
INFO - 2018-03-28 17:34:31 --> Helper loaded: url_helper
INFO - 2018-03-28 17:34:31 --> Helper loaded: form_helper
INFO - 2018-03-28 17:34:31 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:34:31 --> Controller Class Initialized
INFO - 2018-03-28 17:34:31 --> Model Class Initialized
INFO - 2018-03-28 17:34:31 --> Model Class Initialized
INFO - 2018-03-28 17:34:31 --> Model Class Initialized
INFO - 2018-03-28 17:34:31 --> Model Class Initialized
INFO - 2018-03-28 17:34:31 --> Model Class Initialized
INFO - 2018-03-28 17:34:31 --> Model Class Initialized
INFO - 2018-03-28 17:34:31 --> Model Class Initialized
INFO - 2018-03-28 17:34:31 --> Helper loaded: date_helper
INFO - 2018-03-28 17:34:31 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:34:31 --> Model Class Initialized
INFO - 2018-03-28 22:34:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:34:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:34:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-28 22:34:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:34:31 --> Final output sent to browser
DEBUG - 2018-03-28 22:34:31 --> Total execution time: 0.1278
INFO - 2018-03-28 17:34:35 --> Config Class Initialized
INFO - 2018-03-28 17:34:35 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:34:35 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:34:35 --> Utf8 Class Initialized
INFO - 2018-03-28 17:34:35 --> URI Class Initialized
INFO - 2018-03-28 17:34:35 --> Router Class Initialized
INFO - 2018-03-28 17:34:35 --> Output Class Initialized
INFO - 2018-03-28 17:34:35 --> Security Class Initialized
DEBUG - 2018-03-28 17:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:34:35 --> Input Class Initialized
INFO - 2018-03-28 17:34:35 --> Language Class Initialized
INFO - 2018-03-28 17:34:35 --> Loader Class Initialized
INFO - 2018-03-28 17:34:35 --> Helper loaded: url_helper
INFO - 2018-03-28 17:34:35 --> Helper loaded: form_helper
INFO - 2018-03-28 17:34:35 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:34:35 --> Controller Class Initialized
INFO - 2018-03-28 17:34:35 --> Model Class Initialized
INFO - 2018-03-28 17:34:35 --> Model Class Initialized
INFO - 2018-03-28 17:34:35 --> Model Class Initialized
INFO - 2018-03-28 17:34:35 --> Model Class Initialized
INFO - 2018-03-28 17:34:35 --> Model Class Initialized
INFO - 2018-03-28 17:34:35 --> Model Class Initialized
INFO - 2018-03-28 17:34:35 --> Model Class Initialized
INFO - 2018-03-28 17:34:35 --> Helper loaded: date_helper
INFO - 2018-03-28 17:34:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:34:35 --> Model Class Initialized
INFO - 2018-03-28 22:34:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:34:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:34:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/create.php
INFO - 2018-03-28 22:34:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:34:35 --> Final output sent to browser
DEBUG - 2018-03-28 22:34:35 --> Total execution time: 0.1811
INFO - 2018-03-28 17:34:48 --> Config Class Initialized
INFO - 2018-03-28 17:34:48 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:34:48 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:34:48 --> Utf8 Class Initialized
INFO - 2018-03-28 17:34:48 --> URI Class Initialized
INFO - 2018-03-28 17:34:48 --> Router Class Initialized
INFO - 2018-03-28 17:34:48 --> Output Class Initialized
INFO - 2018-03-28 17:34:48 --> Security Class Initialized
DEBUG - 2018-03-28 17:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:34:48 --> Input Class Initialized
INFO - 2018-03-28 17:34:48 --> Language Class Initialized
INFO - 2018-03-28 17:34:48 --> Loader Class Initialized
INFO - 2018-03-28 17:34:48 --> Helper loaded: url_helper
INFO - 2018-03-28 17:34:48 --> Helper loaded: form_helper
INFO - 2018-03-28 17:34:48 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:34:48 --> Controller Class Initialized
INFO - 2018-03-28 17:34:48 --> Model Class Initialized
INFO - 2018-03-28 17:34:48 --> Model Class Initialized
INFO - 2018-03-28 17:34:48 --> Helper loaded: date_helper
INFO - 2018-03-28 17:34:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:34:48 --> Final output sent to browser
DEBUG - 2018-03-28 22:34:48 --> Total execution time: 0.1150
INFO - 2018-03-28 17:35:06 --> Config Class Initialized
INFO - 2018-03-28 17:35:06 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:35:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:35:06 --> Utf8 Class Initialized
INFO - 2018-03-28 17:35:06 --> URI Class Initialized
INFO - 2018-03-28 17:35:06 --> Router Class Initialized
INFO - 2018-03-28 17:35:06 --> Output Class Initialized
INFO - 2018-03-28 17:35:06 --> Security Class Initialized
DEBUG - 2018-03-28 17:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:35:06 --> Input Class Initialized
INFO - 2018-03-28 17:35:06 --> Language Class Initialized
INFO - 2018-03-28 17:35:06 --> Loader Class Initialized
INFO - 2018-03-28 17:35:06 --> Helper loaded: url_helper
INFO - 2018-03-28 17:35:06 --> Helper loaded: form_helper
INFO - 2018-03-28 17:35:06 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:35:06 --> Controller Class Initialized
INFO - 2018-03-28 17:35:06 --> Model Class Initialized
INFO - 2018-03-28 17:35:06 --> Model Class Initialized
INFO - 2018-03-28 17:35:06 --> Helper loaded: date_helper
INFO - 2018-03-28 17:35:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:35:06 --> Final output sent to browser
DEBUG - 2018-03-28 22:35:06 --> Total execution time: 0.0862
INFO - 2018-03-28 17:35:17 --> Config Class Initialized
INFO - 2018-03-28 17:35:17 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:35:17 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:35:17 --> Utf8 Class Initialized
INFO - 2018-03-28 17:35:17 --> URI Class Initialized
INFO - 2018-03-28 17:35:17 --> Router Class Initialized
INFO - 2018-03-28 17:35:17 --> Output Class Initialized
INFO - 2018-03-28 17:35:17 --> Security Class Initialized
DEBUG - 2018-03-28 17:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:35:17 --> Input Class Initialized
INFO - 2018-03-28 17:35:17 --> Language Class Initialized
INFO - 2018-03-28 17:35:17 --> Loader Class Initialized
INFO - 2018-03-28 17:35:17 --> Helper loaded: url_helper
INFO - 2018-03-28 17:35:17 --> Helper loaded: form_helper
INFO - 2018-03-28 17:35:17 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:35:17 --> Controller Class Initialized
INFO - 2018-03-28 17:35:17 --> Model Class Initialized
INFO - 2018-03-28 17:35:17 --> Model Class Initialized
INFO - 2018-03-28 17:35:17 --> Helper loaded: date_helper
INFO - 2018-03-28 17:35:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:35:17 --> Model Class Initialized
INFO - 2018-03-28 22:35:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:35:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:35:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\product/master/table.php
INFO - 2018-03-28 22:35:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:35:17 --> Final output sent to browser
DEBUG - 2018-03-28 22:35:17 --> Total execution time: 0.1420
INFO - 2018-03-28 17:35:23 --> Config Class Initialized
INFO - 2018-03-28 17:35:23 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:35:23 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:35:23 --> Utf8 Class Initialized
INFO - 2018-03-28 17:35:23 --> URI Class Initialized
INFO - 2018-03-28 17:35:23 --> Router Class Initialized
INFO - 2018-03-28 17:35:23 --> Output Class Initialized
INFO - 2018-03-28 17:35:23 --> Security Class Initialized
DEBUG - 2018-03-28 17:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:35:23 --> Input Class Initialized
INFO - 2018-03-28 17:35:23 --> Language Class Initialized
INFO - 2018-03-28 17:35:23 --> Loader Class Initialized
INFO - 2018-03-28 17:35:23 --> Helper loaded: url_helper
INFO - 2018-03-28 17:35:23 --> Helper loaded: form_helper
INFO - 2018-03-28 17:35:23 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:35:23 --> Controller Class Initialized
INFO - 2018-03-28 17:35:23 --> Model Class Initialized
INFO - 2018-03-28 17:35:23 --> Model Class Initialized
INFO - 2018-03-28 17:35:23 --> Model Class Initialized
INFO - 2018-03-28 17:35:23 --> Model Class Initialized
INFO - 2018-03-28 17:35:23 --> Model Class Initialized
INFO - 2018-03-28 17:35:23 --> Helper loaded: date_helper
INFO - 2018-03-28 17:35:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:35:23 --> Model Class Initialized
INFO - 2018-03-28 22:35:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:35:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:35:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-28 22:35:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:35:24 --> Final output sent to browser
DEBUG - 2018-03-28 22:35:24 --> Total execution time: 0.1480
INFO - 2018-03-28 17:35:40 --> Config Class Initialized
INFO - 2018-03-28 17:35:40 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:35:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:35:40 --> Utf8 Class Initialized
INFO - 2018-03-28 17:35:40 --> URI Class Initialized
INFO - 2018-03-28 17:35:40 --> Router Class Initialized
INFO - 2018-03-28 17:35:40 --> Output Class Initialized
INFO - 2018-03-28 17:35:40 --> Security Class Initialized
DEBUG - 2018-03-28 17:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:35:40 --> Input Class Initialized
INFO - 2018-03-28 17:35:40 --> Language Class Initialized
INFO - 2018-03-28 17:35:40 --> Loader Class Initialized
INFO - 2018-03-28 17:35:40 --> Helper loaded: url_helper
INFO - 2018-03-28 17:35:40 --> Helper loaded: form_helper
INFO - 2018-03-28 17:35:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:35:40 --> Controller Class Initialized
INFO - 2018-03-28 17:35:40 --> Model Class Initialized
INFO - 2018-03-28 17:35:40 --> Model Class Initialized
INFO - 2018-03-28 17:35:40 --> Model Class Initialized
INFO - 2018-03-28 17:35:40 --> Model Class Initialized
INFO - 2018-03-28 17:35:40 --> Model Class Initialized
INFO - 2018-03-28 17:35:40 --> Helper loaded: date_helper
INFO - 2018-03-28 17:35:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 17:35:40 --> Config Class Initialized
INFO - 2018-03-28 17:35:40 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:35:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:35:40 --> Utf8 Class Initialized
INFO - 2018-03-28 17:35:40 --> URI Class Initialized
INFO - 2018-03-28 17:35:40 --> Router Class Initialized
INFO - 2018-03-28 17:35:40 --> Output Class Initialized
INFO - 2018-03-28 17:35:40 --> Security Class Initialized
DEBUG - 2018-03-28 17:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:35:40 --> Input Class Initialized
INFO - 2018-03-28 17:35:40 --> Language Class Initialized
INFO - 2018-03-28 17:35:40 --> Loader Class Initialized
INFO - 2018-03-28 17:35:40 --> Helper loaded: url_helper
INFO - 2018-03-28 17:35:40 --> Helper loaded: form_helper
INFO - 2018-03-28 17:35:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:35:40 --> Controller Class Initialized
INFO - 2018-03-28 17:35:40 --> Model Class Initialized
INFO - 2018-03-28 17:35:40 --> Model Class Initialized
INFO - 2018-03-28 17:35:40 --> Model Class Initialized
INFO - 2018-03-28 17:35:40 --> Model Class Initialized
INFO - 2018-03-28 17:35:40 --> Model Class Initialized
INFO - 2018-03-28 17:35:40 --> Helper loaded: date_helper
INFO - 2018-03-28 17:35:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:35:40 --> Model Class Initialized
INFO - 2018-03-28 22:35:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:35:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:35:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-28 22:35:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:35:40 --> Final output sent to browser
DEBUG - 2018-03-28 22:35:40 --> Total execution time: 0.1343
INFO - 2018-03-28 17:36:15 --> Config Class Initialized
INFO - 2018-03-28 17:36:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:36:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:36:15 --> Utf8 Class Initialized
INFO - 2018-03-28 17:36:15 --> URI Class Initialized
INFO - 2018-03-28 17:36:15 --> Router Class Initialized
INFO - 2018-03-28 17:36:15 --> Output Class Initialized
INFO - 2018-03-28 17:36:15 --> Security Class Initialized
DEBUG - 2018-03-28 17:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:36:15 --> Input Class Initialized
INFO - 2018-03-28 17:36:15 --> Language Class Initialized
INFO - 2018-03-28 17:36:15 --> Loader Class Initialized
INFO - 2018-03-28 17:36:15 --> Helper loaded: url_helper
INFO - 2018-03-28 17:36:15 --> Helper loaded: form_helper
INFO - 2018-03-28 17:36:15 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:36:15 --> Controller Class Initialized
INFO - 2018-03-28 17:36:15 --> Model Class Initialized
INFO - 2018-03-28 17:36:15 --> Model Class Initialized
INFO - 2018-03-28 17:36:15 --> Model Class Initialized
INFO - 2018-03-28 17:36:15 --> Model Class Initialized
INFO - 2018-03-28 17:36:15 --> Model Class Initialized
INFO - 2018-03-28 17:36:15 --> Model Class Initialized
INFO - 2018-03-28 17:36:15 --> Model Class Initialized
INFO - 2018-03-28 17:36:15 --> Helper loaded: date_helper
INFO - 2018-03-28 17:36:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:36:15 --> Model Class Initialized
INFO - 2018-03-28 22:36:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:36:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:36:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-28 22:36:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:36:15 --> Final output sent to browser
DEBUG - 2018-03-28 22:36:15 --> Total execution time: 0.1541
INFO - 2018-03-28 17:36:20 --> Config Class Initialized
INFO - 2018-03-28 17:36:20 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:36:20 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:36:20 --> Utf8 Class Initialized
INFO - 2018-03-28 17:36:20 --> URI Class Initialized
INFO - 2018-03-28 17:36:20 --> Router Class Initialized
INFO - 2018-03-28 17:36:20 --> Output Class Initialized
INFO - 2018-03-28 17:36:20 --> Security Class Initialized
DEBUG - 2018-03-28 17:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:36:20 --> Input Class Initialized
INFO - 2018-03-28 17:36:20 --> Language Class Initialized
INFO - 2018-03-28 17:36:20 --> Loader Class Initialized
INFO - 2018-03-28 17:36:20 --> Helper loaded: url_helper
INFO - 2018-03-28 17:36:20 --> Helper loaded: form_helper
INFO - 2018-03-28 17:36:20 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:36:20 --> Controller Class Initialized
INFO - 2018-03-28 17:36:20 --> Model Class Initialized
INFO - 2018-03-28 17:36:20 --> Model Class Initialized
INFO - 2018-03-28 17:36:20 --> Model Class Initialized
INFO - 2018-03-28 17:36:20 --> Model Class Initialized
INFO - 2018-03-28 17:36:20 --> Model Class Initialized
INFO - 2018-03-28 17:36:20 --> Model Class Initialized
INFO - 2018-03-28 17:36:20 --> Model Class Initialized
INFO - 2018-03-28 17:36:20 --> Helper loaded: date_helper
INFO - 2018-03-28 17:36:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:36:20 --> Model Class Initialized
INFO - 2018-03-28 22:36:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:36:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:36:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/create.php
INFO - 2018-03-28 22:36:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:36:20 --> Final output sent to browser
DEBUG - 2018-03-28 22:36:20 --> Total execution time: 0.1373
INFO - 2018-03-28 17:36:37 --> Config Class Initialized
INFO - 2018-03-28 17:36:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:36:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:36:37 --> Utf8 Class Initialized
INFO - 2018-03-28 17:36:37 --> URI Class Initialized
INFO - 2018-03-28 17:36:37 --> Router Class Initialized
INFO - 2018-03-28 17:36:37 --> Output Class Initialized
INFO - 2018-03-28 17:36:37 --> Security Class Initialized
DEBUG - 2018-03-28 17:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:36:37 --> Input Class Initialized
INFO - 2018-03-28 17:36:37 --> Language Class Initialized
INFO - 2018-03-28 17:36:38 --> Loader Class Initialized
INFO - 2018-03-28 17:36:38 --> Helper loaded: url_helper
INFO - 2018-03-28 17:36:38 --> Helper loaded: form_helper
INFO - 2018-03-28 17:36:38 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:36:38 --> Controller Class Initialized
INFO - 2018-03-28 17:36:38 --> Model Class Initialized
INFO - 2018-03-28 17:36:38 --> Model Class Initialized
INFO - 2018-03-28 17:36:38 --> Helper loaded: date_helper
INFO - 2018-03-28 17:36:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:36:38 --> Final output sent to browser
DEBUG - 2018-03-28 22:36:38 --> Total execution time: 0.1184
INFO - 2018-03-28 17:36:38 --> Config Class Initialized
INFO - 2018-03-28 17:36:38 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:36:38 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:36:38 --> Utf8 Class Initialized
INFO - 2018-03-28 17:36:38 --> URI Class Initialized
INFO - 2018-03-28 17:36:38 --> Router Class Initialized
INFO - 2018-03-28 17:36:38 --> Output Class Initialized
INFO - 2018-03-28 17:36:38 --> Security Class Initialized
DEBUG - 2018-03-28 17:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:36:38 --> Input Class Initialized
INFO - 2018-03-28 17:36:38 --> Language Class Initialized
INFO - 2018-03-28 17:36:38 --> Loader Class Initialized
INFO - 2018-03-28 17:36:38 --> Helper loaded: url_helper
INFO - 2018-03-28 17:36:38 --> Helper loaded: form_helper
INFO - 2018-03-28 17:36:38 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:36:38 --> Controller Class Initialized
INFO - 2018-03-28 17:36:38 --> Model Class Initialized
INFO - 2018-03-28 17:36:38 --> Model Class Initialized
INFO - 2018-03-28 17:36:38 --> Helper loaded: date_helper
INFO - 2018-03-28 17:36:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:36:38 --> Final output sent to browser
DEBUG - 2018-03-28 22:36:38 --> Total execution time: 0.1011
INFO - 2018-03-28 17:37:00 --> Config Class Initialized
INFO - 2018-03-28 17:37:00 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:37:00 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:37:00 --> Utf8 Class Initialized
INFO - 2018-03-28 17:37:00 --> URI Class Initialized
INFO - 2018-03-28 17:37:00 --> Router Class Initialized
INFO - 2018-03-28 17:37:00 --> Output Class Initialized
INFO - 2018-03-28 17:37:00 --> Security Class Initialized
DEBUG - 2018-03-28 17:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:37:00 --> Input Class Initialized
INFO - 2018-03-28 17:37:00 --> Language Class Initialized
INFO - 2018-03-28 17:37:00 --> Loader Class Initialized
INFO - 2018-03-28 17:37:00 --> Helper loaded: url_helper
INFO - 2018-03-28 17:37:00 --> Helper loaded: form_helper
INFO - 2018-03-28 17:37:00 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:37:00 --> Controller Class Initialized
INFO - 2018-03-28 17:37:00 --> Model Class Initialized
INFO - 2018-03-28 17:37:00 --> Model Class Initialized
INFO - 2018-03-28 17:37:00 --> Model Class Initialized
INFO - 2018-03-28 17:37:00 --> Model Class Initialized
INFO - 2018-03-28 17:37:00 --> Model Class Initialized
INFO - 2018-03-28 17:37:00 --> Model Class Initialized
INFO - 2018-03-28 17:37:00 --> Model Class Initialized
INFO - 2018-03-28 17:37:00 --> Helper loaded: date_helper
INFO - 2018-03-28 17:37:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 17:37:01 --> Config Class Initialized
INFO - 2018-03-28 17:37:01 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:37:01 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:37:01 --> Utf8 Class Initialized
INFO - 2018-03-28 17:37:01 --> URI Class Initialized
INFO - 2018-03-28 17:37:01 --> Router Class Initialized
INFO - 2018-03-28 17:37:01 --> Output Class Initialized
INFO - 2018-03-28 17:37:01 --> Security Class Initialized
DEBUG - 2018-03-28 17:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:37:01 --> Input Class Initialized
INFO - 2018-03-28 17:37:01 --> Language Class Initialized
INFO - 2018-03-28 17:37:01 --> Loader Class Initialized
INFO - 2018-03-28 17:37:01 --> Helper loaded: url_helper
INFO - 2018-03-28 17:37:01 --> Helper loaded: form_helper
INFO - 2018-03-28 17:37:01 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:37:01 --> Controller Class Initialized
INFO - 2018-03-28 17:37:01 --> Model Class Initialized
INFO - 2018-03-28 17:37:01 --> Model Class Initialized
INFO - 2018-03-28 17:37:01 --> Model Class Initialized
INFO - 2018-03-28 17:37:01 --> Model Class Initialized
INFO - 2018-03-28 17:37:01 --> Model Class Initialized
INFO - 2018-03-28 17:37:01 --> Model Class Initialized
INFO - 2018-03-28 17:37:01 --> Model Class Initialized
INFO - 2018-03-28 17:37:01 --> Helper loaded: date_helper
INFO - 2018-03-28 17:37:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:37:01 --> Model Class Initialized
INFO - 2018-03-28 22:37:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:37:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:37:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-28 22:37:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:37:01 --> Final output sent to browser
DEBUG - 2018-03-28 22:37:01 --> Total execution time: 0.3183
INFO - 2018-03-28 17:37:52 --> Config Class Initialized
INFO - 2018-03-28 17:37:52 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:37:52 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:37:52 --> Utf8 Class Initialized
INFO - 2018-03-28 17:37:52 --> URI Class Initialized
INFO - 2018-03-28 17:37:52 --> Router Class Initialized
INFO - 2018-03-28 17:37:52 --> Output Class Initialized
INFO - 2018-03-28 17:37:52 --> Security Class Initialized
DEBUG - 2018-03-28 17:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:37:52 --> Input Class Initialized
INFO - 2018-03-28 17:37:52 --> Language Class Initialized
INFO - 2018-03-28 17:37:52 --> Loader Class Initialized
INFO - 2018-03-28 17:37:52 --> Helper loaded: url_helper
INFO - 2018-03-28 17:37:52 --> Helper loaded: form_helper
INFO - 2018-03-28 17:37:52 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:37:52 --> Controller Class Initialized
INFO - 2018-03-28 17:37:52 --> Model Class Initialized
INFO - 2018-03-28 17:37:52 --> Model Class Initialized
INFO - 2018-03-28 17:37:52 --> Model Class Initialized
INFO - 2018-03-28 17:37:52 --> Model Class Initialized
INFO - 2018-03-28 17:37:52 --> Model Class Initialized
INFO - 2018-03-28 17:37:52 --> Model Class Initialized
INFO - 2018-03-28 17:37:52 --> Model Class Initialized
INFO - 2018-03-28 17:37:52 --> Model Class Initialized
INFO - 2018-03-28 17:37:52 --> Model Class Initialized
INFO - 2018-03-28 17:37:52 --> Model Class Initialized
INFO - 2018-03-28 17:37:52 --> Model Class Initialized
INFO - 2018-03-28 17:37:52 --> Model Class Initialized
INFO - 2018-03-28 17:37:52 --> Model Class Initialized
INFO - 2018-03-28 17:37:52 --> Model Class Initialized
INFO - 2018-03-28 17:37:52 --> Model Class Initialized
INFO - 2018-03-28 17:37:52 --> Helper loaded: date_helper
INFO - 2018-03-28 17:37:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:37:52 --> Model Class Initialized
INFO - 2018-03-28 22:37:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:37:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:37:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-28 22:37:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:37:52 --> Final output sent to browser
DEBUG - 2018-03-28 22:37:52 --> Total execution time: 0.1784
INFO - 2018-03-28 17:38:21 --> Config Class Initialized
INFO - 2018-03-28 17:38:21 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:38:21 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:38:21 --> Utf8 Class Initialized
INFO - 2018-03-28 17:38:21 --> URI Class Initialized
INFO - 2018-03-28 17:38:21 --> Router Class Initialized
INFO - 2018-03-28 17:38:21 --> Output Class Initialized
INFO - 2018-03-28 17:38:21 --> Security Class Initialized
DEBUG - 2018-03-28 17:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:38:21 --> Input Class Initialized
INFO - 2018-03-28 17:38:21 --> Language Class Initialized
INFO - 2018-03-28 17:38:21 --> Loader Class Initialized
INFO - 2018-03-28 17:38:21 --> Helper loaded: url_helper
INFO - 2018-03-28 17:38:21 --> Helper loaded: form_helper
INFO - 2018-03-28 17:38:21 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:38:21 --> Controller Class Initialized
INFO - 2018-03-28 17:38:21 --> Model Class Initialized
INFO - 2018-03-28 17:38:21 --> Model Class Initialized
INFO - 2018-03-28 17:38:21 --> Model Class Initialized
INFO - 2018-03-28 17:38:21 --> Model Class Initialized
INFO - 2018-03-28 17:38:21 --> Model Class Initialized
INFO - 2018-03-28 17:38:21 --> Model Class Initialized
INFO - 2018-03-28 17:38:21 --> Model Class Initialized
INFO - 2018-03-28 17:38:21 --> Model Class Initialized
INFO - 2018-03-28 17:38:21 --> Model Class Initialized
INFO - 2018-03-28 17:38:21 --> Model Class Initialized
INFO - 2018-03-28 17:38:21 --> Model Class Initialized
INFO - 2018-03-28 17:38:21 --> Model Class Initialized
INFO - 2018-03-28 17:38:21 --> Model Class Initialized
INFO - 2018-03-28 17:38:21 --> Model Class Initialized
INFO - 2018-03-28 17:38:21 --> Model Class Initialized
INFO - 2018-03-28 17:38:21 --> Helper loaded: date_helper
INFO - 2018-03-28 17:38:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:38:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-28 22:38:21 --> Final output sent to browser
DEBUG - 2018-03-28 22:38:21 --> Total execution time: 0.1655
INFO - 2018-03-28 17:38:34 --> Config Class Initialized
INFO - 2018-03-28 17:38:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:38:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:38:34 --> Utf8 Class Initialized
INFO - 2018-03-28 17:38:34 --> URI Class Initialized
INFO - 2018-03-28 17:38:34 --> Router Class Initialized
INFO - 2018-03-28 17:38:34 --> Output Class Initialized
INFO - 2018-03-28 17:38:34 --> Security Class Initialized
DEBUG - 2018-03-28 17:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:38:34 --> Input Class Initialized
INFO - 2018-03-28 17:38:34 --> Language Class Initialized
INFO - 2018-03-28 17:38:34 --> Loader Class Initialized
INFO - 2018-03-28 17:38:34 --> Helper loaded: url_helper
INFO - 2018-03-28 17:38:34 --> Helper loaded: form_helper
INFO - 2018-03-28 17:38:35 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:38:35 --> Controller Class Initialized
INFO - 2018-03-28 17:38:35 --> Model Class Initialized
INFO - 2018-03-28 17:38:35 --> Model Class Initialized
INFO - 2018-03-28 17:38:35 --> Model Class Initialized
INFO - 2018-03-28 17:38:35 --> Model Class Initialized
INFO - 2018-03-28 17:38:35 --> Model Class Initialized
INFO - 2018-03-28 17:38:35 --> Model Class Initialized
INFO - 2018-03-28 17:38:35 --> Model Class Initialized
INFO - 2018-03-28 17:38:35 --> Model Class Initialized
INFO - 2018-03-28 17:38:35 --> Model Class Initialized
INFO - 2018-03-28 17:38:35 --> Model Class Initialized
INFO - 2018-03-28 17:38:35 --> Model Class Initialized
INFO - 2018-03-28 17:38:35 --> Model Class Initialized
INFO - 2018-03-28 17:38:35 --> Model Class Initialized
INFO - 2018-03-28 17:38:35 --> Model Class Initialized
INFO - 2018-03-28 17:38:35 --> Model Class Initialized
INFO - 2018-03-28 17:38:35 --> Helper loaded: date_helper
INFO - 2018-03-28 17:38:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:38:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/list.php
INFO - 2018-03-28 22:38:35 --> Final output sent to browser
DEBUG - 2018-03-28 22:38:35 --> Total execution time: 0.1155
INFO - 2018-03-28 17:38:39 --> Config Class Initialized
INFO - 2018-03-28 17:38:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:38:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:38:39 --> Utf8 Class Initialized
INFO - 2018-03-28 17:38:39 --> URI Class Initialized
INFO - 2018-03-28 17:38:39 --> Router Class Initialized
INFO - 2018-03-28 17:38:39 --> Output Class Initialized
INFO - 2018-03-28 17:38:39 --> Security Class Initialized
DEBUG - 2018-03-28 17:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:38:39 --> Input Class Initialized
INFO - 2018-03-28 17:38:39 --> Language Class Initialized
INFO - 2018-03-28 17:38:39 --> Loader Class Initialized
INFO - 2018-03-28 17:38:39 --> Helper loaded: url_helper
INFO - 2018-03-28 17:38:39 --> Helper loaded: form_helper
INFO - 2018-03-28 17:38:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:38:39 --> Controller Class Initialized
INFO - 2018-03-28 17:38:39 --> Model Class Initialized
INFO - 2018-03-28 17:38:39 --> Model Class Initialized
INFO - 2018-03-28 17:38:39 --> Model Class Initialized
INFO - 2018-03-28 17:38:39 --> Model Class Initialized
INFO - 2018-03-28 17:38:39 --> Model Class Initialized
INFO - 2018-03-28 17:38:39 --> Model Class Initialized
INFO - 2018-03-28 17:38:39 --> Model Class Initialized
INFO - 2018-03-28 17:38:39 --> Model Class Initialized
INFO - 2018-03-28 17:38:39 --> Model Class Initialized
INFO - 2018-03-28 17:38:39 --> Model Class Initialized
INFO - 2018-03-28 17:38:39 --> Model Class Initialized
INFO - 2018-03-28 17:38:39 --> Model Class Initialized
INFO - 2018-03-28 17:38:39 --> Model Class Initialized
INFO - 2018-03-28 17:38:39 --> Model Class Initialized
INFO - 2018-03-28 17:38:39 --> Model Class Initialized
INFO - 2018-03-28 17:38:39 --> Helper loaded: date_helper
INFO - 2018-03-28 17:38:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:38:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/print.php
INFO - 2018-03-28 22:38:39 --> Final output sent to browser
DEBUG - 2018-03-28 22:38:39 --> Total execution time: 0.1634
INFO - 2018-03-28 17:39:13 --> Config Class Initialized
INFO - 2018-03-28 17:39:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:39:13 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:39:13 --> Utf8 Class Initialized
INFO - 2018-03-28 17:39:13 --> URI Class Initialized
INFO - 2018-03-28 17:39:13 --> Router Class Initialized
INFO - 2018-03-28 17:39:13 --> Output Class Initialized
INFO - 2018-03-28 17:39:13 --> Security Class Initialized
DEBUG - 2018-03-28 17:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:39:13 --> Input Class Initialized
INFO - 2018-03-28 17:39:13 --> Language Class Initialized
INFO - 2018-03-28 17:39:13 --> Loader Class Initialized
INFO - 2018-03-28 17:39:13 --> Helper loaded: url_helper
INFO - 2018-03-28 17:39:13 --> Helper loaded: form_helper
INFO - 2018-03-28 17:39:13 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:39:13 --> Controller Class Initialized
INFO - 2018-03-28 17:39:13 --> Model Class Initialized
INFO - 2018-03-28 17:39:13 --> Model Class Initialized
INFO - 2018-03-28 17:39:13 --> Model Class Initialized
INFO - 2018-03-28 17:39:13 --> Model Class Initialized
INFO - 2018-03-28 17:39:13 --> Model Class Initialized
INFO - 2018-03-28 17:39:13 --> Helper loaded: date_helper
INFO - 2018-03-28 17:39:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:39:13 --> Model Class Initialized
INFO - 2018-03-28 22:39:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:39:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:39:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-28 22:39:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:39:13 --> Final output sent to browser
DEBUG - 2018-03-28 22:39:13 --> Total execution time: 0.1251
INFO - 2018-03-28 17:39:17 --> Config Class Initialized
INFO - 2018-03-28 17:39:17 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:39:17 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:39:17 --> Utf8 Class Initialized
INFO - 2018-03-28 17:39:17 --> URI Class Initialized
INFO - 2018-03-28 17:39:17 --> Router Class Initialized
INFO - 2018-03-28 17:39:17 --> Output Class Initialized
INFO - 2018-03-28 17:39:17 --> Security Class Initialized
DEBUG - 2018-03-28 17:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:39:17 --> Input Class Initialized
INFO - 2018-03-28 17:39:17 --> Language Class Initialized
INFO - 2018-03-28 17:39:17 --> Loader Class Initialized
INFO - 2018-03-28 17:39:17 --> Helper loaded: url_helper
INFO - 2018-03-28 17:39:17 --> Helper loaded: form_helper
INFO - 2018-03-28 17:39:17 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:39:17 --> Controller Class Initialized
INFO - 2018-03-28 17:39:17 --> Model Class Initialized
INFO - 2018-03-28 17:39:17 --> Model Class Initialized
INFO - 2018-03-28 17:39:17 --> Model Class Initialized
INFO - 2018-03-28 17:39:17 --> Model Class Initialized
INFO - 2018-03-28 17:39:17 --> Model Class Initialized
INFO - 2018-03-28 17:39:17 --> Helper loaded: date_helper
INFO - 2018-03-28 17:39:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:39:17 --> Model Class Initialized
INFO - 2018-03-28 22:39:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:39:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:39:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/create.php
INFO - 2018-03-28 22:39:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:39:17 --> Final output sent to browser
DEBUG - 2018-03-28 22:39:17 --> Total execution time: 0.1292
INFO - 2018-03-28 17:39:56 --> Config Class Initialized
INFO - 2018-03-28 17:39:56 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:39:56 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:39:56 --> Utf8 Class Initialized
INFO - 2018-03-28 17:39:56 --> URI Class Initialized
INFO - 2018-03-28 17:39:56 --> Router Class Initialized
INFO - 2018-03-28 17:39:56 --> Output Class Initialized
INFO - 2018-03-28 17:39:56 --> Security Class Initialized
DEBUG - 2018-03-28 17:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:39:56 --> Input Class Initialized
INFO - 2018-03-28 17:39:56 --> Language Class Initialized
INFO - 2018-03-28 17:39:56 --> Loader Class Initialized
INFO - 2018-03-28 17:39:56 --> Helper loaded: url_helper
INFO - 2018-03-28 17:39:56 --> Helper loaded: form_helper
INFO - 2018-03-28 17:39:56 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:39:56 --> Controller Class Initialized
INFO - 2018-03-28 17:39:56 --> Model Class Initialized
INFO - 2018-03-28 17:39:56 --> Model Class Initialized
INFO - 2018-03-28 17:39:56 --> Helper loaded: date_helper
INFO - 2018-03-28 17:39:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:39:56 --> Final output sent to browser
DEBUG - 2018-03-28 22:39:56 --> Total execution time: 0.1286
INFO - 2018-03-28 17:40:17 --> Config Class Initialized
INFO - 2018-03-28 17:40:17 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:40:17 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:40:17 --> Utf8 Class Initialized
INFO - 2018-03-28 17:40:17 --> URI Class Initialized
INFO - 2018-03-28 17:40:17 --> Router Class Initialized
INFO - 2018-03-28 17:40:17 --> Output Class Initialized
INFO - 2018-03-28 17:40:17 --> Security Class Initialized
DEBUG - 2018-03-28 17:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:40:17 --> Input Class Initialized
INFO - 2018-03-28 17:40:17 --> Language Class Initialized
INFO - 2018-03-28 17:40:17 --> Loader Class Initialized
INFO - 2018-03-28 17:40:17 --> Helper loaded: url_helper
INFO - 2018-03-28 17:40:17 --> Helper loaded: form_helper
INFO - 2018-03-28 17:40:17 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:40:17 --> Controller Class Initialized
INFO - 2018-03-28 17:40:17 --> Model Class Initialized
INFO - 2018-03-28 17:40:17 --> Model Class Initialized
INFO - 2018-03-28 17:40:17 --> Helper loaded: date_helper
INFO - 2018-03-28 17:40:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:40:17 --> Final output sent to browser
DEBUG - 2018-03-28 22:40:17 --> Total execution time: 0.0761
INFO - 2018-03-28 17:40:18 --> Config Class Initialized
INFO - 2018-03-28 17:40:18 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:40:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:40:18 --> Utf8 Class Initialized
INFO - 2018-03-28 17:40:18 --> URI Class Initialized
INFO - 2018-03-28 17:40:18 --> Router Class Initialized
INFO - 2018-03-28 17:40:18 --> Output Class Initialized
INFO - 2018-03-28 17:40:18 --> Security Class Initialized
DEBUG - 2018-03-28 17:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:40:18 --> Input Class Initialized
INFO - 2018-03-28 17:40:18 --> Language Class Initialized
INFO - 2018-03-28 17:40:18 --> Loader Class Initialized
INFO - 2018-03-28 17:40:18 --> Helper loaded: url_helper
INFO - 2018-03-28 17:40:18 --> Helper loaded: form_helper
INFO - 2018-03-28 17:40:18 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:40:18 --> Controller Class Initialized
INFO - 2018-03-28 17:40:18 --> Model Class Initialized
INFO - 2018-03-28 17:40:18 --> Model Class Initialized
INFO - 2018-03-28 17:40:18 --> Helper loaded: date_helper
INFO - 2018-03-28 17:40:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:40:18 --> Final output sent to browser
DEBUG - 2018-03-28 22:40:18 --> Total execution time: 0.1002
INFO - 2018-03-28 17:40:18 --> Config Class Initialized
INFO - 2018-03-28 17:40:18 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:40:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:40:18 --> Utf8 Class Initialized
INFO - 2018-03-28 17:40:18 --> URI Class Initialized
INFO - 2018-03-28 17:40:18 --> Router Class Initialized
INFO - 2018-03-28 17:40:18 --> Output Class Initialized
INFO - 2018-03-28 17:40:18 --> Security Class Initialized
DEBUG - 2018-03-28 17:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:40:18 --> Input Class Initialized
INFO - 2018-03-28 17:40:18 --> Language Class Initialized
INFO - 2018-03-28 17:40:18 --> Loader Class Initialized
INFO - 2018-03-28 17:40:18 --> Helper loaded: url_helper
INFO - 2018-03-28 17:40:18 --> Helper loaded: form_helper
INFO - 2018-03-28 17:40:18 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:40:18 --> Controller Class Initialized
INFO - 2018-03-28 17:40:18 --> Model Class Initialized
INFO - 2018-03-28 17:40:18 --> Model Class Initialized
INFO - 2018-03-28 17:40:18 --> Helper loaded: date_helper
INFO - 2018-03-28 17:40:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:40:18 --> Final output sent to browser
DEBUG - 2018-03-28 22:40:18 --> Total execution time: 0.1109
INFO - 2018-03-28 17:41:06 --> Config Class Initialized
INFO - 2018-03-28 17:41:06 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:41:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:41:06 --> Utf8 Class Initialized
INFO - 2018-03-28 17:41:06 --> URI Class Initialized
INFO - 2018-03-28 17:41:06 --> Router Class Initialized
INFO - 2018-03-28 17:41:06 --> Output Class Initialized
INFO - 2018-03-28 17:41:06 --> Security Class Initialized
DEBUG - 2018-03-28 17:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:41:06 --> Input Class Initialized
INFO - 2018-03-28 17:41:06 --> Language Class Initialized
INFO - 2018-03-28 17:41:06 --> Loader Class Initialized
INFO - 2018-03-28 17:41:06 --> Helper loaded: url_helper
INFO - 2018-03-28 17:41:06 --> Helper loaded: form_helper
INFO - 2018-03-28 17:41:06 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:41:06 --> Controller Class Initialized
INFO - 2018-03-28 17:41:06 --> Model Class Initialized
INFO - 2018-03-28 17:41:06 --> Model Class Initialized
INFO - 2018-03-28 17:41:06 --> Helper loaded: date_helper
INFO - 2018-03-28 17:41:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:41:06 --> Final output sent to browser
DEBUG - 2018-03-28 22:41:06 --> Total execution time: 0.1188
INFO - 2018-03-28 17:41:51 --> Config Class Initialized
INFO - 2018-03-28 17:41:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:41:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:41:51 --> Utf8 Class Initialized
INFO - 2018-03-28 17:41:51 --> URI Class Initialized
INFO - 2018-03-28 17:41:51 --> Router Class Initialized
INFO - 2018-03-28 17:41:51 --> Output Class Initialized
INFO - 2018-03-28 17:41:51 --> Security Class Initialized
DEBUG - 2018-03-28 17:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:41:51 --> Input Class Initialized
INFO - 2018-03-28 17:41:51 --> Language Class Initialized
INFO - 2018-03-28 17:41:51 --> Loader Class Initialized
INFO - 2018-03-28 17:41:51 --> Helper loaded: url_helper
INFO - 2018-03-28 17:41:51 --> Helper loaded: form_helper
INFO - 2018-03-28 17:41:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:41:51 --> Controller Class Initialized
INFO - 2018-03-28 17:41:51 --> Model Class Initialized
INFO - 2018-03-28 17:41:51 --> Model Class Initialized
INFO - 2018-03-28 17:41:51 --> Model Class Initialized
INFO - 2018-03-28 17:41:51 --> Model Class Initialized
INFO - 2018-03-28 17:41:51 --> Model Class Initialized
INFO - 2018-03-28 17:41:51 --> Helper loaded: date_helper
INFO - 2018-03-28 17:41:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 17:41:51 --> Config Class Initialized
INFO - 2018-03-28 17:41:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:41:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:41:51 --> Utf8 Class Initialized
INFO - 2018-03-28 17:41:51 --> URI Class Initialized
INFO - 2018-03-28 17:41:51 --> Router Class Initialized
INFO - 2018-03-28 17:41:51 --> Output Class Initialized
INFO - 2018-03-28 17:41:51 --> Security Class Initialized
DEBUG - 2018-03-28 17:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:41:51 --> Input Class Initialized
INFO - 2018-03-28 17:41:51 --> Language Class Initialized
INFO - 2018-03-28 17:41:51 --> Loader Class Initialized
INFO - 2018-03-28 17:41:51 --> Helper loaded: url_helper
INFO - 2018-03-28 17:41:51 --> Helper loaded: form_helper
INFO - 2018-03-28 17:41:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:41:51 --> Controller Class Initialized
INFO - 2018-03-28 17:41:51 --> Model Class Initialized
INFO - 2018-03-28 17:41:51 --> Model Class Initialized
INFO - 2018-03-28 17:41:51 --> Model Class Initialized
INFO - 2018-03-28 17:41:51 --> Model Class Initialized
INFO - 2018-03-28 17:41:51 --> Model Class Initialized
INFO - 2018-03-28 17:41:51 --> Helper loaded: date_helper
INFO - 2018-03-28 17:41:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:41:51 --> Model Class Initialized
INFO - 2018-03-28 22:41:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:41:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:41:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/detail.php
INFO - 2018-03-28 22:41:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:41:51 --> Final output sent to browser
DEBUG - 2018-03-28 22:41:51 --> Total execution time: 0.1372
INFO - 2018-03-28 17:42:01 --> Config Class Initialized
INFO - 2018-03-28 17:42:01 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:42:01 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:42:01 --> Utf8 Class Initialized
INFO - 2018-03-28 17:42:01 --> URI Class Initialized
INFO - 2018-03-28 17:42:01 --> Router Class Initialized
INFO - 2018-03-28 17:42:01 --> Output Class Initialized
INFO - 2018-03-28 17:42:01 --> Security Class Initialized
DEBUG - 2018-03-28 17:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:42:01 --> Input Class Initialized
INFO - 2018-03-28 17:42:01 --> Language Class Initialized
INFO - 2018-03-28 17:42:01 --> Loader Class Initialized
INFO - 2018-03-28 17:42:01 --> Helper loaded: url_helper
INFO - 2018-03-28 17:42:01 --> Helper loaded: form_helper
INFO - 2018-03-28 17:42:01 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:42:01 --> Controller Class Initialized
INFO - 2018-03-28 17:42:01 --> Model Class Initialized
INFO - 2018-03-28 17:42:01 --> Model Class Initialized
INFO - 2018-03-28 17:42:01 --> Model Class Initialized
INFO - 2018-03-28 17:42:01 --> Model Class Initialized
INFO - 2018-03-28 17:42:01 --> Model Class Initialized
INFO - 2018-03-28 17:42:01 --> Helper loaded: date_helper
INFO - 2018-03-28 17:42:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:42:01 --> Model Class Initialized
INFO - 2018-03-28 22:42:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:42:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:42:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-28 22:42:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:42:01 --> Final output sent to browser
DEBUG - 2018-03-28 22:42:01 --> Total execution time: 0.1373
INFO - 2018-03-28 17:42:06 --> Config Class Initialized
INFO - 2018-03-28 17:42:06 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:42:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:42:06 --> Utf8 Class Initialized
INFO - 2018-03-28 17:42:06 --> URI Class Initialized
INFO - 2018-03-28 17:42:06 --> Router Class Initialized
INFO - 2018-03-28 17:42:06 --> Output Class Initialized
INFO - 2018-03-28 17:42:06 --> Security Class Initialized
DEBUG - 2018-03-28 17:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:42:06 --> Input Class Initialized
INFO - 2018-03-28 17:42:06 --> Language Class Initialized
INFO - 2018-03-28 17:42:06 --> Loader Class Initialized
INFO - 2018-03-28 17:42:06 --> Helper loaded: url_helper
INFO - 2018-03-28 17:42:06 --> Helper loaded: form_helper
INFO - 2018-03-28 17:42:06 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:42:07 --> Controller Class Initialized
INFO - 2018-03-28 17:42:07 --> Model Class Initialized
INFO - 2018-03-28 17:42:07 --> Model Class Initialized
INFO - 2018-03-28 17:42:07 --> Model Class Initialized
INFO - 2018-03-28 17:42:07 --> Model Class Initialized
INFO - 2018-03-28 17:42:07 --> Model Class Initialized
INFO - 2018-03-28 17:42:07 --> Helper loaded: date_helper
INFO - 2018-03-28 17:42:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 17:42:07 --> Config Class Initialized
INFO - 2018-03-28 17:42:07 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:42:07 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:42:07 --> Utf8 Class Initialized
INFO - 2018-03-28 17:42:07 --> URI Class Initialized
INFO - 2018-03-28 17:42:07 --> Router Class Initialized
INFO - 2018-03-28 17:42:07 --> Output Class Initialized
INFO - 2018-03-28 17:42:07 --> Security Class Initialized
DEBUG - 2018-03-28 17:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:42:07 --> Input Class Initialized
INFO - 2018-03-28 17:42:07 --> Language Class Initialized
INFO - 2018-03-28 17:42:07 --> Loader Class Initialized
INFO - 2018-03-28 17:42:07 --> Helper loaded: url_helper
INFO - 2018-03-28 17:42:07 --> Helper loaded: form_helper
INFO - 2018-03-28 17:42:07 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:42:07 --> Controller Class Initialized
INFO - 2018-03-28 17:42:07 --> Model Class Initialized
INFO - 2018-03-28 17:42:07 --> Model Class Initialized
INFO - 2018-03-28 17:42:07 --> Model Class Initialized
INFO - 2018-03-28 17:42:07 --> Model Class Initialized
INFO - 2018-03-28 17:42:07 --> Model Class Initialized
INFO - 2018-03-28 17:42:07 --> Helper loaded: date_helper
INFO - 2018-03-28 17:42:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:42:07 --> Model Class Initialized
INFO - 2018-03-28 22:42:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:42:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:42:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-28 22:42:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:42:07 --> Final output sent to browser
DEBUG - 2018-03-28 22:42:07 --> Total execution time: 0.1321
INFO - 2018-03-28 17:42:13 --> Config Class Initialized
INFO - 2018-03-28 17:42:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:42:13 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:42:13 --> Utf8 Class Initialized
INFO - 2018-03-28 17:42:13 --> URI Class Initialized
INFO - 2018-03-28 17:42:13 --> Router Class Initialized
INFO - 2018-03-28 17:42:13 --> Output Class Initialized
INFO - 2018-03-28 17:42:13 --> Security Class Initialized
DEBUG - 2018-03-28 17:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:42:13 --> Input Class Initialized
INFO - 2018-03-28 17:42:13 --> Language Class Initialized
INFO - 2018-03-28 17:42:13 --> Loader Class Initialized
INFO - 2018-03-28 17:42:13 --> Helper loaded: url_helper
INFO - 2018-03-28 17:42:13 --> Helper loaded: form_helper
INFO - 2018-03-28 17:42:13 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:42:13 --> Controller Class Initialized
INFO - 2018-03-28 17:42:13 --> Model Class Initialized
INFO - 2018-03-28 17:42:13 --> Model Class Initialized
INFO - 2018-03-28 17:42:13 --> Model Class Initialized
INFO - 2018-03-28 17:42:13 --> Model Class Initialized
INFO - 2018-03-28 17:42:13 --> Model Class Initialized
INFO - 2018-03-28 17:42:13 --> Helper loaded: date_helper
INFO - 2018-03-28 17:42:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:42:13 --> Model Class Initialized
INFO - 2018-03-28 22:42:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:42:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:42:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/detail.php
INFO - 2018-03-28 22:42:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:42:13 --> Final output sent to browser
DEBUG - 2018-03-28 22:42:13 --> Total execution time: 0.0929
INFO - 2018-03-28 17:42:18 --> Config Class Initialized
INFO - 2018-03-28 17:42:18 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:42:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:42:18 --> Utf8 Class Initialized
INFO - 2018-03-28 17:42:18 --> URI Class Initialized
INFO - 2018-03-28 17:42:18 --> Router Class Initialized
INFO - 2018-03-28 17:42:18 --> Output Class Initialized
INFO - 2018-03-28 17:42:18 --> Security Class Initialized
DEBUG - 2018-03-28 17:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:42:18 --> Input Class Initialized
INFO - 2018-03-28 17:42:18 --> Language Class Initialized
INFO - 2018-03-28 17:42:18 --> Loader Class Initialized
INFO - 2018-03-28 17:42:18 --> Helper loaded: url_helper
INFO - 2018-03-28 17:42:18 --> Helper loaded: form_helper
INFO - 2018-03-28 17:42:18 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:42:18 --> Controller Class Initialized
INFO - 2018-03-28 17:42:18 --> Model Class Initialized
INFO - 2018-03-28 17:42:18 --> Model Class Initialized
INFO - 2018-03-28 17:42:18 --> Model Class Initialized
INFO - 2018-03-28 17:42:18 --> Model Class Initialized
INFO - 2018-03-28 17:42:18 --> Model Class Initialized
INFO - 2018-03-28 17:42:18 --> Helper loaded: date_helper
INFO - 2018-03-28 17:42:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:42:18 --> Model Class Initialized
INFO - 2018-03-28 22:42:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:42:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:42:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/edit.php
INFO - 2018-03-28 22:42:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:42:18 --> Final output sent to browser
DEBUG - 2018-03-28 22:42:18 --> Total execution time: 0.1686
INFO - 2018-03-28 17:42:22 --> Config Class Initialized
INFO - 2018-03-28 17:42:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:42:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:42:22 --> Utf8 Class Initialized
INFO - 2018-03-28 17:42:22 --> URI Class Initialized
INFO - 2018-03-28 17:42:22 --> Router Class Initialized
INFO - 2018-03-28 17:42:22 --> Output Class Initialized
INFO - 2018-03-28 17:42:22 --> Security Class Initialized
DEBUG - 2018-03-28 17:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:42:22 --> Input Class Initialized
INFO - 2018-03-28 17:42:22 --> Language Class Initialized
INFO - 2018-03-28 17:42:22 --> Loader Class Initialized
INFO - 2018-03-28 17:42:22 --> Helper loaded: url_helper
INFO - 2018-03-28 17:42:22 --> Helper loaded: form_helper
INFO - 2018-03-28 17:42:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:42:22 --> Controller Class Initialized
INFO - 2018-03-28 17:42:22 --> Model Class Initialized
INFO - 2018-03-28 17:42:22 --> Model Class Initialized
INFO - 2018-03-28 17:42:22 --> Model Class Initialized
INFO - 2018-03-28 17:42:22 --> Model Class Initialized
INFO - 2018-03-28 17:42:22 --> Model Class Initialized
INFO - 2018-03-28 17:42:22 --> Helper loaded: date_helper
INFO - 2018-03-28 17:42:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:42:22 --> Model Class Initialized
INFO - 2018-03-28 22:42:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:42:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:42:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-28 22:42:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:42:22 --> Final output sent to browser
DEBUG - 2018-03-28 22:42:22 --> Total execution time: 0.1316
INFO - 2018-03-28 17:42:25 --> Config Class Initialized
INFO - 2018-03-28 17:42:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:42:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:42:25 --> Utf8 Class Initialized
INFO - 2018-03-28 17:42:25 --> URI Class Initialized
INFO - 2018-03-28 17:42:25 --> Router Class Initialized
INFO - 2018-03-28 17:42:25 --> Output Class Initialized
INFO - 2018-03-28 17:42:25 --> Security Class Initialized
DEBUG - 2018-03-28 17:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:42:25 --> Input Class Initialized
INFO - 2018-03-28 17:42:25 --> Language Class Initialized
INFO - 2018-03-28 17:42:25 --> Loader Class Initialized
INFO - 2018-03-28 17:42:25 --> Helper loaded: url_helper
INFO - 2018-03-28 17:42:25 --> Helper loaded: form_helper
INFO - 2018-03-28 17:42:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:42:25 --> Controller Class Initialized
INFO - 2018-03-28 17:42:25 --> Model Class Initialized
INFO - 2018-03-28 17:42:25 --> Model Class Initialized
INFO - 2018-03-28 17:42:25 --> Model Class Initialized
INFO - 2018-03-28 17:42:25 --> Model Class Initialized
INFO - 2018-03-28 17:42:25 --> Model Class Initialized
INFO - 2018-03-28 17:42:25 --> Helper loaded: date_helper
INFO - 2018-03-28 17:42:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:42:25 --> Model Class Initialized
INFO - 2018-03-28 22:42:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:42:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:42:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/detail.php
INFO - 2018-03-28 22:42:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:42:25 --> Final output sent to browser
DEBUG - 2018-03-28 22:42:25 --> Total execution time: 0.1247
INFO - 2018-03-28 17:42:50 --> Config Class Initialized
INFO - 2018-03-28 17:42:50 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:42:50 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:42:50 --> Utf8 Class Initialized
INFO - 2018-03-28 17:42:50 --> URI Class Initialized
INFO - 2018-03-28 17:42:50 --> Router Class Initialized
INFO - 2018-03-28 17:42:50 --> Output Class Initialized
INFO - 2018-03-28 17:42:50 --> Security Class Initialized
DEBUG - 2018-03-28 17:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:42:50 --> Input Class Initialized
INFO - 2018-03-28 17:42:50 --> Language Class Initialized
INFO - 2018-03-28 17:42:50 --> Loader Class Initialized
INFO - 2018-03-28 17:42:50 --> Helper loaded: url_helper
INFO - 2018-03-28 17:42:50 --> Helper loaded: form_helper
INFO - 2018-03-28 17:42:50 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:42:50 --> Controller Class Initialized
INFO - 2018-03-28 17:42:50 --> Model Class Initialized
INFO - 2018-03-28 17:42:50 --> Model Class Initialized
INFO - 2018-03-28 17:42:50 --> Model Class Initialized
INFO - 2018-03-28 17:42:50 --> Model Class Initialized
INFO - 2018-03-28 17:42:50 --> Model Class Initialized
INFO - 2018-03-28 17:42:50 --> Helper loaded: date_helper
INFO - 2018-03-28 17:42:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:42:50 --> Model Class Initialized
INFO - 2018-03-28 22:42:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:42:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:42:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-28 22:42:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:42:50 --> Final output sent to browser
DEBUG - 2018-03-28 22:42:50 --> Total execution time: 0.1093
INFO - 2018-03-28 17:43:11 --> Config Class Initialized
INFO - 2018-03-28 17:43:11 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:43:11 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:43:11 --> Utf8 Class Initialized
INFO - 2018-03-28 17:43:11 --> URI Class Initialized
INFO - 2018-03-28 17:43:11 --> Router Class Initialized
INFO - 2018-03-28 17:43:11 --> Output Class Initialized
INFO - 2018-03-28 17:43:11 --> Security Class Initialized
DEBUG - 2018-03-28 17:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:43:11 --> Input Class Initialized
INFO - 2018-03-28 17:43:12 --> Language Class Initialized
INFO - 2018-03-28 17:43:12 --> Loader Class Initialized
INFO - 2018-03-28 17:43:12 --> Helper loaded: url_helper
INFO - 2018-03-28 17:43:12 --> Helper loaded: form_helper
INFO - 2018-03-28 17:43:12 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:43:12 --> Controller Class Initialized
INFO - 2018-03-28 17:43:12 --> Model Class Initialized
INFO - 2018-03-28 17:43:12 --> Model Class Initialized
INFO - 2018-03-28 17:43:12 --> Model Class Initialized
INFO - 2018-03-28 17:43:12 --> Model Class Initialized
INFO - 2018-03-28 17:43:12 --> Model Class Initialized
INFO - 2018-03-28 17:43:12 --> Model Class Initialized
INFO - 2018-03-28 17:43:12 --> Model Class Initialized
INFO - 2018-03-28 17:43:12 --> Helper loaded: date_helper
INFO - 2018-03-28 17:43:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:43:12 --> Model Class Initialized
INFO - 2018-03-28 22:43:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:43:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:43:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-28 22:43:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:43:12 --> Final output sent to browser
DEBUG - 2018-03-28 22:43:12 --> Total execution time: 0.1409
INFO - 2018-03-28 17:43:19 --> Config Class Initialized
INFO - 2018-03-28 17:43:19 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:43:19 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:43:19 --> Utf8 Class Initialized
INFO - 2018-03-28 17:43:19 --> URI Class Initialized
INFO - 2018-03-28 17:43:19 --> Router Class Initialized
INFO - 2018-03-28 17:43:19 --> Output Class Initialized
INFO - 2018-03-28 17:43:19 --> Security Class Initialized
DEBUG - 2018-03-28 17:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:43:19 --> Input Class Initialized
INFO - 2018-03-28 17:43:19 --> Language Class Initialized
INFO - 2018-03-28 17:43:19 --> Loader Class Initialized
INFO - 2018-03-28 17:43:19 --> Helper loaded: url_helper
INFO - 2018-03-28 17:43:19 --> Helper loaded: form_helper
INFO - 2018-03-28 17:43:19 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:43:19 --> Controller Class Initialized
INFO - 2018-03-28 17:43:19 --> Model Class Initialized
INFO - 2018-03-28 17:43:19 --> Model Class Initialized
INFO - 2018-03-28 17:43:19 --> Model Class Initialized
INFO - 2018-03-28 17:43:19 --> Model Class Initialized
INFO - 2018-03-28 17:43:19 --> Model Class Initialized
INFO - 2018-03-28 17:43:19 --> Model Class Initialized
INFO - 2018-03-28 17:43:19 --> Model Class Initialized
INFO - 2018-03-28 17:43:19 --> Model Class Initialized
INFO - 2018-03-28 17:43:19 --> Model Class Initialized
INFO - 2018-03-28 17:43:19 --> Model Class Initialized
INFO - 2018-03-28 17:43:19 --> Model Class Initialized
INFO - 2018-03-28 17:43:19 --> Model Class Initialized
INFO - 2018-03-28 17:43:19 --> Model Class Initialized
INFO - 2018-03-28 17:43:19 --> Model Class Initialized
INFO - 2018-03-28 17:43:19 --> Helper loaded: date_helper
INFO - 2018-03-28 17:43:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:43:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:43:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:43:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-28 22:43:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:43:19 --> Final output sent to browser
DEBUG - 2018-03-28 22:43:19 --> Total execution time: 0.1429
INFO - 2018-03-28 17:43:35 --> Config Class Initialized
INFO - 2018-03-28 17:43:35 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:43:35 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:43:35 --> Utf8 Class Initialized
INFO - 2018-03-28 17:43:35 --> URI Class Initialized
INFO - 2018-03-28 17:43:35 --> Router Class Initialized
INFO - 2018-03-28 17:43:35 --> Output Class Initialized
INFO - 2018-03-28 17:43:35 --> Security Class Initialized
DEBUG - 2018-03-28 17:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:43:35 --> Input Class Initialized
INFO - 2018-03-28 17:43:35 --> Language Class Initialized
INFO - 2018-03-28 17:43:35 --> Loader Class Initialized
INFO - 2018-03-28 17:43:35 --> Helper loaded: url_helper
INFO - 2018-03-28 17:43:35 --> Helper loaded: form_helper
INFO - 2018-03-28 17:43:35 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:43:35 --> Controller Class Initialized
INFO - 2018-03-28 17:43:35 --> Model Class Initialized
INFO - 2018-03-28 17:43:35 --> Model Class Initialized
INFO - 2018-03-28 17:43:35 --> Model Class Initialized
INFO - 2018-03-28 17:43:35 --> Model Class Initialized
INFO - 2018-03-28 17:43:35 --> Model Class Initialized
INFO - 2018-03-28 17:43:35 --> Model Class Initialized
INFO - 2018-03-28 17:43:35 --> Model Class Initialized
INFO - 2018-03-28 17:43:35 --> Model Class Initialized
INFO - 2018-03-28 17:43:35 --> Model Class Initialized
INFO - 2018-03-28 17:43:35 --> Model Class Initialized
INFO - 2018-03-28 17:43:35 --> Model Class Initialized
INFO - 2018-03-28 17:43:35 --> Model Class Initialized
INFO - 2018-03-28 17:43:35 --> Model Class Initialized
INFO - 2018-03-28 17:43:35 --> Model Class Initialized
INFO - 2018-03-28 17:43:35 --> Helper loaded: date_helper
INFO - 2018-03-28 17:43:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:43:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:43:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:43:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-28 22:43:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:43:35 --> Final output sent to browser
DEBUG - 2018-03-28 22:43:35 --> Total execution time: 0.1224
INFO - 2018-03-28 17:43:46 --> Config Class Initialized
INFO - 2018-03-28 17:43:46 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:43:46 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:43:46 --> Utf8 Class Initialized
INFO - 2018-03-28 17:43:46 --> URI Class Initialized
INFO - 2018-03-28 17:43:46 --> Router Class Initialized
INFO - 2018-03-28 17:43:46 --> Output Class Initialized
INFO - 2018-03-28 17:43:46 --> Security Class Initialized
DEBUG - 2018-03-28 17:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:43:46 --> Input Class Initialized
INFO - 2018-03-28 17:43:46 --> Language Class Initialized
INFO - 2018-03-28 17:43:46 --> Loader Class Initialized
INFO - 2018-03-28 17:43:46 --> Helper loaded: url_helper
INFO - 2018-03-28 17:43:46 --> Helper loaded: form_helper
INFO - 2018-03-28 17:43:46 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:43:46 --> Controller Class Initialized
INFO - 2018-03-28 17:43:46 --> Model Class Initialized
INFO - 2018-03-28 17:43:46 --> Model Class Initialized
INFO - 2018-03-28 17:43:46 --> Helper loaded: date_helper
INFO - 2018-03-28 17:43:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:43:46 --> Final output sent to browser
DEBUG - 2018-03-28 22:43:46 --> Total execution time: 0.1232
INFO - 2018-03-28 17:43:47 --> Config Class Initialized
INFO - 2018-03-28 17:43:47 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:43:47 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:43:47 --> Utf8 Class Initialized
INFO - 2018-03-28 17:43:47 --> URI Class Initialized
INFO - 2018-03-28 17:43:47 --> Router Class Initialized
INFO - 2018-03-28 17:43:47 --> Output Class Initialized
INFO - 2018-03-28 17:43:47 --> Security Class Initialized
DEBUG - 2018-03-28 17:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:43:47 --> Input Class Initialized
INFO - 2018-03-28 17:43:47 --> Language Class Initialized
INFO - 2018-03-28 17:43:47 --> Loader Class Initialized
INFO - 2018-03-28 17:43:47 --> Helper loaded: url_helper
INFO - 2018-03-28 17:43:47 --> Helper loaded: form_helper
INFO - 2018-03-28 17:43:47 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:43:47 --> Controller Class Initialized
INFO - 2018-03-28 17:43:47 --> Model Class Initialized
INFO - 2018-03-28 17:43:47 --> Model Class Initialized
INFO - 2018-03-28 17:43:47 --> Helper loaded: date_helper
INFO - 2018-03-28 17:43:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:43:47 --> Final output sent to browser
DEBUG - 2018-03-28 22:43:47 --> Total execution time: 0.1252
INFO - 2018-03-28 17:44:38 --> Config Class Initialized
INFO - 2018-03-28 17:44:38 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:44:38 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:44:38 --> Utf8 Class Initialized
INFO - 2018-03-28 17:44:38 --> URI Class Initialized
INFO - 2018-03-28 17:44:38 --> Router Class Initialized
INFO - 2018-03-28 17:44:38 --> Output Class Initialized
INFO - 2018-03-28 17:44:38 --> Security Class Initialized
DEBUG - 2018-03-28 17:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:44:38 --> Input Class Initialized
INFO - 2018-03-28 17:44:38 --> Language Class Initialized
INFO - 2018-03-28 17:44:38 --> Loader Class Initialized
INFO - 2018-03-28 17:44:38 --> Helper loaded: url_helper
INFO - 2018-03-28 17:44:38 --> Helper loaded: form_helper
INFO - 2018-03-28 17:44:38 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:44:38 --> Controller Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Model Class Initialized
INFO - 2018-03-28 17:44:38 --> Helper loaded: date_helper
INFO - 2018-03-28 17:44:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 17:44:39 --> Config Class Initialized
INFO - 2018-03-28 17:44:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:44:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:44:39 --> Utf8 Class Initialized
INFO - 2018-03-28 17:44:39 --> URI Class Initialized
INFO - 2018-03-28 17:44:39 --> Router Class Initialized
INFO - 2018-03-28 17:44:39 --> Output Class Initialized
INFO - 2018-03-28 17:44:39 --> Security Class Initialized
DEBUG - 2018-03-28 17:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:44:39 --> Input Class Initialized
INFO - 2018-03-28 17:44:39 --> Language Class Initialized
INFO - 2018-03-28 17:44:39 --> Loader Class Initialized
INFO - 2018-03-28 17:44:39 --> Helper loaded: url_helper
INFO - 2018-03-28 17:44:39 --> Helper loaded: form_helper
INFO - 2018-03-28 17:44:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:44:39 --> Controller Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Model Class Initialized
INFO - 2018-03-28 17:44:39 --> Helper loaded: date_helper
INFO - 2018-03-28 17:44:39 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:44:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:44:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:44:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-28 22:44:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:44:39 --> Final output sent to browser
DEBUG - 2018-03-28 22:44:39 --> Total execution time: 0.1758
INFO - 2018-03-28 17:45:14 --> Config Class Initialized
INFO - 2018-03-28 17:45:14 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:45:14 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:45:14 --> Utf8 Class Initialized
INFO - 2018-03-28 17:45:14 --> URI Class Initialized
INFO - 2018-03-28 17:45:14 --> Router Class Initialized
INFO - 2018-03-28 17:45:14 --> Output Class Initialized
INFO - 2018-03-28 17:45:14 --> Security Class Initialized
DEBUG - 2018-03-28 17:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:45:14 --> Input Class Initialized
INFO - 2018-03-28 17:45:14 --> Language Class Initialized
INFO - 2018-03-28 17:45:14 --> Loader Class Initialized
INFO - 2018-03-28 17:45:14 --> Helper loaded: url_helper
INFO - 2018-03-28 17:45:14 --> Helper loaded: form_helper
INFO - 2018-03-28 17:45:14 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:45:14 --> Controller Class Initialized
INFO - 2018-03-28 17:45:14 --> Model Class Initialized
INFO - 2018-03-28 17:45:14 --> Model Class Initialized
INFO - 2018-03-28 17:45:14 --> Model Class Initialized
INFO - 2018-03-28 17:45:14 --> Model Class Initialized
INFO - 2018-03-28 17:45:14 --> Model Class Initialized
INFO - 2018-03-28 17:45:14 --> Model Class Initialized
INFO - 2018-03-28 17:45:14 --> Model Class Initialized
INFO - 2018-03-28 17:45:14 --> Model Class Initialized
INFO - 2018-03-28 17:45:14 --> Model Class Initialized
INFO - 2018-03-28 17:45:14 --> Model Class Initialized
INFO - 2018-03-28 17:45:14 --> Model Class Initialized
INFO - 2018-03-28 17:45:14 --> Model Class Initialized
INFO - 2018-03-28 17:45:14 --> Helper loaded: date_helper
INFO - 2018-03-28 17:45:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:45:14 --> Model Class Initialized
INFO - 2018-03-28 22:45:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:45:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:45:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-28 22:45:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:45:14 --> Final output sent to browser
DEBUG - 2018-03-28 22:45:14 --> Total execution time: 0.1301
INFO - 2018-03-28 17:45:24 --> Config Class Initialized
INFO - 2018-03-28 17:45:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:45:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:45:24 --> Utf8 Class Initialized
INFO - 2018-03-28 17:45:24 --> URI Class Initialized
INFO - 2018-03-28 17:45:24 --> Router Class Initialized
INFO - 2018-03-28 17:45:24 --> Output Class Initialized
INFO - 2018-03-28 17:45:24 --> Security Class Initialized
DEBUG - 2018-03-28 17:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:45:24 --> Input Class Initialized
INFO - 2018-03-28 17:45:24 --> Language Class Initialized
INFO - 2018-03-28 17:45:24 --> Loader Class Initialized
INFO - 2018-03-28 17:45:24 --> Helper loaded: url_helper
INFO - 2018-03-28 17:45:24 --> Helper loaded: form_helper
INFO - 2018-03-28 17:45:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:45:24 --> Controller Class Initialized
INFO - 2018-03-28 17:45:24 --> Model Class Initialized
INFO - 2018-03-28 17:45:24 --> Model Class Initialized
INFO - 2018-03-28 17:45:24 --> Model Class Initialized
INFO - 2018-03-28 17:45:24 --> Model Class Initialized
INFO - 2018-03-28 17:45:24 --> Model Class Initialized
INFO - 2018-03-28 17:45:24 --> Model Class Initialized
INFO - 2018-03-28 17:45:24 --> Model Class Initialized
INFO - 2018-03-28 17:45:24 --> Model Class Initialized
INFO - 2018-03-28 17:45:24 --> Model Class Initialized
INFO - 2018-03-28 17:45:24 --> Model Class Initialized
INFO - 2018-03-28 17:45:24 --> Model Class Initialized
INFO - 2018-03-28 17:45:24 --> Model Class Initialized
INFO - 2018-03-28 17:45:24 --> Helper loaded: date_helper
INFO - 2018-03-28 17:45:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:45:24 --> Model Class Initialized
INFO - 2018-03-28 22:45:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:45:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:45:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-28 22:45:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:45:24 --> Final output sent to browser
DEBUG - 2018-03-28 22:45:24 --> Total execution time: 0.1397
INFO - 2018-03-28 17:45:40 --> Config Class Initialized
INFO - 2018-03-28 17:45:40 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:45:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:45:40 --> Utf8 Class Initialized
INFO - 2018-03-28 17:45:40 --> URI Class Initialized
INFO - 2018-03-28 17:45:40 --> Router Class Initialized
INFO - 2018-03-28 17:45:40 --> Output Class Initialized
INFO - 2018-03-28 17:45:40 --> Security Class Initialized
DEBUG - 2018-03-28 17:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:45:40 --> Input Class Initialized
INFO - 2018-03-28 17:45:40 --> Language Class Initialized
INFO - 2018-03-28 17:45:40 --> Loader Class Initialized
INFO - 2018-03-28 17:45:40 --> Helper loaded: url_helper
INFO - 2018-03-28 17:45:40 --> Helper loaded: form_helper
INFO - 2018-03-28 17:45:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:45:40 --> Controller Class Initialized
INFO - 2018-03-28 17:45:40 --> Model Class Initialized
INFO - 2018-03-28 17:45:40 --> Model Class Initialized
INFO - 2018-03-28 17:45:40 --> Model Class Initialized
INFO - 2018-03-28 17:45:40 --> Model Class Initialized
INFO - 2018-03-28 17:45:40 --> Model Class Initialized
INFO - 2018-03-28 17:45:40 --> Model Class Initialized
INFO - 2018-03-28 17:45:40 --> Model Class Initialized
INFO - 2018-03-28 17:45:40 --> Model Class Initialized
INFO - 2018-03-28 17:45:40 --> Model Class Initialized
INFO - 2018-03-28 17:45:40 --> Model Class Initialized
INFO - 2018-03-28 17:45:40 --> Model Class Initialized
INFO - 2018-03-28 17:45:40 --> Model Class Initialized
INFO - 2018-03-28 17:45:40 --> Helper loaded: date_helper
INFO - 2018-03-28 17:45:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:45:40 --> Model Class Initialized
INFO - 2018-03-28 22:45:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:45:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:45:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-28 22:45:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:45:40 --> Final output sent to browser
DEBUG - 2018-03-28 22:45:40 --> Total execution time: 0.1532
INFO - 2018-03-28 17:45:43 --> Config Class Initialized
INFO - 2018-03-28 17:45:43 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:45:43 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:45:43 --> Utf8 Class Initialized
INFO - 2018-03-28 17:45:43 --> URI Class Initialized
INFO - 2018-03-28 17:45:43 --> Router Class Initialized
INFO - 2018-03-28 17:45:43 --> Output Class Initialized
INFO - 2018-03-28 17:45:43 --> Security Class Initialized
DEBUG - 2018-03-28 17:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:45:43 --> Input Class Initialized
INFO - 2018-03-28 17:45:43 --> Language Class Initialized
INFO - 2018-03-28 17:45:43 --> Loader Class Initialized
INFO - 2018-03-28 17:45:43 --> Helper loaded: url_helper
INFO - 2018-03-28 17:45:43 --> Helper loaded: form_helper
INFO - 2018-03-28 17:45:43 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:45:43 --> Controller Class Initialized
INFO - 2018-03-28 17:45:43 --> Model Class Initialized
INFO - 2018-03-28 17:45:43 --> Model Class Initialized
INFO - 2018-03-28 17:45:43 --> Model Class Initialized
INFO - 2018-03-28 17:45:43 --> Model Class Initialized
INFO - 2018-03-28 17:45:43 --> Model Class Initialized
INFO - 2018-03-28 17:45:43 --> Model Class Initialized
INFO - 2018-03-28 17:45:43 --> Model Class Initialized
INFO - 2018-03-28 17:45:43 --> Model Class Initialized
INFO - 2018-03-28 17:45:43 --> Model Class Initialized
INFO - 2018-03-28 17:45:43 --> Model Class Initialized
INFO - 2018-03-28 17:45:43 --> Model Class Initialized
INFO - 2018-03-28 17:45:43 --> Model Class Initialized
INFO - 2018-03-28 17:45:43 --> Helper loaded: date_helper
INFO - 2018-03-28 17:45:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:45:43 --> Model Class Initialized
INFO - 2018-03-28 22:45:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:45:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:45:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-28 22:45:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:45:43 --> Final output sent to browser
DEBUG - 2018-03-28 22:45:43 --> Total execution time: 0.1458
INFO - 2018-03-28 17:45:50 --> Config Class Initialized
INFO - 2018-03-28 17:45:50 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:45:50 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:45:50 --> Utf8 Class Initialized
INFO - 2018-03-28 17:45:50 --> URI Class Initialized
INFO - 2018-03-28 17:45:50 --> Router Class Initialized
INFO - 2018-03-28 17:45:50 --> Output Class Initialized
INFO - 2018-03-28 17:45:50 --> Security Class Initialized
DEBUG - 2018-03-28 17:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:45:50 --> Input Class Initialized
INFO - 2018-03-28 17:45:50 --> Language Class Initialized
INFO - 2018-03-28 17:45:50 --> Loader Class Initialized
INFO - 2018-03-28 17:45:50 --> Helper loaded: url_helper
INFO - 2018-03-28 17:45:50 --> Helper loaded: form_helper
INFO - 2018-03-28 17:45:50 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:45:50 --> Controller Class Initialized
INFO - 2018-03-28 17:45:50 --> Model Class Initialized
INFO - 2018-03-28 17:45:50 --> Model Class Initialized
INFO - 2018-03-28 17:45:50 --> Model Class Initialized
INFO - 2018-03-28 17:45:50 --> Model Class Initialized
INFO - 2018-03-28 17:45:50 --> Model Class Initialized
INFO - 2018-03-28 17:45:50 --> Model Class Initialized
INFO - 2018-03-28 17:45:50 --> Model Class Initialized
INFO - 2018-03-28 17:45:50 --> Model Class Initialized
INFO - 2018-03-28 17:45:50 --> Model Class Initialized
INFO - 2018-03-28 17:45:50 --> Model Class Initialized
INFO - 2018-03-28 17:45:50 --> Model Class Initialized
INFO - 2018-03-28 17:45:50 --> Model Class Initialized
INFO - 2018-03-28 17:45:50 --> Helper loaded: date_helper
INFO - 2018-03-28 17:45:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:45:50 --> Model Class Initialized
INFO - 2018-03-28 22:45:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:45:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:45:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-28 22:45:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:45:50 --> Final output sent to browser
DEBUG - 2018-03-28 22:45:50 --> Total execution time: 0.1131
INFO - 2018-03-28 17:45:59 --> Config Class Initialized
INFO - 2018-03-28 17:45:59 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:45:59 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:45:59 --> Utf8 Class Initialized
INFO - 2018-03-28 17:45:59 --> URI Class Initialized
INFO - 2018-03-28 17:45:59 --> Router Class Initialized
INFO - 2018-03-28 17:45:59 --> Output Class Initialized
INFO - 2018-03-28 17:45:59 --> Security Class Initialized
DEBUG - 2018-03-28 17:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:45:59 --> Input Class Initialized
INFO - 2018-03-28 17:45:59 --> Language Class Initialized
INFO - 2018-03-28 17:45:59 --> Loader Class Initialized
INFO - 2018-03-28 17:45:59 --> Helper loaded: url_helper
INFO - 2018-03-28 17:45:59 --> Helper loaded: form_helper
INFO - 2018-03-28 17:46:00 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:46:00 --> Controller Class Initialized
INFO - 2018-03-28 17:46:00 --> Model Class Initialized
INFO - 2018-03-28 17:46:00 --> Model Class Initialized
INFO - 2018-03-28 17:46:00 --> Model Class Initialized
INFO - 2018-03-28 17:46:00 --> Model Class Initialized
INFO - 2018-03-28 17:46:00 --> Model Class Initialized
INFO - 2018-03-28 17:46:00 --> Model Class Initialized
INFO - 2018-03-28 17:46:00 --> Model Class Initialized
INFO - 2018-03-28 17:46:00 --> Model Class Initialized
INFO - 2018-03-28 17:46:00 --> Model Class Initialized
INFO - 2018-03-28 17:46:00 --> Model Class Initialized
INFO - 2018-03-28 17:46:00 --> Model Class Initialized
INFO - 2018-03-28 17:46:00 --> Model Class Initialized
INFO - 2018-03-28 17:46:00 --> Helper loaded: date_helper
INFO - 2018-03-28 17:46:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:46:00 --> Model Class Initialized
INFO - 2018-03-28 22:46:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:46:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:46:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/detail.php
INFO - 2018-03-28 22:46:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:46:00 --> Final output sent to browser
DEBUG - 2018-03-28 22:46:00 --> Total execution time: 0.1267
INFO - 2018-03-28 17:47:08 --> Config Class Initialized
INFO - 2018-03-28 17:47:08 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:47:08 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:47:08 --> Utf8 Class Initialized
INFO - 2018-03-28 17:47:08 --> URI Class Initialized
INFO - 2018-03-28 17:47:08 --> Router Class Initialized
INFO - 2018-03-28 17:47:08 --> Output Class Initialized
INFO - 2018-03-28 17:47:08 --> Security Class Initialized
DEBUG - 2018-03-28 17:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:47:08 --> Input Class Initialized
INFO - 2018-03-28 17:47:08 --> Language Class Initialized
INFO - 2018-03-28 17:47:08 --> Loader Class Initialized
INFO - 2018-03-28 17:47:08 --> Helper loaded: url_helper
INFO - 2018-03-28 17:47:08 --> Helper loaded: form_helper
INFO - 2018-03-28 17:47:08 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:47:08 --> Controller Class Initialized
INFO - 2018-03-28 17:47:08 --> Model Class Initialized
INFO - 2018-03-28 17:47:08 --> Model Class Initialized
INFO - 2018-03-28 17:47:08 --> Model Class Initialized
INFO - 2018-03-28 17:47:08 --> Model Class Initialized
INFO - 2018-03-28 17:47:08 --> Model Class Initialized
INFO - 2018-03-28 17:47:08 --> Model Class Initialized
INFO - 2018-03-28 17:47:08 --> Model Class Initialized
INFO - 2018-03-28 17:47:08 --> Model Class Initialized
INFO - 2018-03-28 17:47:08 --> Model Class Initialized
INFO - 2018-03-28 17:47:08 --> Model Class Initialized
INFO - 2018-03-28 17:47:08 --> Model Class Initialized
INFO - 2018-03-28 17:47:08 --> Model Class Initialized
INFO - 2018-03-28 17:47:08 --> Helper loaded: date_helper
INFO - 2018-03-28 17:47:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:47:08 --> Final output sent to browser
DEBUG - 2018-03-28 22:47:08 --> Total execution time: 0.1855
INFO - 2018-03-28 17:47:38 --> Config Class Initialized
INFO - 2018-03-28 17:47:38 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:47:38 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:47:38 --> Utf8 Class Initialized
INFO - 2018-03-28 17:47:38 --> URI Class Initialized
INFO - 2018-03-28 17:47:38 --> Router Class Initialized
INFO - 2018-03-28 17:47:38 --> Output Class Initialized
INFO - 2018-03-28 17:47:38 --> Security Class Initialized
DEBUG - 2018-03-28 17:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:47:38 --> Input Class Initialized
INFO - 2018-03-28 17:47:38 --> Language Class Initialized
INFO - 2018-03-28 17:47:38 --> Loader Class Initialized
INFO - 2018-03-28 17:47:38 --> Helper loaded: url_helper
INFO - 2018-03-28 17:47:38 --> Helper loaded: form_helper
INFO - 2018-03-28 17:47:38 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:47:38 --> Controller Class Initialized
INFO - 2018-03-28 17:47:38 --> Model Class Initialized
INFO - 2018-03-28 17:47:38 --> Model Class Initialized
INFO - 2018-03-28 17:47:38 --> Model Class Initialized
INFO - 2018-03-28 17:47:38 --> Model Class Initialized
INFO - 2018-03-28 17:47:38 --> Model Class Initialized
INFO - 2018-03-28 17:47:38 --> Model Class Initialized
INFO - 2018-03-28 17:47:38 --> Model Class Initialized
INFO - 2018-03-28 17:47:38 --> Model Class Initialized
INFO - 2018-03-28 17:47:38 --> Model Class Initialized
INFO - 2018-03-28 17:47:38 --> Model Class Initialized
INFO - 2018-03-28 17:47:38 --> Model Class Initialized
INFO - 2018-03-28 17:47:38 --> Model Class Initialized
INFO - 2018-03-28 17:47:38 --> Helper loaded: date_helper
INFO - 2018-03-28 17:47:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:47:38 --> Model Class Initialized
INFO - 2018-03-28 22:47:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:47:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:47:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-28 22:47:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:47:38 --> Final output sent to browser
DEBUG - 2018-03-28 22:47:38 --> Total execution time: 0.1666
INFO - 2018-03-28 17:48:40 --> Config Class Initialized
INFO - 2018-03-28 17:48:40 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:48:40 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:48:40 --> Utf8 Class Initialized
INFO - 2018-03-28 17:48:40 --> URI Class Initialized
INFO - 2018-03-28 17:48:40 --> Router Class Initialized
INFO - 2018-03-28 17:48:40 --> Output Class Initialized
INFO - 2018-03-28 17:48:40 --> Security Class Initialized
DEBUG - 2018-03-28 17:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:48:40 --> Input Class Initialized
INFO - 2018-03-28 17:48:40 --> Language Class Initialized
INFO - 2018-03-28 17:48:40 --> Loader Class Initialized
INFO - 2018-03-28 17:48:40 --> Helper loaded: url_helper
INFO - 2018-03-28 17:48:40 --> Helper loaded: form_helper
INFO - 2018-03-28 17:48:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:48:40 --> Controller Class Initialized
INFO - 2018-03-28 17:48:40 --> Model Class Initialized
INFO - 2018-03-28 17:48:40 --> Model Class Initialized
INFO - 2018-03-28 17:48:40 --> Model Class Initialized
INFO - 2018-03-28 17:48:40 --> Model Class Initialized
INFO - 2018-03-28 17:48:40 --> Model Class Initialized
INFO - 2018-03-28 17:48:40 --> Model Class Initialized
INFO - 2018-03-28 17:48:40 --> Model Class Initialized
INFO - 2018-03-28 17:48:40 --> Model Class Initialized
INFO - 2018-03-28 17:48:40 --> Model Class Initialized
INFO - 2018-03-28 17:48:40 --> Model Class Initialized
INFO - 2018-03-28 17:48:40 --> Model Class Initialized
INFO - 2018-03-28 17:48:40 --> Model Class Initialized
INFO - 2018-03-28 17:48:40 --> Helper loaded: date_helper
INFO - 2018-03-28 17:48:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:48:40 --> Model Class Initialized
INFO - 2018-03-28 22:48:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:48:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:48:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-28 22:48:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:48:40 --> Final output sent to browser
DEBUG - 2018-03-28 22:48:40 --> Total execution time: 0.1614
INFO - 2018-03-28 17:51:24 --> Config Class Initialized
INFO - 2018-03-28 17:51:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:51:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:51:24 --> Utf8 Class Initialized
INFO - 2018-03-28 17:51:24 --> URI Class Initialized
INFO - 2018-03-28 17:51:24 --> Router Class Initialized
INFO - 2018-03-28 17:51:24 --> Output Class Initialized
INFO - 2018-03-28 17:51:24 --> Security Class Initialized
DEBUG - 2018-03-28 17:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:51:24 --> Input Class Initialized
INFO - 2018-03-28 17:51:24 --> Language Class Initialized
INFO - 2018-03-28 17:51:24 --> Loader Class Initialized
INFO - 2018-03-28 17:51:24 --> Helper loaded: url_helper
INFO - 2018-03-28 17:51:24 --> Helper loaded: form_helper
INFO - 2018-03-28 17:51:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:51:24 --> Controller Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Helper loaded: date_helper
INFO - 2018-03-28 17:51:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:51:24 --> Model Class Initialized
INFO - 2018-03-28 22:51:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:51:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:51:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-28 22:51:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:51:24 --> Final output sent to browser
DEBUG - 2018-03-28 22:51:24 --> Total execution time: 0.1439
INFO - 2018-03-28 17:51:24 --> Config Class Initialized
INFO - 2018-03-28 17:51:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:51:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:51:24 --> Utf8 Class Initialized
INFO - 2018-03-28 17:51:24 --> URI Class Initialized
INFO - 2018-03-28 17:51:24 --> Router Class Initialized
INFO - 2018-03-28 17:51:24 --> Output Class Initialized
INFO - 2018-03-28 17:51:24 --> Security Class Initialized
DEBUG - 2018-03-28 17:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:51:24 --> Input Class Initialized
INFO - 2018-03-28 17:51:24 --> Language Class Initialized
INFO - 2018-03-28 17:51:24 --> Loader Class Initialized
INFO - 2018-03-28 17:51:24 --> Helper loaded: url_helper
INFO - 2018-03-28 17:51:24 --> Helper loaded: form_helper
INFO - 2018-03-28 17:51:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:51:24 --> Controller Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Model Class Initialized
INFO - 2018-03-28 17:51:24 --> Helper loaded: date_helper
INFO - 2018-03-28 17:51:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:51:24 --> Model Class Initialized
INFO - 2018-03-28 22:51:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:51:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:51:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-28 22:51:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:51:24 --> Final output sent to browser
DEBUG - 2018-03-28 22:51:24 --> Total execution time: 0.1162
INFO - 2018-03-28 17:51:28 --> Config Class Initialized
INFO - 2018-03-28 17:51:28 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:51:28 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:51:28 --> Utf8 Class Initialized
INFO - 2018-03-28 17:51:28 --> URI Class Initialized
INFO - 2018-03-28 17:51:28 --> Router Class Initialized
INFO - 2018-03-28 17:51:28 --> Output Class Initialized
INFO - 2018-03-28 17:51:28 --> Security Class Initialized
DEBUG - 2018-03-28 17:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:51:28 --> Input Class Initialized
INFO - 2018-03-28 17:51:28 --> Language Class Initialized
INFO - 2018-03-28 17:51:28 --> Loader Class Initialized
INFO - 2018-03-28 17:51:28 --> Helper loaded: url_helper
INFO - 2018-03-28 17:51:28 --> Helper loaded: form_helper
INFO - 2018-03-28 17:51:28 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:51:28 --> Controller Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Helper loaded: date_helper
INFO - 2018-03-28 17:51:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:51:28 --> Model Class Initialized
INFO - 2018-03-28 22:51:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:51:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:51:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-28 22:51:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:51:28 --> Final output sent to browser
DEBUG - 2018-03-28 22:51:28 --> Total execution time: 0.1469
INFO - 2018-03-28 17:51:28 --> Config Class Initialized
INFO - 2018-03-28 17:51:28 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:51:28 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:51:28 --> Utf8 Class Initialized
INFO - 2018-03-28 17:51:28 --> URI Class Initialized
INFO - 2018-03-28 17:51:28 --> Router Class Initialized
INFO - 2018-03-28 17:51:28 --> Output Class Initialized
INFO - 2018-03-28 17:51:28 --> Security Class Initialized
DEBUG - 2018-03-28 17:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:51:28 --> Input Class Initialized
INFO - 2018-03-28 17:51:28 --> Language Class Initialized
INFO - 2018-03-28 17:51:28 --> Loader Class Initialized
INFO - 2018-03-28 17:51:28 --> Helper loaded: url_helper
INFO - 2018-03-28 17:51:28 --> Helper loaded: form_helper
INFO - 2018-03-28 17:51:28 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:51:28 --> Controller Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Helper loaded: date_helper
INFO - 2018-03-28 17:51:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:51:28 --> Model Class Initialized
INFO - 2018-03-28 22:51:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:51:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:51:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-28 22:51:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:51:28 --> Final output sent to browser
DEBUG - 2018-03-28 22:51:28 --> Total execution time: 0.1538
INFO - 2018-03-28 17:51:28 --> Config Class Initialized
INFO - 2018-03-28 17:51:28 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:51:28 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:51:28 --> Utf8 Class Initialized
INFO - 2018-03-28 17:51:28 --> URI Class Initialized
INFO - 2018-03-28 17:51:28 --> Router Class Initialized
INFO - 2018-03-28 17:51:28 --> Output Class Initialized
INFO - 2018-03-28 17:51:28 --> Security Class Initialized
DEBUG - 2018-03-28 17:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:51:28 --> Input Class Initialized
INFO - 2018-03-28 17:51:28 --> Language Class Initialized
INFO - 2018-03-28 17:51:28 --> Loader Class Initialized
INFO - 2018-03-28 17:51:28 --> Helper loaded: url_helper
INFO - 2018-03-28 17:51:28 --> Helper loaded: form_helper
INFO - 2018-03-28 17:51:28 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:51:28 --> Controller Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Model Class Initialized
INFO - 2018-03-28 17:51:28 --> Helper loaded: date_helper
INFO - 2018-03-28 17:51:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:51:28 --> Model Class Initialized
INFO - 2018-03-28 22:51:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:51:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:51:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-28 22:51:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:51:28 --> Final output sent to browser
DEBUG - 2018-03-28 22:51:28 --> Total execution time: 0.1188
INFO - 2018-03-28 17:51:33 --> Config Class Initialized
INFO - 2018-03-28 17:51:33 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:51:33 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:51:33 --> Utf8 Class Initialized
INFO - 2018-03-28 17:51:33 --> URI Class Initialized
INFO - 2018-03-28 17:51:33 --> Router Class Initialized
INFO - 2018-03-28 17:51:33 --> Output Class Initialized
INFO - 2018-03-28 17:51:33 --> Security Class Initialized
DEBUG - 2018-03-28 17:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:51:33 --> Input Class Initialized
INFO - 2018-03-28 17:51:33 --> Language Class Initialized
INFO - 2018-03-28 17:51:33 --> Loader Class Initialized
INFO - 2018-03-28 17:51:33 --> Helper loaded: url_helper
INFO - 2018-03-28 17:51:33 --> Helper loaded: form_helper
INFO - 2018-03-28 17:51:33 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:51:33 --> Controller Class Initialized
INFO - 2018-03-28 17:51:33 --> Model Class Initialized
INFO - 2018-03-28 17:51:33 --> Model Class Initialized
INFO - 2018-03-28 17:51:33 --> Model Class Initialized
INFO - 2018-03-28 17:51:33 --> Model Class Initialized
INFO - 2018-03-28 17:51:33 --> Model Class Initialized
INFO - 2018-03-28 17:51:33 --> Model Class Initialized
INFO - 2018-03-28 17:51:33 --> Model Class Initialized
INFO - 2018-03-28 17:51:33 --> Model Class Initialized
INFO - 2018-03-28 17:51:33 --> Model Class Initialized
INFO - 2018-03-28 17:51:33 --> Model Class Initialized
INFO - 2018-03-28 17:51:33 --> Model Class Initialized
INFO - 2018-03-28 17:51:33 --> Model Class Initialized
INFO - 2018-03-28 17:51:33 --> Model Class Initialized
INFO - 2018-03-28 17:51:33 --> Model Class Initialized
INFO - 2018-03-28 17:51:33 --> Helper loaded: date_helper
INFO - 2018-03-28 17:51:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:51:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:51:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:51:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-28 22:51:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:51:33 --> Final output sent to browser
DEBUG - 2018-03-28 22:51:33 --> Total execution time: 0.1193
INFO - 2018-03-28 17:51:42 --> Config Class Initialized
INFO - 2018-03-28 17:51:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:51:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:51:42 --> Utf8 Class Initialized
INFO - 2018-03-28 17:51:42 --> URI Class Initialized
INFO - 2018-03-28 17:51:42 --> Router Class Initialized
INFO - 2018-03-28 17:51:42 --> Output Class Initialized
INFO - 2018-03-28 17:51:42 --> Security Class Initialized
DEBUG - 2018-03-28 17:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:51:42 --> Input Class Initialized
INFO - 2018-03-28 17:51:42 --> Language Class Initialized
INFO - 2018-03-28 17:51:42 --> Loader Class Initialized
INFO - 2018-03-28 17:51:42 --> Helper loaded: url_helper
INFO - 2018-03-28 17:51:42 --> Helper loaded: form_helper
INFO - 2018-03-28 17:51:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:51:42 --> Controller Class Initialized
INFO - 2018-03-28 17:51:42 --> Model Class Initialized
INFO - 2018-03-28 17:51:42 --> Model Class Initialized
INFO - 2018-03-28 17:51:42 --> Model Class Initialized
INFO - 2018-03-28 17:51:42 --> Model Class Initialized
INFO - 2018-03-28 17:51:42 --> Model Class Initialized
INFO - 2018-03-28 17:51:42 --> Model Class Initialized
INFO - 2018-03-28 17:51:42 --> Model Class Initialized
INFO - 2018-03-28 17:51:42 --> Model Class Initialized
INFO - 2018-03-28 17:51:42 --> Model Class Initialized
INFO - 2018-03-28 17:51:42 --> Model Class Initialized
INFO - 2018-03-28 17:51:42 --> Model Class Initialized
INFO - 2018-03-28 17:51:42 --> Model Class Initialized
INFO - 2018-03-28 17:51:42 --> Model Class Initialized
INFO - 2018-03-28 17:51:42 --> Model Class Initialized
INFO - 2018-03-28 17:51:42 --> Helper loaded: date_helper
INFO - 2018-03-28 17:51:42 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:51:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:51:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:51:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/create.php
INFO - 2018-03-28 22:51:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:51:42 --> Final output sent to browser
DEBUG - 2018-03-28 22:51:42 --> Total execution time: 0.1649
INFO - 2018-03-28 17:51:46 --> Config Class Initialized
INFO - 2018-03-28 17:51:46 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:51:46 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:51:46 --> Utf8 Class Initialized
INFO - 2018-03-28 17:51:46 --> URI Class Initialized
INFO - 2018-03-28 17:51:46 --> Router Class Initialized
INFO - 2018-03-28 17:51:46 --> Output Class Initialized
INFO - 2018-03-28 17:51:46 --> Security Class Initialized
DEBUG - 2018-03-28 17:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:51:46 --> Input Class Initialized
INFO - 2018-03-28 17:51:46 --> Language Class Initialized
INFO - 2018-03-28 17:51:46 --> Loader Class Initialized
INFO - 2018-03-28 17:51:46 --> Helper loaded: url_helper
INFO - 2018-03-28 17:51:46 --> Helper loaded: form_helper
INFO - 2018-03-28 17:51:46 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:51:46 --> Controller Class Initialized
INFO - 2018-03-28 17:51:46 --> Model Class Initialized
INFO - 2018-03-28 17:51:46 --> Model Class Initialized
INFO - 2018-03-28 17:51:46 --> Model Class Initialized
INFO - 2018-03-28 17:51:46 --> Model Class Initialized
INFO - 2018-03-28 17:51:46 --> Model Class Initialized
INFO - 2018-03-28 17:51:46 --> Model Class Initialized
INFO - 2018-03-28 17:51:46 --> Model Class Initialized
INFO - 2018-03-28 17:51:46 --> Model Class Initialized
INFO - 2018-03-28 17:51:46 --> Model Class Initialized
INFO - 2018-03-28 17:51:46 --> Model Class Initialized
INFO - 2018-03-28 17:51:46 --> Model Class Initialized
INFO - 2018-03-28 17:51:46 --> Model Class Initialized
INFO - 2018-03-28 17:51:46 --> Model Class Initialized
INFO - 2018-03-28 17:51:46 --> Model Class Initialized
INFO - 2018-03-28 17:51:46 --> Helper loaded: date_helper
INFO - 2018-03-28 17:51:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:51:46 --> Final output sent to browser
DEBUG - 2018-03-28 22:51:46 --> Total execution time: 0.1964
INFO - 2018-03-28 17:51:50 --> Config Class Initialized
INFO - 2018-03-28 17:51:50 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:51:50 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:51:50 --> Utf8 Class Initialized
INFO - 2018-03-28 17:51:50 --> URI Class Initialized
INFO - 2018-03-28 17:51:50 --> Router Class Initialized
INFO - 2018-03-28 17:51:50 --> Output Class Initialized
INFO - 2018-03-28 17:51:50 --> Security Class Initialized
DEBUG - 2018-03-28 17:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:51:50 --> Input Class Initialized
INFO - 2018-03-28 17:51:50 --> Language Class Initialized
INFO - 2018-03-28 17:51:50 --> Loader Class Initialized
INFO - 2018-03-28 17:51:50 --> Helper loaded: url_helper
INFO - 2018-03-28 17:51:50 --> Helper loaded: form_helper
INFO - 2018-03-28 17:51:50 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:51:50 --> Controller Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Helper loaded: date_helper
INFO - 2018-03-28 17:51:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 17:51:50 --> Config Class Initialized
INFO - 2018-03-28 17:51:50 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:51:50 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:51:50 --> Utf8 Class Initialized
INFO - 2018-03-28 17:51:50 --> URI Class Initialized
INFO - 2018-03-28 17:51:50 --> Router Class Initialized
INFO - 2018-03-28 17:51:50 --> Output Class Initialized
INFO - 2018-03-28 17:51:50 --> Security Class Initialized
DEBUG - 2018-03-28 17:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:51:50 --> Input Class Initialized
INFO - 2018-03-28 17:51:50 --> Language Class Initialized
INFO - 2018-03-28 17:51:50 --> Loader Class Initialized
INFO - 2018-03-28 17:51:50 --> Helper loaded: url_helper
INFO - 2018-03-28 17:51:50 --> Helper loaded: form_helper
INFO - 2018-03-28 17:51:50 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:51:50 --> Controller Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Model Class Initialized
INFO - 2018-03-28 17:51:50 --> Helper loaded: date_helper
INFO - 2018-03-28 17:51:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:51:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:51:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:51:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-28 22:51:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:51:50 --> Final output sent to browser
DEBUG - 2018-03-28 22:51:50 --> Total execution time: 0.1281
INFO - 2018-03-28 17:51:54 --> Config Class Initialized
INFO - 2018-03-28 17:51:54 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:51:54 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:51:54 --> Utf8 Class Initialized
INFO - 2018-03-28 17:51:54 --> URI Class Initialized
INFO - 2018-03-28 17:51:54 --> Router Class Initialized
INFO - 2018-03-28 17:51:54 --> Output Class Initialized
INFO - 2018-03-28 17:51:54 --> Security Class Initialized
DEBUG - 2018-03-28 17:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:51:54 --> Input Class Initialized
INFO - 2018-03-28 17:51:54 --> Language Class Initialized
INFO - 2018-03-28 17:51:54 --> Loader Class Initialized
INFO - 2018-03-28 17:51:54 --> Helper loaded: url_helper
INFO - 2018-03-28 17:51:54 --> Helper loaded: form_helper
INFO - 2018-03-28 17:51:54 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:51:54 --> Controller Class Initialized
INFO - 2018-03-28 17:51:54 --> Model Class Initialized
INFO - 2018-03-28 17:51:54 --> Model Class Initialized
INFO - 2018-03-28 17:51:54 --> Model Class Initialized
INFO - 2018-03-28 17:51:54 --> Model Class Initialized
INFO - 2018-03-28 17:51:54 --> Model Class Initialized
INFO - 2018-03-28 17:51:54 --> Model Class Initialized
INFO - 2018-03-28 17:51:54 --> Model Class Initialized
INFO - 2018-03-28 17:51:54 --> Model Class Initialized
INFO - 2018-03-28 17:51:54 --> Model Class Initialized
INFO - 2018-03-28 17:51:54 --> Model Class Initialized
INFO - 2018-03-28 17:51:54 --> Model Class Initialized
INFO - 2018-03-28 17:51:54 --> Model Class Initialized
INFO - 2018-03-28 17:51:54 --> Model Class Initialized
INFO - 2018-03-28 17:51:54 --> Model Class Initialized
INFO - 2018-03-28 17:51:54 --> Helper loaded: date_helper
INFO - 2018-03-28 17:51:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:51:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:51:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:51:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-28 22:51:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:51:54 --> Final output sent to browser
DEBUG - 2018-03-28 22:51:54 --> Total execution time: 0.1205
INFO - 2018-03-28 17:51:58 --> Config Class Initialized
INFO - 2018-03-28 17:51:58 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:51:58 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:51:58 --> Utf8 Class Initialized
INFO - 2018-03-28 17:51:58 --> URI Class Initialized
INFO - 2018-03-28 17:51:58 --> Router Class Initialized
INFO - 2018-03-28 17:51:58 --> Output Class Initialized
INFO - 2018-03-28 17:51:58 --> Security Class Initialized
DEBUG - 2018-03-28 17:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:51:58 --> Input Class Initialized
INFO - 2018-03-28 17:51:58 --> Language Class Initialized
INFO - 2018-03-28 17:51:58 --> Loader Class Initialized
INFO - 2018-03-28 17:51:58 --> Helper loaded: url_helper
INFO - 2018-03-28 17:51:58 --> Helper loaded: form_helper
INFO - 2018-03-28 17:51:58 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:51:58 --> Controller Class Initialized
INFO - 2018-03-28 17:51:58 --> Model Class Initialized
INFO - 2018-03-28 17:51:58 --> Model Class Initialized
INFO - 2018-03-28 17:51:58 --> Model Class Initialized
INFO - 2018-03-28 17:51:58 --> Model Class Initialized
INFO - 2018-03-28 17:51:58 --> Model Class Initialized
INFO - 2018-03-28 17:51:58 --> Model Class Initialized
INFO - 2018-03-28 17:51:58 --> Model Class Initialized
INFO - 2018-03-28 17:51:58 --> Model Class Initialized
INFO - 2018-03-28 17:51:58 --> Model Class Initialized
INFO - 2018-03-28 17:51:58 --> Model Class Initialized
INFO - 2018-03-28 17:51:58 --> Model Class Initialized
INFO - 2018-03-28 17:51:58 --> Model Class Initialized
INFO - 2018-03-28 17:51:58 --> Model Class Initialized
INFO - 2018-03-28 17:51:58 --> Model Class Initialized
INFO - 2018-03-28 17:51:58 --> Helper loaded: date_helper
INFO - 2018-03-28 17:51:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:51:58 --> Final output sent to browser
DEBUG - 2018-03-28 22:51:58 --> Total execution time: 0.1644
INFO - 2018-03-28 17:52:01 --> Config Class Initialized
INFO - 2018-03-28 17:52:01 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:52:01 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:52:01 --> Utf8 Class Initialized
INFO - 2018-03-28 17:52:01 --> URI Class Initialized
INFO - 2018-03-28 17:52:01 --> Router Class Initialized
INFO - 2018-03-28 17:52:01 --> Output Class Initialized
INFO - 2018-03-28 17:52:01 --> Security Class Initialized
DEBUG - 2018-03-28 17:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:52:01 --> Input Class Initialized
INFO - 2018-03-28 17:52:01 --> Language Class Initialized
INFO - 2018-03-28 17:52:01 --> Loader Class Initialized
INFO - 2018-03-28 17:52:01 --> Helper loaded: url_helper
INFO - 2018-03-28 17:52:01 --> Helper loaded: form_helper
INFO - 2018-03-28 17:52:01 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:52:02 --> Controller Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Helper loaded: date_helper
INFO - 2018-03-28 17:52:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 17:52:02 --> Config Class Initialized
INFO - 2018-03-28 17:52:02 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:52:02 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:52:02 --> Utf8 Class Initialized
INFO - 2018-03-28 17:52:02 --> URI Class Initialized
INFO - 2018-03-28 17:52:02 --> Router Class Initialized
INFO - 2018-03-28 17:52:02 --> Output Class Initialized
INFO - 2018-03-28 17:52:02 --> Security Class Initialized
DEBUG - 2018-03-28 17:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:52:02 --> Input Class Initialized
INFO - 2018-03-28 17:52:02 --> Language Class Initialized
INFO - 2018-03-28 17:52:02 --> Loader Class Initialized
INFO - 2018-03-28 17:52:02 --> Helper loaded: url_helper
INFO - 2018-03-28 17:52:02 --> Helper loaded: form_helper
INFO - 2018-03-28 17:52:02 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:52:02 --> Controller Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Model Class Initialized
INFO - 2018-03-28 17:52:02 --> Helper loaded: date_helper
INFO - 2018-03-28 17:52:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:52:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:52:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:52:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-28 22:52:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:52:02 --> Final output sent to browser
DEBUG - 2018-03-28 22:52:02 --> Total execution time: 0.1427
INFO - 2018-03-28 17:52:06 --> Config Class Initialized
INFO - 2018-03-28 17:52:06 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:52:06 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:52:06 --> Utf8 Class Initialized
INFO - 2018-03-28 17:52:06 --> URI Class Initialized
INFO - 2018-03-28 17:52:06 --> Router Class Initialized
INFO - 2018-03-28 17:52:06 --> Output Class Initialized
INFO - 2018-03-28 17:52:06 --> Security Class Initialized
DEBUG - 2018-03-28 17:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:52:06 --> Input Class Initialized
INFO - 2018-03-28 17:52:06 --> Language Class Initialized
INFO - 2018-03-28 17:52:06 --> Loader Class Initialized
INFO - 2018-03-28 17:52:06 --> Helper loaded: url_helper
INFO - 2018-03-28 17:52:06 --> Helper loaded: form_helper
INFO - 2018-03-28 17:52:06 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:52:06 --> Controller Class Initialized
INFO - 2018-03-28 17:52:06 --> Model Class Initialized
INFO - 2018-03-28 17:52:06 --> Model Class Initialized
INFO - 2018-03-28 17:52:06 --> Model Class Initialized
INFO - 2018-03-28 17:52:06 --> Model Class Initialized
INFO - 2018-03-28 17:52:06 --> Model Class Initialized
INFO - 2018-03-28 17:52:06 --> Model Class Initialized
INFO - 2018-03-28 17:52:06 --> Model Class Initialized
INFO - 2018-03-28 17:52:06 --> Model Class Initialized
INFO - 2018-03-28 17:52:06 --> Model Class Initialized
INFO - 2018-03-28 17:52:06 --> Model Class Initialized
INFO - 2018-03-28 17:52:06 --> Model Class Initialized
INFO - 2018-03-28 17:52:06 --> Model Class Initialized
INFO - 2018-03-28 17:52:06 --> Model Class Initialized
INFO - 2018-03-28 17:52:06 --> Model Class Initialized
INFO - 2018-03-28 17:52:06 --> Helper loaded: date_helper
INFO - 2018-03-28 17:52:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:52:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:52:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:52:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-28 22:52:06 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:52:06 --> Final output sent to browser
DEBUG - 2018-03-28 22:52:06 --> Total execution time: 0.1716
INFO - 2018-03-28 17:52:11 --> Config Class Initialized
INFO - 2018-03-28 17:52:11 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:52:11 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:52:11 --> Utf8 Class Initialized
INFO - 2018-03-28 17:52:11 --> URI Class Initialized
INFO - 2018-03-28 17:52:11 --> Router Class Initialized
INFO - 2018-03-28 17:52:11 --> Output Class Initialized
INFO - 2018-03-28 17:52:11 --> Security Class Initialized
DEBUG - 2018-03-28 17:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:52:11 --> Input Class Initialized
INFO - 2018-03-28 17:52:11 --> Language Class Initialized
INFO - 2018-03-28 17:52:11 --> Loader Class Initialized
INFO - 2018-03-28 17:52:11 --> Helper loaded: url_helper
INFO - 2018-03-28 17:52:11 --> Helper loaded: form_helper
INFO - 2018-03-28 17:52:11 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:52:11 --> Controller Class Initialized
INFO - 2018-03-28 17:52:11 --> Model Class Initialized
INFO - 2018-03-28 17:52:11 --> Model Class Initialized
INFO - 2018-03-28 17:52:11 --> Model Class Initialized
INFO - 2018-03-28 17:52:11 --> Model Class Initialized
INFO - 2018-03-28 17:52:11 --> Model Class Initialized
INFO - 2018-03-28 17:52:11 --> Model Class Initialized
INFO - 2018-03-28 17:52:11 --> Model Class Initialized
INFO - 2018-03-28 17:52:11 --> Model Class Initialized
INFO - 2018-03-28 17:52:11 --> Model Class Initialized
INFO - 2018-03-28 17:52:11 --> Model Class Initialized
INFO - 2018-03-28 17:52:11 --> Model Class Initialized
INFO - 2018-03-28 17:52:11 --> Model Class Initialized
INFO - 2018-03-28 17:52:11 --> Helper loaded: date_helper
INFO - 2018-03-28 17:52:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:52:11 --> Model Class Initialized
INFO - 2018-03-28 22:52:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:52:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:52:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-28 22:52:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:52:11 --> Final output sent to browser
DEBUG - 2018-03-28 22:52:11 --> Total execution time: 0.2432
INFO - 2018-03-28 17:52:34 --> Config Class Initialized
INFO - 2018-03-28 17:52:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:52:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:52:34 --> Utf8 Class Initialized
INFO - 2018-03-28 17:52:34 --> URI Class Initialized
INFO - 2018-03-28 17:52:34 --> Router Class Initialized
INFO - 2018-03-28 17:52:34 --> Output Class Initialized
INFO - 2018-03-28 17:52:34 --> Security Class Initialized
DEBUG - 2018-03-28 17:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:52:34 --> Input Class Initialized
INFO - 2018-03-28 17:52:34 --> Language Class Initialized
INFO - 2018-03-28 17:52:34 --> Loader Class Initialized
INFO - 2018-03-28 17:52:34 --> Helper loaded: url_helper
INFO - 2018-03-28 17:52:34 --> Helper loaded: form_helper
INFO - 2018-03-28 17:52:34 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:52:35 --> Controller Class Initialized
INFO - 2018-03-28 17:52:35 --> Model Class Initialized
INFO - 2018-03-28 17:52:35 --> Model Class Initialized
INFO - 2018-03-28 17:52:35 --> Model Class Initialized
INFO - 2018-03-28 17:52:35 --> Model Class Initialized
INFO - 2018-03-28 17:52:35 --> Model Class Initialized
INFO - 2018-03-28 17:52:35 --> Model Class Initialized
INFO - 2018-03-28 17:52:35 --> Model Class Initialized
INFO - 2018-03-28 17:52:35 --> Model Class Initialized
INFO - 2018-03-28 17:52:35 --> Model Class Initialized
INFO - 2018-03-28 17:52:35 --> Model Class Initialized
INFO - 2018-03-28 17:52:35 --> Model Class Initialized
INFO - 2018-03-28 17:52:35 --> Model Class Initialized
INFO - 2018-03-28 17:52:35 --> Model Class Initialized
INFO - 2018-03-28 17:52:35 --> Model Class Initialized
INFO - 2018-03-28 17:52:35 --> Helper loaded: date_helper
INFO - 2018-03-28 17:52:35 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:52:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:52:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:52:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-28 22:52:35 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:52:35 --> Final output sent to browser
DEBUG - 2018-03-28 22:52:35 --> Total execution time: 0.1633
INFO - 2018-03-28 17:52:36 --> Config Class Initialized
INFO - 2018-03-28 17:52:36 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:52:36 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:52:36 --> Utf8 Class Initialized
INFO - 2018-03-28 17:52:36 --> URI Class Initialized
INFO - 2018-03-28 17:52:36 --> Router Class Initialized
INFO - 2018-03-28 17:52:36 --> Output Class Initialized
INFO - 2018-03-28 17:52:36 --> Security Class Initialized
DEBUG - 2018-03-28 17:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:52:36 --> Input Class Initialized
INFO - 2018-03-28 17:52:36 --> Language Class Initialized
INFO - 2018-03-28 17:52:36 --> Loader Class Initialized
INFO - 2018-03-28 17:52:36 --> Helper loaded: url_helper
INFO - 2018-03-28 17:52:36 --> Helper loaded: form_helper
INFO - 2018-03-28 17:52:36 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:52:36 --> Controller Class Initialized
INFO - 2018-03-28 17:52:36 --> Model Class Initialized
INFO - 2018-03-28 17:52:36 --> Model Class Initialized
INFO - 2018-03-28 17:52:36 --> Model Class Initialized
INFO - 2018-03-28 17:52:36 --> Model Class Initialized
INFO - 2018-03-28 17:52:36 --> Model Class Initialized
INFO - 2018-03-28 17:52:36 --> Model Class Initialized
INFO - 2018-03-28 17:52:36 --> Model Class Initialized
INFO - 2018-03-28 17:52:36 --> Model Class Initialized
INFO - 2018-03-28 17:52:36 --> Model Class Initialized
INFO - 2018-03-28 17:52:36 --> Model Class Initialized
INFO - 2018-03-28 17:52:36 --> Model Class Initialized
INFO - 2018-03-28 17:52:36 --> Model Class Initialized
INFO - 2018-03-28 17:52:36 --> Model Class Initialized
INFO - 2018-03-28 17:52:36 --> Model Class Initialized
INFO - 2018-03-28 17:52:36 --> Helper loaded: date_helper
INFO - 2018-03-28 17:52:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:52:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:52:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:52:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-28 22:52:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:52:36 --> Final output sent to browser
DEBUG - 2018-03-28 22:52:36 --> Total execution time: 0.2485
INFO - 2018-03-28 17:52:43 --> Config Class Initialized
INFO - 2018-03-28 17:52:43 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:52:43 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:52:43 --> Utf8 Class Initialized
INFO - 2018-03-28 17:52:43 --> URI Class Initialized
INFO - 2018-03-28 17:52:43 --> Router Class Initialized
INFO - 2018-03-28 17:52:43 --> Output Class Initialized
INFO - 2018-03-28 17:52:43 --> Security Class Initialized
DEBUG - 2018-03-28 17:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:52:43 --> Input Class Initialized
INFO - 2018-03-28 17:52:43 --> Language Class Initialized
INFO - 2018-03-28 17:52:43 --> Loader Class Initialized
INFO - 2018-03-28 17:52:43 --> Helper loaded: url_helper
INFO - 2018-03-28 17:52:43 --> Helper loaded: form_helper
INFO - 2018-03-28 17:52:43 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:52:43 --> Controller Class Initialized
INFO - 2018-03-28 17:52:43 --> Model Class Initialized
INFO - 2018-03-28 17:52:43 --> Model Class Initialized
INFO - 2018-03-28 17:52:43 --> Helper loaded: date_helper
INFO - 2018-03-28 17:52:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:52:43 --> Final output sent to browser
DEBUG - 2018-03-28 22:52:43 --> Total execution time: 0.1231
INFO - 2018-03-28 17:52:44 --> Config Class Initialized
INFO - 2018-03-28 17:52:44 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:52:44 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:52:44 --> Utf8 Class Initialized
INFO - 2018-03-28 17:52:44 --> URI Class Initialized
INFO - 2018-03-28 17:52:44 --> Router Class Initialized
INFO - 2018-03-28 17:52:44 --> Output Class Initialized
INFO - 2018-03-28 17:52:44 --> Security Class Initialized
DEBUG - 2018-03-28 17:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:52:44 --> Input Class Initialized
INFO - 2018-03-28 17:52:44 --> Language Class Initialized
INFO - 2018-03-28 17:52:44 --> Loader Class Initialized
INFO - 2018-03-28 17:52:44 --> Helper loaded: url_helper
INFO - 2018-03-28 17:52:44 --> Helper loaded: form_helper
INFO - 2018-03-28 17:52:44 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:52:44 --> Controller Class Initialized
INFO - 2018-03-28 17:52:44 --> Model Class Initialized
INFO - 2018-03-28 17:52:44 --> Model Class Initialized
INFO - 2018-03-28 17:52:44 --> Helper loaded: date_helper
INFO - 2018-03-28 17:52:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:52:44 --> Final output sent to browser
DEBUG - 2018-03-28 22:52:44 --> Total execution time: 0.1244
INFO - 2018-03-28 17:52:47 --> Config Class Initialized
INFO - 2018-03-28 17:52:47 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:52:47 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:52:47 --> Utf8 Class Initialized
INFO - 2018-03-28 17:52:47 --> URI Class Initialized
INFO - 2018-03-28 17:52:47 --> Router Class Initialized
INFO - 2018-03-28 17:52:47 --> Output Class Initialized
INFO - 2018-03-28 17:52:47 --> Security Class Initialized
DEBUG - 2018-03-28 17:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:52:47 --> Input Class Initialized
INFO - 2018-03-28 17:52:47 --> Language Class Initialized
INFO - 2018-03-28 17:52:47 --> Loader Class Initialized
INFO - 2018-03-28 17:52:47 --> Helper loaded: url_helper
INFO - 2018-03-28 17:52:47 --> Helper loaded: form_helper
INFO - 2018-03-28 17:52:47 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:52:47 --> Controller Class Initialized
INFO - 2018-03-28 17:52:47 --> Model Class Initialized
INFO - 2018-03-28 17:52:47 --> Model Class Initialized
INFO - 2018-03-28 17:52:47 --> Helper loaded: date_helper
INFO - 2018-03-28 17:52:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:52:47 --> Final output sent to browser
DEBUG - 2018-03-28 22:52:47 --> Total execution time: 0.1039
INFO - 2018-03-28 17:52:51 --> Config Class Initialized
INFO - 2018-03-28 17:52:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:52:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:52:51 --> Utf8 Class Initialized
INFO - 2018-03-28 17:52:51 --> URI Class Initialized
INFO - 2018-03-28 17:52:51 --> Router Class Initialized
INFO - 2018-03-28 17:52:51 --> Output Class Initialized
INFO - 2018-03-28 17:52:51 --> Security Class Initialized
DEBUG - 2018-03-28 17:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:52:51 --> Input Class Initialized
INFO - 2018-03-28 17:52:51 --> Language Class Initialized
INFO - 2018-03-28 17:52:51 --> Loader Class Initialized
INFO - 2018-03-28 17:52:51 --> Helper loaded: url_helper
INFO - 2018-03-28 17:52:51 --> Helper loaded: form_helper
INFO - 2018-03-28 17:52:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:52:51 --> Controller Class Initialized
INFO - 2018-03-28 17:52:51 --> Model Class Initialized
INFO - 2018-03-28 17:52:51 --> Model Class Initialized
INFO - 2018-03-28 17:52:51 --> Model Class Initialized
INFO - 2018-03-28 17:52:51 --> Model Class Initialized
INFO - 2018-03-28 17:52:51 --> Model Class Initialized
INFO - 2018-03-28 17:52:51 --> Model Class Initialized
INFO - 2018-03-28 17:52:51 --> Model Class Initialized
INFO - 2018-03-28 17:52:51 --> Model Class Initialized
INFO - 2018-03-28 17:52:51 --> Model Class Initialized
INFO - 2018-03-28 17:52:51 --> Model Class Initialized
INFO - 2018-03-28 17:52:51 --> Model Class Initialized
INFO - 2018-03-28 17:52:51 --> Model Class Initialized
INFO - 2018-03-28 17:52:51 --> Model Class Initialized
INFO - 2018-03-28 17:52:51 --> Model Class Initialized
INFO - 2018-03-28 17:52:51 --> Helper loaded: date_helper
INFO - 2018-03-28 17:52:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 17:52:52 --> Config Class Initialized
INFO - 2018-03-28 17:52:52 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:52:52 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:52:52 --> Utf8 Class Initialized
INFO - 2018-03-28 17:52:52 --> URI Class Initialized
INFO - 2018-03-28 17:52:52 --> Router Class Initialized
INFO - 2018-03-28 17:52:52 --> Output Class Initialized
INFO - 2018-03-28 17:52:52 --> Security Class Initialized
DEBUG - 2018-03-28 17:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:52:52 --> Input Class Initialized
INFO - 2018-03-28 17:52:52 --> Language Class Initialized
INFO - 2018-03-28 17:52:52 --> Loader Class Initialized
INFO - 2018-03-28 17:52:52 --> Helper loaded: url_helper
INFO - 2018-03-28 17:52:52 --> Helper loaded: form_helper
INFO - 2018-03-28 17:52:52 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:52:52 --> Controller Class Initialized
INFO - 2018-03-28 17:52:52 --> Model Class Initialized
INFO - 2018-03-28 17:52:52 --> Model Class Initialized
INFO - 2018-03-28 17:52:52 --> Model Class Initialized
INFO - 2018-03-28 17:52:52 --> Model Class Initialized
INFO - 2018-03-28 17:52:52 --> Model Class Initialized
INFO - 2018-03-28 17:52:52 --> Model Class Initialized
INFO - 2018-03-28 17:52:52 --> Model Class Initialized
INFO - 2018-03-28 17:52:52 --> Model Class Initialized
INFO - 2018-03-28 17:52:52 --> Model Class Initialized
INFO - 2018-03-28 17:52:52 --> Model Class Initialized
INFO - 2018-03-28 17:52:52 --> Model Class Initialized
INFO - 2018-03-28 17:52:52 --> Model Class Initialized
INFO - 2018-03-28 17:52:52 --> Model Class Initialized
INFO - 2018-03-28 17:52:52 --> Model Class Initialized
INFO - 2018-03-28 17:52:52 --> Helper loaded: date_helper
INFO - 2018-03-28 17:52:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:52:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:52:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:52:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/detail.php
INFO - 2018-03-28 22:52:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:52:52 --> Final output sent to browser
DEBUG - 2018-03-28 22:52:52 --> Total execution time: 0.1859
INFO - 2018-03-28 17:52:57 --> Config Class Initialized
INFO - 2018-03-28 17:52:57 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:52:57 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:52:57 --> Utf8 Class Initialized
INFO - 2018-03-28 17:52:57 --> URI Class Initialized
INFO - 2018-03-28 17:52:57 --> Router Class Initialized
INFO - 2018-03-28 17:52:57 --> Output Class Initialized
INFO - 2018-03-28 17:52:57 --> Security Class Initialized
DEBUG - 2018-03-28 17:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:52:57 --> Input Class Initialized
INFO - 2018-03-28 17:52:57 --> Language Class Initialized
INFO - 2018-03-28 17:52:57 --> Loader Class Initialized
INFO - 2018-03-28 17:52:57 --> Helper loaded: url_helper
INFO - 2018-03-28 17:52:57 --> Helper loaded: form_helper
INFO - 2018-03-28 17:52:57 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:52:57 --> Controller Class Initialized
INFO - 2018-03-28 17:52:57 --> Model Class Initialized
INFO - 2018-03-28 17:52:57 --> Model Class Initialized
INFO - 2018-03-28 17:52:57 --> Model Class Initialized
INFO - 2018-03-28 17:52:57 --> Model Class Initialized
INFO - 2018-03-28 17:52:57 --> Model Class Initialized
INFO - 2018-03-28 17:52:57 --> Model Class Initialized
INFO - 2018-03-28 17:52:57 --> Model Class Initialized
INFO - 2018-03-28 17:52:57 --> Model Class Initialized
INFO - 2018-03-28 17:52:57 --> Model Class Initialized
INFO - 2018-03-28 17:52:57 --> Model Class Initialized
INFO - 2018-03-28 17:52:57 --> Model Class Initialized
INFO - 2018-03-28 17:52:57 --> Model Class Initialized
INFO - 2018-03-28 17:52:57 --> Helper loaded: date_helper
INFO - 2018-03-28 17:52:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:52:57 --> Model Class Initialized
INFO - 2018-03-28 22:52:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:52:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:52:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-28 22:52:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:52:57 --> Final output sent to browser
DEBUG - 2018-03-28 22:52:57 --> Total execution time: 0.2156
INFO - 2018-03-28 17:53:24 --> Config Class Initialized
INFO - 2018-03-28 17:53:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:53:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:53:24 --> Utf8 Class Initialized
INFO - 2018-03-28 17:53:24 --> URI Class Initialized
INFO - 2018-03-28 17:53:24 --> Router Class Initialized
INFO - 2018-03-28 17:53:24 --> Output Class Initialized
INFO - 2018-03-28 17:53:24 --> Security Class Initialized
DEBUG - 2018-03-28 17:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:53:24 --> Input Class Initialized
INFO - 2018-03-28 17:53:24 --> Language Class Initialized
INFO - 2018-03-28 17:53:24 --> Loader Class Initialized
INFO - 2018-03-28 17:53:24 --> Helper loaded: url_helper
INFO - 2018-03-28 17:53:24 --> Helper loaded: form_helper
INFO - 2018-03-28 17:53:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:53:24 --> Controller Class Initialized
INFO - 2018-03-28 17:53:24 --> Model Class Initialized
INFO - 2018-03-28 17:53:24 --> Model Class Initialized
INFO - 2018-03-28 17:53:24 --> Helper loaded: date_helper
INFO - 2018-03-28 17:53:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:53:24 --> Model Class Initialized
INFO - 2018-03-28 22:53:24 --> Model Class Initialized
INFO - 2018-03-28 22:53:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:53:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:53:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-28 22:53:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:53:24 --> Final output sent to browser
DEBUG - 2018-03-28 22:53:24 --> Total execution time: 0.1987
INFO - 2018-03-28 17:53:37 --> Config Class Initialized
INFO - 2018-03-28 17:53:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:53:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:53:37 --> Utf8 Class Initialized
INFO - 2018-03-28 17:53:37 --> URI Class Initialized
INFO - 2018-03-28 17:53:37 --> Router Class Initialized
INFO - 2018-03-28 17:53:37 --> Output Class Initialized
INFO - 2018-03-28 17:53:37 --> Security Class Initialized
DEBUG - 2018-03-28 17:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:53:37 --> Input Class Initialized
INFO - 2018-03-28 17:53:37 --> Language Class Initialized
INFO - 2018-03-28 17:53:37 --> Loader Class Initialized
INFO - 2018-03-28 17:53:37 --> Helper loaded: url_helper
INFO - 2018-03-28 17:53:37 --> Helper loaded: form_helper
INFO - 2018-03-28 17:53:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:53:37 --> Controller Class Initialized
INFO - 2018-03-28 17:53:37 --> Model Class Initialized
INFO - 2018-03-28 17:53:37 --> Model Class Initialized
INFO - 2018-03-28 17:53:37 --> Helper loaded: date_helper
INFO - 2018-03-28 17:53:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:53:37 --> Model Class Initialized
INFO - 2018-03-28 22:53:37 --> Model Class Initialized
INFO - 2018-03-28 22:53:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:53:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:53:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/table.php
INFO - 2018-03-28 22:53:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:53:37 --> Final output sent to browser
DEBUG - 2018-03-28 22:53:37 --> Total execution time: 0.1987
INFO - 2018-03-28 17:53:39 --> Config Class Initialized
INFO - 2018-03-28 17:53:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:53:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:53:39 --> Utf8 Class Initialized
INFO - 2018-03-28 17:53:39 --> URI Class Initialized
INFO - 2018-03-28 17:53:39 --> Router Class Initialized
INFO - 2018-03-28 17:53:39 --> Output Class Initialized
INFO - 2018-03-28 17:53:40 --> Security Class Initialized
DEBUG - 2018-03-28 17:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:53:40 --> Input Class Initialized
INFO - 2018-03-28 17:53:40 --> Language Class Initialized
INFO - 2018-03-28 17:53:40 --> Loader Class Initialized
INFO - 2018-03-28 17:53:40 --> Helper loaded: url_helper
INFO - 2018-03-28 17:53:40 --> Helper loaded: form_helper
INFO - 2018-03-28 17:53:40 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:53:40 --> Controller Class Initialized
INFO - 2018-03-28 17:53:40 --> Model Class Initialized
INFO - 2018-03-28 17:53:40 --> Model Class Initialized
INFO - 2018-03-28 17:53:40 --> Helper loaded: date_helper
INFO - 2018-03-28 17:53:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:53:40 --> Model Class Initialized
INFO - 2018-03-28 22:53:40 --> Model Class Initialized
INFO - 2018-03-28 22:53:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:53:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:53:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/create.php
INFO - 2018-03-28 22:53:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:53:40 --> Final output sent to browser
DEBUG - 2018-03-28 22:53:40 --> Total execution time: 0.1615
INFO - 2018-03-28 17:54:00 --> Config Class Initialized
INFO - 2018-03-28 17:54:00 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:54:00 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:54:00 --> Utf8 Class Initialized
INFO - 2018-03-28 17:54:00 --> URI Class Initialized
INFO - 2018-03-28 17:54:00 --> Router Class Initialized
INFO - 2018-03-28 17:54:00 --> Output Class Initialized
INFO - 2018-03-28 17:54:00 --> Security Class Initialized
DEBUG - 2018-03-28 17:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:54:00 --> Input Class Initialized
INFO - 2018-03-28 17:54:00 --> Language Class Initialized
INFO - 2018-03-28 17:54:00 --> Loader Class Initialized
INFO - 2018-03-28 17:54:00 --> Helper loaded: url_helper
INFO - 2018-03-28 17:54:00 --> Helper loaded: form_helper
INFO - 2018-03-28 17:54:00 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:54:00 --> Controller Class Initialized
INFO - 2018-03-28 17:54:00 --> Model Class Initialized
INFO - 2018-03-28 17:54:00 --> Model Class Initialized
INFO - 2018-03-28 17:54:00 --> Helper loaded: date_helper
INFO - 2018-03-28 17:54:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 17:54:01 --> Config Class Initialized
INFO - 2018-03-28 17:54:01 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:54:01 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:54:01 --> Utf8 Class Initialized
INFO - 2018-03-28 17:54:01 --> URI Class Initialized
INFO - 2018-03-28 17:54:01 --> Router Class Initialized
INFO - 2018-03-28 17:54:01 --> Output Class Initialized
INFO - 2018-03-28 17:54:01 --> Security Class Initialized
DEBUG - 2018-03-28 17:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:54:01 --> Input Class Initialized
INFO - 2018-03-28 17:54:01 --> Language Class Initialized
INFO - 2018-03-28 17:54:01 --> Loader Class Initialized
INFO - 2018-03-28 17:54:01 --> Helper loaded: url_helper
INFO - 2018-03-28 17:54:01 --> Helper loaded: form_helper
INFO - 2018-03-28 17:54:01 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:54:01 --> Controller Class Initialized
INFO - 2018-03-28 17:54:01 --> Model Class Initialized
INFO - 2018-03-28 17:54:01 --> Model Class Initialized
INFO - 2018-03-28 17:54:01 --> Helper loaded: date_helper
INFO - 2018-03-28 17:54:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:54:01 --> Model Class Initialized
INFO - 2018-03-28 22:54:01 --> Model Class Initialized
INFO - 2018-03-28 22:54:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:54:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:54:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/table.php
INFO - 2018-03-28 22:54:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:54:01 --> Final output sent to browser
DEBUG - 2018-03-28 22:54:01 --> Total execution time: 0.1566
INFO - 2018-03-28 17:54:11 --> Config Class Initialized
INFO - 2018-03-28 17:54:11 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:54:11 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:54:11 --> Utf8 Class Initialized
INFO - 2018-03-28 17:54:11 --> URI Class Initialized
INFO - 2018-03-28 17:54:11 --> Router Class Initialized
INFO - 2018-03-28 17:54:11 --> Output Class Initialized
INFO - 2018-03-28 17:54:11 --> Security Class Initialized
DEBUG - 2018-03-28 17:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:54:11 --> Input Class Initialized
INFO - 2018-03-28 17:54:11 --> Language Class Initialized
INFO - 2018-03-28 17:54:11 --> Loader Class Initialized
INFO - 2018-03-28 17:54:11 --> Helper loaded: url_helper
INFO - 2018-03-28 17:54:11 --> Helper loaded: form_helper
INFO - 2018-03-28 17:54:11 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:54:11 --> Controller Class Initialized
INFO - 2018-03-28 17:54:11 --> Model Class Initialized
INFO - 2018-03-28 17:54:11 --> Model Class Initialized
INFO - 2018-03-28 17:54:11 --> Helper loaded: date_helper
INFO - 2018-03-28 17:54:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:54:11 --> Model Class Initialized
INFO - 2018-03-28 22:54:11 --> Model Class Initialized
INFO - 2018-03-28 22:54:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:54:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:54:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/user/table.php
INFO - 2018-03-28 22:54:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:54:11 --> Final output sent to browser
DEBUG - 2018-03-28 22:54:11 --> Total execution time: 0.2103
INFO - 2018-03-28 17:54:17 --> Config Class Initialized
INFO - 2018-03-28 17:54:17 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:54:17 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:54:17 --> Utf8 Class Initialized
INFO - 2018-03-28 17:54:17 --> URI Class Initialized
INFO - 2018-03-28 17:54:17 --> Router Class Initialized
INFO - 2018-03-28 17:54:17 --> Output Class Initialized
INFO - 2018-03-28 17:54:17 --> Security Class Initialized
DEBUG - 2018-03-28 17:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:54:17 --> Input Class Initialized
INFO - 2018-03-28 17:54:17 --> Language Class Initialized
INFO - 2018-03-28 17:54:17 --> Loader Class Initialized
INFO - 2018-03-28 17:54:17 --> Helper loaded: url_helper
INFO - 2018-03-28 17:54:17 --> Helper loaded: form_helper
INFO - 2018-03-28 17:54:17 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:54:17 --> Controller Class Initialized
INFO - 2018-03-28 17:54:17 --> Model Class Initialized
INFO - 2018-03-28 17:54:17 --> Model Class Initialized
INFO - 2018-03-28 17:54:17 --> Helper loaded: date_helper
INFO - 2018-03-28 17:54:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:54:17 --> Model Class Initialized
INFO - 2018-03-28 22:54:17 --> Model Class Initialized
INFO - 2018-03-28 22:54:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:54:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:54:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/table.php
INFO - 2018-03-28 22:54:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:54:17 --> Final output sent to browser
DEBUG - 2018-03-28 22:54:17 --> Total execution time: 0.1301
INFO - 2018-03-28 17:54:21 --> Config Class Initialized
INFO - 2018-03-28 17:54:21 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:54:21 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:54:21 --> Utf8 Class Initialized
INFO - 2018-03-28 17:54:21 --> URI Class Initialized
INFO - 2018-03-28 17:54:21 --> Router Class Initialized
INFO - 2018-03-28 17:54:21 --> Output Class Initialized
INFO - 2018-03-28 17:54:21 --> Security Class Initialized
DEBUG - 2018-03-28 17:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:54:21 --> Input Class Initialized
INFO - 2018-03-28 17:54:21 --> Language Class Initialized
INFO - 2018-03-28 17:54:21 --> Loader Class Initialized
INFO - 2018-03-28 17:54:21 --> Helper loaded: url_helper
INFO - 2018-03-28 17:54:21 --> Helper loaded: form_helper
INFO - 2018-03-28 17:54:21 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:54:21 --> Controller Class Initialized
INFO - 2018-03-28 17:54:21 --> Model Class Initialized
INFO - 2018-03-28 17:54:21 --> Model Class Initialized
INFO - 2018-03-28 17:54:21 --> Helper loaded: date_helper
INFO - 2018-03-28 17:54:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:54:21 --> Model Class Initialized
INFO - 2018-03-28 22:54:21 --> Model Class Initialized
INFO - 2018-03-28 22:54:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:54:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:54:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/user/table.php
INFO - 2018-03-28 22:54:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:54:21 --> Final output sent to browser
DEBUG - 2018-03-28 22:54:21 --> Total execution time: 0.2109
INFO - 2018-03-28 17:54:24 --> Config Class Initialized
INFO - 2018-03-28 17:54:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:54:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:54:24 --> Utf8 Class Initialized
INFO - 2018-03-28 17:54:24 --> URI Class Initialized
INFO - 2018-03-28 17:54:24 --> Router Class Initialized
INFO - 2018-03-28 17:54:24 --> Output Class Initialized
INFO - 2018-03-28 17:54:24 --> Security Class Initialized
DEBUG - 2018-03-28 17:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:54:24 --> Input Class Initialized
INFO - 2018-03-28 17:54:24 --> Language Class Initialized
INFO - 2018-03-28 17:54:24 --> Loader Class Initialized
INFO - 2018-03-28 17:54:24 --> Helper loaded: url_helper
INFO - 2018-03-28 17:54:24 --> Helper loaded: form_helper
INFO - 2018-03-28 17:54:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:54:24 --> Controller Class Initialized
INFO - 2018-03-28 17:54:24 --> Model Class Initialized
INFO - 2018-03-28 17:54:24 --> Model Class Initialized
INFO - 2018-03-28 17:54:24 --> Helper loaded: date_helper
INFO - 2018-03-28 17:54:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:54:24 --> Model Class Initialized
INFO - 2018-03-28 22:54:24 --> Model Class Initialized
INFO - 2018-03-28 22:54:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:54:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:54:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/user/create.php
INFO - 2018-03-28 22:54:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:54:24 --> Final output sent to browser
DEBUG - 2018-03-28 22:54:24 --> Total execution time: 0.2152
INFO - 2018-03-28 17:54:41 --> Config Class Initialized
INFO - 2018-03-28 17:54:41 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:54:41 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:54:41 --> Utf8 Class Initialized
INFO - 2018-03-28 17:54:41 --> URI Class Initialized
INFO - 2018-03-28 17:54:41 --> Router Class Initialized
INFO - 2018-03-28 17:54:41 --> Output Class Initialized
INFO - 2018-03-28 17:54:41 --> Security Class Initialized
DEBUG - 2018-03-28 17:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:54:41 --> Input Class Initialized
INFO - 2018-03-28 17:54:41 --> Language Class Initialized
INFO - 2018-03-28 17:54:41 --> Loader Class Initialized
INFO - 2018-03-28 17:54:41 --> Helper loaded: url_helper
INFO - 2018-03-28 17:54:41 --> Helper loaded: form_helper
INFO - 2018-03-28 17:54:41 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:54:41 --> Controller Class Initialized
INFO - 2018-03-28 17:54:41 --> Model Class Initialized
INFO - 2018-03-28 17:54:41 --> Model Class Initialized
INFO - 2018-03-28 17:54:41 --> Helper loaded: date_helper
INFO - 2018-03-28 17:54:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 17:54:41 --> Config Class Initialized
INFO - 2018-03-28 17:54:41 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:54:41 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:54:41 --> Utf8 Class Initialized
INFO - 2018-03-28 17:54:41 --> URI Class Initialized
INFO - 2018-03-28 17:54:41 --> Router Class Initialized
INFO - 2018-03-28 17:54:41 --> Output Class Initialized
INFO - 2018-03-28 17:54:41 --> Security Class Initialized
DEBUG - 2018-03-28 17:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:54:41 --> Input Class Initialized
INFO - 2018-03-28 17:54:41 --> Language Class Initialized
INFO - 2018-03-28 17:54:41 --> Loader Class Initialized
INFO - 2018-03-28 17:54:41 --> Helper loaded: url_helper
INFO - 2018-03-28 17:54:41 --> Helper loaded: form_helper
INFO - 2018-03-28 17:54:41 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:54:41 --> Controller Class Initialized
INFO - 2018-03-28 17:54:41 --> Model Class Initialized
INFO - 2018-03-28 17:54:41 --> Model Class Initialized
INFO - 2018-03-28 17:54:41 --> Helper loaded: date_helper
INFO - 2018-03-28 17:54:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:54:41 --> Model Class Initialized
INFO - 2018-03-28 22:54:41 --> Model Class Initialized
INFO - 2018-03-28 22:54:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:54:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:54:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/user/table.php
INFO - 2018-03-28 22:54:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:54:41 --> Final output sent to browser
DEBUG - 2018-03-28 22:54:41 --> Total execution time: 0.1414
INFO - 2018-03-28 17:54:52 --> Config Class Initialized
INFO - 2018-03-28 17:54:52 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:54:52 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:54:52 --> Utf8 Class Initialized
INFO - 2018-03-28 17:54:52 --> URI Class Initialized
INFO - 2018-03-28 17:54:52 --> Router Class Initialized
INFO - 2018-03-28 17:54:52 --> Output Class Initialized
INFO - 2018-03-28 17:54:52 --> Security Class Initialized
DEBUG - 2018-03-28 17:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:54:52 --> Input Class Initialized
INFO - 2018-03-28 17:54:52 --> Language Class Initialized
INFO - 2018-03-28 17:54:52 --> Loader Class Initialized
INFO - 2018-03-28 17:54:52 --> Helper loaded: url_helper
INFO - 2018-03-28 17:54:52 --> Helper loaded: form_helper
INFO - 2018-03-28 17:54:52 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:54:52 --> Controller Class Initialized
INFO - 2018-03-28 17:54:52 --> Model Class Initialized
INFO - 2018-03-28 17:54:52 --> Model Class Initialized
INFO - 2018-03-28 17:54:52 --> Helper loaded: date_helper
INFO - 2018-03-28 22:54:52 --> Model Class Initialized
INFO - 2018-03-28 22:54:52 --> Model Class Initialized
INFO - 2018-03-28 22:54:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:54:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:54:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/group/table.php
INFO - 2018-03-28 22:54:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:54:52 --> Final output sent to browser
DEBUG - 2018-03-28 22:54:52 --> Total execution time: 0.3696
INFO - 2018-03-28 17:55:12 --> Config Class Initialized
INFO - 2018-03-28 17:55:12 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:55:12 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:55:12 --> Utf8 Class Initialized
INFO - 2018-03-28 17:55:12 --> URI Class Initialized
INFO - 2018-03-28 17:55:12 --> Router Class Initialized
INFO - 2018-03-28 17:55:12 --> Output Class Initialized
INFO - 2018-03-28 17:55:12 --> Security Class Initialized
DEBUG - 2018-03-28 17:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:55:12 --> Input Class Initialized
INFO - 2018-03-28 17:55:12 --> Language Class Initialized
INFO - 2018-03-28 17:55:12 --> Loader Class Initialized
INFO - 2018-03-28 17:55:12 --> Helper loaded: url_helper
INFO - 2018-03-28 17:55:12 --> Helper loaded: form_helper
INFO - 2018-03-28 17:55:12 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:55:12 --> Controller Class Initialized
INFO - 2018-03-28 17:55:12 --> Model Class Initialized
INFO - 2018-03-28 17:55:12 --> Model Class Initialized
INFO - 2018-03-28 17:55:12 --> Helper loaded: date_helper
INFO - 2018-03-28 22:55:12 --> Model Class Initialized
INFO - 2018-03-28 22:55:12 --> Model Class Initialized
INFO - 2018-03-28 22:55:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:55:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:55:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/group/create.php
INFO - 2018-03-28 22:55:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:55:12 --> Final output sent to browser
DEBUG - 2018-03-28 22:55:12 --> Total execution time: 0.2102
INFO - 2018-03-28 17:55:15 --> Config Class Initialized
INFO - 2018-03-28 17:55:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:55:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:55:15 --> Utf8 Class Initialized
INFO - 2018-03-28 17:55:15 --> URI Class Initialized
INFO - 2018-03-28 17:55:15 --> Router Class Initialized
INFO - 2018-03-28 17:55:15 --> Output Class Initialized
INFO - 2018-03-28 17:55:15 --> Security Class Initialized
DEBUG - 2018-03-28 17:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:55:15 --> Input Class Initialized
INFO - 2018-03-28 17:55:15 --> Language Class Initialized
INFO - 2018-03-28 17:55:15 --> Loader Class Initialized
INFO - 2018-03-28 17:55:15 --> Helper loaded: url_helper
INFO - 2018-03-28 17:55:15 --> Helper loaded: form_helper
INFO - 2018-03-28 17:55:15 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:55:15 --> Controller Class Initialized
INFO - 2018-03-28 17:55:15 --> Model Class Initialized
INFO - 2018-03-28 17:55:15 --> Model Class Initialized
INFO - 2018-03-28 17:55:15 --> Helper loaded: date_helper
INFO - 2018-03-28 22:55:15 --> Model Class Initialized
INFO - 2018-03-28 22:55:15 --> Model Class Initialized
INFO - 2018-03-28 22:55:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:55:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:55:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/group/table.php
INFO - 2018-03-28 22:55:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:55:15 --> Final output sent to browser
DEBUG - 2018-03-28 22:55:15 --> Total execution time: 0.1263
INFO - 2018-03-28 17:55:19 --> Config Class Initialized
INFO - 2018-03-28 17:55:19 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:55:19 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:55:19 --> Utf8 Class Initialized
INFO - 2018-03-28 17:55:19 --> URI Class Initialized
INFO - 2018-03-28 17:55:19 --> Router Class Initialized
INFO - 2018-03-28 17:55:19 --> Output Class Initialized
INFO - 2018-03-28 17:55:19 --> Security Class Initialized
DEBUG - 2018-03-28 17:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:55:19 --> Input Class Initialized
INFO - 2018-03-28 17:55:19 --> Language Class Initialized
INFO - 2018-03-28 17:55:19 --> Loader Class Initialized
INFO - 2018-03-28 17:55:19 --> Helper loaded: url_helper
INFO - 2018-03-28 17:55:19 --> Helper loaded: form_helper
INFO - 2018-03-28 17:55:19 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:55:19 --> Controller Class Initialized
INFO - 2018-03-28 17:55:19 --> Model Class Initialized
INFO - 2018-03-28 17:55:19 --> Model Class Initialized
INFO - 2018-03-28 17:55:19 --> Model Class Initialized
INFO - 2018-03-28 17:55:19 --> Model Class Initialized
INFO - 2018-03-28 17:55:19 --> Model Class Initialized
INFO - 2018-03-28 17:55:19 --> Helper loaded: date_helper
INFO - 2018-03-28 22:55:19 --> Model Class Initialized
INFO - 2018-03-28 22:55:19 --> Model Class Initialized
INFO - 2018-03-28 22:55:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:55:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:55:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/group_akses/table.php
INFO - 2018-03-28 22:55:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:55:19 --> Final output sent to browser
DEBUG - 2018-03-28 22:55:19 --> Total execution time: 0.1837
INFO - 2018-03-28 17:55:23 --> Config Class Initialized
INFO - 2018-03-28 17:55:23 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:55:23 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:55:23 --> Utf8 Class Initialized
INFO - 2018-03-28 17:55:23 --> URI Class Initialized
INFO - 2018-03-28 17:55:23 --> Router Class Initialized
INFO - 2018-03-28 17:55:23 --> Output Class Initialized
INFO - 2018-03-28 17:55:23 --> Security Class Initialized
DEBUG - 2018-03-28 17:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:55:23 --> Input Class Initialized
INFO - 2018-03-28 17:55:23 --> Language Class Initialized
INFO - 2018-03-28 17:55:23 --> Loader Class Initialized
INFO - 2018-03-28 17:55:23 --> Helper loaded: url_helper
INFO - 2018-03-28 17:55:23 --> Helper loaded: form_helper
INFO - 2018-03-28 17:55:23 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:55:23 --> Controller Class Initialized
INFO - 2018-03-28 17:55:23 --> Model Class Initialized
INFO - 2018-03-28 17:55:23 --> Model Class Initialized
INFO - 2018-03-28 17:55:23 --> Model Class Initialized
INFO - 2018-03-28 17:55:23 --> Model Class Initialized
INFO - 2018-03-28 17:55:23 --> Model Class Initialized
INFO - 2018-03-28 17:55:23 --> Helper loaded: date_helper
INFO - 2018-03-28 22:55:23 --> Model Class Initialized
INFO - 2018-03-28 22:55:23 --> Model Class Initialized
INFO - 2018-03-28 22:55:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:55:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:55:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/group_akses/create.php
INFO - 2018-03-28 22:55:23 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:55:23 --> Final output sent to browser
DEBUG - 2018-03-28 22:55:23 --> Total execution time: 0.0999
INFO - 2018-03-28 17:55:33 --> Config Class Initialized
INFO - 2018-03-28 17:55:33 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:55:33 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:55:33 --> Utf8 Class Initialized
INFO - 2018-03-28 17:55:33 --> URI Class Initialized
INFO - 2018-03-28 17:55:33 --> Router Class Initialized
INFO - 2018-03-28 17:55:33 --> Output Class Initialized
INFO - 2018-03-28 17:55:33 --> Security Class Initialized
DEBUG - 2018-03-28 17:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:55:33 --> Input Class Initialized
INFO - 2018-03-28 17:55:33 --> Language Class Initialized
INFO - 2018-03-28 17:55:33 --> Loader Class Initialized
INFO - 2018-03-28 17:55:33 --> Helper loaded: url_helper
INFO - 2018-03-28 17:55:33 --> Helper loaded: form_helper
INFO - 2018-03-28 17:55:33 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:55:33 --> Controller Class Initialized
INFO - 2018-03-28 17:55:33 --> Model Class Initialized
INFO - 2018-03-28 17:55:33 --> Model Class Initialized
INFO - 2018-03-28 17:55:33 --> Model Class Initialized
INFO - 2018-03-28 17:55:33 --> Model Class Initialized
INFO - 2018-03-28 17:55:33 --> Model Class Initialized
INFO - 2018-03-28 17:55:33 --> Helper loaded: date_helper
INFO - 2018-03-28 17:55:33 --> Config Class Initialized
INFO - 2018-03-28 17:55:33 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:55:33 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:55:33 --> Utf8 Class Initialized
INFO - 2018-03-28 17:55:33 --> URI Class Initialized
INFO - 2018-03-28 17:55:33 --> Router Class Initialized
INFO - 2018-03-28 17:55:33 --> Output Class Initialized
INFO - 2018-03-28 17:55:33 --> Security Class Initialized
DEBUG - 2018-03-28 17:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:55:33 --> Input Class Initialized
INFO - 2018-03-28 17:55:33 --> Language Class Initialized
INFO - 2018-03-28 17:55:33 --> Loader Class Initialized
INFO - 2018-03-28 17:55:33 --> Helper loaded: url_helper
INFO - 2018-03-28 17:55:33 --> Helper loaded: form_helper
INFO - 2018-03-28 17:55:33 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:55:34 --> Controller Class Initialized
INFO - 2018-03-28 17:55:34 --> Model Class Initialized
INFO - 2018-03-28 17:55:34 --> Model Class Initialized
INFO - 2018-03-28 17:55:34 --> Model Class Initialized
INFO - 2018-03-28 17:55:34 --> Model Class Initialized
INFO - 2018-03-28 17:55:34 --> Model Class Initialized
INFO - 2018-03-28 17:55:34 --> Helper loaded: date_helper
INFO - 2018-03-28 22:55:34 --> Model Class Initialized
INFO - 2018-03-28 22:55:34 --> Model Class Initialized
INFO - 2018-03-28 22:55:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:55:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:55:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/group_akses/table.php
INFO - 2018-03-28 22:55:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:55:34 --> Final output sent to browser
DEBUG - 2018-03-28 22:55:34 --> Total execution time: 0.1574
INFO - 2018-03-28 17:55:37 --> Config Class Initialized
INFO - 2018-03-28 17:55:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:55:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:55:37 --> Utf8 Class Initialized
INFO - 2018-03-28 17:55:37 --> URI Class Initialized
INFO - 2018-03-28 17:55:37 --> Router Class Initialized
INFO - 2018-03-28 17:55:37 --> Output Class Initialized
INFO - 2018-03-28 17:55:37 --> Security Class Initialized
DEBUG - 2018-03-28 17:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:55:37 --> Input Class Initialized
INFO - 2018-03-28 17:55:37 --> Language Class Initialized
INFO - 2018-03-28 17:55:37 --> Loader Class Initialized
INFO - 2018-03-28 17:55:37 --> Helper loaded: url_helper
INFO - 2018-03-28 17:55:37 --> Helper loaded: form_helper
INFO - 2018-03-28 17:55:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:55:37 --> Controller Class Initialized
INFO - 2018-03-28 17:55:37 --> Model Class Initialized
INFO - 2018-03-28 17:55:37 --> Model Class Initialized
INFO - 2018-03-28 17:55:37 --> Model Class Initialized
INFO - 2018-03-28 17:55:37 --> Model Class Initialized
INFO - 2018-03-28 17:55:37 --> Model Class Initialized
INFO - 2018-03-28 17:55:37 --> Helper loaded: date_helper
INFO - 2018-03-28 22:55:37 --> Model Class Initialized
INFO - 2018-03-28 22:55:37 --> Model Class Initialized
INFO - 2018-03-28 22:55:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:55:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:55:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-28 22:55:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:55:38 --> Final output sent to browser
DEBUG - 2018-03-28 22:55:38 --> Total execution time: 0.1770
INFO - 2018-03-28 17:55:42 --> Config Class Initialized
INFO - 2018-03-28 17:55:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:55:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:55:42 --> Utf8 Class Initialized
INFO - 2018-03-28 17:55:42 --> URI Class Initialized
INFO - 2018-03-28 17:55:42 --> Router Class Initialized
INFO - 2018-03-28 17:55:42 --> Output Class Initialized
INFO - 2018-03-28 17:55:42 --> Security Class Initialized
DEBUG - 2018-03-28 17:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:55:42 --> Input Class Initialized
INFO - 2018-03-28 17:55:42 --> Language Class Initialized
INFO - 2018-03-28 17:55:42 --> Loader Class Initialized
INFO - 2018-03-28 17:55:42 --> Helper loaded: url_helper
INFO - 2018-03-28 17:55:42 --> Helper loaded: form_helper
INFO - 2018-03-28 17:55:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:55:42 --> Controller Class Initialized
INFO - 2018-03-28 17:55:42 --> Model Class Initialized
INFO - 2018-03-28 17:55:42 --> Model Class Initialized
INFO - 2018-03-28 17:55:42 --> Model Class Initialized
INFO - 2018-03-28 17:55:42 --> Model Class Initialized
INFO - 2018-03-28 17:55:42 --> Model Class Initialized
INFO - 2018-03-28 17:55:42 --> Helper loaded: date_helper
INFO - 2018-03-28 22:55:42 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/list.php
INFO - 2018-03-28 22:55:42 --> Final output sent to browser
DEBUG - 2018-03-28 22:55:42 --> Total execution time: 0.1252
INFO - 2018-03-28 17:55:55 --> Config Class Initialized
INFO - 2018-03-28 17:55:55 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:55:55 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:55:55 --> Utf8 Class Initialized
INFO - 2018-03-28 17:55:55 --> URI Class Initialized
INFO - 2018-03-28 17:55:55 --> Router Class Initialized
INFO - 2018-03-28 17:55:55 --> Output Class Initialized
INFO - 2018-03-28 17:55:55 --> Security Class Initialized
DEBUG - 2018-03-28 17:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:55:55 --> Input Class Initialized
INFO - 2018-03-28 17:55:55 --> Language Class Initialized
INFO - 2018-03-28 17:55:55 --> Loader Class Initialized
INFO - 2018-03-28 17:55:55 --> Helper loaded: url_helper
INFO - 2018-03-28 17:55:55 --> Helper loaded: form_helper
INFO - 2018-03-28 17:55:55 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:55:55 --> Controller Class Initialized
INFO - 2018-03-28 17:55:55 --> Model Class Initialized
INFO - 2018-03-28 17:55:55 --> Model Class Initialized
INFO - 2018-03-28 17:55:55 --> Model Class Initialized
INFO - 2018-03-28 17:55:55 --> Model Class Initialized
INFO - 2018-03-28 17:55:55 --> Model Class Initialized
INFO - 2018-03-28 17:55:55 --> Helper loaded: date_helper
INFO - 2018-03-28 22:55:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/list.php
INFO - 2018-03-28 22:55:55 --> Final output sent to browser
DEBUG - 2018-03-28 22:55:55 --> Total execution time: 0.0932
INFO - 2018-03-28 17:56:08 --> Config Class Initialized
INFO - 2018-03-28 17:56:08 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:56:08 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:56:08 --> Utf8 Class Initialized
INFO - 2018-03-28 17:56:08 --> URI Class Initialized
INFO - 2018-03-28 17:56:08 --> Router Class Initialized
INFO - 2018-03-28 17:56:08 --> Output Class Initialized
INFO - 2018-03-28 17:56:08 --> Security Class Initialized
DEBUG - 2018-03-28 17:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:56:08 --> Input Class Initialized
INFO - 2018-03-28 17:56:08 --> Language Class Initialized
INFO - 2018-03-28 17:56:08 --> Loader Class Initialized
INFO - 2018-03-28 17:56:08 --> Helper loaded: url_helper
INFO - 2018-03-28 17:56:08 --> Helper loaded: form_helper
INFO - 2018-03-28 17:56:08 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:56:08 --> Controller Class Initialized
INFO - 2018-03-28 17:56:08 --> Model Class Initialized
INFO - 2018-03-28 17:56:08 --> Model Class Initialized
INFO - 2018-03-28 17:56:08 --> Model Class Initialized
INFO - 2018-03-28 17:56:08 --> Model Class Initialized
INFO - 2018-03-28 17:56:08 --> Model Class Initialized
INFO - 2018-03-28 17:56:08 --> Helper loaded: date_helper
INFO - 2018-03-28 22:56:08 --> Model Class Initialized
INFO - 2018-03-28 22:56:08 --> Model Class Initialized
INFO - 2018-03-28 22:56:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:56:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:56:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/create.php
INFO - 2018-03-28 22:56:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:56:08 --> Final output sent to browser
DEBUG - 2018-03-28 22:56:08 --> Total execution time: 0.1268
INFO - 2018-03-28 17:56:26 --> Config Class Initialized
INFO - 2018-03-28 17:56:26 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:56:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:56:26 --> Utf8 Class Initialized
INFO - 2018-03-28 17:56:26 --> URI Class Initialized
INFO - 2018-03-28 17:56:26 --> Router Class Initialized
INFO - 2018-03-28 17:56:26 --> Output Class Initialized
INFO - 2018-03-28 17:56:26 --> Security Class Initialized
DEBUG - 2018-03-28 17:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:56:26 --> Input Class Initialized
INFO - 2018-03-28 17:56:26 --> Language Class Initialized
INFO - 2018-03-28 17:56:26 --> Loader Class Initialized
INFO - 2018-03-28 17:56:26 --> Helper loaded: url_helper
INFO - 2018-03-28 17:56:26 --> Helper loaded: form_helper
INFO - 2018-03-28 17:56:26 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:56:26 --> Controller Class Initialized
INFO - 2018-03-28 17:56:26 --> Model Class Initialized
INFO - 2018-03-28 17:56:26 --> Model Class Initialized
INFO - 2018-03-28 17:56:26 --> Model Class Initialized
INFO - 2018-03-28 17:56:26 --> Model Class Initialized
INFO - 2018-03-28 17:56:26 --> Model Class Initialized
INFO - 2018-03-28 17:56:26 --> Helper loaded: date_helper
INFO - 2018-03-28 22:56:26 --> Model Class Initialized
INFO - 2018-03-28 22:56:26 --> Model Class Initialized
INFO - 2018-03-28 22:56:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:56:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:56:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-28 22:56:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:56:27 --> Final output sent to browser
DEBUG - 2018-03-28 22:56:27 --> Total execution time: 0.1332
INFO - 2018-03-28 17:56:29 --> Config Class Initialized
INFO - 2018-03-28 17:56:29 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:56:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:56:29 --> Utf8 Class Initialized
INFO - 2018-03-28 17:56:29 --> URI Class Initialized
INFO - 2018-03-28 17:56:29 --> Router Class Initialized
INFO - 2018-03-28 17:56:29 --> Output Class Initialized
INFO - 2018-03-28 17:56:29 --> Security Class Initialized
DEBUG - 2018-03-28 17:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:56:29 --> Input Class Initialized
INFO - 2018-03-28 17:56:29 --> Language Class Initialized
INFO - 2018-03-28 17:56:29 --> Loader Class Initialized
INFO - 2018-03-28 17:56:29 --> Helper loaded: url_helper
INFO - 2018-03-28 17:56:29 --> Helper loaded: form_helper
INFO - 2018-03-28 17:56:29 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:56:29 --> Controller Class Initialized
INFO - 2018-03-28 17:56:29 --> Model Class Initialized
INFO - 2018-03-28 17:56:29 --> Model Class Initialized
INFO - 2018-03-28 17:56:29 --> Model Class Initialized
INFO - 2018-03-28 17:56:29 --> Model Class Initialized
INFO - 2018-03-28 17:56:29 --> Model Class Initialized
INFO - 2018-03-28 17:56:29 --> Helper loaded: date_helper
INFO - 2018-03-28 22:56:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/list.php
INFO - 2018-03-28 22:56:29 --> Final output sent to browser
DEBUG - 2018-03-28 22:56:29 --> Total execution time: 0.1026
INFO - 2018-03-28 17:56:42 --> Config Class Initialized
INFO - 2018-03-28 17:56:42 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:56:42 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:56:42 --> Utf8 Class Initialized
INFO - 2018-03-28 17:56:42 --> URI Class Initialized
INFO - 2018-03-28 17:56:42 --> Router Class Initialized
INFO - 2018-03-28 17:56:42 --> Output Class Initialized
INFO - 2018-03-28 17:56:42 --> Security Class Initialized
DEBUG - 2018-03-28 17:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:56:42 --> Input Class Initialized
INFO - 2018-03-28 17:56:42 --> Language Class Initialized
INFO - 2018-03-28 17:56:42 --> Loader Class Initialized
INFO - 2018-03-28 17:56:42 --> Helper loaded: url_helper
INFO - 2018-03-28 17:56:42 --> Helper loaded: form_helper
INFO - 2018-03-28 17:56:42 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:56:43 --> Controller Class Initialized
INFO - 2018-03-28 17:56:43 --> Model Class Initialized
INFO - 2018-03-28 17:56:43 --> Model Class Initialized
INFO - 2018-03-28 17:56:43 --> Model Class Initialized
INFO - 2018-03-28 17:56:43 --> Helper loaded: date_helper
INFO - 2018-03-28 17:56:43 --> Config Class Initialized
INFO - 2018-03-28 17:56:43 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:56:43 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:56:43 --> Utf8 Class Initialized
INFO - 2018-03-28 17:56:43 --> URI Class Initialized
INFO - 2018-03-28 17:56:43 --> Router Class Initialized
INFO - 2018-03-28 17:56:43 --> Output Class Initialized
INFO - 2018-03-28 17:56:43 --> Security Class Initialized
DEBUG - 2018-03-28 17:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:56:43 --> Input Class Initialized
INFO - 2018-03-28 17:56:43 --> Language Class Initialized
INFO - 2018-03-28 17:56:43 --> Loader Class Initialized
INFO - 2018-03-28 17:56:43 --> Helper loaded: url_helper
INFO - 2018-03-28 17:56:43 --> Helper loaded: form_helper
INFO - 2018-03-28 17:56:43 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:56:43 --> Controller Class Initialized
INFO - 2018-03-28 17:56:43 --> Model Class Initialized
INFO - 2018-03-28 17:56:43 --> Model Class Initialized
INFO - 2018-03-28 17:56:43 --> Model Class Initialized
INFO - 2018-03-28 17:56:43 --> Helper loaded: date_helper
INFO - 2018-03-28 22:56:43 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-28 22:56:43 --> Final output sent to browser
DEBUG - 2018-03-28 22:56:43 --> Total execution time: 0.1493
INFO - 2018-03-28 17:56:51 --> Config Class Initialized
INFO - 2018-03-28 17:56:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:56:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:56:51 --> Utf8 Class Initialized
INFO - 2018-03-28 17:56:51 --> URI Class Initialized
INFO - 2018-03-28 17:56:51 --> Router Class Initialized
INFO - 2018-03-28 17:56:51 --> Output Class Initialized
INFO - 2018-03-28 17:56:51 --> Security Class Initialized
DEBUG - 2018-03-28 17:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:56:51 --> Input Class Initialized
INFO - 2018-03-28 17:56:51 --> Language Class Initialized
INFO - 2018-03-28 17:56:51 --> Loader Class Initialized
INFO - 2018-03-28 17:56:51 --> Helper loaded: url_helper
INFO - 2018-03-28 17:56:51 --> Helper loaded: form_helper
INFO - 2018-03-28 17:56:51 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:56:51 --> Controller Class Initialized
INFO - 2018-03-28 17:56:51 --> Model Class Initialized
INFO - 2018-03-28 17:56:51 --> Model Class Initialized
INFO - 2018-03-28 17:56:51 --> Model Class Initialized
INFO - 2018-03-28 17:56:51 --> Helper loaded: date_helper
INFO - 2018-03-28 17:56:51 --> Config Class Initialized
INFO - 2018-03-28 17:56:51 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:56:51 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:56:51 --> Utf8 Class Initialized
INFO - 2018-03-28 17:56:51 --> URI Class Initialized
INFO - 2018-03-28 17:56:51 --> Router Class Initialized
INFO - 2018-03-28 17:56:51 --> Output Class Initialized
INFO - 2018-03-28 17:56:51 --> Security Class Initialized
DEBUG - 2018-03-28 17:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:56:51 --> Input Class Initialized
INFO - 2018-03-28 17:56:51 --> Language Class Initialized
INFO - 2018-03-28 17:56:52 --> Loader Class Initialized
INFO - 2018-03-28 17:56:52 --> Helper loaded: url_helper
INFO - 2018-03-28 17:56:52 --> Helper loaded: form_helper
INFO - 2018-03-28 17:56:52 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:56:52 --> Controller Class Initialized
INFO - 2018-03-28 17:56:52 --> Model Class Initialized
INFO - 2018-03-28 17:56:52 --> Model Class Initialized
INFO - 2018-03-28 17:56:52 --> Model Class Initialized
INFO - 2018-03-28 17:56:52 --> Model Class Initialized
INFO - 2018-03-28 17:56:52 --> Model Class Initialized
INFO - 2018-03-28 17:56:52 --> Helper loaded: date_helper
INFO - 2018-03-28 22:56:52 --> Model Class Initialized
INFO - 2018-03-28 22:56:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:56:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:56:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-28 22:56:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:56:52 --> Final output sent to browser
DEBUG - 2018-03-28 22:56:52 --> Total execution time: 0.1130
INFO - 2018-03-28 17:56:57 --> Config Class Initialized
INFO - 2018-03-28 17:56:57 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:56:57 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:56:57 --> Utf8 Class Initialized
INFO - 2018-03-28 17:56:57 --> URI Class Initialized
INFO - 2018-03-28 17:56:57 --> Router Class Initialized
INFO - 2018-03-28 17:56:57 --> Output Class Initialized
INFO - 2018-03-28 17:56:57 --> Security Class Initialized
DEBUG - 2018-03-28 17:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:56:57 --> Input Class Initialized
INFO - 2018-03-28 17:56:57 --> Language Class Initialized
INFO - 2018-03-28 17:56:57 --> Loader Class Initialized
INFO - 2018-03-28 17:56:57 --> Helper loaded: url_helper
INFO - 2018-03-28 17:56:57 --> Helper loaded: form_helper
INFO - 2018-03-28 17:56:57 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:56:57 --> Controller Class Initialized
INFO - 2018-03-28 17:56:57 --> Model Class Initialized
INFO - 2018-03-28 17:56:57 --> Model Class Initialized
INFO - 2018-03-28 17:56:57 --> Model Class Initialized
INFO - 2018-03-28 17:56:57 --> Model Class Initialized
INFO - 2018-03-28 17:56:58 --> Model Class Initialized
INFO - 2018-03-28 17:56:58 --> Model Class Initialized
INFO - 2018-03-28 17:56:58 --> Model Class Initialized
INFO - 2018-03-28 17:56:58 --> Model Class Initialized
INFO - 2018-03-28 17:56:58 --> Model Class Initialized
INFO - 2018-03-28 17:56:58 --> Model Class Initialized
INFO - 2018-03-28 17:56:58 --> Helper loaded: date_helper
INFO - 2018-03-28 17:56:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 22:56:58 --> Model Class Initialized
INFO - 2018-03-28 22:56:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:56:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:56:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-28 22:56:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:56:58 --> Final output sent to browser
DEBUG - 2018-03-28 22:56:58 --> Total execution time: 0.1295
INFO - 2018-03-28 17:57:31 --> Config Class Initialized
INFO - 2018-03-28 17:57:31 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:57:31 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:57:31 --> Utf8 Class Initialized
INFO - 2018-03-28 17:57:31 --> URI Class Initialized
INFO - 2018-03-28 17:57:31 --> Router Class Initialized
INFO - 2018-03-28 17:57:31 --> Output Class Initialized
INFO - 2018-03-28 17:57:31 --> Security Class Initialized
DEBUG - 2018-03-28 17:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:57:31 --> Input Class Initialized
INFO - 2018-03-28 17:57:31 --> Language Class Initialized
INFO - 2018-03-28 17:57:31 --> Loader Class Initialized
INFO - 2018-03-28 17:57:31 --> Helper loaded: url_helper
INFO - 2018-03-28 17:57:31 --> Helper loaded: form_helper
INFO - 2018-03-28 17:57:31 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:57:31 --> Controller Class Initialized
INFO - 2018-03-28 17:57:31 --> Model Class Initialized
INFO - 2018-03-28 17:57:31 --> Model Class Initialized
INFO - 2018-03-28 17:57:31 --> Model Class Initialized
INFO - 2018-03-28 17:57:31 --> Helper loaded: date_helper
INFO - 2018-03-28 17:57:31 --> Config Class Initialized
INFO - 2018-03-28 17:57:31 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:57:31 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:57:31 --> Utf8 Class Initialized
INFO - 2018-03-28 17:57:31 --> URI Class Initialized
INFO - 2018-03-28 17:57:31 --> Router Class Initialized
INFO - 2018-03-28 17:57:31 --> Output Class Initialized
INFO - 2018-03-28 17:57:31 --> Security Class Initialized
DEBUG - 2018-03-28 17:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:57:31 --> Input Class Initialized
INFO - 2018-03-28 17:57:31 --> Language Class Initialized
INFO - 2018-03-28 17:57:31 --> Loader Class Initialized
INFO - 2018-03-28 17:57:31 --> Helper loaded: url_helper
INFO - 2018-03-28 17:57:31 --> Helper loaded: form_helper
INFO - 2018-03-28 17:57:31 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:57:31 --> Controller Class Initialized
INFO - 2018-03-28 17:57:31 --> Model Class Initialized
INFO - 2018-03-28 17:57:31 --> Model Class Initialized
INFO - 2018-03-28 17:57:31 --> Model Class Initialized
INFO - 2018-03-28 17:57:31 --> Helper loaded: date_helper
INFO - 2018-03-28 22:57:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-28 22:57:31 --> Final output sent to browser
DEBUG - 2018-03-28 22:57:31 --> Total execution time: 0.1219
INFO - 2018-03-28 17:57:34 --> Config Class Initialized
INFO - 2018-03-28 17:57:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:57:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:57:34 --> Utf8 Class Initialized
INFO - 2018-03-28 17:57:34 --> URI Class Initialized
INFO - 2018-03-28 17:57:34 --> Router Class Initialized
INFO - 2018-03-28 17:57:34 --> Output Class Initialized
INFO - 2018-03-28 17:57:34 --> Security Class Initialized
DEBUG - 2018-03-28 17:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:57:34 --> Input Class Initialized
INFO - 2018-03-28 17:57:34 --> Language Class Initialized
INFO - 2018-03-28 17:57:34 --> Loader Class Initialized
INFO - 2018-03-28 17:57:34 --> Helper loaded: url_helper
INFO - 2018-03-28 17:57:34 --> Helper loaded: form_helper
INFO - 2018-03-28 17:57:34 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:57:34 --> Controller Class Initialized
INFO - 2018-03-28 17:57:34 --> Model Class Initialized
INFO - 2018-03-28 17:57:34 --> Model Class Initialized
INFO - 2018-03-28 17:57:34 --> Model Class Initialized
INFO - 2018-03-28 17:57:34 --> Helper loaded: date_helper
INFO - 2018-03-28 17:57:34 --> Config Class Initialized
INFO - 2018-03-28 17:57:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:57:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:57:34 --> Utf8 Class Initialized
INFO - 2018-03-28 17:57:34 --> URI Class Initialized
INFO - 2018-03-28 17:57:34 --> Router Class Initialized
INFO - 2018-03-28 17:57:34 --> Output Class Initialized
INFO - 2018-03-28 17:57:34 --> Security Class Initialized
DEBUG - 2018-03-28 17:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:57:34 --> Input Class Initialized
INFO - 2018-03-28 17:57:34 --> Language Class Initialized
INFO - 2018-03-28 17:57:34 --> Loader Class Initialized
INFO - 2018-03-28 17:57:34 --> Helper loaded: url_helper
INFO - 2018-03-28 17:57:34 --> Helper loaded: form_helper
INFO - 2018-03-28 17:57:34 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:57:34 --> Controller Class Initialized
INFO - 2018-03-28 17:57:34 --> Model Class Initialized
INFO - 2018-03-28 17:57:34 --> Model Class Initialized
INFO - 2018-03-28 17:57:34 --> Model Class Initialized
INFO - 2018-03-28 17:57:34 --> Model Class Initialized
INFO - 2018-03-28 17:57:34 --> Model Class Initialized
INFO - 2018-03-28 17:57:34 --> Helper loaded: date_helper
INFO - 2018-03-28 22:57:34 --> Model Class Initialized
INFO - 2018-03-28 22:57:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:57:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:57:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-28 22:57:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:57:34 --> Final output sent to browser
DEBUG - 2018-03-28 22:57:34 --> Total execution time: 0.1560
INFO - 2018-03-28 17:57:37 --> Config Class Initialized
INFO - 2018-03-28 17:57:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:57:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:57:37 --> Utf8 Class Initialized
INFO - 2018-03-28 17:57:37 --> URI Class Initialized
INFO - 2018-03-28 17:57:37 --> Router Class Initialized
INFO - 2018-03-28 17:57:37 --> Output Class Initialized
INFO - 2018-03-28 17:57:37 --> Security Class Initialized
DEBUG - 2018-03-28 17:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:57:37 --> Input Class Initialized
INFO - 2018-03-28 17:57:37 --> Language Class Initialized
INFO - 2018-03-28 17:57:37 --> Loader Class Initialized
INFO - 2018-03-28 17:57:37 --> Helper loaded: url_helper
INFO - 2018-03-28 17:57:37 --> Helper loaded: form_helper
INFO - 2018-03-28 17:57:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:57:37 --> Controller Class Initialized
INFO - 2018-03-28 17:57:37 --> Model Class Initialized
INFO - 2018-03-28 17:57:37 --> Model Class Initialized
INFO - 2018-03-28 17:57:37 --> Model Class Initialized
INFO - 2018-03-28 17:57:37 --> Model Class Initialized
INFO - 2018-03-28 17:57:37 --> Model Class Initialized
INFO - 2018-03-28 17:57:37 --> Helper loaded: date_helper
INFO - 2018-03-28 22:57:37 --> Model Class Initialized
INFO - 2018-03-28 22:57:37 --> Model Class Initialized
INFO - 2018-03-28 22:57:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:57:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:57:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-28 22:57:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:57:37 --> Final output sent to browser
DEBUG - 2018-03-28 22:57:37 --> Total execution time: 0.1501
INFO - 2018-03-28 17:57:39 --> Config Class Initialized
INFO - 2018-03-28 17:57:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:57:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:57:39 --> Utf8 Class Initialized
INFO - 2018-03-28 17:57:39 --> URI Class Initialized
INFO - 2018-03-28 17:57:39 --> Router Class Initialized
INFO - 2018-03-28 17:57:39 --> Output Class Initialized
INFO - 2018-03-28 17:57:39 --> Security Class Initialized
DEBUG - 2018-03-28 17:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:57:39 --> Input Class Initialized
INFO - 2018-03-28 17:57:39 --> Language Class Initialized
INFO - 2018-03-28 17:57:39 --> Loader Class Initialized
INFO - 2018-03-28 17:57:39 --> Helper loaded: url_helper
INFO - 2018-03-28 17:57:39 --> Helper loaded: form_helper
INFO - 2018-03-28 17:57:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:57:39 --> Controller Class Initialized
INFO - 2018-03-28 17:57:39 --> Model Class Initialized
INFO - 2018-03-28 17:57:39 --> Model Class Initialized
INFO - 2018-03-28 17:57:39 --> Model Class Initialized
INFO - 2018-03-28 17:57:39 --> Model Class Initialized
INFO - 2018-03-28 17:57:39 --> Model Class Initialized
INFO - 2018-03-28 17:57:39 --> Helper loaded: date_helper
INFO - 2018-03-28 22:57:39 --> Model Class Initialized
INFO - 2018-03-28 22:57:39 --> Model Class Initialized
INFO - 2018-03-28 22:57:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:57:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:57:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/create.php
INFO - 2018-03-28 22:57:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:57:39 --> Final output sent to browser
DEBUG - 2018-03-28 22:57:39 --> Total execution time: 0.1097
INFO - 2018-03-28 17:57:56 --> Config Class Initialized
INFO - 2018-03-28 17:57:56 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:57:56 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:57:56 --> Utf8 Class Initialized
INFO - 2018-03-28 17:57:56 --> URI Class Initialized
INFO - 2018-03-28 17:57:56 --> Router Class Initialized
INFO - 2018-03-28 17:57:56 --> Output Class Initialized
INFO - 2018-03-28 17:57:56 --> Security Class Initialized
DEBUG - 2018-03-28 17:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:57:56 --> Input Class Initialized
INFO - 2018-03-28 17:57:56 --> Language Class Initialized
INFO - 2018-03-28 17:57:56 --> Loader Class Initialized
INFO - 2018-03-28 17:57:56 --> Helper loaded: url_helper
INFO - 2018-03-28 17:57:56 --> Helper loaded: form_helper
INFO - 2018-03-28 17:57:56 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:57:56 --> Controller Class Initialized
INFO - 2018-03-28 17:57:56 --> Model Class Initialized
INFO - 2018-03-28 17:57:56 --> Model Class Initialized
INFO - 2018-03-28 17:57:56 --> Model Class Initialized
INFO - 2018-03-28 17:57:56 --> Model Class Initialized
INFO - 2018-03-28 17:57:56 --> Model Class Initialized
INFO - 2018-03-28 17:57:56 --> Helper loaded: date_helper
INFO - 2018-03-28 22:57:56 --> Model Class Initialized
INFO - 2018-03-28 22:57:56 --> Model Class Initialized
INFO - 2018-03-28 22:57:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:57:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:57:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-28 22:57:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:57:56 --> Final output sent to browser
DEBUG - 2018-03-28 22:57:56 --> Total execution time: 0.1029
INFO - 2018-03-28 17:58:08 --> Config Class Initialized
INFO - 2018-03-28 17:58:08 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:58:08 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:58:08 --> Utf8 Class Initialized
INFO - 2018-03-28 17:58:08 --> URI Class Initialized
INFO - 2018-03-28 17:58:08 --> Router Class Initialized
INFO - 2018-03-28 17:58:08 --> Output Class Initialized
INFO - 2018-03-28 17:58:08 --> Security Class Initialized
DEBUG - 2018-03-28 17:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:58:08 --> Input Class Initialized
INFO - 2018-03-28 17:58:08 --> Language Class Initialized
INFO - 2018-03-28 17:58:08 --> Loader Class Initialized
INFO - 2018-03-28 17:58:08 --> Helper loaded: url_helper
INFO - 2018-03-28 17:58:08 --> Helper loaded: form_helper
INFO - 2018-03-28 17:58:08 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:58:08 --> Controller Class Initialized
INFO - 2018-03-28 17:58:08 --> Model Class Initialized
INFO - 2018-03-28 17:58:08 --> Model Class Initialized
INFO - 2018-03-28 17:58:08 --> Helper loaded: date_helper
INFO - 2018-03-28 22:58:08 --> Model Class Initialized
INFO - 2018-03-28 22:58:08 --> Model Class Initialized
INFO - 2018-03-28 22:58:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:58:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:58:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/group/table.php
INFO - 2018-03-28 22:58:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:58:08 --> Final output sent to browser
DEBUG - 2018-03-28 22:58:08 --> Total execution time: 0.1297
INFO - 2018-03-28 17:58:22 --> Config Class Initialized
INFO - 2018-03-28 17:58:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:58:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:58:22 --> Utf8 Class Initialized
INFO - 2018-03-28 17:58:22 --> URI Class Initialized
INFO - 2018-03-28 17:58:22 --> Router Class Initialized
INFO - 2018-03-28 17:58:22 --> Output Class Initialized
INFO - 2018-03-28 17:58:22 --> Security Class Initialized
DEBUG - 2018-03-28 17:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:58:22 --> Input Class Initialized
INFO - 2018-03-28 17:58:22 --> Language Class Initialized
INFO - 2018-03-28 17:58:22 --> Loader Class Initialized
INFO - 2018-03-28 17:58:22 --> Helper loaded: url_helper
INFO - 2018-03-28 17:58:22 --> Helper loaded: form_helper
INFO - 2018-03-28 17:58:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:58:22 --> Controller Class Initialized
INFO - 2018-03-28 17:58:22 --> Model Class Initialized
INFO - 2018-03-28 17:58:22 --> Model Class Initialized
INFO - 2018-03-28 17:58:22 --> Model Class Initialized
INFO - 2018-03-28 17:58:22 --> Model Class Initialized
INFO - 2018-03-28 17:58:22 --> Model Class Initialized
INFO - 2018-03-28 17:58:22 --> Helper loaded: date_helper
INFO - 2018-03-28 22:58:22 --> Model Class Initialized
INFO - 2018-03-28 22:58:22 --> Model Class Initialized
INFO - 2018-03-28 22:58:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:58:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:58:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-28 22:58:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:58:22 --> Final output sent to browser
DEBUG - 2018-03-28 22:58:22 --> Total execution time: 0.1022
INFO - 2018-03-28 17:58:26 --> Config Class Initialized
INFO - 2018-03-28 17:58:26 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:58:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:58:26 --> Utf8 Class Initialized
INFO - 2018-03-28 17:58:26 --> URI Class Initialized
INFO - 2018-03-28 17:58:26 --> Router Class Initialized
INFO - 2018-03-28 17:58:26 --> Output Class Initialized
INFO - 2018-03-28 17:58:26 --> Security Class Initialized
DEBUG - 2018-03-28 17:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:58:26 --> Input Class Initialized
INFO - 2018-03-28 17:58:26 --> Language Class Initialized
INFO - 2018-03-28 17:58:26 --> Loader Class Initialized
INFO - 2018-03-28 17:58:26 --> Helper loaded: url_helper
INFO - 2018-03-28 17:58:26 --> Helper loaded: form_helper
INFO - 2018-03-28 17:58:26 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:58:26 --> Controller Class Initialized
INFO - 2018-03-28 17:58:26 --> Model Class Initialized
INFO - 2018-03-28 17:58:26 --> Model Class Initialized
INFO - 2018-03-28 17:58:26 --> Model Class Initialized
INFO - 2018-03-28 17:58:26 --> Model Class Initialized
INFO - 2018-03-28 17:58:26 --> Model Class Initialized
INFO - 2018-03-28 17:58:26 --> Helper loaded: date_helper
INFO - 2018-03-28 22:58:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/list.php
INFO - 2018-03-28 22:58:26 --> Final output sent to browser
DEBUG - 2018-03-28 22:58:26 --> Total execution time: 0.1124
INFO - 2018-03-28 17:58:29 --> Config Class Initialized
INFO - 2018-03-28 17:58:29 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:58:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:58:29 --> Utf8 Class Initialized
INFO - 2018-03-28 17:58:29 --> URI Class Initialized
INFO - 2018-03-28 17:58:30 --> Router Class Initialized
INFO - 2018-03-28 17:58:30 --> Output Class Initialized
INFO - 2018-03-28 17:58:30 --> Security Class Initialized
DEBUG - 2018-03-28 17:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:58:30 --> Input Class Initialized
INFO - 2018-03-28 17:58:30 --> Language Class Initialized
INFO - 2018-03-28 17:58:30 --> Loader Class Initialized
INFO - 2018-03-28 17:58:30 --> Helper loaded: url_helper
INFO - 2018-03-28 17:58:30 --> Helper loaded: form_helper
INFO - 2018-03-28 17:58:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:58:30 --> Controller Class Initialized
INFO - 2018-03-28 17:58:30 --> Model Class Initialized
INFO - 2018-03-28 17:58:30 --> Model Class Initialized
INFO - 2018-03-28 17:58:30 --> Model Class Initialized
INFO - 2018-03-28 17:58:30 --> Model Class Initialized
INFO - 2018-03-28 17:58:30 --> Model Class Initialized
INFO - 2018-03-28 17:58:30 --> Helper loaded: date_helper
INFO - 2018-03-28 22:58:30 --> Model Class Initialized
INFO - 2018-03-28 22:58:30 --> Model Class Initialized
INFO - 2018-03-28 22:58:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:58:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:58:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/create.php
INFO - 2018-03-28 22:58:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:58:30 --> Final output sent to browser
DEBUG - 2018-03-28 22:58:30 --> Total execution time: 0.1219
INFO - 2018-03-28 17:58:59 --> Config Class Initialized
INFO - 2018-03-28 17:58:59 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:58:59 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:58:59 --> Utf8 Class Initialized
INFO - 2018-03-28 17:58:59 --> URI Class Initialized
INFO - 2018-03-28 17:58:59 --> Router Class Initialized
INFO - 2018-03-28 17:58:59 --> Output Class Initialized
INFO - 2018-03-28 17:58:59 --> Security Class Initialized
DEBUG - 2018-03-28 17:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:58:59 --> Input Class Initialized
INFO - 2018-03-28 17:58:59 --> Language Class Initialized
INFO - 2018-03-28 17:58:59 --> Loader Class Initialized
INFO - 2018-03-28 17:58:59 --> Helper loaded: url_helper
INFO - 2018-03-28 17:58:59 --> Helper loaded: form_helper
INFO - 2018-03-28 17:58:59 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:58:59 --> Controller Class Initialized
INFO - 2018-03-28 17:58:59 --> Model Class Initialized
INFO - 2018-03-28 17:58:59 --> Model Class Initialized
INFO - 2018-03-28 17:58:59 --> Model Class Initialized
INFO - 2018-03-28 17:58:59 --> Model Class Initialized
INFO - 2018-03-28 17:58:59 --> Model Class Initialized
INFO - 2018-03-28 17:58:59 --> Helper loaded: date_helper
INFO - 2018-03-28 17:58:59 --> Config Class Initialized
INFO - 2018-03-28 17:58:59 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:58:59 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:58:59 --> Utf8 Class Initialized
INFO - 2018-03-28 17:58:59 --> URI Class Initialized
INFO - 2018-03-28 17:58:59 --> Router Class Initialized
INFO - 2018-03-28 17:58:59 --> Output Class Initialized
INFO - 2018-03-28 17:58:59 --> Security Class Initialized
DEBUG - 2018-03-28 17:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:58:59 --> Input Class Initialized
INFO - 2018-03-28 17:58:59 --> Language Class Initialized
INFO - 2018-03-28 17:58:59 --> Loader Class Initialized
INFO - 2018-03-28 17:58:59 --> Helper loaded: url_helper
INFO - 2018-03-28 17:58:59 --> Helper loaded: form_helper
INFO - 2018-03-28 17:58:59 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:58:59 --> Controller Class Initialized
INFO - 2018-03-28 17:58:59 --> Model Class Initialized
INFO - 2018-03-28 17:58:59 --> Model Class Initialized
INFO - 2018-03-28 17:58:59 --> Model Class Initialized
INFO - 2018-03-28 17:58:59 --> Model Class Initialized
INFO - 2018-03-28 17:58:59 --> Model Class Initialized
INFO - 2018-03-28 17:58:59 --> Helper loaded: date_helper
INFO - 2018-03-28 22:58:59 --> Model Class Initialized
INFO - 2018-03-28 22:58:59 --> Model Class Initialized
INFO - 2018-03-28 22:58:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:58:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:58:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-28 22:58:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:58:59 --> Final output sent to browser
DEBUG - 2018-03-28 22:58:59 --> Total execution time: 0.1106
INFO - 2018-03-28 17:59:02 --> Config Class Initialized
INFO - 2018-03-28 17:59:02 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:59:02 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:59:02 --> Utf8 Class Initialized
INFO - 2018-03-28 17:59:02 --> URI Class Initialized
INFO - 2018-03-28 17:59:02 --> Router Class Initialized
INFO - 2018-03-28 17:59:02 --> Output Class Initialized
INFO - 2018-03-28 17:59:02 --> Security Class Initialized
DEBUG - 2018-03-28 17:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:59:02 --> Input Class Initialized
INFO - 2018-03-28 17:59:02 --> Language Class Initialized
INFO - 2018-03-28 17:59:02 --> Loader Class Initialized
INFO - 2018-03-28 17:59:02 --> Helper loaded: url_helper
INFO - 2018-03-28 17:59:02 --> Helper loaded: form_helper
INFO - 2018-03-28 17:59:02 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:59:02 --> Controller Class Initialized
INFO - 2018-03-28 17:59:02 --> Model Class Initialized
INFO - 2018-03-28 17:59:02 --> Model Class Initialized
INFO - 2018-03-28 17:59:02 --> Model Class Initialized
INFO - 2018-03-28 17:59:02 --> Model Class Initialized
INFO - 2018-03-28 17:59:02 --> Model Class Initialized
INFO - 2018-03-28 17:59:02 --> Helper loaded: date_helper
INFO - 2018-03-28 22:59:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/list.php
INFO - 2018-03-28 22:59:02 --> Final output sent to browser
DEBUG - 2018-03-28 22:59:02 --> Total execution time: 0.1190
INFO - 2018-03-28 17:59:04 --> Config Class Initialized
INFO - 2018-03-28 17:59:04 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:59:04 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:59:04 --> Utf8 Class Initialized
INFO - 2018-03-28 17:59:04 --> URI Class Initialized
INFO - 2018-03-28 17:59:04 --> Router Class Initialized
INFO - 2018-03-28 17:59:04 --> Output Class Initialized
INFO - 2018-03-28 17:59:04 --> Security Class Initialized
DEBUG - 2018-03-28 17:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:59:04 --> Input Class Initialized
INFO - 2018-03-28 17:59:04 --> Language Class Initialized
INFO - 2018-03-28 17:59:04 --> Loader Class Initialized
INFO - 2018-03-28 17:59:04 --> Helper loaded: url_helper
INFO - 2018-03-28 17:59:04 --> Helper loaded: form_helper
INFO - 2018-03-28 17:59:04 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:59:04 --> Controller Class Initialized
INFO - 2018-03-28 17:59:04 --> Model Class Initialized
INFO - 2018-03-28 17:59:04 --> Model Class Initialized
INFO - 2018-03-28 17:59:04 --> Model Class Initialized
INFO - 2018-03-28 17:59:04 --> Model Class Initialized
INFO - 2018-03-28 17:59:04 --> Model Class Initialized
INFO - 2018-03-28 17:59:04 --> Helper loaded: date_helper
INFO - 2018-03-28 22:59:04 --> Model Class Initialized
INFO - 2018-03-28 22:59:04 --> Model Class Initialized
INFO - 2018-03-28 22:59:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:59:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:59:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/create.php
INFO - 2018-03-28 22:59:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:59:04 --> Final output sent to browser
DEBUG - 2018-03-28 22:59:04 --> Total execution time: 0.1263
INFO - 2018-03-28 17:59:13 --> Config Class Initialized
INFO - 2018-03-28 17:59:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:59:13 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:59:13 --> Utf8 Class Initialized
INFO - 2018-03-28 17:59:13 --> URI Class Initialized
INFO - 2018-03-28 17:59:13 --> Router Class Initialized
INFO - 2018-03-28 17:59:13 --> Output Class Initialized
INFO - 2018-03-28 17:59:13 --> Security Class Initialized
DEBUG - 2018-03-28 17:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:59:13 --> Input Class Initialized
INFO - 2018-03-28 17:59:13 --> Language Class Initialized
INFO - 2018-03-28 17:59:13 --> Loader Class Initialized
INFO - 2018-03-28 17:59:13 --> Helper loaded: url_helper
INFO - 2018-03-28 17:59:13 --> Helper loaded: form_helper
INFO - 2018-03-28 17:59:13 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:59:13 --> Controller Class Initialized
INFO - 2018-03-28 17:59:13 --> Model Class Initialized
INFO - 2018-03-28 17:59:13 --> Model Class Initialized
INFO - 2018-03-28 17:59:13 --> Model Class Initialized
INFO - 2018-03-28 17:59:13 --> Helper loaded: date_helper
INFO - 2018-03-28 17:59:13 --> Config Class Initialized
INFO - 2018-03-28 17:59:13 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:59:13 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:59:13 --> Utf8 Class Initialized
INFO - 2018-03-28 17:59:13 --> URI Class Initialized
INFO - 2018-03-28 17:59:13 --> Router Class Initialized
INFO - 2018-03-28 17:59:13 --> Output Class Initialized
INFO - 2018-03-28 17:59:13 --> Security Class Initialized
DEBUG - 2018-03-28 17:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:59:13 --> Input Class Initialized
INFO - 2018-03-28 17:59:13 --> Language Class Initialized
INFO - 2018-03-28 17:59:13 --> Loader Class Initialized
INFO - 2018-03-28 17:59:13 --> Helper loaded: url_helper
INFO - 2018-03-28 17:59:13 --> Helper loaded: form_helper
INFO - 2018-03-28 17:59:13 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:59:13 --> Controller Class Initialized
INFO - 2018-03-28 17:59:13 --> Model Class Initialized
INFO - 2018-03-28 17:59:13 --> Model Class Initialized
INFO - 2018-03-28 17:59:13 --> Model Class Initialized
INFO - 2018-03-28 17:59:13 --> Helper loaded: date_helper
INFO - 2018-03-28 22:59:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-28 22:59:13 --> Final output sent to browser
DEBUG - 2018-03-28 22:59:13 --> Total execution time: 0.1155
INFO - 2018-03-28 17:59:26 --> Config Class Initialized
INFO - 2018-03-28 17:59:26 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:59:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:59:26 --> Utf8 Class Initialized
INFO - 2018-03-28 17:59:26 --> URI Class Initialized
INFO - 2018-03-28 17:59:26 --> Router Class Initialized
INFO - 2018-03-28 17:59:26 --> Output Class Initialized
INFO - 2018-03-28 17:59:26 --> Security Class Initialized
DEBUG - 2018-03-28 17:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:59:26 --> Input Class Initialized
INFO - 2018-03-28 17:59:26 --> Language Class Initialized
INFO - 2018-03-28 17:59:26 --> Loader Class Initialized
INFO - 2018-03-28 17:59:26 --> Helper loaded: url_helper
INFO - 2018-03-28 17:59:26 --> Helper loaded: form_helper
INFO - 2018-03-28 17:59:26 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:59:26 --> Controller Class Initialized
INFO - 2018-03-28 17:59:26 --> Model Class Initialized
INFO - 2018-03-28 17:59:26 --> Model Class Initialized
INFO - 2018-03-28 17:59:26 --> Model Class Initialized
INFO - 2018-03-28 17:59:26 --> Helper loaded: date_helper
INFO - 2018-03-28 17:59:26 --> Config Class Initialized
INFO - 2018-03-28 17:59:26 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:59:26 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:59:26 --> Utf8 Class Initialized
INFO - 2018-03-28 17:59:26 --> URI Class Initialized
INFO - 2018-03-28 17:59:26 --> Router Class Initialized
INFO - 2018-03-28 17:59:26 --> Output Class Initialized
INFO - 2018-03-28 17:59:26 --> Security Class Initialized
DEBUG - 2018-03-28 17:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:59:26 --> Input Class Initialized
INFO - 2018-03-28 17:59:26 --> Language Class Initialized
INFO - 2018-03-28 17:59:26 --> Loader Class Initialized
INFO - 2018-03-28 17:59:26 --> Helper loaded: url_helper
INFO - 2018-03-28 17:59:26 --> Helper loaded: form_helper
INFO - 2018-03-28 17:59:26 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:59:26 --> Controller Class Initialized
INFO - 2018-03-28 17:59:26 --> Model Class Initialized
INFO - 2018-03-28 17:59:26 --> Model Class Initialized
INFO - 2018-03-28 17:59:26 --> Model Class Initialized
INFO - 2018-03-28 17:59:26 --> Model Class Initialized
INFO - 2018-03-28 17:59:26 --> Model Class Initialized
INFO - 2018-03-28 17:59:26 --> Helper loaded: date_helper
INFO - 2018-03-28 22:59:26 --> Model Class Initialized
INFO - 2018-03-28 22:59:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:59:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:59:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-28 22:59:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:59:26 --> Final output sent to browser
DEBUG - 2018-03-28 22:59:26 --> Total execution time: 0.1072
INFO - 2018-03-28 17:59:30 --> Config Class Initialized
INFO - 2018-03-28 17:59:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:59:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:59:30 --> Utf8 Class Initialized
INFO - 2018-03-28 17:59:30 --> URI Class Initialized
INFO - 2018-03-28 17:59:30 --> Router Class Initialized
INFO - 2018-03-28 17:59:30 --> Output Class Initialized
INFO - 2018-03-28 17:59:30 --> Security Class Initialized
DEBUG - 2018-03-28 17:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:59:30 --> Input Class Initialized
INFO - 2018-03-28 17:59:30 --> Language Class Initialized
INFO - 2018-03-28 17:59:30 --> Loader Class Initialized
INFO - 2018-03-28 17:59:30 --> Helper loaded: url_helper
INFO - 2018-03-28 17:59:30 --> Helper loaded: form_helper
INFO - 2018-03-28 17:59:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:59:30 --> Controller Class Initialized
INFO - 2018-03-28 17:59:30 --> Model Class Initialized
INFO - 2018-03-28 17:59:30 --> Model Class Initialized
INFO - 2018-03-28 17:59:30 --> Model Class Initialized
INFO - 2018-03-28 17:59:30 --> Model Class Initialized
INFO - 2018-03-28 17:59:30 --> Model Class Initialized
INFO - 2018-03-28 17:59:30 --> Helper loaded: date_helper
INFO - 2018-03-28 22:59:30 --> Model Class Initialized
INFO - 2018-03-28 22:59:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:59:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:59:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-28 22:59:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:59:30 --> Final output sent to browser
DEBUG - 2018-03-28 22:59:30 --> Total execution time: 0.1613
INFO - 2018-03-28 17:59:34 --> Config Class Initialized
INFO - 2018-03-28 17:59:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:59:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:59:34 --> Utf8 Class Initialized
INFO - 2018-03-28 17:59:34 --> URI Class Initialized
INFO - 2018-03-28 17:59:34 --> Router Class Initialized
INFO - 2018-03-28 17:59:34 --> Output Class Initialized
INFO - 2018-03-28 17:59:34 --> Security Class Initialized
DEBUG - 2018-03-28 17:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:59:34 --> Input Class Initialized
INFO - 2018-03-28 17:59:34 --> Language Class Initialized
INFO - 2018-03-28 17:59:34 --> Loader Class Initialized
INFO - 2018-03-28 17:59:34 --> Helper loaded: url_helper
INFO - 2018-03-28 17:59:34 --> Helper loaded: form_helper
INFO - 2018-03-28 17:59:34 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:59:34 --> Controller Class Initialized
INFO - 2018-03-28 17:59:34 --> Model Class Initialized
INFO - 2018-03-28 17:59:34 --> Model Class Initialized
INFO - 2018-03-28 17:59:34 --> Model Class Initialized
INFO - 2018-03-28 17:59:34 --> Helper loaded: date_helper
INFO - 2018-03-28 17:59:34 --> Config Class Initialized
INFO - 2018-03-28 17:59:34 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:59:34 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:59:34 --> Utf8 Class Initialized
INFO - 2018-03-28 17:59:34 --> URI Class Initialized
INFO - 2018-03-28 17:59:34 --> Router Class Initialized
INFO - 2018-03-28 17:59:34 --> Output Class Initialized
INFO - 2018-03-28 17:59:34 --> Security Class Initialized
DEBUG - 2018-03-28 17:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:59:34 --> Input Class Initialized
INFO - 2018-03-28 17:59:34 --> Language Class Initialized
INFO - 2018-03-28 17:59:34 --> Loader Class Initialized
INFO - 2018-03-28 17:59:34 --> Helper loaded: url_helper
INFO - 2018-03-28 17:59:34 --> Helper loaded: form_helper
INFO - 2018-03-28 17:59:34 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:59:34 --> Controller Class Initialized
INFO - 2018-03-28 17:59:34 --> Model Class Initialized
INFO - 2018-03-28 17:59:34 --> Model Class Initialized
INFO - 2018-03-28 17:59:34 --> Model Class Initialized
INFO - 2018-03-28 17:59:34 --> Helper loaded: date_helper
INFO - 2018-03-28 22:59:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-28 22:59:34 --> Final output sent to browser
DEBUG - 2018-03-28 22:59:34 --> Total execution time: 0.1203
INFO - 2018-03-28 17:59:37 --> Config Class Initialized
INFO - 2018-03-28 17:59:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:59:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:59:37 --> Utf8 Class Initialized
INFO - 2018-03-28 17:59:37 --> URI Class Initialized
INFO - 2018-03-28 17:59:37 --> Router Class Initialized
INFO - 2018-03-28 17:59:37 --> Output Class Initialized
INFO - 2018-03-28 17:59:37 --> Security Class Initialized
DEBUG - 2018-03-28 17:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:59:37 --> Input Class Initialized
INFO - 2018-03-28 17:59:37 --> Language Class Initialized
INFO - 2018-03-28 17:59:37 --> Loader Class Initialized
INFO - 2018-03-28 17:59:37 --> Helper loaded: url_helper
INFO - 2018-03-28 17:59:37 --> Helper loaded: form_helper
INFO - 2018-03-28 17:59:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:59:37 --> Controller Class Initialized
INFO - 2018-03-28 17:59:37 --> Model Class Initialized
INFO - 2018-03-28 17:59:37 --> Model Class Initialized
INFO - 2018-03-28 17:59:37 --> Model Class Initialized
INFO - 2018-03-28 17:59:37 --> Helper loaded: date_helper
INFO - 2018-03-28 17:59:37 --> Config Class Initialized
INFO - 2018-03-28 17:59:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:59:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:59:37 --> Utf8 Class Initialized
INFO - 2018-03-28 17:59:37 --> URI Class Initialized
INFO - 2018-03-28 17:59:37 --> Router Class Initialized
INFO - 2018-03-28 17:59:37 --> Output Class Initialized
INFO - 2018-03-28 17:59:37 --> Security Class Initialized
DEBUG - 2018-03-28 17:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:59:37 --> Input Class Initialized
INFO - 2018-03-28 17:59:37 --> Language Class Initialized
INFO - 2018-03-28 17:59:37 --> Loader Class Initialized
INFO - 2018-03-28 17:59:37 --> Helper loaded: url_helper
INFO - 2018-03-28 17:59:37 --> Helper loaded: form_helper
INFO - 2018-03-28 17:59:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:59:37 --> Controller Class Initialized
INFO - 2018-03-28 17:59:37 --> Model Class Initialized
INFO - 2018-03-28 17:59:37 --> Model Class Initialized
INFO - 2018-03-28 17:59:37 --> Model Class Initialized
INFO - 2018-03-28 17:59:37 --> Model Class Initialized
INFO - 2018-03-28 17:59:37 --> Model Class Initialized
INFO - 2018-03-28 17:59:37 --> Helper loaded: date_helper
INFO - 2018-03-28 22:59:37 --> Model Class Initialized
INFO - 2018-03-28 22:59:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:59:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:59:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-28 22:59:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:59:37 --> Final output sent to browser
DEBUG - 2018-03-28 22:59:37 --> Total execution time: 0.1796
INFO - 2018-03-28 17:59:39 --> Config Class Initialized
INFO - 2018-03-28 17:59:39 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:59:39 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:59:39 --> Utf8 Class Initialized
INFO - 2018-03-28 17:59:39 --> URI Class Initialized
INFO - 2018-03-28 17:59:39 --> Router Class Initialized
INFO - 2018-03-28 17:59:39 --> Output Class Initialized
INFO - 2018-03-28 17:59:39 --> Security Class Initialized
DEBUG - 2018-03-28 17:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:59:39 --> Input Class Initialized
INFO - 2018-03-28 17:59:39 --> Language Class Initialized
INFO - 2018-03-28 17:59:39 --> Loader Class Initialized
INFO - 2018-03-28 17:59:39 --> Helper loaded: url_helper
INFO - 2018-03-28 17:59:39 --> Helper loaded: form_helper
INFO - 2018-03-28 17:59:39 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:59:39 --> Controller Class Initialized
INFO - 2018-03-28 17:59:39 --> Model Class Initialized
INFO - 2018-03-28 17:59:39 --> Model Class Initialized
INFO - 2018-03-28 17:59:39 --> Model Class Initialized
INFO - 2018-03-28 17:59:39 --> Model Class Initialized
INFO - 2018-03-28 17:59:39 --> Model Class Initialized
INFO - 2018-03-28 17:59:39 --> Helper loaded: date_helper
INFO - 2018-03-28 22:59:39 --> Model Class Initialized
INFO - 2018-03-28 22:59:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:59:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:59:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-28 22:59:39 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:59:39 --> Final output sent to browser
DEBUG - 2018-03-28 22:59:39 --> Total execution time: 0.1112
INFO - 2018-03-28 17:59:48 --> Config Class Initialized
INFO - 2018-03-28 17:59:48 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:59:48 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:59:48 --> Utf8 Class Initialized
INFO - 2018-03-28 17:59:48 --> URI Class Initialized
INFO - 2018-03-28 17:59:48 --> Router Class Initialized
INFO - 2018-03-28 17:59:48 --> Output Class Initialized
INFO - 2018-03-28 17:59:48 --> Security Class Initialized
DEBUG - 2018-03-28 17:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:59:48 --> Input Class Initialized
INFO - 2018-03-28 17:59:48 --> Language Class Initialized
INFO - 2018-03-28 17:59:48 --> Loader Class Initialized
INFO - 2018-03-28 17:59:48 --> Helper loaded: url_helper
INFO - 2018-03-28 17:59:48 --> Helper loaded: form_helper
INFO - 2018-03-28 17:59:48 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:59:48 --> Controller Class Initialized
INFO - 2018-03-28 17:59:48 --> Model Class Initialized
INFO - 2018-03-28 17:59:48 --> Model Class Initialized
INFO - 2018-03-28 17:59:48 --> Model Class Initialized
INFO - 2018-03-28 17:59:48 --> Model Class Initialized
INFO - 2018-03-28 17:59:48 --> Model Class Initialized
INFO - 2018-03-28 17:59:48 --> Helper loaded: date_helper
INFO - 2018-03-28 22:59:48 --> Model Class Initialized
INFO - 2018-03-28 22:59:48 --> Model Class Initialized
INFO - 2018-03-28 22:59:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:59:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:59:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-28 22:59:48 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:59:48 --> Final output sent to browser
DEBUG - 2018-03-28 22:59:48 --> Total execution time: 0.1035
INFO - 2018-03-28 17:59:50 --> Config Class Initialized
INFO - 2018-03-28 17:59:50 --> Hooks Class Initialized
DEBUG - 2018-03-28 17:59:50 --> UTF-8 Support Enabled
INFO - 2018-03-28 17:59:50 --> Utf8 Class Initialized
INFO - 2018-03-28 17:59:50 --> URI Class Initialized
INFO - 2018-03-28 17:59:50 --> Router Class Initialized
INFO - 2018-03-28 17:59:50 --> Output Class Initialized
INFO - 2018-03-28 17:59:50 --> Security Class Initialized
DEBUG - 2018-03-28 17:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 17:59:50 --> Input Class Initialized
INFO - 2018-03-28 17:59:50 --> Language Class Initialized
INFO - 2018-03-28 17:59:50 --> Loader Class Initialized
INFO - 2018-03-28 17:59:50 --> Helper loaded: url_helper
INFO - 2018-03-28 17:59:50 --> Helper loaded: form_helper
INFO - 2018-03-28 17:59:50 --> Database Driver Class Initialized
DEBUG - 2018-03-28 17:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 17:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 17:59:50 --> Controller Class Initialized
INFO - 2018-03-28 17:59:50 --> Model Class Initialized
INFO - 2018-03-28 17:59:50 --> Model Class Initialized
INFO - 2018-03-28 17:59:50 --> Model Class Initialized
INFO - 2018-03-28 17:59:50 --> Model Class Initialized
INFO - 2018-03-28 17:59:50 --> Model Class Initialized
INFO - 2018-03-28 17:59:50 --> Helper loaded: date_helper
INFO - 2018-03-28 22:59:50 --> Model Class Initialized
INFO - 2018-03-28 22:59:50 --> Model Class Initialized
INFO - 2018-03-28 22:59:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 22:59:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 22:59:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/create.php
INFO - 2018-03-28 22:59:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 22:59:50 --> Final output sent to browser
DEBUG - 2018-03-28 22:59:50 --> Total execution time: 0.1227
INFO - 2018-03-28 18:00:03 --> Config Class Initialized
INFO - 2018-03-28 18:00:03 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:00:03 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:00:03 --> Utf8 Class Initialized
INFO - 2018-03-28 18:00:03 --> URI Class Initialized
INFO - 2018-03-28 18:00:03 --> Router Class Initialized
INFO - 2018-03-28 18:00:03 --> Output Class Initialized
INFO - 2018-03-28 18:00:03 --> Security Class Initialized
DEBUG - 2018-03-28 18:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:00:03 --> Input Class Initialized
INFO - 2018-03-28 18:00:03 --> Language Class Initialized
INFO - 2018-03-28 18:00:03 --> Loader Class Initialized
INFO - 2018-03-28 18:00:03 --> Helper loaded: url_helper
INFO - 2018-03-28 18:00:03 --> Helper loaded: form_helper
INFO - 2018-03-28 18:00:03 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:00:03 --> Controller Class Initialized
INFO - 2018-03-28 18:00:03 --> Model Class Initialized
INFO - 2018-03-28 18:00:03 --> Model Class Initialized
INFO - 2018-03-28 18:00:03 --> Model Class Initialized
INFO - 2018-03-28 18:00:03 --> Model Class Initialized
INFO - 2018-03-28 18:00:03 --> Model Class Initialized
INFO - 2018-03-28 18:00:03 --> Helper loaded: date_helper
INFO - 2018-03-28 18:00:03 --> Config Class Initialized
INFO - 2018-03-28 18:00:03 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:00:03 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:00:03 --> Utf8 Class Initialized
INFO - 2018-03-28 18:00:03 --> URI Class Initialized
INFO - 2018-03-28 18:00:03 --> Router Class Initialized
INFO - 2018-03-28 18:00:03 --> Output Class Initialized
INFO - 2018-03-28 18:00:03 --> Security Class Initialized
DEBUG - 2018-03-28 18:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:00:03 --> Input Class Initialized
INFO - 2018-03-28 18:00:03 --> Language Class Initialized
INFO - 2018-03-28 18:00:03 --> Loader Class Initialized
INFO - 2018-03-28 18:00:03 --> Helper loaded: url_helper
INFO - 2018-03-28 18:00:03 --> Helper loaded: form_helper
INFO - 2018-03-28 18:00:03 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:00:03 --> Controller Class Initialized
INFO - 2018-03-28 18:00:03 --> Model Class Initialized
INFO - 2018-03-28 18:00:03 --> Model Class Initialized
INFO - 2018-03-28 18:00:03 --> Model Class Initialized
INFO - 2018-03-28 18:00:03 --> Model Class Initialized
INFO - 2018-03-28 18:00:03 --> Model Class Initialized
INFO - 2018-03-28 18:00:03 --> Helper loaded: date_helper
INFO - 2018-03-28 23:00:03 --> Model Class Initialized
INFO - 2018-03-28 23:00:03 --> Model Class Initialized
INFO - 2018-03-28 23:00:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:00:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:00:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-28 23:00:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:00:03 --> Final output sent to browser
DEBUG - 2018-03-28 23:00:03 --> Total execution time: 0.1583
INFO - 2018-03-28 18:00:10 --> Config Class Initialized
INFO - 2018-03-28 18:00:10 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:00:10 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:00:10 --> Utf8 Class Initialized
INFO - 2018-03-28 18:00:10 --> URI Class Initialized
INFO - 2018-03-28 18:00:10 --> Router Class Initialized
INFO - 2018-03-28 18:00:10 --> Output Class Initialized
INFO - 2018-03-28 18:00:10 --> Security Class Initialized
DEBUG - 2018-03-28 18:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:00:10 --> Input Class Initialized
INFO - 2018-03-28 18:00:10 --> Language Class Initialized
INFO - 2018-03-28 18:00:10 --> Loader Class Initialized
INFO - 2018-03-28 18:00:10 --> Helper loaded: url_helper
INFO - 2018-03-28 18:00:10 --> Helper loaded: form_helper
INFO - 2018-03-28 18:00:11 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:00:11 --> Controller Class Initialized
INFO - 2018-03-28 18:00:11 --> Model Class Initialized
INFO - 2018-03-28 18:00:11 --> Model Class Initialized
INFO - 2018-03-28 18:00:11 --> Model Class Initialized
INFO - 2018-03-28 18:00:11 --> Helper loaded: date_helper
INFO - 2018-03-28 18:00:11 --> Config Class Initialized
INFO - 2018-03-28 18:00:11 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:00:11 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:00:11 --> Utf8 Class Initialized
INFO - 2018-03-28 18:00:11 --> URI Class Initialized
INFO - 2018-03-28 18:00:11 --> Router Class Initialized
INFO - 2018-03-28 18:00:11 --> Output Class Initialized
INFO - 2018-03-28 18:00:11 --> Security Class Initialized
DEBUG - 2018-03-28 18:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:00:11 --> Input Class Initialized
INFO - 2018-03-28 18:00:11 --> Language Class Initialized
INFO - 2018-03-28 18:00:11 --> Loader Class Initialized
INFO - 2018-03-28 18:00:11 --> Helper loaded: url_helper
INFO - 2018-03-28 18:00:11 --> Helper loaded: form_helper
INFO - 2018-03-28 18:00:11 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:00:11 --> Controller Class Initialized
INFO - 2018-03-28 18:00:11 --> Model Class Initialized
INFO - 2018-03-28 18:00:11 --> Model Class Initialized
INFO - 2018-03-28 18:00:11 --> Model Class Initialized
INFO - 2018-03-28 18:00:11 --> Helper loaded: date_helper
INFO - 2018-03-28 23:00:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-28 23:00:11 --> Final output sent to browser
DEBUG - 2018-03-28 23:00:11 --> Total execution time: 0.1301
INFO - 2018-03-28 18:00:24 --> Config Class Initialized
INFO - 2018-03-28 18:00:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:00:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:00:24 --> Utf8 Class Initialized
INFO - 2018-03-28 18:00:24 --> URI Class Initialized
INFO - 2018-03-28 18:00:24 --> Router Class Initialized
INFO - 2018-03-28 18:00:24 --> Output Class Initialized
INFO - 2018-03-28 18:00:24 --> Security Class Initialized
DEBUG - 2018-03-28 18:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:00:24 --> Input Class Initialized
INFO - 2018-03-28 18:00:24 --> Language Class Initialized
INFO - 2018-03-28 18:00:24 --> Loader Class Initialized
INFO - 2018-03-28 18:00:24 --> Helper loaded: url_helper
INFO - 2018-03-28 18:00:24 --> Helper loaded: form_helper
INFO - 2018-03-28 18:00:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:00:24 --> Controller Class Initialized
INFO - 2018-03-28 18:00:24 --> Model Class Initialized
INFO - 2018-03-28 18:00:24 --> Model Class Initialized
INFO - 2018-03-28 18:00:24 --> Model Class Initialized
INFO - 2018-03-28 18:00:24 --> Helper loaded: date_helper
INFO - 2018-03-28 18:00:24 --> Config Class Initialized
INFO - 2018-03-28 18:00:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:00:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:00:24 --> Utf8 Class Initialized
INFO - 2018-03-28 18:00:24 --> URI Class Initialized
INFO - 2018-03-28 18:00:24 --> Router Class Initialized
INFO - 2018-03-28 18:00:24 --> Output Class Initialized
INFO - 2018-03-28 18:00:24 --> Security Class Initialized
DEBUG - 2018-03-28 18:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:00:24 --> Input Class Initialized
INFO - 2018-03-28 18:00:24 --> Language Class Initialized
INFO - 2018-03-28 18:00:24 --> Loader Class Initialized
INFO - 2018-03-28 18:00:24 --> Helper loaded: url_helper
INFO - 2018-03-28 18:00:24 --> Helper loaded: form_helper
INFO - 2018-03-28 18:00:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:00:24 --> Controller Class Initialized
INFO - 2018-03-28 18:00:24 --> Model Class Initialized
INFO - 2018-03-28 18:00:24 --> Model Class Initialized
INFO - 2018-03-28 18:00:24 --> Model Class Initialized
INFO - 2018-03-28 18:00:24 --> Model Class Initialized
INFO - 2018-03-28 18:00:24 --> Model Class Initialized
INFO - 2018-03-28 18:00:24 --> Helper loaded: date_helper
INFO - 2018-03-28 23:00:24 --> Model Class Initialized
INFO - 2018-03-28 23:00:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:00:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:00:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-28 23:00:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:00:24 --> Final output sent to browser
DEBUG - 2018-03-28 23:00:24 --> Total execution time: 0.1186
INFO - 2018-03-28 18:00:29 --> Config Class Initialized
INFO - 2018-03-28 18:00:29 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:00:29 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:00:29 --> Utf8 Class Initialized
INFO - 2018-03-28 18:00:29 --> URI Class Initialized
INFO - 2018-03-28 18:00:29 --> Router Class Initialized
INFO - 2018-03-28 18:00:29 --> Output Class Initialized
INFO - 2018-03-28 18:00:29 --> Security Class Initialized
DEBUG - 2018-03-28 18:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:00:29 --> Input Class Initialized
INFO - 2018-03-28 18:00:29 --> Language Class Initialized
INFO - 2018-03-28 18:00:29 --> Loader Class Initialized
INFO - 2018-03-28 18:00:29 --> Helper loaded: url_helper
INFO - 2018-03-28 18:00:29 --> Helper loaded: form_helper
INFO - 2018-03-28 18:00:29 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:00:29 --> Controller Class Initialized
INFO - 2018-03-28 18:00:29 --> Model Class Initialized
INFO - 2018-03-28 18:00:29 --> Model Class Initialized
INFO - 2018-03-28 18:00:29 --> Model Class Initialized
INFO - 2018-03-28 18:00:29 --> Model Class Initialized
INFO - 2018-03-28 18:00:29 --> Model Class Initialized
INFO - 2018-03-28 18:00:29 --> Model Class Initialized
INFO - 2018-03-28 18:00:29 --> Model Class Initialized
INFO - 2018-03-28 18:00:29 --> Model Class Initialized
INFO - 2018-03-28 18:00:29 --> Model Class Initialized
INFO - 2018-03-28 18:00:29 --> Model Class Initialized
INFO - 2018-03-28 18:00:29 --> Model Class Initialized
INFO - 2018-03-28 18:00:29 --> Model Class Initialized
INFO - 2018-03-28 18:00:29 --> Model Class Initialized
INFO - 2018-03-28 18:00:29 --> Model Class Initialized
INFO - 2018-03-28 18:00:29 --> Helper loaded: date_helper
INFO - 2018-03-28 18:00:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 23:00:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:00:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:00:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-28 23:00:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:00:29 --> Final output sent to browser
DEBUG - 2018-03-28 23:00:29 --> Total execution time: 0.1422
INFO - 2018-03-28 18:04:49 --> Config Class Initialized
INFO - 2018-03-28 18:04:49 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:04:49 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:04:49 --> Utf8 Class Initialized
INFO - 2018-03-28 18:04:49 --> URI Class Initialized
INFO - 2018-03-28 18:04:49 --> Router Class Initialized
INFO - 2018-03-28 18:04:49 --> Output Class Initialized
INFO - 2018-03-28 18:04:49 --> Security Class Initialized
DEBUG - 2018-03-28 18:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:04:49 --> Input Class Initialized
INFO - 2018-03-28 18:04:49 --> Language Class Initialized
INFO - 2018-03-28 18:04:49 --> Loader Class Initialized
INFO - 2018-03-28 18:04:49 --> Helper loaded: url_helper
INFO - 2018-03-28 18:04:49 --> Helper loaded: form_helper
INFO - 2018-03-28 18:04:49 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:04:49 --> Controller Class Initialized
INFO - 2018-03-28 18:04:49 --> Model Class Initialized
INFO - 2018-03-28 18:04:49 --> Model Class Initialized
INFO - 2018-03-28 18:04:49 --> Model Class Initialized
INFO - 2018-03-28 18:04:49 --> Helper loaded: date_helper
INFO - 2018-03-28 18:04:49 --> Config Class Initialized
INFO - 2018-03-28 18:04:49 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:04:49 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:04:49 --> Utf8 Class Initialized
INFO - 2018-03-28 18:04:49 --> URI Class Initialized
INFO - 2018-03-28 18:04:49 --> Router Class Initialized
INFO - 2018-03-28 18:04:49 --> Output Class Initialized
INFO - 2018-03-28 18:04:49 --> Security Class Initialized
DEBUG - 2018-03-28 18:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:04:49 --> Input Class Initialized
INFO - 2018-03-28 18:04:49 --> Language Class Initialized
INFO - 2018-03-28 18:04:49 --> Loader Class Initialized
INFO - 2018-03-28 18:04:49 --> Helper loaded: url_helper
INFO - 2018-03-28 18:04:49 --> Helper loaded: form_helper
INFO - 2018-03-28 18:04:49 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:04:49 --> Controller Class Initialized
INFO - 2018-03-28 18:04:49 --> Model Class Initialized
INFO - 2018-03-28 18:04:49 --> Model Class Initialized
INFO - 2018-03-28 18:04:49 --> Model Class Initialized
INFO - 2018-03-28 18:04:49 --> Helper loaded: date_helper
INFO - 2018-03-28 23:04:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-28 23:04:49 --> Final output sent to browser
DEBUG - 2018-03-28 23:04:49 --> Total execution time: 0.1126
INFO - 2018-03-28 18:04:59 --> Config Class Initialized
INFO - 2018-03-28 18:04:59 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:04:59 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:04:59 --> Utf8 Class Initialized
INFO - 2018-03-28 18:04:59 --> URI Class Initialized
INFO - 2018-03-28 18:04:59 --> Router Class Initialized
INFO - 2018-03-28 18:04:59 --> Output Class Initialized
INFO - 2018-03-28 18:04:59 --> Security Class Initialized
DEBUG - 2018-03-28 18:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:04:59 --> Input Class Initialized
INFO - 2018-03-28 18:04:59 --> Language Class Initialized
INFO - 2018-03-28 18:04:59 --> Loader Class Initialized
INFO - 2018-03-28 18:04:59 --> Helper loaded: url_helper
INFO - 2018-03-28 18:04:59 --> Helper loaded: form_helper
INFO - 2018-03-28 18:04:59 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:04:59 --> Controller Class Initialized
INFO - 2018-03-28 18:04:59 --> Model Class Initialized
INFO - 2018-03-28 18:04:59 --> Model Class Initialized
INFO - 2018-03-28 18:04:59 --> Model Class Initialized
INFO - 2018-03-28 18:04:59 --> Helper loaded: date_helper
INFO - 2018-03-28 18:04:59 --> Config Class Initialized
INFO - 2018-03-28 18:04:59 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:04:59 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:04:59 --> Utf8 Class Initialized
INFO - 2018-03-28 18:04:59 --> URI Class Initialized
INFO - 2018-03-28 18:04:59 --> Router Class Initialized
INFO - 2018-03-28 18:04:59 --> Output Class Initialized
INFO - 2018-03-28 18:04:59 --> Security Class Initialized
DEBUG - 2018-03-28 18:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:04:59 --> Input Class Initialized
INFO - 2018-03-28 18:04:59 --> Language Class Initialized
INFO - 2018-03-28 18:04:59 --> Loader Class Initialized
INFO - 2018-03-28 18:04:59 --> Helper loaded: url_helper
INFO - 2018-03-28 18:04:59 --> Helper loaded: form_helper
INFO - 2018-03-28 18:04:59 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:04:59 --> Controller Class Initialized
INFO - 2018-03-28 18:04:59 --> Model Class Initialized
INFO - 2018-03-28 18:04:59 --> Model Class Initialized
INFO - 2018-03-28 18:04:59 --> Model Class Initialized
INFO - 2018-03-28 18:04:59 --> Model Class Initialized
INFO - 2018-03-28 18:04:59 --> Model Class Initialized
INFO - 2018-03-28 18:04:59 --> Helper loaded: date_helper
INFO - 2018-03-28 23:04:59 --> Model Class Initialized
INFO - 2018-03-28 23:04:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:04:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:04:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-28 23:04:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:04:59 --> Final output sent to browser
DEBUG - 2018-03-28 23:04:59 --> Total execution time: 0.1758
INFO - 2018-03-28 18:05:08 --> Config Class Initialized
INFO - 2018-03-28 18:05:08 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:05:08 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:05:08 --> Utf8 Class Initialized
INFO - 2018-03-28 18:05:08 --> URI Class Initialized
INFO - 2018-03-28 18:05:08 --> Router Class Initialized
INFO - 2018-03-28 18:05:08 --> Output Class Initialized
INFO - 2018-03-28 18:05:08 --> Security Class Initialized
DEBUG - 2018-03-28 18:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:05:08 --> Input Class Initialized
INFO - 2018-03-28 18:05:08 --> Language Class Initialized
INFO - 2018-03-28 18:05:08 --> Loader Class Initialized
INFO - 2018-03-28 18:05:08 --> Helper loaded: url_helper
INFO - 2018-03-28 18:05:08 --> Helper loaded: form_helper
INFO - 2018-03-28 18:05:08 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:05:08 --> Controller Class Initialized
INFO - 2018-03-28 18:05:08 --> Model Class Initialized
INFO - 2018-03-28 18:05:08 --> Model Class Initialized
INFO - 2018-03-28 18:05:08 --> Helper loaded: date_helper
INFO - 2018-03-28 18:05:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 23:05:08 --> Model Class Initialized
INFO - 2018-03-28 23:05:08 --> Model Class Initialized
INFO - 2018-03-28 23:05:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:05:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:05:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/table.php
INFO - 2018-03-28 23:05:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:05:08 --> Final output sent to browser
DEBUG - 2018-03-28 23:05:08 --> Total execution time: 0.1115
INFO - 2018-03-28 18:05:14 --> Config Class Initialized
INFO - 2018-03-28 18:05:14 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:05:14 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:05:14 --> Utf8 Class Initialized
INFO - 2018-03-28 18:05:14 --> URI Class Initialized
INFO - 2018-03-28 18:05:14 --> Router Class Initialized
INFO - 2018-03-28 18:05:14 --> Output Class Initialized
INFO - 2018-03-28 18:05:14 --> Security Class Initialized
DEBUG - 2018-03-28 18:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:05:14 --> Input Class Initialized
INFO - 2018-03-28 18:05:14 --> Language Class Initialized
INFO - 2018-03-28 18:05:14 --> Loader Class Initialized
INFO - 2018-03-28 18:05:14 --> Helper loaded: url_helper
INFO - 2018-03-28 18:05:14 --> Helper loaded: form_helper
INFO - 2018-03-28 18:05:14 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:05:14 --> Controller Class Initialized
INFO - 2018-03-28 18:05:14 --> Model Class Initialized
INFO - 2018-03-28 18:05:14 --> Model Class Initialized
INFO - 2018-03-28 18:05:14 --> Helper loaded: date_helper
INFO - 2018-03-28 18:05:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 23:05:14 --> Model Class Initialized
INFO - 2018-03-28 23:05:14 --> Model Class Initialized
INFO - 2018-03-28 23:05:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:05:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:05:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/user/table.php
INFO - 2018-03-28 23:05:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:05:14 --> Final output sent to browser
DEBUG - 2018-03-28 23:05:14 --> Total execution time: 0.1512
INFO - 2018-03-28 18:05:24 --> Config Class Initialized
INFO - 2018-03-28 18:05:24 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:05:24 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:05:24 --> Utf8 Class Initialized
INFO - 2018-03-28 18:05:24 --> URI Class Initialized
INFO - 2018-03-28 18:05:24 --> Router Class Initialized
INFO - 2018-03-28 18:05:24 --> Output Class Initialized
INFO - 2018-03-28 18:05:24 --> Security Class Initialized
DEBUG - 2018-03-28 18:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:05:24 --> Input Class Initialized
INFO - 2018-03-28 18:05:24 --> Language Class Initialized
INFO - 2018-03-28 18:05:24 --> Loader Class Initialized
INFO - 2018-03-28 18:05:24 --> Helper loaded: url_helper
INFO - 2018-03-28 18:05:24 --> Helper loaded: form_helper
INFO - 2018-03-28 18:05:24 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:05:24 --> Controller Class Initialized
INFO - 2018-03-28 18:05:24 --> Model Class Initialized
INFO - 2018-03-28 18:05:24 --> Model Class Initialized
INFO - 2018-03-28 18:05:24 --> Helper loaded: date_helper
INFO - 2018-03-28 23:05:24 --> Model Class Initialized
INFO - 2018-03-28 23:05:24 --> Model Class Initialized
INFO - 2018-03-28 23:05:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:05:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:05:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/group/table.php
INFO - 2018-03-28 23:05:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:05:24 --> Final output sent to browser
DEBUG - 2018-03-28 23:05:24 --> Total execution time: 0.1128
INFO - 2018-03-28 18:05:30 --> Config Class Initialized
INFO - 2018-03-28 18:05:30 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:05:30 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:05:30 --> Utf8 Class Initialized
INFO - 2018-03-28 18:05:30 --> URI Class Initialized
INFO - 2018-03-28 18:05:30 --> Router Class Initialized
INFO - 2018-03-28 18:05:30 --> Output Class Initialized
INFO - 2018-03-28 18:05:30 --> Security Class Initialized
DEBUG - 2018-03-28 18:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:05:30 --> Input Class Initialized
INFO - 2018-03-28 18:05:30 --> Language Class Initialized
INFO - 2018-03-28 18:05:30 --> Loader Class Initialized
INFO - 2018-03-28 18:05:30 --> Helper loaded: url_helper
INFO - 2018-03-28 18:05:30 --> Helper loaded: form_helper
INFO - 2018-03-28 18:05:30 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:05:30 --> Controller Class Initialized
INFO - 2018-03-28 18:05:30 --> Model Class Initialized
INFO - 2018-03-28 18:05:30 --> Model Class Initialized
INFO - 2018-03-28 18:05:30 --> Model Class Initialized
INFO - 2018-03-28 18:05:30 --> Model Class Initialized
INFO - 2018-03-28 18:05:30 --> Model Class Initialized
INFO - 2018-03-28 18:05:30 --> Helper loaded: date_helper
INFO - 2018-03-28 23:05:30 --> Model Class Initialized
INFO - 2018-03-28 23:05:30 --> Model Class Initialized
INFO - 2018-03-28 23:05:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:05:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:05:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-28 23:05:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:05:31 --> Final output sent to browser
DEBUG - 2018-03-28 23:05:31 --> Total execution time: 0.1436
INFO - 2018-03-28 18:06:01 --> Config Class Initialized
INFO - 2018-03-28 18:06:01 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:06:01 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:06:01 --> Utf8 Class Initialized
INFO - 2018-03-28 18:06:01 --> URI Class Initialized
INFO - 2018-03-28 18:06:01 --> Router Class Initialized
INFO - 2018-03-28 18:06:01 --> Output Class Initialized
INFO - 2018-03-28 18:06:01 --> Security Class Initialized
DEBUG - 2018-03-28 18:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:06:01 --> Input Class Initialized
INFO - 2018-03-28 18:06:01 --> Language Class Initialized
INFO - 2018-03-28 18:06:01 --> Loader Class Initialized
INFO - 2018-03-28 18:06:01 --> Helper loaded: url_helper
INFO - 2018-03-28 18:06:01 --> Helper loaded: form_helper
INFO - 2018-03-28 18:06:01 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:06:01 --> Controller Class Initialized
INFO - 2018-03-28 18:06:01 --> Model Class Initialized
INFO - 2018-03-28 18:06:01 --> Model Class Initialized
INFO - 2018-03-28 18:06:01 --> Model Class Initialized
INFO - 2018-03-28 18:06:01 --> Model Class Initialized
INFO - 2018-03-28 18:06:01 --> Model Class Initialized
INFO - 2018-03-28 18:06:01 --> Helper loaded: date_helper
INFO - 2018-03-28 23:06:01 --> Model Class Initialized
INFO - 2018-03-28 23:06:01 --> Model Class Initialized
INFO - 2018-03-28 23:06:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:06:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:06:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-28 23:06:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:06:01 --> Final output sent to browser
DEBUG - 2018-03-28 23:06:01 --> Total execution time: 0.1060
INFO - 2018-03-28 18:06:11 --> Config Class Initialized
INFO - 2018-03-28 18:06:11 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:06:11 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:06:11 --> Utf8 Class Initialized
INFO - 2018-03-28 18:06:11 --> URI Class Initialized
INFO - 2018-03-28 18:06:11 --> Router Class Initialized
INFO - 2018-03-28 18:06:11 --> Output Class Initialized
INFO - 2018-03-28 18:06:11 --> Security Class Initialized
DEBUG - 2018-03-28 18:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:06:11 --> Input Class Initialized
INFO - 2018-03-28 18:06:11 --> Language Class Initialized
INFO - 2018-03-28 18:06:11 --> Loader Class Initialized
INFO - 2018-03-28 18:06:11 --> Helper loaded: url_helper
INFO - 2018-03-28 18:06:11 --> Helper loaded: form_helper
INFO - 2018-03-28 18:06:11 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:06:11 --> Controller Class Initialized
INFO - 2018-03-28 18:06:11 --> Model Class Initialized
INFO - 2018-03-28 18:06:11 --> Model Class Initialized
INFO - 2018-03-28 18:06:11 --> Model Class Initialized
INFO - 2018-03-28 18:06:11 --> Model Class Initialized
INFO - 2018-03-28 18:06:11 --> Model Class Initialized
INFO - 2018-03-28 18:06:11 --> Helper loaded: date_helper
INFO - 2018-03-28 23:06:11 --> Model Class Initialized
INFO - 2018-03-28 23:06:11 --> Model Class Initialized
INFO - 2018-03-28 23:06:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:06:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:06:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/create.php
INFO - 2018-03-28 23:06:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:06:11 --> Final output sent to browser
DEBUG - 2018-03-28 23:06:11 --> Total execution time: 0.1239
INFO - 2018-03-28 18:06:22 --> Config Class Initialized
INFO - 2018-03-28 18:06:22 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:06:22 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:06:22 --> Utf8 Class Initialized
INFO - 2018-03-28 18:06:22 --> URI Class Initialized
INFO - 2018-03-28 18:06:22 --> Router Class Initialized
INFO - 2018-03-28 18:06:22 --> Output Class Initialized
INFO - 2018-03-28 18:06:22 --> Security Class Initialized
DEBUG - 2018-03-28 18:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:06:22 --> Input Class Initialized
INFO - 2018-03-28 18:06:22 --> Language Class Initialized
INFO - 2018-03-28 18:06:22 --> Loader Class Initialized
INFO - 2018-03-28 18:06:22 --> Helper loaded: url_helper
INFO - 2018-03-28 18:06:22 --> Helper loaded: form_helper
INFO - 2018-03-28 18:06:22 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:06:22 --> Controller Class Initialized
INFO - 2018-03-28 18:06:22 --> Model Class Initialized
INFO - 2018-03-28 18:06:22 --> Model Class Initialized
INFO - 2018-03-28 18:06:22 --> Model Class Initialized
INFO - 2018-03-28 18:06:22 --> Model Class Initialized
INFO - 2018-03-28 18:06:22 --> Model Class Initialized
INFO - 2018-03-28 18:06:22 --> Helper loaded: date_helper
INFO - 2018-03-28 23:06:22 --> Model Class Initialized
INFO - 2018-03-28 23:06:22 --> Model Class Initialized
INFO - 2018-03-28 23:06:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:06:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:06:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/group_akses/table.php
INFO - 2018-03-28 23:06:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:06:22 --> Final output sent to browser
DEBUG - 2018-03-28 23:06:22 --> Total execution time: 0.1149
INFO - 2018-03-28 18:06:25 --> Config Class Initialized
INFO - 2018-03-28 18:06:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:06:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:06:25 --> Utf8 Class Initialized
INFO - 2018-03-28 18:06:25 --> URI Class Initialized
INFO - 2018-03-28 18:06:25 --> Router Class Initialized
INFO - 2018-03-28 18:06:25 --> Output Class Initialized
INFO - 2018-03-28 18:06:25 --> Security Class Initialized
DEBUG - 2018-03-28 18:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:06:25 --> Input Class Initialized
INFO - 2018-03-28 18:06:25 --> Language Class Initialized
INFO - 2018-03-28 18:06:25 --> Loader Class Initialized
INFO - 2018-03-28 18:06:25 --> Helper loaded: url_helper
INFO - 2018-03-28 18:06:25 --> Helper loaded: form_helper
INFO - 2018-03-28 18:06:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:06:26 --> Controller Class Initialized
INFO - 2018-03-28 18:06:26 --> Model Class Initialized
INFO - 2018-03-28 18:06:26 --> Model Class Initialized
INFO - 2018-03-28 18:06:26 --> Model Class Initialized
INFO - 2018-03-28 18:06:26 --> Model Class Initialized
INFO - 2018-03-28 18:06:26 --> Model Class Initialized
INFO - 2018-03-28 18:06:26 --> Helper loaded: date_helper
INFO - 2018-03-28 23:06:26 --> Model Class Initialized
INFO - 2018-03-28 23:06:26 --> Model Class Initialized
INFO - 2018-03-28 23:06:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:06:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:06:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/group_akses/create.php
INFO - 2018-03-28 23:06:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:06:26 --> Final output sent to browser
DEBUG - 2018-03-28 23:06:26 --> Total execution time: 0.1679
INFO - 2018-03-28 18:07:11 --> Config Class Initialized
INFO - 2018-03-28 18:07:11 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:07:11 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:07:11 --> Utf8 Class Initialized
INFO - 2018-03-28 18:07:11 --> URI Class Initialized
INFO - 2018-03-28 18:07:11 --> Router Class Initialized
INFO - 2018-03-28 18:07:11 --> Output Class Initialized
INFO - 2018-03-28 18:07:11 --> Security Class Initialized
DEBUG - 2018-03-28 18:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:07:11 --> Input Class Initialized
INFO - 2018-03-28 18:07:11 --> Language Class Initialized
INFO - 2018-03-28 18:07:11 --> Loader Class Initialized
INFO - 2018-03-28 18:07:11 --> Helper loaded: url_helper
INFO - 2018-03-28 18:07:11 --> Helper loaded: form_helper
INFO - 2018-03-28 18:07:11 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:07:11 --> Controller Class Initialized
INFO - 2018-03-28 18:07:11 --> Model Class Initialized
INFO - 2018-03-28 18:07:11 --> Model Class Initialized
INFO - 2018-03-28 18:07:11 --> Model Class Initialized
INFO - 2018-03-28 18:07:11 --> Model Class Initialized
INFO - 2018-03-28 18:07:11 --> Model Class Initialized
INFO - 2018-03-28 18:07:11 --> Model Class Initialized
INFO - 2018-03-28 18:07:11 --> Model Class Initialized
INFO - 2018-03-28 18:07:11 --> Helper loaded: date_helper
INFO - 2018-03-28 18:07:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 23:07:11 --> Model Class Initialized
INFO - 2018-03-28 23:07:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:07:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:07:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-28 23:07:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:07:11 --> Final output sent to browser
DEBUG - 2018-03-28 23:07:11 --> Total execution time: 0.1390
INFO - 2018-03-28 18:07:15 --> Config Class Initialized
INFO - 2018-03-28 18:07:15 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:07:15 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:07:15 --> Utf8 Class Initialized
INFO - 2018-03-28 18:07:15 --> URI Class Initialized
INFO - 2018-03-28 18:07:15 --> Router Class Initialized
INFO - 2018-03-28 18:07:15 --> Output Class Initialized
INFO - 2018-03-28 18:07:15 --> Security Class Initialized
DEBUG - 2018-03-28 18:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:07:15 --> Input Class Initialized
INFO - 2018-03-28 18:07:15 --> Language Class Initialized
ERROR - 2018-03-28 18:07:15 --> 404 Page Not Found: gudang/Penjualan/print
INFO - 2018-03-28 18:07:18 --> Config Class Initialized
INFO - 2018-03-28 18:07:18 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:07:18 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:07:18 --> Utf8 Class Initialized
INFO - 2018-03-28 18:07:18 --> URI Class Initialized
INFO - 2018-03-28 18:07:18 --> Router Class Initialized
INFO - 2018-03-28 18:07:18 --> Output Class Initialized
INFO - 2018-03-28 18:07:18 --> Security Class Initialized
DEBUG - 2018-03-28 18:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:07:18 --> Input Class Initialized
INFO - 2018-03-28 18:07:18 --> Language Class Initialized
INFO - 2018-03-28 18:07:18 --> Loader Class Initialized
INFO - 2018-03-28 18:07:18 --> Helper loaded: url_helper
INFO - 2018-03-28 18:07:18 --> Helper loaded: form_helper
INFO - 2018-03-28 18:07:18 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:07:18 --> Controller Class Initialized
INFO - 2018-03-28 18:07:18 --> Model Class Initialized
INFO - 2018-03-28 18:07:18 --> Model Class Initialized
INFO - 2018-03-28 18:07:18 --> Model Class Initialized
INFO - 2018-03-28 18:07:18 --> Model Class Initialized
INFO - 2018-03-28 18:07:18 --> Model Class Initialized
INFO - 2018-03-28 18:07:18 --> Model Class Initialized
INFO - 2018-03-28 18:07:18 --> Model Class Initialized
INFO - 2018-03-28 18:07:18 --> Helper loaded: date_helper
INFO - 2018-03-28 18:07:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 23:07:18 --> Model Class Initialized
INFO - 2018-03-28 23:07:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:07:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:07:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-28 23:07:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:07:18 --> Final output sent to browser
DEBUG - 2018-03-28 23:07:18 --> Total execution time: 0.1489
INFO - 2018-03-28 18:07:21 --> Config Class Initialized
INFO - 2018-03-28 18:07:21 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:07:21 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:07:21 --> Utf8 Class Initialized
INFO - 2018-03-28 18:07:21 --> URI Class Initialized
INFO - 2018-03-28 18:07:21 --> Router Class Initialized
INFO - 2018-03-28 18:07:21 --> Output Class Initialized
INFO - 2018-03-28 18:07:21 --> Security Class Initialized
DEBUG - 2018-03-28 18:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:07:21 --> Input Class Initialized
INFO - 2018-03-28 18:07:21 --> Language Class Initialized
INFO - 2018-03-28 18:07:21 --> Loader Class Initialized
INFO - 2018-03-28 18:07:21 --> Helper loaded: url_helper
INFO - 2018-03-28 18:07:21 --> Helper loaded: form_helper
INFO - 2018-03-28 18:07:21 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:07:21 --> Controller Class Initialized
INFO - 2018-03-28 18:07:21 --> Model Class Initialized
INFO - 2018-03-28 18:07:21 --> Model Class Initialized
INFO - 2018-03-28 18:07:21 --> Model Class Initialized
INFO - 2018-03-28 18:07:21 --> Model Class Initialized
INFO - 2018-03-28 18:07:21 --> Model Class Initialized
INFO - 2018-03-28 18:07:21 --> Model Class Initialized
INFO - 2018-03-28 18:07:21 --> Model Class Initialized
INFO - 2018-03-28 18:07:21 --> Helper loaded: date_helper
INFO - 2018-03-28 18:07:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 23:07:21 --> Model Class Initialized
INFO - 2018-03-28 23:07:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:07:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:07:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-28 23:07:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:07:21 --> Final output sent to browser
DEBUG - 2018-03-28 23:07:21 --> Total execution time: 0.1243
INFO - 2018-03-28 18:07:23 --> Config Class Initialized
INFO - 2018-03-28 18:07:23 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:07:23 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:07:23 --> Utf8 Class Initialized
INFO - 2018-03-28 18:07:23 --> URI Class Initialized
INFO - 2018-03-28 18:07:23 --> Router Class Initialized
INFO - 2018-03-28 18:07:23 --> Output Class Initialized
INFO - 2018-03-28 18:07:23 --> Security Class Initialized
DEBUG - 2018-03-28 18:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:07:23 --> Input Class Initialized
INFO - 2018-03-28 18:07:23 --> Language Class Initialized
ERROR - 2018-03-28 18:07:23 --> 404 Page Not Found: gudang/Penjualan/print
INFO - 2018-03-28 18:07:25 --> Config Class Initialized
INFO - 2018-03-28 18:07:25 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:07:25 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:07:25 --> Utf8 Class Initialized
INFO - 2018-03-28 18:07:25 --> URI Class Initialized
INFO - 2018-03-28 18:07:25 --> Router Class Initialized
INFO - 2018-03-28 18:07:25 --> Output Class Initialized
INFO - 2018-03-28 18:07:25 --> Security Class Initialized
DEBUG - 2018-03-28 18:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:07:25 --> Input Class Initialized
INFO - 2018-03-28 18:07:25 --> Language Class Initialized
INFO - 2018-03-28 18:07:25 --> Loader Class Initialized
INFO - 2018-03-28 18:07:25 --> Helper loaded: url_helper
INFO - 2018-03-28 18:07:25 --> Helper loaded: form_helper
INFO - 2018-03-28 18:07:25 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:07:25 --> Controller Class Initialized
INFO - 2018-03-28 18:07:25 --> Model Class Initialized
INFO - 2018-03-28 18:07:25 --> Model Class Initialized
INFO - 2018-03-28 18:07:25 --> Model Class Initialized
INFO - 2018-03-28 18:07:25 --> Model Class Initialized
INFO - 2018-03-28 18:07:25 --> Model Class Initialized
INFO - 2018-03-28 18:07:25 --> Model Class Initialized
INFO - 2018-03-28 18:07:25 --> Model Class Initialized
INFO - 2018-03-28 18:07:25 --> Helper loaded: date_helper
INFO - 2018-03-28 18:07:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 23:07:25 --> Model Class Initialized
INFO - 2018-03-28 23:07:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:07:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:07:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/detail.php
INFO - 2018-03-28 23:07:25 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:07:25 --> Final output sent to browser
DEBUG - 2018-03-28 23:07:25 --> Total execution time: 0.1312
INFO - 2018-03-28 18:08:37 --> Config Class Initialized
INFO - 2018-03-28 18:08:37 --> Hooks Class Initialized
DEBUG - 2018-03-28 18:08:37 --> UTF-8 Support Enabled
INFO - 2018-03-28 18:08:37 --> Utf8 Class Initialized
INFO - 2018-03-28 18:08:37 --> URI Class Initialized
INFO - 2018-03-28 18:08:37 --> Router Class Initialized
INFO - 2018-03-28 18:08:37 --> Output Class Initialized
INFO - 2018-03-28 18:08:37 --> Security Class Initialized
DEBUG - 2018-03-28 18:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-28 18:08:37 --> Input Class Initialized
INFO - 2018-03-28 18:08:37 --> Language Class Initialized
INFO - 2018-03-28 18:08:37 --> Loader Class Initialized
INFO - 2018-03-28 18:08:37 --> Helper loaded: url_helper
INFO - 2018-03-28 18:08:37 --> Helper loaded: form_helper
INFO - 2018-03-28 18:08:37 --> Database Driver Class Initialized
DEBUG - 2018-03-28 18:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-28 18:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-28 18:08:37 --> Controller Class Initialized
INFO - 2018-03-28 18:08:37 --> Model Class Initialized
INFO - 2018-03-28 18:08:37 --> Model Class Initialized
INFO - 2018-03-28 18:08:37 --> Model Class Initialized
INFO - 2018-03-28 18:08:37 --> Model Class Initialized
INFO - 2018-03-28 18:08:37 --> Model Class Initialized
INFO - 2018-03-28 18:08:37 --> Model Class Initialized
INFO - 2018-03-28 18:08:37 --> Model Class Initialized
INFO - 2018-03-28 18:08:37 --> Model Class Initialized
INFO - 2018-03-28 18:08:37 --> Model Class Initialized
INFO - 2018-03-28 18:08:37 --> Model Class Initialized
INFO - 2018-03-28 18:08:37 --> Helper loaded: date_helper
INFO - 2018-03-28 18:08:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-28 23:08:37 --> Model Class Initialized
INFO - 2018-03-28 23:08:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-28 23:08:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-28 23:08:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-28 23:08:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-28 23:08:37 --> Final output sent to browser
DEBUG - 2018-03-28 23:08:37 --> Total execution time: 0.1447
