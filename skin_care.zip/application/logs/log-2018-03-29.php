<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-29 16:16:15 --> Config Class Initialized
INFO - 2018-03-29 16:16:15 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:16:15 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:16:15 --> Utf8 Class Initialized
INFO - 2018-03-29 16:16:15 --> URI Class Initialized
DEBUG - 2018-03-29 16:16:16 --> No URI present. Default controller set.
INFO - 2018-03-29 16:16:16 --> Router Class Initialized
INFO - 2018-03-29 16:16:16 --> Output Class Initialized
INFO - 2018-03-29 16:16:16 --> Security Class Initialized
DEBUG - 2018-03-29 16:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:16:16 --> Input Class Initialized
INFO - 2018-03-29 16:16:16 --> Language Class Initialized
INFO - 2018-03-29 16:16:16 --> Loader Class Initialized
INFO - 2018-03-29 16:16:16 --> Helper loaded: url_helper
INFO - 2018-03-29 16:16:16 --> Helper loaded: form_helper
INFO - 2018-03-29 16:16:16 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:16:16 --> Controller Class Initialized
INFO - 2018-03-29 16:16:16 --> Model Class Initialized
INFO - 2018-03-29 16:16:16 --> Model Class Initialized
INFO - 2018-03-29 16:16:16 --> Model Class Initialized
INFO - 2018-03-29 16:16:16 --> Helper loaded: date_helper
INFO - 2018-03-29 21:16:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-29 21:16:16 --> Final output sent to browser
DEBUG - 2018-03-29 21:16:16 --> Total execution time: 0.5250
INFO - 2018-03-29 16:16:21 --> Config Class Initialized
INFO - 2018-03-29 16:16:21 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:16:21 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:16:21 --> Utf8 Class Initialized
INFO - 2018-03-29 16:16:21 --> URI Class Initialized
DEBUG - 2018-03-29 16:16:21 --> No URI present. Default controller set.
INFO - 2018-03-29 16:16:21 --> Router Class Initialized
INFO - 2018-03-29 16:16:21 --> Output Class Initialized
INFO - 2018-03-29 16:16:21 --> Security Class Initialized
DEBUG - 2018-03-29 16:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:16:21 --> Input Class Initialized
INFO - 2018-03-29 16:16:21 --> Language Class Initialized
INFO - 2018-03-29 16:16:21 --> Loader Class Initialized
INFO - 2018-03-29 16:16:21 --> Helper loaded: url_helper
INFO - 2018-03-29 16:16:21 --> Helper loaded: form_helper
INFO - 2018-03-29 16:16:21 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:16:21 --> Controller Class Initialized
INFO - 2018-03-29 16:16:21 --> Model Class Initialized
INFO - 2018-03-29 16:16:21 --> Model Class Initialized
INFO - 2018-03-29 16:16:21 --> Model Class Initialized
INFO - 2018-03-29 16:16:21 --> Helper loaded: date_helper
INFO - 2018-03-29 16:16:21 --> Config Class Initialized
INFO - 2018-03-29 16:16:21 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:16:21 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:16:21 --> Utf8 Class Initialized
INFO - 2018-03-29 16:16:21 --> URI Class Initialized
INFO - 2018-03-29 16:16:21 --> Router Class Initialized
INFO - 2018-03-29 16:16:21 --> Output Class Initialized
INFO - 2018-03-29 16:16:21 --> Security Class Initialized
DEBUG - 2018-03-29 16:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:16:21 --> Input Class Initialized
INFO - 2018-03-29 16:16:21 --> Language Class Initialized
INFO - 2018-03-29 16:16:21 --> Loader Class Initialized
INFO - 2018-03-29 16:16:21 --> Helper loaded: url_helper
INFO - 2018-03-29 16:16:21 --> Helper loaded: form_helper
INFO - 2018-03-29 16:16:21 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:16:21 --> Controller Class Initialized
INFO - 2018-03-29 16:16:21 --> Model Class Initialized
INFO - 2018-03-29 16:16:21 --> Model Class Initialized
INFO - 2018-03-29 16:16:21 --> Model Class Initialized
INFO - 2018-03-29 16:16:21 --> Model Class Initialized
INFO - 2018-03-29 16:16:21 --> Model Class Initialized
INFO - 2018-03-29 16:16:21 --> Helper loaded: date_helper
INFO - 2018-03-29 21:16:21 --> Model Class Initialized
INFO - 2018-03-29 21:16:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 21:16:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 21:16:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-29 21:16:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 21:16:21 --> Final output sent to browser
DEBUG - 2018-03-29 21:16:21 --> Total execution time: 0.2643
INFO - 2018-03-29 16:34:54 --> Config Class Initialized
INFO - 2018-03-29 16:34:54 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:34:54 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:34:54 --> Utf8 Class Initialized
INFO - 2018-03-29 16:34:54 --> URI Class Initialized
DEBUG - 2018-03-29 16:34:54 --> No URI present. Default controller set.
INFO - 2018-03-29 16:34:54 --> Router Class Initialized
INFO - 2018-03-29 16:34:54 --> Output Class Initialized
INFO - 2018-03-29 16:34:54 --> Security Class Initialized
DEBUG - 2018-03-29 16:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:34:54 --> Input Class Initialized
INFO - 2018-03-29 16:34:54 --> Language Class Initialized
INFO - 2018-03-29 16:34:54 --> Loader Class Initialized
INFO - 2018-03-29 16:34:54 --> Helper loaded: url_helper
INFO - 2018-03-29 16:34:54 --> Helper loaded: form_helper
INFO - 2018-03-29 16:34:54 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:34:54 --> Controller Class Initialized
INFO - 2018-03-29 16:34:54 --> Model Class Initialized
INFO - 2018-03-29 16:34:54 --> Model Class Initialized
INFO - 2018-03-29 16:34:54 --> Model Class Initialized
INFO - 2018-03-29 16:34:54 --> Helper loaded: date_helper
INFO - 2018-03-29 21:34:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-29 21:34:54 --> Final output sent to browser
DEBUG - 2018-03-29 21:34:54 --> Total execution time: 0.0538
INFO - 2018-03-29 16:35:04 --> Config Class Initialized
INFO - 2018-03-29 16:35:04 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:35:04 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:35:04 --> Utf8 Class Initialized
INFO - 2018-03-29 16:35:04 --> URI Class Initialized
INFO - 2018-03-29 16:35:04 --> Router Class Initialized
INFO - 2018-03-29 16:35:04 --> Output Class Initialized
INFO - 2018-03-29 16:35:04 --> Security Class Initialized
DEBUG - 2018-03-29 16:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:35:04 --> Input Class Initialized
INFO - 2018-03-29 16:35:04 --> Language Class Initialized
INFO - 2018-03-29 16:35:04 --> Loader Class Initialized
INFO - 2018-03-29 16:35:04 --> Helper loaded: url_helper
INFO - 2018-03-29 16:35:04 --> Helper loaded: form_helper
INFO - 2018-03-29 16:35:04 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:35:04 --> Controller Class Initialized
INFO - 2018-03-29 16:35:04 --> Model Class Initialized
INFO - 2018-03-29 16:35:04 --> Model Class Initialized
INFO - 2018-03-29 16:35:04 --> Model Class Initialized
INFO - 2018-03-29 16:35:04 --> Model Class Initialized
INFO - 2018-03-29 16:35:04 --> Model Class Initialized
INFO - 2018-03-29 16:35:04 --> Helper loaded: date_helper
INFO - 2018-03-29 21:35:04 --> Model Class Initialized
INFO - 2018-03-29 21:35:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 21:35:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 21:35:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-29 21:35:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 21:35:04 --> Final output sent to browser
DEBUG - 2018-03-29 21:35:04 --> Total execution time: 0.0657
INFO - 2018-03-29 16:35:08 --> Config Class Initialized
INFO - 2018-03-29 16:35:08 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:35:08 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:35:08 --> Utf8 Class Initialized
INFO - 2018-03-29 16:35:08 --> URI Class Initialized
INFO - 2018-03-29 16:35:08 --> Router Class Initialized
INFO - 2018-03-29 16:35:08 --> Output Class Initialized
INFO - 2018-03-29 16:35:08 --> Security Class Initialized
DEBUG - 2018-03-29 16:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:35:08 --> Input Class Initialized
INFO - 2018-03-29 16:35:08 --> Language Class Initialized
INFO - 2018-03-29 16:35:08 --> Loader Class Initialized
INFO - 2018-03-29 16:35:08 --> Helper loaded: url_helper
INFO - 2018-03-29 16:35:08 --> Helper loaded: form_helper
INFO - 2018-03-29 16:35:08 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:35:08 --> Controller Class Initialized
INFO - 2018-03-29 16:35:08 --> Model Class Initialized
INFO - 2018-03-29 16:35:08 --> Model Class Initialized
INFO - 2018-03-29 16:35:08 --> Model Class Initialized
INFO - 2018-03-29 16:35:08 --> Model Class Initialized
INFO - 2018-03-29 16:35:08 --> Model Class Initialized
INFO - 2018-03-29 16:35:08 --> Model Class Initialized
INFO - 2018-03-29 16:35:08 --> Model Class Initialized
INFO - 2018-03-29 16:35:08 --> Model Class Initialized
INFO - 2018-03-29 16:35:08 --> Model Class Initialized
INFO - 2018-03-29 16:35:08 --> Model Class Initialized
INFO - 2018-03-29 16:35:08 --> Helper loaded: date_helper
INFO - 2018-03-29 16:35:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 21:35:08 --> Model Class Initialized
INFO - 2018-03-29 21:35:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 21:35:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 21:35:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-29 21:35:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 21:35:08 --> Final output sent to browser
DEBUG - 2018-03-29 21:35:08 --> Total execution time: 0.2668
INFO - 2018-03-29 16:35:30 --> Config Class Initialized
INFO - 2018-03-29 16:35:30 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:35:30 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:35:30 --> Utf8 Class Initialized
INFO - 2018-03-29 16:35:30 --> URI Class Initialized
DEBUG - 2018-03-29 16:35:30 --> No URI present. Default controller set.
INFO - 2018-03-29 16:35:30 --> Router Class Initialized
INFO - 2018-03-29 16:35:30 --> Output Class Initialized
INFO - 2018-03-29 16:35:30 --> Security Class Initialized
DEBUG - 2018-03-29 16:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:35:30 --> Input Class Initialized
INFO - 2018-03-29 16:35:30 --> Language Class Initialized
INFO - 2018-03-29 16:35:30 --> Loader Class Initialized
INFO - 2018-03-29 16:35:30 --> Helper loaded: url_helper
INFO - 2018-03-29 16:35:30 --> Helper loaded: form_helper
INFO - 2018-03-29 16:35:30 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:35:30 --> Controller Class Initialized
INFO - 2018-03-29 16:35:30 --> Model Class Initialized
INFO - 2018-03-29 16:35:30 --> Model Class Initialized
INFO - 2018-03-29 16:35:30 --> Model Class Initialized
INFO - 2018-03-29 16:35:30 --> Helper loaded: date_helper
INFO - 2018-03-29 16:35:31 --> Config Class Initialized
INFO - 2018-03-29 16:35:31 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:35:31 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:35:31 --> Utf8 Class Initialized
INFO - 2018-03-29 16:35:31 --> URI Class Initialized
INFO - 2018-03-29 16:35:31 --> Router Class Initialized
INFO - 2018-03-29 16:35:31 --> Output Class Initialized
INFO - 2018-03-29 16:35:31 --> Security Class Initialized
DEBUG - 2018-03-29 16:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:35:31 --> Input Class Initialized
INFO - 2018-03-29 16:35:31 --> Language Class Initialized
INFO - 2018-03-29 16:35:31 --> Loader Class Initialized
INFO - 2018-03-29 16:35:31 --> Helper loaded: url_helper
INFO - 2018-03-29 16:35:31 --> Helper loaded: form_helper
INFO - 2018-03-29 16:35:31 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:35:31 --> Controller Class Initialized
INFO - 2018-03-29 16:35:31 --> Model Class Initialized
INFO - 2018-03-29 16:35:31 --> Model Class Initialized
INFO - 2018-03-29 16:35:31 --> Model Class Initialized
INFO - 2018-03-29 16:35:31 --> Model Class Initialized
INFO - 2018-03-29 16:35:31 --> Model Class Initialized
INFO - 2018-03-29 16:35:31 --> Helper loaded: date_helper
INFO - 2018-03-29 21:35:31 --> Model Class Initialized
INFO - 2018-03-29 21:35:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 21:35:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 21:35:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-29 21:35:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 21:35:31 --> Final output sent to browser
DEBUG - 2018-03-29 21:35:31 --> Total execution time: 0.1213
INFO - 2018-03-29 16:35:52 --> Config Class Initialized
INFO - 2018-03-29 16:35:52 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:35:52 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:35:52 --> Utf8 Class Initialized
INFO - 2018-03-29 16:35:52 --> URI Class Initialized
INFO - 2018-03-29 16:35:52 --> Router Class Initialized
INFO - 2018-03-29 16:35:52 --> Output Class Initialized
INFO - 2018-03-29 16:35:52 --> Security Class Initialized
DEBUG - 2018-03-29 16:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:35:52 --> Input Class Initialized
INFO - 2018-03-29 16:35:52 --> Language Class Initialized
INFO - 2018-03-29 16:35:52 --> Loader Class Initialized
INFO - 2018-03-29 16:35:52 --> Helper loaded: url_helper
INFO - 2018-03-29 16:35:52 --> Helper loaded: form_helper
INFO - 2018-03-29 16:35:52 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:35:52 --> Controller Class Initialized
INFO - 2018-03-29 16:35:52 --> Model Class Initialized
INFO - 2018-03-29 16:35:52 --> Model Class Initialized
INFO - 2018-03-29 16:35:52 --> Model Class Initialized
INFO - 2018-03-29 16:35:52 --> Model Class Initialized
INFO - 2018-03-29 16:35:52 --> Model Class Initialized
INFO - 2018-03-29 16:35:52 --> Model Class Initialized
INFO - 2018-03-29 16:35:52 --> Model Class Initialized
INFO - 2018-03-29 16:35:52 --> Model Class Initialized
INFO - 2018-03-29 16:35:52 --> Model Class Initialized
INFO - 2018-03-29 16:35:52 --> Model Class Initialized
INFO - 2018-03-29 16:35:52 --> Helper loaded: date_helper
INFO - 2018-03-29 16:35:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 21:35:52 --> Model Class Initialized
INFO - 2018-03-29 21:35:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 21:35:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 21:35:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-29 21:35:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 21:35:52 --> Final output sent to browser
DEBUG - 2018-03-29 21:35:52 --> Total execution time: 0.1929
INFO - 2018-03-29 16:54:49 --> Config Class Initialized
INFO - 2018-03-29 16:54:49 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:54:49 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:54:49 --> Utf8 Class Initialized
INFO - 2018-03-29 16:54:49 --> URI Class Initialized
INFO - 2018-03-29 16:54:49 --> Router Class Initialized
INFO - 2018-03-29 16:54:49 --> Output Class Initialized
INFO - 2018-03-29 16:54:49 --> Security Class Initialized
DEBUG - 2018-03-29 16:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:54:49 --> Input Class Initialized
INFO - 2018-03-29 16:54:49 --> Language Class Initialized
INFO - 2018-03-29 16:54:49 --> Loader Class Initialized
INFO - 2018-03-29 16:54:49 --> Helper loaded: url_helper
INFO - 2018-03-29 16:54:49 --> Helper loaded: form_helper
INFO - 2018-03-29 16:54:49 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:54:49 --> Controller Class Initialized
INFO - 2018-03-29 16:54:49 --> Model Class Initialized
INFO - 2018-03-29 16:54:49 --> Model Class Initialized
INFO - 2018-03-29 16:54:49 --> Model Class Initialized
INFO - 2018-03-29 16:54:49 --> Model Class Initialized
INFO - 2018-03-29 16:54:49 --> Model Class Initialized
INFO - 2018-03-29 16:54:49 --> Model Class Initialized
INFO - 2018-03-29 16:54:49 --> Model Class Initialized
INFO - 2018-03-29 16:54:49 --> Model Class Initialized
INFO - 2018-03-29 16:54:49 --> Model Class Initialized
INFO - 2018-03-29 16:54:49 --> Model Class Initialized
INFO - 2018-03-29 16:54:49 --> Model Class Initialized
INFO - 2018-03-29 16:54:49 --> Model Class Initialized
INFO - 2018-03-29 16:54:49 --> Model Class Initialized
INFO - 2018-03-29 16:54:49 --> Model Class Initialized
INFO - 2018-03-29 16:54:49 --> Model Class Initialized
INFO - 2018-03-29 16:54:49 --> Helper loaded: date_helper
INFO - 2018-03-29 16:54:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 21:54:49 --> Model Class Initialized
INFO - 2018-03-29 21:54:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 21:54:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 21:54:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-29 21:54:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 21:54:49 --> Final output sent to browser
DEBUG - 2018-03-29 21:54:49 --> Total execution time: 0.3280
INFO - 2018-03-29 16:54:57 --> Config Class Initialized
INFO - 2018-03-29 16:54:57 --> Hooks Class Initialized
DEBUG - 2018-03-29 16:54:57 --> UTF-8 Support Enabled
INFO - 2018-03-29 16:54:57 --> Utf8 Class Initialized
INFO - 2018-03-29 16:54:57 --> URI Class Initialized
INFO - 2018-03-29 16:54:57 --> Router Class Initialized
INFO - 2018-03-29 16:54:57 --> Output Class Initialized
INFO - 2018-03-29 16:54:57 --> Security Class Initialized
DEBUG - 2018-03-29 16:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 16:54:57 --> Input Class Initialized
INFO - 2018-03-29 16:54:57 --> Language Class Initialized
INFO - 2018-03-29 16:54:57 --> Loader Class Initialized
INFO - 2018-03-29 16:54:57 --> Helper loaded: url_helper
INFO - 2018-03-29 16:54:57 --> Helper loaded: form_helper
INFO - 2018-03-29 16:54:57 --> Database Driver Class Initialized
DEBUG - 2018-03-29 16:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 16:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 16:54:57 --> Controller Class Initialized
INFO - 2018-03-29 16:54:57 --> Model Class Initialized
INFO - 2018-03-29 16:54:57 --> Model Class Initialized
INFO - 2018-03-29 16:54:57 --> Model Class Initialized
INFO - 2018-03-29 16:54:57 --> Model Class Initialized
INFO - 2018-03-29 16:54:57 --> Model Class Initialized
INFO - 2018-03-29 16:54:57 --> Model Class Initialized
INFO - 2018-03-29 16:54:57 --> Model Class Initialized
INFO - 2018-03-29 16:54:57 --> Model Class Initialized
INFO - 2018-03-29 16:54:57 --> Model Class Initialized
INFO - 2018-03-29 16:54:57 --> Model Class Initialized
INFO - 2018-03-29 16:54:57 --> Model Class Initialized
INFO - 2018-03-29 16:54:57 --> Model Class Initialized
INFO - 2018-03-29 16:54:57 --> Helper loaded: date_helper
INFO - 2018-03-29 16:54:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 21:54:57 --> Model Class Initialized
INFO - 2018-03-29 21:54:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 21:54:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 21:54:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPasien/table.php
INFO - 2018-03-29 21:54:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 21:54:58 --> Final output sent to browser
DEBUG - 2018-03-29 21:54:58 --> Total execution time: 0.1815
INFO - 2018-03-29 17:09:45 --> Config Class Initialized
INFO - 2018-03-29 17:09:45 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:09:45 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:09:45 --> Utf8 Class Initialized
INFO - 2018-03-29 17:09:45 --> URI Class Initialized
INFO - 2018-03-29 17:09:45 --> Router Class Initialized
INFO - 2018-03-29 17:09:45 --> Output Class Initialized
INFO - 2018-03-29 17:09:45 --> Security Class Initialized
DEBUG - 2018-03-29 17:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:09:45 --> Input Class Initialized
INFO - 2018-03-29 17:09:45 --> Language Class Initialized
INFO - 2018-03-29 17:09:45 --> Loader Class Initialized
INFO - 2018-03-29 17:09:45 --> Helper loaded: url_helper
INFO - 2018-03-29 17:09:45 --> Helper loaded: form_helper
INFO - 2018-03-29 17:09:45 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:09:45 --> Controller Class Initialized
INFO - 2018-03-29 17:09:45 --> Model Class Initialized
INFO - 2018-03-29 17:09:45 --> Model Class Initialized
INFO - 2018-03-29 17:09:45 --> Helper loaded: date_helper
INFO - 2018-03-29 17:09:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 22:09:45 --> Model Class Initialized
INFO - 2018-03-29 22:09:45 --> Model Class Initialized
INFO - 2018-03-29 22:09:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 22:09:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 22:09:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/pegawai/profile.php
INFO - 2018-03-29 22:09:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 22:09:45 --> Final output sent to browser
DEBUG - 2018-03-29 22:09:45 --> Total execution time: 0.3086
INFO - 2018-03-29 17:10:31 --> Config Class Initialized
INFO - 2018-03-29 17:10:31 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:10:31 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:10:31 --> Utf8 Class Initialized
INFO - 2018-03-29 17:10:31 --> URI Class Initialized
DEBUG - 2018-03-29 17:10:31 --> No URI present. Default controller set.
INFO - 2018-03-29 17:10:31 --> Router Class Initialized
INFO - 2018-03-29 17:10:31 --> Output Class Initialized
INFO - 2018-03-29 17:10:31 --> Security Class Initialized
DEBUG - 2018-03-29 17:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:10:31 --> Input Class Initialized
INFO - 2018-03-29 17:10:31 --> Language Class Initialized
INFO - 2018-03-29 17:10:31 --> Loader Class Initialized
INFO - 2018-03-29 17:10:31 --> Helper loaded: url_helper
INFO - 2018-03-29 17:10:31 --> Helper loaded: form_helper
INFO - 2018-03-29 17:10:31 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:10:31 --> Controller Class Initialized
INFO - 2018-03-29 17:10:31 --> Model Class Initialized
INFO - 2018-03-29 17:10:31 --> Model Class Initialized
INFO - 2018-03-29 17:10:31 --> Model Class Initialized
INFO - 2018-03-29 17:10:31 --> Helper loaded: date_helper
INFO - 2018-03-29 22:10:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-29 22:10:31 --> Final output sent to browser
DEBUG - 2018-03-29 22:10:31 --> Total execution time: 0.1398
INFO - 2018-03-29 17:10:36 --> Config Class Initialized
INFO - 2018-03-29 17:10:36 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:10:36 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:10:36 --> Utf8 Class Initialized
INFO - 2018-03-29 17:10:36 --> URI Class Initialized
DEBUG - 2018-03-29 17:10:36 --> No URI present. Default controller set.
INFO - 2018-03-29 17:10:36 --> Router Class Initialized
INFO - 2018-03-29 17:10:36 --> Output Class Initialized
INFO - 2018-03-29 17:10:36 --> Security Class Initialized
DEBUG - 2018-03-29 17:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:10:36 --> Input Class Initialized
INFO - 2018-03-29 17:10:36 --> Language Class Initialized
INFO - 2018-03-29 17:10:36 --> Loader Class Initialized
INFO - 2018-03-29 17:10:36 --> Helper loaded: url_helper
INFO - 2018-03-29 17:10:36 --> Helper loaded: form_helper
INFO - 2018-03-29 17:10:36 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:10:36 --> Controller Class Initialized
INFO - 2018-03-29 17:10:36 --> Model Class Initialized
INFO - 2018-03-29 17:10:36 --> Model Class Initialized
INFO - 2018-03-29 17:10:36 --> Model Class Initialized
INFO - 2018-03-29 17:10:36 --> Helper loaded: date_helper
INFO - 2018-03-29 17:10:37 --> Config Class Initialized
INFO - 2018-03-29 17:10:37 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:10:37 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:10:37 --> Utf8 Class Initialized
INFO - 2018-03-29 17:10:37 --> URI Class Initialized
INFO - 2018-03-29 17:10:37 --> Router Class Initialized
INFO - 2018-03-29 17:10:37 --> Output Class Initialized
INFO - 2018-03-29 17:10:37 --> Security Class Initialized
DEBUG - 2018-03-29 17:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:10:37 --> Input Class Initialized
INFO - 2018-03-29 17:10:37 --> Language Class Initialized
INFO - 2018-03-29 17:10:37 --> Loader Class Initialized
INFO - 2018-03-29 17:10:37 --> Helper loaded: url_helper
INFO - 2018-03-29 17:10:37 --> Helper loaded: form_helper
INFO - 2018-03-29 17:10:37 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:10:37 --> Controller Class Initialized
INFO - 2018-03-29 17:10:37 --> Model Class Initialized
INFO - 2018-03-29 17:10:37 --> Model Class Initialized
INFO - 2018-03-29 17:10:37 --> Model Class Initialized
INFO - 2018-03-29 17:10:37 --> Model Class Initialized
INFO - 2018-03-29 17:10:37 --> Model Class Initialized
INFO - 2018-03-29 17:10:37 --> Helper loaded: date_helper
INFO - 2018-03-29 22:10:37 --> Model Class Initialized
INFO - 2018-03-29 22:10:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 22:10:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 22:10:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-29 22:10:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 22:10:37 --> Final output sent to browser
DEBUG - 2018-03-29 22:10:37 --> Total execution time: 0.1662
INFO - 2018-03-29 17:32:33 --> Config Class Initialized
INFO - 2018-03-29 17:32:33 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:32:33 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:32:33 --> Utf8 Class Initialized
INFO - 2018-03-29 17:32:33 --> URI Class Initialized
INFO - 2018-03-29 17:32:33 --> Router Class Initialized
INFO - 2018-03-29 17:32:33 --> Output Class Initialized
INFO - 2018-03-29 17:32:33 --> Security Class Initialized
DEBUG - 2018-03-29 17:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:32:33 --> Input Class Initialized
INFO - 2018-03-29 17:32:33 --> Language Class Initialized
INFO - 2018-03-29 17:32:34 --> Loader Class Initialized
INFO - 2018-03-29 17:32:34 --> Helper loaded: url_helper
INFO - 2018-03-29 17:32:34 --> Helper loaded: form_helper
INFO - 2018-03-29 17:32:34 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:32:34 --> Controller Class Initialized
INFO - 2018-03-29 17:32:34 --> Model Class Initialized
INFO - 2018-03-29 17:32:34 --> Model Class Initialized
INFO - 2018-03-29 17:32:34 --> Model Class Initialized
INFO - 2018-03-29 17:32:34 --> Model Class Initialized
INFO - 2018-03-29 17:32:34 --> Model Class Initialized
INFO - 2018-03-29 17:32:34 --> Helper loaded: date_helper
INFO - 2018-03-29 17:32:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 22:32:34 --> Model Class Initialized
INFO - 2018-03-29 22:32:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 22:32:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 22:32:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-29 22:32:34 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 22:32:34 --> Final output sent to browser
DEBUG - 2018-03-29 22:32:34 --> Total execution time: 0.3192
INFO - 2018-03-29 17:32:36 --> Config Class Initialized
INFO - 2018-03-29 17:32:36 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:32:36 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:32:36 --> Utf8 Class Initialized
INFO - 2018-03-29 17:32:36 --> URI Class Initialized
INFO - 2018-03-29 17:32:36 --> Router Class Initialized
INFO - 2018-03-29 17:32:36 --> Output Class Initialized
INFO - 2018-03-29 17:32:36 --> Security Class Initialized
DEBUG - 2018-03-29 17:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:32:36 --> Input Class Initialized
INFO - 2018-03-29 17:32:36 --> Language Class Initialized
INFO - 2018-03-29 17:32:36 --> Loader Class Initialized
INFO - 2018-03-29 17:32:36 --> Helper loaded: url_helper
INFO - 2018-03-29 17:32:36 --> Helper loaded: form_helper
INFO - 2018-03-29 17:32:36 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:32:36 --> Controller Class Initialized
INFO - 2018-03-29 17:32:36 --> Model Class Initialized
INFO - 2018-03-29 17:32:36 --> Model Class Initialized
INFO - 2018-03-29 17:32:36 --> Model Class Initialized
INFO - 2018-03-29 17:32:36 --> Model Class Initialized
INFO - 2018-03-29 17:32:36 --> Model Class Initialized
INFO - 2018-03-29 17:32:36 --> Helper loaded: date_helper
INFO - 2018-03-29 17:32:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 22:32:36 --> Model Class Initialized
INFO - 2018-03-29 22:32:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 22:32:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 22:32:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/create.php
INFO - 2018-03-29 22:32:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 22:32:36 --> Final output sent to browser
DEBUG - 2018-03-29 22:32:36 --> Total execution time: 0.1969
INFO - 2018-03-29 17:32:40 --> Config Class Initialized
INFO - 2018-03-29 17:32:40 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:32:40 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:32:40 --> Utf8 Class Initialized
INFO - 2018-03-29 17:32:40 --> URI Class Initialized
INFO - 2018-03-29 17:32:40 --> Router Class Initialized
INFO - 2018-03-29 17:32:40 --> Output Class Initialized
INFO - 2018-03-29 17:32:40 --> Security Class Initialized
DEBUG - 2018-03-29 17:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:32:40 --> Input Class Initialized
INFO - 2018-03-29 17:32:40 --> Language Class Initialized
INFO - 2018-03-29 17:32:40 --> Loader Class Initialized
INFO - 2018-03-29 17:32:40 --> Helper loaded: url_helper
INFO - 2018-03-29 17:32:40 --> Helper loaded: form_helper
INFO - 2018-03-29 17:32:40 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:32:40 --> Controller Class Initialized
INFO - 2018-03-29 17:32:40 --> Model Class Initialized
INFO - 2018-03-29 17:32:40 --> Model Class Initialized
INFO - 2018-03-29 17:32:40 --> Helper loaded: date_helper
INFO - 2018-03-29 17:32:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 22:32:40 --> Final output sent to browser
DEBUG - 2018-03-29 22:32:40 --> Total execution time: 0.1693
INFO - 2018-03-29 17:37:15 --> Config Class Initialized
INFO - 2018-03-29 17:37:15 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:37:15 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:37:15 --> Utf8 Class Initialized
INFO - 2018-03-29 17:37:15 --> URI Class Initialized
INFO - 2018-03-29 17:37:15 --> Router Class Initialized
INFO - 2018-03-29 17:37:15 --> Output Class Initialized
INFO - 2018-03-29 17:37:15 --> Security Class Initialized
DEBUG - 2018-03-29 17:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:37:15 --> Input Class Initialized
INFO - 2018-03-29 17:37:15 --> Language Class Initialized
INFO - 2018-03-29 17:37:15 --> Loader Class Initialized
INFO - 2018-03-29 17:37:15 --> Helper loaded: url_helper
INFO - 2018-03-29 17:37:15 --> Helper loaded: form_helper
INFO - 2018-03-29 17:37:15 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:37:15 --> Controller Class Initialized
INFO - 2018-03-29 17:37:15 --> Model Class Initialized
INFO - 2018-03-29 17:37:15 --> Model Class Initialized
INFO - 2018-03-29 17:37:15 --> Model Class Initialized
INFO - 2018-03-29 17:37:15 --> Model Class Initialized
INFO - 2018-03-29 17:37:15 --> Model Class Initialized
INFO - 2018-03-29 17:37:15 --> Model Class Initialized
INFO - 2018-03-29 17:37:15 --> Model Class Initialized
INFO - 2018-03-29 17:37:15 --> Model Class Initialized
INFO - 2018-03-29 17:37:15 --> Model Class Initialized
INFO - 2018-03-29 17:37:15 --> Model Class Initialized
INFO - 2018-03-29 17:37:15 --> Model Class Initialized
INFO - 2018-03-29 17:37:15 --> Model Class Initialized
INFO - 2018-03-29 17:37:15 --> Model Class Initialized
INFO - 2018-03-29 17:37:15 --> Model Class Initialized
INFO - 2018-03-29 17:37:15 --> Model Class Initialized
INFO - 2018-03-29 17:37:15 --> Helper loaded: date_helper
INFO - 2018-03-29 17:37:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 22:37:15 --> Model Class Initialized
INFO - 2018-03-29 22:37:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 22:37:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 22:37:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-29 22:37:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 22:37:15 --> Final output sent to browser
DEBUG - 2018-03-29 22:37:15 --> Total execution time: 0.1781
INFO - 2018-03-29 17:37:59 --> Config Class Initialized
INFO - 2018-03-29 17:37:59 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:37:59 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:37:59 --> Utf8 Class Initialized
INFO - 2018-03-29 17:37:59 --> URI Class Initialized
INFO - 2018-03-29 17:37:59 --> Router Class Initialized
INFO - 2018-03-29 17:37:59 --> Output Class Initialized
INFO - 2018-03-29 17:37:59 --> Security Class Initialized
DEBUG - 2018-03-29 17:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:37:59 --> Input Class Initialized
INFO - 2018-03-29 17:37:59 --> Language Class Initialized
INFO - 2018-03-29 17:37:59 --> Loader Class Initialized
INFO - 2018-03-29 17:37:59 --> Helper loaded: url_helper
INFO - 2018-03-29 17:37:59 --> Helper loaded: form_helper
INFO - 2018-03-29 17:37:59 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:37:59 --> Controller Class Initialized
INFO - 2018-03-29 17:37:59 --> Model Class Initialized
INFO - 2018-03-29 17:37:59 --> Model Class Initialized
INFO - 2018-03-29 17:37:59 --> Model Class Initialized
INFO - 2018-03-29 17:37:59 --> Model Class Initialized
INFO - 2018-03-29 17:37:59 --> Model Class Initialized
INFO - 2018-03-29 17:37:59 --> Helper loaded: date_helper
INFO - 2018-03-29 17:37:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 22:37:59 --> Model Class Initialized
INFO - 2018-03-29 22:37:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 22:37:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 22:37:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/create.php
INFO - 2018-03-29 22:37:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 22:37:59 --> Final output sent to browser
DEBUG - 2018-03-29 22:37:59 --> Total execution time: 0.1416
INFO - 2018-03-29 17:38:03 --> Config Class Initialized
INFO - 2018-03-29 17:38:03 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:38:03 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:38:03 --> Utf8 Class Initialized
INFO - 2018-03-29 17:38:03 --> URI Class Initialized
INFO - 2018-03-29 17:38:03 --> Router Class Initialized
INFO - 2018-03-29 17:38:03 --> Output Class Initialized
INFO - 2018-03-29 17:38:03 --> Security Class Initialized
DEBUG - 2018-03-29 17:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:38:03 --> Input Class Initialized
INFO - 2018-03-29 17:38:03 --> Language Class Initialized
INFO - 2018-03-29 17:38:03 --> Loader Class Initialized
INFO - 2018-03-29 17:38:03 --> Helper loaded: url_helper
INFO - 2018-03-29 17:38:03 --> Helper loaded: form_helper
INFO - 2018-03-29 17:38:03 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:38:03 --> Controller Class Initialized
INFO - 2018-03-29 17:38:03 --> Model Class Initialized
INFO - 2018-03-29 17:38:03 --> Model Class Initialized
INFO - 2018-03-29 17:38:03 --> Model Class Initialized
INFO - 2018-03-29 17:38:03 --> Model Class Initialized
INFO - 2018-03-29 17:38:03 --> Model Class Initialized
INFO - 2018-03-29 17:38:03 --> Helper loaded: date_helper
INFO - 2018-03-29 17:38:03 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 22:38:03 --> Model Class Initialized
INFO - 2018-03-29 22:38:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 22:38:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 22:38:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-29 22:38:03 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 22:38:03 --> Final output sent to browser
DEBUG - 2018-03-29 22:38:03 --> Total execution time: 0.1348
INFO - 2018-03-29 17:38:33 --> Config Class Initialized
INFO - 2018-03-29 17:38:33 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:38:33 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:38:33 --> Utf8 Class Initialized
INFO - 2018-03-29 17:38:33 --> URI Class Initialized
INFO - 2018-03-29 17:38:33 --> Router Class Initialized
INFO - 2018-03-29 17:38:33 --> Output Class Initialized
INFO - 2018-03-29 17:38:33 --> Security Class Initialized
DEBUG - 2018-03-29 17:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:38:33 --> Input Class Initialized
INFO - 2018-03-29 17:38:33 --> Language Class Initialized
INFO - 2018-03-29 17:38:33 --> Loader Class Initialized
INFO - 2018-03-29 17:38:33 --> Helper loaded: url_helper
INFO - 2018-03-29 17:38:33 --> Helper loaded: form_helper
INFO - 2018-03-29 17:38:33 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:38:33 --> Controller Class Initialized
INFO - 2018-03-29 17:38:33 --> Model Class Initialized
INFO - 2018-03-29 17:38:33 --> Model Class Initialized
INFO - 2018-03-29 17:38:33 --> Model Class Initialized
INFO - 2018-03-29 17:38:33 --> Model Class Initialized
INFO - 2018-03-29 17:38:33 --> Model Class Initialized
INFO - 2018-03-29 17:38:33 --> Helper loaded: date_helper
INFO - 2018-03-29 17:38:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 22:38:33 --> Model Class Initialized
INFO - 2018-03-29 22:38:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 22:38:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 22:38:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/create.php
INFO - 2018-03-29 22:38:33 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 22:38:33 --> Final output sent to browser
DEBUG - 2018-03-29 22:38:33 --> Total execution time: 0.1603
INFO - 2018-03-29 17:38:38 --> Config Class Initialized
INFO - 2018-03-29 17:38:38 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:38:38 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:38:38 --> Utf8 Class Initialized
INFO - 2018-03-29 17:38:38 --> URI Class Initialized
INFO - 2018-03-29 17:38:38 --> Router Class Initialized
INFO - 2018-03-29 17:38:38 --> Output Class Initialized
INFO - 2018-03-29 17:38:38 --> Security Class Initialized
DEBUG - 2018-03-29 17:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:38:38 --> Input Class Initialized
INFO - 2018-03-29 17:38:38 --> Language Class Initialized
INFO - 2018-03-29 17:38:38 --> Loader Class Initialized
INFO - 2018-03-29 17:38:38 --> Helper loaded: url_helper
INFO - 2018-03-29 17:38:38 --> Helper loaded: form_helper
INFO - 2018-03-29 17:38:38 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:38:38 --> Controller Class Initialized
INFO - 2018-03-29 17:38:38 --> Model Class Initialized
INFO - 2018-03-29 17:38:38 --> Model Class Initialized
INFO - 2018-03-29 17:38:38 --> Helper loaded: date_helper
INFO - 2018-03-29 17:38:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 22:38:38 --> Final output sent to browser
DEBUG - 2018-03-29 22:38:38 --> Total execution time: 0.1148
INFO - 2018-03-29 17:38:43 --> Config Class Initialized
INFO - 2018-03-29 17:38:43 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:38:43 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:38:43 --> Utf8 Class Initialized
INFO - 2018-03-29 17:38:43 --> URI Class Initialized
INFO - 2018-03-29 17:38:43 --> Router Class Initialized
INFO - 2018-03-29 17:38:43 --> Output Class Initialized
INFO - 2018-03-29 17:38:43 --> Security Class Initialized
DEBUG - 2018-03-29 17:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:38:43 --> Input Class Initialized
INFO - 2018-03-29 17:38:43 --> Language Class Initialized
INFO - 2018-03-29 17:38:43 --> Loader Class Initialized
INFO - 2018-03-29 17:38:43 --> Helper loaded: url_helper
INFO - 2018-03-29 17:38:43 --> Helper loaded: form_helper
INFO - 2018-03-29 17:38:43 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:38:43 --> Controller Class Initialized
INFO - 2018-03-29 17:38:43 --> Model Class Initialized
INFO - 2018-03-29 17:38:43 --> Model Class Initialized
INFO - 2018-03-29 17:38:43 --> Helper loaded: date_helper
INFO - 2018-03-29 17:38:43 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 22:38:43 --> Final output sent to browser
DEBUG - 2018-03-29 22:38:43 --> Total execution time: 0.1272
INFO - 2018-03-29 17:39:11 --> Config Class Initialized
INFO - 2018-03-29 17:39:11 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:39:11 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:39:11 --> Utf8 Class Initialized
INFO - 2018-03-29 17:39:11 --> URI Class Initialized
INFO - 2018-03-29 17:39:11 --> Router Class Initialized
INFO - 2018-03-29 17:39:11 --> Output Class Initialized
INFO - 2018-03-29 17:39:11 --> Security Class Initialized
DEBUG - 2018-03-29 17:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:39:11 --> Input Class Initialized
INFO - 2018-03-29 17:39:11 --> Language Class Initialized
INFO - 2018-03-29 17:39:11 --> Loader Class Initialized
INFO - 2018-03-29 17:39:11 --> Helper loaded: url_helper
INFO - 2018-03-29 17:39:11 --> Helper loaded: form_helper
INFO - 2018-03-29 17:39:11 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:39:11 --> Controller Class Initialized
INFO - 2018-03-29 17:39:11 --> Model Class Initialized
INFO - 2018-03-29 17:39:11 --> Model Class Initialized
INFO - 2018-03-29 17:39:11 --> Model Class Initialized
INFO - 2018-03-29 17:39:11 --> Model Class Initialized
INFO - 2018-03-29 17:39:11 --> Model Class Initialized
INFO - 2018-03-29 17:39:11 --> Helper loaded: date_helper
INFO - 2018-03-29 17:39:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 17:39:11 --> Config Class Initialized
INFO - 2018-03-29 17:39:11 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:39:11 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:39:11 --> Utf8 Class Initialized
INFO - 2018-03-29 17:39:11 --> URI Class Initialized
INFO - 2018-03-29 17:39:11 --> Router Class Initialized
INFO - 2018-03-29 17:39:11 --> Output Class Initialized
INFO - 2018-03-29 17:39:11 --> Security Class Initialized
DEBUG - 2018-03-29 17:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:39:11 --> Input Class Initialized
INFO - 2018-03-29 17:39:11 --> Language Class Initialized
INFO - 2018-03-29 17:39:11 --> Loader Class Initialized
INFO - 2018-03-29 17:39:11 --> Helper loaded: url_helper
INFO - 2018-03-29 17:39:11 --> Helper loaded: form_helper
INFO - 2018-03-29 17:39:11 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:39:11 --> Controller Class Initialized
INFO - 2018-03-29 17:39:11 --> Model Class Initialized
INFO - 2018-03-29 17:39:11 --> Model Class Initialized
INFO - 2018-03-29 17:39:11 --> Model Class Initialized
INFO - 2018-03-29 17:39:11 --> Model Class Initialized
INFO - 2018-03-29 17:39:11 --> Model Class Initialized
INFO - 2018-03-29 17:39:11 --> Helper loaded: date_helper
INFO - 2018-03-29 17:39:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 22:39:11 --> Model Class Initialized
INFO - 2018-03-29 22:39:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 22:39:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 22:39:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/detail.php
INFO - 2018-03-29 22:39:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 22:39:11 --> Final output sent to browser
DEBUG - 2018-03-29 22:39:11 --> Total execution time: 0.1713
INFO - 2018-03-29 17:39:13 --> Config Class Initialized
INFO - 2018-03-29 17:39:13 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:39:13 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:39:13 --> Utf8 Class Initialized
INFO - 2018-03-29 17:39:13 --> URI Class Initialized
INFO - 2018-03-29 17:39:13 --> Router Class Initialized
INFO - 2018-03-29 17:39:13 --> Output Class Initialized
INFO - 2018-03-29 17:39:13 --> Security Class Initialized
DEBUG - 2018-03-29 17:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:39:13 --> Input Class Initialized
INFO - 2018-03-29 17:39:13 --> Language Class Initialized
INFO - 2018-03-29 17:39:13 --> Loader Class Initialized
INFO - 2018-03-29 17:39:13 --> Helper loaded: url_helper
INFO - 2018-03-29 17:39:13 --> Helper loaded: form_helper
INFO - 2018-03-29 17:39:13 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:39:13 --> Controller Class Initialized
INFO - 2018-03-29 17:39:13 --> Model Class Initialized
INFO - 2018-03-29 17:39:13 --> Model Class Initialized
INFO - 2018-03-29 17:39:13 --> Model Class Initialized
INFO - 2018-03-29 17:39:13 --> Model Class Initialized
INFO - 2018-03-29 17:39:13 --> Model Class Initialized
INFO - 2018-03-29 17:39:13 --> Helper loaded: date_helper
INFO - 2018-03-29 17:39:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 22:39:13 --> Model Class Initialized
INFO - 2018-03-29 22:39:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 22:39:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 22:39:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penerimaan/table.php
INFO - 2018-03-29 22:39:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 22:39:13 --> Final output sent to browser
DEBUG - 2018-03-29 22:39:13 --> Total execution time: 0.1682
INFO - 2018-03-29 17:53:49 --> Config Class Initialized
INFO - 2018-03-29 17:53:49 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:53:49 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:53:49 --> Utf8 Class Initialized
INFO - 2018-03-29 17:53:49 --> URI Class Initialized
INFO - 2018-03-29 17:53:49 --> Router Class Initialized
INFO - 2018-03-29 17:53:49 --> Output Class Initialized
INFO - 2018-03-29 17:53:49 --> Security Class Initialized
DEBUG - 2018-03-29 17:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:53:49 --> Input Class Initialized
INFO - 2018-03-29 17:53:49 --> Language Class Initialized
INFO - 2018-03-29 17:53:49 --> Loader Class Initialized
INFO - 2018-03-29 17:53:49 --> Helper loaded: url_helper
INFO - 2018-03-29 17:53:49 --> Helper loaded: form_helper
INFO - 2018-03-29 17:53:49 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:53:49 --> Controller Class Initialized
INFO - 2018-03-29 17:53:49 --> Model Class Initialized
INFO - 2018-03-29 17:53:49 --> Model Class Initialized
INFO - 2018-03-29 17:53:49 --> Model Class Initialized
INFO - 2018-03-29 17:53:49 --> Model Class Initialized
INFO - 2018-03-29 17:53:49 --> Model Class Initialized
INFO - 2018-03-29 17:53:49 --> Model Class Initialized
INFO - 2018-03-29 17:53:49 --> Model Class Initialized
INFO - 2018-03-29 17:53:49 --> Model Class Initialized
INFO - 2018-03-29 17:53:49 --> Model Class Initialized
INFO - 2018-03-29 17:53:49 --> Model Class Initialized
INFO - 2018-03-29 17:53:49 --> Model Class Initialized
INFO - 2018-03-29 17:53:49 --> Model Class Initialized
INFO - 2018-03-29 17:53:49 --> Model Class Initialized
INFO - 2018-03-29 17:53:49 --> Model Class Initialized
INFO - 2018-03-29 17:53:49 --> Model Class Initialized
INFO - 2018-03-29 17:53:49 --> Helper loaded: date_helper
INFO - 2018-03-29 17:53:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 22:53:49 --> Model Class Initialized
INFO - 2018-03-29 22:53:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 22:53:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 22:53:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penjualan/table.php
INFO - 2018-03-29 22:53:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 22:53:49 --> Final output sent to browser
DEBUG - 2018-03-29 22:53:49 --> Total execution time: 0.2286
INFO - 2018-03-29 17:55:55 --> Config Class Initialized
INFO - 2018-03-29 17:55:55 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:55:55 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:55:55 --> Utf8 Class Initialized
INFO - 2018-03-29 17:55:55 --> URI Class Initialized
INFO - 2018-03-29 17:55:55 --> Router Class Initialized
INFO - 2018-03-29 17:55:55 --> Output Class Initialized
INFO - 2018-03-29 17:55:55 --> Security Class Initialized
DEBUG - 2018-03-29 17:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:55:55 --> Input Class Initialized
INFO - 2018-03-29 17:55:55 --> Language Class Initialized
INFO - 2018-03-29 17:55:55 --> Loader Class Initialized
INFO - 2018-03-29 17:55:55 --> Helper loaded: url_helper
INFO - 2018-03-29 17:55:55 --> Helper loaded: form_helper
INFO - 2018-03-29 17:55:55 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:55:55 --> Controller Class Initialized
INFO - 2018-03-29 17:55:55 --> Model Class Initialized
INFO - 2018-03-29 17:55:55 --> Model Class Initialized
INFO - 2018-03-29 17:55:55 --> Model Class Initialized
INFO - 2018-03-29 17:55:55 --> Model Class Initialized
INFO - 2018-03-29 17:55:55 --> Model Class Initialized
INFO - 2018-03-29 17:55:55 --> Model Class Initialized
INFO - 2018-03-29 17:55:55 --> Model Class Initialized
INFO - 2018-03-29 17:55:55 --> Model Class Initialized
INFO - 2018-03-29 17:55:55 --> Model Class Initialized
INFO - 2018-03-29 17:55:55 --> Model Class Initialized
INFO - 2018-03-29 17:55:55 --> Model Class Initialized
INFO - 2018-03-29 17:55:55 --> Model Class Initialized
INFO - 2018-03-29 17:55:55 --> Model Class Initialized
INFO - 2018-03-29 17:55:55 --> Model Class Initialized
INFO - 2018-03-29 17:55:55 --> Model Class Initialized
INFO - 2018-03-29 17:55:55 --> Helper loaded: date_helper
INFO - 2018-03-29 17:55:55 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 22:55:55 --> Model Class Initialized
INFO - 2018-03-29 22:55:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 22:55:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 22:55:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-29 22:55:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 22:55:55 --> Final output sent to browser
DEBUG - 2018-03-29 22:55:55 --> Total execution time: 0.1871
INFO - 2018-03-29 17:55:58 --> Config Class Initialized
INFO - 2018-03-29 17:55:58 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:55:58 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:55:58 --> Utf8 Class Initialized
INFO - 2018-03-29 17:55:58 --> URI Class Initialized
INFO - 2018-03-29 17:55:58 --> Router Class Initialized
INFO - 2018-03-29 17:55:58 --> Output Class Initialized
INFO - 2018-03-29 17:55:58 --> Security Class Initialized
DEBUG - 2018-03-29 17:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:55:58 --> Input Class Initialized
INFO - 2018-03-29 17:55:58 --> Language Class Initialized
INFO - 2018-03-29 17:55:58 --> Loader Class Initialized
INFO - 2018-03-29 17:55:58 --> Helper loaded: url_helper
INFO - 2018-03-29 17:55:58 --> Helper loaded: form_helper
INFO - 2018-03-29 17:55:58 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:55:58 --> Controller Class Initialized
INFO - 2018-03-29 17:55:58 --> Model Class Initialized
INFO - 2018-03-29 17:55:58 --> Model Class Initialized
INFO - 2018-03-29 17:55:58 --> Helper loaded: date_helper
INFO - 2018-03-29 17:55:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 22:55:58 --> Final output sent to browser
DEBUG - 2018-03-29 22:55:58 --> Total execution time: 0.1042
INFO - 2018-03-29 17:56:41 --> Config Class Initialized
INFO - 2018-03-29 17:56:41 --> Hooks Class Initialized
DEBUG - 2018-03-29 17:56:41 --> UTF-8 Support Enabled
INFO - 2018-03-29 17:56:41 --> Utf8 Class Initialized
INFO - 2018-03-29 17:56:41 --> URI Class Initialized
INFO - 2018-03-29 17:56:41 --> Router Class Initialized
INFO - 2018-03-29 17:56:41 --> Output Class Initialized
INFO - 2018-03-29 17:56:41 --> Security Class Initialized
DEBUG - 2018-03-29 17:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 17:56:41 --> Input Class Initialized
INFO - 2018-03-29 17:56:41 --> Language Class Initialized
INFO - 2018-03-29 17:56:41 --> Loader Class Initialized
INFO - 2018-03-29 17:56:41 --> Helper loaded: url_helper
INFO - 2018-03-29 17:56:41 --> Helper loaded: form_helper
INFO - 2018-03-29 17:56:41 --> Database Driver Class Initialized
DEBUG - 2018-03-29 17:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 17:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 17:56:41 --> Controller Class Initialized
INFO - 2018-03-29 17:56:41 --> Model Class Initialized
INFO - 2018-03-29 17:56:41 --> Model Class Initialized
INFO - 2018-03-29 17:56:41 --> Model Class Initialized
INFO - 2018-03-29 17:56:41 --> Model Class Initialized
INFO - 2018-03-29 17:56:41 --> Model Class Initialized
INFO - 2018-03-29 17:56:41 --> Model Class Initialized
INFO - 2018-03-29 17:56:41 --> Model Class Initialized
INFO - 2018-03-29 17:56:41 --> Model Class Initialized
INFO - 2018-03-29 17:56:41 --> Model Class Initialized
INFO - 2018-03-29 17:56:41 --> Model Class Initialized
INFO - 2018-03-29 17:56:41 --> Model Class Initialized
INFO - 2018-03-29 17:56:41 --> Model Class Initialized
INFO - 2018-03-29 17:56:41 --> Model Class Initialized
INFO - 2018-03-29 17:56:41 --> Model Class Initialized
INFO - 2018-03-29 17:56:41 --> Model Class Initialized
INFO - 2018-03-29 17:56:41 --> Helper loaded: date_helper
INFO - 2018-03-29 17:56:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 22:56:41 --> Model Class Initialized
INFO - 2018-03-29 22:56:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 22:56:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 22:56:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-29 22:56:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 22:56:41 --> Final output sent to browser
DEBUG - 2018-03-29 22:56:41 --> Total execution time: 0.1517
INFO - 2018-03-29 18:09:08 --> Config Class Initialized
INFO - 2018-03-29 18:09:08 --> Hooks Class Initialized
DEBUG - 2018-03-29 18:09:08 --> UTF-8 Support Enabled
INFO - 2018-03-29 18:09:08 --> Utf8 Class Initialized
INFO - 2018-03-29 18:09:08 --> URI Class Initialized
INFO - 2018-03-29 18:09:08 --> Router Class Initialized
INFO - 2018-03-29 18:09:08 --> Output Class Initialized
INFO - 2018-03-29 18:09:08 --> Security Class Initialized
DEBUG - 2018-03-29 18:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 18:09:08 --> Input Class Initialized
INFO - 2018-03-29 18:09:08 --> Language Class Initialized
INFO - 2018-03-29 18:09:08 --> Loader Class Initialized
INFO - 2018-03-29 18:09:08 --> Helper loaded: url_helper
INFO - 2018-03-29 18:09:08 --> Helper loaded: form_helper
INFO - 2018-03-29 18:09:08 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:09:08 --> Controller Class Initialized
INFO - 2018-03-29 18:09:08 --> Model Class Initialized
INFO - 2018-03-29 18:09:08 --> Model Class Initialized
INFO - 2018-03-29 18:09:08 --> Model Class Initialized
INFO - 2018-03-29 18:09:08 --> Model Class Initialized
INFO - 2018-03-29 18:09:08 --> Model Class Initialized
INFO - 2018-03-29 18:09:08 --> Model Class Initialized
INFO - 2018-03-29 18:09:08 --> Model Class Initialized
INFO - 2018-03-29 18:09:08 --> Model Class Initialized
INFO - 2018-03-29 18:09:08 --> Model Class Initialized
INFO - 2018-03-29 18:09:08 --> Model Class Initialized
INFO - 2018-03-29 18:09:08 --> Model Class Initialized
INFO - 2018-03-29 18:09:08 --> Model Class Initialized
INFO - 2018-03-29 18:09:08 --> Model Class Initialized
INFO - 2018-03-29 18:09:08 --> Model Class Initialized
INFO - 2018-03-29 18:09:08 --> Model Class Initialized
INFO - 2018-03-29 18:09:08 --> Helper loaded: date_helper
INFO - 2018-03-29 18:09:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 23:09:08 --> Model Class Initialized
INFO - 2018-03-29 23:09:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 23:09:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 23:09:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-29 23:09:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 23:09:08 --> Final output sent to browser
DEBUG - 2018-03-29 23:09:08 --> Total execution time: 0.1284
INFO - 2018-03-29 18:09:11 --> Config Class Initialized
INFO - 2018-03-29 18:09:11 --> Hooks Class Initialized
DEBUG - 2018-03-29 18:09:11 --> UTF-8 Support Enabled
INFO - 2018-03-29 18:09:11 --> Utf8 Class Initialized
INFO - 2018-03-29 18:09:11 --> URI Class Initialized
INFO - 2018-03-29 18:09:11 --> Router Class Initialized
INFO - 2018-03-29 18:09:11 --> Output Class Initialized
INFO - 2018-03-29 18:09:11 --> Security Class Initialized
DEBUG - 2018-03-29 18:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 18:09:11 --> Input Class Initialized
INFO - 2018-03-29 18:09:11 --> Language Class Initialized
INFO - 2018-03-29 18:09:11 --> Loader Class Initialized
INFO - 2018-03-29 18:09:11 --> Helper loaded: url_helper
INFO - 2018-03-29 18:09:11 --> Helper loaded: form_helper
INFO - 2018-03-29 18:09:11 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:09:11 --> Controller Class Initialized
INFO - 2018-03-29 18:09:11 --> Model Class Initialized
INFO - 2018-03-29 18:09:11 --> Model Class Initialized
INFO - 2018-03-29 18:09:11 --> Helper loaded: date_helper
INFO - 2018-03-29 18:09:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 23:09:11 --> Final output sent to browser
DEBUG - 2018-03-29 23:09:11 --> Total execution time: 0.0788
INFO - 2018-03-29 18:09:16 --> Config Class Initialized
INFO - 2018-03-29 18:09:16 --> Hooks Class Initialized
DEBUG - 2018-03-29 18:09:16 --> UTF-8 Support Enabled
INFO - 2018-03-29 18:09:16 --> Utf8 Class Initialized
INFO - 2018-03-29 18:09:16 --> URI Class Initialized
INFO - 2018-03-29 18:09:16 --> Router Class Initialized
INFO - 2018-03-29 18:09:16 --> Output Class Initialized
INFO - 2018-03-29 18:09:16 --> Security Class Initialized
DEBUG - 2018-03-29 18:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 18:09:16 --> Input Class Initialized
INFO - 2018-03-29 18:09:16 --> Language Class Initialized
INFO - 2018-03-29 18:09:16 --> Loader Class Initialized
INFO - 2018-03-29 18:09:16 --> Helper loaded: url_helper
INFO - 2018-03-29 18:09:16 --> Helper loaded: form_helper
INFO - 2018-03-29 18:09:16 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:09:16 --> Controller Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Model Class Initialized
INFO - 2018-03-29 18:09:16 --> Helper loaded: date_helper
INFO - 2018-03-29 18:09:16 --> Helper loaded: tanggal_helper
ERROR - 2018-03-29 23:09:16 --> Severity: error --> Exception: Call to a member function laporanPenerimaan() on null E:\xampp\htdocs\skin_care\application\controllers\Laporan\Laporan.php 75
INFO - 2018-03-29 18:09:25 --> Config Class Initialized
INFO - 2018-03-29 18:09:25 --> Hooks Class Initialized
DEBUG - 2018-03-29 18:09:25 --> UTF-8 Support Enabled
INFO - 2018-03-29 18:09:25 --> Utf8 Class Initialized
INFO - 2018-03-29 18:09:25 --> URI Class Initialized
INFO - 2018-03-29 18:09:25 --> Router Class Initialized
INFO - 2018-03-29 18:09:25 --> Output Class Initialized
INFO - 2018-03-29 18:09:25 --> Security Class Initialized
DEBUG - 2018-03-29 18:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 18:09:25 --> Input Class Initialized
INFO - 2018-03-29 18:09:25 --> Language Class Initialized
INFO - 2018-03-29 18:09:25 --> Loader Class Initialized
INFO - 2018-03-29 18:09:25 --> Helper loaded: url_helper
INFO - 2018-03-29 18:09:25 --> Helper loaded: form_helper
INFO - 2018-03-29 18:09:25 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:09:25 --> Controller Class Initialized
INFO - 2018-03-29 18:09:25 --> Model Class Initialized
INFO - 2018-03-29 18:09:25 --> Model Class Initialized
INFO - 2018-03-29 18:09:25 --> Model Class Initialized
INFO - 2018-03-29 18:09:25 --> Model Class Initialized
INFO - 2018-03-29 18:09:25 --> Model Class Initialized
INFO - 2018-03-29 18:09:25 --> Model Class Initialized
INFO - 2018-03-29 18:09:25 --> Model Class Initialized
INFO - 2018-03-29 18:09:25 --> Model Class Initialized
INFO - 2018-03-29 18:09:25 --> Model Class Initialized
INFO - 2018-03-29 18:09:25 --> Model Class Initialized
INFO - 2018-03-29 18:09:25 --> Model Class Initialized
INFO - 2018-03-29 18:09:25 --> Model Class Initialized
INFO - 2018-03-29 18:09:25 --> Model Class Initialized
INFO - 2018-03-29 18:09:25 --> Model Class Initialized
INFO - 2018-03-29 18:09:25 --> Model Class Initialized
INFO - 2018-03-29 18:09:25 --> Helper loaded: date_helper
INFO - 2018-03-29 18:09:25 --> Helper loaded: tanggal_helper
ERROR - 2018-03-29 23:09:25 --> Severity: error --> Exception: Call to a member function laporanPenerimaan() on null E:\xampp\htdocs\skin_care\application\controllers\Laporan\Laporan.php 75
INFO - 2018-03-29 18:10:01 --> Config Class Initialized
INFO - 2018-03-29 18:10:01 --> Hooks Class Initialized
DEBUG - 2018-03-29 18:10:01 --> UTF-8 Support Enabled
INFO - 2018-03-29 18:10:01 --> Utf8 Class Initialized
INFO - 2018-03-29 18:10:01 --> URI Class Initialized
INFO - 2018-03-29 18:10:01 --> Router Class Initialized
INFO - 2018-03-29 18:10:01 --> Output Class Initialized
INFO - 2018-03-29 18:10:01 --> Security Class Initialized
DEBUG - 2018-03-29 18:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 18:10:01 --> Input Class Initialized
INFO - 2018-03-29 18:10:01 --> Language Class Initialized
INFO - 2018-03-29 18:10:01 --> Loader Class Initialized
INFO - 2018-03-29 18:10:01 --> Helper loaded: url_helper
INFO - 2018-03-29 18:10:01 --> Helper loaded: form_helper
INFO - 2018-03-29 18:10:01 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:10:01 --> Controller Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Model Class Initialized
INFO - 2018-03-29 18:10:01 --> Helper loaded: date_helper
INFO - 2018-03-29 18:10:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 23:10:01 --> Model Class Initialized
INFO - 2018-03-29 23:10:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 23:10:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 23:10:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-29 23:10:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 23:10:01 --> Final output sent to browser
DEBUG - 2018-03-29 23:10:01 --> Total execution time: 0.1667
INFO - 2018-03-29 18:10:04 --> Config Class Initialized
INFO - 2018-03-29 18:10:04 --> Hooks Class Initialized
DEBUG - 2018-03-29 18:10:04 --> UTF-8 Support Enabled
INFO - 2018-03-29 18:10:04 --> Utf8 Class Initialized
INFO - 2018-03-29 18:10:04 --> URI Class Initialized
INFO - 2018-03-29 18:10:04 --> Router Class Initialized
INFO - 2018-03-29 18:10:04 --> Output Class Initialized
INFO - 2018-03-29 18:10:04 --> Security Class Initialized
DEBUG - 2018-03-29 18:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 18:10:04 --> Input Class Initialized
INFO - 2018-03-29 18:10:04 --> Language Class Initialized
INFO - 2018-03-29 18:10:04 --> Loader Class Initialized
INFO - 2018-03-29 18:10:04 --> Helper loaded: url_helper
INFO - 2018-03-29 18:10:04 --> Helper loaded: form_helper
INFO - 2018-03-29 18:10:04 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:10:04 --> Controller Class Initialized
INFO - 2018-03-29 18:10:04 --> Model Class Initialized
INFO - 2018-03-29 18:10:04 --> Model Class Initialized
INFO - 2018-03-29 18:10:04 --> Helper loaded: date_helper
INFO - 2018-03-29 18:10:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 23:10:04 --> Final output sent to browser
DEBUG - 2018-03-29 23:10:04 --> Total execution time: 0.0952
INFO - 2018-03-29 18:10:08 --> Config Class Initialized
INFO - 2018-03-29 18:10:08 --> Hooks Class Initialized
DEBUG - 2018-03-29 18:10:08 --> UTF-8 Support Enabled
INFO - 2018-03-29 18:10:08 --> Utf8 Class Initialized
INFO - 2018-03-29 18:10:08 --> URI Class Initialized
INFO - 2018-03-29 18:10:08 --> Router Class Initialized
INFO - 2018-03-29 18:10:08 --> Output Class Initialized
INFO - 2018-03-29 18:10:08 --> Security Class Initialized
DEBUG - 2018-03-29 18:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 18:10:08 --> Input Class Initialized
INFO - 2018-03-29 18:10:08 --> Language Class Initialized
INFO - 2018-03-29 18:10:08 --> Loader Class Initialized
INFO - 2018-03-29 18:10:08 --> Helper loaded: url_helper
INFO - 2018-03-29 18:10:08 --> Helper loaded: form_helper
INFO - 2018-03-29 18:10:08 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:10:08 --> Controller Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Model Class Initialized
INFO - 2018-03-29 18:10:08 --> Helper loaded: date_helper
INFO - 2018-03-29 18:10:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 23:10:08 --> Final output sent to browser
DEBUG - 2018-03-29 23:10:08 --> Total execution time: 0.1447
INFO - 2018-03-29 18:10:36 --> Config Class Initialized
INFO - 2018-03-29 18:10:36 --> Hooks Class Initialized
DEBUG - 2018-03-29 18:10:36 --> UTF-8 Support Enabled
INFO - 2018-03-29 18:10:36 --> Utf8 Class Initialized
INFO - 2018-03-29 18:10:36 --> URI Class Initialized
INFO - 2018-03-29 18:10:36 --> Router Class Initialized
INFO - 2018-03-29 18:10:36 --> Output Class Initialized
INFO - 2018-03-29 18:10:36 --> Security Class Initialized
DEBUG - 2018-03-29 18:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 18:10:36 --> Input Class Initialized
INFO - 2018-03-29 18:10:36 --> Language Class Initialized
INFO - 2018-03-29 18:10:36 --> Loader Class Initialized
INFO - 2018-03-29 18:10:36 --> Helper loaded: url_helper
INFO - 2018-03-29 18:10:36 --> Helper loaded: form_helper
INFO - 2018-03-29 18:10:36 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:10:36 --> Controller Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Model Class Initialized
INFO - 2018-03-29 18:10:36 --> Helper loaded: date_helper
INFO - 2018-03-29 18:10:36 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 23:10:36 --> Model Class Initialized
INFO - 2018-03-29 23:10:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 23:10:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 23:10:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-29 23:10:36 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 23:10:36 --> Final output sent to browser
DEBUG - 2018-03-29 23:10:36 --> Total execution time: 0.1436
INFO - 2018-03-29 18:10:41 --> Config Class Initialized
INFO - 2018-03-29 18:10:41 --> Hooks Class Initialized
DEBUG - 2018-03-29 18:10:41 --> UTF-8 Support Enabled
INFO - 2018-03-29 18:10:41 --> Utf8 Class Initialized
INFO - 2018-03-29 18:10:41 --> URI Class Initialized
INFO - 2018-03-29 18:10:41 --> Router Class Initialized
INFO - 2018-03-29 18:10:41 --> Output Class Initialized
INFO - 2018-03-29 18:10:41 --> Security Class Initialized
DEBUG - 2018-03-29 18:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 18:10:41 --> Input Class Initialized
INFO - 2018-03-29 18:10:41 --> Language Class Initialized
INFO - 2018-03-29 18:10:41 --> Loader Class Initialized
INFO - 2018-03-29 18:10:41 --> Helper loaded: url_helper
INFO - 2018-03-29 18:10:41 --> Helper loaded: form_helper
INFO - 2018-03-29 18:10:41 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:10:41 --> Controller Class Initialized
INFO - 2018-03-29 18:10:41 --> Model Class Initialized
INFO - 2018-03-29 18:10:41 --> Model Class Initialized
INFO - 2018-03-29 18:10:41 --> Helper loaded: date_helper
INFO - 2018-03-29 18:10:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 23:10:41 --> Final output sent to browser
DEBUG - 2018-03-29 23:10:41 --> Total execution time: 0.0802
INFO - 2018-03-29 18:10:48 --> Config Class Initialized
INFO - 2018-03-29 18:10:48 --> Hooks Class Initialized
DEBUG - 2018-03-29 18:10:48 --> UTF-8 Support Enabled
INFO - 2018-03-29 18:10:48 --> Utf8 Class Initialized
INFO - 2018-03-29 18:10:48 --> URI Class Initialized
INFO - 2018-03-29 18:10:48 --> Router Class Initialized
INFO - 2018-03-29 18:10:48 --> Output Class Initialized
INFO - 2018-03-29 18:10:48 --> Security Class Initialized
DEBUG - 2018-03-29 18:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 18:10:48 --> Input Class Initialized
INFO - 2018-03-29 18:10:48 --> Language Class Initialized
INFO - 2018-03-29 18:10:48 --> Loader Class Initialized
INFO - 2018-03-29 18:10:48 --> Helper loaded: url_helper
INFO - 2018-03-29 18:10:48 --> Helper loaded: form_helper
INFO - 2018-03-29 18:10:48 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:10:48 --> Controller Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Model Class Initialized
INFO - 2018-03-29 18:10:48 --> Helper loaded: date_helper
INFO - 2018-03-29 18:10:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 23:10:48 --> Final output sent to browser
DEBUG - 2018-03-29 23:10:48 --> Total execution time: 0.1460
INFO - 2018-03-29 18:12:29 --> Config Class Initialized
INFO - 2018-03-29 18:12:29 --> Hooks Class Initialized
DEBUG - 2018-03-29 18:12:29 --> UTF-8 Support Enabled
INFO - 2018-03-29 18:12:29 --> Utf8 Class Initialized
INFO - 2018-03-29 18:12:29 --> URI Class Initialized
INFO - 2018-03-29 18:12:29 --> Router Class Initialized
INFO - 2018-03-29 18:12:29 --> Output Class Initialized
INFO - 2018-03-29 18:12:29 --> Security Class Initialized
DEBUG - 2018-03-29 18:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 18:12:29 --> Input Class Initialized
INFO - 2018-03-29 18:12:29 --> Language Class Initialized
INFO - 2018-03-29 18:12:29 --> Loader Class Initialized
INFO - 2018-03-29 18:12:29 --> Helper loaded: url_helper
INFO - 2018-03-29 18:12:29 --> Helper loaded: form_helper
INFO - 2018-03-29 18:12:29 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:12:29 --> Controller Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Model Class Initialized
INFO - 2018-03-29 18:12:29 --> Helper loaded: date_helper
INFO - 2018-03-29 18:12:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 23:12:29 --> Model Class Initialized
INFO - 2018-03-29 23:12:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 23:12:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 23:12:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-29 23:12:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 23:12:29 --> Final output sent to browser
DEBUG - 2018-03-29 23:12:29 --> Total execution time: 0.1583
INFO - 2018-03-29 18:12:33 --> Config Class Initialized
INFO - 2018-03-29 18:12:33 --> Hooks Class Initialized
DEBUG - 2018-03-29 18:12:33 --> UTF-8 Support Enabled
INFO - 2018-03-29 18:12:33 --> Utf8 Class Initialized
INFO - 2018-03-29 18:12:33 --> URI Class Initialized
INFO - 2018-03-29 18:12:33 --> Router Class Initialized
INFO - 2018-03-29 18:12:33 --> Output Class Initialized
INFO - 2018-03-29 18:12:33 --> Security Class Initialized
DEBUG - 2018-03-29 18:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 18:12:33 --> Input Class Initialized
INFO - 2018-03-29 18:12:33 --> Language Class Initialized
INFO - 2018-03-29 18:12:33 --> Loader Class Initialized
INFO - 2018-03-29 18:12:33 --> Helper loaded: url_helper
INFO - 2018-03-29 18:12:33 --> Helper loaded: form_helper
INFO - 2018-03-29 18:12:33 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:12:33 --> Controller Class Initialized
INFO - 2018-03-29 18:12:33 --> Model Class Initialized
INFO - 2018-03-29 18:12:33 --> Model Class Initialized
INFO - 2018-03-29 18:12:33 --> Helper loaded: date_helper
INFO - 2018-03-29 18:12:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 23:12:33 --> Final output sent to browser
DEBUG - 2018-03-29 23:12:33 --> Total execution time: 0.0956
INFO - 2018-03-29 18:12:37 --> Config Class Initialized
INFO - 2018-03-29 18:12:37 --> Hooks Class Initialized
DEBUG - 2018-03-29 18:12:37 --> UTF-8 Support Enabled
INFO - 2018-03-29 18:12:37 --> Utf8 Class Initialized
INFO - 2018-03-29 18:12:37 --> URI Class Initialized
INFO - 2018-03-29 18:12:37 --> Router Class Initialized
INFO - 2018-03-29 18:12:37 --> Output Class Initialized
INFO - 2018-03-29 18:12:37 --> Security Class Initialized
DEBUG - 2018-03-29 18:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 18:12:37 --> Input Class Initialized
INFO - 2018-03-29 18:12:37 --> Language Class Initialized
INFO - 2018-03-29 18:12:37 --> Loader Class Initialized
INFO - 2018-03-29 18:12:37 --> Helper loaded: url_helper
INFO - 2018-03-29 18:12:37 --> Helper loaded: form_helper
INFO - 2018-03-29 18:12:37 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:12:37 --> Controller Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Model Class Initialized
INFO - 2018-03-29 18:12:37 --> Helper loaded: date_helper
INFO - 2018-03-29 18:12:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 23:12:37 --> Final output sent to browser
DEBUG - 2018-03-29 23:12:37 --> Total execution time: 0.1178
INFO - 2018-03-29 18:12:58 --> Config Class Initialized
INFO - 2018-03-29 18:12:58 --> Hooks Class Initialized
DEBUG - 2018-03-29 18:12:58 --> UTF-8 Support Enabled
INFO - 2018-03-29 18:12:58 --> Utf8 Class Initialized
INFO - 2018-03-29 18:12:58 --> URI Class Initialized
INFO - 2018-03-29 18:12:58 --> Router Class Initialized
INFO - 2018-03-29 18:12:58 --> Output Class Initialized
INFO - 2018-03-29 18:12:58 --> Security Class Initialized
DEBUG - 2018-03-29 18:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 18:12:58 --> Input Class Initialized
INFO - 2018-03-29 18:12:58 --> Language Class Initialized
INFO - 2018-03-29 18:12:58 --> Loader Class Initialized
INFO - 2018-03-29 18:12:58 --> Helper loaded: url_helper
INFO - 2018-03-29 18:12:58 --> Helper loaded: form_helper
INFO - 2018-03-29 18:12:58 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:12:58 --> Controller Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Model Class Initialized
INFO - 2018-03-29 18:12:58 --> Helper loaded: date_helper
INFO - 2018-03-29 18:12:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 23:12:58 --> Model Class Initialized
INFO - 2018-03-29 23:12:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-29 23:12:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-29 23:12:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-29 23:12:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-29 23:12:58 --> Final output sent to browser
DEBUG - 2018-03-29 23:12:58 --> Total execution time: 0.1448
INFO - 2018-03-29 18:13:02 --> Config Class Initialized
INFO - 2018-03-29 18:13:02 --> Hooks Class Initialized
DEBUG - 2018-03-29 18:13:02 --> UTF-8 Support Enabled
INFO - 2018-03-29 18:13:02 --> Utf8 Class Initialized
INFO - 2018-03-29 18:13:02 --> URI Class Initialized
INFO - 2018-03-29 18:13:02 --> Router Class Initialized
INFO - 2018-03-29 18:13:02 --> Output Class Initialized
INFO - 2018-03-29 18:13:02 --> Security Class Initialized
DEBUG - 2018-03-29 18:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 18:13:02 --> Input Class Initialized
INFO - 2018-03-29 18:13:02 --> Language Class Initialized
INFO - 2018-03-29 18:13:02 --> Loader Class Initialized
INFO - 2018-03-29 18:13:02 --> Helper loaded: url_helper
INFO - 2018-03-29 18:13:02 --> Helper loaded: form_helper
INFO - 2018-03-29 18:13:02 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:13:02 --> Controller Class Initialized
INFO - 2018-03-29 18:13:02 --> Model Class Initialized
INFO - 2018-03-29 18:13:02 --> Model Class Initialized
INFO - 2018-03-29 18:13:02 --> Helper loaded: date_helper
INFO - 2018-03-29 18:13:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 23:13:02 --> Final output sent to browser
DEBUG - 2018-03-29 23:13:02 --> Total execution time: 0.0774
INFO - 2018-03-29 18:13:06 --> Config Class Initialized
INFO - 2018-03-29 18:13:06 --> Hooks Class Initialized
DEBUG - 2018-03-29 18:13:06 --> UTF-8 Support Enabled
INFO - 2018-03-29 18:13:06 --> Utf8 Class Initialized
INFO - 2018-03-29 18:13:06 --> URI Class Initialized
INFO - 2018-03-29 18:13:06 --> Router Class Initialized
INFO - 2018-03-29 18:13:06 --> Output Class Initialized
INFO - 2018-03-29 18:13:06 --> Security Class Initialized
DEBUG - 2018-03-29 18:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-29 18:13:06 --> Input Class Initialized
INFO - 2018-03-29 18:13:06 --> Language Class Initialized
INFO - 2018-03-29 18:13:06 --> Loader Class Initialized
INFO - 2018-03-29 18:13:06 --> Helper loaded: url_helper
INFO - 2018-03-29 18:13:06 --> Helper loaded: form_helper
INFO - 2018-03-29 18:13:06 --> Database Driver Class Initialized
DEBUG - 2018-03-29 18:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-29 18:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-29 18:13:06 --> Controller Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Model Class Initialized
INFO - 2018-03-29 18:13:06 --> Helper loaded: date_helper
INFO - 2018-03-29 18:13:06 --> Helper loaded: tanggal_helper
INFO - 2018-03-29 23:13:06 --> Final output sent to browser
DEBUG - 2018-03-29 23:13:06 --> Total execution time: 0.1262
