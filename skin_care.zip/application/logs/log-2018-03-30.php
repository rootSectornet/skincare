<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-30 16:23:08 --> Config Class Initialized
INFO - 2018-03-30 16:23:08 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:23:08 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:23:08 --> Utf8 Class Initialized
INFO - 2018-03-30 16:23:08 --> URI Class Initialized
INFO - 2018-03-30 16:23:08 --> Router Class Initialized
INFO - 2018-03-30 16:23:08 --> Output Class Initialized
INFO - 2018-03-30 16:23:08 --> Security Class Initialized
DEBUG - 2018-03-30 16:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:23:08 --> Input Class Initialized
INFO - 2018-03-30 16:23:08 --> Language Class Initialized
INFO - 2018-03-30 16:23:09 --> Loader Class Initialized
INFO - 2018-03-30 16:23:09 --> Helper loaded: url_helper
INFO - 2018-03-30 16:23:09 --> Helper loaded: form_helper
INFO - 2018-03-30 16:23:09 --> Database Driver Class Initialized
ERROR - 2018-03-30 16:23:11 --> Unable to connect to the database
DEBUG - 2018-03-30 16:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:23:11 --> Controller Class Initialized
INFO - 2018-03-30 16:23:11 --> Config Class Initialized
INFO - 2018-03-30 16:23:11 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:23:11 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:23:11 --> Utf8 Class Initialized
INFO - 2018-03-30 16:23:11 --> URI Class Initialized
INFO - 2018-03-30 16:23:11 --> Router Class Initialized
INFO - 2018-03-30 16:23:11 --> Output Class Initialized
INFO - 2018-03-30 16:23:11 --> Security Class Initialized
DEBUG - 2018-03-30 16:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:23:11 --> Input Class Initialized
INFO - 2018-03-30 16:23:11 --> Language Class Initialized
INFO - 2018-03-30 16:23:11 --> Loader Class Initialized
INFO - 2018-03-30 16:23:11 --> Helper loaded: url_helper
INFO - 2018-03-30 16:23:11 --> Helper loaded: form_helper
INFO - 2018-03-30 16:23:11 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:23:14 --> Controller Class Initialized
INFO - 2018-03-30 16:23:14 --> Model Class Initialized
INFO - 2018-03-30 16:23:14 --> Model Class Initialized
INFO - 2018-03-30 16:23:14 --> Model Class Initialized
INFO - 2018-03-30 16:23:14 --> Helper loaded: date_helper
INFO - 2018-03-30 21:23:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-30 21:23:14 --> Final output sent to browser
DEBUG - 2018-03-30 21:23:14 --> Total execution time: 2.9630
INFO - 2018-03-30 16:23:50 --> Config Class Initialized
INFO - 2018-03-30 16:23:50 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:23:50 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:23:50 --> Utf8 Class Initialized
INFO - 2018-03-30 16:23:50 --> URI Class Initialized
INFO - 2018-03-30 16:23:50 --> Router Class Initialized
INFO - 2018-03-30 16:23:50 --> Output Class Initialized
INFO - 2018-03-30 16:23:50 --> Security Class Initialized
DEBUG - 2018-03-30 16:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:23:50 --> Input Class Initialized
INFO - 2018-03-30 16:23:50 --> Language Class Initialized
INFO - 2018-03-30 16:23:50 --> Loader Class Initialized
INFO - 2018-03-30 16:23:50 --> Helper loaded: url_helper
INFO - 2018-03-30 16:23:50 --> Helper loaded: form_helper
INFO - 2018-03-30 16:23:50 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:23:51 --> Controller Class Initialized
INFO - 2018-03-30 16:23:51 --> Model Class Initialized
INFO - 2018-03-30 16:23:51 --> Model Class Initialized
INFO - 2018-03-30 16:23:51 --> Model Class Initialized
INFO - 2018-03-30 16:23:51 --> Helper loaded: date_helper
INFO - 2018-03-30 16:23:52 --> Config Class Initialized
INFO - 2018-03-30 16:23:52 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:23:52 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:23:52 --> Utf8 Class Initialized
INFO - 2018-03-30 16:23:52 --> URI Class Initialized
INFO - 2018-03-30 16:23:52 --> Router Class Initialized
INFO - 2018-03-30 16:23:52 --> Output Class Initialized
INFO - 2018-03-30 16:23:52 --> Security Class Initialized
DEBUG - 2018-03-30 16:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:23:52 --> Input Class Initialized
INFO - 2018-03-30 16:23:52 --> Language Class Initialized
INFO - 2018-03-30 16:23:52 --> Loader Class Initialized
INFO - 2018-03-30 16:23:52 --> Helper loaded: url_helper
INFO - 2018-03-30 16:23:52 --> Helper loaded: form_helper
INFO - 2018-03-30 16:23:52 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:23:52 --> Controller Class Initialized
INFO - 2018-03-30 16:23:52 --> Model Class Initialized
INFO - 2018-03-30 16:23:52 --> Model Class Initialized
INFO - 2018-03-30 16:23:52 --> Model Class Initialized
INFO - 2018-03-30 16:23:52 --> Model Class Initialized
INFO - 2018-03-30 16:23:52 --> Model Class Initialized
INFO - 2018-03-30 16:23:52 --> Helper loaded: date_helper
INFO - 2018-03-30 21:23:53 --> Model Class Initialized
INFO - 2018-03-30 21:23:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 21:23:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 21:23:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-30 21:23:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 21:23:53 --> Final output sent to browser
DEBUG - 2018-03-30 21:23:53 --> Total execution time: 1.4557
INFO - 2018-03-30 16:24:10 --> Config Class Initialized
INFO - 2018-03-30 16:24:10 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:24:10 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:24:10 --> Utf8 Class Initialized
INFO - 2018-03-30 16:24:10 --> URI Class Initialized
INFO - 2018-03-30 16:24:10 --> Router Class Initialized
INFO - 2018-03-30 16:24:10 --> Output Class Initialized
INFO - 2018-03-30 16:24:10 --> Security Class Initialized
DEBUG - 2018-03-30 16:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:24:10 --> Input Class Initialized
INFO - 2018-03-30 16:24:10 --> Language Class Initialized
INFO - 2018-03-30 16:24:10 --> Loader Class Initialized
INFO - 2018-03-30 16:24:10 --> Helper loaded: url_helper
INFO - 2018-03-30 16:24:10 --> Helper loaded: form_helper
INFO - 2018-03-30 16:24:10 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:24:10 --> Controller Class Initialized
INFO - 2018-03-30 16:24:10 --> Model Class Initialized
INFO - 2018-03-30 16:24:11 --> Model Class Initialized
INFO - 2018-03-30 16:24:11 --> Model Class Initialized
INFO - 2018-03-30 16:24:11 --> Model Class Initialized
INFO - 2018-03-30 16:24:11 --> Model Class Initialized
INFO - 2018-03-30 16:24:11 --> Model Class Initialized
INFO - 2018-03-30 16:24:11 --> Model Class Initialized
INFO - 2018-03-30 16:24:11 --> Helper loaded: date_helper
INFO - 2018-03-30 16:24:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:24:11 --> Model Class Initialized
INFO - 2018-03-30 21:24:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 21:24:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 21:24:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/table.php
INFO - 2018-03-30 21:24:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 21:24:11 --> Final output sent to browser
DEBUG - 2018-03-30 21:24:11 --> Total execution time: 0.6537
INFO - 2018-03-30 16:24:12 --> Config Class Initialized
INFO - 2018-03-30 16:24:12 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:24:12 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:24:12 --> Utf8 Class Initialized
INFO - 2018-03-30 16:24:12 --> URI Class Initialized
INFO - 2018-03-30 16:24:12 --> Router Class Initialized
INFO - 2018-03-30 16:24:12 --> Output Class Initialized
INFO - 2018-03-30 16:24:12 --> Security Class Initialized
DEBUG - 2018-03-30 16:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:24:12 --> Input Class Initialized
INFO - 2018-03-30 16:24:12 --> Language Class Initialized
INFO - 2018-03-30 16:24:12 --> Loader Class Initialized
INFO - 2018-03-30 16:24:12 --> Helper loaded: url_helper
INFO - 2018-03-30 16:24:12 --> Helper loaded: form_helper
INFO - 2018-03-30 16:24:12 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:24:12 --> Controller Class Initialized
INFO - 2018-03-30 16:24:12 --> Model Class Initialized
INFO - 2018-03-30 16:24:12 --> Model Class Initialized
INFO - 2018-03-30 16:24:12 --> Model Class Initialized
INFO - 2018-03-30 16:24:12 --> Model Class Initialized
INFO - 2018-03-30 16:24:12 --> Model Class Initialized
INFO - 2018-03-30 16:24:12 --> Model Class Initialized
INFO - 2018-03-30 16:24:12 --> Model Class Initialized
INFO - 2018-03-30 16:24:12 --> Helper loaded: date_helper
INFO - 2018-03-30 16:24:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:24:12 --> Model Class Initialized
INFO - 2018-03-30 21:24:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 21:24:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 21:24:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\penjualan/create.php
INFO - 2018-03-30 21:24:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 21:24:12 --> Final output sent to browser
DEBUG - 2018-03-30 21:24:12 --> Total execution time: 0.1187
INFO - 2018-03-30 16:24:18 --> Config Class Initialized
INFO - 2018-03-30 16:24:18 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:24:18 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:24:18 --> Utf8 Class Initialized
INFO - 2018-03-30 16:24:18 --> URI Class Initialized
INFO - 2018-03-30 16:24:18 --> Router Class Initialized
INFO - 2018-03-30 16:24:18 --> Output Class Initialized
INFO - 2018-03-30 16:24:18 --> Security Class Initialized
DEBUG - 2018-03-30 16:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:24:18 --> Input Class Initialized
INFO - 2018-03-30 16:24:18 --> Language Class Initialized
INFO - 2018-03-30 16:24:18 --> Loader Class Initialized
INFO - 2018-03-30 16:24:18 --> Helper loaded: url_helper
INFO - 2018-03-30 16:24:18 --> Helper loaded: form_helper
INFO - 2018-03-30 16:24:18 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:24:18 --> Controller Class Initialized
INFO - 2018-03-30 16:24:18 --> Model Class Initialized
INFO - 2018-03-30 16:24:18 --> Model Class Initialized
INFO - 2018-03-30 16:24:18 --> Helper loaded: date_helper
INFO - 2018-03-30 16:24:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:24:18 --> Final output sent to browser
DEBUG - 2018-03-30 21:24:18 --> Total execution time: 0.1234
INFO - 2018-03-30 16:26:18 --> Config Class Initialized
INFO - 2018-03-30 16:26:18 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:26:18 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:26:18 --> Utf8 Class Initialized
INFO - 2018-03-30 16:26:18 --> URI Class Initialized
INFO - 2018-03-30 16:26:18 --> Router Class Initialized
INFO - 2018-03-30 16:26:18 --> Output Class Initialized
INFO - 2018-03-30 16:26:18 --> Security Class Initialized
DEBUG - 2018-03-30 16:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:26:18 --> Input Class Initialized
INFO - 2018-03-30 16:26:18 --> Language Class Initialized
INFO - 2018-03-30 16:26:18 --> Loader Class Initialized
INFO - 2018-03-30 16:26:18 --> Helper loaded: url_helper
INFO - 2018-03-30 16:26:18 --> Helper loaded: form_helper
INFO - 2018-03-30 16:26:18 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:26:18 --> Controller Class Initialized
INFO - 2018-03-30 16:26:18 --> Model Class Initialized
INFO - 2018-03-30 16:26:18 --> Model Class Initialized
INFO - 2018-03-30 16:26:18 --> Model Class Initialized
INFO - 2018-03-30 16:26:18 --> Model Class Initialized
INFO - 2018-03-30 16:26:18 --> Model Class Initialized
INFO - 2018-03-30 16:26:18 --> Model Class Initialized
INFO - 2018-03-30 16:26:18 --> Model Class Initialized
INFO - 2018-03-30 16:26:18 --> Model Class Initialized
INFO - 2018-03-30 16:26:18 --> Model Class Initialized
INFO - 2018-03-30 16:26:18 --> Model Class Initialized
INFO - 2018-03-30 16:26:18 --> Model Class Initialized
INFO - 2018-03-30 16:26:18 --> Model Class Initialized
INFO - 2018-03-30 16:26:18 --> Model Class Initialized
INFO - 2018-03-30 16:26:18 --> Model Class Initialized
INFO - 2018-03-30 16:26:18 --> Model Class Initialized
INFO - 2018-03-30 16:26:18 --> Helper loaded: date_helper
INFO - 2018-03-30 16:26:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:26:19 --> Model Class Initialized
INFO - 2018-03-30 21:26:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 21:26:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 21:26:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-30 21:26:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 21:26:19 --> Final output sent to browser
DEBUG - 2018-03-30 21:26:19 --> Total execution time: 1.4204
INFO - 2018-03-30 16:26:24 --> Config Class Initialized
INFO - 2018-03-30 16:26:24 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:26:24 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:26:24 --> Utf8 Class Initialized
INFO - 2018-03-30 16:26:24 --> URI Class Initialized
INFO - 2018-03-30 16:26:24 --> Router Class Initialized
INFO - 2018-03-30 16:26:24 --> Output Class Initialized
INFO - 2018-03-30 16:26:24 --> Security Class Initialized
DEBUG - 2018-03-30 16:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:26:24 --> Input Class Initialized
INFO - 2018-03-30 16:26:24 --> Language Class Initialized
INFO - 2018-03-30 16:26:24 --> Loader Class Initialized
INFO - 2018-03-30 16:26:24 --> Helper loaded: url_helper
INFO - 2018-03-30 16:26:24 --> Helper loaded: form_helper
INFO - 2018-03-30 16:26:24 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:26:24 --> Controller Class Initialized
INFO - 2018-03-30 16:26:24 --> Model Class Initialized
INFO - 2018-03-30 16:26:24 --> Model Class Initialized
INFO - 2018-03-30 16:26:24 --> Model Class Initialized
INFO - 2018-03-30 16:26:24 --> Model Class Initialized
INFO - 2018-03-30 16:26:24 --> Model Class Initialized
INFO - 2018-03-30 16:26:24 --> Model Class Initialized
INFO - 2018-03-30 16:26:24 --> Model Class Initialized
INFO - 2018-03-30 16:26:24 --> Model Class Initialized
INFO - 2018-03-30 16:26:24 --> Model Class Initialized
INFO - 2018-03-30 16:26:24 --> Model Class Initialized
INFO - 2018-03-30 16:26:24 --> Model Class Initialized
INFO - 2018-03-30 16:26:24 --> Model Class Initialized
INFO - 2018-03-30 16:26:24 --> Model Class Initialized
INFO - 2018-03-30 16:26:24 --> Model Class Initialized
INFO - 2018-03-30 16:26:24 --> Model Class Initialized
INFO - 2018-03-30 16:26:24 --> Helper loaded: date_helper
INFO - 2018-03-30 16:26:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:26:24 --> Final output sent to browser
DEBUG - 2018-03-30 21:26:24 --> Total execution time: 0.1048
INFO - 2018-03-30 16:26:28 --> Config Class Initialized
INFO - 2018-03-30 16:26:28 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:26:28 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:26:28 --> Utf8 Class Initialized
INFO - 2018-03-30 16:26:28 --> URI Class Initialized
INFO - 2018-03-30 16:26:28 --> Router Class Initialized
INFO - 2018-03-30 16:26:28 --> Output Class Initialized
INFO - 2018-03-30 16:26:28 --> Security Class Initialized
DEBUG - 2018-03-30 16:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:26:28 --> Input Class Initialized
INFO - 2018-03-30 16:26:28 --> Language Class Initialized
INFO - 2018-03-30 16:26:28 --> Loader Class Initialized
INFO - 2018-03-30 16:26:28 --> Helper loaded: url_helper
INFO - 2018-03-30 16:26:28 --> Helper loaded: form_helper
INFO - 2018-03-30 16:26:28 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:26:28 --> Controller Class Initialized
INFO - 2018-03-30 16:26:28 --> Model Class Initialized
INFO - 2018-03-30 16:26:28 --> Model Class Initialized
INFO - 2018-03-30 16:26:28 --> Model Class Initialized
INFO - 2018-03-30 16:26:28 --> Model Class Initialized
INFO - 2018-03-30 16:26:28 --> Model Class Initialized
INFO - 2018-03-30 16:26:28 --> Model Class Initialized
INFO - 2018-03-30 16:26:28 --> Model Class Initialized
INFO - 2018-03-30 16:26:28 --> Model Class Initialized
INFO - 2018-03-30 16:26:28 --> Model Class Initialized
INFO - 2018-03-30 16:26:28 --> Model Class Initialized
INFO - 2018-03-30 16:26:28 --> Model Class Initialized
INFO - 2018-03-30 16:26:28 --> Model Class Initialized
INFO - 2018-03-30 16:26:28 --> Model Class Initialized
INFO - 2018-03-30 16:26:28 --> Model Class Initialized
INFO - 2018-03-30 16:26:28 --> Model Class Initialized
INFO - 2018-03-30 16:26:28 --> Helper loaded: date_helper
INFO - 2018-03-30 16:26:28 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:26:28 --> Model Class Initialized
INFO - 2018-03-30 21:26:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 21:26:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 21:26:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Kasir/TagihanPenjualan/table.php
INFO - 2018-03-30 21:26:28 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 21:26:28 --> Final output sent to browser
DEBUG - 2018-03-30 21:26:28 --> Total execution time: 0.1306
INFO - 2018-03-30 16:28:05 --> Config Class Initialized
INFO - 2018-03-30 16:28:05 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:28:05 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:28:05 --> Utf8 Class Initialized
INFO - 2018-03-30 16:28:05 --> URI Class Initialized
INFO - 2018-03-30 16:28:05 --> Router Class Initialized
INFO - 2018-03-30 16:28:05 --> Output Class Initialized
INFO - 2018-03-30 16:28:05 --> Security Class Initialized
DEBUG - 2018-03-30 16:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:28:05 --> Input Class Initialized
INFO - 2018-03-30 16:28:05 --> Language Class Initialized
INFO - 2018-03-30 16:28:05 --> Loader Class Initialized
INFO - 2018-03-30 16:28:05 --> Helper loaded: url_helper
INFO - 2018-03-30 16:28:05 --> Helper loaded: form_helper
INFO - 2018-03-30 16:28:05 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:28:05 --> Controller Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Model Class Initialized
INFO - 2018-03-30 16:28:05 --> Helper loaded: date_helper
INFO - 2018-03-30 16:28:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:28:05 --> Model Class Initialized
INFO - 2018-03-30 21:28:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 21:28:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 21:28:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-30 21:28:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 21:28:05 --> Final output sent to browser
DEBUG - 2018-03-30 21:28:05 --> Total execution time: 0.2503
INFO - 2018-03-30 16:28:15 --> Config Class Initialized
INFO - 2018-03-30 16:28:15 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:28:15 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:28:15 --> Utf8 Class Initialized
INFO - 2018-03-30 16:28:15 --> URI Class Initialized
INFO - 2018-03-30 16:28:15 --> Router Class Initialized
INFO - 2018-03-30 16:28:15 --> Output Class Initialized
INFO - 2018-03-30 16:28:15 --> Security Class Initialized
DEBUG - 2018-03-30 16:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:28:15 --> Input Class Initialized
INFO - 2018-03-30 16:28:15 --> Language Class Initialized
INFO - 2018-03-30 16:28:15 --> Loader Class Initialized
INFO - 2018-03-30 16:28:15 --> Helper loaded: url_helper
INFO - 2018-03-30 16:28:15 --> Helper loaded: form_helper
INFO - 2018-03-30 16:28:15 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:28:15 --> Controller Class Initialized
INFO - 2018-03-30 16:28:15 --> Model Class Initialized
INFO - 2018-03-30 16:28:15 --> Model Class Initialized
INFO - 2018-03-30 16:28:15 --> Helper loaded: date_helper
INFO - 2018-03-30 16:28:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:28:15 --> Final output sent to browser
DEBUG - 2018-03-30 21:28:15 --> Total execution time: 0.1732
INFO - 2018-03-30 16:28:15 --> Config Class Initialized
INFO - 2018-03-30 16:28:15 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:28:15 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:28:15 --> Utf8 Class Initialized
INFO - 2018-03-30 16:28:15 --> URI Class Initialized
INFO - 2018-03-30 16:28:15 --> Router Class Initialized
INFO - 2018-03-30 16:28:15 --> Output Class Initialized
INFO - 2018-03-30 16:28:15 --> Security Class Initialized
DEBUG - 2018-03-30 16:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:28:15 --> Input Class Initialized
INFO - 2018-03-30 16:28:15 --> Language Class Initialized
INFO - 2018-03-30 16:28:15 --> Loader Class Initialized
INFO - 2018-03-30 16:28:15 --> Helper loaded: url_helper
INFO - 2018-03-30 16:28:15 --> Helper loaded: form_helper
INFO - 2018-03-30 16:28:15 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:28:15 --> Controller Class Initialized
INFO - 2018-03-30 16:28:15 --> Model Class Initialized
INFO - 2018-03-30 16:28:15 --> Model Class Initialized
INFO - 2018-03-30 16:28:15 --> Helper loaded: date_helper
INFO - 2018-03-30 16:28:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:28:15 --> Final output sent to browser
DEBUG - 2018-03-30 21:28:15 --> Total execution time: 0.0941
INFO - 2018-03-30 16:28:17 --> Config Class Initialized
INFO - 2018-03-30 16:28:17 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:28:17 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:28:17 --> Utf8 Class Initialized
INFO - 2018-03-30 16:28:17 --> URI Class Initialized
INFO - 2018-03-30 16:28:17 --> Router Class Initialized
INFO - 2018-03-30 16:28:17 --> Output Class Initialized
INFO - 2018-03-30 16:28:17 --> Security Class Initialized
DEBUG - 2018-03-30 16:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:28:17 --> Input Class Initialized
INFO - 2018-03-30 16:28:17 --> Language Class Initialized
INFO - 2018-03-30 16:28:17 --> Loader Class Initialized
INFO - 2018-03-30 16:28:17 --> Helper loaded: url_helper
INFO - 2018-03-30 16:28:17 --> Helper loaded: form_helper
INFO - 2018-03-30 16:28:17 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:28:17 --> Controller Class Initialized
INFO - 2018-03-30 16:28:17 --> Model Class Initialized
INFO - 2018-03-30 16:28:17 --> Model Class Initialized
INFO - 2018-03-30 16:28:17 --> Helper loaded: date_helper
INFO - 2018-03-30 16:28:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:28:17 --> Final output sent to browser
DEBUG - 2018-03-30 21:28:17 --> Total execution time: 0.1417
INFO - 2018-03-30 16:28:18 --> Config Class Initialized
INFO - 2018-03-30 16:28:18 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:28:18 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:28:18 --> Utf8 Class Initialized
INFO - 2018-03-30 16:28:18 --> URI Class Initialized
INFO - 2018-03-30 16:28:18 --> Router Class Initialized
INFO - 2018-03-30 16:28:18 --> Output Class Initialized
INFO - 2018-03-30 16:28:18 --> Security Class Initialized
DEBUG - 2018-03-30 16:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:28:18 --> Input Class Initialized
INFO - 2018-03-30 16:28:18 --> Language Class Initialized
INFO - 2018-03-30 16:28:19 --> Loader Class Initialized
INFO - 2018-03-30 16:28:19 --> Helper loaded: url_helper
INFO - 2018-03-30 16:28:19 --> Helper loaded: form_helper
INFO - 2018-03-30 16:28:19 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:28:19 --> Controller Class Initialized
INFO - 2018-03-30 16:28:19 --> Model Class Initialized
INFO - 2018-03-30 16:28:19 --> Model Class Initialized
INFO - 2018-03-30 16:28:19 --> Helper loaded: date_helper
INFO - 2018-03-30 16:28:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:28:19 --> Final output sent to browser
DEBUG - 2018-03-30 21:28:19 --> Total execution time: 0.1075
INFO - 2018-03-30 16:28:25 --> Config Class Initialized
INFO - 2018-03-30 16:28:25 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:28:25 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:28:25 --> Utf8 Class Initialized
INFO - 2018-03-30 16:28:25 --> URI Class Initialized
INFO - 2018-03-30 16:28:25 --> Router Class Initialized
INFO - 2018-03-30 16:28:25 --> Output Class Initialized
INFO - 2018-03-30 16:28:25 --> Security Class Initialized
DEBUG - 2018-03-30 16:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:28:25 --> Input Class Initialized
INFO - 2018-03-30 16:28:25 --> Language Class Initialized
INFO - 2018-03-30 16:28:25 --> Loader Class Initialized
INFO - 2018-03-30 16:28:25 --> Helper loaded: url_helper
INFO - 2018-03-30 16:28:25 --> Helper loaded: form_helper
INFO - 2018-03-30 16:28:25 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:28:25 --> Controller Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Model Class Initialized
INFO - 2018-03-30 16:28:25 --> Helper loaded: date_helper
INFO - 2018-03-30 16:28:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:28:25 --> Final output sent to browser
DEBUG - 2018-03-30 21:28:25 --> Total execution time: 0.2845
INFO - 2018-03-30 16:28:53 --> Config Class Initialized
INFO - 2018-03-30 16:28:53 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:28:53 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:28:53 --> Utf8 Class Initialized
INFO - 2018-03-30 16:28:53 --> URI Class Initialized
INFO - 2018-03-30 16:28:53 --> Router Class Initialized
INFO - 2018-03-30 16:28:53 --> Output Class Initialized
INFO - 2018-03-30 16:28:53 --> Security Class Initialized
DEBUG - 2018-03-30 16:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:28:53 --> Input Class Initialized
INFO - 2018-03-30 16:28:53 --> Language Class Initialized
INFO - 2018-03-30 16:28:53 --> Loader Class Initialized
INFO - 2018-03-30 16:28:53 --> Helper loaded: url_helper
INFO - 2018-03-30 16:28:53 --> Helper loaded: form_helper
INFO - 2018-03-30 16:28:53 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:28:53 --> Controller Class Initialized
INFO - 2018-03-30 16:28:53 --> Model Class Initialized
INFO - 2018-03-30 16:28:53 --> Model Class Initialized
INFO - 2018-03-30 16:28:53 --> Model Class Initialized
INFO - 2018-03-30 16:28:53 --> Helper loaded: date_helper
INFO - 2018-03-30 16:28:53 --> Config Class Initialized
INFO - 2018-03-30 16:28:53 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:28:53 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:28:53 --> Utf8 Class Initialized
INFO - 2018-03-30 16:28:53 --> URI Class Initialized
INFO - 2018-03-30 16:28:53 --> Router Class Initialized
INFO - 2018-03-30 16:28:53 --> Output Class Initialized
INFO - 2018-03-30 16:28:53 --> Security Class Initialized
DEBUG - 2018-03-30 16:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:28:53 --> Input Class Initialized
INFO - 2018-03-30 16:28:53 --> Language Class Initialized
INFO - 2018-03-30 16:28:53 --> Loader Class Initialized
INFO - 2018-03-30 16:28:53 --> Helper loaded: url_helper
INFO - 2018-03-30 16:28:53 --> Helper loaded: form_helper
INFO - 2018-03-30 16:28:53 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:28:53 --> Controller Class Initialized
INFO - 2018-03-30 16:28:53 --> Model Class Initialized
INFO - 2018-03-30 16:28:53 --> Model Class Initialized
INFO - 2018-03-30 16:28:53 --> Model Class Initialized
INFO - 2018-03-30 16:28:53 --> Helper loaded: date_helper
INFO - 2018-03-30 21:28:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-30 21:28:53 --> Final output sent to browser
DEBUG - 2018-03-30 21:28:53 --> Total execution time: 0.0990
INFO - 2018-03-30 16:30:02 --> Config Class Initialized
INFO - 2018-03-30 16:30:02 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:30:02 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:30:02 --> Utf8 Class Initialized
INFO - 2018-03-30 16:30:02 --> URI Class Initialized
INFO - 2018-03-30 16:30:02 --> Router Class Initialized
INFO - 2018-03-30 16:30:02 --> Output Class Initialized
INFO - 2018-03-30 16:30:02 --> Security Class Initialized
DEBUG - 2018-03-30 16:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:30:02 --> Input Class Initialized
INFO - 2018-03-30 16:30:02 --> Language Class Initialized
INFO - 2018-03-30 16:30:02 --> Loader Class Initialized
INFO - 2018-03-30 16:30:02 --> Helper loaded: url_helper
INFO - 2018-03-30 16:30:02 --> Helper loaded: form_helper
INFO - 2018-03-30 16:30:02 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:30:02 --> Controller Class Initialized
INFO - 2018-03-30 16:30:02 --> Model Class Initialized
INFO - 2018-03-30 16:30:02 --> Model Class Initialized
INFO - 2018-03-30 16:30:02 --> Model Class Initialized
INFO - 2018-03-30 16:30:02 --> Helper loaded: date_helper
INFO - 2018-03-30 16:30:02 --> Config Class Initialized
INFO - 2018-03-30 16:30:02 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:30:02 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:30:02 --> Utf8 Class Initialized
INFO - 2018-03-30 16:30:02 --> URI Class Initialized
INFO - 2018-03-30 16:30:02 --> Router Class Initialized
INFO - 2018-03-30 16:30:02 --> Output Class Initialized
INFO - 2018-03-30 16:30:02 --> Security Class Initialized
DEBUG - 2018-03-30 16:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:30:02 --> Input Class Initialized
INFO - 2018-03-30 16:30:02 --> Language Class Initialized
INFO - 2018-03-30 16:30:02 --> Loader Class Initialized
INFO - 2018-03-30 16:30:02 --> Helper loaded: url_helper
INFO - 2018-03-30 16:30:02 --> Helper loaded: form_helper
INFO - 2018-03-30 16:30:02 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:30:02 --> Controller Class Initialized
INFO - 2018-03-30 16:30:02 --> Model Class Initialized
INFO - 2018-03-30 16:30:02 --> Model Class Initialized
INFO - 2018-03-30 16:30:02 --> Model Class Initialized
INFO - 2018-03-30 16:30:02 --> Model Class Initialized
INFO - 2018-03-30 16:30:02 --> Model Class Initialized
INFO - 2018-03-30 16:30:02 --> Helper loaded: date_helper
INFO - 2018-03-30 21:30:02 --> Model Class Initialized
INFO - 2018-03-30 21:30:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 21:30:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 21:30:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-30 21:30:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 21:30:02 --> Final output sent to browser
DEBUG - 2018-03-30 21:30:02 --> Total execution time: 0.1055
INFO - 2018-03-30 16:40:20 --> Config Class Initialized
INFO - 2018-03-30 16:40:20 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:40:20 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:40:20 --> Utf8 Class Initialized
INFO - 2018-03-30 16:40:20 --> URI Class Initialized
INFO - 2018-03-30 16:40:20 --> Router Class Initialized
INFO - 2018-03-30 16:40:20 --> Output Class Initialized
INFO - 2018-03-30 16:40:20 --> Security Class Initialized
DEBUG - 2018-03-30 16:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:40:20 --> Input Class Initialized
INFO - 2018-03-30 16:40:20 --> Language Class Initialized
INFO - 2018-03-30 16:40:20 --> Loader Class Initialized
INFO - 2018-03-30 16:40:20 --> Helper loaded: url_helper
INFO - 2018-03-30 16:40:20 --> Helper loaded: form_helper
INFO - 2018-03-30 16:40:20 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:40:20 --> Controller Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Model Class Initialized
INFO - 2018-03-30 16:40:20 --> Helper loaded: date_helper
INFO - 2018-03-30 16:40:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:40:20 --> Model Class Initialized
INFO - 2018-03-30 21:40:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 21:40:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 21:40:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-30 21:40:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 21:40:20 --> Final output sent to browser
DEBUG - 2018-03-30 21:40:20 --> Total execution time: 0.1475
INFO - 2018-03-30 16:40:24 --> Config Class Initialized
INFO - 2018-03-30 16:40:24 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:40:24 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:40:24 --> Utf8 Class Initialized
INFO - 2018-03-30 16:40:24 --> URI Class Initialized
INFO - 2018-03-30 16:40:24 --> Router Class Initialized
INFO - 2018-03-30 16:40:24 --> Output Class Initialized
INFO - 2018-03-30 16:40:24 --> Security Class Initialized
DEBUG - 2018-03-30 16:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:40:24 --> Input Class Initialized
INFO - 2018-03-30 16:40:24 --> Language Class Initialized
INFO - 2018-03-30 16:40:24 --> Loader Class Initialized
INFO - 2018-03-30 16:40:24 --> Helper loaded: url_helper
INFO - 2018-03-30 16:40:24 --> Helper loaded: form_helper
INFO - 2018-03-30 16:40:24 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:40:24 --> Controller Class Initialized
INFO - 2018-03-30 16:40:24 --> Model Class Initialized
INFO - 2018-03-30 16:40:24 --> Model Class Initialized
INFO - 2018-03-30 16:40:24 --> Helper loaded: date_helper
INFO - 2018-03-30 16:40:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:40:24 --> Final output sent to browser
DEBUG - 2018-03-30 21:40:24 --> Total execution time: 0.0618
INFO - 2018-03-30 16:40:33 --> Config Class Initialized
INFO - 2018-03-30 16:40:33 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:40:33 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:40:33 --> Utf8 Class Initialized
INFO - 2018-03-30 16:40:33 --> URI Class Initialized
INFO - 2018-03-30 16:40:33 --> Router Class Initialized
INFO - 2018-03-30 16:40:33 --> Output Class Initialized
INFO - 2018-03-30 16:40:33 --> Security Class Initialized
DEBUG - 2018-03-30 16:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:40:33 --> Input Class Initialized
INFO - 2018-03-30 16:40:33 --> Language Class Initialized
INFO - 2018-03-30 16:40:33 --> Loader Class Initialized
INFO - 2018-03-30 16:40:33 --> Helper loaded: url_helper
INFO - 2018-03-30 16:40:33 --> Helper loaded: form_helper
INFO - 2018-03-30 16:40:33 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:40:33 --> Controller Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Model Class Initialized
INFO - 2018-03-30 16:40:33 --> Helper loaded: date_helper
INFO - 2018-03-30 16:40:33 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:40:33 --> Final output sent to browser
DEBUG - 2018-03-30 21:40:33 --> Total execution time: 0.0759
INFO - 2018-03-30 16:44:58 --> Config Class Initialized
INFO - 2018-03-30 16:44:58 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:44:58 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:44:58 --> Utf8 Class Initialized
INFO - 2018-03-30 16:44:58 --> URI Class Initialized
INFO - 2018-03-30 16:44:58 --> Router Class Initialized
INFO - 2018-03-30 16:44:58 --> Output Class Initialized
INFO - 2018-03-30 16:44:58 --> Security Class Initialized
DEBUG - 2018-03-30 16:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:44:58 --> Input Class Initialized
INFO - 2018-03-30 16:44:58 --> Language Class Initialized
INFO - 2018-03-30 16:44:58 --> Loader Class Initialized
INFO - 2018-03-30 16:44:58 --> Helper loaded: url_helper
INFO - 2018-03-30 16:44:58 --> Helper loaded: form_helper
INFO - 2018-03-30 16:44:58 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:44:58 --> Controller Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Model Class Initialized
INFO - 2018-03-30 16:44:58 --> Helper loaded: date_helper
INFO - 2018-03-30 16:44:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:44:58 --> Model Class Initialized
INFO - 2018-03-30 21:44:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 21:44:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 21:44:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-30 21:44:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 21:44:58 --> Final output sent to browser
DEBUG - 2018-03-30 21:44:58 --> Total execution time: 0.1126
INFO - 2018-03-30 16:47:51 --> Config Class Initialized
INFO - 2018-03-30 16:47:51 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:47:51 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:47:51 --> Utf8 Class Initialized
INFO - 2018-03-30 16:47:51 --> URI Class Initialized
INFO - 2018-03-30 16:47:51 --> Router Class Initialized
INFO - 2018-03-30 16:47:51 --> Output Class Initialized
INFO - 2018-03-30 16:47:51 --> Security Class Initialized
DEBUG - 2018-03-30 16:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:47:51 --> Input Class Initialized
INFO - 2018-03-30 16:47:51 --> Language Class Initialized
INFO - 2018-03-30 16:47:51 --> Loader Class Initialized
INFO - 2018-03-30 16:47:51 --> Helper loaded: url_helper
INFO - 2018-03-30 16:47:51 --> Helper loaded: form_helper
INFO - 2018-03-30 16:47:51 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:47:51 --> Controller Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Model Class Initialized
INFO - 2018-03-30 16:47:51 --> Helper loaded: date_helper
INFO - 2018-03-30 16:47:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:47:51 --> Model Class Initialized
INFO - 2018-03-30 21:47:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 21:47:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 21:47:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-30 21:47:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 21:47:51 --> Final output sent to browser
DEBUG - 2018-03-30 21:47:51 --> Total execution time: 0.1102
INFO - 2018-03-30 16:47:54 --> Config Class Initialized
INFO - 2018-03-30 16:47:54 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:47:54 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:47:54 --> Utf8 Class Initialized
INFO - 2018-03-30 16:47:54 --> URI Class Initialized
INFO - 2018-03-30 16:47:54 --> Router Class Initialized
INFO - 2018-03-30 16:47:54 --> Output Class Initialized
INFO - 2018-03-30 16:47:54 --> Security Class Initialized
DEBUG - 2018-03-30 16:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:47:54 --> Input Class Initialized
INFO - 2018-03-30 16:47:54 --> Language Class Initialized
INFO - 2018-03-30 16:47:54 --> Loader Class Initialized
INFO - 2018-03-30 16:47:54 --> Helper loaded: url_helper
INFO - 2018-03-30 16:47:54 --> Helper loaded: form_helper
INFO - 2018-03-30 16:47:54 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:47:54 --> Controller Class Initialized
INFO - 2018-03-30 16:47:54 --> Model Class Initialized
INFO - 2018-03-30 16:47:54 --> Model Class Initialized
INFO - 2018-03-30 16:47:54 --> Helper loaded: date_helper
INFO - 2018-03-30 16:47:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:47:54 --> Final output sent to browser
DEBUG - 2018-03-30 21:47:54 --> Total execution time: 0.0762
INFO - 2018-03-30 16:48:00 --> Config Class Initialized
INFO - 2018-03-30 16:48:00 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:48:00 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:48:00 --> Utf8 Class Initialized
INFO - 2018-03-30 16:48:00 --> URI Class Initialized
INFO - 2018-03-30 16:48:00 --> Router Class Initialized
INFO - 2018-03-30 16:48:00 --> Output Class Initialized
INFO - 2018-03-30 16:48:00 --> Security Class Initialized
DEBUG - 2018-03-30 16:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:48:00 --> Input Class Initialized
INFO - 2018-03-30 16:48:00 --> Language Class Initialized
INFO - 2018-03-30 16:48:00 --> Loader Class Initialized
INFO - 2018-03-30 16:48:00 --> Helper loaded: url_helper
INFO - 2018-03-30 16:48:00 --> Helper loaded: form_helper
INFO - 2018-03-30 16:48:00 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:48:00 --> Controller Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Model Class Initialized
INFO - 2018-03-30 16:48:00 --> Helper loaded: date_helper
INFO - 2018-03-30 16:48:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:48:00 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/list.php
INFO - 2018-03-30 21:48:00 --> Final output sent to browser
DEBUG - 2018-03-30 21:48:00 --> Total execution time: 0.1345
INFO - 2018-03-30 16:48:13 --> Config Class Initialized
INFO - 2018-03-30 16:48:13 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:48:13 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:48:13 --> Utf8 Class Initialized
INFO - 2018-03-30 16:48:13 --> URI Class Initialized
INFO - 2018-03-30 16:48:13 --> Router Class Initialized
INFO - 2018-03-30 16:48:13 --> Output Class Initialized
INFO - 2018-03-30 16:48:13 --> Security Class Initialized
DEBUG - 2018-03-30 16:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:48:13 --> Input Class Initialized
INFO - 2018-03-30 16:48:13 --> Language Class Initialized
INFO - 2018-03-30 16:48:13 --> Loader Class Initialized
INFO - 2018-03-30 16:48:13 --> Helper loaded: url_helper
INFO - 2018-03-30 16:48:13 --> Helper loaded: form_helper
INFO - 2018-03-30 16:48:13 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:48:13 --> Controller Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Model Class Initialized
INFO - 2018-03-30 16:48:13 --> Helper loaded: date_helper
INFO - 2018-03-30 16:48:13 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:48:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/list.php
INFO - 2018-03-30 21:48:13 --> Final output sent to browser
DEBUG - 2018-03-30 21:48:13 --> Total execution time: 0.1578
INFO - 2018-03-30 16:48:27 --> Config Class Initialized
INFO - 2018-03-30 16:48:27 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:48:27 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:48:27 --> Utf8 Class Initialized
INFO - 2018-03-30 16:48:27 --> URI Class Initialized
INFO - 2018-03-30 16:48:27 --> Router Class Initialized
INFO - 2018-03-30 16:48:27 --> Output Class Initialized
INFO - 2018-03-30 16:48:27 --> Security Class Initialized
DEBUG - 2018-03-30 16:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:48:27 --> Input Class Initialized
INFO - 2018-03-30 16:48:27 --> Language Class Initialized
INFO - 2018-03-30 16:48:27 --> Loader Class Initialized
INFO - 2018-03-30 16:48:27 --> Helper loaded: url_helper
INFO - 2018-03-30 16:48:27 --> Helper loaded: form_helper
INFO - 2018-03-30 16:48:27 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:48:27 --> Controller Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Model Class Initialized
INFO - 2018-03-30 16:48:27 --> Helper loaded: date_helper
INFO - 2018-03-30 16:48:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:48:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/list.php
INFO - 2018-03-30 21:48:27 --> Final output sent to browser
DEBUG - 2018-03-30 21:48:27 --> Total execution time: 0.1508
INFO - 2018-03-30 16:50:41 --> Config Class Initialized
INFO - 2018-03-30 16:50:41 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:50:41 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:50:41 --> Utf8 Class Initialized
INFO - 2018-03-30 16:50:41 --> URI Class Initialized
INFO - 2018-03-30 16:50:41 --> Router Class Initialized
INFO - 2018-03-30 16:50:41 --> Output Class Initialized
INFO - 2018-03-30 16:50:41 --> Security Class Initialized
DEBUG - 2018-03-30 16:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:50:41 --> Input Class Initialized
INFO - 2018-03-30 16:50:41 --> Language Class Initialized
INFO - 2018-03-30 16:50:41 --> Loader Class Initialized
INFO - 2018-03-30 16:50:41 --> Helper loaded: url_helper
INFO - 2018-03-30 16:50:41 --> Helper loaded: form_helper
INFO - 2018-03-30 16:50:41 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:50:41 --> Controller Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Model Class Initialized
INFO - 2018-03-30 16:50:41 --> Helper loaded: date_helper
INFO - 2018-03-30 16:50:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:50:41 --> Model Class Initialized
INFO - 2018-03-30 21:50:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 21:50:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 21:50:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-30 21:50:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 21:50:41 --> Final output sent to browser
DEBUG - 2018-03-30 21:50:41 --> Total execution time: 0.1138
INFO - 2018-03-30 16:50:44 --> Config Class Initialized
INFO - 2018-03-30 16:50:44 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:50:44 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:50:44 --> Utf8 Class Initialized
INFO - 2018-03-30 16:50:44 --> URI Class Initialized
INFO - 2018-03-30 16:50:44 --> Router Class Initialized
INFO - 2018-03-30 16:50:44 --> Output Class Initialized
INFO - 2018-03-30 16:50:44 --> Security Class Initialized
DEBUG - 2018-03-30 16:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:50:44 --> Input Class Initialized
INFO - 2018-03-30 16:50:44 --> Language Class Initialized
INFO - 2018-03-30 16:50:44 --> Loader Class Initialized
INFO - 2018-03-30 16:50:44 --> Helper loaded: url_helper
INFO - 2018-03-30 16:50:44 --> Helper loaded: form_helper
INFO - 2018-03-30 16:50:44 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:50:44 --> Controller Class Initialized
INFO - 2018-03-30 16:50:44 --> Model Class Initialized
INFO - 2018-03-30 16:50:44 --> Model Class Initialized
INFO - 2018-03-30 16:50:44 --> Helper loaded: date_helper
INFO - 2018-03-30 16:50:44 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:50:44 --> Final output sent to browser
DEBUG - 2018-03-30 21:50:44 --> Total execution time: 0.0868
INFO - 2018-03-30 16:50:50 --> Config Class Initialized
INFO - 2018-03-30 16:50:50 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:50:50 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:50:50 --> Utf8 Class Initialized
INFO - 2018-03-30 16:50:50 --> URI Class Initialized
INFO - 2018-03-30 16:50:50 --> Router Class Initialized
INFO - 2018-03-30 16:50:50 --> Output Class Initialized
INFO - 2018-03-30 16:50:50 --> Security Class Initialized
DEBUG - 2018-03-30 16:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:50:50 --> Input Class Initialized
INFO - 2018-03-30 16:50:50 --> Language Class Initialized
INFO - 2018-03-30 16:50:50 --> Loader Class Initialized
INFO - 2018-03-30 16:50:50 --> Helper loaded: url_helper
INFO - 2018-03-30 16:50:50 --> Helper loaded: form_helper
INFO - 2018-03-30 16:50:50 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:50:50 --> Controller Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Model Class Initialized
INFO - 2018-03-30 16:50:50 --> Helper loaded: date_helper
INFO - 2018-03-30 16:50:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:50:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/list.php
INFO - 2018-03-30 21:50:50 --> Final output sent to browser
DEBUG - 2018-03-30 21:50:50 --> Total execution time: 0.0992
INFO - 2018-03-30 16:50:51 --> Config Class Initialized
INFO - 2018-03-30 16:50:51 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:50:51 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:50:51 --> Utf8 Class Initialized
INFO - 2018-03-30 16:50:51 --> URI Class Initialized
INFO - 2018-03-30 16:50:51 --> Router Class Initialized
INFO - 2018-03-30 16:50:51 --> Output Class Initialized
INFO - 2018-03-30 16:50:51 --> Security Class Initialized
DEBUG - 2018-03-30 16:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:50:51 --> Input Class Initialized
INFO - 2018-03-30 16:50:51 --> Language Class Initialized
ERROR - 2018-03-30 16:50:51 --> 404 Page Not Found: Laporan/Laporan/listLaporanPenerimaanPrint
INFO - 2018-03-30 16:55:08 --> Config Class Initialized
INFO - 2018-03-30 16:55:08 --> Hooks Class Initialized
DEBUG - 2018-03-30 16:55:08 --> UTF-8 Support Enabled
INFO - 2018-03-30 16:55:08 --> Utf8 Class Initialized
INFO - 2018-03-30 16:55:08 --> URI Class Initialized
INFO - 2018-03-30 16:55:08 --> Router Class Initialized
INFO - 2018-03-30 16:55:08 --> Output Class Initialized
INFO - 2018-03-30 16:55:08 --> Security Class Initialized
DEBUG - 2018-03-30 16:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 16:55:08 --> Input Class Initialized
INFO - 2018-03-30 16:55:08 --> Language Class Initialized
INFO - 2018-03-30 16:55:08 --> Loader Class Initialized
INFO - 2018-03-30 16:55:08 --> Helper loaded: url_helper
INFO - 2018-03-30 16:55:08 --> Helper loaded: form_helper
INFO - 2018-03-30 16:55:08 --> Database Driver Class Initialized
DEBUG - 2018-03-30 16:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 16:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 16:55:08 --> Controller Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Model Class Initialized
INFO - 2018-03-30 16:55:08 --> Helper loaded: date_helper
INFO - 2018-03-30 16:55:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:55:08 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/print.php
INFO - 2018-03-30 21:55:08 --> Final output sent to browser
DEBUG - 2018-03-30 21:55:08 --> Total execution time: 0.1519
INFO - 2018-03-30 17:03:02 --> Config Class Initialized
INFO - 2018-03-30 17:03:02 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:03:02 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:03:02 --> Utf8 Class Initialized
INFO - 2018-03-30 17:03:02 --> URI Class Initialized
INFO - 2018-03-30 17:03:02 --> Router Class Initialized
INFO - 2018-03-30 17:03:02 --> Output Class Initialized
INFO - 2018-03-30 17:03:02 --> Security Class Initialized
DEBUG - 2018-03-30 17:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:03:02 --> Input Class Initialized
INFO - 2018-03-30 17:03:02 --> Language Class Initialized
INFO - 2018-03-30 17:03:02 --> Loader Class Initialized
INFO - 2018-03-30 17:03:02 --> Helper loaded: url_helper
INFO - 2018-03-30 17:03:02 --> Helper loaded: form_helper
INFO - 2018-03-30 17:03:02 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:03:02 --> Controller Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Model Class Initialized
INFO - 2018-03-30 17:03:02 --> Helper loaded: date_helper
INFO - 2018-03-30 17:03:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:03:02 --> Model Class Initialized
INFO - 2018-03-30 22:03:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:03:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:03:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-30 22:03:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:03:02 --> Final output sent to browser
DEBUG - 2018-03-30 22:03:02 --> Total execution time: 0.1455
INFO - 2018-03-30 17:03:04 --> Config Class Initialized
INFO - 2018-03-30 17:03:04 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:03:04 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:03:04 --> Utf8 Class Initialized
INFO - 2018-03-30 17:03:04 --> URI Class Initialized
INFO - 2018-03-30 17:03:04 --> Router Class Initialized
INFO - 2018-03-30 17:03:04 --> Output Class Initialized
INFO - 2018-03-30 17:03:04 --> Security Class Initialized
DEBUG - 2018-03-30 17:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:03:04 --> Input Class Initialized
INFO - 2018-03-30 17:03:04 --> Language Class Initialized
INFO - 2018-03-30 17:03:04 --> Loader Class Initialized
INFO - 2018-03-30 17:03:04 --> Helper loaded: url_helper
INFO - 2018-03-30 17:03:04 --> Helper loaded: form_helper
INFO - 2018-03-30 17:03:04 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:03:04 --> Controller Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Model Class Initialized
INFO - 2018-03-30 17:03:04 --> Helper loaded: date_helper
INFO - 2018-03-30 17:03:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:03:04 --> Model Class Initialized
INFO - 2018-03-30 22:03:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:03:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:03:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-30 22:03:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:03:04 --> Final output sent to browser
DEBUG - 2018-03-30 22:03:04 --> Total execution time: 0.1122
INFO - 2018-03-30 17:03:07 --> Config Class Initialized
INFO - 2018-03-30 17:03:07 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:03:07 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:03:07 --> Utf8 Class Initialized
INFO - 2018-03-30 17:03:07 --> URI Class Initialized
INFO - 2018-03-30 17:03:07 --> Router Class Initialized
INFO - 2018-03-30 17:03:07 --> Output Class Initialized
INFO - 2018-03-30 17:03:07 --> Security Class Initialized
DEBUG - 2018-03-30 17:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:03:07 --> Input Class Initialized
INFO - 2018-03-30 17:03:07 --> Language Class Initialized
INFO - 2018-03-30 17:03:07 --> Loader Class Initialized
INFO - 2018-03-30 17:03:07 --> Helper loaded: url_helper
INFO - 2018-03-30 17:03:07 --> Helper loaded: form_helper
INFO - 2018-03-30 17:03:07 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:03:07 --> Controller Class Initialized
INFO - 2018-03-30 17:03:07 --> Model Class Initialized
INFO - 2018-03-30 17:03:07 --> Model Class Initialized
INFO - 2018-03-30 17:03:07 --> Helper loaded: date_helper
INFO - 2018-03-30 17:03:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:03:07 --> Final output sent to browser
DEBUG - 2018-03-30 22:03:07 --> Total execution time: 0.0993
INFO - 2018-03-30 17:03:14 --> Config Class Initialized
INFO - 2018-03-30 17:03:14 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:03:14 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:03:14 --> Utf8 Class Initialized
INFO - 2018-03-30 17:03:14 --> URI Class Initialized
INFO - 2018-03-30 17:03:14 --> Router Class Initialized
INFO - 2018-03-30 17:03:14 --> Output Class Initialized
INFO - 2018-03-30 17:03:14 --> Security Class Initialized
DEBUG - 2018-03-30 17:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:03:14 --> Input Class Initialized
INFO - 2018-03-30 17:03:14 --> Language Class Initialized
INFO - 2018-03-30 17:03:14 --> Loader Class Initialized
INFO - 2018-03-30 17:03:14 --> Helper loaded: url_helper
INFO - 2018-03-30 17:03:14 --> Helper loaded: form_helper
INFO - 2018-03-30 17:03:14 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:03:14 --> Controller Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Model Class Initialized
INFO - 2018-03-30 17:03:14 --> Helper loaded: date_helper
INFO - 2018-03-30 17:03:14 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:03:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/list.php
INFO - 2018-03-30 22:03:14 --> Final output sent to browser
DEBUG - 2018-03-30 22:03:14 --> Total execution time: 0.1489
INFO - 2018-03-30 17:03:16 --> Config Class Initialized
INFO - 2018-03-30 17:03:16 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:03:16 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:03:16 --> Utf8 Class Initialized
INFO - 2018-03-30 17:03:16 --> URI Class Initialized
INFO - 2018-03-30 17:03:16 --> Router Class Initialized
INFO - 2018-03-30 17:03:16 --> Output Class Initialized
INFO - 2018-03-30 17:03:16 --> Security Class Initialized
DEBUG - 2018-03-30 17:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:03:16 --> Input Class Initialized
INFO - 2018-03-30 17:03:16 --> Language Class Initialized
INFO - 2018-03-30 17:03:16 --> Loader Class Initialized
INFO - 2018-03-30 17:03:16 --> Helper loaded: url_helper
INFO - 2018-03-30 17:03:16 --> Helper loaded: form_helper
INFO - 2018-03-30 17:03:16 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:03:16 --> Controller Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Model Class Initialized
INFO - 2018-03-30 17:03:16 --> Helper loaded: date_helper
INFO - 2018-03-30 17:03:16 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:03:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/print.php
INFO - 2018-03-30 22:03:16 --> Final output sent to browser
DEBUG - 2018-03-30 22:03:16 --> Total execution time: 0.1534
INFO - 2018-03-30 17:09:47 --> Config Class Initialized
INFO - 2018-03-30 17:09:47 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:09:47 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:09:47 --> Utf8 Class Initialized
INFO - 2018-03-30 17:09:47 --> URI Class Initialized
INFO - 2018-03-30 17:09:47 --> Router Class Initialized
INFO - 2018-03-30 17:09:47 --> Output Class Initialized
INFO - 2018-03-30 17:09:47 --> Security Class Initialized
DEBUG - 2018-03-30 17:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:09:47 --> Input Class Initialized
INFO - 2018-03-30 17:09:47 --> Language Class Initialized
INFO - 2018-03-30 17:09:47 --> Loader Class Initialized
INFO - 2018-03-30 17:09:47 --> Helper loaded: url_helper
INFO - 2018-03-30 17:09:47 --> Helper loaded: form_helper
INFO - 2018-03-30 17:09:47 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:09:47 --> Controller Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Model Class Initialized
INFO - 2018-03-30 17:09:47 --> Helper loaded: date_helper
INFO - 2018-03-30 17:09:47 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:09:47 --> Model Class Initialized
INFO - 2018-03-30 22:09:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:09:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:09:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/table.php
INFO - 2018-03-30 22:09:47 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:09:47 --> Final output sent to browser
DEBUG - 2018-03-30 22:09:47 --> Total execution time: 0.1165
INFO - 2018-03-30 17:09:50 --> Config Class Initialized
INFO - 2018-03-30 17:09:50 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:09:50 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:09:50 --> Utf8 Class Initialized
INFO - 2018-03-30 17:09:50 --> URI Class Initialized
INFO - 2018-03-30 17:09:50 --> Router Class Initialized
INFO - 2018-03-30 17:09:50 --> Output Class Initialized
INFO - 2018-03-30 17:09:50 --> Security Class Initialized
DEBUG - 2018-03-30 17:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:09:50 --> Input Class Initialized
INFO - 2018-03-30 17:09:50 --> Language Class Initialized
INFO - 2018-03-30 17:09:50 --> Loader Class Initialized
INFO - 2018-03-30 17:09:50 --> Helper loaded: url_helper
INFO - 2018-03-30 17:09:50 --> Helper loaded: form_helper
INFO - 2018-03-30 17:09:50 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:09:50 --> Controller Class Initialized
INFO - 2018-03-30 17:09:50 --> Model Class Initialized
INFO - 2018-03-30 17:09:50 --> Model Class Initialized
INFO - 2018-03-30 17:09:50 --> Helper loaded: date_helper
INFO - 2018-03-30 17:09:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:09:50 --> Final output sent to browser
DEBUG - 2018-03-30 22:09:50 --> Total execution time: 0.1062
INFO - 2018-03-30 17:09:55 --> Config Class Initialized
INFO - 2018-03-30 17:09:55 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:09:55 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:09:55 --> Utf8 Class Initialized
INFO - 2018-03-30 17:09:55 --> URI Class Initialized
INFO - 2018-03-30 17:09:55 --> Router Class Initialized
INFO - 2018-03-30 17:09:55 --> Output Class Initialized
INFO - 2018-03-30 17:09:55 --> Security Class Initialized
DEBUG - 2018-03-30 17:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:09:55 --> Input Class Initialized
INFO - 2018-03-30 17:09:55 --> Language Class Initialized
INFO - 2018-03-30 17:09:55 --> Loader Class Initialized
INFO - 2018-03-30 17:09:55 --> Helper loaded: url_helper
INFO - 2018-03-30 17:09:55 --> Helper loaded: form_helper
INFO - 2018-03-30 17:09:55 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:09:55 --> Controller Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Model Class Initialized
INFO - 2018-03-30 17:09:55 --> Helper loaded: date_helper
INFO - 2018-03-30 17:09:55 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:09:55 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/list.php
INFO - 2018-03-30 22:09:55 --> Final output sent to browser
DEBUG - 2018-03-30 22:09:55 --> Total execution time: 0.1319
INFO - 2018-03-30 17:09:57 --> Config Class Initialized
INFO - 2018-03-30 17:09:57 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:09:57 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:09:57 --> Utf8 Class Initialized
INFO - 2018-03-30 17:09:57 --> URI Class Initialized
INFO - 2018-03-30 17:09:57 --> Router Class Initialized
INFO - 2018-03-30 17:09:57 --> Output Class Initialized
INFO - 2018-03-30 17:09:57 --> Security Class Initialized
DEBUG - 2018-03-30 17:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:09:57 --> Input Class Initialized
INFO - 2018-03-30 17:09:57 --> Language Class Initialized
INFO - 2018-03-30 17:09:57 --> Loader Class Initialized
INFO - 2018-03-30 17:09:57 --> Helper loaded: url_helper
INFO - 2018-03-30 17:09:57 --> Helper loaded: form_helper
INFO - 2018-03-30 17:09:57 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:09:57 --> Controller Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Model Class Initialized
INFO - 2018-03-30 17:09:57 --> Helper loaded: date_helper
INFO - 2018-03-30 17:09:57 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:09:57 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/print.php
INFO - 2018-03-30 22:09:57 --> Final output sent to browser
DEBUG - 2018-03-30 22:09:57 --> Total execution time: 0.1084
INFO - 2018-03-30 17:12:23 --> Config Class Initialized
INFO - 2018-03-30 17:12:23 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:12:23 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:12:23 --> Utf8 Class Initialized
INFO - 2018-03-30 17:12:23 --> URI Class Initialized
INFO - 2018-03-30 17:12:23 --> Router Class Initialized
INFO - 2018-03-30 17:12:23 --> Output Class Initialized
INFO - 2018-03-30 17:12:23 --> Security Class Initialized
DEBUG - 2018-03-30 17:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:12:24 --> Input Class Initialized
INFO - 2018-03-30 17:12:24 --> Language Class Initialized
INFO - 2018-03-30 17:12:24 --> Loader Class Initialized
INFO - 2018-03-30 17:12:24 --> Helper loaded: url_helper
INFO - 2018-03-30 17:12:24 --> Helper loaded: form_helper
INFO - 2018-03-30 17:12:24 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:12:24 --> Controller Class Initialized
INFO - 2018-03-30 17:12:24 --> Model Class Initialized
INFO - 2018-03-30 17:12:24 --> Model Class Initialized
INFO - 2018-03-30 17:12:24 --> Model Class Initialized
INFO - 2018-03-30 17:12:24 --> Model Class Initialized
INFO - 2018-03-30 17:12:24 --> Model Class Initialized
INFO - 2018-03-30 17:12:24 --> Model Class Initialized
INFO - 2018-03-30 17:12:24 --> Model Class Initialized
INFO - 2018-03-30 17:12:24 --> Model Class Initialized
INFO - 2018-03-30 17:12:24 --> Model Class Initialized
INFO - 2018-03-30 17:12:24 --> Model Class Initialized
INFO - 2018-03-30 17:12:24 --> Model Class Initialized
INFO - 2018-03-30 17:12:24 --> Model Class Initialized
INFO - 2018-03-30 17:12:24 --> Model Class Initialized
INFO - 2018-03-30 17:12:24 --> Model Class Initialized
INFO - 2018-03-30 17:12:24 --> Helper loaded: date_helper
INFO - 2018-03-30 17:12:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:12:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:12:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:12:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-30 22:12:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:12:24 --> Final output sent to browser
DEBUG - 2018-03-30 22:12:24 --> Total execution time: 0.2452
INFO - 2018-03-30 17:13:13 --> Config Class Initialized
INFO - 2018-03-30 17:13:13 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:13:13 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:13:13 --> Utf8 Class Initialized
INFO - 2018-03-30 17:13:13 --> URI Class Initialized
INFO - 2018-03-30 17:13:13 --> Router Class Initialized
INFO - 2018-03-30 17:13:13 --> Output Class Initialized
INFO - 2018-03-30 17:13:13 --> Security Class Initialized
DEBUG - 2018-03-30 17:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:13:13 --> Input Class Initialized
INFO - 2018-03-30 17:13:13 --> Language Class Initialized
INFO - 2018-03-30 17:13:13 --> Loader Class Initialized
INFO - 2018-03-30 17:13:13 --> Helper loaded: url_helper
INFO - 2018-03-30 17:13:13 --> Helper loaded: form_helper
INFO - 2018-03-30 17:13:13 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:13:13 --> Controller Class Initialized
INFO - 2018-03-30 17:13:13 --> Model Class Initialized
INFO - 2018-03-30 17:13:13 --> Model Class Initialized
INFO - 2018-03-30 17:13:13 --> Model Class Initialized
INFO - 2018-03-30 17:13:13 --> Model Class Initialized
INFO - 2018-03-30 17:13:13 --> Model Class Initialized
INFO - 2018-03-30 17:13:13 --> Helper loaded: date_helper
INFO - 2018-03-30 22:13:13 --> Model Class Initialized
INFO - 2018-03-30 22:13:13 --> Model Class Initialized
INFO - 2018-03-30 22:13:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:13:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:13:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-30 22:13:13 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:13:13 --> Final output sent to browser
DEBUG - 2018-03-30 22:13:13 --> Total execution time: 0.1267
INFO - 2018-03-30 17:13:23 --> Config Class Initialized
INFO - 2018-03-30 17:13:23 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:13:23 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:13:23 --> Utf8 Class Initialized
INFO - 2018-03-30 17:13:23 --> URI Class Initialized
INFO - 2018-03-30 17:13:23 --> Router Class Initialized
INFO - 2018-03-30 17:13:23 --> Output Class Initialized
INFO - 2018-03-30 17:13:23 --> Security Class Initialized
DEBUG - 2018-03-30 17:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:13:23 --> Input Class Initialized
INFO - 2018-03-30 17:13:23 --> Language Class Initialized
INFO - 2018-03-30 17:13:24 --> Loader Class Initialized
INFO - 2018-03-30 17:13:24 --> Helper loaded: url_helper
INFO - 2018-03-30 17:13:24 --> Helper loaded: form_helper
INFO - 2018-03-30 17:13:24 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:13:24 --> Controller Class Initialized
INFO - 2018-03-30 17:13:24 --> Model Class Initialized
INFO - 2018-03-30 17:13:24 --> Model Class Initialized
INFO - 2018-03-30 17:13:24 --> Model Class Initialized
INFO - 2018-03-30 17:13:24 --> Model Class Initialized
INFO - 2018-03-30 17:13:24 --> Model Class Initialized
INFO - 2018-03-30 17:13:24 --> Helper loaded: date_helper
INFO - 2018-03-30 22:13:24 --> Model Class Initialized
INFO - 2018-03-30 22:13:24 --> Model Class Initialized
INFO - 2018-03-30 22:13:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:13:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:13:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/create.php
INFO - 2018-03-30 22:13:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:13:24 --> Final output sent to browser
DEBUG - 2018-03-30 22:13:24 --> Total execution time: 0.1506
INFO - 2018-03-30 17:14:07 --> Config Class Initialized
INFO - 2018-03-30 17:14:07 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:14:07 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:14:07 --> Utf8 Class Initialized
INFO - 2018-03-30 17:14:07 --> URI Class Initialized
INFO - 2018-03-30 17:14:07 --> Router Class Initialized
INFO - 2018-03-30 17:14:07 --> Output Class Initialized
INFO - 2018-03-30 17:14:07 --> Security Class Initialized
DEBUG - 2018-03-30 17:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:14:07 --> Input Class Initialized
INFO - 2018-03-30 17:14:07 --> Language Class Initialized
INFO - 2018-03-30 17:14:07 --> Loader Class Initialized
INFO - 2018-03-30 17:14:07 --> Helper loaded: url_helper
INFO - 2018-03-30 17:14:07 --> Helper loaded: form_helper
INFO - 2018-03-30 17:14:07 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:14:07 --> Controller Class Initialized
INFO - 2018-03-30 17:14:07 --> Model Class Initialized
INFO - 2018-03-30 17:14:07 --> Model Class Initialized
INFO - 2018-03-30 17:14:07 --> Model Class Initialized
INFO - 2018-03-30 17:14:07 --> Model Class Initialized
INFO - 2018-03-30 17:14:07 --> Model Class Initialized
INFO - 2018-03-30 17:14:07 --> Helper loaded: date_helper
INFO - 2018-03-30 17:14:07 --> Config Class Initialized
INFO - 2018-03-30 17:14:07 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:14:07 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:14:07 --> Utf8 Class Initialized
INFO - 2018-03-30 17:14:07 --> URI Class Initialized
INFO - 2018-03-30 17:14:07 --> Router Class Initialized
INFO - 2018-03-30 17:14:07 --> Output Class Initialized
INFO - 2018-03-30 17:14:07 --> Security Class Initialized
DEBUG - 2018-03-30 17:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:14:07 --> Input Class Initialized
INFO - 2018-03-30 17:14:07 --> Language Class Initialized
INFO - 2018-03-30 17:14:07 --> Loader Class Initialized
INFO - 2018-03-30 17:14:07 --> Helper loaded: url_helper
INFO - 2018-03-30 17:14:07 --> Helper loaded: form_helper
INFO - 2018-03-30 17:14:07 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:14:07 --> Controller Class Initialized
INFO - 2018-03-30 17:14:07 --> Model Class Initialized
INFO - 2018-03-30 17:14:07 --> Model Class Initialized
INFO - 2018-03-30 17:14:07 --> Model Class Initialized
INFO - 2018-03-30 17:14:07 --> Model Class Initialized
INFO - 2018-03-30 17:14:07 --> Model Class Initialized
INFO - 2018-03-30 17:14:07 --> Helper loaded: date_helper
INFO - 2018-03-30 22:14:07 --> Model Class Initialized
INFO - 2018-03-30 22:14:07 --> Model Class Initialized
INFO - 2018-03-30 22:14:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:14:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:14:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu/table.php
INFO - 2018-03-30 22:14:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:14:07 --> Final output sent to browser
DEBUG - 2018-03-30 22:14:07 --> Total execution time: 0.1550
INFO - 2018-03-30 17:14:14 --> Config Class Initialized
INFO - 2018-03-30 17:14:14 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:14:14 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:14:14 --> Utf8 Class Initialized
INFO - 2018-03-30 17:14:14 --> URI Class Initialized
INFO - 2018-03-30 17:14:14 --> Router Class Initialized
INFO - 2018-03-30 17:14:14 --> Output Class Initialized
INFO - 2018-03-30 17:14:14 --> Security Class Initialized
DEBUG - 2018-03-30 17:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:14:14 --> Input Class Initialized
INFO - 2018-03-30 17:14:14 --> Language Class Initialized
INFO - 2018-03-30 17:14:14 --> Loader Class Initialized
INFO - 2018-03-30 17:14:14 --> Helper loaded: url_helper
INFO - 2018-03-30 17:14:14 --> Helper loaded: form_helper
INFO - 2018-03-30 17:14:14 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:14:14 --> Controller Class Initialized
INFO - 2018-03-30 17:14:14 --> Model Class Initialized
INFO - 2018-03-30 17:14:14 --> Model Class Initialized
INFO - 2018-03-30 17:14:14 --> Model Class Initialized
INFO - 2018-03-30 17:14:14 --> Model Class Initialized
INFO - 2018-03-30 17:14:14 --> Model Class Initialized
INFO - 2018-03-30 17:14:14 --> Helper loaded: date_helper
INFO - 2018-03-30 22:14:14 --> Model Class Initialized
INFO - 2018-03-30 22:14:14 --> Model Class Initialized
INFO - 2018-03-30 22:14:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:14:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:14:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-30 22:14:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:14:14 --> Final output sent to browser
DEBUG - 2018-03-30 22:14:14 --> Total execution time: 0.1959
INFO - 2018-03-30 17:14:16 --> Config Class Initialized
INFO - 2018-03-30 17:14:16 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:14:16 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:14:16 --> Utf8 Class Initialized
INFO - 2018-03-30 17:14:16 --> URI Class Initialized
INFO - 2018-03-30 17:14:16 --> Router Class Initialized
INFO - 2018-03-30 17:14:16 --> Output Class Initialized
INFO - 2018-03-30 17:14:16 --> Security Class Initialized
DEBUG - 2018-03-30 17:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:14:17 --> Input Class Initialized
INFO - 2018-03-30 17:14:17 --> Language Class Initialized
INFO - 2018-03-30 17:14:17 --> Loader Class Initialized
INFO - 2018-03-30 17:14:17 --> Helper loaded: url_helper
INFO - 2018-03-30 17:14:17 --> Helper loaded: form_helper
INFO - 2018-03-30 17:14:17 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:14:17 --> Controller Class Initialized
INFO - 2018-03-30 17:14:17 --> Model Class Initialized
INFO - 2018-03-30 17:14:17 --> Model Class Initialized
INFO - 2018-03-30 17:14:17 --> Model Class Initialized
INFO - 2018-03-30 17:14:17 --> Model Class Initialized
INFO - 2018-03-30 17:14:17 --> Model Class Initialized
INFO - 2018-03-30 17:14:17 --> Helper loaded: date_helper
INFO - 2018-03-30 22:14:17 --> Model Class Initialized
INFO - 2018-03-30 22:14:17 --> Model Class Initialized
INFO - 2018-03-30 22:14:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:14:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:14:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/create.php
INFO - 2018-03-30 22:14:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:14:17 --> Final output sent to browser
DEBUG - 2018-03-30 22:14:17 --> Total execution time: 0.1458
INFO - 2018-03-30 17:14:46 --> Config Class Initialized
INFO - 2018-03-30 17:14:46 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:14:46 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:14:46 --> Utf8 Class Initialized
INFO - 2018-03-30 17:14:46 --> URI Class Initialized
INFO - 2018-03-30 17:14:46 --> Router Class Initialized
INFO - 2018-03-30 17:14:46 --> Output Class Initialized
INFO - 2018-03-30 17:14:46 --> Security Class Initialized
DEBUG - 2018-03-30 17:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:14:46 --> Input Class Initialized
INFO - 2018-03-30 17:14:46 --> Language Class Initialized
INFO - 2018-03-30 17:14:46 --> Loader Class Initialized
INFO - 2018-03-30 17:14:46 --> Helper loaded: url_helper
INFO - 2018-03-30 17:14:46 --> Helper loaded: form_helper
INFO - 2018-03-30 17:14:46 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:14:46 --> Controller Class Initialized
INFO - 2018-03-30 17:14:46 --> Model Class Initialized
INFO - 2018-03-30 17:14:46 --> Model Class Initialized
INFO - 2018-03-30 17:14:46 --> Model Class Initialized
INFO - 2018-03-30 17:14:46 --> Model Class Initialized
INFO - 2018-03-30 17:14:46 --> Model Class Initialized
INFO - 2018-03-30 17:14:46 --> Helper loaded: date_helper
INFO - 2018-03-30 17:14:46 --> Config Class Initialized
INFO - 2018-03-30 17:14:46 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:14:46 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:14:46 --> Utf8 Class Initialized
INFO - 2018-03-30 17:14:46 --> URI Class Initialized
INFO - 2018-03-30 17:14:46 --> Router Class Initialized
INFO - 2018-03-30 17:14:46 --> Output Class Initialized
INFO - 2018-03-30 17:14:46 --> Security Class Initialized
DEBUG - 2018-03-30 17:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:14:46 --> Input Class Initialized
INFO - 2018-03-30 17:14:46 --> Language Class Initialized
INFO - 2018-03-30 17:14:46 --> Loader Class Initialized
INFO - 2018-03-30 17:14:46 --> Helper loaded: url_helper
INFO - 2018-03-30 17:14:46 --> Helper loaded: form_helper
INFO - 2018-03-30 17:14:46 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:14:46 --> Controller Class Initialized
INFO - 2018-03-30 17:14:46 --> Model Class Initialized
INFO - 2018-03-30 17:14:46 --> Model Class Initialized
INFO - 2018-03-30 17:14:46 --> Model Class Initialized
INFO - 2018-03-30 17:14:46 --> Model Class Initialized
INFO - 2018-03-30 17:14:46 --> Model Class Initialized
INFO - 2018-03-30 17:14:46 --> Helper loaded: date_helper
INFO - 2018-03-30 22:14:46 --> Model Class Initialized
INFO - 2018-03-30 22:14:46 --> Model Class Initialized
INFO - 2018-03-30 22:14:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:14:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:14:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-30 22:14:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:14:46 --> Final output sent to browser
DEBUG - 2018-03-30 22:14:46 --> Total execution time: 0.1152
INFO - 2018-03-30 17:14:49 --> Config Class Initialized
INFO - 2018-03-30 17:14:49 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:14:49 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:14:49 --> Utf8 Class Initialized
INFO - 2018-03-30 17:14:49 --> URI Class Initialized
INFO - 2018-03-30 17:14:49 --> Router Class Initialized
INFO - 2018-03-30 17:14:49 --> Output Class Initialized
INFO - 2018-03-30 17:14:49 --> Security Class Initialized
DEBUG - 2018-03-30 17:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:14:49 --> Input Class Initialized
INFO - 2018-03-30 17:14:49 --> Language Class Initialized
ERROR - 2018-03-30 17:14:49 --> 404 Page Not Found: Laporan/Laporan/pengunjung
INFO - 2018-03-30 17:16:50 --> Config Class Initialized
INFO - 2018-03-30 17:16:50 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:16:50 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:16:50 --> Utf8 Class Initialized
INFO - 2018-03-30 17:16:50 --> URI Class Initialized
INFO - 2018-03-30 17:16:50 --> Router Class Initialized
INFO - 2018-03-30 17:16:50 --> Output Class Initialized
INFO - 2018-03-30 17:16:50 --> Security Class Initialized
DEBUG - 2018-03-30 17:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:16:50 --> Input Class Initialized
INFO - 2018-03-30 17:16:50 --> Language Class Initialized
INFO - 2018-03-30 17:16:50 --> Loader Class Initialized
INFO - 2018-03-30 17:16:50 --> Helper loaded: url_helper
INFO - 2018-03-30 17:16:50 --> Helper loaded: form_helper
INFO - 2018-03-30 17:16:50 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:16:50 --> Controller Class Initialized
INFO - 2018-03-30 17:16:50 --> Model Class Initialized
INFO - 2018-03-30 17:16:50 --> Model Class Initialized
INFO - 2018-03-30 17:16:50 --> Model Class Initialized
INFO - 2018-03-30 17:16:50 --> Model Class Initialized
INFO - 2018-03-30 17:16:50 --> Model Class Initialized
INFO - 2018-03-30 17:16:50 --> Helper loaded: date_helper
INFO - 2018-03-30 22:16:50 --> Model Class Initialized
INFO - 2018-03-30 22:16:50 --> Model Class Initialized
INFO - 2018-03-30 22:16:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:16:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:16:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\system/menu_akses/table.php
INFO - 2018-03-30 22:16:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:16:50 --> Final output sent to browser
DEBUG - 2018-03-30 22:16:50 --> Total execution time: 0.1255
INFO - 2018-03-30 17:17:37 --> Config Class Initialized
INFO - 2018-03-30 17:17:37 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:17:37 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:17:37 --> Utf8 Class Initialized
INFO - 2018-03-30 17:17:37 --> URI Class Initialized
INFO - 2018-03-30 17:17:37 --> Router Class Initialized
INFO - 2018-03-30 17:17:37 --> Output Class Initialized
INFO - 2018-03-30 17:17:37 --> Security Class Initialized
DEBUG - 2018-03-30 17:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:17:37 --> Input Class Initialized
INFO - 2018-03-30 17:17:37 --> Language Class Initialized
INFO - 2018-03-30 17:17:37 --> Loader Class Initialized
INFO - 2018-03-30 17:17:37 --> Helper loaded: url_helper
INFO - 2018-03-30 17:17:37 --> Helper loaded: form_helper
INFO - 2018-03-30 17:17:37 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:17:37 --> Controller Class Initialized
INFO - 2018-03-30 17:17:37 --> Model Class Initialized
INFO - 2018-03-30 17:17:37 --> Model Class Initialized
INFO - 2018-03-30 17:17:37 --> Helper loaded: date_helper
INFO - 2018-03-30 17:17:37 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:17:37 --> Model Class Initialized
INFO - 2018-03-30 22:17:37 --> Model Class Initialized
INFO - 2018-03-30 22:17:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:17:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:17:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\suplier/table.php
INFO - 2018-03-30 22:17:37 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:17:37 --> Final output sent to browser
DEBUG - 2018-03-30 22:17:37 --> Total execution time: 0.1867
INFO - 2018-03-30 17:22:40 --> Config Class Initialized
INFO - 2018-03-30 17:22:40 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:22:40 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:22:40 --> Utf8 Class Initialized
INFO - 2018-03-30 17:22:40 --> URI Class Initialized
INFO - 2018-03-30 17:22:40 --> Router Class Initialized
INFO - 2018-03-30 17:22:40 --> Output Class Initialized
INFO - 2018-03-30 17:22:40 --> Security Class Initialized
DEBUG - 2018-03-30 17:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:22:40 --> Input Class Initialized
INFO - 2018-03-30 17:22:40 --> Language Class Initialized
INFO - 2018-03-30 17:22:40 --> Loader Class Initialized
INFO - 2018-03-30 17:22:40 --> Helper loaded: url_helper
INFO - 2018-03-30 17:22:40 --> Helper loaded: form_helper
INFO - 2018-03-30 17:22:40 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:22:40 --> Controller Class Initialized
INFO - 2018-03-30 17:22:40 --> Model Class Initialized
INFO - 2018-03-30 17:22:40 --> Model Class Initialized
INFO - 2018-03-30 17:22:40 --> Model Class Initialized
INFO - 2018-03-30 17:22:40 --> Model Class Initialized
INFO - 2018-03-30 17:22:40 --> Model Class Initialized
INFO - 2018-03-30 17:22:40 --> Model Class Initialized
INFO - 2018-03-30 17:22:40 --> Model Class Initialized
INFO - 2018-03-30 17:22:40 --> Model Class Initialized
INFO - 2018-03-30 17:22:40 --> Model Class Initialized
INFO - 2018-03-30 17:22:40 --> Model Class Initialized
INFO - 2018-03-30 17:22:40 --> Model Class Initialized
INFO - 2018-03-30 17:22:40 --> Model Class Initialized
INFO - 2018-03-30 17:22:40 --> Model Class Initialized
INFO - 2018-03-30 17:22:40 --> Model Class Initialized
INFO - 2018-03-30 17:22:40 --> Helper loaded: date_helper
INFO - 2018-03-30 17:22:40 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:22:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:22:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:22:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-30 22:22:40 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:22:40 --> Final output sent to browser
DEBUG - 2018-03-30 22:22:40 --> Total execution time: 0.1514
INFO - 2018-03-30 17:38:50 --> Config Class Initialized
INFO - 2018-03-30 17:38:50 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:38:50 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:38:50 --> Utf8 Class Initialized
INFO - 2018-03-30 17:38:50 --> URI Class Initialized
INFO - 2018-03-30 17:38:50 --> Router Class Initialized
INFO - 2018-03-30 17:38:50 --> Output Class Initialized
INFO - 2018-03-30 17:38:50 --> Security Class Initialized
DEBUG - 2018-03-30 17:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:38:50 --> Input Class Initialized
INFO - 2018-03-30 17:38:50 --> Language Class Initialized
INFO - 2018-03-30 17:38:50 --> Loader Class Initialized
INFO - 2018-03-30 17:38:50 --> Helper loaded: url_helper
INFO - 2018-03-30 17:38:50 --> Helper loaded: form_helper
INFO - 2018-03-30 17:38:50 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:38:50 --> Controller Class Initialized
INFO - 2018-03-30 17:38:50 --> Model Class Initialized
INFO - 2018-03-30 17:38:50 --> Model Class Initialized
INFO - 2018-03-30 17:38:50 --> Model Class Initialized
INFO - 2018-03-30 17:38:50 --> Model Class Initialized
INFO - 2018-03-30 17:38:50 --> Model Class Initialized
INFO - 2018-03-30 17:38:50 --> Model Class Initialized
INFO - 2018-03-30 17:38:50 --> Model Class Initialized
INFO - 2018-03-30 17:38:51 --> Model Class Initialized
INFO - 2018-03-30 17:38:51 --> Model Class Initialized
INFO - 2018-03-30 17:38:51 --> Model Class Initialized
INFO - 2018-03-30 17:38:51 --> Model Class Initialized
INFO - 2018-03-30 17:38:51 --> Model Class Initialized
INFO - 2018-03-30 17:38:51 --> Model Class Initialized
INFO - 2018-03-30 17:38:51 --> Model Class Initialized
INFO - 2018-03-30 17:38:51 --> Helper loaded: date_helper
INFO - 2018-03-30 17:38:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:38:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:38:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:38:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-30 22:38:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:38:51 --> Final output sent to browser
DEBUG - 2018-03-30 22:38:51 --> Total execution time: 0.1208
INFO - 2018-03-30 17:38:54 --> Config Class Initialized
INFO - 2018-03-30 17:38:54 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:38:54 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:38:54 --> Utf8 Class Initialized
INFO - 2018-03-30 17:38:54 --> URI Class Initialized
INFO - 2018-03-30 17:38:54 --> Router Class Initialized
INFO - 2018-03-30 17:38:54 --> Output Class Initialized
INFO - 2018-03-30 17:38:54 --> Security Class Initialized
DEBUG - 2018-03-30 17:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:38:54 --> Input Class Initialized
INFO - 2018-03-30 17:38:54 --> Language Class Initialized
INFO - 2018-03-30 17:38:54 --> Loader Class Initialized
INFO - 2018-03-30 17:38:54 --> Helper loaded: url_helper
INFO - 2018-03-30 17:38:54 --> Helper loaded: form_helper
INFO - 2018-03-30 17:38:54 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:38:54 --> Controller Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Model Class Initialized
INFO - 2018-03-30 17:38:54 --> Helper loaded: date_helper
INFO - 2018-03-30 17:38:54 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:38:54 --> Model Class Initialized
INFO - 2018-03-30 22:38:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:38:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 17:39:11 --> Config Class Initialized
INFO - 2018-03-30 17:39:11 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:39:11 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:39:11 --> Utf8 Class Initialized
INFO - 2018-03-30 17:39:11 --> URI Class Initialized
INFO - 2018-03-30 17:39:11 --> Router Class Initialized
INFO - 2018-03-30 17:39:11 --> Output Class Initialized
INFO - 2018-03-30 17:39:11 --> Security Class Initialized
DEBUG - 2018-03-30 17:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:39:11 --> Input Class Initialized
INFO - 2018-03-30 17:39:11 --> Language Class Initialized
INFO - 2018-03-30 17:39:11 --> Loader Class Initialized
INFO - 2018-03-30 17:39:11 --> Helper loaded: url_helper
INFO - 2018-03-30 17:39:11 --> Helper loaded: form_helper
INFO - 2018-03-30 17:39:11 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:39:11 --> Controller Class Initialized
INFO - 2018-03-30 17:39:11 --> Model Class Initialized
INFO - 2018-03-30 17:39:11 --> Model Class Initialized
INFO - 2018-03-30 17:39:11 --> Model Class Initialized
INFO - 2018-03-30 17:39:11 --> Model Class Initialized
INFO - 2018-03-30 17:39:12 --> Model Class Initialized
INFO - 2018-03-30 17:39:12 --> Model Class Initialized
INFO - 2018-03-30 17:39:12 --> Model Class Initialized
INFO - 2018-03-30 17:39:12 --> Model Class Initialized
INFO - 2018-03-30 17:39:12 --> Model Class Initialized
INFO - 2018-03-30 17:39:12 --> Model Class Initialized
INFO - 2018-03-30 17:39:12 --> Model Class Initialized
INFO - 2018-03-30 17:39:12 --> Model Class Initialized
INFO - 2018-03-30 17:39:12 --> Model Class Initialized
INFO - 2018-03-30 17:39:12 --> Model Class Initialized
INFO - 2018-03-30 17:39:12 --> Model Class Initialized
INFO - 2018-03-30 17:39:12 --> Model Class Initialized
INFO - 2018-03-30 17:39:12 --> Model Class Initialized
INFO - 2018-03-30 17:39:12 --> Model Class Initialized
INFO - 2018-03-30 17:39:12 --> Helper loaded: date_helper
INFO - 2018-03-30 17:39:12 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:39:12 --> Model Class Initialized
INFO - 2018-03-30 22:39:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:39:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:39:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-30 22:39:12 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:39:12 --> Final output sent to browser
DEBUG - 2018-03-30 22:39:12 --> Total execution time: 0.1099
INFO - 2018-03-30 17:41:50 --> Config Class Initialized
INFO - 2018-03-30 17:41:50 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:41:50 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:41:50 --> Utf8 Class Initialized
INFO - 2018-03-30 17:41:50 --> URI Class Initialized
INFO - 2018-03-30 17:41:50 --> Router Class Initialized
INFO - 2018-03-30 17:41:50 --> Output Class Initialized
INFO - 2018-03-30 17:41:50 --> Security Class Initialized
DEBUG - 2018-03-30 17:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:41:50 --> Input Class Initialized
INFO - 2018-03-30 17:41:50 --> Language Class Initialized
INFO - 2018-03-30 17:41:50 --> Loader Class Initialized
INFO - 2018-03-30 17:41:50 --> Helper loaded: url_helper
INFO - 2018-03-30 17:41:50 --> Helper loaded: form_helper
INFO - 2018-03-30 17:41:50 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:41:50 --> Controller Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Model Class Initialized
INFO - 2018-03-30 17:41:50 --> Helper loaded: date_helper
INFO - 2018-03-30 17:41:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:41:50 --> Model Class Initialized
INFO - 2018-03-30 22:41:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:41:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:41:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-30 22:41:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:41:50 --> Final output sent to browser
DEBUG - 2018-03-30 22:41:50 --> Total execution time: 0.1076
INFO - 2018-03-30 17:41:58 --> Config Class Initialized
INFO - 2018-03-30 17:41:58 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:41:58 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:41:58 --> Utf8 Class Initialized
INFO - 2018-03-30 17:41:58 --> URI Class Initialized
INFO - 2018-03-30 17:41:58 --> Router Class Initialized
INFO - 2018-03-30 17:41:58 --> Output Class Initialized
INFO - 2018-03-30 17:41:58 --> Security Class Initialized
DEBUG - 2018-03-30 17:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:41:58 --> Input Class Initialized
INFO - 2018-03-30 17:41:58 --> Language Class Initialized
INFO - 2018-03-30 17:41:58 --> Loader Class Initialized
INFO - 2018-03-30 17:41:58 --> Helper loaded: url_helper
INFO - 2018-03-30 17:41:58 --> Helper loaded: form_helper
INFO - 2018-03-30 17:41:58 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:41:58 --> Controller Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Model Class Initialized
INFO - 2018-03-30 17:41:58 --> Helper loaded: date_helper
INFO - 2018-03-30 17:41:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:41:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/list.php
INFO - 2018-03-30 22:41:58 --> Final output sent to browser
DEBUG - 2018-03-30 22:41:58 --> Total execution time: 0.1220
INFO - 2018-03-30 17:42:17 --> Config Class Initialized
INFO - 2018-03-30 17:42:17 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:42:17 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:42:17 --> Utf8 Class Initialized
INFO - 2018-03-30 17:42:17 --> URI Class Initialized
INFO - 2018-03-30 17:42:17 --> Router Class Initialized
INFO - 2018-03-30 17:42:17 --> Output Class Initialized
INFO - 2018-03-30 17:42:17 --> Security Class Initialized
DEBUG - 2018-03-30 17:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:42:17 --> Input Class Initialized
INFO - 2018-03-30 17:42:17 --> Language Class Initialized
INFO - 2018-03-30 17:42:17 --> Loader Class Initialized
INFO - 2018-03-30 17:42:17 --> Helper loaded: url_helper
INFO - 2018-03-30 17:42:17 --> Helper loaded: form_helper
INFO - 2018-03-30 17:42:17 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:42:17 --> Controller Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Model Class Initialized
INFO - 2018-03-30 17:42:17 --> Helper loaded: date_helper
INFO - 2018-03-30 17:42:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:42:17 --> Model Class Initialized
INFO - 2018-03-30 22:42:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:42:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:42:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-30 22:42:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:42:17 --> Final output sent to browser
DEBUG - 2018-03-30 22:42:17 --> Total execution time: 0.1239
INFO - 2018-03-30 17:42:24 --> Config Class Initialized
INFO - 2018-03-30 17:42:24 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:42:24 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:42:24 --> Utf8 Class Initialized
INFO - 2018-03-30 17:42:24 --> URI Class Initialized
INFO - 2018-03-30 17:42:24 --> Router Class Initialized
INFO - 2018-03-30 17:42:24 --> Output Class Initialized
INFO - 2018-03-30 17:42:24 --> Security Class Initialized
DEBUG - 2018-03-30 17:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:42:24 --> Input Class Initialized
INFO - 2018-03-30 17:42:24 --> Language Class Initialized
INFO - 2018-03-30 17:42:24 --> Loader Class Initialized
INFO - 2018-03-30 17:42:24 --> Helper loaded: url_helper
INFO - 2018-03-30 17:42:24 --> Helper loaded: form_helper
INFO - 2018-03-30 17:42:24 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:42:24 --> Controller Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Model Class Initialized
INFO - 2018-03-30 17:42:24 --> Helper loaded: date_helper
INFO - 2018-03-30 17:42:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:42:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/list.php
INFO - 2018-03-30 22:42:24 --> Final output sent to browser
DEBUG - 2018-03-30 22:42:24 --> Total execution time: 0.1030
INFO - 2018-03-30 17:42:41 --> Config Class Initialized
INFO - 2018-03-30 17:42:41 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:42:41 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:42:41 --> Utf8 Class Initialized
INFO - 2018-03-30 17:42:41 --> URI Class Initialized
INFO - 2018-03-30 17:42:41 --> Router Class Initialized
INFO - 2018-03-30 17:42:41 --> Output Class Initialized
INFO - 2018-03-30 17:42:41 --> Security Class Initialized
DEBUG - 2018-03-30 17:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:42:41 --> Input Class Initialized
INFO - 2018-03-30 17:42:41 --> Language Class Initialized
INFO - 2018-03-30 17:42:41 --> Loader Class Initialized
INFO - 2018-03-30 17:42:41 --> Helper loaded: url_helper
INFO - 2018-03-30 17:42:41 --> Helper loaded: form_helper
INFO - 2018-03-30 17:42:41 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:42:41 --> Controller Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Model Class Initialized
INFO - 2018-03-30 17:42:41 --> Helper loaded: date_helper
INFO - 2018-03-30 17:42:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:42:41 --> Model Class Initialized
INFO - 2018-03-30 22:42:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:42:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:42:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-30 22:42:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:42:41 --> Final output sent to browser
DEBUG - 2018-03-30 22:42:41 --> Total execution time: 0.1602
INFO - 2018-03-30 17:54:56 --> Config Class Initialized
INFO - 2018-03-30 17:54:56 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:54:56 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:54:56 --> Utf8 Class Initialized
INFO - 2018-03-30 17:54:56 --> URI Class Initialized
INFO - 2018-03-30 17:54:56 --> Router Class Initialized
INFO - 2018-03-30 17:54:56 --> Output Class Initialized
INFO - 2018-03-30 17:54:56 --> Security Class Initialized
DEBUG - 2018-03-30 17:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:54:56 --> Input Class Initialized
INFO - 2018-03-30 17:54:56 --> Language Class Initialized
INFO - 2018-03-30 17:54:56 --> Loader Class Initialized
INFO - 2018-03-30 17:54:56 --> Helper loaded: url_helper
INFO - 2018-03-30 17:54:56 --> Helper loaded: form_helper
INFO - 2018-03-30 17:54:56 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:54:56 --> Controller Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Model Class Initialized
INFO - 2018-03-30 17:54:56 --> Helper loaded: date_helper
INFO - 2018-03-30 17:54:56 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:54:56 --> Model Class Initialized
INFO - 2018-03-30 22:54:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:54:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:54:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-30 22:54:56 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:54:56 --> Final output sent to browser
DEBUG - 2018-03-30 22:54:56 --> Total execution time: 0.1282
INFO - 2018-03-30 17:55:01 --> Config Class Initialized
INFO - 2018-03-30 17:55:01 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:55:01 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:55:01 --> Utf8 Class Initialized
INFO - 2018-03-30 17:55:01 --> URI Class Initialized
INFO - 2018-03-30 17:55:01 --> Router Class Initialized
INFO - 2018-03-30 17:55:01 --> Output Class Initialized
INFO - 2018-03-30 17:55:01 --> Security Class Initialized
DEBUG - 2018-03-30 17:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:55:01 --> Input Class Initialized
INFO - 2018-03-30 17:55:01 --> Language Class Initialized
INFO - 2018-03-30 17:55:01 --> Loader Class Initialized
INFO - 2018-03-30 17:55:01 --> Helper loaded: url_helper
INFO - 2018-03-30 17:55:01 --> Helper loaded: form_helper
INFO - 2018-03-30 17:55:01 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:55:01 --> Controller Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Model Class Initialized
INFO - 2018-03-30 17:55:01 --> Helper loaded: date_helper
INFO - 2018-03-30 17:55:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:55:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/list.php
INFO - 2018-03-30 22:55:01 --> Final output sent to browser
DEBUG - 2018-03-30 22:55:01 --> Total execution time: 0.1576
INFO - 2018-03-30 17:55:52 --> Config Class Initialized
INFO - 2018-03-30 17:55:52 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:55:52 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:55:52 --> Utf8 Class Initialized
INFO - 2018-03-30 17:55:52 --> URI Class Initialized
INFO - 2018-03-30 17:55:52 --> Router Class Initialized
INFO - 2018-03-30 17:55:52 --> Output Class Initialized
INFO - 2018-03-30 17:55:52 --> Security Class Initialized
DEBUG - 2018-03-30 17:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:55:52 --> Input Class Initialized
INFO - 2018-03-30 17:55:52 --> Language Class Initialized
INFO - 2018-03-30 17:55:52 --> Loader Class Initialized
INFO - 2018-03-30 17:55:52 --> Helper loaded: url_helper
INFO - 2018-03-30 17:55:52 --> Helper loaded: form_helper
INFO - 2018-03-30 17:55:52 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:55:52 --> Controller Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Model Class Initialized
INFO - 2018-03-30 17:55:52 --> Helper loaded: date_helper
INFO - 2018-03-30 17:55:52 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:55:52 --> Model Class Initialized
INFO - 2018-03-30 22:55:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:55:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:55:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-30 22:55:52 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:55:52 --> Final output sent to browser
DEBUG - 2018-03-30 22:55:52 --> Total execution time: 0.1296
INFO - 2018-03-30 17:55:58 --> Config Class Initialized
INFO - 2018-03-30 17:55:58 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:55:58 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:55:58 --> Utf8 Class Initialized
INFO - 2018-03-30 17:55:58 --> URI Class Initialized
INFO - 2018-03-30 17:55:58 --> Router Class Initialized
INFO - 2018-03-30 17:55:58 --> Output Class Initialized
INFO - 2018-03-30 17:55:58 --> Security Class Initialized
DEBUG - 2018-03-30 17:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:55:58 --> Input Class Initialized
INFO - 2018-03-30 17:55:58 --> Language Class Initialized
INFO - 2018-03-30 17:55:58 --> Loader Class Initialized
INFO - 2018-03-30 17:55:58 --> Helper loaded: url_helper
INFO - 2018-03-30 17:55:58 --> Helper loaded: form_helper
INFO - 2018-03-30 17:55:58 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:55:58 --> Controller Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Model Class Initialized
INFO - 2018-03-30 17:55:58 --> Helper loaded: date_helper
INFO - 2018-03-30 17:55:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:55:58 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/list.php
INFO - 2018-03-30 22:55:58 --> Final output sent to browser
DEBUG - 2018-03-30 22:55:58 --> Total execution time: 0.1779
INFO - 2018-03-30 17:56:02 --> Config Class Initialized
INFO - 2018-03-30 17:56:02 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:56:02 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:56:02 --> Utf8 Class Initialized
INFO - 2018-03-30 17:56:02 --> URI Class Initialized
INFO - 2018-03-30 17:56:02 --> Router Class Initialized
INFO - 2018-03-30 17:56:02 --> Output Class Initialized
INFO - 2018-03-30 17:56:02 --> Security Class Initialized
DEBUG - 2018-03-30 17:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:56:02 --> Input Class Initialized
INFO - 2018-03-30 17:56:02 --> Language Class Initialized
INFO - 2018-03-30 17:56:02 --> Loader Class Initialized
INFO - 2018-03-30 17:56:02 --> Helper loaded: url_helper
INFO - 2018-03-30 17:56:02 --> Helper loaded: form_helper
INFO - 2018-03-30 17:56:02 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:56:02 --> Controller Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Model Class Initialized
INFO - 2018-03-30 17:56:02 --> Helper loaded: date_helper
INFO - 2018-03-30 17:56:02 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:56:02 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/list.php
INFO - 2018-03-30 22:56:02 --> Final output sent to browser
DEBUG - 2018-03-30 22:56:02 --> Total execution time: 0.1572
INFO - 2018-03-30 17:56:21 --> Config Class Initialized
INFO - 2018-03-30 17:56:21 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:56:21 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:56:21 --> Utf8 Class Initialized
INFO - 2018-03-30 17:56:21 --> URI Class Initialized
INFO - 2018-03-30 17:56:21 --> Router Class Initialized
INFO - 2018-03-30 17:56:21 --> Output Class Initialized
INFO - 2018-03-30 17:56:21 --> Security Class Initialized
DEBUG - 2018-03-30 17:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:56:21 --> Input Class Initialized
INFO - 2018-03-30 17:56:21 --> Language Class Initialized
INFO - 2018-03-30 17:56:21 --> Loader Class Initialized
INFO - 2018-03-30 17:56:21 --> Helper loaded: url_helper
INFO - 2018-03-30 17:56:21 --> Helper loaded: form_helper
INFO - 2018-03-30 17:56:21 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:56:21 --> Controller Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Model Class Initialized
INFO - 2018-03-30 17:56:21 --> Helper loaded: date_helper
INFO - 2018-03-30 17:56:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:56:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/list.php
INFO - 2018-03-30 22:56:21 --> Final output sent to browser
DEBUG - 2018-03-30 22:56:21 --> Total execution time: 0.1227
INFO - 2018-03-30 17:56:24 --> Config Class Initialized
INFO - 2018-03-30 17:56:24 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:56:24 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:56:24 --> Utf8 Class Initialized
INFO - 2018-03-30 17:56:24 --> URI Class Initialized
INFO - 2018-03-30 17:56:24 --> Router Class Initialized
INFO - 2018-03-30 17:56:24 --> Output Class Initialized
INFO - 2018-03-30 17:56:24 --> Security Class Initialized
DEBUG - 2018-03-30 17:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:56:24 --> Input Class Initialized
INFO - 2018-03-30 17:56:24 --> Language Class Initialized
INFO - 2018-03-30 17:56:24 --> Loader Class Initialized
INFO - 2018-03-30 17:56:24 --> Helper loaded: url_helper
INFO - 2018-03-30 17:56:24 --> Helper loaded: form_helper
INFO - 2018-03-30 17:56:24 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:56:24 --> Controller Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Model Class Initialized
INFO - 2018-03-30 17:56:24 --> Helper loaded: date_helper
INFO - 2018-03-30 17:56:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:56:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/list.php
INFO - 2018-03-30 22:56:24 --> Final output sent to browser
DEBUG - 2018-03-30 22:56:24 --> Total execution time: 0.1367
INFO - 2018-03-30 17:56:27 --> Config Class Initialized
INFO - 2018-03-30 17:56:27 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:56:27 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:56:27 --> Utf8 Class Initialized
INFO - 2018-03-30 17:56:27 --> URI Class Initialized
INFO - 2018-03-30 17:56:27 --> Router Class Initialized
INFO - 2018-03-30 17:56:27 --> Output Class Initialized
INFO - 2018-03-30 17:56:27 --> Security Class Initialized
DEBUG - 2018-03-30 17:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:56:27 --> Input Class Initialized
INFO - 2018-03-30 17:56:27 --> Language Class Initialized
INFO - 2018-03-30 17:56:27 --> Loader Class Initialized
INFO - 2018-03-30 17:56:27 --> Helper loaded: url_helper
INFO - 2018-03-30 17:56:27 --> Helper loaded: form_helper
INFO - 2018-03-30 17:56:27 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:56:27 --> Controller Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Model Class Initialized
INFO - 2018-03-30 17:56:27 --> Helper loaded: date_helper
INFO - 2018-03-30 17:56:27 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:56:27 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/list.php
INFO - 2018-03-30 22:56:27 --> Final output sent to browser
DEBUG - 2018-03-30 22:56:27 --> Total execution time: 0.1166
INFO - 2018-03-30 17:56:53 --> Config Class Initialized
INFO - 2018-03-30 17:56:53 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:56:53 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:56:53 --> Utf8 Class Initialized
INFO - 2018-03-30 17:56:53 --> URI Class Initialized
INFO - 2018-03-30 17:56:53 --> Router Class Initialized
INFO - 2018-03-30 17:56:53 --> Output Class Initialized
INFO - 2018-03-30 17:56:53 --> Security Class Initialized
DEBUG - 2018-03-30 17:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:56:53 --> Input Class Initialized
INFO - 2018-03-30 17:56:53 --> Language Class Initialized
INFO - 2018-03-30 17:56:53 --> Loader Class Initialized
INFO - 2018-03-30 17:56:53 --> Helper loaded: url_helper
INFO - 2018-03-30 17:56:53 --> Helper loaded: form_helper
INFO - 2018-03-30 17:56:53 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:56:53 --> Controller Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Model Class Initialized
INFO - 2018-03-30 17:56:53 --> Helper loaded: date_helper
INFO - 2018-03-30 17:56:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:56:53 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/list.php
INFO - 2018-03-30 22:56:53 --> Final output sent to browser
DEBUG - 2018-03-30 22:56:53 --> Total execution time: 0.1053
INFO - 2018-03-30 17:57:19 --> Config Class Initialized
INFO - 2018-03-30 17:57:19 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:57:19 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:57:19 --> Utf8 Class Initialized
INFO - 2018-03-30 17:57:19 --> URI Class Initialized
INFO - 2018-03-30 17:57:19 --> Router Class Initialized
INFO - 2018-03-30 17:57:19 --> Output Class Initialized
INFO - 2018-03-30 17:57:19 --> Security Class Initialized
DEBUG - 2018-03-30 17:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:57:19 --> Input Class Initialized
INFO - 2018-03-30 17:57:19 --> Language Class Initialized
INFO - 2018-03-30 17:57:19 --> Loader Class Initialized
INFO - 2018-03-30 17:57:19 --> Helper loaded: url_helper
INFO - 2018-03-30 17:57:19 --> Helper loaded: form_helper
INFO - 2018-03-30 17:57:19 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:57:19 --> Controller Class Initialized
INFO - 2018-03-30 17:57:19 --> Model Class Initialized
INFO - 2018-03-30 17:57:19 --> Model Class Initialized
INFO - 2018-03-30 17:57:19 --> Model Class Initialized
INFO - 2018-03-30 17:57:19 --> Model Class Initialized
INFO - 2018-03-30 17:57:19 --> Model Class Initialized
INFO - 2018-03-30 17:57:19 --> Model Class Initialized
INFO - 2018-03-30 17:57:19 --> Model Class Initialized
INFO - 2018-03-30 17:57:19 --> Model Class Initialized
INFO - 2018-03-30 17:57:19 --> Model Class Initialized
INFO - 2018-03-30 17:57:19 --> Model Class Initialized
INFO - 2018-03-30 17:57:19 --> Model Class Initialized
INFO - 2018-03-30 17:57:19 --> Model Class Initialized
INFO - 2018-03-30 17:57:19 --> Model Class Initialized
INFO - 2018-03-30 17:57:19 --> Model Class Initialized
INFO - 2018-03-30 17:57:20 --> Model Class Initialized
INFO - 2018-03-30 17:57:20 --> Model Class Initialized
INFO - 2018-03-30 17:57:20 --> Model Class Initialized
INFO - 2018-03-30 17:57:20 --> Model Class Initialized
INFO - 2018-03-30 17:57:20 --> Helper loaded: date_helper
INFO - 2018-03-30 17:57:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:57:20 --> Model Class Initialized
INFO - 2018-03-30 22:57:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:57:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:57:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-30 22:57:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:57:20 --> Final output sent to browser
DEBUG - 2018-03-30 22:57:20 --> Total execution time: 0.1316
INFO - 2018-03-30 17:57:29 --> Config Class Initialized
INFO - 2018-03-30 17:57:29 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:57:29 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:57:29 --> Utf8 Class Initialized
INFO - 2018-03-30 17:57:29 --> URI Class Initialized
INFO - 2018-03-30 17:57:29 --> Router Class Initialized
INFO - 2018-03-30 17:57:29 --> Output Class Initialized
INFO - 2018-03-30 17:57:29 --> Security Class Initialized
DEBUG - 2018-03-30 17:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:57:29 --> Input Class Initialized
INFO - 2018-03-30 17:57:29 --> Language Class Initialized
INFO - 2018-03-30 17:57:29 --> Loader Class Initialized
INFO - 2018-03-30 17:57:29 --> Helper loaded: url_helper
INFO - 2018-03-30 17:57:29 --> Helper loaded: form_helper
INFO - 2018-03-30 17:57:29 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:57:29 --> Controller Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Model Class Initialized
INFO - 2018-03-30 17:57:29 --> Helper loaded: date_helper
INFO - 2018-03-30 17:57:29 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:57:29 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/list.php
INFO - 2018-03-30 22:57:29 --> Final output sent to browser
DEBUG - 2018-03-30 22:57:29 --> Total execution time: 0.1202
INFO - 2018-03-30 17:57:59 --> Config Class Initialized
INFO - 2018-03-30 17:57:59 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:57:59 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:57:59 --> Utf8 Class Initialized
INFO - 2018-03-30 17:57:59 --> URI Class Initialized
INFO - 2018-03-30 17:57:59 --> Router Class Initialized
INFO - 2018-03-30 17:57:59 --> Output Class Initialized
INFO - 2018-03-30 17:57:59 --> Security Class Initialized
DEBUG - 2018-03-30 17:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:57:59 --> Input Class Initialized
INFO - 2018-03-30 17:57:59 --> Language Class Initialized
INFO - 2018-03-30 17:57:59 --> Loader Class Initialized
INFO - 2018-03-30 17:57:59 --> Helper loaded: url_helper
INFO - 2018-03-30 17:57:59 --> Helper loaded: form_helper
INFO - 2018-03-30 17:57:59 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:57:59 --> Controller Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Model Class Initialized
INFO - 2018-03-30 17:57:59 --> Helper loaded: date_helper
INFO - 2018-03-30 17:57:59 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:57:59 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/list.php
INFO - 2018-03-30 22:57:59 --> Final output sent to browser
DEBUG - 2018-03-30 22:57:59 --> Total execution time: 0.1054
INFO - 2018-03-30 17:58:05 --> Config Class Initialized
INFO - 2018-03-30 17:58:05 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:58:05 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:58:05 --> Utf8 Class Initialized
INFO - 2018-03-30 17:58:05 --> URI Class Initialized
INFO - 2018-03-30 17:58:05 --> Router Class Initialized
INFO - 2018-03-30 17:58:05 --> Output Class Initialized
INFO - 2018-03-30 17:58:05 --> Security Class Initialized
DEBUG - 2018-03-30 17:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:58:05 --> Input Class Initialized
INFO - 2018-03-30 17:58:05 --> Language Class Initialized
INFO - 2018-03-30 17:58:05 --> Loader Class Initialized
INFO - 2018-03-30 17:58:05 --> Helper loaded: url_helper
INFO - 2018-03-30 17:58:05 --> Helper loaded: form_helper
INFO - 2018-03-30 17:58:05 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:58:05 --> Controller Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Model Class Initialized
INFO - 2018-03-30 17:58:05 --> Helper loaded: date_helper
INFO - 2018-03-30 17:58:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:58:05 --> Model Class Initialized
INFO - 2018-03-30 22:58:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-30 22:58:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-30 22:58:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-30 22:58:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-30 22:58:05 --> Final output sent to browser
DEBUG - 2018-03-30 22:58:05 --> Total execution time: 0.1326
INFO - 2018-03-30 17:58:15 --> Config Class Initialized
INFO - 2018-03-30 17:58:15 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:58:15 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:58:15 --> Utf8 Class Initialized
INFO - 2018-03-30 17:58:15 --> URI Class Initialized
INFO - 2018-03-30 17:58:15 --> Router Class Initialized
INFO - 2018-03-30 17:58:15 --> Output Class Initialized
INFO - 2018-03-30 17:58:15 --> Security Class Initialized
DEBUG - 2018-03-30 17:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:58:15 --> Input Class Initialized
INFO - 2018-03-30 17:58:15 --> Language Class Initialized
INFO - 2018-03-30 17:58:15 --> Loader Class Initialized
INFO - 2018-03-30 17:58:15 --> Helper loaded: url_helper
INFO - 2018-03-30 17:58:15 --> Helper loaded: form_helper
INFO - 2018-03-30 17:58:15 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:58:15 --> Controller Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Model Class Initialized
INFO - 2018-03-30 17:58:15 --> Helper loaded: date_helper
INFO - 2018-03-30 17:58:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 22:58:15 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/list.php
INFO - 2018-03-30 22:58:15 --> Final output sent to browser
DEBUG - 2018-03-30 22:58:15 --> Total execution time: 0.1531
INFO - 2018-03-30 19:18:41 --> Config Class Initialized
INFO - 2018-03-30 19:18:41 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:18:41 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:18:41 --> Utf8 Class Initialized
INFO - 2018-03-30 19:18:41 --> URI Class Initialized
INFO - 2018-03-30 19:18:41 --> Router Class Initialized
INFO - 2018-03-30 19:18:41 --> Output Class Initialized
INFO - 2018-03-30 19:18:41 --> Security Class Initialized
DEBUG - 2018-03-30 19:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:18:41 --> Input Class Initialized
INFO - 2018-03-30 19:18:41 --> Language Class Initialized
INFO - 2018-03-30 19:18:41 --> Loader Class Initialized
INFO - 2018-03-30 19:18:41 --> Helper loaded: url_helper
INFO - 2018-03-30 19:18:41 --> Helper loaded: form_helper
INFO - 2018-03-30 19:18:41 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:18:41 --> Controller Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Model Class Initialized
INFO - 2018-03-30 19:18:41 --> Helper loaded: date_helper
INFO - 2018-03-30 19:18:41 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:18:49 --> Config Class Initialized
INFO - 2018-03-30 19:18:49 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:18:49 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:18:49 --> Utf8 Class Initialized
INFO - 2018-03-30 19:18:49 --> URI Class Initialized
INFO - 2018-03-30 19:18:49 --> Router Class Initialized
INFO - 2018-03-30 19:18:49 --> Output Class Initialized
INFO - 2018-03-30 19:18:49 --> Security Class Initialized
DEBUG - 2018-03-30 19:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:18:49 --> Input Class Initialized
INFO - 2018-03-30 19:18:49 --> Language Class Initialized
INFO - 2018-03-30 19:18:49 --> Loader Class Initialized
INFO - 2018-03-30 19:18:49 --> Helper loaded: url_helper
INFO - 2018-03-30 19:18:49 --> Helper loaded: form_helper
INFO - 2018-03-30 19:18:49 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:18:49 --> Controller Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Model Class Initialized
INFO - 2018-03-30 19:18:49 --> Helper loaded: date_helper
INFO - 2018-03-30 19:18:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:18:51 --> Config Class Initialized
INFO - 2018-03-30 19:18:51 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:18:51 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:18:51 --> Utf8 Class Initialized
INFO - 2018-03-30 19:18:51 --> URI Class Initialized
INFO - 2018-03-30 19:18:51 --> Router Class Initialized
INFO - 2018-03-30 19:18:51 --> Output Class Initialized
INFO - 2018-03-30 19:18:51 --> Security Class Initialized
DEBUG - 2018-03-30 19:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:18:51 --> Input Class Initialized
INFO - 2018-03-30 19:18:51 --> Language Class Initialized
INFO - 2018-03-30 19:18:51 --> Loader Class Initialized
INFO - 2018-03-30 19:18:51 --> Helper loaded: url_helper
INFO - 2018-03-30 19:18:51 --> Helper loaded: form_helper
INFO - 2018-03-30 19:18:51 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:18:51 --> Controller Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Model Class Initialized
INFO - 2018-03-30 19:18:51 --> Helper loaded: date_helper
INFO - 2018-03-30 19:18:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:33:04 --> Config Class Initialized
INFO - 2018-03-30 19:33:04 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:33:04 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:33:04 --> Utf8 Class Initialized
INFO - 2018-03-30 19:33:04 --> URI Class Initialized
INFO - 2018-03-30 19:33:04 --> Router Class Initialized
INFO - 2018-03-30 19:33:04 --> Output Class Initialized
INFO - 2018-03-30 19:33:04 --> Security Class Initialized
DEBUG - 2018-03-30 19:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:33:04 --> Input Class Initialized
INFO - 2018-03-30 19:33:04 --> Language Class Initialized
INFO - 2018-03-30 19:33:04 --> Loader Class Initialized
INFO - 2018-03-30 19:33:04 --> Helper loaded: url_helper
INFO - 2018-03-30 19:33:04 --> Helper loaded: form_helper
INFO - 2018-03-30 19:33:04 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:33:04 --> Controller Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Model Class Initialized
INFO - 2018-03-30 19:33:04 --> Helper loaded: date_helper
INFO - 2018-03-30 19:33:04 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:33:10 --> Config Class Initialized
INFO - 2018-03-30 19:33:10 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:33:10 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:33:10 --> Utf8 Class Initialized
INFO - 2018-03-30 19:33:10 --> URI Class Initialized
DEBUG - 2018-03-30 19:33:10 --> No URI present. Default controller set.
INFO - 2018-03-30 19:33:10 --> Router Class Initialized
INFO - 2018-03-30 19:33:10 --> Output Class Initialized
INFO - 2018-03-30 19:33:10 --> Security Class Initialized
DEBUG - 2018-03-30 19:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:33:10 --> Input Class Initialized
INFO - 2018-03-30 19:33:10 --> Language Class Initialized
INFO - 2018-03-30 19:33:10 --> Loader Class Initialized
INFO - 2018-03-30 19:33:10 --> Helper loaded: url_helper
INFO - 2018-03-30 19:33:10 --> Helper loaded: form_helper
INFO - 2018-03-30 19:33:10 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:33:10 --> Controller Class Initialized
INFO - 2018-03-30 19:33:10 --> Model Class Initialized
INFO - 2018-03-30 19:33:10 --> Model Class Initialized
INFO - 2018-03-30 19:33:10 --> Model Class Initialized
INFO - 2018-03-30 19:33:10 --> Helper loaded: date_helper
INFO - 2018-03-30 19:33:13 --> Config Class Initialized
INFO - 2018-03-30 19:33:13 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:33:13 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:33:13 --> Utf8 Class Initialized
INFO - 2018-03-30 19:33:13 --> URI Class Initialized
DEBUG - 2018-03-30 19:33:13 --> No URI present. Default controller set.
INFO - 2018-03-30 19:33:13 --> Router Class Initialized
INFO - 2018-03-30 19:33:13 --> Output Class Initialized
INFO - 2018-03-30 19:33:13 --> Security Class Initialized
DEBUG - 2018-03-30 19:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:33:13 --> Input Class Initialized
INFO - 2018-03-30 19:33:13 --> Language Class Initialized
INFO - 2018-03-30 19:33:13 --> Loader Class Initialized
INFO - 2018-03-30 19:33:13 --> Helper loaded: url_helper
INFO - 2018-03-30 19:33:13 --> Helper loaded: form_helper
INFO - 2018-03-30 19:33:13 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:33:13 --> Controller Class Initialized
INFO - 2018-03-30 19:33:13 --> Model Class Initialized
INFO - 2018-03-30 19:33:13 --> Model Class Initialized
INFO - 2018-03-30 19:33:13 --> Model Class Initialized
INFO - 2018-03-30 19:33:13 --> Helper loaded: date_helper
INFO - 2018-03-30 19:33:14 --> Config Class Initialized
INFO - 2018-03-30 19:33:14 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:33:14 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:33:14 --> Utf8 Class Initialized
INFO - 2018-03-30 19:33:14 --> URI Class Initialized
INFO - 2018-03-30 19:33:14 --> Router Class Initialized
INFO - 2018-03-30 19:33:14 --> Output Class Initialized
INFO - 2018-03-30 19:33:14 --> Security Class Initialized
DEBUG - 2018-03-30 19:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:33:14 --> Input Class Initialized
INFO - 2018-03-30 19:33:14 --> Language Class Initialized
INFO - 2018-03-30 19:33:14 --> Loader Class Initialized
INFO - 2018-03-30 19:33:14 --> Helper loaded: url_helper
INFO - 2018-03-30 19:33:14 --> Helper loaded: form_helper
INFO - 2018-03-30 19:33:14 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:33:14 --> Controller Class Initialized
INFO - 2018-03-30 19:33:14 --> Model Class Initialized
INFO - 2018-03-30 19:33:14 --> Model Class Initialized
INFO - 2018-03-30 19:33:14 --> Model Class Initialized
INFO - 2018-03-30 19:33:14 --> Model Class Initialized
INFO - 2018-03-30 19:33:14 --> Model Class Initialized
INFO - 2018-03-30 19:33:14 --> Helper loaded: date_helper
INFO - 2018-03-30 19:33:19 --> Config Class Initialized
INFO - 2018-03-30 19:33:19 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:33:19 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:33:19 --> Utf8 Class Initialized
INFO - 2018-03-30 19:33:19 --> URI Class Initialized
INFO - 2018-03-30 19:33:19 --> Router Class Initialized
INFO - 2018-03-30 19:33:19 --> Output Class Initialized
INFO - 2018-03-30 19:33:19 --> Security Class Initialized
DEBUG - 2018-03-30 19:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:33:19 --> Input Class Initialized
INFO - 2018-03-30 19:33:19 --> Language Class Initialized
INFO - 2018-03-30 19:33:19 --> Loader Class Initialized
INFO - 2018-03-30 19:33:19 --> Helper loaded: url_helper
INFO - 2018-03-30 19:33:19 --> Helper loaded: form_helper
INFO - 2018-03-30 19:33:19 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:33:19 --> Controller Class Initialized
INFO - 2018-03-30 19:33:19 --> Model Class Initialized
INFO - 2018-03-30 19:33:19 --> Model Class Initialized
INFO - 2018-03-30 19:33:19 --> Model Class Initialized
INFO - 2018-03-30 19:33:19 --> Model Class Initialized
INFO - 2018-03-30 19:33:19 --> Model Class Initialized
INFO - 2018-03-30 19:33:19 --> Model Class Initialized
INFO - 2018-03-30 19:33:19 --> Model Class Initialized
INFO - 2018-03-30 19:33:19 --> Model Class Initialized
INFO - 2018-03-30 19:33:19 --> Model Class Initialized
INFO - 2018-03-30 19:33:19 --> Model Class Initialized
INFO - 2018-03-30 19:33:19 --> Helper loaded: date_helper
INFO - 2018-03-30 19:33:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:34:46 --> Config Class Initialized
INFO - 2018-03-30 19:34:46 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:34:46 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:34:46 --> Utf8 Class Initialized
INFO - 2018-03-30 19:34:46 --> URI Class Initialized
INFO - 2018-03-30 19:34:46 --> Router Class Initialized
INFO - 2018-03-30 19:34:46 --> Output Class Initialized
INFO - 2018-03-30 19:34:46 --> Security Class Initialized
DEBUG - 2018-03-30 19:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:34:46 --> Input Class Initialized
INFO - 2018-03-30 19:34:46 --> Language Class Initialized
INFO - 2018-03-30 19:34:46 --> Loader Class Initialized
INFO - 2018-03-30 19:34:46 --> Helper loaded: url_helper
INFO - 2018-03-30 19:34:46 --> Helper loaded: form_helper
INFO - 2018-03-30 19:34:46 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:34:46 --> Controller Class Initialized
INFO - 2018-03-30 19:34:46 --> Model Class Initialized
INFO - 2018-03-30 19:34:46 --> Model Class Initialized
INFO - 2018-03-30 19:34:46 --> Model Class Initialized
INFO - 2018-03-30 19:34:46 --> Model Class Initialized
INFO - 2018-03-30 19:34:46 --> Model Class Initialized
INFO - 2018-03-30 19:34:46 --> Model Class Initialized
INFO - 2018-03-30 19:34:46 --> Model Class Initialized
INFO - 2018-03-30 19:34:46 --> Model Class Initialized
INFO - 2018-03-30 19:34:46 --> Model Class Initialized
INFO - 2018-03-30 19:34:46 --> Model Class Initialized
INFO - 2018-03-30 19:34:46 --> Helper loaded: date_helper
INFO - 2018-03-30 19:34:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:34:50 --> Config Class Initialized
INFO - 2018-03-30 19:34:50 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:34:50 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:34:50 --> Utf8 Class Initialized
INFO - 2018-03-30 19:34:50 --> URI Class Initialized
INFO - 2018-03-30 19:34:50 --> Router Class Initialized
INFO - 2018-03-30 19:34:50 --> Output Class Initialized
INFO - 2018-03-30 19:34:50 --> Security Class Initialized
DEBUG - 2018-03-30 19:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:34:50 --> Input Class Initialized
INFO - 2018-03-30 19:34:50 --> Language Class Initialized
INFO - 2018-03-30 19:34:50 --> Loader Class Initialized
INFO - 2018-03-30 19:34:50 --> Helper loaded: url_helper
INFO - 2018-03-30 19:34:50 --> Helper loaded: form_helper
INFO - 2018-03-30 19:34:50 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:34:50 --> Controller Class Initialized
INFO - 2018-03-30 19:34:50 --> Model Class Initialized
INFO - 2018-03-30 19:34:50 --> Model Class Initialized
INFO - 2018-03-30 19:34:50 --> Model Class Initialized
INFO - 2018-03-30 19:34:50 --> Model Class Initialized
INFO - 2018-03-30 19:34:50 --> Model Class Initialized
INFO - 2018-03-30 19:34:50 --> Model Class Initialized
INFO - 2018-03-30 19:34:50 --> Model Class Initialized
INFO - 2018-03-30 19:34:50 --> Model Class Initialized
INFO - 2018-03-30 19:34:50 --> Model Class Initialized
INFO - 2018-03-30 19:34:50 --> Model Class Initialized
INFO - 2018-03-30 19:34:50 --> Helper loaded: date_helper
INFO - 2018-03-30 19:34:50 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:34:51 --> Config Class Initialized
INFO - 2018-03-30 19:34:51 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:34:51 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:34:51 --> Utf8 Class Initialized
INFO - 2018-03-30 19:34:51 --> URI Class Initialized
INFO - 2018-03-30 19:34:51 --> Router Class Initialized
INFO - 2018-03-30 19:34:51 --> Output Class Initialized
INFO - 2018-03-30 19:34:51 --> Security Class Initialized
DEBUG - 2018-03-30 19:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:34:51 --> Input Class Initialized
INFO - 2018-03-30 19:34:51 --> Language Class Initialized
INFO - 2018-03-30 19:34:51 --> Loader Class Initialized
INFO - 2018-03-30 19:34:51 --> Helper loaded: url_helper
INFO - 2018-03-30 19:34:51 --> Helper loaded: form_helper
INFO - 2018-03-30 19:34:51 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:34:51 --> Controller Class Initialized
INFO - 2018-03-30 19:34:51 --> Model Class Initialized
INFO - 2018-03-30 19:34:51 --> Model Class Initialized
INFO - 2018-03-30 19:34:51 --> Model Class Initialized
INFO - 2018-03-30 19:34:51 --> Model Class Initialized
INFO - 2018-03-30 19:34:51 --> Model Class Initialized
INFO - 2018-03-30 19:34:51 --> Model Class Initialized
INFO - 2018-03-30 19:34:51 --> Model Class Initialized
INFO - 2018-03-30 19:34:51 --> Model Class Initialized
INFO - 2018-03-30 19:34:51 --> Model Class Initialized
INFO - 2018-03-30 19:34:51 --> Model Class Initialized
INFO - 2018-03-30 19:34:51 --> Helper loaded: date_helper
INFO - 2018-03-30 19:34:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:35:08 --> Config Class Initialized
INFO - 2018-03-30 19:35:08 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:35:08 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:35:08 --> Utf8 Class Initialized
INFO - 2018-03-30 19:35:08 --> URI Class Initialized
INFO - 2018-03-30 19:35:08 --> Router Class Initialized
INFO - 2018-03-30 19:35:08 --> Output Class Initialized
INFO - 2018-03-30 19:35:08 --> Security Class Initialized
DEBUG - 2018-03-30 19:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:35:08 --> Input Class Initialized
INFO - 2018-03-30 19:35:08 --> Language Class Initialized
INFO - 2018-03-30 19:35:08 --> Loader Class Initialized
INFO - 2018-03-30 19:35:08 --> Helper loaded: url_helper
INFO - 2018-03-30 19:35:08 --> Helper loaded: form_helper
INFO - 2018-03-30 19:35:08 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:35:08 --> Controller Class Initialized
INFO - 2018-03-30 19:35:08 --> Model Class Initialized
INFO - 2018-03-30 19:35:08 --> Model Class Initialized
INFO - 2018-03-30 19:35:08 --> Model Class Initialized
INFO - 2018-03-30 19:35:08 --> Model Class Initialized
INFO - 2018-03-30 19:35:08 --> Model Class Initialized
INFO - 2018-03-30 19:35:08 --> Model Class Initialized
INFO - 2018-03-30 19:35:08 --> Model Class Initialized
INFO - 2018-03-30 19:35:08 --> Model Class Initialized
INFO - 2018-03-30 19:35:08 --> Model Class Initialized
INFO - 2018-03-30 19:35:08 --> Model Class Initialized
INFO - 2018-03-30 19:35:08 --> Helper loaded: date_helper
INFO - 2018-03-30 19:35:08 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:35:09 --> Config Class Initialized
INFO - 2018-03-30 19:35:09 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:35:09 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:35:09 --> Utf8 Class Initialized
INFO - 2018-03-30 19:35:09 --> URI Class Initialized
INFO - 2018-03-30 19:35:09 --> Router Class Initialized
INFO - 2018-03-30 19:35:09 --> Output Class Initialized
INFO - 2018-03-30 19:35:09 --> Security Class Initialized
DEBUG - 2018-03-30 19:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:35:09 --> Input Class Initialized
INFO - 2018-03-30 19:35:09 --> Language Class Initialized
INFO - 2018-03-30 19:35:09 --> Loader Class Initialized
INFO - 2018-03-30 19:35:09 --> Helper loaded: url_helper
INFO - 2018-03-30 19:35:09 --> Helper loaded: form_helper
INFO - 2018-03-30 19:35:09 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:35:09 --> Controller Class Initialized
INFO - 2018-03-30 19:35:09 --> Model Class Initialized
INFO - 2018-03-30 19:35:09 --> Model Class Initialized
INFO - 2018-03-30 19:35:09 --> Model Class Initialized
INFO - 2018-03-30 19:35:09 --> Model Class Initialized
INFO - 2018-03-30 19:35:09 --> Model Class Initialized
INFO - 2018-03-30 19:35:09 --> Model Class Initialized
INFO - 2018-03-30 19:35:09 --> Model Class Initialized
INFO - 2018-03-30 19:35:09 --> Model Class Initialized
INFO - 2018-03-30 19:35:09 --> Model Class Initialized
INFO - 2018-03-30 19:35:09 --> Model Class Initialized
INFO - 2018-03-30 19:35:09 --> Helper loaded: date_helper
INFO - 2018-03-30 19:35:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:35:45 --> Config Class Initialized
INFO - 2018-03-30 19:35:45 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:35:45 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:35:45 --> Utf8 Class Initialized
INFO - 2018-03-30 19:35:45 --> URI Class Initialized
INFO - 2018-03-30 19:35:45 --> Router Class Initialized
INFO - 2018-03-30 19:35:45 --> Output Class Initialized
INFO - 2018-03-30 19:35:45 --> Security Class Initialized
DEBUG - 2018-03-30 19:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:35:45 --> Input Class Initialized
INFO - 2018-03-30 19:35:45 --> Language Class Initialized
INFO - 2018-03-30 19:35:45 --> Loader Class Initialized
INFO - 2018-03-30 19:35:45 --> Helper loaded: url_helper
INFO - 2018-03-30 19:35:45 --> Helper loaded: form_helper
INFO - 2018-03-30 19:35:45 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:35:45 --> Controller Class Initialized
INFO - 2018-03-30 19:35:45 --> Model Class Initialized
INFO - 2018-03-30 19:35:45 --> Model Class Initialized
INFO - 2018-03-30 19:35:45 --> Model Class Initialized
INFO - 2018-03-30 19:35:45 --> Model Class Initialized
INFO - 2018-03-30 19:35:45 --> Model Class Initialized
INFO - 2018-03-30 19:35:45 --> Model Class Initialized
INFO - 2018-03-30 19:35:45 --> Model Class Initialized
INFO - 2018-03-30 19:35:45 --> Model Class Initialized
INFO - 2018-03-30 19:35:45 --> Model Class Initialized
INFO - 2018-03-30 19:35:45 --> Model Class Initialized
INFO - 2018-03-30 19:35:45 --> Helper loaded: date_helper
INFO - 2018-03-30 19:35:45 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:35:48 --> Config Class Initialized
INFO - 2018-03-30 19:35:48 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:35:48 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:35:48 --> Utf8 Class Initialized
INFO - 2018-03-30 19:35:48 --> URI Class Initialized
INFO - 2018-03-30 19:35:48 --> Router Class Initialized
INFO - 2018-03-30 19:35:48 --> Output Class Initialized
INFO - 2018-03-30 19:35:48 --> Security Class Initialized
DEBUG - 2018-03-30 19:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:35:48 --> Input Class Initialized
INFO - 2018-03-30 19:35:48 --> Language Class Initialized
INFO - 2018-03-30 19:35:48 --> Loader Class Initialized
INFO - 2018-03-30 19:35:48 --> Helper loaded: url_helper
INFO - 2018-03-30 19:35:48 --> Helper loaded: form_helper
INFO - 2018-03-30 19:35:48 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:35:48 --> Controller Class Initialized
INFO - 2018-03-30 19:35:48 --> Model Class Initialized
INFO - 2018-03-30 19:35:48 --> Model Class Initialized
INFO - 2018-03-30 19:35:48 --> Model Class Initialized
INFO - 2018-03-30 19:35:48 --> Model Class Initialized
INFO - 2018-03-30 19:35:48 --> Model Class Initialized
INFO - 2018-03-30 19:35:48 --> Model Class Initialized
INFO - 2018-03-30 19:35:48 --> Model Class Initialized
INFO - 2018-03-30 19:35:48 --> Model Class Initialized
INFO - 2018-03-30 19:35:48 --> Model Class Initialized
INFO - 2018-03-30 19:35:48 --> Model Class Initialized
INFO - 2018-03-30 19:35:48 --> Helper loaded: date_helper
INFO - 2018-03-30 19:35:48 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:36:25 --> Config Class Initialized
INFO - 2018-03-30 19:36:25 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:36:25 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:36:25 --> Utf8 Class Initialized
INFO - 2018-03-30 19:36:25 --> URI Class Initialized
INFO - 2018-03-30 19:36:25 --> Router Class Initialized
INFO - 2018-03-30 19:36:25 --> Output Class Initialized
INFO - 2018-03-30 19:36:25 --> Security Class Initialized
DEBUG - 2018-03-30 19:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:36:25 --> Input Class Initialized
INFO - 2018-03-30 19:36:25 --> Language Class Initialized
INFO - 2018-03-30 19:36:25 --> Loader Class Initialized
INFO - 2018-03-30 19:36:25 --> Helper loaded: url_helper
INFO - 2018-03-30 19:36:25 --> Helper loaded: form_helper
INFO - 2018-03-30 19:36:25 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:36:25 --> Controller Class Initialized
INFO - 2018-03-30 19:36:25 --> Model Class Initialized
INFO - 2018-03-30 19:36:25 --> Model Class Initialized
INFO - 2018-03-30 19:36:25 --> Model Class Initialized
INFO - 2018-03-30 19:36:25 --> Model Class Initialized
INFO - 2018-03-30 19:36:25 --> Model Class Initialized
INFO - 2018-03-30 19:36:25 --> Model Class Initialized
INFO - 2018-03-30 19:36:25 --> Model Class Initialized
INFO - 2018-03-30 19:36:25 --> Model Class Initialized
INFO - 2018-03-30 19:36:25 --> Model Class Initialized
INFO - 2018-03-30 19:36:25 --> Model Class Initialized
INFO - 2018-03-30 19:36:25 --> Helper loaded: date_helper
INFO - 2018-03-30 19:36:25 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:36:34 --> Config Class Initialized
INFO - 2018-03-30 19:36:34 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:36:34 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:36:34 --> Utf8 Class Initialized
INFO - 2018-03-30 19:36:34 --> URI Class Initialized
INFO - 2018-03-30 19:36:34 --> Router Class Initialized
INFO - 2018-03-30 19:36:34 --> Output Class Initialized
INFO - 2018-03-30 19:36:34 --> Security Class Initialized
DEBUG - 2018-03-30 19:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:36:34 --> Input Class Initialized
INFO - 2018-03-30 19:36:34 --> Language Class Initialized
INFO - 2018-03-30 19:36:34 --> Loader Class Initialized
INFO - 2018-03-30 19:36:34 --> Helper loaded: url_helper
INFO - 2018-03-30 19:36:34 --> Helper loaded: form_helper
INFO - 2018-03-30 19:36:34 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:36:34 --> Controller Class Initialized
INFO - 2018-03-30 19:36:34 --> Model Class Initialized
INFO - 2018-03-30 19:36:34 --> Model Class Initialized
INFO - 2018-03-30 19:36:34 --> Model Class Initialized
INFO - 2018-03-30 19:36:34 --> Model Class Initialized
INFO - 2018-03-30 19:36:34 --> Model Class Initialized
INFO - 2018-03-30 19:36:34 --> Model Class Initialized
INFO - 2018-03-30 19:36:34 --> Model Class Initialized
INFO - 2018-03-30 19:36:34 --> Model Class Initialized
INFO - 2018-03-30 19:36:34 --> Model Class Initialized
INFO - 2018-03-30 19:36:34 --> Model Class Initialized
INFO - 2018-03-30 19:36:34 --> Helper loaded: date_helper
INFO - 2018-03-30 19:36:34 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:38:58 --> Config Class Initialized
INFO - 2018-03-30 19:38:58 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:38:58 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:38:58 --> Utf8 Class Initialized
INFO - 2018-03-30 19:38:58 --> URI Class Initialized
INFO - 2018-03-30 19:38:58 --> Router Class Initialized
INFO - 2018-03-30 19:38:58 --> Output Class Initialized
INFO - 2018-03-30 19:38:58 --> Security Class Initialized
DEBUG - 2018-03-30 19:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:38:58 --> Input Class Initialized
INFO - 2018-03-30 19:38:58 --> Language Class Initialized
INFO - 2018-03-30 19:38:58 --> Loader Class Initialized
INFO - 2018-03-30 19:38:58 --> Helper loaded: url_helper
INFO - 2018-03-30 19:38:58 --> Helper loaded: form_helper
INFO - 2018-03-30 19:38:58 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:38:58 --> Controller Class Initialized
INFO - 2018-03-30 19:38:58 --> Model Class Initialized
INFO - 2018-03-30 19:38:58 --> Model Class Initialized
INFO - 2018-03-30 19:38:58 --> Model Class Initialized
INFO - 2018-03-30 19:38:58 --> Model Class Initialized
INFO - 2018-03-30 19:38:58 --> Model Class Initialized
INFO - 2018-03-30 19:38:58 --> Model Class Initialized
INFO - 2018-03-30 19:38:58 --> Model Class Initialized
INFO - 2018-03-30 19:38:58 --> Model Class Initialized
INFO - 2018-03-30 19:38:58 --> Model Class Initialized
INFO - 2018-03-30 19:38:58 --> Model Class Initialized
INFO - 2018-03-30 19:38:58 --> Helper loaded: date_helper
INFO - 2018-03-30 19:38:58 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:39:49 --> Config Class Initialized
INFO - 2018-03-30 19:39:49 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:39:49 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:39:49 --> Utf8 Class Initialized
INFO - 2018-03-30 19:39:49 --> URI Class Initialized
INFO - 2018-03-30 19:39:49 --> Router Class Initialized
INFO - 2018-03-30 19:39:49 --> Output Class Initialized
INFO - 2018-03-30 19:39:49 --> Security Class Initialized
DEBUG - 2018-03-30 19:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:39:49 --> Input Class Initialized
INFO - 2018-03-30 19:39:49 --> Language Class Initialized
INFO - 2018-03-30 19:39:49 --> Loader Class Initialized
INFO - 2018-03-30 19:39:49 --> Helper loaded: url_helper
INFO - 2018-03-30 19:39:49 --> Helper loaded: form_helper
INFO - 2018-03-30 19:39:49 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:39:49 --> Controller Class Initialized
INFO - 2018-03-30 19:39:49 --> Model Class Initialized
INFO - 2018-03-30 19:39:49 --> Model Class Initialized
INFO - 2018-03-30 19:39:49 --> Model Class Initialized
INFO - 2018-03-30 19:39:49 --> Model Class Initialized
INFO - 2018-03-30 19:39:49 --> Model Class Initialized
INFO - 2018-03-30 19:39:49 --> Model Class Initialized
INFO - 2018-03-30 19:39:49 --> Model Class Initialized
INFO - 2018-03-30 19:39:49 --> Model Class Initialized
INFO - 2018-03-30 19:39:49 --> Model Class Initialized
INFO - 2018-03-30 19:39:49 --> Model Class Initialized
INFO - 2018-03-30 19:39:49 --> Helper loaded: date_helper
INFO - 2018-03-30 19:39:49 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:40:21 --> Config Class Initialized
INFO - 2018-03-30 19:40:21 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:40:21 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:40:21 --> Utf8 Class Initialized
INFO - 2018-03-30 19:40:21 --> URI Class Initialized
INFO - 2018-03-30 19:40:21 --> Router Class Initialized
INFO - 2018-03-30 19:40:21 --> Output Class Initialized
INFO - 2018-03-30 19:40:21 --> Security Class Initialized
DEBUG - 2018-03-30 19:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:40:21 --> Input Class Initialized
INFO - 2018-03-30 19:40:21 --> Language Class Initialized
INFO - 2018-03-30 19:40:21 --> Loader Class Initialized
INFO - 2018-03-30 19:40:21 --> Helper loaded: url_helper
INFO - 2018-03-30 19:40:21 --> Helper loaded: form_helper
INFO - 2018-03-30 19:40:21 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:40:21 --> Controller Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Model Class Initialized
INFO - 2018-03-30 19:40:21 --> Helper loaded: date_helper
INFO - 2018-03-30 19:40:21 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:43:15 --> Config Class Initialized
INFO - 2018-03-30 19:43:15 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:43:15 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:43:15 --> Utf8 Class Initialized
INFO - 2018-03-30 19:43:15 --> URI Class Initialized
INFO - 2018-03-30 19:43:15 --> Router Class Initialized
INFO - 2018-03-30 19:43:15 --> Output Class Initialized
INFO - 2018-03-30 19:43:15 --> Security Class Initialized
DEBUG - 2018-03-30 19:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:43:15 --> Input Class Initialized
INFO - 2018-03-30 19:43:15 --> Language Class Initialized
INFO - 2018-03-30 19:43:15 --> Loader Class Initialized
INFO - 2018-03-30 19:43:15 --> Helper loaded: url_helper
INFO - 2018-03-30 19:43:15 --> Helper loaded: form_helper
INFO - 2018-03-30 19:43:15 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:43:15 --> Controller Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Model Class Initialized
INFO - 2018-03-30 19:43:15 --> Helper loaded: date_helper
INFO - 2018-03-30 19:43:15 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:43:17 --> Config Class Initialized
INFO - 2018-03-30 19:43:17 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:43:17 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:43:17 --> Utf8 Class Initialized
INFO - 2018-03-30 19:43:17 --> URI Class Initialized
INFO - 2018-03-30 19:43:17 --> Router Class Initialized
INFO - 2018-03-30 19:43:17 --> Output Class Initialized
INFO - 2018-03-30 19:43:17 --> Security Class Initialized
DEBUG - 2018-03-30 19:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:43:17 --> Input Class Initialized
INFO - 2018-03-30 19:43:17 --> Language Class Initialized
INFO - 2018-03-30 19:43:17 --> Loader Class Initialized
INFO - 2018-03-30 19:43:17 --> Helper loaded: url_helper
INFO - 2018-03-30 19:43:17 --> Helper loaded: form_helper
INFO - 2018-03-30 19:43:17 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:43:17 --> Controller Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Model Class Initialized
INFO - 2018-03-30 19:43:17 --> Helper loaded: date_helper
INFO - 2018-03-30 19:43:17 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:43:22 --> Config Class Initialized
INFO - 2018-03-30 19:43:22 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:43:22 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:43:22 --> Utf8 Class Initialized
INFO - 2018-03-30 19:43:22 --> URI Class Initialized
INFO - 2018-03-30 19:43:22 --> Router Class Initialized
INFO - 2018-03-30 19:43:22 --> Output Class Initialized
INFO - 2018-03-30 19:43:22 --> Security Class Initialized
DEBUG - 2018-03-30 19:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:43:22 --> Input Class Initialized
INFO - 2018-03-30 19:43:22 --> Language Class Initialized
INFO - 2018-03-30 19:43:22 --> Loader Class Initialized
INFO - 2018-03-30 19:43:22 --> Helper loaded: url_helper
INFO - 2018-03-30 19:43:22 --> Helper loaded: form_helper
INFO - 2018-03-30 19:43:22 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:43:22 --> Controller Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Model Class Initialized
INFO - 2018-03-30 19:43:22 --> Helper loaded: date_helper
INFO - 2018-03-30 19:43:22 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:43:24 --> Config Class Initialized
INFO - 2018-03-30 19:43:24 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:43:24 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:43:24 --> Utf8 Class Initialized
INFO - 2018-03-30 19:43:24 --> URI Class Initialized
INFO - 2018-03-30 19:43:24 --> Router Class Initialized
INFO - 2018-03-30 19:43:24 --> Output Class Initialized
INFO - 2018-03-30 19:43:24 --> Security Class Initialized
DEBUG - 2018-03-30 19:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:43:24 --> Input Class Initialized
INFO - 2018-03-30 19:43:24 --> Language Class Initialized
INFO - 2018-03-30 19:43:24 --> Loader Class Initialized
INFO - 2018-03-30 19:43:24 --> Helper loaded: url_helper
INFO - 2018-03-30 19:43:24 --> Helper loaded: form_helper
INFO - 2018-03-30 19:43:24 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:43:24 --> Controller Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Model Class Initialized
INFO - 2018-03-30 19:43:24 --> Helper loaded: date_helper
INFO - 2018-03-30 19:43:24 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 19:44:11 --> Config Class Initialized
INFO - 2018-03-30 19:44:11 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:44:11 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:44:11 --> Utf8 Class Initialized
INFO - 2018-03-30 19:44:11 --> URI Class Initialized
INFO - 2018-03-30 19:44:11 --> Router Class Initialized
INFO - 2018-03-30 19:44:11 --> Output Class Initialized
INFO - 2018-03-30 19:44:11 --> Security Class Initialized
DEBUG - 2018-03-30 19:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:44:11 --> Input Class Initialized
INFO - 2018-03-30 19:44:11 --> Language Class Initialized
INFO - 2018-03-30 19:44:11 --> Loader Class Initialized
INFO - 2018-03-30 19:44:11 --> Helper loaded: url_helper
INFO - 2018-03-30 19:44:11 --> Helper loaded: form_helper
INFO - 2018-03-30 19:44:11 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:44:11 --> Controller Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Model Class Initialized
INFO - 2018-03-30 19:44:11 --> Helper loaded: date_helper
INFO - 2018-03-30 19:44:11 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 20:49:07 --> Config Class Initialized
INFO - 2018-03-30 20:49:07 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:49:07 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:49:07 --> Utf8 Class Initialized
INFO - 2018-03-30 20:49:07 --> URI Class Initialized
INFO - 2018-03-30 20:49:07 --> Router Class Initialized
INFO - 2018-03-30 20:49:07 --> Output Class Initialized
INFO - 2018-03-30 20:49:07 --> Security Class Initialized
DEBUG - 2018-03-30 20:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:49:07 --> Input Class Initialized
INFO - 2018-03-30 20:49:07 --> Language Class Initialized
INFO - 2018-03-30 20:49:07 --> Loader Class Initialized
INFO - 2018-03-30 20:49:07 --> Helper loaded: url_helper
INFO - 2018-03-30 20:49:07 --> Helper loaded: form_helper
INFO - 2018-03-30 20:49:07 --> Database Driver Class Initialized
DEBUG - 2018-03-30 20:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 20:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:49:07 --> Controller Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Model Class Initialized
INFO - 2018-03-30 20:49:07 --> Helper loaded: date_helper
INFO - 2018-03-30 20:49:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 20:50:09 --> Config Class Initialized
INFO - 2018-03-30 20:50:09 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:50:09 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:50:09 --> Utf8 Class Initialized
INFO - 2018-03-30 20:50:09 --> URI Class Initialized
INFO - 2018-03-30 20:50:09 --> Router Class Initialized
INFO - 2018-03-30 20:50:09 --> Output Class Initialized
INFO - 2018-03-30 20:50:09 --> Security Class Initialized
DEBUG - 2018-03-30 20:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:50:09 --> Input Class Initialized
INFO - 2018-03-30 20:50:09 --> Language Class Initialized
INFO - 2018-03-30 20:50:09 --> Loader Class Initialized
INFO - 2018-03-30 20:50:09 --> Helper loaded: url_helper
INFO - 2018-03-30 20:50:09 --> Helper loaded: form_helper
INFO - 2018-03-30 20:50:09 --> Database Driver Class Initialized
DEBUG - 2018-03-30 20:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 20:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:50:09 --> Controller Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Model Class Initialized
INFO - 2018-03-30 20:50:09 --> Helper loaded: date_helper
INFO - 2018-03-30 20:50:09 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 20:50:20 --> Config Class Initialized
INFO - 2018-03-30 20:50:20 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:50:20 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:50:20 --> Utf8 Class Initialized
INFO - 2018-03-30 20:50:20 --> URI Class Initialized
INFO - 2018-03-30 20:50:20 --> Router Class Initialized
INFO - 2018-03-30 20:50:20 --> Output Class Initialized
INFO - 2018-03-30 20:50:20 --> Security Class Initialized
DEBUG - 2018-03-30 20:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:50:20 --> Input Class Initialized
INFO - 2018-03-30 20:50:20 --> Language Class Initialized
INFO - 2018-03-30 20:50:20 --> Loader Class Initialized
INFO - 2018-03-30 20:50:20 --> Helper loaded: url_helper
INFO - 2018-03-30 20:50:20 --> Helper loaded: form_helper
INFO - 2018-03-30 20:50:20 --> Database Driver Class Initialized
DEBUG - 2018-03-30 20:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 20:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:50:20 --> Controller Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Model Class Initialized
INFO - 2018-03-30 20:50:20 --> Helper loaded: date_helper
INFO - 2018-03-30 20:50:20 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 20:50:51 --> Config Class Initialized
INFO - 2018-03-30 20:50:51 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:50:51 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:50:51 --> Utf8 Class Initialized
INFO - 2018-03-30 20:50:51 --> URI Class Initialized
INFO - 2018-03-30 20:50:51 --> Router Class Initialized
INFO - 2018-03-30 20:50:51 --> Output Class Initialized
INFO - 2018-03-30 20:50:51 --> Security Class Initialized
DEBUG - 2018-03-30 20:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:50:51 --> Input Class Initialized
INFO - 2018-03-30 20:50:51 --> Language Class Initialized
INFO - 2018-03-30 20:50:51 --> Loader Class Initialized
INFO - 2018-03-30 20:50:51 --> Helper loaded: url_helper
INFO - 2018-03-30 20:50:51 --> Helper loaded: form_helper
INFO - 2018-03-30 20:50:51 --> Database Driver Class Initialized
DEBUG - 2018-03-30 20:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 20:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:50:51 --> Controller Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Model Class Initialized
INFO - 2018-03-30 20:50:51 --> Helper loaded: date_helper
INFO - 2018-03-30 20:50:51 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 20:53:19 --> Config Class Initialized
INFO - 2018-03-30 20:53:19 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:53:19 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:53:19 --> Utf8 Class Initialized
INFO - 2018-03-30 20:53:19 --> URI Class Initialized
INFO - 2018-03-30 20:53:19 --> Router Class Initialized
INFO - 2018-03-30 20:53:19 --> Output Class Initialized
INFO - 2018-03-30 20:53:19 --> Security Class Initialized
DEBUG - 2018-03-30 20:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:53:19 --> Input Class Initialized
INFO - 2018-03-30 20:53:19 --> Language Class Initialized
INFO - 2018-03-30 20:53:19 --> Loader Class Initialized
INFO - 2018-03-30 20:53:19 --> Helper loaded: url_helper
INFO - 2018-03-30 20:53:19 --> Helper loaded: form_helper
INFO - 2018-03-30 20:53:19 --> Database Driver Class Initialized
DEBUG - 2018-03-30 20:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 20:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:53:19 --> Controller Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Model Class Initialized
INFO - 2018-03-30 20:53:19 --> Helper loaded: date_helper
INFO - 2018-03-30 20:53:19 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 20:53:23 --> Config Class Initialized
INFO - 2018-03-30 20:53:23 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:53:23 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:53:23 --> Utf8 Class Initialized
INFO - 2018-03-30 20:53:23 --> URI Class Initialized
INFO - 2018-03-30 20:53:23 --> Router Class Initialized
INFO - 2018-03-30 20:53:23 --> Output Class Initialized
INFO - 2018-03-30 20:53:23 --> Security Class Initialized
DEBUG - 2018-03-30 20:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:53:23 --> Input Class Initialized
INFO - 2018-03-30 20:53:23 --> Language Class Initialized
INFO - 2018-03-30 20:53:23 --> Loader Class Initialized
INFO - 2018-03-30 20:53:23 --> Helper loaded: url_helper
INFO - 2018-03-30 20:53:23 --> Helper loaded: form_helper
INFO - 2018-03-30 20:53:23 --> Database Driver Class Initialized
DEBUG - 2018-03-30 20:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 20:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:53:23 --> Controller Class Initialized
INFO - 2018-03-30 20:53:23 --> Model Class Initialized
INFO - 2018-03-30 20:53:23 --> Model Class Initialized
INFO - 2018-03-30 20:53:23 --> Model Class Initialized
INFO - 2018-03-30 20:53:23 --> Model Class Initialized
INFO - 2018-03-30 20:53:23 --> Model Class Initialized
INFO - 2018-03-30 20:53:23 --> Model Class Initialized
INFO - 2018-03-30 20:53:23 --> Model Class Initialized
INFO - 2018-03-30 20:53:23 --> Model Class Initialized
INFO - 2018-03-30 20:53:23 --> Model Class Initialized
INFO - 2018-03-30 20:53:23 --> Model Class Initialized
INFO - 2018-03-30 20:53:23 --> Helper loaded: date_helper
INFO - 2018-03-30 20:53:23 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 20:54:00 --> Config Class Initialized
INFO - 2018-03-30 20:54:00 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:54:00 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:54:00 --> Utf8 Class Initialized
INFO - 2018-03-30 20:54:00 --> URI Class Initialized
INFO - 2018-03-30 20:54:00 --> Router Class Initialized
INFO - 2018-03-30 20:54:00 --> Output Class Initialized
INFO - 2018-03-30 20:54:00 --> Security Class Initialized
DEBUG - 2018-03-30 20:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:54:00 --> Input Class Initialized
INFO - 2018-03-30 20:54:00 --> Language Class Initialized
INFO - 2018-03-30 20:54:00 --> Loader Class Initialized
INFO - 2018-03-30 20:54:00 --> Helper loaded: url_helper
INFO - 2018-03-30 20:54:00 --> Helper loaded: form_helper
INFO - 2018-03-30 20:54:00 --> Database Driver Class Initialized
DEBUG - 2018-03-30 20:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 20:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:54:00 --> Controller Class Initialized
INFO - 2018-03-30 20:54:00 --> Model Class Initialized
INFO - 2018-03-30 20:54:00 --> Model Class Initialized
INFO - 2018-03-30 20:54:00 --> Model Class Initialized
INFO - 2018-03-30 20:54:00 --> Model Class Initialized
INFO - 2018-03-30 20:54:00 --> Model Class Initialized
INFO - 2018-03-30 20:54:00 --> Model Class Initialized
INFO - 2018-03-30 20:54:00 --> Model Class Initialized
INFO - 2018-03-30 20:54:00 --> Model Class Initialized
INFO - 2018-03-30 20:54:00 --> Model Class Initialized
INFO - 2018-03-30 20:54:00 --> Model Class Initialized
INFO - 2018-03-30 20:54:00 --> Helper loaded: date_helper
INFO - 2018-03-30 20:54:00 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 20:54:05 --> Config Class Initialized
INFO - 2018-03-30 20:54:05 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:54:05 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:54:05 --> Utf8 Class Initialized
INFO - 2018-03-30 20:54:05 --> URI Class Initialized
INFO - 2018-03-30 20:54:05 --> Router Class Initialized
INFO - 2018-03-30 20:54:05 --> Output Class Initialized
INFO - 2018-03-30 20:54:05 --> Security Class Initialized
DEBUG - 2018-03-30 20:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:54:05 --> Input Class Initialized
INFO - 2018-03-30 20:54:05 --> Language Class Initialized
INFO - 2018-03-30 20:54:05 --> Loader Class Initialized
INFO - 2018-03-30 20:54:05 --> Helper loaded: url_helper
INFO - 2018-03-30 20:54:05 --> Helper loaded: form_helper
INFO - 2018-03-30 20:54:05 --> Database Driver Class Initialized
DEBUG - 2018-03-30 20:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 20:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:54:05 --> Controller Class Initialized
INFO - 2018-03-30 20:54:05 --> Model Class Initialized
INFO - 2018-03-30 20:54:05 --> Model Class Initialized
INFO - 2018-03-30 20:54:05 --> Model Class Initialized
INFO - 2018-03-30 20:54:05 --> Model Class Initialized
INFO - 2018-03-30 20:54:05 --> Model Class Initialized
INFO - 2018-03-30 20:54:05 --> Model Class Initialized
INFO - 2018-03-30 20:54:05 --> Model Class Initialized
INFO - 2018-03-30 20:54:05 --> Model Class Initialized
INFO - 2018-03-30 20:54:05 --> Model Class Initialized
INFO - 2018-03-30 20:54:05 --> Model Class Initialized
INFO - 2018-03-30 20:54:05 --> Helper loaded: date_helper
INFO - 2018-03-30 20:54:05 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 20:57:45 --> Config Class Initialized
INFO - 2018-03-30 20:57:45 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:57:45 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:57:45 --> Utf8 Class Initialized
INFO - 2018-03-30 20:57:45 --> URI Class Initialized
INFO - 2018-03-30 20:57:46 --> Router Class Initialized
INFO - 2018-03-30 20:57:46 --> Output Class Initialized
INFO - 2018-03-30 20:57:46 --> Security Class Initialized
DEBUG - 2018-03-30 20:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:57:46 --> Input Class Initialized
INFO - 2018-03-30 20:57:46 --> Language Class Initialized
INFO - 2018-03-30 20:57:46 --> Loader Class Initialized
INFO - 2018-03-30 20:57:46 --> Helper loaded: url_helper
INFO - 2018-03-30 20:57:46 --> Helper loaded: form_helper
INFO - 2018-03-30 20:57:46 --> Database Driver Class Initialized
DEBUG - 2018-03-30 20:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 20:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:57:46 --> Controller Class Initialized
INFO - 2018-03-30 20:57:46 --> Model Class Initialized
INFO - 2018-03-30 20:57:46 --> Model Class Initialized
INFO - 2018-03-30 20:57:46 --> Model Class Initialized
INFO - 2018-03-30 20:57:46 --> Model Class Initialized
INFO - 2018-03-30 20:57:46 --> Model Class Initialized
INFO - 2018-03-30 20:57:46 --> Model Class Initialized
INFO - 2018-03-30 20:57:46 --> Model Class Initialized
INFO - 2018-03-30 20:57:46 --> Model Class Initialized
INFO - 2018-03-30 20:57:46 --> Model Class Initialized
INFO - 2018-03-30 20:57:46 --> Model Class Initialized
INFO - 2018-03-30 20:57:46 --> Helper loaded: date_helper
INFO - 2018-03-30 20:57:46 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 20:57:53 --> Config Class Initialized
INFO - 2018-03-30 20:57:53 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:57:53 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:57:53 --> Utf8 Class Initialized
INFO - 2018-03-30 20:57:53 --> URI Class Initialized
INFO - 2018-03-30 20:57:53 --> Router Class Initialized
INFO - 2018-03-30 20:57:53 --> Output Class Initialized
INFO - 2018-03-30 20:57:53 --> Security Class Initialized
DEBUG - 2018-03-30 20:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:57:53 --> Input Class Initialized
INFO - 2018-03-30 20:57:53 --> Language Class Initialized
INFO - 2018-03-30 20:57:53 --> Loader Class Initialized
INFO - 2018-03-30 20:57:53 --> Helper loaded: url_helper
INFO - 2018-03-30 20:57:53 --> Helper loaded: form_helper
INFO - 2018-03-30 20:57:53 --> Database Driver Class Initialized
DEBUG - 2018-03-30 20:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 20:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:57:53 --> Controller Class Initialized
INFO - 2018-03-30 20:57:53 --> Model Class Initialized
INFO - 2018-03-30 20:57:53 --> Model Class Initialized
INFO - 2018-03-30 20:57:53 --> Model Class Initialized
INFO - 2018-03-30 20:57:53 --> Model Class Initialized
INFO - 2018-03-30 20:57:53 --> Model Class Initialized
INFO - 2018-03-30 20:57:53 --> Helper loaded: date_helper
INFO - 2018-03-30 20:57:53 --> Config Class Initialized
INFO - 2018-03-30 20:57:53 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:57:53 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:57:53 --> Utf8 Class Initialized
INFO - 2018-03-30 20:57:53 --> URI Class Initialized
INFO - 2018-03-30 20:57:53 --> Router Class Initialized
INFO - 2018-03-30 20:57:53 --> Output Class Initialized
INFO - 2018-03-30 20:57:53 --> Security Class Initialized
DEBUG - 2018-03-30 20:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:57:53 --> Input Class Initialized
INFO - 2018-03-30 20:57:53 --> Language Class Initialized
INFO - 2018-03-30 20:57:53 --> Loader Class Initialized
INFO - 2018-03-30 20:57:53 --> Helper loaded: url_helper
INFO - 2018-03-30 20:57:53 --> Helper loaded: form_helper
INFO - 2018-03-30 20:57:53 --> Database Driver Class Initialized
DEBUG - 2018-03-30 20:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 20:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:57:53 --> Controller Class Initialized
INFO - 2018-03-30 20:57:53 --> Model Class Initialized
INFO - 2018-03-30 20:57:53 --> Model Class Initialized
INFO - 2018-03-30 20:57:53 --> Model Class Initialized
INFO - 2018-03-30 20:57:53 --> Model Class Initialized
INFO - 2018-03-30 20:57:53 --> Model Class Initialized
INFO - 2018-03-30 20:57:53 --> Model Class Initialized
INFO - 2018-03-30 20:57:53 --> Model Class Initialized
INFO - 2018-03-30 20:57:53 --> Model Class Initialized
INFO - 2018-03-30 20:57:53 --> Model Class Initialized
INFO - 2018-03-30 20:57:53 --> Model Class Initialized
INFO - 2018-03-30 20:57:53 --> Helper loaded: date_helper
INFO - 2018-03-30 20:57:53 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 20:59:18 --> Config Class Initialized
INFO - 2018-03-30 20:59:18 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:59:18 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:59:18 --> Utf8 Class Initialized
INFO - 2018-03-30 20:59:18 --> URI Class Initialized
INFO - 2018-03-30 20:59:18 --> Router Class Initialized
INFO - 2018-03-30 20:59:18 --> Output Class Initialized
INFO - 2018-03-30 20:59:18 --> Security Class Initialized
DEBUG - 2018-03-30 20:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:59:18 --> Input Class Initialized
INFO - 2018-03-30 20:59:18 --> Language Class Initialized
INFO - 2018-03-30 20:59:18 --> Loader Class Initialized
INFO - 2018-03-30 20:59:18 --> Helper loaded: url_helper
INFO - 2018-03-30 20:59:18 --> Helper loaded: form_helper
INFO - 2018-03-30 20:59:18 --> Database Driver Class Initialized
DEBUG - 2018-03-30 20:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 20:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:59:18 --> Controller Class Initialized
INFO - 2018-03-30 20:59:18 --> Model Class Initialized
INFO - 2018-03-30 20:59:18 --> Model Class Initialized
INFO - 2018-03-30 20:59:18 --> Model Class Initialized
INFO - 2018-03-30 20:59:18 --> Model Class Initialized
INFO - 2018-03-30 20:59:18 --> Model Class Initialized
INFO - 2018-03-30 20:59:18 --> Model Class Initialized
INFO - 2018-03-30 20:59:18 --> Model Class Initialized
INFO - 2018-03-30 20:59:18 --> Model Class Initialized
INFO - 2018-03-30 20:59:18 --> Model Class Initialized
INFO - 2018-03-30 20:59:18 --> Model Class Initialized
INFO - 2018-03-30 20:59:18 --> Helper loaded: date_helper
INFO - 2018-03-30 20:59:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 20:59:30 --> Config Class Initialized
INFO - 2018-03-30 20:59:30 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:59:30 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:59:30 --> Utf8 Class Initialized
INFO - 2018-03-30 20:59:30 --> URI Class Initialized
INFO - 2018-03-30 20:59:30 --> Router Class Initialized
INFO - 2018-03-30 20:59:30 --> Output Class Initialized
INFO - 2018-03-30 20:59:30 --> Security Class Initialized
DEBUG - 2018-03-30 20:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:59:30 --> Input Class Initialized
INFO - 2018-03-30 20:59:30 --> Language Class Initialized
INFO - 2018-03-30 20:59:30 --> Loader Class Initialized
INFO - 2018-03-30 20:59:30 --> Helper loaded: url_helper
INFO - 2018-03-30 20:59:30 --> Helper loaded: form_helper
INFO - 2018-03-30 20:59:30 --> Database Driver Class Initialized
DEBUG - 2018-03-30 20:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 20:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:59:30 --> Controller Class Initialized
INFO - 2018-03-30 20:59:30 --> Model Class Initialized
INFO - 2018-03-30 20:59:30 --> Model Class Initialized
INFO - 2018-03-30 20:59:30 --> Model Class Initialized
INFO - 2018-03-30 20:59:30 --> Model Class Initialized
INFO - 2018-03-30 20:59:30 --> Model Class Initialized
INFO - 2018-03-30 20:59:30 --> Model Class Initialized
INFO - 2018-03-30 20:59:30 --> Model Class Initialized
INFO - 2018-03-30 20:59:30 --> Model Class Initialized
INFO - 2018-03-30 20:59:30 --> Model Class Initialized
INFO - 2018-03-30 20:59:30 --> Model Class Initialized
INFO - 2018-03-30 20:59:30 --> Helper loaded: date_helper
INFO - 2018-03-30 20:59:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:00:07 --> Config Class Initialized
INFO - 2018-03-30 21:00:07 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:00:07 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:00:07 --> Utf8 Class Initialized
INFO - 2018-03-30 21:00:07 --> URI Class Initialized
INFO - 2018-03-30 21:00:07 --> Router Class Initialized
INFO - 2018-03-30 21:00:07 --> Output Class Initialized
INFO - 2018-03-30 21:00:07 --> Security Class Initialized
DEBUG - 2018-03-30 21:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:00:07 --> Input Class Initialized
INFO - 2018-03-30 21:00:07 --> Language Class Initialized
INFO - 2018-03-30 21:00:07 --> Loader Class Initialized
INFO - 2018-03-30 21:00:07 --> Helper loaded: url_helper
INFO - 2018-03-30 21:00:07 --> Helper loaded: form_helper
INFO - 2018-03-30 21:00:07 --> Database Driver Class Initialized
DEBUG - 2018-03-30 21:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 21:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:00:07 --> Controller Class Initialized
INFO - 2018-03-30 21:00:07 --> Model Class Initialized
INFO - 2018-03-30 21:00:07 --> Model Class Initialized
INFO - 2018-03-30 21:00:07 --> Model Class Initialized
INFO - 2018-03-30 21:00:07 --> Model Class Initialized
INFO - 2018-03-30 21:00:07 --> Model Class Initialized
INFO - 2018-03-30 21:00:07 --> Model Class Initialized
INFO - 2018-03-30 21:00:07 --> Model Class Initialized
INFO - 2018-03-30 21:00:07 --> Model Class Initialized
INFO - 2018-03-30 21:00:07 --> Model Class Initialized
INFO - 2018-03-30 21:00:07 --> Model Class Initialized
INFO - 2018-03-30 21:00:07 --> Helper loaded: date_helper
INFO - 2018-03-30 21:00:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:00:38 --> Config Class Initialized
INFO - 2018-03-30 21:00:38 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:00:38 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:00:38 --> Utf8 Class Initialized
INFO - 2018-03-30 21:00:38 --> URI Class Initialized
INFO - 2018-03-30 21:00:38 --> Router Class Initialized
INFO - 2018-03-30 21:00:38 --> Output Class Initialized
INFO - 2018-03-30 21:00:38 --> Security Class Initialized
DEBUG - 2018-03-30 21:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:00:38 --> Input Class Initialized
INFO - 2018-03-30 21:00:38 --> Language Class Initialized
INFO - 2018-03-30 21:00:38 --> Loader Class Initialized
INFO - 2018-03-30 21:00:38 --> Helper loaded: url_helper
INFO - 2018-03-30 21:00:38 --> Helper loaded: form_helper
INFO - 2018-03-30 21:00:38 --> Database Driver Class Initialized
DEBUG - 2018-03-30 21:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 21:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:00:38 --> Controller Class Initialized
INFO - 2018-03-30 21:00:38 --> Model Class Initialized
INFO - 2018-03-30 21:00:38 --> Model Class Initialized
INFO - 2018-03-30 21:00:38 --> Model Class Initialized
INFO - 2018-03-30 21:00:38 --> Model Class Initialized
INFO - 2018-03-30 21:00:38 --> Model Class Initialized
INFO - 2018-03-30 21:00:38 --> Model Class Initialized
INFO - 2018-03-30 21:00:38 --> Model Class Initialized
INFO - 2018-03-30 21:00:38 --> Model Class Initialized
INFO - 2018-03-30 21:00:38 --> Model Class Initialized
INFO - 2018-03-30 21:00:38 --> Model Class Initialized
INFO - 2018-03-30 21:00:38 --> Helper loaded: date_helper
INFO - 2018-03-30 21:00:38 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:01:01 --> Config Class Initialized
INFO - 2018-03-30 21:01:01 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:01:01 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:01:01 --> Utf8 Class Initialized
INFO - 2018-03-30 21:01:01 --> URI Class Initialized
INFO - 2018-03-30 21:01:01 --> Router Class Initialized
INFO - 2018-03-30 21:01:01 --> Output Class Initialized
INFO - 2018-03-30 21:01:01 --> Security Class Initialized
DEBUG - 2018-03-30 21:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:01:01 --> Input Class Initialized
INFO - 2018-03-30 21:01:01 --> Language Class Initialized
INFO - 2018-03-30 21:01:01 --> Loader Class Initialized
INFO - 2018-03-30 21:01:01 --> Helper loaded: url_helper
INFO - 2018-03-30 21:01:01 --> Helper loaded: form_helper
INFO - 2018-03-30 21:01:01 --> Database Driver Class Initialized
DEBUG - 2018-03-30 21:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 21:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:01:01 --> Controller Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Model Class Initialized
INFO - 2018-03-30 21:01:01 --> Helper loaded: date_helper
INFO - 2018-03-30 21:01:01 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:01:18 --> Config Class Initialized
INFO - 2018-03-30 21:01:18 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:01:18 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:01:18 --> Utf8 Class Initialized
INFO - 2018-03-30 21:01:18 --> URI Class Initialized
INFO - 2018-03-30 21:01:18 --> Router Class Initialized
INFO - 2018-03-30 21:01:18 --> Output Class Initialized
INFO - 2018-03-30 21:01:18 --> Security Class Initialized
DEBUG - 2018-03-30 21:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:01:18 --> Input Class Initialized
INFO - 2018-03-30 21:01:18 --> Language Class Initialized
INFO - 2018-03-30 21:01:18 --> Loader Class Initialized
INFO - 2018-03-30 21:01:18 --> Helper loaded: url_helper
INFO - 2018-03-30 21:01:18 --> Helper loaded: form_helper
INFO - 2018-03-30 21:01:18 --> Database Driver Class Initialized
DEBUG - 2018-03-30 21:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 21:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:01:18 --> Controller Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Model Class Initialized
INFO - 2018-03-30 21:01:18 --> Helper loaded: date_helper
INFO - 2018-03-30 21:01:18 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:01:25 --> Config Class Initialized
INFO - 2018-03-30 21:01:25 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:01:26 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:01:26 --> Utf8 Class Initialized
INFO - 2018-03-30 21:01:26 --> URI Class Initialized
INFO - 2018-03-30 21:01:26 --> Router Class Initialized
INFO - 2018-03-30 21:01:26 --> Output Class Initialized
INFO - 2018-03-30 21:01:26 --> Security Class Initialized
DEBUG - 2018-03-30 21:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:01:26 --> Input Class Initialized
INFO - 2018-03-30 21:01:26 --> Language Class Initialized
INFO - 2018-03-30 21:01:26 --> Loader Class Initialized
INFO - 2018-03-30 21:01:26 --> Helper loaded: url_helper
INFO - 2018-03-30 21:01:26 --> Helper loaded: form_helper
INFO - 2018-03-30 21:01:26 --> Database Driver Class Initialized
DEBUG - 2018-03-30 21:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 21:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:01:26 --> Controller Class Initialized
INFO - 2018-03-30 21:01:26 --> Model Class Initialized
INFO - 2018-03-30 21:01:26 --> Model Class Initialized
INFO - 2018-03-30 21:01:26 --> Model Class Initialized
INFO - 2018-03-30 21:01:26 --> Model Class Initialized
INFO - 2018-03-30 21:01:26 --> Model Class Initialized
INFO - 2018-03-30 21:01:26 --> Helper loaded: date_helper
INFO - 2018-03-30 21:01:29 --> Config Class Initialized
INFO - 2018-03-30 21:01:29 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:01:29 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:01:29 --> Utf8 Class Initialized
INFO - 2018-03-30 21:01:29 --> URI Class Initialized
INFO - 2018-03-30 21:01:29 --> Router Class Initialized
INFO - 2018-03-30 21:01:29 --> Output Class Initialized
INFO - 2018-03-30 21:01:29 --> Security Class Initialized
DEBUG - 2018-03-30 21:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:01:29 --> Input Class Initialized
INFO - 2018-03-30 21:01:29 --> Language Class Initialized
INFO - 2018-03-30 21:01:29 --> Config Class Initialized
INFO - 2018-03-30 21:01:29 --> Hooks Class Initialized
INFO - 2018-03-30 21:01:29 --> Loader Class Initialized
INFO - 2018-03-30 21:01:29 --> Helper loaded: url_helper
DEBUG - 2018-03-30 21:01:29 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:01:29 --> Utf8 Class Initialized
INFO - 2018-03-30 21:01:29 --> Helper loaded: form_helper
INFO - 2018-03-30 21:01:29 --> URI Class Initialized
INFO - 2018-03-30 21:01:29 --> Router Class Initialized
INFO - 2018-03-30 21:01:29 --> Database Driver Class Initialized
INFO - 2018-03-30 21:01:29 --> Output Class Initialized
INFO - 2018-03-30 21:01:29 --> Security Class Initialized
DEBUG - 2018-03-30 21:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:01:29 --> Input Class Initialized
INFO - 2018-03-30 21:01:29 --> Language Class Initialized
INFO - 2018-03-30 21:01:29 --> Loader Class Initialized
INFO - 2018-03-30 21:01:30 --> Helper loaded: url_helper
DEBUG - 2018-03-30 21:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 21:01:30 --> Helper loaded: form_helper
INFO - 2018-03-30 21:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:01:30 --> Controller Class Initialized
INFO - 2018-03-30 21:01:30 --> Model Class Initialized
INFO - 2018-03-30 21:01:30 --> Model Class Initialized
INFO - 2018-03-30 21:01:30 --> Model Class Initialized
INFO - 2018-03-30 21:01:30 --> Database Driver Class Initialized
INFO - 2018-03-30 21:01:30 --> Model Class Initialized
INFO - 2018-03-30 21:01:30 --> Model Class Initialized
INFO - 2018-03-30 21:01:30 --> Helper loaded: date_helper
DEBUG - 2018-03-30 21:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 21:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:01:30 --> Controller Class Initialized
INFO - 2018-03-30 21:01:30 --> Model Class Initialized
INFO - 2018-03-30 21:01:30 --> Model Class Initialized
INFO - 2018-03-30 21:01:30 --> Model Class Initialized
INFO - 2018-03-30 21:01:30 --> Model Class Initialized
INFO - 2018-03-30 21:01:30 --> Model Class Initialized
INFO - 2018-03-30 21:01:30 --> Model Class Initialized
INFO - 2018-03-30 21:01:30 --> Model Class Initialized
INFO - 2018-03-30 21:01:30 --> Model Class Initialized
INFO - 2018-03-30 21:01:30 --> Model Class Initialized
INFO - 2018-03-30 21:01:30 --> Model Class Initialized
INFO - 2018-03-30 21:01:30 --> Helper loaded: date_helper
INFO - 2018-03-30 21:01:30 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:04:00 --> Config Class Initialized
INFO - 2018-03-30 21:04:00 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:04:00 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:04:00 --> Utf8 Class Initialized
INFO - 2018-03-30 21:04:00 --> URI Class Initialized
INFO - 2018-03-30 21:04:00 --> Router Class Initialized
INFO - 2018-03-30 21:04:00 --> Output Class Initialized
INFO - 2018-03-30 21:04:00 --> Security Class Initialized
DEBUG - 2018-03-30 21:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:04:00 --> Input Class Initialized
INFO - 2018-03-30 21:04:00 --> Language Class Initialized
INFO - 2018-03-30 21:04:00 --> Loader Class Initialized
INFO - 2018-03-30 21:04:00 --> Helper loaded: url_helper
INFO - 2018-03-30 21:04:01 --> Helper loaded: form_helper
INFO - 2018-03-30 21:04:01 --> Database Driver Class Initialized
DEBUG - 2018-03-30 21:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 21:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:04:01 --> Controller Class Initialized
INFO - 2018-03-30 21:04:01 --> Model Class Initialized
INFO - 2018-03-30 21:04:01 --> Model Class Initialized
INFO - 2018-03-30 21:04:01 --> Helper loaded: date_helper
INFO - 2018-03-30 21:04:07 --> Config Class Initialized
INFO - 2018-03-30 21:04:07 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:04:07 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:04:07 --> Config Class Initialized
INFO - 2018-03-30 21:04:07 --> Utf8 Class Initialized
INFO - 2018-03-30 21:04:07 --> Hooks Class Initialized
INFO - 2018-03-30 21:04:07 --> URI Class Initialized
INFO - 2018-03-30 21:04:07 --> Router Class Initialized
DEBUG - 2018-03-30 21:04:07 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:04:07 --> Utf8 Class Initialized
INFO - 2018-03-30 21:04:07 --> Output Class Initialized
INFO - 2018-03-30 21:04:07 --> URI Class Initialized
INFO - 2018-03-30 21:04:07 --> Security Class Initialized
INFO - 2018-03-30 21:04:07 --> Router Class Initialized
DEBUG - 2018-03-30 21:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:04:07 --> Input Class Initialized
INFO - 2018-03-30 21:04:07 --> Language Class Initialized
INFO - 2018-03-30 21:04:07 --> Output Class Initialized
INFO - 2018-03-30 21:04:07 --> Security Class Initialized
INFO - 2018-03-30 21:04:07 --> Loader Class Initialized
DEBUG - 2018-03-30 21:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:04:07 --> Input Class Initialized
INFO - 2018-03-30 21:04:07 --> Helper loaded: url_helper
INFO - 2018-03-30 21:04:07 --> Language Class Initialized
INFO - 2018-03-30 21:04:07 --> Helper loaded: form_helper
INFO - 2018-03-30 21:04:07 --> Loader Class Initialized
INFO - 2018-03-30 21:04:07 --> Helper loaded: url_helper
INFO - 2018-03-30 21:04:07 --> Database Driver Class Initialized
INFO - 2018-03-30 21:04:07 --> Helper loaded: form_helper
DEBUG - 2018-03-30 21:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 21:04:07 --> Database Driver Class Initialized
INFO - 2018-03-30 21:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:04:07 --> Controller Class Initialized
INFO - 2018-03-30 21:04:07 --> Model Class Initialized
INFO - 2018-03-30 21:04:07 --> Model Class Initialized
DEBUG - 2018-03-30 21:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 21:04:07 --> Model Class Initialized
INFO - 2018-03-30 21:04:07 --> Model Class Initialized
INFO - 2018-03-30 21:04:07 --> Model Class Initialized
INFO - 2018-03-30 21:04:07 --> Helper loaded: date_helper
INFO - 2018-03-30 21:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:04:07 --> Controller Class Initialized
INFO - 2018-03-30 21:04:07 --> Model Class Initialized
INFO - 2018-03-30 21:04:07 --> Model Class Initialized
INFO - 2018-03-30 21:04:07 --> Model Class Initialized
INFO - 2018-03-30 21:04:07 --> Model Class Initialized
INFO - 2018-03-30 21:04:07 --> Model Class Initialized
INFO - 2018-03-30 21:04:07 --> Model Class Initialized
INFO - 2018-03-30 21:04:07 --> Model Class Initialized
INFO - 2018-03-30 21:04:07 --> Model Class Initialized
INFO - 2018-03-30 21:04:07 --> Model Class Initialized
INFO - 2018-03-30 21:04:07 --> Model Class Initialized
INFO - 2018-03-30 21:04:07 --> Helper loaded: date_helper
INFO - 2018-03-30 21:04:07 --> Helper loaded: tanggal_helper
INFO - 2018-03-30 21:04:14 --> Config Class Initialized
INFO - 2018-03-30 21:04:14 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:04:14 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:04:14 --> Utf8 Class Initialized
INFO - 2018-03-30 21:04:14 --> URI Class Initialized
INFO - 2018-03-30 21:04:14 --> Router Class Initialized
INFO - 2018-03-30 21:04:14 --> Output Class Initialized
INFO - 2018-03-30 21:04:14 --> Security Class Initialized
DEBUG - 2018-03-30 21:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:04:14 --> Input Class Initialized
INFO - 2018-03-30 21:04:14 --> Language Class Initialized
INFO - 2018-03-30 21:04:14 --> Loader Class Initialized
INFO - 2018-03-30 21:04:14 --> Helper loaded: url_helper
INFO - 2018-03-30 21:04:14 --> Helper loaded: form_helper
INFO - 2018-03-30 21:04:14 --> Database Driver Class Initialized
DEBUG - 2018-03-30 21:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 21:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:04:14 --> Controller Class Initialized
INFO - 2018-03-30 21:04:14 --> Model Class Initialized
INFO - 2018-03-30 21:04:14 --> Model Class Initialized
INFO - 2018-03-30 21:04:14 --> Model Class Initialized
INFO - 2018-03-30 21:04:14 --> Model Class Initialized
INFO - 2018-03-30 21:04:14 --> Model Class Initialized
INFO - 2018-03-30 21:04:14 --> Model Class Initialized
INFO - 2018-03-30 21:04:14 --> Model Class Initialized
INFO - 2018-03-30 21:04:14 --> Model Class Initialized
INFO - 2018-03-30 21:04:14 --> Model Class Initialized
INFO - 2018-03-30 21:04:14 --> Model Class Initialized
INFO - 2018-03-30 21:04:14 --> Model Class Initialized
INFO - 2018-03-30 21:04:14 --> Model Class Initialized
INFO - 2018-03-30 21:04:14 --> Model Class Initialized
INFO - 2018-03-30 21:04:14 --> Model Class Initialized
INFO - 2018-03-30 21:04:14 --> Helper loaded: date_helper
INFO - 2018-03-30 21:04:14 --> Helper loaded: tanggal_helper
