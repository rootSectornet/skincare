<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-31 00:18:41 --> Model Class Initialized
INFO - 2018-03-31 00:18:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 00:18:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 00:18:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-31 00:18:41 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 00:18:41 --> Final output sent to browser
DEBUG - 2018-03-31 00:18:41 --> Total execution time: 0.5688
INFO - 2018-03-31 00:18:50 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/list.php
INFO - 2018-03-31 00:18:50 --> Final output sent to browser
DEBUG - 2018-03-31 00:18:50 --> Total execution time: 0.1566
INFO - 2018-03-31 00:18:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/print.php
INFO - 2018-03-31 00:18:51 --> Final output sent to browser
DEBUG - 2018-03-31 00:18:51 --> Total execution time: 0.1105
INFO - 2018-03-31 00:33:04 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/penerimaan/print.php
INFO - 2018-03-31 00:33:04 --> Final output sent to browser
DEBUG - 2018-03-31 00:33:04 --> Total execution time: 0.1591
INFO - 2018-03-31 00:33:10 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Auth/Login.php
INFO - 2018-03-31 00:33:10 --> Final output sent to browser
DEBUG - 2018-03-31 00:33:10 --> Total execution time: 0.1286
INFO - 2018-03-31 00:33:14 --> Model Class Initialized
INFO - 2018-03-31 00:33:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 00:33:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 00:33:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-31 00:33:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 00:33:14 --> Final output sent to browser
DEBUG - 2018-03-31 00:33:14 --> Total execution time: 0.5169
INFO - 2018-03-31 00:33:19 --> Model Class Initialized
INFO - 2018-03-31 00:33:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 00:33:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 00:33:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-31 00:33:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 00:33:19 --> Final output sent to browser
DEBUG - 2018-03-31 00:33:19 --> Total execution time: 0.7164
INFO - 2018-03-31 00:34:46 --> Model Class Initialized
INFO - 2018-03-31 00:34:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 00:34:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 00:34:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/create.php
INFO - 2018-03-31 00:34:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 00:34:46 --> Final output sent to browser
DEBUG - 2018-03-31 00:34:46 --> Total execution time: 0.1581
INFO - 2018-03-31 00:34:50 --> Final output sent to browser
DEBUG - 2018-03-31 00:34:50 --> Total execution time: 0.0871
INFO - 2018-03-31 00:34:51 --> Final output sent to browser
DEBUG - 2018-03-31 00:34:51 --> Total execution time: 0.0956
INFO - 2018-03-31 00:35:08 --> Final output sent to browser
DEBUG - 2018-03-31 00:35:08 --> Total execution time: 0.0871
INFO - 2018-03-31 00:35:09 --> Final output sent to browser
DEBUG - 2018-03-31 00:35:09 --> Total execution time: 0.0765
INFO - 2018-03-31 00:35:45 --> Model Class Initialized
INFO - 2018-03-31 00:35:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 00:35:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 00:35:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/create.php
INFO - 2018-03-31 00:35:45 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 00:35:45 --> Final output sent to browser
DEBUG - 2018-03-31 00:35:45 --> Total execution time: 0.1053
INFO - 2018-03-31 00:35:48 --> Final output sent to browser
DEBUG - 2018-03-31 00:35:48 --> Total execution time: 0.1065
INFO - 2018-03-31 00:36:25 --> Final output sent to browser
DEBUG - 2018-03-31 00:36:25 --> Total execution time: 0.1002
INFO - 2018-03-31 00:36:34 --> Final output sent to browser
DEBUG - 2018-03-31 00:36:34 --> Total execution time: 0.0907
INFO - 2018-03-31 00:39:43 --> Final output sent to browser
DEBUG - 2018-03-31 00:39:43 --> Total execution time: 44.6363
INFO - 2018-03-31 00:39:49 --> Model Class Initialized
INFO - 2018-03-31 00:39:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 00:39:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 00:39:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-31 00:39:49 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 00:39:50 --> Final output sent to browser
DEBUG - 2018-03-31 00:39:50 --> Total execution time: 0.9308
INFO - 2018-03-31 00:40:21 --> Model Class Initialized
INFO - 2018-03-31 00:40:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 00:40:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 00:40:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-31 00:40:21 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 00:40:21 --> Final output sent to browser
DEBUG - 2018-03-31 00:40:21 --> Total execution time: 0.1246
INFO - 2018-03-31 00:43:16 --> Model Class Initialized
INFO - 2018-03-31 00:43:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 00:43:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 00:43:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-31 00:43:16 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 00:43:16 --> Final output sent to browser
DEBUG - 2018-03-31 00:43:16 --> Total execution time: 0.1050
INFO - 2018-03-31 00:43:17 --> Model Class Initialized
INFO - 2018-03-31 00:43:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 00:43:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 00:43:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-31 00:43:17 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 00:43:17 --> Final output sent to browser
DEBUG - 2018-03-31 00:43:17 --> Total execution time: 0.1013
INFO - 2018-03-31 00:43:22 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/list.php
INFO - 2018-03-31 00:43:22 --> Final output sent to browser
DEBUG - 2018-03-31 00:43:22 --> Total execution time: 0.1938
INFO - 2018-03-31 00:43:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/print.php
INFO - 2018-03-31 00:43:24 --> Final output sent to browser
DEBUG - 2018-03-31 00:43:24 --> Total execution time: 0.1239
INFO - 2018-03-31 00:44:11 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/print.php
INFO - 2018-03-31 00:44:11 --> Final output sent to browser
DEBUG - 2018-03-31 00:44:11 --> Total execution time: 0.1098
INFO - 2018-03-31 01:49:07 --> Model Class Initialized
INFO - 2018-03-31 01:49:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 01:49:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 01:49:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-31 01:49:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 01:49:07 --> Final output sent to browser
DEBUG - 2018-03-31 01:49:07 --> Total execution time: 0.7617
INFO - 2018-03-31 01:50:09 --> Model Class Initialized
INFO - 2018-03-31 01:50:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 01:50:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 01:50:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-31 01:50:09 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 01:50:09 --> Final output sent to browser
DEBUG - 2018-03-31 01:50:09 --> Total execution time: 0.1163
INFO - 2018-03-31 01:50:20 --> Model Class Initialized
INFO - 2018-03-31 01:50:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 01:50:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 01:50:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-31 01:50:20 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 01:50:20 --> Final output sent to browser
DEBUG - 2018-03-31 01:50:20 --> Total execution time: 0.1212
INFO - 2018-03-31 01:50:51 --> Model Class Initialized
INFO - 2018-03-31 01:50:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 01:50:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 01:50:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-31 01:50:51 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 01:50:51 --> Final output sent to browser
DEBUG - 2018-03-31 01:50:51 --> Total execution time: 0.1070
INFO - 2018-03-31 01:53:19 --> Model Class Initialized
INFO - 2018-03-31 01:53:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 01:53:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 01:53:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-31 01:53:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 01:53:19 --> Final output sent to browser
DEBUG - 2018-03-31 01:53:19 --> Total execution time: 0.1011
INFO - 2018-03-31 01:53:24 --> Model Class Initialized
INFO - 2018-03-31 01:53:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 01:53:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 01:53:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-31 01:53:24 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 01:53:24 --> Final output sent to browser
DEBUG - 2018-03-31 01:53:24 --> Total execution time: 1.1495
INFO - 2018-03-31 01:54:01 --> Model Class Initialized
INFO - 2018-03-31 01:54:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 01:54:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 01:54:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-31 01:54:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 01:54:01 --> Final output sent to browser
DEBUG - 2018-03-31 01:54:01 --> Total execution time: 0.5583
INFO - 2018-03-31 01:54:05 --> Model Class Initialized
INFO - 2018-03-31 01:54:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 01:54:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 01:54:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-31 01:54:05 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 01:54:05 --> Final output sent to browser
DEBUG - 2018-03-31 01:54:05 --> Total execution time: 0.5909
INFO - 2018-03-31 01:57:46 --> Model Class Initialized
INFO - 2018-03-31 01:57:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 01:57:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 01:57:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-31 01:57:46 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 01:57:46 --> Final output sent to browser
DEBUG - 2018-03-31 01:57:46 --> Total execution time: 0.5140
INFO - 2018-03-31 01:57:53 --> Final output sent to browser
DEBUG - 2018-03-31 01:57:53 --> Total execution time: 0.0570
INFO - 2018-03-31 01:57:54 --> Model Class Initialized
INFO - 2018-03-31 01:57:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 01:57:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 01:57:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-31 01:57:54 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 01:57:54 --> Final output sent to browser
DEBUG - 2018-03-31 01:57:54 --> Total execution time: 0.5706
INFO - 2018-03-31 01:59:19 --> Model Class Initialized
INFO - 2018-03-31 01:59:19 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 01:59:31 --> Model Class Initialized
INFO - 2018-03-31 01:59:31 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 02:00:07 --> Model Class Initialized
INFO - 2018-03-31 02:00:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 02:00:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 02:00:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-31 02:00:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 02:00:07 --> Final output sent to browser
DEBUG - 2018-03-31 02:00:07 --> Total execution time: 0.5326
INFO - 2018-03-31 02:00:38 --> Model Class Initialized
INFO - 2018-03-31 02:00:38 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 02:01:01 --> Model Class Initialized
INFO - 2018-03-31 02:01:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 02:01:18 --> Model Class Initialized
INFO - 2018-03-31 02:01:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 02:01:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 02:01:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Laporan/pengunjung/table.php
INFO - 2018-03-31 02:01:18 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 02:01:18 --> Final output sent to browser
DEBUG - 2018-03-31 02:01:18 --> Total execution time: 0.0943
INFO - 2018-03-31 02:01:26 --> Model Class Initialized
INFO - 2018-03-31 02:01:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 02:01:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 02:01:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\Dashboard.php
INFO - 2018-03-31 02:01:26 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 02:01:26 --> Final output sent to browser
DEBUG - 2018-03-31 02:01:26 --> Total execution time: 0.0775
INFO - 2018-03-31 02:01:30 --> Final output sent to browser
DEBUG - 2018-03-31 02:01:30 --> Total execution time: 0.0891
INFO - 2018-03-31 02:01:30 --> Model Class Initialized
INFO - 2018-03-31 02:01:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 02:01:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 02:01:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-31 02:01:30 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 02:01:30 --> Final output sent to browser
DEBUG - 2018-03-31 02:01:30 --> Total execution time: 0.5828
INFO - 2018-03-31 02:04:01 --> Model Class Initialized
INFO - 2018-03-31 02:04:01 --> Model Class Initialized
INFO - 2018-03-31 02:04:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 02:04:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 02:04:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\sdm/group/table.php
INFO - 2018-03-31 02:04:01 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 02:04:01 --> Final output sent to browser
DEBUG - 2018-03-31 02:04:01 --> Total execution time: 0.1882
INFO - 2018-03-31 02:04:07 --> Final output sent to browser
DEBUG - 2018-03-31 02:04:07 --> Total execution time: 0.0616
INFO - 2018-03-31 02:04:07 --> Model Class Initialized
INFO - 2018-03-31 02:04:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 02:04:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 02:04:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pasien/table.php
INFO - 2018-03-31 02:04:07 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 02:04:07 --> Final output sent to browser
DEBUG - 2018-03-31 02:04:07 --> Total execution time: 0.5622
INFO - 2018-03-31 02:04:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/header.php
INFO - 2018-03-31 02:04:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/menu.php
INFO - 2018-03-31 02:04:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\pendaftaran/table.php
INFO - 2018-03-31 02:04:14 --> File loaded: E:\xampp\htdocs\skin_care\application\views\template/footer.php
INFO - 2018-03-31 02:04:14 --> Final output sent to browser
DEBUG - 2018-03-31 02:04:14 --> Total execution time: 0.2144
