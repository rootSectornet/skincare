
  <?php foreach ($TagihanPenjualan as $key => $row): ?>
     <tr>
       <td><?= $row->id_tagihan;?></td>
       <td><?= $row->tgl_penjualan;?></td>
       <td><?= $row->cara_bayar;?></td>
       <td><?= $row->ppn;?></td>
       <td>Rp. <?= number_format($row->total,0,',','.');?></td>
       <td>
         <?= BtnView('Kasir/Tpenjualan/detailTagihan/'.$row->id_billing,'Pembayaran Detail');?>
       </td>
     </tr>
  <?php endforeach; ?>


  <script type="text/javascript">

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
});
  </script>
