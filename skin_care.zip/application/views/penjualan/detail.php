
<link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/selectize/css/selectize.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/selectize/css/selectize.bootstrap3.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/loader.css">
<script src="<?php echo base_url();?>assets/plugins/selectize/js/selectize.min.js"></script>
<style media="screen">
  .red{
    background-color: red !important;
    color: #ffffff !important;
  }
  .biru{
    background-color: #00f6ff !important;
  }
</style>
<?php $index = 0; ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">


    <div class="loader" id="loader-6">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
    </div>
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12 col-md-12">
          <div class="box">
            <div class="box-header">
            <?php echo $this->session->flashdata('pesan_eror'); ?>
              <h2>Data Penjualan Obat</h2>
              <p class="text-muted "> <i class="fa fa-info-circle fa-fw"></i> Dilakukan Oleh  : <?= $penjualan['head'][0]->nama_pegawai;?></p>

                <?= BtnPrint('gudang/penjualan/print/'.$penjualan['head'][0]->faktur_penjualan,'Print Faktur Penjualan');?>

            </div>
            <div class="box-body">
              <div class="form">
                <?= form_open();?>
                <?php foreach ($penjualan['head'] as $key => $head): ?>
                      <div class="box">
                        <div class="box-header">
                          <h3 class="box-title">Data Penjualan</h3>
                        </div>
                        <div class="box-body">
                          <div class="col-md-6">
                            <div class="form-group">
                              <label class="control-label">No Faktur : </label>
                              <input type="text" name="head[faktur_penjualan]" disabled class="form-control" required value="<?= $head->faktur_penjualan;?>">
                            </div>
                            <div class="form-group">
                              <label class="control-label">Tgl Penjualan : </label>
                              <input type="date" name="head[tgl_penjualan]" class="form-control" disabled value="<?= date('Y-m-d');?>">
                              <input type="hidden" name="head[tgl_penjualan]" class="form-control"  value="<?= date('Y-m-d');?>">
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label class="control-label">Cara Bayar : </label>
                              <input type="text" name="head[cara_bayar]" disabled class="form-control" required value="<?= $head->cara_bayar;?>">
                            </div>
                            <div class="form-group">
                                <label class="control-label">PPN : </label>
                                <div class="input-group">
                                      <span class="input-group-addon">
                                         <input type="checkbox" name="head[ppn]" disabled id="Idppn" value="1" <?= ($head->ppn == 1) ? 'checked' : '';?>>
                                      </span>
                                    <input type="text" name="ppn" id="ppn" disabled class="form-control"  value="Rp. <?= ($head->ppn == 1) ? number_format($head->total * 10 / 100,2,',','.') : number_format(0,2,',','.');?>">
                                </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label">Total : </label>
                              <input type="text" name="total" id="totalSemua" disabled class="form-control" value="Rp. <?= ($head->ppn == 1) ? number_format($head->total + $head->total * 10 / 100,2,',','.') : number_format($head->total,2,',','.');?>" id="total">
                            </div>
                          </div>
                        </div>
                      </div>
                  <?php endforeach; ?>
                  <div class="box">
                    <div class="box-header">
                      <h3 class="box-title">Detail Penjualan</h3>
                    </div>
                    <div class="box-body">
                            <table class="table table-bordered table-condensed table-striped trx-table" id="table-row"> <!-- << Ganti name table-id sesuai no trx >> -->
                                <thead>
                                    <tr>
                                        <th>Nama Obat</th>
                                        <th>QTY</th>
                                        <th>Harga</th>
                                        <th>Sub Total</th>
                                        <th>
                                            <button type="button" class="btn btn-primary btn-sm" disabled id="addRow"><span class="fa fa-plus"></span> Tambah</button>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody  id="table-body">
                                  <?php foreach ($penjualan['detail'] as $key => $detail): ?>
                                    <tr id="row<?= $detail->id_detail_penjualan;?>">
                                      <td style="width: 30%">
                                        <input type="text" class="form-control <?= $detail->flag_retur == 1 ? 'red' : '';?>" name="detail" id="id_product<?= $detail->id_detail_penjualan;?>" disabled value="<?= $detail->nama_product;?>"/>
                                      </td>
                                      <td><input type="number"  class="form-control <?= $detail->flag_retur == 1 ? 'red' : '';?>" value="<?= $detail->qty;?>" disabled name="detail[<?= $key;?>][qty]" id="qty<?= $detail->id_detail_penjualan;?>"/></td>
                                      <td>
                                        <input type="text" class="form-control <?= $detail->flag_retur == 1 ? 'red' : '';?>" name="detail[<?= $key;?>][harga]" value="<?= $detail->harga;?>" disabled  id="harga<?= $detail->id_detail_penjualan;?>"/></td>
                                      </td>
                                      <td><input type="text"   class="form-control <?= $detail->flag_retur == 1 ? 'red' : '';?>" name="ss" id="sub_totals<?= $detail->id_detail_penjualan;?>" disabled value="<?= $detail->sub_total;?>"/></td>
                                      <?php if ($detail->flag_retur != '1'): ?>
                                        <td><button id="Btnretur<?= $detail->id_detail_penjualan;?>" type="button" onclick="modal_retur(<?= $detail->id_detail_penjualan;?>, <?= $detail->id_product;?>)" class="btn btn-warning btn-flat btn-xs">Retur</button> </td>
                                      <?php endif; ?>
                                      <?php if ($detail->flag_retur == '1'): ?>
                                        <td><button type="button" name="button" disabled class="btn btn-info btn-xs">telah Diretur</button></td>
                                        <tr>
                                          <td><input type="text" class="form-control " name="detail" disabled value="<?= $detail->retur->nama_product;?>"/></td>
                                          <td><input type="number"  class="form-control " value="<?= $detail->retur->qty_retur;?>" disabled/></td>
                                          <td><input type="text" class="form-control " value="<?= $detail->retur->harga_jual;?>" disabled/></td>
                                          <td><input type="text"   class="form-control " disabled value="<?= $detail->retur->sub_total;?>"/></td>
                                        </tr>
                                      <?php endif; ?>
                                    </tr>
                                    <?php $index = $key; ?>
                                  <?php endforeach; ?>
                                </tbody>
                            </table>
                    </div>
                  </div>
                  <div class="form-group">
                    <?= BtnBack('gudang/penjualan');?>

                  </div>
                <?= form_close();?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- modal alert -->
  <div class="modal fade" id="modal-alert">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Information !</h4>
        </div>
        <div class="modal-body">

        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
<!-- end modal alert -->
<!-- modal retur -->
        <div class="modal fade" id="modal-retur">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Retur Obat</h4>
            </div>
            <div class="modal-body">
              <form class="form" method="post">
                <input type="hidden" name="id_detail" class="form-control" id="id_detail">
                <input type="hidden" name="id_product" class="form-control" id="id_product">
                <div class="form-group">
                  <label class="control-label">Nama Product : </label>
                  <select class="form-control" name="nama_product" id="selects-retur"></select>
                </div>
                <div class="form-group">
                  <label for="qty" class="control-label">QTY : </label>
                  <input type="number" name="qty_retur" onchange="hitungSubTotal()" class="form-control" id="qty_retur">
                </div>
                <div class="form-group">
                  <label for="harga_jual" class="control-label">Harga : </label>
                  <input type="text" name="harga_jual" class="form-control" id="harga_jual">
                  <input type="hidden" name="harga_beli" class="form-control" id="harga_beli">
                </div>
                <div class="form-group">
                  <label for="sub_total" class="control-label">Sub Total : </label>
                  <input type="text" name="sub_total" class="form-control" id="sub_total">
                </div>
                <div class="form-group">
                  <label for="keterangan" class="control-label">Keterangan : </label>
                  <textarea name="keterangan" rows="3" class="form-control" id="keterangan">-</textarea>
                </div>
                <div class="form-group">
                  <label for="kondisi" class="control-label">Kondisi : </label>
                  <select class="form-control" name="kondisi" id="kondisi">
                    <option value="1">Baik</option>
                    <option value="2">Rusak</option>
                    <option value="3">Kadaluarsa</option>
                  </select>
                </div>
              </form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-primary" id="save" onclick="saveRetur()">Save changes</button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->
<!-- end modal retur -->
<script>
$(window).on('load', function() { // makes sure the whole site is loaded
  $('.loader').fadeOut(); // will first fade out the loading animation
  $('.loader').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website.
  $('body').delay(350).css({'overflow':'visible'});
})
  $(function () {
  $('[data-toggle="tooltip"]').tooltip()
});

	function modal_retur(id,idProductLama){
      var mymodal = $('#modal-retur');
      mymodal.find('.modal-body #id_detail').val(id);
			mymodal.modal('show');
	}

  function hitungSubTotal(){

      let modal_retur = $('#modal_retur');
      qty = $('.modal-body #qty_retur').val();
      harga = $('.modal-body #harga_jual').val();
      if (qty == 0) {
        $('.modal-body #sub_total').val(harga);
      }else {
        $('.modal-body #sub_total').val(qty * harga);
      }
  }
  function saveRetur(){
    var data = {
          id_detail : $('.modal-body #id_detail').val(),
          id_product : $('.modal-body #id_product').val(),
          nama_product : $('.modal-body #selects-retur').val(),
          qty_retur : $('.modal-body #qty_retur').val(),
          keterangan : $('.modal-body #keterangan').val(),
          harga_beli : $('.modal-body #harga_beli').val(),
          harga_jual : $('.modal-body #harga_jual').val(),
          sub_total : $('.modal-body #sub_total').val(),
          kondisi : $('.modal-body #kondisi').val(),
    }
     // $('#table-row').childs('tr').append('<tr class="child"><td>blahblah<\/td></tr>');
    if (data.id_product != '' && data.qty_retur != '') {
      var JsonData = JSON.stringify(data);
      let NewRow = "";
      $.ajax({
          type: 'POST', // Metode pengiriman data menggunakan POST
          url: '<?php echo base_url(); ?>gudang/Penjualan/retur', // File pemroses data
          data: 'post=' + JsonData, // Data yang akan dikirim ke file pemroses
          success: function(response) { // Jika berhasil
              let hasil = JSON.parse(response);
              if (hasil.code == '200') {
                    let myModalRetur = $('#modal-retur');
                    myModalRetur.modal('hide');
                    NewRow += '<tr>';
                    NewRow += '<td> <input type="text" class="form-control " name="detail" disabled value="'+hasil.nama_obat+'"/></td>';
                    NewRow += '<td> <input type="number"  class="form-control " value="' + hasil.qty +'" disabled/></td>';
                    NewRow += '<td> <input type="text" class="form-control " value="' + hasil.harga + '" disabled/></td>';
                    NewRow += '<td><input type="text"   class="form-control " disabled value="' + hasil.sub_total + '"/></td>';
                    NewRow += '</tr>';
                    $('#table-body').append(NewRow);
                    $('#totalSemua').val('Rp. ' + hasil.total.toLocaleString('en', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
                    $('#id_product'+hasil.id).addClass('red');
                    $('#qty'+hasil.id).addClass('red');
                    $('#harga'+hasil.id).addClass('red');
                    $('#sub_totals'+hasil.id).addClass('red');
                    $('#Btnretur'+hasil.id).removeClass('btn-warning');
                    $('#Btnretur'+hasil.id).addClass('btn-info');
                    $('#Btnretur'+hasil.id).html('Telah Diretur');
                    $('#Btnretur'+hasil.id).prop('disabled',true);
              }else if (hasil.code == '300') {
                  let myModalRetur = $('#modal-retur');
                  myModalRetur.modal('hide');
                  let myModalAlert = $('#modal-alert');
                  myModalAlert.find('.modal-body').html("<p class='red'>Gagal Mengganti Data Lama !");
                  myModalAlert.modal('show');
              }else{
                let myModalRetur = $('#modal-retur');
                myModalRetur.modal('hide');
                let myModalAlert = $('#modal-alert');
                myModalAlert.find('.modal-body').html("<p class='red'>Gagal Simpan Data Retur !");
          			myModalAlert.modal('show');
              }
              console.log(JSON.parse(response));
            },
          ajaxSend: function(){
                $('.loader').fadeIn(3000); // will fade out the white DIV that covers the website.
                $('.loader').fadeOut('slow'); // will fade out the white DIV that covers the website.
          },
          beforeSend: function(){
                $('.loader').fadeIn(3000); // will fade out the white DIV that covers the website.
                $('.loader').fadeOut('slow');
          }

      });
    }else{
      alert('Harap Dipilih Obatnya dan Di isi QTY nya !');
    }
  }
   $('#selects-retur').selectize({
       valueField: 'nama_product',
       labelField: 'nama_product',
       searchField: 'nama_product',
       placeholder: "Ketik Untuk Mencari Nama Obat",
       options: [],
       create: false,
       render: {
           option: function(item, escape) {
               if (escape(item.qty) <= 0) {
                       return '<div style="color:red;" class="col-xs-12" style="border-top :1px solid #ccc; padding: 0px !important">' +
                               '<div class="col-xs-6" style="padding-left: 4px;color:red;">' + '<p><strong> Nama :' + escape(item.nama_product) + '</strong></p>' + '</div>' +
                               '<div class="col-xs-6" style="border-left :1px solid #ddd; padding: 0px;">' +
                                   '<div class="col-xs-12" style="padding-left: 4px;">' +
                                       '<p style="margin-bottom: 2px !important; color:red;"><strong> Harga :' + escape(item.harga_jual) + '</strong></p>' +
                                       '<p style="margin-bottom: 2px !important; color:red;"><small>Stock : ' + escape(item.qty) + '</small></p>' +
                                   '</div>' +
                                   //'<div class="col-xs-12">' + '<small>' + escape(item.ket_icd_icd10) + '</small>' + '</div>' +
                               '</div>' +
                           '</div>';
               }else{
                 return '<div class="col-xs-12" style="border-top :1px solid #ccc; padding: 0px !important">' +
                         '<div class="col-xs-6" style="padding-left: 4px;">' + '<p><strong> Nama :' + escape(item.nama_product) + '</strong></p>' + '</div>' +
                         '<div class="col-xs-6" style="border-left :1px solid #ddd; padding: 0px;">' +
                             '<div class="col-xs-12" style="padding-left: 4px;">' +
                                 '<p style="margin-bottom: 2px !important;"><strong> Harga :' + escape(item.harga_jual) + '</strong></p>' +
                                 '<p style="margin-bottom: 2px !important;"><small>Stock : ' + escape(item.qty) + '</small></p>' +
                             '</div>' +
                             //'<div class="col-xs-12">' + '<small>' + escape(item.ket_icd_icd10) + '</small>' + '</div>' +
                         '</div>' +
                     '</div>';
               }
           }
       },
       load: function(query, callback) {
           if (!query.length) return callback();
           $.ajax({
               url: '<?= base_url();?>gudang/product/jsonpenjualan',
               type: 'POST',
               dataType: 'json',
               data: {
               },
               error: function() {
                   callback();
               },
               success: function(res) {
                   callback(res);
               }
           });
       },
       onItemAdd: function(value,$item){
         let data = this.options[value];
           if (data.qty <= 0) {
             alert('Stock Tidak ada, Silahkan Pilih Obat lain atau buat penerimaan');
           }else{
             $('.modal-body #id_product').val(data.id_product);
             $('.modal-body #harga_jual').val(data.harga_jual);
             $('.modal-body #harga_beli').val(data.harga_beli);
           }

       },
       onDelete : function(value, $item) {
           let data = this.options[value];
           $('.modal-body #id_product').val("");
           $('.modal-body #harga_jual').val("");
           $('.modal-body #harga_beli').val("");
       },
       onItemRemove : function(value, $item) {
           let data = this.options[value];
           $('.modal-body #id_product').val("");
           $('.modal-body #harga_jual').val("");
           $('.modal-body #harga_beli').val("");
       },
       onLoad: function(){
           $('#selects-retur').val('Ketik Untuk Mencari Nama Obat');
       }
   });


</script>
