
  <?php foreach ($penjualan as $key => $row): ?>
    <tr>
      <td><?= $row->faktur_penjualan;?></td>
      <td><?= tanggal($row->tgl_penjualan);?></td>
      <td><?= $row->cara_bayar;?></td>
      <td><?= ($row->ppn == 1) ? $row->total * 10 / 100 : '0';?></td>
      <td><?= number_format( $row->total,2,',','.');?></td>
      <td>
        <?php if ($row->flag_lunas == 0): ?>
            <?= BtnEdit('gudang/penjualan/edit/'.$row->faktur_penjualan, $row->faktur_penjualan);?>
            <?= BtnDelete('gudang/penjualan/delete/'.$row->faktur_penjualan, $row->faktur_penjualan);?>
        <?php endif; ?>
        <?= BtnPrint('gudang/penjualan/print/'.$row->faktur_penjualan, $row->faktur_penjualan);?>
        <?= BtnView('gudang/penjualan/detail/'.$row->faktur_penjualan, $row->faktur_penjualan);?>
      </td>
    </tr>
  <?php endforeach ?>

  <script type="text/javascript">
  $(function () {
    $('[data-toggle="tooltip"]').tooltip()
  });

  </script>
